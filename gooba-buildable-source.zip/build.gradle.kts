plugins {
    id("fabric-loom") version "1.16.3"
}

version = property("mod_version") as String
group = property("maven_group") as String

base {
    archivesName.set(property("archives_base_name") as String)
}

repositories {
    mavenCentral()
}

dependencies {
    minecraft("com.mojang:minecraft:${property("minecraft_version")}")
    mappings("net.fabricmc:yarn:${property("yarn_mappings")}:v2")
    modImplementation("net.fabricmc:fabric-loader:${property("loader_version")}")
    modImplementation("net.fabricmc.fabric-api:fabric-api:${property("fabric_api_version")}")
    implementation(fileTree("src/main/resources/META-INF/jars") { include("*.jar") })
}

loom {
    accessWidenerPath.set(file("src/main/resources/client.accesswidener"))
}

tasks.remapJar {
    archiveFileName.set("goobaa-client-deobf-built.jar")
}

tasks.remapSourcesJar {
    archiveFileName.set("goobaa-client-deobf-built-sources.jar")
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(21)
}

java {
    withSourcesJar()
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
}
