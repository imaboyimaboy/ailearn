package dev.gooba.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class ThemeConfig {
    private static ThemeConfig instance;
    private static final Path THEME_DIRECTORY = GoobaPaths.CONFIG_DIRECTORY.resolve("theme");

    private final List<VisualEffectSettings> themes = new ArrayList<>();
    private static final Path ACTIVE_THEME_FILE = ThemeConfig.THEME_DIRECTORY.resolve(".active");
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private VisualEffectSettings activeTheme;

    private VisualEffectSettings loadTheme(Path path) {
        try {
            VisualEffectSettings visualEffectSettings2;
            try (InputStreamReader inputstreamreader =
                    new InputStreamReader(
                            new FileInputStream(path.toFile()), StandardCharsets.UTF_8)) {
                JsonObject jsonobject = JsonParser.parseReader(inputstreamreader).getAsJsonObject();
                String text;
                if (jsonobject.has("name")) {
                    text = jsonobject.get("name").getAsString();
                } else {
                    text = removeExtension(path.getFileName().toString());
                }

                VisualEffectSettings visualEffectSettings3 = new VisualEffectSettings(text);

                for (int i = 0; i < 8; i++) {
                    String colorKey = getColorKey(i);
                    if (jsonobject.has(colorKey)) {
                        visualEffectSettings3.colors[i] = jsonobject.get(colorKey).getAsInt();
                    }
                }

                for (int j = 0; j < visualEffectSettings3.values.length; j++) {
                    String valueKey = getValueKey(j);
                    if (jsonobject.has(valueKey)) {
                        visualEffectSettings3.setValue(j, jsonobject.get(valueKey).getAsFloat());
                    }
                }

                for (int k = 0; k < visualEffectSettings3.enabledEffects.length; k++) {
                    String effectKey = getEffectKey(k);
                    if (jsonobject.has(effectKey)) {
                        visualEffectSettings3.setEffectEnabled(
                                k, jsonobject.get(effectKey).getAsBoolean());
                    }
                }

                visualEffectSettings2 = visualEffectSettings3;
            }

            return visualEffectSettings2;
        } catch (Exception exception) {
            return null;
        }
    }

    public static ThemeConfig getInstance() {
        if (instance == null) {
            instance = new ThemeConfig();
            instance.loadThemes();
        }

        return instance;
    }

    public VisualEffectSettings getActiveTheme() {
        if (this.activeTheme == null) {
            this.activeTheme =
                    this.themes.isEmpty()
                            ? new VisualEffectSettings("Default")
                            : this.themes.get(0);
            if (this.themes.isEmpty()) {
                this.themes.add(this.activeTheme);
            }
        }

        return this.activeTheme;
    }

    private static VisualEffectSettings createBuiltInTheme(String text, int color, int colorValue) {
        VisualEffectSettings visualEffectSettings2 = new VisualEffectSettings(text);
        visualEffectSettings2.builtIn = true;
        visualEffectSettings2.colors[0] = color;
        visualEffectSettings2.colors[5] = colorValue;
        visualEffectSettings2.colors[3] = VisualEffectSettings.rgb(255, 255, 255);
        visualEffectSettings2.colors[4] = VisualEffectSettings.rgb(177, 177, 177);
        visualEffectSettings2.colors[1] = VisualEffectSettings.rgb(20, 23, 32);
        visualEffectSettings2.colors[2] = ColorUtils.cachedRgba(255, 255, 255, 15);
        visualEffectSettings2.colors[6] = ColorUtils.cachedRgba(255, 255, 255, 15);
        visualEffectSettings2.colors[7] = ColorUtils.cachedRgba(255, 255, 255, 10);
        visualEffectSettings2.setValue(0, 0.9F);
        visualEffectSettings2.setValue(1, 4.0F);
        visualEffectSettings2.setEffectEnabled(0, false);
        visualEffectSettings2.setEffectEnabled(1, false);
        return visualEffectSettings2;
    }

    private boolean isNameTaken(String text, VisualEffectSettings visualEffectSettings2) {
        return this.themes.stream()
                .anyMatch(
                        visualEffectSettings3 ->
                                visualEffectSettings3 != visualEffectSettings2
                                        && visualEffectSettings3.name.equalsIgnoreCase(text));
    }

    private static String getValueKey(int i) {
        switch (i) {
            case 0:
                return "opacity";
            case 1:
                return "blur";
            default:
                return "s" + i;
        }
    }

    private static String getEffectKey(int i) {
        switch (i) {
            case 0:
                return "shadow";
            case 1:
                return "distortion";
            default:
                return "b" + i;
        }
    }

    private String readActiveThemeName() {
        try {
            if (!Files.exists(ACTIVE_THEME_FILE)) {
                return null;
            }

            return new String(Files.readAllBytes(ACTIVE_THEME_FILE), StandardCharsets.UTF_8).trim();
        } catch (IOException ioexception) {
            return null;
        }
    }

    private static String removeExtension(String text) {
        int i = text.lastIndexOf(46);
        return i > 0 ? text.substring(0, i) : text;
    }

    public void loadThemes() {
        this.themes.clear();
        this.themes.add(
                createBuiltInTheme(
                        "Blue",
                        VisualEffectSettings.rgb(92, 160, 245),
                        VisualEffectSettings.rgb(118, 142, 203)));
        this.themes.add(
                createBuiltInTheme(
                        "Red",
                        VisualEffectSettings.rgb(246, 124, 126),
                        VisualEffectSettings.rgb(246, 124, 126)));

        try {
            Files.createDirectories(THEME_DIRECTORY);

            try (DirectoryStream<Path> directorystream =
                    Files.newDirectoryStream(THEME_DIRECTORY, "*.json")) {
                for (Path pathx : directorystream) {
                    VisualEffectSettings visualEffectSettings2 = this.loadTheme(pathx);
                    if (visualEffectSettings2 != null
                            && !this.isNameTaken(visualEffectSettings2.name, null)) {
                        this.themes.add(visualEffectSettings2);
                    }
                }
            }
        } catch (IOException ioexception) {
        }

        String text = this.readActiveThemeName();
        this.activeTheme =
                this.themes.stream()
                        .filter(visualEffectSettings3 -> visualEffectSettings3.name.equals(text))
                        .findFirst()
                        .orElse(this.themes.get(0));
    }

    private static String getColorKey(int i) {
        switch (i) {
            case 0:
                return "accent";
            case 1:
                return "background";
            case 2:
                return "outline";
            case 3:
                return "text";
            case 4:
                return "text2";
            case 5:
                return "element";
            case 6:
                return "separator";
            case 7:
                return "lightbg";
            default:
                return "c" + i;
        }
    }
}
