package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class TimedAnimation {
    protected int durationMillis;
    protected double endValue;
    public DeadlineTimer timer = new DeadlineTimer();
    protected AnimationDirection direction;

    public boolean isFinished() {
        return this.timer.hasElapsed((double) this.durationMillis);
    }

    public void setDirection(AnimationDirection animationDirection2) {
        if (this.direction != animationDirection2) {
            this.direction = animationDirection2;
            this.timer.setStartTime(
                    System.currentTimeMillis()
                            - ((long) this.durationMillis
                                    - Math.min(
                                            (long) this.durationMillis,
                                            this.timer.elapsedMillis())));
        }
    }

    public float getValue() {
        if (this.direction == AnimationDirection.FORWARDS) {
            return this.isFinished()
                    ? (float) this.endValue
                    : (float) (this.evaluate((double) this.timer.elapsedMillis()) * this.endValue);
        } else if (this.isFinished()) {
            return 0.0F;
        } else if (this.reverseEasing()) {
            double d0 =
                    (double)
                            Math.min(
                                    (long) this.durationMillis,
                                    Math.max(
                                            0L,
                                            (long) this.durationMillis
                                                    - this.timer.elapsedMillis()));
            return (float) (this.evaluate(d0) * this.endValue);
        } else {
            return (float)
                    ((1.0 - this.evaluate((double) this.timer.elapsedMillis())) * this.endValue);
        }
    }

    public TimedAnimation(int durationMillisValue, double endValueValue) {
        this.durationMillis = durationMillisValue;
        this.endValue = endValueValue;
        this.direction = AnimationDirection.FORWARDS;
    }

    protected boolean reverseEasing() {
        return false;
    }

    protected abstract double evaluate(double d0);

    public TimedAnimation(
            int durationMillisValue, double endValueValue, AnimationDirection animationDirection2) {
        this.durationMillis = durationMillisValue;
        this.endValue = endValueValue;
        this.direction = animationDirection2;
    }
}
