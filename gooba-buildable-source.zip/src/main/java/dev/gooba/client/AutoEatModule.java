package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.item.ItemStack;

@ModuleInfo(
        name = "Auto Eat",
        category = ModuleCategory.OTHER,
        desc = "Automatically eats food when health or hunger is low.")
@Environment(EnvType.CLIENT)
public class AutoEatModule extends Module {

    private int previousSlot;
    public final ModeSetting foodPrioritySetting;
    public final ModeSetting thresholdModeSetting =
            new ModeSetting(
                    this,
                    "Threshold Mode",
                    new String[] {"Any", "Health", "Hunger", "Any", "Both"});
    private int foodSlot;
    private boolean eating;
    public final BooleanSetting searchInventorySetting;
    public final SliderSetting hungerThresholdSetting;
    public final SliderSetting healthThresholdSetting =
            new SliderSetting(this, "Health Threshold", 10.0F, 1.0F, 19.0F, 1.0F);

    private boolean hasAlwaysEdibleFood() {
        for (int i = 0; i < 9; i++) {
            FoodComponent foodcomponent =
                    client.player.getInventory().getStack(i).get(DataComponentTypes.FOOD);
            if (foodcomponent != null && foodcomponent.canAlwaysEat()) {
                return true;
            }
        }

        return false;
    }

    private int findFoodSlot() {
        ItemStack itemstack = client.player.getOffHandStack();
        if (this.isFood(itemstack)) {
            return 40;
        } else {
            int i = this.findBestFoodSlot(0, 9);
            if (i >= 0) {
                return i;
            } else {
                return this.searchInventorySetting.isOn()
                        ? this.findBestFoodSlot(9, client.player.getInventory().size())
                        : -1;
            }
        }
    }

    private int findBestFoodSlot(int firstSlot, int endSlot) {
        int bestSlot = -1;
        float bestScore = -1.0F;
        for (int slot = firstSlot; slot < endSlot; slot++) {
            ItemStack stack = client.player.getInventory().getStack(slot);
            FoodComponent food = stack.get(DataComponentTypes.FOOD);
            if (food == null) continue;
            float score =
                    switch (foodPrioritySetting.getSelectedMode()) {
                        case "Hunger" -> food.nutrition();
                        case "Combined" -> food.nutrition() + food.saturation();
                        default -> food.saturation();
                    };
            if (score > bestScore) {
                bestScore = score;
                bestSlot = slot;
            }
        }
        return bestSlot;
    }

    private void stopEating() {
        client.options.useKey.setPressed(false);
        if (this.previousSlot >= 0 && this.previousSlot < 9) {
            client.player.getInventory().setSelectedSlot(this.previousSlot);
        }

        this.previousSlot = -1;
        this.foodSlot = -1;
        this.eating = false;
    }

    private void startEating() {
        int foodSlotValue = this.findFoodSlot();
        if (foodSlotValue >= 0) {
            this.previousSlot = client.player.getInventory().getSelectedSlot();
            this.foodSlot = foodSlotValue;
            if (foodSlotValue < 9) {
                client.player.getInventory().setSelectedSlot(foodSlotValue);
            }

            client.options.useKey.setPressed(true);
            this.eating = true;
        }
    }

    public AutoEatModule() {
        this.hungerThresholdSetting =
                new SliderSetting(this, "Hunger Threshold", 16.0F, 1.0F, 19.0F, 1.0F);
        this.searchInventorySetting = new BooleanSetting(this, "Search Inventory", false);
        this.foodPrioritySetting =
                new ModeSetting(
                        this,
                        "Food Priority",
                        new String[] {"Saturation", "Combined", "Hunger", "Saturation"});
        this.foodSlot = -1;
        this.previousSlot = -1;
    }

    private boolean isFood(ItemStack itemstack) {
        return itemstack != null && itemstack.get(DataComponentTypes.FOOD) != null;
    }

    private boolean shouldEat() {
        boolean lowHealth = client.player.getHealth() <= healthThresholdSetting.getFloat();
        boolean lowHunger =
                client.player.getHungerManager().getFoodLevel()
                        <= hungerThresholdSetting.getFloat();
        boolean belowThreshold =
                switch (thresholdModeSetting.getSelectedMode()) {
                    case "Health" -> lowHealth;
                    case "Hunger" -> lowHunger;
                    case "Both" -> lowHealth && lowHunger;
                    default -> lowHealth || lowHunger;
                };
        return belowThreshold
                && (client.player.getHungerManager().isNotFull() || hasAlwaysEdibleFood());
    }

    @Override
    protected void onDisable() {
        if (client.player != null) {
            client.options.useKey.setPressed(false);
        }

        this.previousSlot = -1;
        this.foodSlot = -1;
        this.eating = false;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null && client.currentScreen == null) {
            if (this.eating) {
                if (this.shouldEat()
                        && this.isFood(client.player.getInventory().getStack(this.foodSlot))) {
                    if (this.foodSlot < 9) {
                        client.player.getInventory().setSelectedSlot(this.foodSlot);
                    }

                    client.options.useKey.setPressed(true);
                } else {
                    this.stopEating();
                }
            } else {
                if (this.shouldEat()) {
                    this.startEating();
                }
            }
        }
    }
}
