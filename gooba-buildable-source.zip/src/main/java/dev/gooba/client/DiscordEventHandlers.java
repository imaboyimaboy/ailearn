package dev.gooba.client;

import com.sun.jna.Structure;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Arrays;
import java.util.List;

@Environment(EnvType.CLIENT)
public class DiscordEventHandlers extends Structure {
    public DiscordReadyCallback ready;
    public DiscordJoinGameCallback joinGame;
    public DiscordDisconnectedCallback disconnected;

    public DiscordJoinRequestCallback joinRequest;
    public DiscordErrorCallback errored;
    public DiscordSpectateGameCallback spectateGame;

    protected List<String> getFieldOrder() {
        return Arrays.asList(
                "ready", "disconnected", "errored", "joinGame", "spectateGame", "joinRequest");
    }
}
