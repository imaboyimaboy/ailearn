package dev.gooba.client;

import dev.redstones.mediaplayerinfo.IMediaSession;
import dev.redstones.mediaplayerinfo.MediaInfo;
import dev.redstones.mediaplayerinfo.MediaPlayerInfo;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.math.MathHelper;

import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

@Environment(EnvType.CLIENT)
public class MediaPlayerHud implements HudElement {
    private final float[] barHeights;
    private final float[] barPhases;
    private final MediaPlayerHud.AnimatedText animatedText;
    private static final MediaInfo PREVIEW_MEDIA =
            new MediaInfo("Track title", "Artist", new byte[0], 43L, 150L, false);
    private final float[] barTargets;
    private final MediaPlayerHud.AnimatedText animatedText2;
    private final ElapsedTimer mediaAge = new ElapsedTimer();
    private final EasingAnimation visibilityAnimation;
    private final float[] barSpeeds;
    private volatile MediaInfo currentMedia;
    private float playbackProgress;
    private volatile IMediaSession session;
    private ExecutorService worker;
    private float animationTime;
    private long lastFrameNanos;
    private static final EasingFunction TEXT_EASING = d0 -> cubicBezier(d0, 0.45, 1.45, 0.49, 1.15);
    private long lastBarUpdateNanos;

    private static EasingAnimation createAnimation(float f) {
        return new EasingAnimation()
                .setCurrentValue((double) f)
                .setPreviousValue((double) f)
                .setStartValue((double) f)
                .setTargetValue((double) f)
                .setDurationMillis(1.0);
    }

    public void nextTrack() {
        this.withSession(IMediaSession::next);
    }

    private void updateVisualizer(float f, boolean flag) {
        long nowNanos = System.nanoTime();
        if ((nowNanos - this.lastBarUpdateNanos) / 1000000L >= 90L) {
            this.lastBarUpdateNanos = nowNanos;
            byte b0 = 15;

            for (int j = 0; j <= b0; j++) {
                float f1 = 1.0F - (float) j / (float) (b0 + 1) * 0.55F;
                float f2 = 0.15F + (float) Math.random() * 0.85F;
                float barTarget = MathHelper.clamp(f2 * f1, 0.04F, 1.0F);
                this.barTargets[b0 - j] = barTarget;
                this.barTargets[b0 + j] = barTarget;
            }
        }

        for (int k = 0; k < 31; k++) {
            this.barPhases[k] = this.barPhases[k] + this.barSpeeds[k] * f;
            float f4 =
                    flag
                            ? (float) Math.sin((double) this.barPhases[k]) * 0.05F
                            : -this.barTargets[k];
            float f5 = MathHelper.clamp(this.barTargets[k] + f4, 0.03F, 1.0F);
            this.barHeights[k] =
                    this.barHeights[k]
                            + (f5 - this.barHeights[k]) * MathHelper.clamp(f * 10.0F, 0.0F, 1.0F);
        }
    }

    private static String formatTime(int i) {
        String text = String.format("%02d", i % 60);
        int j = i / 60;
        return j + ":" + text;
    }

    public MediaPlayerHud() {
        this.barTargets = new float[31];
        this.barHeights = new float[31];
        this.barPhases = new float[31];
        this.barSpeeds = new float[31];
        this.animatedText = new MediaPlayerHud.AnimatedText();
        this.animatedText2 = new MediaPlayerHud.AnimatedText();
        this.visibilityAnimation = createAnimation(0.0F);
        this.currentMedia = PREVIEW_MEDIA;
        this.lastFrameNanos = System.nanoTime();
        this.lastBarUpdateNanos = System.nanoTime();
        byte b0 = 15;

        for (int i = 0; i <= b0; i++) {
            float barPhase = (float) (Math.random() * Math.PI * 2.0);
            float barSpeed = 2.2F + (float) Math.random() * 2.6F;
            int j = b0 - i;
            int k = b0 + i;
            this.barPhases[j] = barPhase;
            this.barSpeeds[j] = barSpeed;
            this.barPhases[k] = barPhase;
            this.barSpeeds[k] = barSpeed;
        }
    }

    public void refreshMedia() {
        if (client.player != null && client.world != null && client.player.age % 5 == 0) {
            this.getWorker()
                    .submit(
                            () -> {
                                try {
                                    IMediaSession imediasession =
                                            MediaPlayerInfo.Instance.getMediaSessions().stream()
                                                    .max(
                                                            Comparator.comparingInt(
                                                                    imediasessionx ->
                                                                            imediasessionx
                                                                                            .getMedia()
                                                                                            .getPlaying()
                                                                                    ? 1
                                                                                    : 0))
                                                    .orElse(null);
                                    this.session = imediasession;
                                    if (imediasession == null) {
                                        return;
                                    }

                                    MediaInfo mediainfo = imediasession.getMedia();
                                    if (mediainfo.getTitle().isEmpty()
                                            && mediainfo.getArtist().isEmpty()) {
                                        return;
                                    }

                                    this.currentMedia = mediainfo;
                                    this.mediaAge.reset();
                                    MediaArtwork.setArtwork(mediainfo.getArtworkPng());
                                } catch (Throwable throwable) {
                                }
                            });
        }
    }

    public void previousTrack() {
        this.withSession(IMediaSession::previous);
    }

    private void drawScrollingText(
            Font font, String text, float f, float f1, float f2, float size) {
        String string = text == null ? "" : text;
        String textValue = "  |  ";
        float f4 = font.measureWidth(string + textValue, size);
        if (f4 - f2 < 10.0F) {
            font.drawText(string, f, f1, size);
        } else {
            int i = Math.max(1, (int) (f4 * 75.0F));
            float f5 =
                    (float)
                                    MathHelper.clamp(
                                            (double) (System.currentTimeMillis() % (long) i)
                                                    * Math.PI
                                                    / (double) i,
                                            0.0,
                                            1.0)
                            * f4;
            font.drawText(string + textValue + string, f - f5, f1, size);
        }
    }

    private void updatePlaybackAnimation(float f, boolean flag) {
        float playbackProgressValue = flag ? 1.0F : 0.0F;
        float f2 = 1.0F - (float) Math.exp((double) (-7.5F * f));
        this.playbackProgress =
                this.playbackProgress + (playbackProgressValue - this.playbackProgress) * f2;
        if (Math.abs(playbackProgressValue - this.playbackProgress) < 0.001F) {
            this.playbackProgress = playbackProgressValue;
        }

        this.animationTime += f;
    }

    public void togglePlayback() {
        this.withSession(IMediaSession::playPause);
    }

    private synchronized ExecutorService getWorker() {
        if (this.worker == null || this.worker.isShutdown()) {
            this.worker =
                    Executors.newSingleThreadExecutor(
                            runnable -> {
                                Thread thread = new Thread(runnable, "goobaa-media-hud");
                                thread.setDaemon(true);
                                return thread;
                            });
        }

        return this.worker;
    }

    private static double cubicBezier(double d0, double d1, double d2, double d3, double d4) {
        if (d0 <= 0.0) {
            return 0.0;
        } else if (d0 >= 1.0) {
            return 1.0;
        } else {
            double d5 = d0;

            for (int i = 0; i < 8; i++) {
                double d6 = 1.0 - d5;
                double d7 = 3.0 * d6 * d6 * d5 * d1 + 3.0 * d6 * d5 * d5 * d3 + d5 * d5 * d5;
                double d8 =
                        3.0 * (d6 * (1.0 - 3.0 * d5) * d1 + (2.0 * d5 - 3.0 * d5 * d5) * d3)
                                + 3.0 * d5 * d5;
                if (Math.abs(d7 - d0) < 1.0E-5 || Math.abs(d8) < 1.0E-6) {
                    break;
                }

                d5 = Math.max(0.0, Math.min(1.0, d5 - (d7 - d0) / d8));
            }

            double d9 = 1.0 - d5;
            return 3.0 * d9 * d9 * d5 * d2 + 3.0 * d9 * d5 * d5 * d4 + d5 * d5 * d5;
        }
    }

    @Override
    public void render(PositionSetting positionSetting2, HUDModule hUDModule) {
        boolean flag;
        flag =
                !(!hUDModule.alwaysShowSetting.isOn()
                        && this.mediaAge.hasElapsed(2000.0)
                        && !(client.currentScreen instanceof ChatScreen));

        float opacity = animateTo(this.visibilityAnimation, flag ? 1.0F : 0.0F);
        float f1 = hUDModule.hudSizeSetting.getFloat();
        float width3 = 150.0F * f1;
        float heightValue = 46.0F * f1;
        if (!flag && !(opacity > 0.01F)) {
            positionSetting2.visible = false;
        } else {
            positionSetting2.visible = true;
        }

        positionSetting2.size.set(width3, heightValue);
        if (!(opacity <= 0.01F)) {
            float innerX = positionSetting2.position.x;
            float innerY = positionSetting2.position.y;
            float sizeValue = 8.0F * f1;
            float width = 38.0F * f1;
            float innerXValue = innerX + 3.0F * f1;
            float innerYValue = innerY + 4.0F * f1;
            float f10 = innerXValue + width + 3.0F * f1;
            float f11 = width3 - (f10 - innerX) - 5.0F * f1;
            float f12 = innerY + 4.0F * f1;
            float f13 = innerY + 14.0F * f1;
            float f14 = innerY + 24.0F * f1;
            float f15 = innerY + 35.0F * f1;
            Font font = Fonts.SF_MEDIUM;
            MediaInfo mediainfo = this.currentMedia;
            int i = Math.max(1, (int) mediainfo.getDuration());
            int j = MathHelper.clamp((int) mediainfo.getPosition(), 0, i);
            String string = formatTime(j);
            String stringValue = formatTime(i);
            String text = "-" + stringValue;
            this.animatedText.setText(string);
            this.animatedText2.setText(text);
            long nowNanos = System.nanoTime();
            float f16 =
                    MathHelper.clamp((float) (nowNanos - this.lastFrameNanos) / 1.0E9F, 0.0F, 0.1F);
            this.lastFrameNanos = nowNanos;
            boolean flag1;
            flag1 = (this.session != null && mediainfo.getPlaying());

            this.updateVisualizer(f16, flag1);
            this.updatePlaybackAnimation(f16, flag1);
            hUDModule.drawBackground(innerX, innerY, width3, heightValue, 3.0F * f1, opacity);
            RenderUtils.Render2D.drawRoundedRect(
                    innerXValue,
                    innerYValue,
                    width,
                    width,
                    ColorUtils.cachedRgba(0, 0, 0, Math.round(180.0F * opacity)),
                    3.0F * f1);
            if (MediaArtwork.isAvailable()) {
                RenderUtils.Images.drawRoundedImage(
                        MediaArtwork.TEXTURE_ID,
                        innerXValue,
                        innerYValue,
                        width,
                        width,
                        1.0F,
                        3.0F * f1,
                        ColorUtils.grayscaleOpacity(255, opacity));
            } else {
                float size = 9.0F * f1;
                Fonts.GOOBA.drawCenteredText(
                        "M",
                        innerXValue + width / 2.0F,
                        Fonts.GOOBA.centerTextY("M", innerYValue, width, size),
                        size,
                        hUDModule.getAccentColor(opacity));
            }

            ColorUtils.cachedRgba(255, 255, 255, Math.round(191.0F * opacity));
            font.drawText("now playing", f10, f12, sizeValue);
            ScissorStack.push(f10, innerY, f11, heightValue);
            String title = mediainfo.getTitle();
            ColorUtils.grayscaleOpacity(255, opacity);
            this.drawScrollingText(font, title, f10, f13, f11, sizeValue);
            title = mediainfo.getArtist();
            ColorUtils.grayscaleOpacity(255, opacity);
            this.drawScrollingText(font, title, f10, f14, f11, sizeValue);
            ScissorStack.pop();
            float f40 = this.animatedText.measureWidth(font, sizeValue);
            float f18 = this.animatedText2.measureWidth(font, sizeValue);
            float f19 = smoothstep(this.playbackProgress);
            float f20 = smoothstep(this.playbackProgress / 0.45F);
            float f21 = 1.0F - f20;
            float f22 = smoothstep((this.playbackProgress - 0.25F) / 0.75F);
            this.animatedText.render(
                    font,
                    f10,
                    f15,
                    false,
                    sizeValue,
                    ColorUtils.opaqueGrayscale(255),
                    f19 * opacity,
                    f1);
            this.animatedText2.render(
                    font,
                    f10 + f11,
                    f15,
                    true,
                    sizeValue,
                    ColorUtils.opaqueGrayscale(255),
                    f19 * opacity,
                    f1);
            float f23 = f10 + f40 + 3.0F * f1;
            float f24 = f11 - f40 - f18 - 6.0F * f1;
            float f25 = f15 + 4.5F * f1;
            float f26 = 13.0F * f1;
            float f27 = 1.2F * f1;
            float widthValue = 1.3F * f1;
            int l = Math.max(1, (int) ((f24 + f27) / (widthValue + f27)));
            if (l % 2 == 0) {
                l--;
            }

            float f29 = f23 + f24 / 2.0F;
            float f30 = (float) l * widthValue + (float) (l - 1) * f27;
            float f31 = f29 - f30 / 2.0F;
            int i1 = l / 2;
            if (f21 > 0.001F) {
                ScissorStack.push(f10, f25 - f26 / 2.0F - 2.0F * f1, f11, f26 + 4.0F * f1);
                this.drawWaitingText(
                        font,
                        f10 + f11 / 2.0F,
                        f15,
                        f20,
                        f21 * opacity,
                        sizeValue,
                        f1,
                        hUDModule.getAccentColor(1.0F));
                ScissorStack.pop();
            }

            if (f24 > 0.0F) {
                ScissorStack.push(f23, f25 - f26 / 2.0F - 2.0F * f1, f24, f26 + 4.0F * f1);

                for (int j1 = 0; j1 < l && f19 > 0.0F; j1++) {
                    float f32 = l == 1 ? 0.0F : (float) j1 / (float) (l - 1);
                    int k1 = MathHelper.clamp(Math.round(f32 * 30.0F), 0, 30);
                    float f33 = Math.max(widthValue, this.barHeights[k1] * f26);
                    float f34 = i1 == 0 ? 0.0F : (float) Math.abs(j1 - i1) / (float) i1;
                    float f35 = smoothstep(f22 * 1.35F - f34 * 0.35F);
                    if (!(f35 <= 0.001F)) {
                        float f36 = f31 + (float) j1 * (widthValue + f27);
                        float innerX2 = MathHelper.lerp(f35, f29 - widthValue / 2.0F, f36);
                        float height = MathHelper.lerp(f35, widthValue, f33);
                        float innerY2 = f25 - height / 2.0F;
                        RenderUtils.Render2D.drawRoundedRect(
                                innerX2,
                                innerY2,
                                widthValue,
                                height,
                                ColorUtils.scaleAlpha(
                                        hUDModule.getAccentColor(1.0F), 0.85F * opacity * f35),
                                widthValue / 2.0F);
                    }
                }

                ScissorStack.pop();
            }
        }
    }

    public void close() {
        if (this.worker != null) {
            this.worker.shutdownNow();
        }

        MediaArtwork.reset();
    }

    private static float animateTo(EasingAnimation easingAnimation2, float f) {
        easingAnimation2.animateTo((double) f, 0.2F, Easings.OUT_QUAD, true);
        easingAnimation2.update();
        return easingAnimation2.getFloatValue();
    }

    private void withSession(Consumer<IMediaSession> consumer) {
        IMediaSession imediasession = this.session;
        if (imediasession != null) {
            this.getWorker()
                    .submit(
                            () -> {
                                try {
                                    consumer.accept(imediasession);
                                } catch (Throwable throwable) {
                                }
                            });
        }
    }

    private void drawWaitingText(
            Font font, float f, float f1, float f2, float factor, float size, float f5, int color) {
        String stringValue = "waiting";
        String string = stringValue + "...";
        float f6 = font.measureWidth(string, size);
        float f7 = Math.max(0.02F, 1.0F - f2);
        float f8 = Math.max(f5, f6 * f7);
        ScissorStack.push(f - f8 / 2.0F, f1 - 2.0F * f5, f8, size + 4.0F * f5);
        float f9 = f - f6 / 2.0F;
        ColorUtils.scaleAlpha(color, factor);
        font.drawText(stringValue, f9, f1, size);

        for (int j = 0; j < 3; j++) {
            float f10 =
                    0.3F
                            + 0.7F
                                    * ((float)
                                                            Math.sin(
                                                                    (double)
                                                                            (this.animationTime
                                                                                            * 4.2F
                                                                                    - (float) j
                                                                                            * 0.85F))
                                                    * 0.5F
                                            + 0.5F);
            String text = ".".repeat(j);
            float f11 = f9 + font.measureWidth(stringValue + text, size);
            ColorUtils.scaleAlpha(color, factor * f10);
            font.drawText(".", f11, f1, size);
        }

        ScissorStack.pop();
    }

    private static float smoothstep(float f) {
        float f1 = MathHelper.clamp(f, 0.0F, 1.0F);
        return f1 * f1 * (3.0F - 2.0F * f1);
    }

    @Environment(EnvType.CLIENT)
    private static final class AnimatedText {
        private String previousText;
        private String currentText;
        private final EasingAnimation transition = MediaPlayerHud.createAnimation(1.0F);

        private AnimatedText() {
            this.previousText = "";
            this.currentText = "";
        }

        private void setText(String text) {
            String stringValue = text == null ? "" : text;
            if (this.currentText.isEmpty()) {
                this.previousText = stringValue;
                this.currentText = stringValue;
                this.transition.snapTo(1.0);
            } else if (!this.transition.isRunning() && !stringValue.equals(this.currentText)) {
                this.previousText = this.currentText;
                this.currentText = stringValue;
                this.transition.snapTo(0.0);
                this.transition.animateTo(1.0, 0.24F, MediaPlayerHud.TEXT_EASING, false);
            }

            this.transition.update();
        }

        private float measureWidth(Font font, float size) {
            return Math.max(
                    font.measureWidth(this.previousText, size),
                    font.measureWidth(this.currentText, size));
        }

        private int commonPrefixLength() {
            int i = Math.min(this.previousText.length(), this.currentText.length());
            int j = 0;

            while (j < i
                    && this.previousText.charAt(j) == this.currentText.charAt(j)
                    && !Character.isDigit(this.currentText.charAt(j))) {
                j++;
            }

            return j;
        }

        private void drawGlyph(
                Font font, char c0, float f, float f1, float size, int color, float f3) {
            if (!(f3 <= 0.0F)) {
                String stringValue = String.valueOf(c0);
                ColorUtils.scaleAlpha(color, MathHelper.clamp(f3, 0.0F, 1.0F));
                font.drawText(stringValue, f, f1, size);
            }
        }

        private void render(
                Font font,
                float f,
                float f1,
                boolean flag,
                float size,
                int color,
                float factor,
                float f4) {
            float f5 = flag ? f - font.measureWidth(this.previousText, size) : f;
            float f6 = flag ? f - font.measureWidth(this.currentText, size) : f;
            float floatValue = this.transition.getFloatValue();
            if (!this.previousText.equals(this.currentText) && this.transition.isRunning()) {
                float f8 = MathHelper.clamp(floatValue, 0.0F, 1.0F) * factor;
                float f9 = MathHelper.clamp(1.0F - floatValue, 0.0F, 1.0F) * factor;
                int j = this.commonPrefixLength();
                int k = this.previousText.length() - this.currentText.length();
                boolean[] aboolean = new boolean[this.previousText.length()];

                for (int l = 0; l < this.currentText.length(); l++) {
                    int i1 = l < j ? l : l + k;
                    boolean flag1;
                    flag1 = (i1 >= j && i1 < this.previousText.length());

                    char c0 = this.currentText.charAt(l);
                    char c1;
                    if (flag1) {
                        c1 = this.previousText.charAt(i1);
                    } else {
                        c1 = 0;
                    }

                    float f10 = f6 + font.measureWidth(this.currentText.substring(0, l), size);
                    if (flag1) {
                        aboolean[i1] = true;
                    }

                    if (flag1 && c1 == c0) {
                        this.drawGlyph(font, c0, f10, f1, size, color, factor);
                    } else {
                        if (Character.isDigit(c0)) {
                            this.drawGlyph(
                                    font,
                                    c0,
                                    f10,
                                    f1 + 4.0F * f4 * (1.0F - floatValue),
                                    size,
                                    color,
                                    f8);
                        } else {
                            this.drawGlyph(font, c0, f10, f1, size, color, factor);
                        }

                        if (flag1 && Character.isDigit(c1)) {
                            float f11 =
                                    f5
                                            + font.measureWidth(
                                                    this.previousText.substring(0, i1), size);
                            this.drawBlurredGlyph(
                                    font,
                                    c1,
                                    f11,
                                    f1 - 4.0F * f4 * floatValue,
                                    size,
                                    color,
                                    f9,
                                    f4);
                        }
                    }
                }

                for (int j1 = 0; j1 < this.previousText.length(); j1++) {
                    if (!aboolean[j1]) {
                        char c2 = this.previousText.charAt(j1);
                        if (Character.isDigit(c2)) {
                            float f12 =
                                    f5
                                            + font.measureWidth(
                                                    this.previousText.substring(0, j1), size);
                            this.drawBlurredGlyph(
                                    font,
                                    c2,
                                    f12,
                                    f1 - 4.0F * f4 * floatValue,
                                    size,
                                    color,
                                    f9,
                                    f4);
                        }
                    }
                }
            } else {
                String stringValue = this.currentText;
                ColorUtils.scaleAlpha(color, factor);
                font.drawText(stringValue, f6, f1, size);
            }
        }

        private void drawBlurredGlyph(
                Font font, char c0, float f, float f1, float size, int color, float f3, float f4) {
            this.drawGlyph(font, c0, f, f1 - 0.45F * f4, size, color, f3 * 0.18F);
            this.drawGlyph(font, c0, f, f1, size, color, f3 * 0.64F);
            this.drawGlyph(font, c0, f, f1 + 0.45F * f4, size, color, f3 * 0.18F);
        }
    }
}
