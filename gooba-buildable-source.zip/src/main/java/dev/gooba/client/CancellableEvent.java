package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class CancellableEvent extends Event implements Cancellable {
    private boolean cancelled;

    @Override
    public void cancel() {
        Cancellable.super.cancel();
    }

    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }

    @Override
    public void setCancelled(boolean cancelledValue) {
        this.cancelled = cancelledValue;
    }
}
