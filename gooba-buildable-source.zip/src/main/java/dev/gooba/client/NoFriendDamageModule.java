package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "No Friend Damage",
        desc = "Prevents you from attacking players on your friend list",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class NoFriendDamageModule extends Module {
    @EventHandler
    public void onAttack(AttackEvent attackEvent) {
        if (Gooba.getInstance()
                .getFriendManager()
                .isFriend(attackEvent.getTarget().getName().getString())) {
            attackEvent.cancel();
        }
    }
}
