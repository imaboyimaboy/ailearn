package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class GuiSounds {
    private static long lastTypingMillis;
    private static long lastSliderMillis;

    public static void playClose() {
        playDefaultPitch("guiclose", 0.45F);
    }

    private static void play(String text, float f, float f1) {
        SoundPlayer.play(text, f, f1);
    }

    public static void playSliderDrag(float f) {
        if (hasDelayElapsed(lastSliderMillis, 28L)) {
            lastSliderMillis = System.currentTimeMillis();
            play("slider", 0.3F, 0.9F + 0.35F * Math.max(0.0F, Math.min(1.0F, f)));
        }
    }

    public static void playOpen() {
        playDefaultPitch("guiopen", 0.45F);
    }

    public static void playOptionSelection(int i, int j) {
        float f;
        if (j <= 1) {
            f = 0.0F;
        } else {
            f = (float) i / (float) (j - 1);
        }

        play("boolean_value", 0.45F, 0.95F + 0.15F * f);
    }

    public static void playExpand(boolean flag) {
        play("expand_module", 0.4F, flag ? 1.0F : 0.88F);
    }

    public static void playDeleteCharacter() {
        if (hasDelayElapsed(lastTypingMillis, 25L)) {
            lastTypingMillis = System.currentTimeMillis();
            play("boolean_value", 0.3F, 0.88F);
        }
    }

    public static void playSoftBindRemove() {
        playDefaultPitch("bind_remove", 0.35F);
    }

    private static boolean hasDelayElapsed(long i, long j) {
        return System.currentTimeMillis() - i >= j;
    }

    public static void playSoftBindSuccess() {
        playDefaultPitch("bind_success", 0.35F);
    }

    public static void playBindRemove() {
        playDefaultPitch("bind_remove", 0.4F);
    }

    public static void playBindSuccess() {
        playDefaultPitch("bind_success", 0.4F);
    }

    public static void playBooleanToggle(boolean flag) {
        play("boolean_value", 0.4F, flag ? 1.08F : 0.92F);
    }

    public static void playTypeCharacter() {
        if (hasDelayElapsed(lastTypingMillis, 25L)) {
            lastTypingMillis = System.currentTimeMillis();
            play("boolean_value", 0.35F, 1.0F + (float) (Math.random() * 0.12F - 0.06F));
        }
    }

    public static void playHighSlider() {
        play("slider", 0.3F, 1.25F);
    }

    public static void playSlider() {
        playDefaultPitch("slider", 0.35F);
    }

    public static void playOptionToggle(boolean flag) {
        play("boolean_value", 0.4F, flag ? 1.08F : 0.92F);
    }

    public static void playModuleExpand(boolean flag) {
        play("expand_module", 0.45F, flag ? 1.0F : 0.88F);
    }

    public static void playColorSlider(float f) {
        if (hasDelayElapsed(lastSliderMillis, 22L)) {
            lastSliderMillis = System.currentTimeMillis();
            play("slider", 0.35F, 0.9F + 0.35F * Math.max(0.0F, Math.min(1.0F, f)));
        }
    }

    private static void playDefaultPitch(String text, float f) {
        SoundPlayer.playDefaultPitch(text, f);
    }

    public static void playLowSlider() {
        if (hasDelayElapsed(lastSliderMillis, 55L)) {
            lastSliderMillis = System.currentTimeMillis();
            play("slider", 0.35F, 0.82F);
        }
    }

    public static void playSelection() {
        playDefaultPitch("boolean_value", 0.4F);
    }

    public static void playConfirmation() {
        playDefaultPitch("boolean_value", 0.45F);
    }
}
