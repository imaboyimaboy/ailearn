package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.util.Identifier;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class TextureBatchRenderer implements RenderBatchDispatcher.Batched {
    private static final Identifier PIPELINE_ID = Identifier.of("client", "pipeline/texture");
    private static final Identifier VERTEX_SHADER = Identifier.of("client", "core/texture");

    private static final Identifier FRAGMENT_SHADER =
            Identifier.of("client", "core/texture_onetap");
    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(PIPELINE_ID)
                            .withVertexShader(TextureBatchRenderer.VERTEX_SHADER)
                            .withFragmentShader(TextureBatchRenderer.FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("TextureData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private boolean initialized;
    private int uniformIndex = 0;
    private static final RenderPipeline GLOW_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/texture_glow"))
                            .withVertexShader(TextureBatchRenderer.VERTEX_SHADER)
                            .withFragmentShader(TextureBatchRenderer.FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("TextureData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private GpuBuffer vertexBuffer;
    private static final Identifier ANTIALIASED_SHADER =
            Identifier.of("client", "core/texture_antialiased");
    private ByteBuffer uniformData;
    private final ArrayList<TextureBatchRenderer.TexDraw> drawQueue;
    private final Map<GpuTexture, GpuTextureView> textureViews;
    private static final RenderPipeline ANTIALIASED_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/texture_antialiased"))
                            .withVertexShader(VERTEX_SHADER)
                            .withFragmentShader(TextureBatchRenderer.ANTIALIASED_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("TextureData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private GpuBuffer[] uniformBuffers;

    @Override
    public void clear() {
        this.drawQueue.clear();
    }

    @Override
    public void render(RenderPass renderpass) {
        if (!this.drawQueue.isEmpty()) {
            RenderPipeline renderpipeline = null;

            for (TextureBatchRenderer.TexDraw texDraw : this.drawQueue) {
                if (!texDraw.view().isClosed()) {
                    if (texDraw.pipeline() != renderpipeline) {
                        renderpass.setPipeline(texDraw.pipeline());
                        renderpass.setVertexBuffer(0, this.vertexBuffer);
                        renderpipeline = texDraw.pipeline();
                    }

                    GpuSampler gpusampler =
                            RenderSystem.getSamplerCache().get(texDraw.filterMode());
                    renderpass.bindTexture("Sampler0", texDraw.view(), gpusampler);
                    renderpass.setUniform("TextureData", texDraw.uniformBuffer());
                    renderpass.draw(0, 6);
                }
            }

            this.drawQueue.clear();
        }
    }

    @Override
    public void prepare(CommandEncoder commandencoder) {}

    public void drawGlow(
            Identifier identifier,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            int[] aint,
            float[] afloat,
            float f8,
            float f9) {
        this.enqueue(
                identifier,
                f,
                f1,
                f2,
                f3,
                f4,
                f5,
                f6,
                f7,
                aint,
                afloat,
                f8,
                f9,
                GLOW_PIPELINE,
                FilterMode.LINEAR);
    }

    private void initialize() {
        if (!this.initialized) {
            this.uniformData = MemoryUtil.memAlloc(256);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.vertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:texture_dummy_vertex", 32, bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.uniformBuffers = new GpuBuffer[64];
            this.initialized = true;
        }
    }

    public void drawAntialiased(
            Identifier identifier,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            int[] aint,
            float[] afloat,
            float f8) {
        this.enqueue(
                identifier,
                f,
                f1,
                f2,
                f3,
                f4,
                f5,
                f6,
                f7,
                aint,
                afloat,
                f8,
                0.0F,
                ANTIALIASED_PIPELINE,
                FilterMode.LINEAR);
    }

    @Override
    public int getSortOrder() {
        return 2;
    }

    public void draw(
            Identifier identifier,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            int[] aint,
            float[] afloat,
            float f8,
            float f9) {
        this.enqueue(
                identifier,
                f,
                f1,
                f2,
                f3,
                f4,
                f5,
                f6,
                f7,
                aint,
                afloat,
                f8,
                f9,
                PIPELINE,
                FilterMode.LINEAR);
    }

    private void writeUniforms(
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float f8,
            float f9,
            float f10,
            int[] aint,
            float[] afloat,
            float f11,
            float f12) {
        this.uniformData.clear();
        this.uniformData.putFloat(f8);
        this.uniformData.putFloat(f9);
        this.uniformData.putFloat(f11);
        this.uniformData.putFloat(f10);
        this.uniformData.putFloat(f);
        this.uniformData.putFloat(f1);
        this.uniformData.putFloat(f2);
        this.uniformData.putFloat(f3);
        this.uniformData.putFloat(f4);
        this.uniformData.putFloat(f5);
        this.uniformData.putFloat(f6);
        this.uniformData.putFloat(f7);
        this.uniformData.putFloat(afloat[0]);
        this.uniformData.putFloat(afloat[1]);
        this.uniformData.putFloat(afloat[2]);
        this.uniformData.putFloat(afloat[3]);
        float f13 = (float) Math.toRadians((double) f12);
        this.uniformData.putFloat(f13);
        this.uniformData.putFloat(0.0F);
        this.uniformData.putFloat(0.0F);
        this.uniformData.putFloat(0.0F);

        for (int i = 0; i < 4; i++) {
            int j = i < aint.length ? aint[i] : aint[aint.length - 1];
            float f14 = (float) (j >> 24 & 0xFF) / 255.0F;
            float f15 = (float) (j >> 16 & 0xFF) / 255.0F;
            float f16 = (float) (j >> 8 & 0xFF) / 255.0F;
            float f17 = (float) (j & 0xFF) / 255.0F;
            this.uniformData.putFloat(f15);
            this.uniformData.putFloat(f16);
            this.uniformData.putFloat(f17);
            this.uniformData.putFloat(f14);
        }

        this.uniformData.flip();
    }

    public void draw(
            Identifier identifier,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            int[] aint,
            float[] afloat,
            float f8) {
        this.draw(identifier, f, f1, f2, f3, f4, f5, f6, f7, aint, afloat, f8, 0.0F);
    }

    private GpuBuffer nextUniformBuffer() {
        GpuBuffer gpubuffer = this.uniformBuffers[this.uniformIndex];
        if (gpubuffer == null) {
            int uniformIndexValue = this.uniformIndex;
            gpubuffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "minecraft:texture_uniform_" + uniformIndexValue,
                                    136,
                                    256L);
            this.uniformBuffers[this.uniformIndex] = gpubuffer;
        }

        this.uniformIndex = (this.uniformIndex + 1) % 64;
        return gpubuffer;
    }

    public TextureBatchRenderer() {
        this.initialized = false;
        this.drawQueue = new ArrayList<>();
        this.textureViews = new HashMap<>();
    }

    private GpuTextureView getOrCreateView(GpuTexture gputexture) {
        GpuTextureView gputextureview = this.textureViews.get(gputexture);
        if (gputextureview == null || gputextureview.isClosed()) {
            this.textureViews
                    .entrySet()
                    .removeIf(
                            entry -> {
                                if (!entry.getKey().isClosed() && !entry.getValue().isClosed()) {
                                    return false;
                                } else {
                                    if (!entry.getValue().isClosed()) {
                                        entry.getValue().close();
                                    }

                                    return true;
                                }
                            });
            gputextureview = RenderSystem.getDevice().createTextureView(gputexture);
            this.textureViews.put(gputexture, gputextureview);
        }

        return gputextureview;
    }

    public void drawNearest(
            Identifier identifier,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            int[] aint,
            float[] afloat,
            float f8) {
        this.enqueue(
                identifier,
                f,
                f1,
                f2,
                f3,
                f4,
                f5,
                f6,
                f7,
                aint,
                afloat,
                f8,
                0.0F,
                PIPELINE,
                FilterMode.NEAREST);
    }

    private void enqueue(
            Identifier identifier,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            int[] aint,
            float[] afloat,
            float f8,
            float f9,
            RenderPipeline renderpipeline,
            FilterMode filtermode) {

        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient.getFramebuffer() != null) {
            AbstractTexture abstracttexture =
                    minecraftclient.getTextureManager().getTexture(identifier);
            if (abstracttexture != null) {
                GpuTexture gputexture = abstracttexture.getGlTexture();
                if (gputexture != null) {
                    this.initialize();
                    float f10 = (float) minecraftclient.getWindow().getFramebufferWidth() / 2.0F;
                    float f11 = (float) minecraftclient.getWindow().getFramebufferHeight() / 2.0F;
                    this.writeUniforms(
                            f, f1, f2, f3, f4, f5, f6, f7, f10, f11, 2.0F, aint, afloat, f8, f9);
                    GpuBuffer gpubuffer = this.nextUniformBuffer();
                    RenderSystem.getDevice()
                            .createCommandEncoder()
                            .writeToBuffer(
                                    gpubuffer.slice(0L, (long) this.uniformData.remaining()),
                                    this.uniformData);
                    this.drawQueue.add(
                            new TextureBatchRenderer.TexDraw(
                                    renderpipeline,
                                    this.getOrCreateView(gputexture),
                                    gpubuffer,
                                    filtermode));
                    if (RenderBatchDispatcher.isBatching()) {
                        RenderBatchDispatcher.enqueue(this);
                        if (this.drawQueue.size() >= 64) {
                            RenderBatchDispatcher.renderImmediately(this);
                        }
                    } else {
                        RenderBatchDispatcher.flush();
                        RenderBatchDispatcher.renderImmediately(this);
                    }
                }
            }
        }
    }

    public void close() {
        this.drawQueue.clear();

        for (GpuTextureView gputextureview : this.textureViews.values()) {
            if (!gputextureview.isClosed()) {
                gputextureview.close();
            }
        }

        this.textureViews.clear();
        if (this.uniformBuffers != null) {
            for (GpuBuffer gpubuffer : this.uniformBuffers) {
                if (gpubuffer != null) {
                    gpubuffer.close();
                }
            }

            this.uniformBuffers = null;
        }

        this.uniformIndex = 0;
        if (this.vertexBuffer != null) {
            this.vertexBuffer.close();
            this.vertexBuffer = null;
        }

        if (this.uniformData != null) {
            MemoryUtil.memFree(this.uniformData);
            this.uniformData = null;
        }

        this.initialized = false;
    }

    @Environment(EnvType.CLIENT)
    private static record TexDraw(
            RenderPipeline pipeline,
            GpuTextureView view,
            GpuBuffer uniformBuffer,
            FilterMode filterMode) {}
}
