package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;

@ModuleInfo(
        name = "Coord Snapper",
        category = ModuleCategory.OTHER,
        desc = "Copies coordinates to clipboard and optionally sends via Discord webhook.")
@Environment(EnvType.CLIENT)
public class CoordSnapperModule extends Module {
    public final BooleanSetting selfPingSetting;
    public final BooleanSetting chatFeedbackSetting =
            new BooleanSetting(this, "Chat Feedback", true);
    public final TextSetting webhookURLSetting;
    public final BooleanSetting webhookSetting = new BooleanSetting(this, "Webhook", false);
    public final TextSetting discordIDSetting;

    public CoordSnapperModule() {
        this.webhookURLSetting = new TextSetting(this, "Webhook URL", "");
        this.selfPingSetting = new BooleanSetting(this, "Self Ping", false);
        this.discordIDSetting = new TextSetting(this, "Discord ID", "");
    }

    private static String escapeJson(String text) {
        return text == null ? "" : text.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    @Override
    protected void onEnable() {
        try {
            Exception exception;
            label91:
            {
                try {
                    if (client.player == null) {
                        return;
                    }
                } catch (Exception exceptionValue) {
                    exception = exceptionValue;
                    if (client.player == null) {
                        return;
                    }
                    break label91;
                }

                try {
                    BlockPos blockpos = client.player.getBlockPos();
                    int l = blockpos.getX();
                    int k = blockpos.getZ();
                    int j = blockpos.getY();
                    int i = l;
                    String text = i + " " + j + " " + k;
                    if (client.keyboard != null) {
                        client.keyboard.setClipboard(text);
                    }

                    String textValue;
                    if (this.chatFeedbackSetting.isOn()) {
                        client.player.sendMessage(
                                Text.literal("§7[§6CoordSnapper§7] §aCopied: §f" + text), false);
                        textValue = this.webhookURLSetting.getText();
                    } else {
                        textValue = this.webhookURLSetting.getText();
                    }

                    if (this.webhookSetting.isOn() && textValue != null && !textValue.isBlank()) {
                        this.sendCoordinates(
                                textValue.trim(),
                                blockpos.getX(),
                                blockpos.getY(),
                                blockpos.getZ());
                    }

                    return;
                } catch (Exception exception3) {
                    exception = exception3;
                    if (client.player == null) {
                        return;
                    }
                }
            }

            ClientPlayerEntity clientplayerentity = client.player;
            String message = exception.getMessage();
            clientplayerentity.sendMessage(
                    Text.literal("§7[§6CoordSnapper§7] §cError: " + message), false);
        } finally {
            this.setEnabled(false);
        }
    }

    private void sendCoordinates(String text, int i, int j, int k) {
        if (text.startsWith("http")) {
            String textValue;
            if (this.selfPingSetting.isOn() && !this.discordIDSetting.getText().isBlank()) {
                String text2 = this.discordIDSetting.getText().trim();
                textValue = "<@" + text2 + "> ";
            } else {
                textValue = "";
            }

            Thread thread;
            if (textValue.isEmpty()) {
                String text3 = "";
                String text4 =
                        "{\"username\":\"Coord Snapper\","
                                + text3
                                + "\"allowed_mentions\":{\"parse\":[\"users\"]},\"embeds\":[{\"title\":\"Coordsnapper"
                                + " Coords\",\"description\":\"Coords: X: "
                                + i
                                + ", Y: "
                                + j
                                + ", Z: "
                                + k
                                + "\",\"color\":6948525}]}";
                thread =
                        new Thread(
                                () -> {
                                    try {
                                        HttpClient.newHttpClient()
                                                .send(
                                                        HttpRequest.newBuilder()
                                                                .uri(URI.create(text))
                                                                .header(
                                                                        "Content-Type",
                                                                        "application/json")
                                                                .POST(
                                                                        BodyPublishers.ofString(
                                                                                text4,
                                                                                StandardCharsets
                                                                                        .UTF_8))
                                                                .build(),
                                                        BodyHandlers.discarding());
                                    } catch (Exception exception) {
                                    }
                                },
                                "Goobaa-CoordSnapper");
            } else {
                String string = escapeJson(textValue);
                String text5 = "\"content\":\"" + string + "\",";
                String text6 =
                        "{\"username\":\"Coord Snapper\","
                                + text5
                                + "\"allowed_mentions\":{\"parse\":[\"users\"]},\"embeds\":[{\"title\":\"Coordsnapper"
                                + " Coords\",\"description\":\"Coords: X: "
                                + i
                                + ", Y: "
                                + j
                                + ", Z: "
                                + k
                                + "\",\"color\":6948525}]}";
                thread =
                        new Thread(
                                () -> {
                                    try {
                                        HttpClient.newHttpClient()
                                                .send(
                                                        HttpRequest.newBuilder()
                                                                .uri(URI.create(text))
                                                                .header(
                                                                        "Content-Type",
                                                                        "application/json")
                                                                .POST(
                                                                        BodyPublishers.ofString(
                                                                                text6,
                                                                                StandardCharsets
                                                                                        .UTF_8))
                                                                .build(),
                                                        BodyHandlers.discarding());
                                    } catch (Exception exception) {
                                    }
                                },
                                "Goobaa-CoordSnapper");
            }

            thread.setDaemon(true);
            thread.start();
        }
    }
}
