package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public class ShaderSkyRenderer {
    private static final Identifier FULLSCREEN_VERTEX_SHADER =
            Identifier.of("client", "core/shader_sky_fullscreen");
    private GpuBuffer uniformBuffer;
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
    private static final Vector3f MODEL_OFFSET = new Vector3f(0.0F, 0.0F, 0.0F);
    private final MinecraftClient minecraftClient;
    private boolean initialized;
    private static final Identifier SKY_PIPELINE_ID =
            Identifier.of("client", "pipeline/shader_sky");
    private static final Identifier SKY_VERTEX_SHADER = Identifier.of("client", "core/shader_sky");
    private static final Identifier SKY_FRAGMENT_SHADER =
            Identifier.of("client", "core/shader_sky");
    private static final RenderPipeline SKY_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(ShaderSkyRenderer.SKY_PIPELINE_ID)
                            .withVertexShader(ShaderSkyRenderer.SKY_VERTEX_SHADER)
                            .withFragmentShader(ShaderSkyRenderer.SKY_FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.POSITION, DrawMode.TRIANGLES)
                            .withUniform("ShaderSkyData", UniformType.UNIFORM_BUFFER)
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private static final Identifier BLUR_FRAGMENT_SHADER =
            Identifier.of("client", "core/shader_sky_blur");
    private GpuBuffer fullscreenVertexBuffer;
    private static ShaderSkyRenderer instance;
    private static final Identifier BLUR_PIPELINE_ID =
            Identifier.of("client", "pipeline/shader_sky_blur");
    private static final RenderPipeline BLUR_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(ShaderSkyRenderer.BLUR_PIPELINE_ID)
                            .withVertexShader(FULLSCREEN_VERTEX_SHADER)
                            .withFragmentShader(BLUR_FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("ShaderSkyData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private GpuBuffer skyboxVertexBuffer;

    private final KawaseBlur kawaseBlur = new KawaseBlur();
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
    private boolean enabled;
    private ByteBuffer uniformData;

    private long startedAtMillis;

    public ShaderSkyRenderer() {
        this.initialized = false;
        this.enabled = false;
        this.startedAtMillis = System.currentTimeMillis();
        this.minecraftClient = MinecraftClient.getInstance();
        instance = this;
    }

    public static ShaderSkyRenderer getInstance() {
        if (instance == null) {
            instance = new ShaderSkyRenderer();
        }

        return instance;
    }

    private void renderFullscreen(
            Framebuffer framebuffer, RenderPipeline renderpipeline, GpuTextureView gputextureview) {
        CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
        GpuBufferSlice gpubufferslice =
                RenderSystem.getDynamicUniforms()
                        .write(
                                RenderSystem.getModelViewMatrix(),
                                COLOR_MODULATOR,
                                MODEL_OFFSET,
                                TEXTURE_MATRIX);

        try (RenderPass renderpass =
                commandencoder.createRenderPass(
                        () -> "client:shader_sky_pass",
                        framebuffer.getColorAttachmentView(),
                        OptionalInt.empty(),
                        framebuffer.getDepthAttachmentView(),
                        OptionalDouble.empty())) {
            renderpass.setPipeline(renderpipeline);
            renderpass.setVertexBuffer(0, this.fullscreenVertexBuffer);
            if (gputextureview != null) {
                GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
                renderpass.bindTexture("Sampler0", gputextureview, gpusampler);
            }

            RenderSystem.bindDefaultUniforms(renderpass);
            renderpass.setUniform("DynamicTransforms", gpubufferslice);
            renderpass.setUniform("ShaderSkyData", this.uniformBuffer);
            renderpass.draw(0, 6);
        }
    }

    private static int modeIndex(String text) {
        switch (text.hashCode()) {
            case 83201:
                if (text.equals("Sky")) {
                    return 3;
                }
                break;
            case 2222509:
                if (text.equals("Glow")) {
                    return 5;
                }
                break;
            case 2581923:
                if (text.equals("Snow")) {
                    return 2;
                }
                break;
            case 2587250:
                if (text.equals("Star")) {
                    return 4;
                }
                break;
            case 2138584635:
                if (text.equals("Goobaa")) {
                    return 1;
                }
        }

        return 0;
    }

    private void initialize() {
        if (!this.initialized) {
            this.uniformData = MemoryUtil.memAlloc(96);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.fullscreenVertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "client:shader_sky_dummy_vertex", 32, bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.uniformBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "client:shader_sky_uniform", 136, 96L);
            ByteBuffer byteBufferValue = createSkyboxVertices();
            this.skyboxVertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "client:shader_sky_celestial_vertex",
                                    32,
                                    byteBufferValue);
            MemoryUtil.memFree(byteBufferValue);
            this.initialized = true;
        }
    }

    public void renderBlur() {
        ShaderSkyModule shaderSkyModule2 = ShaderSkyModule.getInstance();
        if (this.enabled && shaderSkyModule2 != null && shaderSkyModule2.isEnabled()) {
            if (shaderSkyModule2.modeSetting.isSelected("Blur")) {
                Framebuffer framebuffer = this.minecraftClient.getFramebuffer();
                if (framebuffer != null && framebuffer.getColorAttachmentView() != null) {
                    this.initialize();
                    this.blurFramebuffer(framebuffer, shaderSkyModule2);
                }
            }
        }
    }

    public void setEnabled(boolean enabledValue) {
        this.enabled = enabledValue;
        if (enabledValue) {
            this.initialize();
            this.startedAtMillis = System.currentTimeMillis();
        }
    }

    private void blurFramebuffer(Framebuffer framebuffer, ShaderSkyModule shaderSkyModule2) {
        if (framebuffer.getColorAttachment() != null
                && framebuffer.getColorAttachmentView() != null) {
            GpuTextureView gputextureview =
                    this.kawaseBlur.blur(
                            framebuffer.getColorAttachment(),
                            framebuffer.getColorAttachmentView(),
                            framebuffer.textureWidth,
                            framebuffer.textureHeight,
                            3,
                            3.0F);
            if (gputextureview != null) {
                this.uploadUniforms(
                        framebuffer.textureWidth, framebuffer.textureHeight, shaderSkyModule2);
                this.renderFullscreen(framebuffer, BLUR_PIPELINE, gputextureview);
            }
        }
    }

    private void renderSkybox(Framebuffer framebuffer) {
        CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
        GpuBufferSlice gpubufferslice =
                RenderSystem.getDynamicUniforms()
                        .write(
                                RenderSystem.getModelViewMatrix(),
                                COLOR_MODULATOR,
                                MODEL_OFFSET,
                                TEXTURE_MATRIX);

        try (RenderPass renderpass =
                commandencoder.createRenderPass(
                        () -> "client:shader_sky_pass",
                        framebuffer.getColorAttachmentView(),
                        OptionalInt.empty(),
                        framebuffer.getDepthAttachmentView(),
                        OptionalDouble.empty())) {
            renderpass.setPipeline(SKY_PIPELINE);
            renderpass.setVertexBuffer(0, this.skyboxVertexBuffer);
            RenderSystem.bindDefaultUniforms(renderpass);
            renderpass.setUniform("DynamicTransforms", gpubufferslice);
            renderpass.setUniform("ShaderSkyData", this.uniformBuffer);
            renderpass.draw(0, 36);
        }
    }

    public void close() {
        if (this.uniformBuffer != null) {
            this.uniformBuffer.close();
            this.uniformBuffer = null;
        }

        if (this.fullscreenVertexBuffer != null) {
            this.fullscreenVertexBuffer.close();
            this.fullscreenVertexBuffer = null;
        }

        if (this.skyboxVertexBuffer != null) {
            this.skyboxVertexBuffer.close();
            this.skyboxVertexBuffer = null;
        }

        if (this.uniformData != null) {
            MemoryUtil.memFree(this.uniformData);
            this.uniformData = null;
        }

        this.kawaseBlur.close();
        this.initialized = false;
    }

    private void uploadUniforms(int i, int j, ShaderSkyModule shaderSkyModule2) {
        float opacity = getOpacity(shaderSkyModule2);
        Color color = new Color(ShaderSkyModule.primaryColor(), true);
        Color colorValue = new Color(ShaderSkyModule.secondaryColor(), true);
        Color WHITE = Color.WHITE;
        this.uniformData.clear();
        this.uniformData.putFloat((float) i);
        this.uniformData.putFloat((float) j);
        this.uniformData.putFloat(
                (float) (System.currentTimeMillis() - this.startedAtMillis) / 1000.0F);
        this.uniformData.putFloat(opacity);
        putColor(this.uniformData, color, opacity);
        putColor(this.uniformData, colorValue, opacity);
        putColor(this.uniformData, WHITE, opacity);
        this.uniformData.putFloat(
                (float) modeIndex(shaderSkyModule2.modeSetting.getSelectedMode()));
        this.uniformData.putFloat(shaderSkyModule2.speedSetting.getFloat());
        this.uniformData.putFloat(shaderSkyModule2.scaleSetting.getFloat());
        this.uniformData.putFloat(shaderSkyModule2.strengthSetting.getFloat());
        this.uniformData.putFloat(shaderSkyModule2.starsSetting.getFloat());
        this.uniformData.putFloat(shaderSkyModule2.vanillaSkySetting.isOn() ? 1.0F : 0.0F);
        this.uniformData.putFloat(0.0F);
        this.uniformData.putFloat(0.0F);
        this.uniformData.flip();
        RenderSystem.getDevice()
                .createCommandEncoder()
                .writeToBuffer(this.uniformBuffer.slice(), this.uniformData);
    }

    private static float getOpacity(ShaderSkyModule shaderSkyModule2) {
        if (shaderSkyModule2.modeSetting.isSelected("Blur")) {
            return shaderSkyModule2.strengthSetting.getFloat();
        } else {
            return shaderSkyModule2.vanillaSkySetting.isOn() ? 0.78F : 1.0F;
        }
    }

    private static ByteBuffer createSkyboxVertices() {
        float f = 512.0F;
        float[] afloat =
                new float[] {
                    -f, -f, -f, f, -f, -f, f, f, -f, -f, -f, -f, f, f, -f, -f, f, -f, f, -f, f, -f,
                    -f, f, -f, f, f, f, -f, f, -f, f, f, f, f, f, -f, -f, f, -f, -f, -f, -f, f, -f,
                    -f, -f, f, -f, f, -f, -f, f, f, f, -f, -f, f, -f, f, f, f, f, f, -f, -f, f, f,
                    f, f, f, -f, -f, f, -f, f, f, -f, f, f, f, -f, f, -f, f, f, f, -f, f, f, -f, -f,
                    f, f, -f, f, f, -f, -f, -f, -f, f, f, -f, -f, -f, -f, -f
                };
        ByteBuffer bytebuffer = MemoryUtil.memAlloc(afloat.length * 4);

        for (float f1 : afloat) {
            bytebuffer.putFloat(f1);
        }

        bytebuffer.flip();
        return bytebuffer;
    }

    public void disable() {
        this.enabled = false;
        this.close();
    }

    private static void putColor(ByteBuffer bytebuffer, Color color, float f) {
        bytebuffer.putFloat((float) color.getRed() / 255.0F);
        bytebuffer.putFloat((float) color.getGreen() / 255.0F);
        bytebuffer.putFloat((float) color.getBlue() / 255.0F);
        bytebuffer.putFloat((float) color.getAlpha() / 255.0F * f);
    }

    public void renderSky() {
        ShaderSkyModule shaderSkyModule2 = ShaderSkyModule.getInstance();
        if (this.enabled
                && shaderSkyModule2 != null
                && shaderSkyModule2.isEnabled()
                && !shaderSkyModule2.modeSetting.isSelected("Blur")) {
            Framebuffer framebuffer = this.minecraftClient.getFramebuffer();
            if (framebuffer != null && framebuffer.getColorAttachmentView() != null) {
                this.initialize();
                this.uploadUniforms(
                        framebuffer.textureWidth, framebuffer.textureHeight, shaderSkyModule2);
                this.renderSkybox(framebuffer);
            }
        }
    }
}
