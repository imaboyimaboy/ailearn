package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Random;

@Environment(EnvType.CLIENT)
public class FeedForwardNetwork {
    public final int hiddenSize;
    public final double[][] inputWeights;

    public final int outputSize;
    public final double[] hiddenBiases;
    private static final Random random = new Random();
    public final double[][] outputWeights;
    public final int inputSize;
    public final double[] outputBiases;

    private static double sigmoid(double d0) {
        return 1.0 / (1.0 + Math.exp(-d0));
    }

    private static double[] parseVector(String text) {
        String[] astring = text.trim().split("\\s+");
        double[] adouble = new double[astring.length];

        for (int i = 0; i < astring.length; i++) {
            adouble[i] = Double.parseDouble(astring[i]);
        }

        return adouble;
    }

    public double[] predict(double[] adouble) {
        double[] values = new double[this.hiddenSize];

        for (int i = 0; i < this.hiddenSize; i++) {
            double hiddenBiase = this.hiddenBiases[i];

            for (int j = 0; j < this.inputSize; j++) {
                hiddenBiase += this.inputWeights[i][j] * adouble[j];
            }

            values[i] = Math.tanh(hiddenBiase);
        }

        double[] dValArray2Value = new double[this.outputSize];

        for (int l = 0; l < this.outputSize; l++) {
            double outputBiase = this.outputBiases[l];

            for (int k = 0; k < this.hiddenSize; k++) {
                outputBiase += this.outputWeights[l][k] * values[k];
            }

            dValArray2Value[l] = sigmoid(outputBiase);
        }

        return dValArray2Value;
    }

    public double train(double[][] adouble, double[][] valuesArray, int i, double d0) {
        double d1 = 0.0;
        int length = adouble.length;

        for (int k = 0; k < i; k++) {
            double d2 = 0.0;

            for (int l = 0; l < length; l++) {
                d2 += this.trainSample(adouble[l], valuesArray[l], d0);
            }

            d1 = d2 / (double) Math.max(1, length);
        }

        return d1;
    }

    public String serialize() {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder
                .append(this.inputSize)
                .append(' ')
                .append(this.hiddenSize)
                .append(' ')
                .append(this.outputSize)
                .append('\n');

        for (double[] adouble : this.inputWeights) {
            for (double d0 : adouble) {
                stringbuilder.append(d0).append(' ');
            }
        }

        stringbuilder.append('\n');

        for (double d1 : this.hiddenBiases) {
            stringbuilder.append(d1).append(' ');
        }

        stringbuilder.append('\n');

        for (double[] values : this.outputWeights) {
            for (double d3 : values) {
                stringbuilder.append(d3).append(' ');
            }
        }

        stringbuilder.append('\n');

        for (double d2 : this.outputBiases) {
            stringbuilder.append(d2).append(' ');
        }

        stringbuilder.append('\n');
        return stringbuilder.toString();
    }

    private double trainSample(double[] adouble, double[] values, double d0) {
        double[] valuesValue = new double[this.hiddenSize];

        for (int i = 0; i < this.hiddenSize; i++) {
            double hiddenBiase = this.hiddenBiases[i];

            for (int j = 0; j < this.inputSize; j++) {
                hiddenBiase += this.inputWeights[i][j] * adouble[j];
            }

            valuesValue[i] = Math.tanh(hiddenBiase);
        }

        double[] values2 = new double[this.outputSize];

        for (int i1 = 0; i1 < this.outputSize; i1++) {
            double outputBiase = this.outputBiases[i1];

            for (int k = 0; k < this.hiddenSize; k++) {
                outputBiase += this.outputWeights[i1][k] * valuesValue[k];
            }

            values2[i1] = sigmoid(outputBiase);
        }

        double d5 = 0.0;
        double[] values3 = new double[this.outputSize];

        for (int j1 = 0; j1 < this.outputSize; j1++) {
            double d3 = values2[j1] - values[j1];
            d5 += d3 * d3;
            values3[j1] = d3 * values2[j1] * (1.0 - values2[j1]);
        }

        double[] values4 = new double[this.hiddenSize];

        for (int k1 = 0; k1 < this.hiddenSize; k1++) {
            double d4 = 0.0;

            for (int l = 0; l < this.outputSize; l++) {
                d4 += values3[l] * this.outputWeights[l][k1];
            }

            values4[k1] = d4 * (1.0 - valuesValue[k1] * valuesValue[k1]);
        }

        for (int l1 = 0; l1 < this.outputSize; l1++) {
            for (int j2 = 0; j2 < this.hiddenSize; j2++) {
                this.outputWeights[l1][j2] =
                        this.outputWeights[l1][j2] - d0 * values3[l1] * valuesValue[j2];
            }

            this.outputBiases[l1] = this.outputBiases[l1] - d0 * values3[l1];
        }

        for (int i2 = 0; i2 < this.hiddenSize; i2++) {
            for (int k2 = 0; k2 < this.inputSize; k2++) {
                this.inputWeights[i2][k2] =
                        this.inputWeights[i2][k2] - d0 * values4[i2] * adouble[k2];
            }

            this.hiddenBiases[i2] = this.hiddenBiases[i2] - d0 * values4[i2];
        }

        return d5;
    }

    public FeedForwardNetwork(int inputSizeValue, int hiddenSizeValue, int outputSizeValue) {
        this.inputSize = inputSizeValue;
        this.hiddenSize = hiddenSizeValue;
        this.outputSize = outputSizeValue;
        this.inputWeights = new double[hiddenSizeValue][inputSizeValue];
        this.hiddenBiases = new double[hiddenSizeValue];
        this.outputWeights = new double[outputSizeValue][hiddenSizeValue];
        this.outputBiases = new double[outputSizeValue];
        double d0 = Math.sqrt(2.0 / (double) inputSizeValue);
        double d1 = Math.sqrt(2.0 / (double) hiddenSizeValue);

        for (int l = 0; l < hiddenSizeValue; l++) {
            for (int i11 = 0; i11 < inputSizeValue; i11++) {
                this.inputWeights[l][i11] = (random.nextDouble() * 2.0 - 1.0) * d0;
            }
        }

        for (int j1 = 0; j1 < outputSizeValue; j1++) {
            for (int k1 = 0; k1 < hiddenSizeValue; k1++) {
                this.outputWeights[j1][k1] = (random.nextDouble() * 2.0 - 1.0) * d1;
            }
        }
    }

    public static FeedForwardNetwork deserialize(String text) {
        String[] astring = text.split("\n");
        String[] texts = astring[0].trim().split("\\s+");
        int i = Integer.parseInt(texts[0]);
        int j = Integer.parseInt(texts[1]);
        int k = Integer.parseInt(texts[2]);
        FeedForwardNetwork feedForwardNetwork2 = new FeedForwardNetwork(i, j, k);
        double[] adouble = parseVector(astring[1]);
        int l = 0;

        for (int i1 = 0; i1 < j; i1++) {
            for (int j1 = 0; j1 < i; j1++) {
                feedForwardNetwork2.inputWeights[i1][j1] = adouble[l++];
            }
        }

        double[] dValArrayValue = parseVector(astring[2]);

        for (int i2 = 0; i2 < j; i2++) {
            feedForwardNetwork2.hiddenBiases[i2] = dValArrayValue[i2];
        }

        double[] dValArray5 = parseVector(astring[3]);
        l = 0;

        for (int k1 = 0; k1 < k; k1++) {
            for (int l1 = 0; l1 < j; l1++) {
                feedForwardNetwork2.outputWeights[k1][l1] = dValArray5[l++];
            }
        }

        double[] dValArray6 = parseVector(astring[4]);

        for (int j2 = 0; j2 < k; j2++) {
            feedForwardNetwork2.outputBiases[j2] = dValArray6[j2];
        }

        return feedForwardNetwork2;
    }
}
