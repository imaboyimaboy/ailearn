package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.awt.Color;

@ModuleInfo(
        name = "Gradient",
        desc = "Applies tint, brightness, and vignette color grading to the world",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class GradientModule extends Module {
    public SliderSetting tintStrengthSetting;
    public SliderSetting brightnessSetting;
    public BooleanSetting vignetteSetting;
    public ColorSetting colorSetting =
            new ColorSetting(this, "Color", new Color(80, 130, 255).getRGB());
    public SliderSetting vignetteStrengthSetting;

    @EventHandler(priority = 500)
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null) {
            float width = (float) client.getWindow().getFramebufferWidth() / 2.0F;
            float height = (float) client.getWindow().getFramebufferHeight() / 2.0F;
            int integer = this.colorSetting.getColor();
            int red = integer >> 16 & 0xFF;
            int green = integer >> 8 & 0xFF;
            int blue = integer & 0xFF;
            int alpha = clampAlpha(this.tintStrengthSetting.getFloat() * 255.0F);
            RenderUtils.Render2D.drawRect(
                    0.0F, 0.0F, width, height, ColorUtils.cachedRgba(red, green, blue, alpha));
            float f2 = this.brightnessSetting.getFloat();
            if (f2 < -0.005F) {
                RenderUtils.Render2D.drawRect(
                        0.0F,
                        0.0F,
                        width,
                        height,
                        ColorUtils.cachedRgba(0, 0, 0, clampAlpha(-f2 * 255.0F)));
            } else if (f2 > 0.005F) {
                RenderUtils.Render2D.drawRect(
                        0.0F,
                        0.0F,
                        width,
                        height,
                        ColorUtils.cachedRgba(255, 255, 255, clampAlpha(f2 * 255.0F)));
            }

            if (this.vignetteSetting.isOn()) {
                this.drawVignette(width, height, this.vignetteStrengthSetting.getFloat());
            }
        }
    }

    private static int clampAlpha(float f) {
        return (int) Math.max(0.0F, Math.min(255.0F, f));
    }

    public GradientModule() {
        this.tintStrengthSetting =
                new SliderSetting(this, "Tint Strength", 0.25F, 0.02F, 0.7F, 0.01F);
        this.brightnessSetting = new SliderSetting(this, "Brightness", 0.0F, -0.4F, 0.4F, 0.01F);
        this.vignetteSetting = new BooleanSetting(this, "Vignette", false);
        this.vignetteStrengthSetting =
                new SliderSetting(this, "Vignette Strength", 0.45F, 0.1F, 0.85F, 0.05F)
                        .visibleWhen(() -> this.vignetteSetting.isOn());
    }

    private void drawVignette(float width, float heightValue, float f2) {
        int alpha = clampAlpha(f2 * 255.0F);
        int j = ColorUtils.cachedRgba(0, 0, 0, alpha);
        int k = ColorUtils.cachedRgba(0, 0, 0, 0);
        float widthValue = width * 0.52F;
        float height = heightValue * 0.52F;
        RenderUtils.Render2D.drawRoundedGradient(
                0.0F, 0.0F, width, height, new int[] {j, j, k, k}, 0.0F);
        RenderUtils.Render2D.drawRoundedGradient(
                0.0F, heightValue - height, width, height, new int[] {k, k, j, j}, 0.0F);
        RenderUtils.Render2D.drawRoundedGradient(
                0.0F, 0.0F, widthValue, heightValue, new int[] {j, k, k, j}, 0.0F);
        RenderUtils.Render2D.drawRoundedGradient(
                width - widthValue, 0.0F, widthValue, heightValue, new int[] {k, j, j, k}, 0.0F);
    }
}
