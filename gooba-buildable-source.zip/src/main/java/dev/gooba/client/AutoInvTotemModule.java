package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

@ModuleInfo(
        name = "Auto Inv Totem",
        desc = "Equips totems while the inventory is open",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class AutoInvTotemModule extends Module {
    private final BooleanSetting forceSetting;

    private final SliderSetting totemSlotSetting =
            new SliderSetting(this, "Totem Slot", 1.0F, 1.0F, 9.0F, 1.0F);

    private Slot findTotemSlot() {
        PlayerInventory playerinventory = client.player.getInventory();

        for (Slot slot : client.player.currentScreenHandler.slots) {
            int index = slot.getIndex();
            if (slot.inventory == playerinventory
                    && index >= 0
                    && index < 36
                    && index != -1
                    && slot.getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                return slot;
            }
        }

        return null;
    }

    private void swapTotemToOffhand(Slot slot) {
        client.interactionManager.clickSlot(
                client.player.currentScreenHandler.syncId,
                slot.id,
                40,
                SlotActionType.SWAP,
                client.player);
    }

    public AutoInvTotemModule() {
        this.forceSetting = new BooleanSetting(this, "Force", false);
    }

    private void notifyTotemEquipped(ItemStack itemstack) {
        if (itemstack.isOf(Items.TOTEM_OF_UNDYING)) {
            NotificationManager.showItem(
                    "Totem has been equiped",
                    NotificationManager.Type.INFO,
                    itemstack.copy(),
                    2000L);
        }
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (client.currentScreen instanceof InventoryScreen
                && client.player != null
                && client.interactionManager != null
                && client.player.isAlive()) {
            int i = Math.round(this.totemSlotSetting.getFloat()) - 1;
            if (client.player.getInventory().getSelectedSlot() != i) {
                client.player.getInventory().setSelectedSlot(i);
                client.interactionManager.syncSelectedSlot();
            }

            if (!client.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                Slot slotValue = this.findTotemSlot();
                if (slotValue != null) {
                    this.swapTotemToOffhand(slotValue);
                    this.notifyTotemEquipped(client.player.getOffHandStack());
                }
            } else if (!client.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                if (client.player.getInventory().getStack(i).isEmpty()
                        || this.forceSetting.isOn()) {
                    Slot slot = this.findTotemSlot();
                    if (slot != null) {
                        this.swapTotemToOffhand(slot);
                        this.notifyTotemEquipped(client.player.getInventory().getStack(i));
                    }
                }
            }
        }
    }
}
