package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.io.Serializable;

@Environment(EnvType.CLIENT)
public class StringPair implements Serializable {
    private final String second;
    private final String first;

    protected StringPair(String text, String stringValue) {
        this.first = text;
        this.second = stringValue;
    }
}
