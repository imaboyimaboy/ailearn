package dev.gooba.client;

import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;

@Environment(EnvType.CLIENT)
public class BackgroundBlur {
    private static int width = 0;
    private static boolean previouslyRequested = true;
    private static boolean requested = false;
    private static GpuTextureView textureView = null;
    private static int height = 0;
    private static final KawaseBlur kawaseBlur = new KawaseBlur();

    public static boolean isAvailable() {
        return textureView != null;
    }

    public static void blurDefault() {
        previouslyRequested = true;
        blur(2, (float) 2);
    }

    public static void update(boolean flag) {
        boolean flag1;
        flag1 = !(!flag && !requested && !BackgroundBlur.previouslyRequested);

        BackgroundBlur.previouslyRequested = requested;
        requested = false;
        if (!flag1) {
            textureView = null;
        } else {
            if (flag) {
                blurMenu();
            } else {
                blurTheme();
            }
        }
    }

    public static void blurMenu() {
        previouslyRequested = true;
        blur(4, 24.0F, true);
    }

    public static GpuTextureView getTextureView() {
        return textureView;
    }

    public static void requestBlur() {
        requested = true;
    }

    public static int getHeight() {
        return height;
    }

    public static void close() {
        textureView = null;
        kawaseBlur.close();
    }

    private static void blurTheme() {
        int i = Math.max(0, Math.min(6, ThemeColors.getBlurRadius()));
        if (i == 0) {
            textureView = null;
        } else {
            blur(i, (float) i);
        }
    }

    private static void blur(int i, float f, boolean flag) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient != null) {
            Framebuffer framebuffer = minecraftclient.getFramebuffer();
            if (framebuffer != null) {
                RenderBatchDispatcher.flush();

                try {
                    GpuTexture gputexture = framebuffer.getColorAttachment();
                    GpuTextureView gputextureview = framebuffer.getColorAttachmentView();
                    if (gputexture == null || gputextureview == null) {
                        textureView = null;
                        return;
                    }

                    int textureWidth = framebuffer.textureWidth;
                    int textureHeight = framebuffer.textureHeight;
                    if (textureWidth <= 0 || textureHeight <= 0) {
                        textureView = null;
                        return;
                    }

                    textureView =
                            kawaseBlur.blur(
                                    gputexture,
                                    gputextureview,
                                    textureWidth,
                                    textureHeight,
                                    i,
                                    f,
                                    flag);
                    if (textureView != null) {
                        width = textureWidth;
                        height = textureHeight;
                    }
                } catch (Exception exception) {
                    textureView = null;
                }
            }
        }
    }

    public static int getWidth() {
        return width;
    }

    private static void blur(int i, float f) {
        blur(i, f, false);
    }
}
