package dev.gooba.client;

public final class Sneaky {
    private Sneaky() {}

    public static RuntimeException rethrow(Throwable throwable) {
        throw Sneaky.<RuntimeException>raise(throwable);
    }

    @SuppressWarnings("unchecked")
    private static <T extends Throwable> T raise(Throwable throwable) throws T {
        throw (T) throwable;
    }
}
