package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.PlayerInput;

@ModuleInfo(
        name = "Auto Totem",
        desc = "Equips an available offhand totem as soon as movement input is released",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class AutoTotemModule extends Module {
    public final SliderSetting healthSetting;
    public final BooleanSetting doubleHandSetting = new BooleanSetting(this, "Double Hand", false);

    private static AutoTotemModule instance;
    private boolean swapPending;
    private boolean movementStopped;

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.swapPending = false;
        this.movementStopped = false;
    }

    public static boolean isSwapPending() {
        return instance != null && instance.isEnabled() && instance.swapPending;
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        this.finishPendingSwap();
        this.swapPending = false;
        this.movementStopped = false;
        if (client.player != null && client.interactionManager != null && client.player.isAlive()) {
            if (!client.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)
                    || this.needsMainHandTotem()) {
                this.swapPending = this.findTotemSlot() != null;
                if (this.swapPending) {
                    client.player.setSprinting(false);
                }
            }
        }
    }

    private void finishPendingSwap() {
        if (isSwapPending()
                && this.movementStopped
                && client.player != null
                && client.interactionManager != null) {
            try {
                if (!client.player.isAlive()) {
                    return;
                }

                boolean notIsOf = !client.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
                if (!notIsOf && !this.needsMainHandTotem()) {
                    return;
                }

                PlayerInput playerinput = client.player.input.playerInput;
                if (playerinput.forward()
                        || playerinput.backward()
                        || playerinput.left()
                        || playerinput.right()
                        || playerinput.jump()
                        || playerinput.sneak()
                        || playerinput.sprint()
                        || client.player.isSprinting()) {
                    return;
                }

                Slot slot = this.findTotemSlot();
                if (slot == null) {
                    return;
                }

                int i = notIsOf ? 40 : client.player.getInventory().getSelectedSlot();
                client.interactionManager.clickSlot(
                        client.player.currentScreenHandler.syncId,
                        slot.id,
                        i,
                        SlotActionType.SWAP,
                        client.player);
                ItemStack itemstack =
                        notIsOf
                                ? client.player.getOffHandStack()
                                : client.player.getMainHandStack();
                if (itemstack.isOf(Items.TOTEM_OF_UNDYING)) {
                    NotificationManager.showItem(
                            "Totem has been equiped",
                            NotificationManager.Type.INFO,
                            itemstack.copy(),
                            2000L);
                }
            } finally {
                this.swapPending = false;
                this.movementStopped = false;
            }
        }
    }

    private boolean needsMainHandTotem() {
        return this.doubleHandSetting.isOn()
                && client.player.getHealth() / 2.0F <= this.healthSetting.getFloat()
                && !client.player.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING);
    }

    @Override
    protected void onDisable() {
        this.swapPending = false;
        this.movementStopped = false;
    }

    public AutoTotemModule() {
        this.healthSetting =
                new SliderSetting(this, "Health", 10.0F, 0.0F, 10.0F, 0.1F)
                        .visibleWhen(() -> this.doubleHandSetting.isOn());
        instance = this;
    }

    private Slot findTotemSlot() {
        PlayerInventory playerinventory = client.player.getInventory();

        for (Slot slot : client.player.currentScreenHandler.slots) {
            if (slot.inventory == playerinventory
                    && slot.getIndex() >= 0
                    && slot.getIndex() < 36
                    && slot.getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                return slot;
            }
        }

        return null;
    }

    public void stopMovementForSwap() {
        if (isSwapPending() && client.player != null) {
            client.player.input.playerInput =
                    new PlayerInput(false, false, false, false, false, false, false);
            client.player.setSprinting(false);
            this.movementStopped = true;
        }
    }

    public static AutoTotemModule getInstance() {
        return instance;
    }

    @EventHandler(priority = -500)
    public void onAction(ActionEvent actionEvent) {
        if (isSwapPending() && client.player != null) {
            client.player.setSprinting(false);
            actionEvent.setSprintState(false);
        }
    }
}
