package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;

import java.lang.reflect.Field;

@ModuleInfo(
        name = "No Delay",
        category = ModuleCategory.PLAYER,
        desc = "Removes the jump and experience-bottle use delays")
@Environment(EnvType.CLIENT)
public class NoDelayModule extends Module {
    public BooleanSetting jumpDelaySetting = new BooleanSetting(this, "Jump Delay", true);
    public BooleanSetting experienceBottleDelaySetting =
            new BooleanSetting(this, "Experience Bottle Delay", true);

    public static NoDelayModule getInstance() {
        return (NoDelayModule) ModuleLookup.getModule(NoDelayModule.class);
    }

    private void clearItemUseCooldown() {
        Field fieldValue;
        label50:
        {
            Field field;
            try {
                field = MinecraftClient.class.getDeclaredField("itemUseCooldown");
            } catch (Exception exceptionValue) {
                try {
                    fieldValue = MinecraftClient.class.getDeclaredField("field_1752");
                    fieldValue.setAccessible(true);
                    break label50;
                } catch (Exception exception7) {
                    return;
                }
            }

            try {
                field.setAccessible(true);
            } catch (Exception exception8) {
                try {
                    fieldValue = MinecraftClient.class.getDeclaredField("field_1752");
                    fieldValue.setAccessible(true);
                    break label50;
                } catch (Exception exception9) {
                    return;
                }
            }

            try {
                field.setInt(client, 0);
                return;
            } catch (Exception exception10) {
                try {
                    fieldValue = MinecraftClient.class.getDeclaredField("field_1752");
                    fieldValue.setAccessible(true);
                } catch (Exception exception11) {
                    return;
                }
            }
        }

        try {
            fieldValue.setInt(client, 0);
        } catch (Exception exception) {
        }
    }

    @EventHandler
    private void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (client.player != null) {
            if (this.experienceBottleDelaySetting.isOn()
                    && client.player.getMainHandStack().getItem() == Items.EXPERIENCE_BOTTLE) {
                client.player
                        .getItemCooldownManager()
                        .remove(Registries.ITEM.getId(Items.EXPERIENCE_BOTTLE));
                this.clearItemUseCooldown();
            }
        }
    }
}
