package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundInstance.AttenuationType;
import net.minecraft.client.sound.SoundSystem.PlayResult;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public final class MenuBackgroundRenderer {
    private static final Identifier MUSIC_ID = Identifier.of("client", "gui_bg");

    private static MenuBackgroundRenderer.GuiMusicSound music;

    private static float clampVolume(float f) {
        return Math.max(0.0F, Math.min(1.0F, f));
    }

    public static void stopMusic() {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        minecraftclient.execute(
                () -> {
                    MenuBackgroundRenderer.GuiMusicSound guiMusicSoundValue = music;
                    music = null;
                    if (guiMusicSoundValue != null) {
                        guiMusicSoundValue.stop();
                        minecraftclient.getSoundManager().stop(guiMusicSoundValue);
                    }
                });
    }

    private MenuBackgroundRenderer() {}

    public static void playMusic(float f) {
        if (SoundPlayer.areSoundsEnabled()) {
            float volumeValue = clampVolume(f);
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            minecraftclient.execute(
                    () -> {
                        if (music != null && !music.isDone()) {
                            music.setVolume(volumeValue);
                        } else {
                            MenuBackgroundRenderer.GuiMusicSound guiMusicSoundValue =
                                    new MenuBackgroundRenderer.GuiMusicSound(volumeValue);
                            music = guiMusicSoundValue;
                            PlayResult playresult =
                                    minecraftclient.getSoundManager().play(guiMusicSoundValue);
                            if (playresult == PlayResult.NOT_STARTED
                                    && music == guiMusicSoundValue) {
                                music = null;
                            }
                        }
                    });
        }
    }

    @Environment(EnvType.CLIENT)
    private static final class GuiMusicSound extends MovingSoundInstance {

        private float targetVolume;
        private int fadeTicks;

        private void stop() {
            this.setDone();
        }

        @Override
        public void tick() {
            if (this.fadeTicks < 10) {
                this.fadeTicks++;
                float f = (float) this.fadeTicks / 10.0F;
                float f1 = 1.0F - (1.0F - f) * (1.0F - f);
                this.volume = this.targetVolume * f1;
            } else {
                this.volume = this.targetVolume;
            }
        }

        private GuiMusicSound(float targetVolumeValue) {
            super(
                    SoundEvent.of(MenuBackgroundRenderer.MUSIC_ID),
                    SoundCategory.MASTER,
                    SoundInstance.createRandom());
            this.targetVolume = targetVolumeValue;
            this.volume = 0.001F;
            this.pitch = 1.0F;
            this.repeat = true;
            this.repeatDelay = 0;
            this.relative = true;
            this.attenuationType = AttenuationType.NONE;
        }

        private void setVolume(float volumeValue) {
            this.targetVolume = volumeValue;
            if (this.fadeTicks >= 10) {
                this.volume = volumeValue;
            }
        }
    }

    private static void setMusicVolume(float volumeValue) {
        if (music != null && !music.isDone()) {
            music.setVolume(volumeValue);
        }
    }
}
