package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Shader Sky",
        category = ModuleCategory.RENDER,
        desc = "Replaces the sky with a configurable procedural shader")
@Environment(EnvType.CLIENT)
public class ShaderSkyModule extends Module {
    public ModeSetting modeSetting =
            new ModeSetting(
                    this, "Mode", new String[] {"Aurora", "Goobaa", "Snow", "Sky", "Star", "Glow"});
    public SliderSetting scaleSetting;
    private static ShaderSkyModule instance;
    public SliderSetting strengthSetting =
            new SliderSetting(this, "Strength", 1.0F, 0.1F, 1.0F, 0.05F);
    public ModeSetting colorModeSetting;
    public ColorSetting color1Setting;
    public BooleanSetting vanillaSkySetting;
    public SliderSetting speedSetting = new SliderSetting(this, "Speed", 1.0F, 0.1F, 3.0F, 0.1F);
    public SliderSetting starsSetting;
    public ColorSetting color2Setting;

    @Override
    protected void onEnable() {
        ShaderSkyRenderer shaderSkyRenderer2 = ShaderSkyRenderer.getInstance();
        shaderSkyRenderer2.disable();
        shaderSkyRenderer2.setEnabled(true);
    }

    @Override
    protected void onDisable() {
        ShaderSkyRenderer.getInstance().setEnabled(false);
    }

    public static ShaderSkyModule getInstance() {
        return instance;
    }

    public ShaderSkyModule() {
        this.scaleSetting = new SliderSetting(this, "Scale", 1.1F, 0.45F, 3.0F, 0.05F);
        this.starsSetting = new SliderSetting(this, "Stars", 0.75F, 0.0F, 1.0F, 0.05F);
        this.colorModeSetting =
                new ModeSetting(this, "Color Mode", new String[] {"Theme", "Custom"});
        this.color1Setting =
                new ColorSetting(this, "Color 1", -8788225)
                        .visibleWhen(() -> this.colorModeSetting.isSelected("Custom"));
        this.color2Setting =
                new ColorSetting(this, "Color 2", -34074)
                        .visibleWhen(() -> this.colorModeSetting.isSelected("Custom"));
        this.vanillaSkySetting = new BooleanSetting(this, "Vanilla sky", false);
        instance = this;
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        if (this.isEnabled()) {
            ShaderSkyRenderer shaderSkyRenderer2 = ShaderSkyRenderer.getInstance();
            shaderSkyRenderer2.disable();
            shaderSkyRenderer2.setEnabled(true);
        }
    }

    public static int primaryColor() {
        return getInstance().colorModeSetting.isSelected("Theme")
                ? ColorUtils.hudAccent()
                : getInstance().color1Setting.getColor();
    }

    public static int secondaryColor() {
        return getInstance().colorModeSetting.isSelected("Theme")
                ? ColorUtils.darken(ColorUtils.hudAccent(), 0.25F)
                : getInstance().color2Setting.getColor();
    }
}
