package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.awt.Color;

@Environment(EnvType.CLIENT)
public enum ThemePreset {
    TOXIS(
            "Blue",
            new Color(92, 160, 245).getRGB(),
            new Color(20, 23, 32).getRGB(),
            ColorUtils.opaqueGrayscale(240),
            ColorUtils.opaqueGrayscale(160),
            ColorUtils.rgb(24, 24, 27),
            new Color(118, 142, 203).getRGB()),
    Turquoise(
            "Red",
            new Color(16747403).getRGB(),
            new Color(-1726280692, true).getRGB(),
            ColorUtils.opaqueGrayscale(240),
            ColorUtils.opaqueGrayscale(160),
            ColorUtils.rgb(24, 24, 27),
            new Color(16747403).getRGB()),
    GOOBAA(
            "Violet",
            new Color(10521599).getRGB(),
            new Color(-1726672860, true).getRGB(),
            ColorUtils.opaqueGrayscale(240),
            ColorUtils.opaqueGrayscale(160),
            ColorUtils.rgb(24, 24, 27),
            new Color(10521599).getRGB()),
    VALUE_H(
            "Toxis",
            new Color(9961355).getRGB(),
            new Color(-1726996979, true).getRGB(),
            ColorUtils.opaqueGrayscale(240),
            ColorUtils.opaqueGrayscale(160),
            ColorUtils.rgb(24, 24, 27),
            new Color(12189579).getRGB()),
    White(
            "White",
            new Color(14671839).getRGB(),
            new Color(-1728053248, true).getRGB(),
            ColorUtils.opaqueGrayscale(240),
            ColorUtils.opaqueGrayscale(160),
            ColorUtils.rgb(24, 24, 27),
            new Color(14671839).getRGB()),
    VIOLKA(
            "Turquoise",
            new Color(96, 255, 198).getRGB(),
            new Color(-1726797010, true).getRGB(),
            ColorUtils.opaqueGrayscale(240),
            ColorUtils.opaqueGrayscale(160),
            ColorUtils.rgb(24, 24, 27),
            new Color(96, 255, 198).getRGB()),
    Purple(
            "Purple",
            new Color(216, 68, 234).getRGB(),
            new Color(-1725690581, true).getRGB(),
            ColorUtils.opaqueGrayscale(240),
            ColorUtils.opaqueGrayscale(160),
            ColorUtils.rgb(24, 24, 27),
            new Color(216, 68, 234).getRGB());

    private final int textColor;
    public TimedAnimation selectionAnimation = new DecelerateAnimation(300, 1.0);

    private final int elementColor;
    private final String name;
    private final int secondaryTextColor;
    private final int backgroundColor;
    private final int panelColor;
    private final int accentColor;

    public int getElementColor() {
        return this.elementColor;
    }

    public int getAccentColor() {
        return this.accentColor;
    }

    private ThemePreset(
            String nameValue,
            int accentColorValue,
            int backgroundColorValue,
            int textColorValue,
            int secondaryTextColorValue,
            int panelColorValue,
            int elementColorValue) {
        this.name = nameValue;
        this.accentColor = accentColorValue;
        this.backgroundColor = backgroundColorValue;
        this.textColor = textColorValue;
        this.secondaryTextColor = secondaryTextColorValue;
        this.panelColor = panelColorValue;
        this.elementColor = elementColorValue;
    }

    public int getBackgroundColor() {
        return this.backgroundColor;
    }
}
