package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@ModuleInfo(
        name = "Trajectories",
        desc = "Shows the path, item icon, and impact point of pearls, arrows, and tridents",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class TrajectoriesModule extends Module {
    private final List<TrajectoriesModule.SmoothedState> renderPredictions;
    public final BooleanSetting timeToImpactSetting;
    private static final RenderPipeline GLOW_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "trajectories_glow_ribbon"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    public final BooleanSetting trajectoryLineSetting;
    public final BooleanSetting heldProjectileSetting;
    public final MultiBooleanSetting itemsSetting =
            new MultiBooleanSetting(
                    this,
                    "Items",
                    new BooleanSetting[] {
                        BooleanSetting.create("ender pearl", true),
                        BooleanSetting.create("Arrows", true),
                        BooleanSetting.create("Trident", true)
                    });
    private static final RenderPipeline FILL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "trajectories_fill"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    private final Map<Integer, TrajectoriesModule.SmoothedState> predictionsByEntity;
    private static final RenderLayer FILL_LAYER =
            RenderLayer.of(
                    "trajectories_fill",
                    RenderSetup.builder(TrajectoriesModule.FILL_PIPELINE)
                            .expectedBufferSize(4096)
                            .build());
    private static final RenderLayer GLOW_LAYER =
            RenderLayer.of(
                    "trajectories_glow_ribbon",
                    RenderSetup.builder(GLOW_PIPELINE).expectedBufferSize(32768).build());
    public final BooleanSetting glowLineSetting;
    public final SliderSetting lineThicknessSetting;
    private static final RenderPipeline LINE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "trajectories_line"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.DEBUG_LINES)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    private static final RenderLayer LINE_LAYER =
            RenderLayer.of(
                    "trajectories_line",
                    RenderSetup.builder(TrajectoriesModule.LINE_PIPELINE)
                            .expectedBufferSize(16384)
                            .build());
    public final BooleanSetting flyingProjectilesSetting;
    private static final RenderPipeline RIBBON_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "trajectories_ribbon"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .build());
    public final BooleanSetting itemIconSetting;
    public final SliderSetting impactMarkerSizeSetting;
    private long lastFrameNanos;
    private final BufferAllocator bufferAllocator;
    private static final RenderLayer RIBBON_LAYER =
            RenderLayer.of(
                    "trajectories_ribbon",
                    RenderSetup.builder(TrajectoriesModule.RIBBON_PIPELINE)
                            .expectedBufferSize(32768)
                            .build());

    private TrajectoriesModule.Prediction predictFlight(
            Vec3d vec3d,
            Vec3d vec3d1,
            double d0,
            Entity entity,
            Entity entityValue,
            ItemStack itemstack) {
        ArrayList arraylist = new ArrayList(128);
        arraylist.add(vec3d);
        double d1 = 0.25;
        double d2 = Math.pow(0.99, d1);
        double d3 = d0 * d1;

        for (int i = 0; i < 200; i++) {
            for (int j = 0; j < 4; j++) {
                Vec3d vec3d2 = vec3d.add(vec3d1.multiply(d1));
                BlockHitResult blockhitresult =
                        client.world.raycast(
                                new RaycastContext(
                                        vec3d,
                                        vec3d2,
                                        ShapeType.COLLIDER,
                                        FluidHandling.NONE,
                                        entity));
                Vec3d vec3d3 =
                        blockhitresult.getType() == Type.BLOCK ? blockhitresult.getPos() : vec3d2;
                Entity entity4 = null;
                Vec3d vec3d4 = null;
                double MAX_VALUE = Double.MAX_VALUE;
                Box box = new Box(vec3d, vec3d3).expand(0.25);

                for (Entity entity6 :
                        client.world.getOtherEntities(
                                entity,
                                box,
                                entity7 ->
                                        entity7 instanceof LivingEntity
                                                && entity7.isAlive()
                                                && entity7 != entityValue
                                                && !entity7.isSpectator())) {
                    Vec3d vec3d5 =
                            entity6.getBoundingBox()
                                    .expand(0.25)
                                    .raycast(vec3d, vec3d3)
                                    .orElse(null);
                    if (vec3d5 != null) {
                        double MAX_VALUEValue = vec3d5.squaredDistanceTo(vec3d);
                        if (MAX_VALUEValue < MAX_VALUE) {
                            MAX_VALUE = MAX_VALUEValue;
                            entity4 = entity6;
                            vec3d4 = vec3d5;
                        }
                    }
                }

                if (entity4 != null) {
                    arraylist.add(vec3d4);
                    return new TrajectoriesModule.Prediction(
                            densifyPath(arraylist), vec3d4, i + 1, entity4, itemstack);
                }

                if (blockhitresult.getType() == Type.BLOCK) {
                    arraylist.add(vec3d3);
                    return new TrajectoriesModule.Prediction(
                            densifyPath(arraylist), vec3d3, i + 1, null, itemstack);
                }

                arraylist.add(vec3d2);
                vec3d = vec3d2;
                vec3d1 = vec3d1.multiply(d2).subtract(0.0, d3, 0.0);
                if (vec3d2.y < (double) (client.world.getBottomY() - 16)) {
                    return null;
                }
            }
        }

        return null;
    }

    private void updateSmoothedPrediction(
            int i, TrajectoriesModule.Prediction prediction, float f) {
        if (prediction != null) {
            TrajectoriesModule.SmoothedState smoothedState = this.predictionsByEntity.get(i);
            if (smoothedState == null) {
                smoothedState = TrajectoriesModule.SmoothedState.fromPrediction(prediction);
                this.predictionsByEntity.put(i, smoothedState);
            } else {
                smoothedState.update(
                        prediction, f, prediction.icon().isOf(Items.ENDER_PEARL) ? 18.0F : 100.0F);
            }

            smoothedState.updated = true;
        }
    }

    private static int alphaOrOpaque(int i) {
        int j = i >> 24 & 0xFF;
        return j == 0 ? 255 : j;
    }

    private TrajectoriesModule.RibbonData buildRibbon(
            TrajectoriesModule.SmoothedState smoothedState, Vec3d vec3d) {
        List listx = smoothedState.points;
        int i = 0;

        while (listx.size() - i > 2 && ((Vec3d) listx.get(i)).squaredDistanceTo(vec3d) < 0.16) {
            i++;
        }

        int j = listx.size() - i;
        if (j < 2) {
            return null;
        } else {
            boolean flag = smoothedState.hitEntity instanceof LivingEntity;
            int k = flag ? ColorUtils.cachedRgba(64, 255, 64, 255) : ColorUtils.animatedAccent(1);
            TrajectoriesModule.RibbonData ribbonData = new TrajectoriesModule.RibbonData();
            ribbonData.red = colorChannel(k, 16);
            ribbonData.green = colorChannel(k, 8);
            ribbonData.blue = colorChannel(k, 0);
            ribbonData.points = new Vec3d[j];
            ribbonData.sideVectors = new Vec3d[j];
            ribbonData.opacities = new float[j];
            ribbonData.widths = new float[j];
            double d0 =
                    Math.tan(
                            Math.toRadians((double) client.options.getFov().getValue().floatValue())
                                    / 2.0);
            double d1 = 2.0 * d0 / (double) Math.max(1, client.getWindow().getFramebufferHeight());
            float f = this.lineThicknessSetting.getFloat();

            for (int l = 0; l < j; l++) {
                ribbonData.points[l] = ((Vec3d) listx.get(i + l)).subtract(vec3d);
            }

            double d2 = 0.0;
            Vec3d vec3d1 = new Vec3d(0.0, 1.0, 0.0);

            for (int i1 = 0; i1 < j; i1++) {
                Vec3d vec3d2 =
                        ribbonData.points[Math.min(i1 + 1, j - 1)].subtract(
                                ribbonData.points[Math.max(i1 - 1, 0)]);
                Vec3d vec3d3 = vec3d2.crossProduct(ribbonData.points[i1]);
                if (vec3d3.lengthSquared() < 1.0E-8) {
                    vec3d3 = vec3d1;
                } else {
                    vec3d3 = vec3d3.normalize();
                }

                vec3d1 = vec3d3;
                ribbonData.sideVectors[i1] = vec3d3;
                ribbonData.widths[i1] =
                        (float) (0.5 * (double) f * ribbonData.points[i1].length() * d1);
                if (i1 > 0) {
                    d2 += ((Vec3d) listx.get(i + i1)).distanceTo((Vec3d) listx.get(i + i1 - 1));
                }

                ribbonData.opacities[i1] = (float) MathHelper.clamp((d2 - 0.1) / 0.55, 0.0, 1.0);
            }

            return ribbonData;
        }
    }

    private void updateFlyingProjectiles(float f, float f1) {
        for (Entity entity : client.world.getEntities()) {
            if (!(entity.getVelocity().lengthSquared() < 4.0E-4)) {
                double d0;
                ItemStack itemstack;
                if (entity instanceof EnderPearlEntity) {
                    if (!this.itemsSetting.isOn("ender pearl")) {
                        continue;
                    }

                    d0 = 0.03;
                    itemstack = new ItemStack(Items.ENDER_PEARL);
                } else if (entity instanceof TridentEntity) {
                    TridentEntity tridententity = (TridentEntity) entity;
                    if (!this.itemsSetting.isOn("Trident")
                            || tridententity.isOnGround()
                            || tridententity.isNoClip()) {
                        continue;
                    }

                    d0 = 0.05;
                    itemstack = new ItemStack(Items.TRIDENT);
                } else {
                    if (!(entity instanceof ArrowEntity)
                                    && !(entity instanceof PersistentProjectileEntity)
                            || !this.itemsSetting.isOn("Arrows")) {
                        continue;
                    }

                    if (entity instanceof ArrowEntity) {
                        ArrowEntity arrowentity = (ArrowEntity) entity;
                        if (arrowentity.isOnGround()) {
                            continue;
                        }
                    }

                    d0 = 0.05;
                    itemstack = new ItemStack(Items.ARROW);
                }

                Vec3d vec3d = entity.getLerpedPos(f);
                Vec3d vec3d1 = entity.getVelocity();
                Entity entityValue =
                        entity instanceof ProjectileEntity projectileentity
                                ? projectileentity.getOwner()
                                : null;
                this.updateSmoothedPrediction(
                        entity.getId(),
                        this.predictFlight(vec3d, vec3d1, d0, entity, entityValue, itemstack),
                        f1);
            }
        }
    }

    private static int colorChannel(int i, int j) {
        return i >> j & 0xFF;
    }

    private void drawImpactDisc(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            Vec3d vec3d,
            TrajectoriesModule.SmoothedState smoothedState) {
        float f = this.impactMarkerSizeSetting.getFloat();
        if (!(f <= 0.01F)) {
            Vec3d vec3d1 = smoothedState.impact;
            boolean flag = smoothedState.hitEntity instanceof LivingEntity;
            int i =
                    flag
                            ? ColorUtils.cachedRgba(64, 255, 64, 160)
                            : ColorUtils.scaleAlpha(ColorUtils.animatedAccent(1), 0.6F);
            int j =
                    flag
                            ? ColorUtils.cachedRgba(64, 255, 64, 40)
                            : ColorUtils.scaleAlpha(ColorUtils.animatedAccent(1), 0.15F);
            float f1 = (float) (vec3d1.x - vec3d.x);
            float f2 = (float) (vec3d1.y - vec3d.y) + 0.02F;
            float f3 = (float) (vec3d1.z - vec3d.z);
            int k = colorChannel(i, 16);
            int l = colorChannel(i, 8);
            int i1 = colorChannel(i, 0);
            int j1 = alphaOrOpaque(i);
            int k1 = colorChannel(j, 16);
            int l1 = colorChannel(j, 8);
            int i2 = colorChannel(j, 0);
            int j2 = alphaOrOpaque(j);

            for (int k2 = 0; k2 < 24; k2++) {
                double d0 = (Math.PI * 2) * (double) k2 / 24.0;
                double d1 = (Math.PI * 2) * (double) (k2 + 1) / 24.0;
                float f4 = f1 + (float) (Math.cos(d0) * (double) f);
                float f5 = f3 + (float) (Math.sin(d0) * (double) f);
                float f6 = f1 + (float) (Math.cos(d1) * (double) f);
                float f7 = f3 + (float) (Math.sin(d1) * (double) f);
                vertexconsumer.vertex(matrix4f, f1, f2, f3).color(k, l, i1, j1);
                vertexconsumer.vertex(matrix4f, f4, f2, f5).color(k1, l1, i2, j2);
                vertexconsumer.vertex(matrix4f, f6, f2, f7).color(k1, l1, i2, j2);
                vertexconsumer.vertex(matrix4f, f1, f2, f3).color(k, l, i1, j1);
            }
        }
    }

    private static void putColoredVertex(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            Vec3d vec3d,
            int i,
            int j,
            int k,
            int l) {
        vertexconsumer
                .vertex(matrix4f, (float) vec3d.x, (float) vec3d.y, (float) vec3d.z)
                .color(i, j, k, l);
    }

    private TrajectoriesModule.Prediction predictHeldItem(
            ItemStack itemstack, float f, double d0, double d1, boolean flag) {
        float yaw = client.player.getYaw(f);
        float pitch = client.player.getPitch(f);
        double d2 =
                (double)
                        (-MathHelper.sin((double) (yaw * (float) (Math.PI / 180.0)))
                                * MathHelper.cos((double) (pitch * (float) (Math.PI / 180.0))));
        double d3 = (double) (-MathHelper.sin((double) (pitch * (float) (Math.PI / 180.0))));
        double d4 =
                (double)
                        (MathHelper.cos((double) (yaw * (float) (Math.PI / 180.0)))
                                * MathHelper.cos((double) (pitch * (float) (Math.PI / 180.0))));
        Vec3d vec3d = new Vec3d(d2, d3, d4).normalize().multiply(d0);
        Vec3d vec3d1 = client.player.getVelocity();
        vec3d = vec3d.add(vec3d1.x, client.player.isOnGround() ? 0.0 : vec3d1.y, vec3d1.z);
        Vec3d vec3d2 = client.player.getLerpedPos(f);
        double d5 = vec3d2.y + (double) client.player.getStandingEyeHeight();
        Vec3d vec3d3 =
                new Vec3d(vec3d2.x, d5, vec3d2.z)
                        .add(new Vec3d(d2, d3, d4).normalize().multiply(0.2));
        TrajectoriesModule.Prediction prediction =
                this.predictFlight(vec3d3, vec3d, d1, client.player, client.player, itemstack);
        if (prediction == null) {
            return null;
        } else {
            Vec3d vec3d4 = new Vec3d(d2, d3, d4).normalize();
            Vec3d vec3d5 = Vec3d.fromPolar(0.0F, yaw + 90.0F);
            if (flag) {
                vec3d5 = vec3d5.multiply(-1.0);
            }

            Vec3d vec3d6 = vec3d5.multiply(0.32).add(0.0, -0.18, 0.0).add(vec3d4.multiply(0.25));
            List listx = prediction.points;
            int i = Math.min(10, listx.size());

            for (int j = 0; j < i; j++) {
                float f3 = 1.0F - (float) j / (float) i;
                f3 *= f3;
                listx.set(j, ((Vec3d) listx.get(j)).add(vec3d6.multiply((double) f3)));
            }

            return prediction;
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null) {
            float tickDelta = render3DEvent.getTickDelta();
            long nowNanos = System.nanoTime();
            float f1 =
                    this.lastFrameNanos == 0L
                            ? 0.05F
                            : Math.min(0.1F, (float) (nowNanos - this.lastFrameNanos) / 1.0E9F);
            this.lastFrameNanos = nowNanos;
            this.updatePredictions(tickDelta, f1);
            if (!this.renderPredictions.isEmpty()) {
                MatrixStack matrixstack = render3DEvent.getMatrixStack();
                Vec3d vec3d = client.gameRenderer.getCamera().getCameraPos();
                Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
                Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);
                if (this.trajectoryLineSetting.isOn()) {
                    ArrayList arraylist = new ArrayList(this.renderPredictions.size());

                    for (TrajectoriesModule.SmoothedState smoothedState : this.renderPredictions) {
                        TrajectoriesModule.RibbonData ribbonData =
                                this.buildRibbon(smoothedState, vec3d);
                        if (ribbonData != null) {
                            arraylist.add(ribbonData);
                        }
                    }

                    if (this.glowLineSetting.isOn()) {
                        VertexConsumer buffer = immediate.getBuffer(GLOW_LAYER);

                        for (TrajectoriesModule.RibbonData ribbonDataValue :
                                (Iterable<TrajectoriesModule.RibbonData>) (Iterable) arraylist) {
                            drawRibbonGlow(buffer, matrix4f, ribbonDataValue);
                        }
                    }

                    VertexConsumer bufferValue = immediate.getBuffer(RIBBON_LAYER);

                    for (TrajectoriesModule.RibbonData ribbonData2 :
                            (Iterable<TrajectoriesModule.RibbonData>) (Iterable) arraylist) {
                        drawRibbon(bufferValue, matrix4f, ribbonData2);
                    }
                }

                VertexConsumer vertexconsumer = immediate.getBuffer(FILL_LAYER);

                for (TrajectoriesModule.SmoothedState smoothedStateValue : this.renderPredictions) {
                    this.drawImpactDisc(vertexconsumer, matrix4f, vec3d, smoothedStateValue);
                }

                VertexConsumer buffer2 = immediate.getBuffer(LINE_LAYER);

                for (TrajectoriesModule.SmoothedState smoothedState2 : this.renderPredictions) {
                    this.drawImpactCross(buffer2, matrix4f, vec3d, smoothedState2);
                }

                immediate.draw();
            }
        }
    }

    private void drawImpactCross(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            Vec3d vec3d,
            TrajectoriesModule.SmoothedState smoothedState) {
        float f = this.impactMarkerSizeSetting.getFloat();
        if (!(f <= 0.01F)) {
            Vec3d vec3d1 = smoothedState.impact;
            boolean flag = smoothedState.hitEntity instanceof LivingEntity;
            int color =
                    flag
                            ? ColorUtils.cachedRgba(64, 255, 64, 160)
                            : ColorUtils.scaleAlpha(ColorUtils.animatedAccent(1), 0.6F);
            int j =
                    flag
                            ? ColorUtils.cachedRgba(64, 255, 64, 200)
                            : ColorUtils.scaleAlpha(color, 1.0F);
            float f1 = (float) (vec3d1.x - vec3d.x);
            float f2 = (float) (vec3d1.y - vec3d.y) + 0.02F;
            float f3 = (float) (vec3d1.z - vec3d.z);
            int k = colorChannel(j, 16);
            int l = colorChannel(j, 8);
            int i1 = colorChannel(j, 0);
            int j1 = alphaOrOpaque(j);
            float f4 = Math.max(0.15F, f * 0.35F);
            putLine(vertexconsumer, matrix4f, f1 - f4, f2, f3, f1 + f4, f2, f3, k, l, i1, j1);
            putLine(vertexconsumer, matrix4f, f1, f2, f3 - f4, f1, f2, f3 + f4, k, l, i1, j1);
        }
    }

    private static void drawRibbonGlow(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            TrajectoriesModule.RibbonData ribbonData) {
        int length = ribbonData.points.length;

        for (int j = 0; j < length - 1; j++) {
            int k = (int) (ribbonData.opacities[j] * 0.3F * 255.0F);
            int l = (int) (ribbonData.opacities[j + 1] * 0.3F * 255.0F);
            if (k > 0 || l > 0) {
                Vec3d vec3d = ribbonData.points[j];
                Vec3d vec3d1 = ribbonData.points[j + 1];
                Vec3d vec3d2 =
                        ribbonData.sideVectors[j].multiply((double) (ribbonData.widths[j] * 3.0F));
                Vec3d vec3d3 =
                        ribbonData.sideVectors[j + 1].multiply(
                                (double) (ribbonData.widths[j + 1] * 3.0F));
                putColoredVertex(
                        vertexconsumer,
                        matrix4f,
                        vec3d,
                        ribbonData.red,
                        ribbonData.green,
                        ribbonData.blue,
                        k);
                putColoredVertex(
                        vertexconsumer,
                        matrix4f,
                        vec3d1,
                        ribbonData.red,
                        ribbonData.green,
                        ribbonData.blue,
                        l);
                putColoredVertex(
                        vertexconsumer,
                        matrix4f,
                        vec3d1.add(vec3d3),
                        ribbonData.red,
                        ribbonData.green,
                        ribbonData.blue,
                        0);
                putColoredVertex(
                        vertexconsumer,
                        matrix4f,
                        vec3d.add(vec3d2),
                        ribbonData.red,
                        ribbonData.green,
                        ribbonData.blue,
                        0);
                putColoredVertex(
                        vertexconsumer,
                        matrix4f,
                        vec3d,
                        ribbonData.red,
                        ribbonData.green,
                        ribbonData.blue,
                        k);
                putColoredVertex(
                        vertexconsumer,
                        matrix4f,
                        vec3d1,
                        ribbonData.red,
                        ribbonData.green,
                        ribbonData.blue,
                        l);
                putColoredVertex(
                        vertexconsumer,
                        matrix4f,
                        vec3d1.subtract(vec3d3),
                        ribbonData.red,
                        ribbonData.green,
                        ribbonData.blue,
                        0);
                putColoredVertex(
                        vertexconsumer,
                        matrix4f,
                        vec3d.subtract(vec3d2),
                        ribbonData.red,
                        ribbonData.green,
                        ribbonData.blue,
                        0);
            }
        }
    }

    private static int brightenChannel(int i, float f) {
        return i + (int) ((float) (255 - i) * 0.45F * f);
    }

    private void updatePredictions(float f, float f1) {
        for (TrajectoriesModule.SmoothedState smoothedState : this.predictionsByEntity.values()) {
            smoothedState.updated = false;
        }

        if (this.heldProjectileSetting.isOn()) {
            this.updateHeldProjectiles(f, f1);
        }

        if (this.flyingProjectilesSetting.isOn()) {
            this.updateFlyingProjectiles(f, f1);
        }

        this.predictionsByEntity.entrySet().removeIf(entry -> !entry.getValue().updated);
        this.renderPredictions.clear();
        this.renderPredictions.addAll(this.predictionsByEntity.values());
    }

    private static boolean isCrossbowCharged(ItemStack itemstack) {
        ChargedProjectilesComponent chargedprojectilescomponent =
                itemstack.get(DataComponentTypes.CHARGED_PROJECTILES);
        return chargedprojectilescomponent != null && !chargedprojectilescomponent.isEmpty();
    }

    public TrajectoriesModule() {
        this.heldProjectileSetting = new BooleanSetting(this, "Held Projectile", true);
        this.flyingProjectilesSetting = new BooleanSetting(this, "Flying projectiles", true);
        this.trajectoryLineSetting = new BooleanSetting(this, "Trajectory line", true);
        this.glowLineSetting =
                new BooleanSetting(this, "Glow line", false)
                        .visibleWhen(() -> this.trajectoryLineSetting.isOn());
        this.itemIconSetting = new BooleanSetting(this, "Item icon", true);
        this.timeToImpactSetting = new BooleanSetting(this, "Time to Impact", true);
        this.lineThicknessSetting =
                new SliderSetting(this, "Line thickness", 2.0F, 1.0F, 5.0F, 0.5F)
                        .visibleWhen(() -> this.trajectoryLineSetting.isOn());
        this.impactMarkerSizeSetting =
                new SliderSetting(this, "Impact Marker Size", 0.5F, 0.1F, 2.0F, 0.1F);
        this.bufferAllocator = new BufferAllocator(131072);
        this.predictionsByEntity = new LinkedHashMap<>();
        this.renderPredictions = new ArrayList<>();
        this.lastFrameNanos = 0L;
    }

    @EventHandler
    public void onRender2D(Render2DEvent render2DEvent) {
        if (client.player != null && !this.renderPredictions.isEmpty()) {
            if (this.itemIconSetting.isOn() || this.timeToImpactSetting.isOn()) {
                for (TrajectoriesModule.SmoothedState smoothedState : this.renderPredictions) {
                    Vec3d vec3d =
                            ProjectionUtils.worldToScreen(smoothedState.impact.add(0.0, 0.25, 0.0));
                    if (!(vec3d.z <= 0.0) && !(vec3d.z >= 1.0)) {
                        float f = (float) vec3d.x;
                        float f1 = (float) vec3d.y;
                        float f2 = 10.0F;
                        float width = f2 + 4.0F;
                        if (this.itemIconSetting.isOn() && !smoothedState.icon.isEmpty()) {
                            RenderUtils.Render2D.drawRoundedRect(
                                    f - width / 2.0F,
                                    f1 - width / 2.0F,
                                    width,
                                    width,
                                    ColorUtils.cachedRgba(11, 11, 11, 140),
                                    4.0F);
                            ItemIconRenderer.drawItem(
                                    render2DEvent.getDrawContext(),
                                    smoothedState.icon,
                                    f - f2 / 2.0F,
                                    f1 - f2 / 2.0F,
                                    f2 / 16.0F,
                                    1.0F);
                        }

                        if (this.timeToImpactSetting.isOn()) {
                            String string =
                                    String.format(
                                            Locale.ROOT,
                                            "%.1fs",
                                            (float) smoothedState.ticks / 20.0F);
                            float size = 6.0F;
                            float widthValue = Fonts.SF_REGULAR.measureWidth(string, size) + 6.0F;
                            float innerX = f - widthValue / 2.0F;
                            float innerY = f1 + width / 2.0F + 2.0F;
                            RenderUtils.Render2D.drawRoundedRect(
                                    innerX,
                                    innerY,
                                    widthValue,
                                    size + 3.0F,
                                    ColorUtils.cachedRgba(0, 0, 0, 128),
                                    3.0F);
                            Font font = Fonts.SF_REGULAR;
                            float f8 = innerX + 3.0F;
                            float f9 = innerY + 1.5F;
                            ColorUtils.opaqueGrayscale(255);
                            font.drawText(string, f8, f9, size);
                        }
                    }
                }
            }
        }
    }

    @Override
    protected void onDisable() {
        this.predictionsByEntity.clear();
        this.renderPredictions.clear();
        this.lastFrameNanos = 0L;
    }

    private ItemStack getCrossbowProjectile(ItemStack itemstack) {
        ChargedProjectilesComponent chargedprojectilescomponent =
                itemstack.get(DataComponentTypes.CHARGED_PROJECTILES);
        return chargedprojectilescomponent != null
                        && !chargedprojectilescomponent.getProjectiles().isEmpty()
                ? chargedprojectilescomponent.getProjectiles().getFirst()
                : new ItemStack(Items.ARROW);
    }

    private static void putLine(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            int i,
            int j,
            int k,
            int l) {
        vertexconsumer.vertex(matrix4f, f, f1, f2).color(i, j, k, l);
        vertexconsumer.vertex(matrix4f, f3, f4, f5).color(i, j, k, l);
    }

    private void updateHeldProjectiles(float f, float f1) {
        ItemStack itemstack = client.player.getMainHandStack();
        ItemStack offHandStack = client.player.getOffHandStack();
        if (this.itemsSetting.isOn("ender pearl")) {
            if (itemstack.isOf(Items.ENDER_PEARL)) {
                this.updateSmoothedPrediction(
                        0, this.predictHeldItem(itemstack, f, 1.5, 0.03, false), f1);
            } else if (offHandStack.isOf(Items.ENDER_PEARL)) {
                this.updateSmoothedPrediction(
                        0, this.predictHeldItem(offHandStack, f, 1.5, 0.03, true), f1);
            }
        }

        if (this.itemsSetting.isOn("Arrows")) {
            if (client.player.isUsingItem()
                    && client.player.getActiveItem().getItem() == Items.BOW) {
                float pullProgress = BowItem.getPullProgress(client.player.getItemUseTime());
                if (pullProgress >= 0.1F) {
                    boolean flag2;
                    flag2 = (client.player.getActiveHand() == Hand.OFF_HAND);

                    this.updateSmoothedPrediction(
                            0,
                            this.predictHeldItem(
                                    new ItemStack(Items.ARROW),
                                    f,
                                    (double) pullProgress * 3.0,
                                    0.05,
                                    flag2),
                            f1);
                }
            } else {
                ItemStack itemstackValue = null;
                boolean flag = false;
                if (itemstack.isOf(Items.CROSSBOW)) {
                    itemstackValue = itemstack;
                } else if (offHandStack.isOf(Items.CROSSBOW)) {
                    itemstackValue = offHandStack;
                    flag = true;
                }

                if (itemstackValue != null && isCrossbowCharged(itemstackValue)) {
                    this.updateSmoothedPrediction(
                            0,
                            this.predictHeldItem(
                                    this.getCrossbowProjectile(itemstackValue),
                                    f,
                                    3.15,
                                    0.05,
                                    flag),
                            f1);
                }
            }
        }

        if (this.itemsSetting.isOn("Trident")
                && client.player.isUsingItem()
                && client.player.getActiveItem().getItem() == Items.TRIDENT) {
            int itemUseTime = client.player.getItemUseTime();
            if (itemUseTime > 0) {
                float f3 = Math.min((float) itemUseTime / 10.0F, 1.0F);
                if (f3 < 0.1F) {
                    f3 = 0.1F;
                }

                boolean flag1;
                flag1 = (client.player.getActiveHand() == Hand.OFF_HAND);

                this.updateSmoothedPrediction(
                        0,
                        this.predictHeldItem(
                                new ItemStack(Items.TRIDENT), f, 2.5 * (double) f3, 0.05, flag1),
                        f1);
            }
        }
    }

    private static List<Vec3d> densifyPath(List<Vec3d> list) {
        if (list.size() < 2) {
            return list;
        } else {
            ArrayList arraylist = new ArrayList(list.size() * 2);
            arraylist.add((Vec3d) list.getFirst());

            for (int i = 0; i + 1 < list.size(); i++) {
                Vec3d vec3d = (Vec3d) list.get(i);
                Vec3d vec3d1 = (Vec3d) list.get(i + 1);
                arraylist.add(vec3d.lerp(vec3d1, 0.33));
                arraylist.add(vec3d.lerp(vec3d1, 0.66));
                arraylist.add(vec3d1);
            }

            return arraylist;
        }
    }

    private static void drawRibbon(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            TrajectoriesModule.RibbonData ribbonData) {
        int length = ribbonData.points.length;

        for (int j = 0; j < length - 1; j++) {
            int k = (int) (ribbonData.opacities[j] * 255.0F);
            int l = (int) (ribbonData.opacities[j + 1] * 255.0F);
            if (k > 0 || l > 0) {
                float f = (float) j / (float) (length - 1);
                float f1 = (float) (j + 1) / (float) (length - 1);
                int i1 = brightenChannel(ribbonData.red, f);
                int j1 = brightenChannel(ribbonData.green, f);
                int k1 = brightenChannel(ribbonData.blue, f);
                int l1 = brightenChannel(ribbonData.red, f1);
                int i2 = brightenChannel(ribbonData.green, f1);
                int j2 = brightenChannel(ribbonData.blue, f1);
                Vec3d vec3d = ribbonData.points[j];
                Vec3d vec3d1 = ribbonData.points[j + 1];
                Vec3d vec3d2 = ribbonData.sideVectors[j].multiply((double) ribbonData.widths[j]);
                Vec3d vec3d3 =
                        ribbonData.sideVectors[j + 1].multiply((double) ribbonData.widths[j + 1]);
                Vec3d vec3d4 = vec3d2.multiply(0.7);
                Vec3d vec3d5 = vec3d3.multiply(0.7);
                putColoredVertex(vertexconsumer, matrix4f, vec3d.subtract(vec3d4), i1, j1, k1, k);
                putColoredVertex(vertexconsumer, matrix4f, vec3d1.subtract(vec3d5), l1, i2, j2, l);
                putColoredVertex(vertexconsumer, matrix4f, vec3d1.add(vec3d5), l1, i2, j2, l);
                putColoredVertex(vertexconsumer, matrix4f, vec3d.add(vec3d4), i1, j1, k1, k);
                putColoredVertex(vertexconsumer, matrix4f, vec3d.add(vec3d4), i1, j1, k1, k);
                putColoredVertex(vertexconsumer, matrix4f, vec3d1.add(vec3d5), l1, i2, j2, l);
                putColoredVertex(vertexconsumer, matrix4f, vec3d1.add(vec3d3), l1, i2, j2, 0);
                putColoredVertex(vertexconsumer, matrix4f, vec3d.add(vec3d2), i1, j1, k1, 0);
                putColoredVertex(vertexconsumer, matrix4f, vec3d.subtract(vec3d4), i1, j1, k1, k);
                putColoredVertex(vertexconsumer, matrix4f, vec3d1.subtract(vec3d5), l1, i2, j2, l);
                putColoredVertex(vertexconsumer, matrix4f, vec3d1.subtract(vec3d3), l1, i2, j2, 0);
                putColoredVertex(vertexconsumer, matrix4f, vec3d.subtract(vec3d2), i1, j1, k1, 0);
            }
        }
    }

    @Environment(EnvType.CLIENT)
    private static record Prediction(
            List<Vec3d> points, Vec3d impact, int ticks, Entity hitEntity, ItemStack icon) {}

    @Environment(EnvType.CLIENT)
    private static final class RibbonData {
        float[] widths;
        int blue;
        int red;
        float[] opacities;
        Vec3d[] points;
        Vec3d[] sideVectors;
        int green;
    }

    @Environment(EnvType.CLIENT)
    private static final class SmoothedState {
        boolean updated;
        Entity hitEntity;
        int ticks;
        ItemStack icon;
        List<Vec3d> points = new ArrayList<>();
        Vec3d impact = Vec3d.ZERO;

        private void smoothPath(List list, float f) {
            if (list.isEmpty()) {
                this.points.clear();
            } else {
                int i = Math.max(this.points.size(), list.size());
                if (i <= 1) {
                    this.points = new ArrayList<>(list);
                } else {
                    List listValue = resamplePath(this.points, i);
                    List list3 = resamplePath(list, i);
                    this.points = new ArrayList<>(i);

                    for (int j = 0; j < i; j++) {
                        float f1 = f * (0.15F + 0.85F * (float) j / (float) (i - 1));
                        this.points.add(
                                ((Vec3d) listValue.get(j)).lerp((Vec3d) list3.get(j), (double) f1));
                    }
                }
            }
        }

        private static Vec3d pointAtDistance(List<Vec3d> list, double d0) {
            double d1 = 0.0;

            for (int i = 0; i + 1 < list.size(); i++) {
                Vec3d vec3dx = (Vec3d) list.get(i);
                Vec3d vec3d1 = (Vec3d) list.get(i + 1);
                double d2 = vec3dx.distanceTo(vec3d1);
                if (d1 + d2 >= d0) {
                    double d3 = d2 <= 1.0E-8 ? 0.0 : (d0 - d1) / d2;
                    return vec3dx.lerp(vec3d1, d3);
                }

                d1 += d2;
            }

            return (Vec3d) list.getLast();
        }

        static TrajectoriesModule.SmoothedState fromPrediction(
                TrajectoriesModule.Prediction prediction) {
            TrajectoriesModule.SmoothedState smoothedState = new TrajectoriesModule.SmoothedState();
            smoothedState.points = new ArrayList<>(prediction.points());
            smoothedState.impact = prediction.impact();
            smoothedState.ticks = prediction.ticks();
            smoothedState.hitEntity = prediction.hitEntity();
            smoothedState.icon = prediction.icon().copy();
            return smoothedState;
        }

        void update(TrajectoriesModule.Prediction prediction, float f, float f1) {
            float f2 = 1.0F - (float) Math.exp((double) (-f * f1));
            if (this.impact.squaredDistanceTo(prediction.impact()) > 4096.0) {
                this.points = new ArrayList<>(prediction.points());
                this.impact = prediction.impact();
            } else {
                this.impact = this.impact.lerp(prediction.impact(), (double) f2);
                this.smoothPath(prediction.points(), f2);
            }

            this.ticks = prediction.ticks();
            this.hitEntity = prediction.hitEntity();
            this.icon = prediction.icon().copy();
        }

        private SmoothedState() {
            this.icon = ItemStack.EMPTY;
        }

        private static List<Vec3d> resamplePath(List<Vec3d> list, int i) {
            if (list.isEmpty()) {
                return new ArrayList<>();
            } else if (list.size() != 1 && i > 1) {
                double d0 = 0.0;

                for (int l = 0; l + 1 < list.size(); l++) {
                    d0 += ((Vec3d) list.get(l)).distanceTo((Vec3d) list.get(l + 1));
                }

                ArrayList arrayList = new ArrayList(i);
                arrayList.add((Vec3d) list.getFirst());

                for (int k = 1; k < i - 1; k++) {
                    arrayList.add(pointAtDistance(list, d0 * (double) k / (double) (i - 1)));
                }

                arrayList.add((Vec3d) list.getLast());
                return arrayList;
            } else {
                ArrayList arraylist = new ArrayList(i);
                Vec3d vec3dx = (Vec3d) list.getFirst();

                for (int j = 0; j < i; j++) {
                    arraylist.add(vec3dx);
                }

                return arraylist;
            }
        }
    }
}
