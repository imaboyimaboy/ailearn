package dev.gooba.client;

import com.mojang.blaze3d.systems.RenderSystem;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

import org.joml.Matrix4f;
import org.joml.Vector4f;

@Environment(EnvType.CLIENT)
public final class HandEditor implements OverlayEditor {
    private Arm draggedArm;
    private boolean active;
    private float initialHandY;
    private static final HandEditor instance = new HandEditor();
    private float initialHandX;
    private long nextSwingMillis;
    private final ModuleSettingsPanel shaderSettingsPanel;
    private final MenuButton resetRightButton;
    private int dragButton;
    private final MenuButton resetLeftButton;
    private final HandEditor.HandBounds rightHandBounds;
    private float dragStartX;
    private static final ItemStack LEFT_PREVIEW_ITEM = new ItemStack(Items.TOTEM_OF_UNDYING);
    private boolean swingPreviewEnabled;
    private final ModuleSettingsPanel swingSettingsPanel;
    private final HandEditor.HandBounds leftHandBounds = new HandEditor.HandBounds();
    private Arm hoveredArm;
    private float screenWidth;
    private final EasingAnimation rightArmHoverAnimation;
    private Rectangle swingPreviewBounds;
    private final MenuButton foldHandsButton;
    private final EasingAnimation overlayOpacityAnimation;
    private final AnimationRegistry animationRegistry;
    private static final ItemStack RIGHT_PREVIEW_ITEM = new ItemStack(Items.NETHERITE_SWORD);
    private final MenuButton saveButton;
    private float dragStartY;
    private static final float[][] HAND_BOX_CORNERS =
            new float[][] {
                {-0.55F, -0.55F, -0.35F},
                {-0.55F, -0.55F, 0.35F},
                {-0.55F, 0.55F, -0.35F},
                {-0.55F, 0.55F, 0.35F},
                {0.55F, -0.55F, -0.35F},
                {0.55F, -0.55F, 0.35F},
                {0.55F, 0.55F, -0.35F},
                {0.55F, 0.55F, 0.35F}
            };
    private final EasingAnimation leftArmHoverAnimation;
    private float screenHeight;

    private void dragHand(float f, float f1) {
        if (this.active && this.draggedArm != null) {
            HandsModule handsModule = HandsModule.getInstance();
            if (handsModule != null) {
                float f2 = 1.0F / this.getPixelsPerUnit();
                float f3 = this.initialHandX + (f - this.dragStartX) * f2;
                float f4 = this.initialHandY - (f1 - this.dragStartY) * f2;
                SliderSetting sliderSetting2 =
                        this.draggedArm == Arm.RIGHT
                                ? handsModule.rightXSetting
                                : handsModule.leftXSetting;
                SliderSetting sliderSetting3 =
                        this.draggedArm == Arm.RIGHT
                                ? handsModule.rightYSetting
                                : handsModule.leftYSetting;
                sliderSetting2.setValue(
                        MathHelper.clamp(f3, sliderSetting2.minValue, sliderSetting2.maxValue));
                sliderSetting3.setValue(
                        MathHelper.clamp(f4, sliderSetting3.minValue, sliderSetting3.maxValue));
            }
        }
    }

    private void drawInstructions(float f, float opacity) {
        Gooba.getInstance().getHudManager().flush();
        Fonts.SF_REGULAR.drawCenteredText(
                "Hand Editor", f / 2.0F, 16.0F, 8.0F, ColorUtils.grayscaleOpacity(240, opacity));
        Fonts.SF_REGULAR.drawCenteredText(
                "Hover Over a Hand",
                f / 2.0F,
                29.0F,
                6.0F,
                ColorUtils.grayscaleOpacity(255, opacity * 0.45F));
        Fonts.SF_REGULAR.drawCenteredText(
                "LMB/RMB + Move — Position   •   Mouse Wheel — Resize",
                f / 2.0F,
                39.0F,
                5.5F,
                ColorUtils.grayscaleOpacity(255, opacity * 0.3F));
    }

    @Override
    public void saveAndClose() {
        if (this.active) {
            if (Gooba.getInstance() != null && Gooba.getInstance().getConfigManager() != null) {
                Gooba.getInstance().getConfigManager().saveState();
            }

            this.close();
        }
    }

    private void restoreEffects() {
        HandEffectFramebuffer handEffectFramebuffer2 = HandEffectFramebuffer.getInstance();
        handEffectFramebuffer2.setCaptureEditorOverlay(false);
        ShaderHandModule shaderHandModule2 = ShaderHandModule.getInstance();
        if (shaderHandModule2 != null && shaderHandModule2.isEnabled()) {
            handEffectFramebuffer2.setEnabled(true);
            shaderHandModule2.applyEffectSettings();
        } else {
            handEffectFramebuffer2.setEnabled(false);
        }
    }

    public void afterHandRender() {
        if (this.active) {
            HandEffectFramebuffer handEffectFramebuffer2 = HandEffectFramebuffer.getInstance();
            handEffectFramebuffer2.captureAfterHands();
            handEffectFramebuffer2.compositeEffects();
        }
    }

    private float getPixelsPerUnit() {
        return Math.max(1.0F, this.screenHeight / 1.05F);
    }

    @Override
    public void handleMouseButton(float mouseX, float mouseY, int dragButtonValue, boolean flag) {
        if (this.active) {
            if (dragButtonValue == 0 || dragButtonValue == 1) {
                if (!flag) {
                    if (dragButtonValue == 0) {
                        this.swingSettingsPanel.stopDragging();
                        this.shaderSettingsPanel.stopDragging();
                    }

                    if (dragButtonValue == this.dragButton) {
                        this.draggedArm = null;
                        this.dragButton = -1;
                    }
                } else if (!this.isOverControls(mouseX, mouseY)) {
                    Arm armx = this.nearestHandAt(mouseX, mouseY);
                    if (armx != null) {
                        this.beginDrag(armx, mouseX, mouseY, dragButtonValue);
                    }
                }
            }
        }
    }

    @Override
    public boolean isActive() {
        return this.active;
    }

    private Rectangle getHandRectangle(Arm arm) {
        HandsModule handsModule = HandsModule.getInstance();
        float f = 0.0F;
        float f1 = 0.0F;
        float f2 = 1.0F;
        if (handsModule != null) {
            f =
                    arm == Arm.RIGHT
                            ? handsModule.rightXSetting.getFloat()
                            : handsModule.leftXSetting.getFloat();
            f1 =
                    arm == Arm.RIGHT
                            ? handsModule.rightYSetting.getFloat()
                            : handsModule.leftYSetting.getFloat();
            f2 =
                    arm == Arm.RIGHT
                            ? handsModule.rightScaleSetting.getFloat()
                            : handsModule.leftScaleSetting.getFloat();
        }

        float pixelsPerUnit = this.getPixelsPerUnit();
        float f4 = this.screenWidth * (arm == Arm.LEFT ? 0.16F : 0.84F);
        float f5 = this.screenHeight * 0.78F;
        float f6 =
                MathHelper.clamp(
                        Math.min(this.screenWidth, this.screenHeight) * 0.38F, 150.0F, 240.0F);
        float f7 = MathHelper.clamp(f6 * (0.88F + f2 * 0.12F), 145.0F, 275.0F);
        float f8 = f4 + f * pixelsPerUnit;
        float f9 = f5 - f1 * pixelsPerUnit;
        f8 = MathHelper.clamp(f8, f7 / 2.0F + 8.0F, this.screenWidth - f7 / 2.0F - 8.0F);
        f9 = MathHelper.clamp(f9, f7 / 2.0F + 52.0F, this.screenHeight - f7 / 2.0F - 54.0F);
        return new Rectangle(f8 - f7 / 2.0F, f9 - f7 / 2.0F, f7, f7);
    }

    private void layoutControls(float f, float f1) {
        float heightValue = 18.0F;
        float widthValue2 = 100.0F;
        float widthValue = 120.0F;
        float widthValueValue = 112.0F;
        float f6 = f1 - 30.0F;
        this.saveButton.setBounds(f / 2.0F - widthValue / 2.0F, f6, widthValue, heightValue);
        this.foldHandsButton.setBounds(
                f / 2.0F - widthValueValue / 2.0F, f6 - 25.0F, widthValueValue, heightValue);
        this.resetLeftButton.setBounds(20.0F, f6, widthValue2, heightValue);
        this.resetRightButton.setBounds(f - 20.0F - widthValue2, f6, widthValue2, heightValue);
        this.swingPreviewBounds = new Rectangle(f / 2.0F - 80.0F, f6 - 52.0F, 160.0F, 13.0F);
    }

    private void applyPreviewEffects(HandEffectFramebuffer handEffectFramebuffer2) {
        handEffectFramebuffer2.setEnabled(true);
        handEffectFramebuffer2.setGlassEnabled(false);
        handEffectFramebuffer2.setSaturation(1.0F);
        handEffectFramebuffer2.setReflectionEnabled(false);
        handEffectFramebuffer2.setTintColor(0);
        handEffectFramebuffer2.setTintIntensity(0.0F);
        handEffectFramebuffer2.setIceIntensity(0.0F);
        handEffectFramebuffer2.setSmokeAmount(0.0F);
        handEffectFramebuffer2.setOutlineEnabled(true);
        handEffectFramebuffer2.setGlowStrength(this.hoveredArm == null ? 12.0F : 20.0F);
        handEffectFramebuffer2.setOutlineWidth(1);
        handEffectFramebuffer2.setGlowMode(2);
        handEffectFramebuffer2.setOutlineColor(0);
        handEffectFramebuffer2.setGlowColors(ColorUtils.hudAccent());
        handEffectFramebuffer2.setShimmerEnabled(false);
    }

    private boolean isOverControls(float mouseX, float mouseY) {
        return this.saveButton.contains(mouseX, mouseY)
                || this.foldHandsButton.contains(mouseX, mouseY)
                || this.resetLeftButton.contains(mouseX, mouseY)
                || this.resetRightButton.contains(mouseX, mouseY)
                || this.swingPreviewBounds.contains(mouseX, mouseY)
                || this.swingSettingsPanel.getBounds().contains(mouseX, mouseY)
                || this.shaderSettingsPanel.getBounds().contains(mouseX, mouseY);
    }

    @Override
    public void handleMouseMove(float f, float f1) {
        if (!this.shaderSettingsPanel.mouseDragged(f, f1)) {
            if (!this.swingSettingsPanel.mouseDragged(f, f1)) {
                this.dragHand(f, f1);
            }
        }
    }

    private void resetSettingsPanels() {
        this.swingSettingsPanel.closeColorPickers();
        this.shaderSettingsPanel.closeColorPickers();
    }

    @Override
    public boolean capturesMouse(float f, float f1) {
        return this.active;
    }

    private void close() {
        this.active = false;
        this.hoveredArm = null;
        this.draggedArm = null;
        this.dragButton = -1;
        this.swingSettingsPanel.stopDragging();
        this.shaderSettingsPanel.stopDragging();
        this.swingPreviewEnabled = false;
        this.nextSwingMillis = 0L;
        this.resetSettingsPanels();
        HandsModule handsModule = HandsModule.getInstance();
        if (handsModule != null) {
            handsModule.setPreviewing(false);
        }

        this.restoreEffects();
    }

    private Arm handAt(float mouseX, float mouseY) {
        if (!this.isOverControls(mouseX, mouseY)
                && !(this.screenWidth <= 0.0F)
                && !(this.screenHeight <= 0.0F)) {
            Rectangle rectangleValue = this.getHandRectangle(Arm.LEFT);
            Rectangle handRectangle = this.getHandRectangle(Arm.RIGHT);
            boolean flagx = rectangleValue.contains(mouseX, mouseY);
            boolean flag1 = handRectangle.contains(mouseX, mouseY);
            if (flagx && flag1) {
                float f2 = rectangleValue.squaredDistanceToCenter(mouseX, mouseY);
                float f3 = handRectangle.squaredDistanceToCenter(mouseX, mouseY);
                return f2 <= f3 ? Arm.LEFT : Arm.RIGHT;
            } else if (flagx) {
                return Arm.LEFT;
            } else if (flag1) {
                return Arm.RIGHT;
            } else if (mouseY >= this.screenHeight * 0.32F) {
                return mouseX < this.screenWidth / 2.0F ? Arm.LEFT : Arm.RIGHT;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    public void beforeHandRender() {
        if (this.active) {
            HandEffectFramebuffer handEffectFramebuffer2 = HandEffectFramebuffer.getInstance();
            handEffectFramebuffer2.setCaptureEditorOverlay(true);
            ShaderHandModule shaderHandModule2 = ShaderHandModule.getInstance();
            if (shaderHandModule2 != null && shaderHandModule2.isEnabled()) {
                handEffectFramebuffer2.setEnabled(true);
                shaderHandModule2.applyEffectSettings();
            } else {
                this.applyPreviewEffects(handEffectFramebuffer2);
            }

            handEffectFramebuffer2.captureBeforeHands();
        }
    }

    private void beginDrag(
            Arm arm, float dragStartXValue, float dragStartYValue, int dragButtonValue) {
        HandsModule handsModule = HandsModule.getInstance();
        if (handsModule != null) {
            this.draggedArm = arm;
            this.dragButton = dragButtonValue;
            this.dragStartX = dragStartXValue;
            this.dragStartY = dragStartYValue;
            this.initialHandX =
                    arm == Arm.RIGHT
                            ? handsModule.rightXSetting.getFloat()
                            : handsModule.leftXSetting.getFloat();
            this.initialHandY =
                    arm == Arm.RIGHT
                            ? handsModule.rightYSetting.getFloat()
                            : handsModule.leftYSetting.getFloat();
        }
    }

    public static HandEditor getInstance() {
        return instance;
    }

    @Override
    public void saveAndCloseOnKey(int i) {
        if (this.active) {
            if (Gooba.getInstance() != null && Gooba.getInstance().getConfigManager() != null) {
                Gooba.getInstance().getConfigManager().saveState();
            }

            this.close();
        }
    }

    @Override
    public void render(float width, float height, float mouseXValue, float mouseYValue, float f4) {
        if (this.active) {
            this.screenWidth = width;
            this.screenHeight = height;
            this.animationRegistry.setMousePosition(mouseXValue, mouseYValue);
            this.layoutControls(width, height);
            this.swingSettingsPanel.layout(
                    SwingAnimationModule.getInstance(),
                    "Swing Animation",
                    width - 168.0F - 16.0F,
                    14.0F,
                    width,
                    height,
                    this.animationRegistry);
            this.shaderSettingsPanel.layout(
                    ShaderHandModule.getInstance(),
                    "GlassHands",
                    16.0F,
                    14.0F,
                    width,
                    height,
                    this.animationRegistry);
            this.updateSwingPreview();
            this.overlayOpacityAnimation.update();
            float opacity = this.overlayOpacityAnimation.getFloatValue() * f4;
            this.hoveredArm =
                    this.draggedArm != null
                            ? this.draggedArm
                            : this.handAt(mouseXValue, mouseYValue);
            if (this.hoveredArm == Arm.LEFT) {
                this.animateVisibility(this.leftArmHoverAnimation, true);
            } else {
                this.animateVisibility(this.leftArmHoverAnimation, false);
            }

            if (this.hoveredArm == Arm.RIGHT) {
                this.animateVisibility(this.rightArmHoverAnimation, true);
            } else {
                this.animateVisibility(this.rightArmHoverAnimation, false);
            }

            this.saveButton.updateAnimations(mouseXValue, mouseYValue);
            this.foldHandsButton.updateAnimations(mouseXValue, mouseYValue);
            this.resetLeftButton.updateAnimations(mouseXValue, mouseYValue);
            this.resetRightButton.updateAnimations(mouseXValue, mouseYValue);
            RenderUtils.Render2D.drawRect(
                    0.0F, 0.0F, width, height, ColorUtils.grayscaleOpacity(0, 0.3F * opacity));
            Gooba.getInstance().getHudManager().flush();
            HandEffectFramebuffer.getInstance().renderEditorOverlay();
            this.drawInstructions(width, opacity);
            this.animationRegistry.drawMenuButton(this.resetLeftButton, opacity);
            this.animationRegistry.drawMenuButton(this.resetRightButton, opacity);
            this.animationRegistry.drawMenuButton(this.foldHandsButton, opacity);
            this.animationRegistry.drawMenuButton(this.saveButton, opacity);
            this.animationRegistry.drawToggle(
                    this.swingPreviewBounds,
                    "Auto-Swing Right Hand",
                    this.swingPreviewEnabled,
                    "editor:autoswing",
                    opacity);
            this.swingSettingsPanel.render(this.animationRegistry, opacity);
            this.shaderSettingsPanel.render(this.animationRegistry, opacity);
        }
    }

    public ItemStack getPreviewItem(Arm arm) {
        return arm == Arm.RIGHT ? RIGHT_PREVIEW_ITEM : LEFT_PREVIEW_ITEM;
    }

    private Arm nearestHandAt(float mouseX, float mouseY) {
        Arm armx = this.handAt(mouseX, mouseY);
        if (armx == null && mouseY >= this.screenHeight * 0.32F) {
            armx = mouseX < this.screenWidth / 2.0F ? Arm.LEFT : Arm.RIGHT;
        }

        return armx;
    }

    public void updateProjectedBounds(Arm arm, MatrixStack matrixstack) {
        if (this.active && matrixstack != null) {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (minecraftclient != null
                    && minecraftclient.gameRenderer != null
                    && minecraftclient.getWindow() != null) {
                Matrix4f matrix4f = new Matrix4f(matrixstack.peek().getPositionMatrix());
                Matrix4f matrix4f1 = new Matrix4f(RenderSystem.getModelViewMatrix());
                Matrix4f matrix4f2 = minecraftclient.gameRenderer.getBasicProjectionMatrix(70.0F);
                float f = (float) minecraftclient.getWindow().getFramebufferWidth() / 2.0F;
                float f1 = (float) minecraftclient.getWindow().getFramebufferHeight() / 2.0F;
                float POSITIVE_INFINITY = Float.POSITIVE_INFINITY;
                float POSITIVE_INFINITYValue = Float.POSITIVE_INFINITY;
                float NEGATIVE_INFINITY = Float.NEGATIVE_INFINITY;
                float NEGATIVE_INFINITYValue = Float.NEGATIVE_INFINITY;
                int i = 0;
                Vector4f vector4f = new Vector4f();

                for (float[] afloat : HAND_BOX_CORNERS) {
                    vector4f.set(afloat[0], afloat[1], afloat[2], 1.0F);
                    vector4f.mul(matrix4f);
                    vector4f.mul(matrix4f1);
                    vector4f.mul(matrix4f2);
                    if (!(vector4f.w() <= 0.001F) && Float.isFinite(vector4f.w())) {
                        float f6 = vector4f.x() / vector4f.w();
                        float f7 = vector4f.y() / vector4f.w();
                        if (Float.isFinite(f6) && Float.isFinite(f7)) {
                            float f8 = (f6 * 0.5F + 0.5F) * f;
                            float f9 = (0.5F - f7 * 0.5F) * f1;
                            POSITIVE_INFINITY = Math.min(POSITIVE_INFINITY, f8);
                            POSITIVE_INFINITYValue = Math.min(POSITIVE_INFINITYValue, f9);
                            NEGATIVE_INFINITY = Math.max(NEGATIVE_INFINITY, f8);
                            NEGATIVE_INFINITYValue = Math.max(NEGATIVE_INFINITYValue, f9);
                            i++;
                        }
                    }
                }

                if (i >= 2) {
                    float centerXValue = (POSITIVE_INFINITY + NEGATIVE_INFINITY) / 2.0F;
                    float centerYValue = (POSITIVE_INFINITYValue + NEGATIVE_INFINITYValue) / 2.0F;
                    float widthValue =
                            MathHelper.clamp(
                                    NEGATIVE_INFINITY - POSITIVE_INFINITY + 34.0F, 76.0F, 260.0F);
                    float heightValue =
                            MathHelper.clamp(
                                    NEGATIVE_INFINITYValue - POSITIVE_INFINITYValue + 42.0F,
                                    90.0F,
                                    280.0F);
                    if (Float.isFinite(centerXValue) && Float.isFinite(centerYValue)) {
                        this.getProjectedBounds(arm)
                                .update(centerXValue, centerYValue, widthValue, heightValue);
                    }
                }
            }
        }
    }

    private float clampSettingValue(float value, SliderSetting sliderSetting2) {
        return MathHelper.clamp(
                MathUtils.quantize(value, sliderSetting2.step),
                sliderSetting2.minValue,
                sliderSetting2.maxValue);
    }

    @Override
    public boolean mouseClicked(float mouseX, float mouseY, int dragButtonValue) {

        if (!this.active) {
            return false;
        } else if (dragButtonValue != 0 && dragButtonValue != 1
                || !this.shaderSettingsPanel.mouseClicked(mouseX, mouseY, dragButtonValue)
                        && !this.swingSettingsPanel.mouseClicked(mouseX, mouseY, dragButtonValue)) {
            if (dragButtonValue == 0) {
                if (this.swingPreviewBounds.contains(mouseX, mouseY)) {
                    if (!this.swingPreviewEnabled) {
                        this.swingPreviewEnabled = true;
                    } else {
                        this.swingPreviewEnabled = false;
                    }

                    this.nextSwingMillis = 0L;
                    return true;
                } else {
                    HandsModule handsModule = HandsModule.getInstance();
                    if (this.saveButton.contains(mouseX, mouseY)) {
                        this.saveButton.animateClick();
                        this.saveAndClose();
                    } else if (handsModule != null
                            && this.foldHandsButton.contains(mouseX, mouseY)) {
                        this.foldHandsButton.animateClick();
                        handsModule.resetHands();
                    } else if (handsModule != null
                            && this.resetLeftButton.contains(mouseX, mouseY)) {
                        this.resetLeftButton.animateClick();
                        handsModule.resetLeftHand();
                    } else if (handsModule != null
                            && this.resetRightButton.contains(mouseX, mouseY)) {
                        this.resetRightButton.animateClick();
                        handsModule.resetRightHand();
                    } else {
                        Arm armValue = this.nearestHandAt(mouseX, mouseY);
                        if (armValue != null) {
                            this.beginDrag(armValue, mouseX, mouseY, dragButtonValue);
                        }
                    }

                    return true;
                }
            } else if (dragButtonValue != 1) {
                return true;
            } else if (this.isOverControls(mouseX, mouseY)) {
                return true;
            } else {
                Arm armx = this.nearestHandAt(mouseX, mouseY);
                if (armx != null) {
                    this.beginDrag(armx, mouseX, mouseY, dragButtonValue);
                }

                return true;
            }
        } else {
            return true;
        }
    }

    @Override
    public boolean mouseScrolled(float mouseX, float mouseY, double d0) {
        if (!this.active) {
            return false;
        } else if (this.shaderSettingsPanel.mouseScrolled(mouseX, mouseY, d0)
                || this.swingSettingsPanel.mouseScrolled(mouseX, mouseY, d0)) {
            return true;
        } else if (this.swingPreviewBounds.contains(mouseX, mouseY)) {
            return true;
        } else {
            Arm armx = this.handAt(mouseX, mouseY);
            HandsModule handsModule = HandsModule.getInstance();
            if (armx != null && handsModule != null && d0 != 0.0) {
                SliderSetting sliderSetting2 =
                        armx == Arm.RIGHT
                                ? handsModule.rightScaleSetting
                                : handsModule.leftScaleSetting;
                float f2 = d0 > 0.0 ? 1.0F : -1.0F;
                float f3 = sliderSetting2.getFloat();
                float object =
                        this.clampSettingValue(f3 + f2 * sliderSetting2.step, sliderSetting2);
                if (Math.abs(object - f3) < 1.0E-4F) {
                    return true;
                } else {
                    Rectangle rectangleValue = this.getProjectedBounds(armx).getRecentRectangle();
                    Rectangle rectangle =
                            rectangleValue != null ? rectangleValue : this.getHandRectangle(armx);
                    float f5 = object / f3;
                    float f6 = (1.0F - f5) * (mouseX - rectangle.centerX());
                    float f7 = (1.0F - f5) * (mouseY - rectangle.centerY());
                    SliderSetting sliderSetting3 =
                            armx == Arm.RIGHT
                                    ? handsModule.rightXSetting
                                    : handsModule.leftXSetting;
                    SliderSetting sliderSetting4 =
                            armx == Arm.RIGHT
                                    ? handsModule.rightYSetting
                                    : handsModule.leftYSetting;
                    float pixelsPerUnit = this.getPixelsPerUnit();
                    sliderSetting3.setValue(
                            MathHelper.clamp(
                                    sliderSetting3.getFloat() + f6 / pixelsPerUnit,
                                    sliderSetting3.minValue,
                                    sliderSetting3.maxValue));
                    sliderSetting4.setValue(
                            MathHelper.clamp(
                                    sliderSetting4.getFloat() - f7 / pixelsPerUnit,
                                    sliderSetting4.minValue,
                                    sliderSetting4.maxValue));
                    sliderSetting2.setValue(object);
                    return true;
                }
            } else {
                return true;
            }
        }
    }

    private HandEditor() {
        this.rightHandBounds = new HandEditor.HandBounds();
        this.overlayOpacityAnimation = new EasingAnimation();
        this.leftArmHoverAnimation = new EasingAnimation();
        this.rightArmHoverAnimation = new EasingAnimation();
        this.saveButton = new MenuButton("Exit and save", true);
        this.foldHandsButton = new MenuButton("Fold both hands", false);
        this.resetLeftButton = new MenuButton("Reset left", false);
        this.resetRightButton = new MenuButton("Reset right", false);
        this.dragButton = -1;
        this.swingPreviewBounds = Rectangle.EMPTY;
        this.animationRegistry = new AnimationRegistry();
        this.swingSettingsPanel = new ModuleSettingsPanel();
        this.shaderSettingsPanel = new ModuleSettingsPanel();
    }

    private void updateSwingPreview() {
        if (this.swingPreviewEnabled) {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (minecraftclient != null
                    && minecraftclient.player != null
                    && !minecraftclient.player.handSwinging) {
                long nowMillis = System.currentTimeMillis();
                if (nowMillis >= this.nextSwingMillis) {
                    Hand hand =
                            minecraftclient.player.getMainArm() == Arm.RIGHT
                                    ? Hand.MAIN_HAND
                                    : Hand.OFF_HAND;
                    minecraftclient.player.swingHand(hand, false);
                    this.nextSwingMillis = nowMillis + 500L;
                }
            }
        }
    }

    private HandEditor.HandBounds getProjectedBounds(Arm arm) {
        return arm == Arm.RIGHT ? this.rightHandBounds : this.leftHandBounds;
    }

    private void animateVisibility(EasingAnimation easingAnimation2, boolean flag) {
        easingAnimation2.update();
        easingAnimation2.animateTo(flag ? 1.0 : 0.0, 0.18F, Easings.OUT_QUAD, true);
    }

    @Override
    public boolean mouseReleased(int i) {
        if (!this.active) {
            return false;
        } else {
            if (i == 0) {
                this.swingSettingsPanel.stopDragging();
                this.shaderSettingsPanel.stopDragging();
            }

            if (i == this.dragButton) {
                this.draggedArm = null;
                this.dragButton = -1;
            }

            return true;
        }
    }

    @Environment(EnvType.CLIENT)
    private static final class HandBounds {
        private float width;
        private float height;
        private float centerX;
        private float centerY;
        private long updatedAtMillis;

        void update(float centerXValue, float centerYValue, float widthValue, float heightValue) {
            this.centerX = centerXValue;
            this.centerY = centerYValue;
            this.width = widthValue;
            this.height = heightValue;
            this.updatedAtMillis = System.currentTimeMillis();
        }

        Rectangle getRecentRectangle() {
            boolean flag;
            flag =
                    (this.updatedAtMillis > 0L
                            && System.currentTimeMillis() - this.updatedAtMillis <= 250L);

            return flag
                    ? new Rectangle(
                            this.centerX - this.width / 2.0F,
                            this.centerY - this.height / 2.0F,
                            this.width,
                            this.height)
                    : null;
        }
    }
}
