package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@ModuleInfo(
        name = "Auto Potion",
        desc = "Automatically throws selected splash potions when their effects are missing",
        category = ModuleCategory.OTHER)
@Environment(EnvType.CLIENT)
public class AutoPotionModule extends Module {
    public final SliderSetting throwDelaySetting;
    private final Stopwatch stopwatch;
    public final MultiBooleanSetting potionsSetting =
            new MultiBooleanSetting(
                    this,
                    "Potions",
                    new BooleanSetting[] {
                        new BooleanSetting("Strength", true),
                        new BooleanSetting("Speed", true),
                        new BooleanSetting("Fire Resistance", true)
                    });

    private int previousSlot;

    public AutoPotionModule() {
        this.throwDelaySetting =
                new SliderSetting(this, "Throw Delay", 500.0F, 100.0F, 2000.0F, 50.0F);
        this.stopwatch = new Stopwatch();
        this.previousSlot = -1;
    }

    private String getEffectName(RegistryEntry<StatusEffect> registryentry) {
        if (registryentry.value() == StatusEffects.STRENGTH.value()) {
            return "Strength";
        } else if (registryentry.value() == StatusEffects.SPEED.value()) {
            return "Speed";
        } else {
            return registryentry.value() == StatusEffects.FIRE_RESISTANCE.value()
                    ? "Fire resistance"
                    : null;
        }
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (client.player != null
                && client.world != null
                && client.interactionManager != null
                && client.player.networkHandler != null) {
            if (client.currentScreen == null && !client.player.isUsingItem()) {
                List list = this.findPotionSlots();
                if (list.isEmpty()) {
                    this.restoreSelectedSlot();
                } else {
                    TargetRingRenderer.aim(
                            new Rotation(client.player.getYaw(), 90.0F), 180.0F, 180.0F, 2);
                    if (!(client.player.getPitch() < 88.0F)) {
                        if (this.stopwatch.hasElapsed(
                                (long) this.throwDelaySetting.getFloat().floatValue())) {
                            this.previousSlot = client.player.getInventory().getSelectedSlot();

                            for (int i : (Iterable<Integer>) (Iterable) list) {
                                client.player.getInventory().setSelectedSlot(i);
                                client.player.networkHandler.sendPacket(
                                        new UpdateSelectedSlotC2SPacket(i));
                                client.interactionManager.interactItem(
                                        client.player, Hand.MAIN_HAND);
                                client.player.swingHand(Hand.MAIN_HAND);
                            }

                            this.restoreSelectedSlot();
                            this.stopwatch.reset();
                        }
                    }
                }
            }
        }
    }

    private void restoreSelectedSlot() {
        if (this.previousSlot != -1 && client.player != null) {
            client.player.getInventory().setSelectedSlot(this.previousSlot);
            if (client.player.networkHandler != null) {
                client.player.networkHandler.sendPacket(
                        new UpdateSelectedSlotC2SPacket(this.previousSlot));
            }

            this.previousSlot = -1;
        }
    }

    private List<String> getMissingEffects(ItemStack itemstack) {
        ArrayList arraylist = new ArrayList();
        PotionContentsComponent potioncontentscomponent =
                itemstack.get(DataComponentTypes.POTION_CONTENTS);
        if (potioncontentscomponent == null) {
            return arraylist;
        } else {
            for (StatusEffectInstance statuseffectinstance : potioncontentscomponent.getEffects()) {
                RegistryEntry registryentry = statuseffectinstance.getEffectType();
                String string = this.getEffectName(registryentry);
                if (string != null
                        && this.potionsSetting.isOn(string)
                        && !client.player.hasStatusEffect(registryentry)) {
                    arraylist.add(string);
                }
            }

            return arraylist;
        }
    }

    @Override
    protected void onDisable() {
        this.restoreSelectedSlot();
    }

    private List<Integer> findPotionSlots() {
        ArrayList arraylist = new ArrayList();
        HashSet hashset = new HashSet();

        for (int i = 0; i <= 8; i++) {
            ItemStack itemstack = client.player.getInventory().getStack(i);
            if (itemstack.getItem() == Items.SPLASH_POTION) {
                List list = this.getMissingEffects(itemstack);
                if (!list.isEmpty()) {
                    boolean flag = false;

                    for (String text : (Iterable<String>) (Iterable) list) {
                        if (!hashset.contains(text)) {
                            flag = true;
                            break;
                        }
                    }

                    if (flag) {
                        arraylist.add(i);
                        hashset.addAll(list);
                    }
                }
            }
        }

        return arraylist;
    }
}
