package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Sprint",
        desc = "Automatically sprints while you move",
        category = ModuleCategory.OTHER)
@Environment(EnvType.CLIENT)
public class SprintModule extends Module {
    public int sprintSuppressionTicks;

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.sprintSuppressionTicks += 4;
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (client.player != null && client.world != null) {
            if (!client.player.isAlive()) {
                this.sprintSuppressionTicks += 2;
            }

            if (this.sprintSuppressionTicks != 0) {
                client.player.setSprinting(false);
                client.options.sprintKey.setPressed(false);
                this.sprintSuppressionTicks--;
            } else if (CombatUtils.shouldResetSprint(
                            AttackAuraModule.target,
                            AttackAuraModule.getInstance().getAttackRanges())
                    && AttackAuraModule.getInstance().isEnabled()
                    && AttackAuraModule.getInstance().sprintModeSetting.isSelected("Silent")) {
                client.options.sprintKey.setPressed(false);
            } else if (CombatUtils.shouldResetSprint(
                            AttackAuraModule.target,
                            AttackAuraModule.getInstance().getAttackRanges())
                    && AttackAuraModule.getInstance().isEnabled()
                    && AttackAuraModule.getInstance().sprintModeSetting.isSelected("Packet")) {
                client.player.setSprinting(false);
                client.options.sprintKey.setPressed(false);
            } else {
                boolean flag = client.player.horizontalCollision && !client.player.collidedSoftly;
                boolean flag1 = client.player.isSneaking() && !client.player.isSwimming();
                if (!flag && client.player.forwardSpeed > 0.0F) {}

                if (!flag1) {
                    client.options.sprintKey.setPressed(true);
                }
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (client.player != null) {
            client.player.setSprinting(false);
        }
    }
}
