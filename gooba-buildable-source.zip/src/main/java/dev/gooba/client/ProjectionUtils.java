package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4d;
import org.joml.Vector4f;

@Environment(EnvType.CLIENT)
public final class ProjectionUtils implements MinecraftAccess {

    public static Vector4d projectEntityBounds(Entity entity, float f) {
        if (entity == null) {
            return null;
        } else {
            Camera camera = client.getEntityRenderDispatcher().camera;
            if (camera == null) {
                return null;
            } else {
                Vec3d vec3d = camera.getCameraPos();
                Vec3d vec3d1 = entity.getLerpedPos(f);
                Vec3d vec3d2 = entity.getEntityPos();
                Box box = entity.getBoundingBox().offset(vec3d1.subtract(vec3d2));
                Vec3d vec3d3 = box.getCenter();
                double d0 = viewDepth(vec3d3, vec3d);
                if (d0 < -5.0) {
                    return null;
                } else {
                    int framebufferHeight = client.getWindow().getFramebufferHeight();
                    int[] aint =
                            new int[] {
                                0, 0, client.getWindow().getFramebufferWidth(), framebufferHeight
                            };
                    double d1 = 2.0;
                    double d2 = (double) client.getWindow().getFramebufferWidth() / 2.0;
                    double d3 = (double) client.getWindow().getFramebufferHeight() / 2.0;
                    Vec3d[] avec3d =
                            new Vec3d[] {
                                new Vec3d(box.minX, box.minY, box.minZ),
                                new Vec3d(box.minX, box.minY, box.maxZ),
                                new Vec3d(box.maxX, box.minY, box.minZ),
                                new Vec3d(box.maxX, box.minY, box.maxZ),
                                new Vec3d(box.minX, box.maxY, box.minZ),
                                new Vec3d(box.minX, box.maxY, box.maxZ),
                                new Vec3d(box.maxX, box.maxY, box.minZ),
                                new Vec3d(box.maxX, box.maxY, box.maxZ)
                            };
                    int[][] valuesArray =
                            new int[][] {
                                {0, 1}, {0, 2}, {1, 3}, {2, 3}, {4, 5}, {4, 6}, {5, 7}, {6, 7},
                                {0, 4}, {1, 5}, {2, 6}, {3, 7}
                            };
                    ProjectionUtils.ClipResult[] clipResults = new ProjectionUtils.ClipResult[8];

                    for (int j = 0; j < 8; j++) {
                        clipResults[j] = worldToClip(avec3d[j], vec3d);
                        if (clipResults[j] == null) {
                            return null;
                        }
                    }

                    double MAX_VALUE = Double.MAX_VALUE;
                    double MAX_VALUEValue = Double.MAX_VALUE;
                    double d5 = -Double.MAX_VALUE;
                    double d6 = -Double.MAX_VALUE;
                    int k = 0;

                    for (int l = 0; l < 8; l++) {
                        ProjectionUtils.ClipResult clipResultValue = clipResults[l];
                        if (clipResultValue.viewZ > 0.05) {
                            k++;
                            Vec3d vec3d4 =
                                    clipToScreen(clipResultValue, aint, framebufferHeight, d1);
                            double d7 = clampHorizontal(vec3d4.x, d2);
                            double d8 = clampVertical(vec3d4.y, d3);
                            MAX_VALUE = Math.min(MAX_VALUE, d7);
                            MAX_VALUEValue = Math.min(MAX_VALUEValue, d8);
                            d5 = Math.max(d5, d7);
                            d6 = Math.max(d6, d8);
                        }
                    }

                    for (int[] values : valuesArray) {
                        ProjectionUtils.ClipResult clipResult2 = clipResults[values[0]];
                        ProjectionUtils.ClipResult clipResult3 = clipResults[values[1]];
                        boolean flag;
                        flag = (clipResult2.viewZ > 0.05);

                        boolean flag1;
                        flag1 = (clipResult3.viewZ > 0.05);

                        if (flag != flag1) {
                            double d9 = clipResult3.viewZ - clipResult2.viewZ;
                            if (!(Math.abs(d9) < 1.0E-14)) {
                                double d10 = (0.05 - clipResult2.viewZ) / d9;
                                d10 = Math.max(0.0, Math.min(1.0, d10));
                                ProjectionUtils.ClipResult clipResult =
                                        new ProjectionUtils.ClipResult(
                                                clipResult2.x
                                                        + d10 * (clipResult3.x - clipResult2.x),
                                                clipResult2.y
                                                        + d10 * (clipResult3.y - clipResult2.y),
                                                clipResult2.z
                                                        + d10 * (clipResult3.z - clipResult2.z),
                                                clipResult2.w
                                                        + d10 * (clipResult3.w - clipResult2.w),
                                                0.05);
                                Vec3d vec3d5 =
                                        clipToScreen(clipResult, aint, framebufferHeight, d1);
                                double d11 = clampHorizontal(vec3d5.x, d2);
                                double d12 = clampVertical(vec3d5.y, d3);
                                MAX_VALUE = Math.min(MAX_VALUE, d11);
                                MAX_VALUEValue = Math.min(MAX_VALUEValue, d12);
                                d5 = Math.max(d5, d11);
                                d6 = Math.max(d6, d12);
                            }
                        }
                    }

                    if (k == 0 && MAX_VALUE == Double.MAX_VALUE) {
                        return null;
                    } else if (!(d5 <= MAX_VALUE) && !(d6 <= MAX_VALUEValue)) {
                        MAX_VALUE = Math.max(-d2, MAX_VALUE);
                        MAX_VALUEValue = Math.max(-d3, MAX_VALUEValue);
                        d5 = Math.min(d2 * 2.0, d5);
                        d6 = Math.min(d3 * 2.0, d6);
                        return new Vector4d(MAX_VALUE, MAX_VALUEValue, d5, d6);
                    } else {
                        return null;
                    }
                }
            }
        }
    }

    private static double clampHorizontal(double d0, double d1) {
        return Math.max(-d1 * 2.0, Math.min(d1 * 3.0, d0));
    }

    private ProjectionUtils() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    private static double viewDepth(Vec3d vec3d, Vec3d vec3d1) {
        double d0 = vec3d.x - vec3d1.x;
        double d1 = vec3d.y - vec3d1.y;
        double d2 = vec3d.z - vec3d1.z;
        Matrix4d matrix4d = toDoubleMatrix(RenderUtils.Render3D.positionMatrix);
        Vector4d vector4d = new Vector4d(d0, d1, d2, 1.0);
        matrix4d.transform(vector4d);
        return -vector4d.z;
    }

    public static boolean isInFrontOfCamera(Vec3d vec3d) {
        Camera camera = client.gameRenderer.getCamera();
        return camera != null && camera.isReady()
                ? isInFrontOfCamera(vec3d, camera.getCameraPos(), camera)
                : false;
    }

    private static Vec3d clipToScreen(
            ProjectionUtils.ClipResult clipResult, int[] aint, int i, double d0) {
        double d1 = clipResult.w;
        if (Math.abs(d1) < 1.0E-14) {
            return new Vec3d((double) aint[2] / d0 / 2.0, (double) i / d0 / 2.0, 0.0);
        } else {
            double d2 = 1.0 / d1;
            double d3 = clipResult.x * d2;
            double d4 = clipResult.y * d2;
            double d5 = clipResult.z * d2;
            double d6 = (d3 * 0.5 + 0.5) * (double) aint[2] / d0;
            double d7 = ((double) i - (d4 * 0.5 + 0.5) * (double) aint[3]) / d0;
            double d8 = d5 * 0.5 + 0.5;
            return new Vec3d(d6, d7, d1 > 0.0 ? d8 : -1.0);
        }
    }

    private static Matrix4d toDoubleMatrix(Matrix4f matrix4f) {
        Matrix4d matrix4d = new Matrix4d();
        matrix4d.m00((double) matrix4f.m00())
                .m01((double) matrix4f.m01())
                .m02((double) matrix4f.m02())
                .m03((double) matrix4f.m03());
        matrix4d.m10((double) matrix4f.m10())
                .m11((double) matrix4f.m11())
                .m12((double) matrix4f.m12())
                .m13((double) matrix4f.m13());
        matrix4d.m20((double) matrix4f.m20())
                .m21((double) matrix4f.m21())
                .m22((double) matrix4f.m22())
                .m23((double) matrix4f.m23());
        matrix4d.m30((double) matrix4f.m30())
                .m31((double) matrix4f.m31())
                .m32((double) matrix4f.m32())
                .m33((double) matrix4f.m33());
        return matrix4d;
    }

    public static Vec3d worldToScreen(Vec3d vec3d) {
        Camera camera = client.getEntityRenderDispatcher().camera;
        if (camera == null) {
            return Vec3d.ZERO;
        } else {
            int framebufferHeight = client.getWindow().getFramebufferHeight();
            int[] aint =
                    new int[] {0, 0, client.getWindow().getFramebufferWidth(), framebufferHeight};
            Vector3f vector3f = new Vector3f();
            double d0 = vec3d.x - camera.getCameraPos().x;
            double d1 = vec3d.y - camera.getCameraPos().y;
            double d2 = vec3d.z - camera.getCameraPos().z;
            Vector4f vector4f = new Vector4f((float) d0, (float) d1, (float) d2, 1.0F);
            vector4f.mul(RenderUtils.Render3D.positionMatrix);
            Matrix4f matrix4f = new Matrix4f(RenderUtils.Render3D.projectionMatrix);
            Matrix4f matrix4f1 = new Matrix4f(RenderUtils.Render3D.modelViewMatrix);
            matrix4f.mul(matrix4f1)
                    .project(vector4f.x(), vector4f.y(), vector4f.z(), aint, vector3f);
            return new Vec3d(
                    (double) vector3f.x / 2.0,
                    (double) ((float) framebufferHeight - vector3f.y) / 2.0,
                    (double) vector3f.z);
        }
    }

    public static boolean isOutsideScreen(Vector4d vector4d) {
        if (vector4d == null) {
            return true;
        } else {
            double d0 = (double) client.getWindow().getFramebufferWidth() / 2.0;
            double d1 = (double) client.getWindow().getFramebufferHeight() / 2.0;
            if (Double.isNaN(vector4d.x)
                    || Double.isNaN(vector4d.y)
                    || Double.isNaN(vector4d.z)
                    || Double.isNaN(vector4d.w)) {
                return true;
            } else if (Double.isInfinite(vector4d.x)
                    || Double.isInfinite(vector4d.y)
                    || Double.isInfinite(vector4d.z)
                    || Double.isInfinite(vector4d.w)) {
                return true;
            } else {
                return vector4d.z < -d0 || vector4d.x > d0 * 2.0
                        ? true
                        : vector4d.w < -d1 || vector4d.y > d1 * 2.0;
            }
        }
    }

    private static double clampVertical(double d0, double d1) {
        return Math.max(-d1 * 2.0, Math.min(d1 * 3.0, d0));
    }

    private static boolean isInFrontOfCamera(Vec3d vec3d, Vec3d vec3d1, Camera camera) {
        double d0 = vec3d.x - vec3d1.x;
        double d1 = vec3d.y - vec3d1.y;
        double d2 = vec3d.z - vec3d1.z;
        double yaw = (double) camera.getYaw();
        double pitch = (double) camera.getPitch();
        double d5 = Math.toRadians(yaw);
        double d6 = Math.toRadians(pitch);
        double d7 = Math.cos(d6);
        double d8 = -Math.sin(d5) * d7;
        double d9 = -Math.sin(d6);
        double d10 = Math.cos(d5) * d7;
        double d11 = d8 * d0 + d9 * d1 + d10 * d2;
        return d11 > -10.0;
    }

    private static ProjectionUtils.ClipResult worldToClip(Vec3d vec3d, Vec3d vec3d1) {
        double d0 = vec3d.x - vec3d1.x;
        double d1 = vec3d.y - vec3d1.y;
        double d2 = vec3d.z - vec3d1.z;
        Matrix4d matrix4d = toDoubleMatrix(RenderUtils.Render3D.positionMatrix);
        Vector4d vector4d = new Vector4d(d0, d1, d2, 1.0);
        matrix4d.transform(vector4d);
        Matrix4d matrix4d1 = toDoubleMatrix(RenderUtils.Render3D.projectionMatrix);
        Matrix4d matrix4d2 = toDoubleMatrix(RenderUtils.Render3D.modelViewMatrix);
        Matrix4d matrix4d3 = new Matrix4d(matrix4d1).mul(matrix4d2);
        double d3 =
                matrix4d3.m00() * vector4d.x
                        + matrix4d3.m10() * vector4d.y
                        + matrix4d3.m20() * vector4d.z
                        + matrix4d3.m30() * vector4d.w;
        double d4 =
                matrix4d3.m01() * vector4d.x
                        + matrix4d3.m11() * vector4d.y
                        + matrix4d3.m21() * vector4d.z
                        + matrix4d3.m31() * vector4d.w;
        double d5 =
                matrix4d3.m02() * vector4d.x
                        + matrix4d3.m12() * vector4d.y
                        + matrix4d3.m22() * vector4d.z
                        + matrix4d3.m32() * vector4d.w;
        double d6 =
                matrix4d3.m03() * vector4d.x
                        + matrix4d3.m13() * vector4d.y
                        + matrix4d3.m23() * vector4d.z
                        + matrix4d3.m33() * vector4d.w;
        return new ProjectionUtils.ClipResult(d3, d4, d5, d6, -vector4d.z);
    }

    @Environment(EnvType.CLIENT)
    private static record ClipResult(double x, double y, double z, double w, double viewZ) {}
}
