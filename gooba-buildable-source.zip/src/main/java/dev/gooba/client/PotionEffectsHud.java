package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.util.Identifier;

import org.joml.Matrix3x2fStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class PotionEffectsHud implements MinecraftAccess {
    private final EasingAnimation visibilityAnimation = createAnimation(0.0F);
    private final Map<String, PotionEffectsHud.EffectData> effects;
    private final EasingAnimation heightAnimation;
    private final EasingAnimation widthAnimation = new EasingAnimation().resetValue(0.0F);

    private static String romanNumeral(int i) {
        return switch (Math.min(i, 10)) {
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> Integer.toString(i);
        };
    }

    private static EasingAnimation createAnimation(float f) {
        return new EasingAnimation()
                .setCurrentValue((double) f)
                .setStartValue((double) f)
                .setTargetValue((double) f)
                .setDurationMillis(1.0);
    }

    private static float centerTextY(float f, float height, float size) {
        return Fonts.INTER_SEMIBOLD.centerTextY("Ag09:", f, height, size) + 0.45F * size / 7.2F;
    }

    public void render(
            PositionSetting positionSetting2, HUDModule hUDModule, Render2DEvent render2DEvent) {
        if (client.player != null) {
            float f = hUDModule.hudSizeSetting.getFloat();
            float innerX = positionSetting2.position.x;
            float innerY = positionSetting2.position.y;
            this.effects.values().forEach(cxe$effectdata3 -> cxe$effectdata3.active = false);

            for (StatusEffectInstance statuseffectinstance : client.player.getStatusEffects()) {
                String string = statuseffectinstance.getEffectType().value().getName().getString();
                PotionEffectsHud.EffectData effectDataValue =
                        this.effects.computeIfAbsent(
                                string,
                                text -> new PotionEffectsHud.EffectData(statuseffectinstance));
                effectDataValue.effect = statuseffectinstance;
                effectDataValue.name = effectName(statuseffectinstance);
                effectDataValue.amplifierLabel = amplifierLabel(statuseffectinstance);
                effectDataValue.durationLabel = formatDuration(statuseffectinstance);
                if (!statuseffectinstance.isInfinite()) {
                    effectDataValue.maximumDuration =
                            Math.max(
                                    effectDataValue.maximumDuration,
                                    statuseffectinstance.getDuration());
                }

                effectDataValue.active = true;
            }

            ArrayList<PotionEffectsHud.EffectData> arraylist =
                    new ArrayList<>(this.effects.values());
            arraylist.sort(
                    Comparator.comparing(
                            cxe$effectdata3 -> cxe$effectdata3.name,
                            String.CASE_INSENSITIVE_ORDER));
            float f37 = 0.0F;
            float f38 =
                    16.0F
                            + Fonts.INTER_SEMIBOLD.measureWidth("  ", 7.5F)
                            + Fonts.INTER_SEMIBOLD.measureVisibleWidth("Potions", 7.5F);
            float f39 = 0.0F;
            boolean flag = false;

            for (PotionEffectsHud.EffectData effectData3 :
                    (Iterable<PotionEffectsHud.EffectData>) (Iterable) arraylist) {
                float f3 =
                        effectData3.visibilityAnimation.approach(
                                effectData3.active ? 1.0F : 0.0F, 2.5F);
                if (effectData3.active) {
                    flag = true;
                }

                if (effectData3.active || !(f3 <= 0.001F)) {
                    f37 += 14.0F * f3;
                    String stringValue = displayName(effectData3);
                    float f4 = Fonts.INTER_SEMIBOLD.measureVisibleWidth(stringValue, 7.2F);
                    float f5 =
                            Fonts.INTER_SEMIBOLD.measureVisibleWidth(
                                    effectData3.durationLabel, 7.2F);
                    float f6 =
                            22.0F
                                    + f4
                                    + 0.5F
                                    + 8.0F
                                    + f5
                                    + Fonts.INTER_SEMIBOLD.measureWidth("  ", 7.2F)
                                    + 6.0F;
                    f39 = Math.max(f39, f6);
                }
            }

            float target = Math.max(f38, f39);
            float targetValue = 15.0F + f37;
            boolean flag2;
            flag2 =
                    !(!hUDModule.alwaysShowSetting.isOn()
                            && !flag
                            && !(f37 > 0.001F)
                            && !(client.currentScreen instanceof ChatScreen));

            if (flag2 && this.visibilityAnimation.getFloatValue() <= 0.001F) {
                this.widthAnimation.resetValue(target);
                this.heightAnimation.resetValue(targetValue);
            }

            float factor = animate(this.visibilityAnimation, flag2 ? 1.0F : 0.0F);
            if (!flag2 && !(factor > 0.01F)) {
                positionSetting2.visible = false;
            } else {
                positionSetting2.visible = true;
            }

            if (factor <= 0.01F) {
                this.removeExpiredEffects();
                positionSetting2.size.set(f38 * f, 15.0F * f);
            } else {
                float f43 = this.widthAnimation.approach(target, 2.5F) * f;
                float f44 = this.heightAnimation.approach(targetValue, 2.5F) * f;
                float height = 15.0F * f;
                float f7 = 4.0F * f;
                String string2 = "P";
                float size = 7.5F * f;
                float f9 = Fonts.INTER_SEMIBOLD.measureWidth("  ", 7.5F * f);
                float width7 =
                        16.0F * f
                                + f9
                                + Fonts.INTER_SEMIBOLD.measureVisibleWidth("Potions", 7.5F * f);
                hUDModule.drawBackground(innerX, innerY, width7, height, f7, factor);
                float f11 = innerX + 4.0F * f;
                Font font = Fonts.GOOBA_ICONS;
                float f47 = Fonts.GOOBA_ICONS.centerTextX(string2, f11, 8.0F * f, size);
                float f48 = Fonts.GOOBA_ICONS.centerTextY(string2, innerY, height, size);
                hUDModule.getAccentColor(factor);
                font.drawText(string2, f47, f48, size);
                float f12 = f11 + 8.0F * f + f9;
                float width = Fonts.INTER_SEMIBOLD.measureVisibleWidth("Potions", 7.5F * f);
                float f14 = Fonts.INTER_SEMIBOLD.centerTextX("Potions", f12, width, 7.5F * f);
                float f15 = centerTextY(innerY, height, 7.5F * f);
                font = Fonts.INTER_SEMIBOLD;
                float sizeValue = 7.5F * f;
                ColorUtils.multiplyAlpha(-657931, factor);
                font.drawText("Potions", f14, f15, sizeValue);
                long nowMillis = System.currentTimeMillis();
                float f16 = (float) (nowMillis % 600L) / 300.0F;
                if (f16 > 1.0F) {
                    f16 = 2.0F - f16;
                }

                f16 = Math.max(0.5F, f16);
                float innerYValue = innerY + height;

                for (PotionEffectsHud.EffectData effectData4 :
                        (Iterable<PotionEffectsHud.EffectData>) (Iterable) arraylist) {
                    float floatValue = effectData4.visibilityAnimation.getFloatValue();
                    if (!(floatValue <= 0.001F)) {
                        float f19 = 13.5F * floatValue * f;
                        float f20 = factor * floatValue;
                        boolean flag1;
                        flag1 =
                                (!effectData4.effect.isInfinite()
                                        && effectData4.effect.getDuration() <= 120);

                        float factorValue = f20 * (flag1 ? f16 : 1.0F);
                        innerYValue += 0.5F * floatValue * f;
                        float f22 = (1.0F - floatValue) * 8.0F * f;
                        innerX += f22;
                        float f23 = innerYValue + 13.5F * f * 0.5F;
                        float width8 = 13.5F * f;
                        float innerXValue = innerX + width8 + 0.5F * f;
                        float size3 = 7.2F * f;
                        String string3 = displayName(effectData4);
                        float widthValue = Fonts.INTER_SEMIBOLD.measureVisibleWidth(string3, size3);
                        float width9 = 8.0F * f + widthValue;
                        float innerX2 = innerXValue + width9 + 0.5F * f;
                        float width11 =
                                Fonts.INTER_SEMIBOLD.measureVisibleWidth(
                                        effectData4.durationLabel, size3);
                        float f31 = Fonts.INTER_SEMIBOLD.measureWidth("  ", size3);
                        float width10 = 8.0F * f + width11 + f31 + 6.0F * f;
                        hUDModule.drawBackground(innerX, innerYValue, width8, 13.5F * f, f7, f20);
                        hUDModule.drawBackground(
                                innerXValue, innerYValue, width9, 13.5F * f, f7, f20);
                        hUDModule.drawBackground(innerX2, innerYValue, width10, 13.5F * f, f7, f20);
                        this.drawEffectIcon(
                                render2DEvent,
                                effectData4.effect,
                                innerX + (width8 - 8.0F * f) * 0.5F,
                                f23 - 4.0F * f,
                                8.0F * f,
                                factorValue);
                        float f33 = centerTextY(innerYValue, 13.5F * f, size3);
                        float f34 =
                                Fonts.INTER_SEMIBOLD.centerTextX(
                                        string3, innerXValue + 4.0F * f, widthValue, size3);
                        font = Fonts.INTER_SEMIBOLD;
                        String name = effectData4.name;
                        ColorUtils.multiplyAlpha(-657931, factorValue);
                        font.drawText(name, f34, f33, size3);
                        if (!effectData4.amplifierLabel.isEmpty()) {
                            String textValue = effectData4.name;
                            float f35 =
                                    f34 + Fonts.INTER_SEMIBOLD.measureWidth(textValue + " ", size3);
                            font = Fonts.INTER_SEMIBOLD;
                            name = effectData4.amplifierLabel;
                            hUDModule.getAccentColor(factorValue);
                            font.drawText(name, f35, f33, size3);
                        }

                        float centerX = innerX2 + width10 - 7.0F * f;
                        float f36 =
                                Fonts.INTER_SEMIBOLD.centerTextX(
                                        effectData4.durationLabel,
                                        innerX2 + 4.0F * f,
                                        width11,
                                        size3);
                        font = Fonts.INTER_SEMIBOLD;
                        name = effectData4.durationLabel;
                        ColorUtils.multiplyAlpha(-657931, factorValue);
                        font.drawText(name, f36, f33, size3);
                        Gooba.getInstance()
                                .getHudManager()
                                .getCircleData()
                                .drawProgressArc(
                                        centerX,
                                        f23 - 0.3F * f,
                                        3.0F * f,
                                        1.0F * f,
                                        1.0F,
                                        ColorUtils.multiplyAlpha(-13092808, factorValue));
                        Gooba.getInstance()
                                .getHudManager()
                                .getCircleData()
                                .drawProgressArc(
                                        centerX,
                                        f23 - 0.3F * f,
                                        3.0F * f,
                                        1.0F * f,
                                        remainingFraction(effectData4),
                                        hUDModule.getAccentColor(factorValue));
                        innerX -= f22;
                        innerYValue += f19;
                    }
                }

                this.removeExpiredEffects();
                positionSetting2.size.set(f43, f44);
            }
        }
    }

    private static String formatDuration(StatusEffectInstance statuseffectinstance) {
        if (statuseffectinstance.isInfinite()) {
            return "13:37";
        } else {
            int i = Math.max(0, statuseffectinstance.getDuration() / 20);
            return String.format(Locale.ROOT, "%d:%02d", i / 60, i % 60);
        }
    }

    private static float remainingFraction(PotionEffectsHud.EffectData effectData) {
        return !effectData.effect.isInfinite() && effectData.maximumDuration > 0
                ? Math.max(
                        0.0F,
                        Math.min(
                                1.0F,
                                (float) effectData.effect.getDuration()
                                        / (float) effectData.maximumDuration))
                : 1.0F;
    }

    private void drawEffectIcon(
            Render2DEvent render2DEvent,
            StatusEffectInstance statuseffectinstance,
            float f,
            float f1,
            float f2,
            float opacity) {
        Identifier identifier = InGameHud.getEffectTexture(statuseffectinstance.getEffectType());
        Matrix3x2fStack matrix3x2fstack = render2DEvent.getDrawContext().getMatrices();
        matrix3x2fstack.pushMatrix();
        matrix3x2fstack.translate(f, f1);
        matrix3x2fstack.scale(f2 / 12.0F, f2 / 12.0F);
        render2DEvent
                .getDrawContext()
                .drawGuiTexture(
                        RenderPipelines.GUI_TEXTURED,
                        identifier,
                        0,
                        0,
                        12,
                        12,
                        ColorUtils.grayscaleOpacity(255, opacity));
        matrix3x2fstack.popMatrix();
    }

    public PotionEffectsHud() {
        this.heightAnimation = new EasingAnimation().resetValue(15.0F);
        this.effects = new LinkedHashMap<>();
    }

    private static String displayName(PotionEffectsHud.EffectData effectData) {
        String text;
        if (effectData.amplifierLabel.isEmpty()) {
            text = effectData.name;
        } else {
            String string = effectData.amplifierLabel;
            String textValue = effectData.name;
            text = textValue + " " + string;
        }

        return text;
    }

    private void removeExpiredEffects() {
        this.effects
                .entrySet()
                .removeIf(
                        entry ->
                                !entry.getValue().active
                                        && entry.getValue().visibilityAnimation.getFloatValue()
                                                <= 0.001F);
    }

    private static float animate(EasingAnimation easingAnimation2, float f) {
        easingAnimation2.animateTo((double) f, 0.3F, Easings.OUT_EXPO, true);
        easingAnimation2.update();
        return easingAnimation2.getFloatValue();
    }

    private static String amplifierLabel(StatusEffectInstance statuseffectinstance) {
        int i = statuseffectinstance.getAmplifier() + 1;
        return i <= 1 ? "" : romanNumeral(i);
    }

    private static String effectName(StatusEffectInstance statuseffectinstance) {
        return statuseffectinstance.getEffectType().value().getName().getString();
    }

    @Environment(EnvType.CLIENT)
    private static class EffectData {
        private String amplifierLabel;
        private final EasingAnimation visibilityAnimation = new EasingAnimation().resetValue(0.0F);
        private StatusEffectInstance effect;
        private int maximumDuration;
        private boolean active;
        private String durationLabel;
        private String name;

        private EffectData(StatusEffectInstance statuseffectinstance) {
            this.effect = statuseffectinstance;
            this.name = PotionEffectsHud.effectName(statuseffectinstance);
            this.amplifierLabel = PotionEffectsHud.amplifierLabel(statuseffectinstance);
            this.durationLabel = PotionEffectsHud.formatDuration(statuseffectinstance);
            if (statuseffectinstance.isInfinite()) {
                this.maximumDuration = 0;
            } else {
                this.maximumDuration = statuseffectinstance.getDuration();
            }
        }
    }
}
