package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class GrimRotationMode implements RotationModeHandler {
    private float pitchSpeed;
    private float yawSpeed = 34.0F;

    public GrimRotationMode() {
        this.pitchSpeed = 12.0F;
    }

    @Override
    public void updateRotation(
            AttackAuraModule attackAuraModule,
            LivingEntity livingentity,
            float[] afloat,
            boolean flag) {
        if (client.player != null && livingentity != null) {
            Vec3d vec3d =
                    RaycastUtils.findAimPoint(livingentity.getBoundingBox())
                            .subtract(client.player.getEyePos())
                            .normalize();
            float f = (float) Math.toDegrees(Math.atan2(-vec3d.x, vec3d.z));
            float f1 =
                    (float)
                            MathHelper.clamp(
                                    -Math.toDegrees(
                                            Math.atan2(vec3d.y, Math.hypot(vec3d.x, vec3d.z))),
                                    -90.0,
                                    90.0);
            float f2 = MathUtils.secureRandomFloat(50.0F, 80.0F);
            float f3 = MathUtils.secureRandomFloat(7.0F, 12.0F);
            if (EntityRaycast.intersectsTarget(
                    client.player.getYaw(),
                    client.player.getPitch(),
                    (double) attackAuraModule.attackRangeSetting.getFloat().floatValue(),
                    livingentity)) {
                f2 = MathUtils.secureRandomFloat(3.0F, 4.0F);
                f3 = MathUtils.secureRandomFloat(1.0F, 2.0F);
            }

            float f4 = 0.3F;
            this.yawSpeed = this.yawSpeed + (f2 - this.yawSpeed) * f4;
            this.pitchSpeed = this.pitchSpeed + (f3 - this.pitchSpeed) * f4;
            TargetRingRenderer.aim(
                    new Rotation(f, f1),
                    this.yawSpeed,
                    this.pitchSpeed,
                    MathUtils.randomInterpolated(360.0, 390.0),
                    MathUtils.randomInterpolated(360.0, 390.0),
                    (int) MathUtils.randomInterpolated(3.0, 5.0),
                    1,
                    false);
        }
    }
}
