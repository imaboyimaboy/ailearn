package dev.gooba.client;

import com.mojang.blaze3d.shaders.ShaderType;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Environment(EnvType.CLIENT)
public final class ShaderSourceProvider {

    private static String loadResourceSource(Identifier identifier) {
        MinecraftClient minecraftclient;
        try {
            minecraftclient = MinecraftClient.getInstance();
        } catch (Exception exceptionValue) {
            return null;
        }

        try {
            if (minecraftclient == null) {
                return null;
            } else {
                ResourceManager resourcemanager = minecraftclient.getResourceManager();
                if (resourcemanager == null) {
                    return null;
                } else {
                    Optional optional = resourcemanager.getResource(identifier);
                    if (optional.isEmpty()) {
                        return null;
                    } else {
                        String text;
                        try (InputStream inputstream =
                                ((Resource) optional.get()).getInputStream()) {
                            text = new String(inputstream.readAllBytes(), StandardCharsets.UTF_8);
                        }

                        return text;
                    }
                }
            }
        } catch (Exception exception) {
            return null;
        }
    }

    private static String resolveImports(String text, Identifier identifier, Set<String> set) {
        StringBuilder stringbuilder = new StringBuilder(text.length() + 256);

        for (String textValue : text.split("\n", -1)) {
            String text2 = textValue.trim();
            if (text2.startsWith("#moj_import")) {
                Identifier identifierValue = parseImportIdentifier(text2, identifier);
                if (identifierValue != null) {
                    if (set.add(identifierValue.toString())) {
                        String text3 = loadResourceSource(identifierValue);
                        if (text3 != null) {
                            stringbuilder.append(resolveImports(text3, identifierValue, set));
                            if (stringbuilder.length() > 0
                                    && stringbuilder.charAt(stringbuilder.length() - 1) != '\n') {
                                stringbuilder.append('\n');
                            }
                        }
                    }
                    continue;
                }
            }

            stringbuilder.append(textValue).append('\n');
        }

        return stringbuilder.toString();
    }

    private static String removeDuplicateVersions(String text) {
        StringBuilder stringbuilder = new StringBuilder(text.length());
        boolean flag = false;

        for (String textValue : text.split("\n", -1)) {
            if (textValue.trim().startsWith("#version")) {
                if (flag) {
                    continue;
                }

                flag = true;
            }

            stringbuilder.append(textValue).append('\n');
        }

        return stringbuilder.toString();
    }

    private static String loadBundledShader(String resourcePath) {
        try (InputStream input = ShaderSourceProvider.class.getResourceAsStream(resourcePath)) {
            if (input == null) {
                throw new IllegalStateException("Missing shader resource: " + resourcePath);
            }
            return new String(input.readAllBytes(), StandardCharsets.UTF_8);
        } catch (java.io.IOException exception) {
            throw new java.io.UncheckedIOException(exception);
        }
    }

    private ShaderSourceProvider() {}

    public static String loadShader(Identifier identifier, ShaderType shadertype) {
        if (identifier != null && "client".equals(identifier.getNamespace())) {
            String text;
            String textValue;
            if (shadertype == ShaderType.VERTEX) {
                text = "vsh";
                String path = identifier.getPath();
                textValue = path + "|" + text;
            } else {
                text = "fsh";
                String pathValue = identifier.getPath();
                textValue = pathValue + "|" + text;
            }

            if ("core/blur|vsh".equals(textValue)) {
                return loadBundledShader(ShaderCatalog.RESOURCES.get(textValue));
            } else if ("core/blur|fsh".equals(textValue)) {
                return loadBundledShader(ShaderCatalog.RESOURCES.get(textValue));
            } else if ("core/rect_onetap|fsh".equals(textValue)) {
                return loadBundledShader(ShaderCatalog.RESOURCES.get(textValue));
            } else if ("core/texture_onetap|fsh".equals(textValue)) {
                return loadBundledShader(ShaderCatalog.RESOURCES.get(textValue));
            } else if ("core/texture_antialiased|fsh".equals(textValue)) {
                return loadBundledShader(ShaderCatalog.RESOURCES.get(textValue));
            } else {
                String resourcePath = ShaderCatalog.RESOURCES.get(textValue);
                if (resourcePath == null) {
                    return null;
                } else {
                    String text2 = loadBundledShader(resourcePath);
                    String path2 = identifier.getPath();
                    Identifier identifierValue =
                            Identifier.of(
                                    identifier.getNamespace(), "shaders/" + path2 + "." + text);
                    String text3 = resolveImports(text2, identifierValue, new HashSet<>());
                    return removeDuplicateVersions(text3);
                }
            }
        } else {
            return null;
        }
    }

    private static Identifier parseImportIdentifier(String text, Identifier identifier) {
        int i = text.indexOf(60);
        int j = text.indexOf(62);
        if (i >= 0 && j > i) {
            String textValue = text.substring(i + 1, j).trim();
            Identifier identifierValue = Identifier.of(textValue);
            String path = identifierValue.getPath();
            return Identifier.of(identifierValue.getNamespace(), "shaders/include/" + path);
        } else {
            int k = text.indexOf(34);
            int l = text.lastIndexOf(34);
            if (k >= 0 && l > k) {
                String text2 = text.substring(k + 1, l).trim();
                String pathValue = identifier.getPath();
                int i1 = pathValue.lastIndexOf(47);
                if (i1 >= 0) {
                    String text3 = pathValue.substring(0, i1 + 1);
                    return Identifier.of(identifier.getNamespace(), text3 + text2);
                } else {
                    String text4 = "";
                    return Identifier.of(identifier.getNamespace(), text4 + text2);
                }
            } else {
                return null;
            }
        }
    }
}
