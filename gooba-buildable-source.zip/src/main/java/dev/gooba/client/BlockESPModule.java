package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

@ModuleInfo(
        name = "Block ESP",
        category = ModuleCategory.RENDER,
        desc = "Highlights selected blocks through walls")
@Environment(EnvType.CLIENT)
public class BlockESPModule extends Module {
    private final List<BlockPos> positions;
    public final SliderSetting espAlphaSetting;
    private int scanTicks;
    private static BlockESPModule instance;
    public final StringListSetting blockListSetting = new StringListSetting(this, "Block List");
    public final SliderSetting tracersAlphaSetting;
    public final BooleanSetting belowY0Setting = new BooleanSetting(this, "Below Y=0", false);
    public final BooleanSetting tracersSetting = new BooleanSetting(this, "Tracers", true);

    @Override
    protected void onDisable() {
        this.positions.clear();
        this.scanTicks = 0;
    }

    public BlockESPModule() {
        this.tracersAlphaSetting =
                new SliderSetting(this, "Tracers Alpha", 255.0F, 0.0F, 255.0F, 1.0F);
        this.espAlphaSetting = new SliderSetting(this, "ESP Alpha", 70.0F, 0.0F, 255.0F, 1.0F);
        this.positions = new CopyOnWriteArrayList<>();
        instance = this;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.world != null && client.player != null) {
            Set set = this.selectedBlocks();
            if (set.isEmpty()) {
                this.positions.clear();
            } else if (++this.scanTicks >= 10) {
                this.scanTicks = 0;
                List listx =
                        ChunkBlockScanner.findBlocks(
                                Integer.MAX_VALUE,
                                blockstate ->
                                        !blockstate.isAir() && set.contains(blockstate.getBlock()));
                this.positions.clear();
                this.positions.addAll(listx);
            }
        } else {
            this.positions.clear();
        }
    }

    public Set<Block> selectedBlocks() {
        return new HashSet<>(this.blockListSetting.getSelectedBlocks());
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.world != null && client.player != null && !this.positions.isEmpty()) {
            int i = Math.max(0, Math.min(255, Math.round(this.espAlphaSetting.getFloat())));
            int j = Math.max(0, Math.min(255, Math.round(this.tracersAlphaSetting.getFloat())));
            WorldEspRenderer.clear();

            for (BlockPos blockpos : this.positions) {
                if (!this.belowY0Setting.isOn() || blockpos.getY() < 0) {
                    String text =
                            Registries.BLOCK
                                    .getId(client.world.getBlockState(blockpos).getBlock())
                                    .toString();
                    int blockColor = this.blockListSetting.getBlockColor(text);
                    int l = blockColor & 16777215;
                    float f = (float) (blockColor >>> 24) / 255.0F;
                    WorldEspRenderer.enqueueBox(
                            new Box(
                                    (double) blockpos.getX() + 0.1,
                                    (double) blockpos.getY() + 0.05,
                                    (double) blockpos.getZ() + 0.1,
                                    (double) blockpos.getX() + 0.9,
                                    (double) blockpos.getY() + 0.85,
                                    (double) blockpos.getZ() + 0.9),
                            Math.round((float) i * f) << 24 | l,
                            Math.round((float) j * f),
                            this.tracersSetting.isOn());
                }
            }

            WorldEspRenderer.flush(render3DEvent.getMatrixStack());
        }
    }
}
