package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class NeuroRotationMode implements RotationModeHandler {
    private float previousPitchDelta;
    private float previousPitch;
    private float targetX = 0.5F;
    private int ticksSinceAttack;
    private boolean initialized;
    private float stability;
    private float targetY = 0.5F;
    private float previousYawDelta;

    private float targetZ = 0.5F;
    private float previousYaw;
    private float aggression;

    public NeuroRotationMode() {
        this.stability = 1.0F;
        this.aggression = 0.0F;
        this.ticksSinceAttack = 999;
    }

    @Override
    public void updateRotation(
            AttackAuraModule attackAuraModule,
            LivingEntity livingentity,
            float[] afloat,
            boolean flag) {
        CombatUtils.canAttack(livingentity, false, true, true, -100L, afloat);
        float cameraYaw = Rotation.getCameraYaw();
        float cameraPitch = Rotation.getCameraPitch();
        if (!this.initialized) {
            this.previousYaw = cameraYaw;
            this.previousPitch = cameraPitch;
            this.initialized = true;
        }

        float previousYawDeltaValue = MathHelper.wrapDegrees(cameraYaw - this.previousYaw);
        float previousPitchDeltaValue = cameraPitch - this.previousPitch;
        Vec3d vec3d = livingentity.getBoundingBox().getCenter().subtract(client.player.getEyePos());
        float f4 = yawTo(vec3d);
        float f5 = pitchTo(vec3d);
        float f6 = MathHelper.wrapDegrees(f4 - cameraYaw);
        float f7 = f5 - cameraPitch;
        float f8 =
                (float)
                        client.player
                                .getEyePos()
                                .distanceTo(livingentity.getBoundingBox().getCenter());
        if (attackAuraModule.attackOccurred) {
            attackAuraModule.attackOccurred = false;
            this.ticksSinceAttack = 0;
        } else {
            this.ticksSinceAttack = Math.min(this.ticksSinceAttack + 1, 999);
        }

        float[] values =
                RotationTrainer.getInstance()
                        .sampleTrajectory(f6, f7, (float) Math.min(this.ticksSinceAttack, 60));
        if (values != null) {
            float f25 = cameraYaw + values[0];
            float f26 = MathHelper.clamp(cameraPitch + values[1], -90.0F, 90.0F);
            TargetRingRenderer.aim(
                    new Rotation(f25, f26),
                    Math.max(Math.abs(values[0]), 1.0F),
                    Math.max(Math.abs(values[1]), 1.0F),
                    (float) MathUtils.randomIntInclusive(900, 1424),
                    (float) MathUtils.randomIntInclusive(900, 1424),
                    MathUtils.randomIntInclusive(3, 5),
                    15,
                    false);
            this.previousYawDelta = previousYawDeltaValue;
            this.previousPitchDelta = previousPitchDeltaValue;
            this.previousYaw = cameraYaw;
            this.previousPitch = cameraPitch;
        } else {
            double[] adouble =
                    RotationModelStore.encodeFeatures(
                            f6,
                            f7,
                            previousYawDeltaValue,
                            previousPitchDeltaValue,
                            this.previousYawDelta,
                            this.previousPitchDelta,
                            this.targetX,
                            this.targetY,
                            this.targetZ,
                            f8,
                            this.stability,
                            this.aggression);
            RotationModelStore.Prediction prediction =
                    RotationTrainer.getInstance().predict(adouble);
            this.targetX = prediction.targetX;
            this.targetY = prediction.targetY;
            this.targetZ = prediction.targetZ;
            this.stability = prediction.stability;
            this.aggression = prediction.aggression;
            Vec3d vec3d1 = this.predictedAimPoint(livingentity.getBoundingBox(), prediction);
            Vec3d vec3d2 = vec3d1.subtract(client.player.getEyePos());
            float f9 = yawTo(vec3d2);
            float f10 = pitchTo(vec3d2);
            float f11 = MathHelper.wrapDegrees(f9 - cameraYaw);
            float f12 = f10 - cameraPitch;
            float f13 = (float) Math.hypot((double) f11, (double) f12);
            float f14 = MathHelper.clamp(1.0F - f13 / 35.0F, 0.15F, 1.0F);
            float f15 = 1.0F + (1.0F - prediction.stability) * 0.9F;
            float f16 =
                    (prediction.yawOffset
                                    + prediction.yawVelocity * 0.16F
                                    + prediction.yawAcceleration * 0.05F)
                            * f14
                            * f15;
            float f17 =
                    (prediction.pitchOffset
                                    + prediction.pitchVelocity * 0.16F
                                    + prediction.pitchAcceleration * 0.05F)
                            * f14
                            * f15;
            float[] valuesValue =
                    RotationTrainer.getInstance()
                            .sampleStroke(
                                    (float)
                                            Math.hypot(
                                                    (double) previousYawDeltaValue,
                                                    (double) previousPitchDeltaValue));
            float f18 = MathHelper.clamp(valuesValue[0], -8.0F, 8.0F);
            float f19 = MathHelper.clamp(valuesValue[1], -5.0F, 5.0F);
            float f20 = f9 + f16 + f18;
            float f21 = MathHelper.clamp(f10 + f17 + f19, -90.0F, 90.0F);
            MathHelper.wrapDegrees(f20 - cameraYaw);
            float f22 = prediction.aggression * 18.0F;
            float aimYawSpeedValue =
                    MathHelper.clamp(
                            Math.max(prediction.maxYawSpeed, Math.abs(f11) * 0.6F) + f22,
                            0.0F,
                            80.0F);
            float aimPitchSpeedValue =
                    MathHelper.clamp(
                            Math.max(prediction.maxPitchSpeed, Math.abs(f12) * 0.03F) + f22 * 0.4F,
                            0.0F,
                            11.0F);
            TargetRingRenderer.aim(
                    new Rotation(f20, f21),
                    aimYawSpeedValue,
                    aimPitchSpeedValue,
                    (float) MathUtils.randomIntInclusive(900, 1424),
                    (float) MathUtils.randomIntInclusive(900, 1424),
                    MathUtils.randomIntInclusive(3, 5),
                    15,
                    false);
            this.previousYawDelta = previousYawDeltaValue;
            this.previousPitchDelta = previousPitchDeltaValue;
            this.previousYaw = cameraYaw;
            this.previousPitch = cameraPitch;
        }
    }

    private Vec3d predictedAimPoint(Box box, RotationModelStore.Prediction prediction) {
        return new Vec3d(
                MathHelper.lerp((double) prediction.targetX, box.minX, box.maxX),
                MathHelper.lerp((double) prediction.targetY, box.minY, box.maxY),
                MathHelper.lerp((double) prediction.targetZ, box.minZ, box.maxZ));
    }

    private static float pitchTo(Vec3d vec3d) {
        return (float)
                MathHelper.clamp(
                        -Math.toDegrees(Math.atan2(vec3d.y, Math.hypot(vec3d.x, vec3d.z))),
                        -90.0,
                        90.0);
    }

    private static float yawTo(Vec3d vec3d) {
        return (float) Math.toDegrees(Math.atan2(-vec3d.x, vec3d.z));
    }
}
