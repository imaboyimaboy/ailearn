package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.regex.Pattern;

@Environment(EnvType.CLIENT)
public class TextRenderEvent extends Event {
    private String text;

    public void replaceRegex(String textValue, String text2) {
        if (this.text != null && !this.text.isEmpty()) {
            this.text = this.text.replaceAll(textValue, text2);
        }
    }

    public void setText(String textValue) {
        this.text = textValue;
    }

    public void replaceText(String textValue, String text2) {
        if (this.text != null
                && !this.text.isEmpty()
                && textValue != null
                && !textValue.isEmpty()) {
            if (this.text.toLowerCase().contains(textValue.toLowerCase())) {
                this.text = this.text.replaceAll("(?ui)" + Pattern.quote(textValue), text2);
            }
        }
    }

    public TextRenderEvent(String textValue) {
        this.text = textValue;
    }

    public String getText() {
        return this.text;
    }
}
