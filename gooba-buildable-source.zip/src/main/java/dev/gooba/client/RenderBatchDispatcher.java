package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.OptionalDouble;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public final class RenderBatchDispatcher {
    private static final Vector3f zeroOffset = new Vector3f(0.0F, 0.0F, 0.0F);
    private static final Matrix4f identityMatrix = new Matrix4f();
    private static boolean batching = false;
    private static final Vector4f whiteColor = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
    private static final ArrayList<RenderBatchDispatcher.Batched> pendingBatches =
            new ArrayList<>(8);

    public static void setBatching(boolean batchingValue) {
        if (!batchingValue) {
            flush();
        }

        RenderBatchDispatcher.batching = batchingValue;
    }

    private RenderBatchDispatcher() {}

    public static void enqueue(RenderBatchDispatcher.Batched batched) {
        if (!pendingBatches.contains(batched)) {
            pendingBatches.add(batched);
        }
    }

    private static GpuBufferSlice writeTransforms() {
        return RenderSystem.getDynamicUniforms()
                .write(RenderSystem.getModelViewMatrix(), whiteColor, zeroOffset, identityMatrix);
    }

    public static void flush() {
        if (pendingBatches.isEmpty()) {
            return;
        }

        RenderBatchDispatcher.Batched[] batches =
                pendingBatches.toArray(new RenderBatchDispatcher.Batched[0]);
        pendingBatches.clear();
        java.util.Arrays.sort(
                batches,
                java.util.Comparator.comparingInt(RenderBatchDispatcher.Batched::getSortOrder));
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.getFramebuffer() == null) {
            for (RenderBatchDispatcher.Batched batch : batches) {
                batch.clear();
            }
            return;
        }

        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        for (RenderBatchDispatcher.Batched batch : batches) {
            batch.prepare(encoder);
        }
        GpuBufferSlice transforms = writeTransforms();
        try (RenderPass pass =
                encoder.createRenderPass(
                        () -> "client:2d_batch",
                        client.getFramebuffer().getColorAttachmentView(),
                        OptionalInt.empty(),
                        client.getFramebuffer().getDepthAttachmentView(),
                        OptionalDouble.empty())) {
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", transforms);
            for (RenderBatchDispatcher.Batched batch : batches) {
                batch.render(pass);
            }
        } finally {
            for (RenderBatchDispatcher.Batched batch : batches) {
                batch.clear();
            }
        }
    }

    public static void renderImmediately(RenderBatchDispatcher.Batched batched, boolean flag) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient != null && minecraftclient.getFramebuffer() != null) {
            CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
            if (flag) {
                batched.prepare(commandencoder);
            }

            GpuBufferSlice gpubufferslice = writeTransforms();

            try (RenderPass renderpass =
                    commandencoder.createRenderPass(
                            () -> "client:2d_immediate",
                            minecraftclient.getFramebuffer().getColorAttachmentView(),
                            OptionalInt.empty(),
                            minecraftclient.getFramebuffer().getDepthAttachmentView(),
                            OptionalDouble.empty())) {
                RenderSystem.bindDefaultUniforms(renderpass);
                renderpass.setUniform("DynamicTransforms", gpubufferslice);
                batched.render(renderpass);
            } finally {
                batched.clear();
            }
        } else {
            batched.clear();
        }
    }

    public static void renderImmediately(RenderBatchDispatcher.Batched batched) {
        renderImmediately(batched, true);
    }

    public static boolean isBatching() {
        return batching;
    }

    @Environment(EnvType.CLIENT)
    public interface Batched {
        void clear();

        void render(RenderPass renderpass);

        void prepare(CommandEncoder commandencoder);

        default int getSortOrder() {
            return 0;
        }
    }
}
