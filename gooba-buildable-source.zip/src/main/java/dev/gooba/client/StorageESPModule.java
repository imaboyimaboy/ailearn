package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

@ModuleInfo(
        name = "Storage ESP",
        category = ModuleCategory.RENDER,
        desc = "Highlights selected storage and utility blocks")
@Environment(EnvType.CLIENT)
public class StorageESPModule extends Module {
    public final SliderSetting tracersAlphaSetting;
    private int scanTicks;
    private ExecutorService scanExecutor;
    private final AtomicBoolean scanning;
    public final BooleanSetting belowY0Setting;
    private static final List<String> DEFAULT_BLOCK_IDS =
            List.of(
                    "minecraft:chest",
                    "minecraft:trapped_chest",
                    "minecraft:ender_chest",
                    "minecraft:shulker_box",
                    "minecraft:barrel",
                    "minecraft:hopper",
                    "minecraft:dropper",
                    "minecraft:dispenser",
                    "minecraft:smoker",
                    "minecraft:enchanting_table",
                    "minecraft:crafter",
                    "minecraft:spawner",
                    "minecraft:detector_rail",
                    "minecraft:powered_rail",
                    "minecraft:activator_rail",
                    "minecraft:ancient_debris",
                    "minecraft:observer",
                    "minecraft:redstone_wire",
                    "minecraft:redstone_block",
                    "minecraft:netherite_block",
                    "minecraft:note_block",
                    "minecraft:redstone_lamp",
                    "minecraft:gilded_blackstone",
                    "minecraft:redstone_torch",
                    "minecraft:redstone_wall_torch",
                    "minecraft:repeater",
                    "minecraft:comparator",
                    "minecraft:iron_door",
                    "minecraft:piston",
                    "minecraft:sticky_piston");
    public final BooleanSetting tracersSetting;
    private final List<StorageESPModule.FoundBlock> foundBlocks;
    public final SliderSetting espAlphaSetting;
    public final StringListSetting blockListSetting =
            new StringListSetting(this, "Block List", DEFAULT_BLOCK_IDS, DEFAULT_BLOCK_IDS);

    private void queueScan() {
        if (this.scanExecutor != null
                && !this.scanExecutor.isShutdown()
                && client.world != null
                && client.player != null) {
            if (this.scanning.compareAndSet(false, true)) {
                HashMap hashmap = new HashMap();

                for (String text : this.blockListSetting.getSelectedIds()) {
                    Identifier identifier = Identifier.tryParse(text);
                    if (identifier != null) {
                        Registries.BLOCK
                                .getOptionalValue(identifier)
                                .ifPresent(block -> hashmap.put(block, text));
                    }
                }

                boolean flag =
                        this.blockListSetting.getSelectedIds().contains("minecraft:shulker_box");
                boolean isOn = this.belowY0Setting.isOn();
                int value = client.options.getViewDistance().getValue();
                ChunkPos chunkpos = client.player.getChunkPos();
                this.scanExecutor.submit(
                        () -> {
                            try {
                                this.scanBlocks(hashmap, flag, isOn, value, chunkpos);
                            } finally {
                                this.scanning.set(false);
                            }
                        });
            }
        }
    }

    private void scanBlocks(
            Map<Block, String> map, boolean flag, boolean flag1, int i, ChunkPos chunkpos) {
        if (client.world != null) {
            ArrayList arraylist = new ArrayList();

            for (int j = chunkpos.x - i; j <= chunkpos.x + i; j++) {
                for (int k = chunkpos.z - i; k <= chunkpos.z + i; k++) {
                    if (client.world == null) {
                        return;
                    }

                    WorldChunk worldchunk =
                            client.world.getChunkManager().getWorldChunk(j, k, false);
                    if (worldchunk != null && !worldchunk.isEmpty()) {
                        int l = j << 4;
                        int i1 = k << 4;
                        int bottomY = worldchunk.getBottomY();
                        int k1 =
                                flag1
                                        ? Math.min(0, bottomY + worldchunk.getHeight())
                                        : bottomY + worldchunk.getHeight();
                        Mutable mutable = new Mutable();

                        for (int l1 = l; l1 < l + 16; l1++) {
                            for (int i2 = i1; i2 < i1 + 16; i2++) {
                                for (int bottomYValue = bottomY;
                                        bottomYValue < k1;
                                        bottomYValue++) {
                                    mutable.set(l1, bottomYValue, i2);
                                    BlockState blockstate = worldchunk.getBlockState(mutable);
                                    Block block = blockstate.getBlock();
                                    String text = (String) map.get(block);
                                    if (text == null && flag && block instanceof ShulkerBoxBlock) {
                                        text = "minecraft:shulker_box";
                                    }

                                    if (text != null) {
                                        arraylist.add(
                                                new StorageESPModule.FoundBlock(
                                                        mutable.toImmutable(), text));
                                    }
                                }
                            }
                        }
                    }
                }
            }

            this.foundBlocks.clear();
            this.foundBlocks.addAll(arraylist);
        }
    }

    public StorageESPModule() {
        this.belowY0Setting = new BooleanSetting(this, "Below Y=0", false);
        this.tracersSetting = new BooleanSetting(this, "Tracers", false);
        this.tracersAlphaSetting =
                new SliderSetting(this, "Tracers Alpha", 235.0F, 0.0F, 255.0F, 1.0F);
        this.espAlphaSetting = new SliderSetting(this, "ESP Alpha", 70.0F, 0.0F, 255.0F, 1.0F);
        this.foundBlocks = new CopyOnWriteArrayList<>();
        this.scanning = new AtomicBoolean(false);
    }

    @Override
    protected void onDisable() {
        this.foundBlocks.clear();
        if (this.scanExecutor != null) {
            this.scanExecutor.shutdownNow();

            try {
                this.scanExecutor.awaitTermination(1L, TimeUnit.SECONDS);
            } catch (InterruptedException interruptedexception) {
            }

            this.scanExecutor = null;
        }
    }

    @Override
    protected void onEnable() {
        this.foundBlocks.clear();
        this.scanTicks = 0;
        this.scanExecutor =
                Executors.newSingleThreadExecutor(
                        runnable -> {
                            Thread thread = new Thread(runnable, "Goobaa-StorageESP-Scanner");
                            thread.setDaemon(true);
                            return thread;
                        });
        this.queueScan();
    }

    private int blockColor(String text) {
        if (text.contains("shulker_box")) {
            return -5635926;
        } else if (text.endsWith(":chest")) {
            return -3636686;
        } else if (text.contains("trapped_chest")) {
            return -3636686;
        } else if (text.contains("ender_chest")) {
            return -9109249;
        } else if (text.contains("barrel")) {
            return -32126;
        } else if (text.contains("hopper")) {
            return -12156236;
        } else if (text.contains("smoker")) {
            return -16744448;
        } else if (text.contains("dropper")) {
            return -32106;
        } else if (text.contains("dispenser")) {
            return -16741226;
        } else if (text.contains("enchanting_table")) {
            return -16776961;
        } else if (text.contains("crafter")) {
            return -1;
        } else if (text.contains("spawner")) {
            return -65536;
        } else if (text.contains("detector_rail")) {
            return -1;
        } else if (text.contains("powered_rail")) {
            return -1;
        } else if (text.contains("activator_rail")) {
            return -1;
        } else if (text.contains("ancient_debris")) {
            return -65536;
        } else if (text.contains("observer")) {
            return -1;
        } else if (text.contains("redstone_wire")) {
            return -1;
        } else if (text.contains("redstone_block")) {
            return -1;
        } else if (text.contains("netherite_block")) {
            return -65536;
        } else if (text.contains("note_block")) {
            return -1;
        } else if (text.contains("redstone_lamp")) {
            return -1;
        } else if (text.contains("gilded_blackstone")) {
            return -65536;
        } else if (text.contains("redstone_torch") || text.contains("redstone_wall_torch")) {
            return -1;
        } else if (text.contains("repeater")) {
            return -1;
        } else if (text.contains("comparator")) {
            return -1;
        } else if (text.contains("iron_door")) {
            return -1;
        } else if (text.contains("sticky_piston")) {
            return -16744448;
        } else {
            return text.contains("piston")
                    ? -16711936
                    : StringListSetting.getDefaultBlockColor(text);
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.world != null && client.player != null && !this.foundBlocks.isEmpty()) {
            int i = Math.max(0, Math.min(255, Math.round(this.espAlphaSetting.getFloat())));
            int j = Math.max(0, Math.min(255, Math.round(this.tracersAlphaSetting.getFloat())));
            WorldEspRenderer.clear();

            for (StorageESPModule.FoundBlock foundBlock : this.foundBlocks) {
                BlockPos blockpos = foundBlock.pos;
                if (!this.belowY0Setting.isOn() || blockpos.getY() < 0) {
                    int k = this.blockColor(foundBlock.id) & 16777215;
                    WorldEspRenderer.enqueueBox(
                            new Box(
                                    (double) blockpos.getX() + 0.1,
                                    (double) blockpos.getY() + 0.05,
                                    (double) blockpos.getZ() + 0.1,
                                    (double) blockpos.getX() + 0.9,
                                    (double) blockpos.getY() + 0.85,
                                    (double) blockpos.getZ() + 0.9),
                            i << 24 | k,
                            j,
                            this.tracersSetting.isOn());
                }
            }

            WorldEspRenderer.flush(render3DEvent.getMatrixStack());
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.world != null && client.player != null) {
            if (++this.scanTicks >= 12) {
                this.scanTicks = 0;
                this.queueScan();
            }
        } else {
            this.foundBlocks.clear();
        }
    }

    @Environment(EnvType.CLIENT)
    private static record FoundBlock(BlockPos pos, String id) {}
}
