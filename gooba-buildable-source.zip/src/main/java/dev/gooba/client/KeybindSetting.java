package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class KeybindSetting extends Setting<Integer> {
    private Integer cachedKeyCode;

    public TimedAnimation timedAnimation = new DecelerateAnimation(300, 1.0);
    public final boolean flag = true;

    public KeybindSetting setValue(Integer integer) {
        this.cachedKeyCode = integer;
        return (KeybindSetting) super.setValue(integer);
    }

    public KeybindSetting(Module moduleValue, String nameValue, Integer integer) {
        super(moduleValue, nameValue, integer);
        this.cachedKeyCode = integer;
    }

    public Integer getKeyCode() {
        if (this.cachedKeyCode == null) {
            this.cachedKeyCode = (Integer) super.getValue();
        }

        return this.cachedKeyCode;
    }

    public KeybindSetting visibleWhen(Supplier supplier) {
        return (KeybindSetting) super.visibleWhen(supplier);
    }

    public KeybindSetting(Module moduleValue, String nameValue) {
        super(moduleValue, nameValue, -1);
        this.cachedKeyCode = -1;
    }

    public KeybindSetting(String nameValue, Integer integer) {
        super(nameValue, integer);
        this.cachedKeyCode = integer;
    }

    public KeybindSetting onChange(Runnable runnable) {
        return (KeybindSetting)
                super.onChange(
                        () -> {
                            runnable.run();
                            this.cachedKeyCode = (Integer) super.getValue();
                        });
    }

    public Integer getCachedKeyCode() {
        if (this.cachedKeyCode == null) {
            this.cachedKeyCode = (Integer) super.getValue();
        }

        return this.cachedKeyCode;
    }
}
