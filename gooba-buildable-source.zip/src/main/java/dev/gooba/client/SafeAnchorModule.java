package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

import org.lwjgl.glfw.GLFW;

@ModuleInfo(
        name = "Safe Anchor",
        desc = "Places anchors, charges them, places leg cover and detonates",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class SafeAnchorModule extends Module {
    private long lastSwitchMillis;

    private BlockHitResult placementHit;
    private Item shieldItem;
    private final KeybindSetting activationKeySetting =
            new KeybindSetting(this, "Activation Key", 1);
    private float serverYaw;
    private boolean rotating;
    private boolean active;
    private BlockPos anchorPosition;
    private boolean heightProtected;
    private final SliderSetting chargeDelaySetting;
    private boolean interactedThisTick;
    private static SafeAnchorModule instance;
    private long lastAnchorPlaceMillis;
    private float serverPitch;
    private boolean hasServerRotation;
    private int switchedSlot;
    private BlockHitResult anchorHit;
    private boolean activationQueued;
    private final SliderSetting delaySetting =
            new SliderSetting(this, "Delay", 0.0F, 0.0F, 500.0F, 5.0F);
    private long lastChargeMillis;
    private static final double[] FACE_SAMPLES = new double[] {0.5, 0.2, 0.8};
    private boolean activationConsumed;
    private final BooleanSetting autoExplodeSetting;
    private boolean shieldConfirmed;
    private long sequenceStartedAtMillis;
    private final SliderSetting rotationSetting;
    private boolean anchorConfirmed;
    private final SliderSetting switchSlotSetting;
    private long shieldPlacedAtMillis;
    private BlockPos shieldPosition;
    private BlockPos lastChargedPosition;
    private BlockHitResult queuedActivationHit;

    private void selectSlot(int switchedSlotValue, long lastSwitchMillisValue) {
        if (switchedSlotValue >= 0
                && switchedSlotValue <= 8
                && client.player.getInventory().getSelectedSlot() != switchedSlotValue) {
            client.player.getInventory().setSelectedSlot(switchedSlotValue);
            client.interactionManager.syncSelectedSlot();
            this.switchedSlot = switchedSlotValue;
            this.lastSwitchMillis = lastSwitchMillisValue;
        }
    }

    private void resetShieldBlock() {
        this.shieldPosition = null;
        this.shieldItem = null;
        this.shieldPlacedAtMillis = 0L;
        this.shieldConfirmed = false;
    }

    private BlockHitResult getCrosshairBlock() {
        if (client.crosshairTarget instanceof BlockHitResult blockhitresult
                && blockhitresult.getType() == Type.BLOCK
                && !blockhitresult.isInsideBlock()) {
            return blockhitresult;
        }

        return null;
    }

    private boolean isReplaceable(BlockPos blockpos, Item item) {
        ItemStack itemstack = this.findHotbarStack(item);
        if (itemstack.isEmpty()) {
            return false;
        } else {
            BlockHitResult blockhitresult =
                    new BlockHitResult(
                            blockpos.toCenterPos().add(0.0, 0.5, 0.0),
                            Direction.UP,
                            blockpos,
                            false);
            ItemPlacementContext itemplacementcontext =
                    new ItemPlacementContext(
                            client.player, Hand.MAIN_HAND, itemstack, blockhitresult);
            return client.world.getBlockState(blockpos).canReplace(itemplacementcontext);
        }
    }

    public static boolean shouldSuppressUse() {
        if (instance == null
                || !instance.isEnabled()
                || client.player == null
                || client.world == null
                || client.currentScreen != null) {
            return false;
        } else if (instance.active || instance.activationQueued) {
            return true;
        } else {
            return !instance.activationConsumed && instance.isActivationHeld()
                    ? instance.canStartAt(instance.getCrosshairBlock())
                    : false;
        }
    }

    private void chargeOrExplode(
            BlockHitResult blockhitresult, BlockState blockstate, long lastChargeMillisValue) {
        BlockPos blockpos = this.anchorPosition;
        if (blockstate.get(RespawnAnchorBlock.CHARGES) == 0) {
            if (!blockpos.equals(this.lastChargedPosition)
                    || lastChargeMillisValue - this.lastChargeMillis >= 500L) {
                if (lastChargeMillisValue - this.lastChargeMillis
                        >= (long) Math.round(this.chargeDelaySetting.getFloat())) {
                    if (this.selectItem(Items.GLOWSTONE, lastChargeMillisValue)) {
                        BlockHitResult blockhitresultValue = this.alignToHit(blockhitresult);
                        if (blockhitresultValue != null && this.interactOnce(blockhitresultValue)) {
                            this.lastChargedPosition = blockpos;
                            this.lastChargeMillis = lastChargeMillisValue;
                        }
                    }
                }
            }
        } else if (this.ensureShieldBlock(blockpos, lastChargeMillisValue)) {
            int switchedSlotValue = Math.round(this.switchSlotSetting.getFloat()) - 1;
            if (this.selectSlotAndWait(switchedSlotValue, lastChargeMillisValue)) {
                if (!this.autoExplodeSetting.isOn()) {
                    this.finishSequence();
                } else if (this.heightProtected
                        || this.shieldConfirmed
                                && this.isShieldConfirmed()
                                && this.blocksExplosion(blockpos, this.shieldPosition)) {
                    if (!client.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
                        BlockHitResult explosionHit = this.getExplosionHit(blockhitresult);
                        if (explosionHit != null && this.interactOnce(explosionHit)) {
                            this.finishSequence();
                        }
                    }
                }
            }
        }
    }

    private BlockHitResult raycast(Vec3d vec3d, Vec3d vec3d1) {
        return client.world.raycast(
                new RaycastContext(
                        vec3d, vec3d1, ShapeType.OUTLINE, FluidHandling.NONE, client.player));
    }

    @EventHandler
    public void onPreClientTick(PreClientTickEvent preClientTickEvent) {
        if (client.player != null
                && client.world != null
                && client.interactionManager != null
                && client.currentScreen == null) {
            this.interactedThisTick = false;
            boolean isActivationHeld = this.isActivationHeld();
            if (!isActivationHeld && !this.activationQueued) {
                this.activationConsumed = false;
            }

            if (!DoubleAnchorModule.isActive()) {
                long nowMillis = System.currentTimeMillis();
                if (!this.active) {
                    if (!this.activationQueued && isActivationHeld && !this.activationConsumed) {
                        this.queueActivation();
                    }

                    if (!this.activationQueued) {
                        return;
                    }

                    BlockHitResult blockhitresult = this.queuedActivationHit;
                    this.activationQueued = false;
                    this.queuedActivationHit = null;
                    if (!this.startSequence(blockhitresult, nowMillis)) {
                        return;
                    }
                }

                this.suppressUseInput();
                if (nowMillis - this.sequenceStartedAtMillis > 6000L) {
                    this.finishSequence();
                } else {
                    BlockState blockstate = client.world.getBlockState(this.anchorPosition);
                    if (blockstate.isOf(Blocks.RESPAWN_ANCHOR)) {
                        this.anchorConfirmed = true;
                        BlockHitResult blockHitResult2Value =
                                this.findAnchorHit(this.anchorPosition);
                        if (blockHitResult2Value != null) {
                            this.anchorHit = blockHitResult2Value;
                        }

                        if (this.anchorHit != null) {
                            this.chargeOrExplode(this.anchorHit, blockstate, nowMillis);
                        }
                    } else if (this.anchorConfirmed) {
                        this.finishSequence();
                    } else {
                        this.placeAnchor(nowMillis);
                    }
                }
            }
        } else {
            this.resetState();
        }
    }

    private boolean canPlaceAt(BlockHitResult blockhitresult, BlockPos blockpos, Item item) {
        if (blockhitresult != null
                && blockpos != null
                && blockhitresult.getType() == Type.BLOCK
                && !blockhitresult.isInsideBlock()) {
            ItemStack itemstack = this.findHotbarStack(item);
            if (itemstack.isEmpty()) {
                return false;
            } else {
                ItemPlacementContext itemplacementcontext =
                        new ItemPlacementContext(
                                client.player, Hand.MAIN_HAND, itemstack, blockhitresult);
                return itemplacementcontext.getBlockPos().equals(blockpos)
                        && itemplacementcontext.canPlace();
            }
        } else {
            return false;
        }
    }

    private boolean isActivationHeld() {
        int cachedKeyCode = this.activationKeySetting.getCachedKeyCode();
        if (cachedKeyCode < 0) {
            return false;
        } else {
            return cachedKeyCode <= 7
                    ? GLFW.glfwGetMouseButton(client.getWindow().getHandle(), cachedKeyCode) == 1
                    : InputUtil.isKeyPressed(client.getWindow(), cachedKeyCode);
        }
    }

    public SafeAnchorModule() {
        this.chargeDelaySetting = new SliderSetting(this, "Charge Delay", 0.0F, 0.0F, 500.0F, 5.0F);
        this.switchSlotSetting = new SliderSetting(this, "Switch Slot", 1.0F, 1.0F, 9.0F, 1.0F);
        this.rotationSetting = new SliderSetting(this, "Rotation", 0.0F, 0.0F, 1.0F, 0.05F);
        this.autoExplodeSetting = new BooleanSetting(this, "Auto Explode", true);
        this.switchedSlot = -1;
        instance = this;
    }

    private Rotation rotationTo(Vec3d vec3d) {
        Vec3d vec3d1 = vec3d.subtract(client.player.getEyePos());
        return new Rotation(
                (float) (Math.toDegrees(Math.atan2(vec3d1.z, vec3d1.x)) - 90.0),
                (float) (-Math.toDegrees(Math.atan2(vec3d1.y, Math.hypot(vec3d1.x, vec3d1.z)))));
    }

    private BlockHitResult findPlacementHit(BlockPos blockpos, Item item) {
        if (!this.isReplaceable(blockpos, item)) {
            return null;
        } else {
            for (Direction direction : Direction.values()) {
                BlockPos blockposValue = blockpos.offset(direction);
                BlockState blockstate = client.world.getBlockState(blockposValue);
                if (blockstate.isSolidBlock(client.world, blockposValue)
                        && !blockstate.hasBlockEntity()
                        && !blockstate.isOf(Blocks.RESPAWN_ANCHOR)
                        && !blockstate.isOf(Blocks.CRAFTING_TABLE)) {
                    BlockHitResult blockhitresult =
                            this.findVisibleFace(blockposValue, direction.getOpposite());
                    if (blockhitresult != null && this.canPlaceAt(blockhitresult, blockpos, item)) {
                        return blockhitresult;
                    }
                }
            }

            for (Direction directionValue : Direction.values()) {
                BlockHitResult blockhitresultValue = this.findVisibleFace(blockpos, directionValue);
                if (blockhitresultValue != null
                        && this.canPlaceAt(blockhitresultValue, blockpos, item)) {
                    return blockhitresultValue;
                }
            }

            return null;
        }
    }

    private boolean isSwitchDelayElapsed(long i) {
        int selectedSlot = client.player.getInventory().getSelectedSlot();
        return selectedSlot != this.switchedSlot
                || i - this.lastSwitchMillis >= (long) Math.round(this.delaySetting.getFloat());
    }

    private boolean canStartAt(BlockHitResult blockhitresult) {
        if (blockhitresult != null && this.isHoldingAnchor()) {
            if (client.world
                    .getBlockState(blockhitresult.getBlockPos())
                    .isOf(Blocks.RESPAWN_ANCHOR)) {
                return true;
            } else {
                ItemStack itemstack = client.player.getMainHandStack();
                if (!itemstack.isEmpty() && this.findHotbarItem(Items.GLOWSTONE) != -1) {
                    ItemPlacementContext itemplacementcontext =
                            new ItemPlacementContext(
                                    client.player, Hand.MAIN_HAND, itemstack, blockhitresult);
                    return itemplacementcontext.canPlace()
                            && this.isPlacementSpaceClear(itemplacementcontext.getBlockPos());
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
    }

    @Override
    protected void onEnable() {
        this.resetState();
        super.onEnable();
    }

    private ItemStack findHotbarStack(Item item) {
        if (item == null) {
            return ItemStack.EMPTY;
        } else {
            int i = this.findHotbarItem(item);
            return i == -1 ? ItemStack.EMPTY : client.player.getInventory().getStack(i);
        }
    }

    @EventHandler(priority = -500)
    public void onPacket(PacketEvent packetEvent) {
        if (!packetEvent.isCancelled()) {
            if (packetEvent.isSend()) {
                if (packetEvent.getPacket() instanceof PlayerMoveC2SPacket playermovec2spacket
                        && client.player != null
                        && playermovec2spacket.changesLook()) {
                    this.serverYaw = playermovec2spacket.getYaw(client.player.getYaw());
                    this.serverPitch = playermovec2spacket.getPitch(client.player.getPitch());
                    this.hasServerRotation = true;
                }
            } else {
                if (packetEvent.getPacket() instanceof BlockUpdateS2CPacket blockupdates2cpacket) {
                    this.handleBlockUpdate(
                            blockupdates2cpacket.getPos(), blockupdates2cpacket.getState());
                } else if (packetEvent.getPacket()
                        instanceof ChunkDeltaUpdateS2CPacket chunkdeltaupdates2cpacket) {
                    chunkdeltaupdates2cpacket.visitUpdates(this::handleBlockUpdate);
                }
            }
        }
    }

    private BlockHitResult findVisibleFace(BlockPos blockpos, Direction direction) {
        Vec3d vec3d = client.player.getEyePos();
        double blockInteractionRange = client.player.getBlockInteractionRange();
        VoxelShape voxelshape =
                client.world.getBlockState(blockpos).getOutlineShape(client.world, blockpos);
        if (voxelshape.isEmpty()) {
            return null;
        } else {
            for (Box box : voxelshape.getBoundingBoxes()) {
                for (double d1 : FACE_SAMPLES) {
                    for (double d2 : FACE_SAMPLES) {
                        Vec3d vec3d1 =
                                switch (direction.getAxis()) {
                                    case X ->
                                            new Vec3d(
                                                    (double) blockpos.getX()
                                                            + (direction == Direction.EAST
                                                                    ? box.maxX
                                                                    : box.minX),
                                                    (double) blockpos.getY()
                                                            + MathHelper.lerp(
                                                                    d1, box.minY, box.maxY),
                                                    (double) blockpos.getZ()
                                                            + MathHelper.lerp(
                                                                    d2, box.minZ, box.maxZ));
                                    case Y ->
                                            new Vec3d(
                                                    (double) blockpos.getX()
                                                            + MathHelper.lerp(
                                                                    d1, box.minX, box.maxX),
                                                    (double) blockpos.getY()
                                                            + (direction == Direction.UP
                                                                    ? box.maxY
                                                                    : box.minY),
                                                    (double) blockpos.getZ()
                                                            + MathHelper.lerp(
                                                                    d2, box.minZ, box.maxZ));
                                    case Z ->
                                            new Vec3d(
                                                    (double) blockpos.getX()
                                                            + MathHelper.lerp(
                                                                    d1, box.minX, box.maxX),
                                                    (double) blockpos.getY()
                                                            + MathHelper.lerp(
                                                                    d2, box.minY, box.maxY),
                                                    (double) blockpos.getZ()
                                                            + (direction == Direction.SOUTH
                                                                    ? box.maxZ
                                                                    : box.minZ));
                                };
                        if (!(vec3d.squaredDistanceTo(vec3d1)
                                > blockInteractionRange * blockInteractionRange)) {
                            Vec3d vec3d2 =
                                    vec3d1.add(vec3d1.subtract(vec3d).normalize().multiply(0.001));
                            BlockHitResult blockhitresult = this.raycast(vec3d, vec3d2);
                            if (blockhitresult.getType() == Type.BLOCK
                                    && !blockhitresult.isInsideBlock()
                                    && blockhitresult.getBlockPos().equals(blockpos)
                                    && blockhitresult.getSide() == direction) {
                                return blockhitresult;
                            }
                        }
                    }
                }
            }

            return null;
        }
    }

    private boolean isPlacementSpaceClear(BlockPos blockpos) {
        Box box = new Box(blockpos);
        return client.world.isInBuildLimit(blockpos)
                && client.world.getWorldBorder().contains(blockpos)
                && !client.player.getBoundingBox().intersects(box)
                && client.world
                        .getOtherEntities(null, box, entity -> !entity.isSpectator())
                        .isEmpty();
    }

    @Override
    protected void onDisable() {
        this.resetState();
        super.onDisable();
    }

    private BlockHitResult raycastRotation(float f, float f1) {

        Vec3d vec3d = client.player.getEyePos();

        Vec3d vec3d2 = EntityRaycast.rotationVector(f, f1);

        vec3d2 = vec3d2.multiply(client.player.getBlockInteractionRange());

        Vec3d vec3d1 = vec3d.add(vec3d2);

        return this.raycast(vec3d, vec3d1);
    }

    private boolean selectItem(Item item, long lastSwitchMillisValue) {
        if (item == null) {
            return false;
        } else if (client.player.getMainHandStack().isOf(item)) {
            return this.isSwitchDelayElapsed(lastSwitchMillisValue);
        } else {
            int switchedSlotValue = this.findHotbarItem(item);
            if (switchedSlotValue == -1) {
                return false;
            } else {
                this.selectSlot(switchedSlotValue, lastSwitchMillisValue);
                return this.delaySetting.getFloat() <= 0.0F;
            }
        }
    }

    private boolean isShieldBlock(BlockPos blockpos, BlockState blockstate) {
        if (!blockstate.isAir()
                && !blockstate.isReplaceable()
                && !blockstate.isOf(Blocks.RESPAWN_ANCHOR)) {
            VoxelShape voxelshape = blockstate.getCollisionShape(client.world, blockpos);
            if (voxelshape.isEmpty()) {
                return false;
            } else {
                Box box = voxelshape.getBoundingBox();
                return box.getLengthX() >= 0.9
                        && box.getLengthY() >= 0.9
                        && box.getLengthZ() >= 0.9;
            }
        } else {
            return false;
        }
    }

    private boolean isHoldingAnchor() {
        return client.player != null && client.player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR);
    }

    private int findHotbarItem(Item item) {
        for (int i = 0; i < 9; i++) {
            if (client.player.getInventory().getStack(i).isOf(item)) {
                return i;
            }
        }

        return -1;
    }

    @EventHandler
    public void onKeyPress(KeyPressEvent keyPressEvent) {
        int cachedKeyCode = this.activationKeySetting.getCachedKeyCode();
        if (client.currentScreen == null
                && cachedKeyCode > 7
                && keyPressEvent.getKey() == cachedKeyCode
                && this.isActivationHeld()) {
            this.queueActivation();
        }
    }

    private boolean selectSlotAndWait(int switchedSlotValue, long lastSwitchMillisValue) {
        if (switchedSlotValue >= 0 && switchedSlotValue <= 8) {
            if (client.player.getInventory().getSelectedSlot() == switchedSlotValue) {
                return this.isSwitchDelayElapsed(lastSwitchMillisValue);
            } else {
                this.selectSlot(switchedSlotValue, lastSwitchMillisValue);
                return this.delaySetting.getFloat() <= 0.0F;
            }
        } else {
            return false;
        }
    }

    private BlockHitResult findAnchorHit(BlockPos blockpos) {
        BlockHitResult blockhitresult =
                this.raycastRotation(client.player.getPitch(), client.player.getYaw());
        if (blockhitresult.getType() == Type.BLOCK
                && !blockhitresult.isInsideBlock()
                && blockhitresult.getBlockPos().equals(blockpos)) {
            return blockhitresult;
        } else {
            for (Direction direction : Direction.values()) {
                BlockHitResult blockHitResult6 = this.findVisibleFace(blockpos, direction);
                if (blockHitResult6 != null) {
                    return blockHitResult6;
                }
            }

            return null;
        }
    }

    private boolean interactOnce(BlockHitResult blockhitresult) {
        if (this.interactedThisTick) {
            return false;
        } else {
            this.interactedThisTick = true;
            ActionResult actionresult =
                    client.interactionManager.interactBlock(
                            client.player, Hand.MAIN_HAND, blockhitresult);
            if (!actionresult.isAccepted()) {
                return false;
            } else {
                client.player.swingHand(Hand.MAIN_HAND);
                return true;
            }
        }
    }

    private BlockPos findExistingShieldBlock(BlockPos blockpos) {
        BlockPos blockPosValue = client.player.getBlockPos();
        BlockPos blockPos4 = null;
        double MAX_VALUE = Double.MAX_VALUE;

        for (int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                int k = Math.abs(i) + Math.abs(j);
                if (k >= 1 && k <= 2) {
                    BlockPos blockposValue = blockPosValue.add(i, 0, j);
                    if (this.blocksExplosion(blockpos, blockposValue)
                            && this.isShieldBlock(
                                    blockposValue, client.world.getBlockState(blockposValue))) {
                        double MAX_VALUEValue =
                                blockposValue
                                        .toCenterPos()
                                        .squaredDistanceTo(client.player.getEntityPos());
                        if (!(MAX_VALUEValue >= MAX_VALUE)) {
                            MAX_VALUE = MAX_VALUEValue;
                            blockPos4 = blockposValue;
                        }
                    }
                }
            }
        }

        return blockPos4;
    }

    private void resetAnchor() {
        this.anchorPosition = null;
        this.placementHit = null;
        this.anchorHit = null;
        this.anchorConfirmed = false;
        this.lastAnchorPlaceMillis = 0L;
        this.lastChargedPosition = null;
        this.heightProtected = false;
        this.resetShieldBlock();
        if (this.rotating && TargetRingRenderer.rotationPriority == 35) {
            TargetRingRenderer.rotationTask = TargetRingRenderer.RotationTask.RESET;
        }

        this.rotating = false;
    }

    private void suppressUseInput() {
        MouseSimulator.suppressUse(75L);
        client.options.useKey.setPressed(false);
    }

    @EventHandler
    public void onMouseButton(MouseButtonEvent mouseButtonEvent) {
        int cachedKeyCode = this.activationKeySetting.getCachedKeyCode();
        if (mouseButtonEvent.getScreen() == null
                && cachedKeyCode >= 0
                && cachedKeyCode <= 7
                && mouseButtonEvent.getButton() == cachedKeyCode
                && mouseButtonEvent.getAction() == 1
                && !MouseSimulator.isPressed(cachedKeyCode)) {
            this.queueActivation();
        }
    }

    private boolean isSameBlockFace(
            BlockHitResult blockhitresult, BlockHitResult blockHitResultValue) {
        return blockhitresult.getType() == Type.BLOCK
                && !blockhitresult.isInsideBlock()
                && blockhitresult.getBlockPos().equals(blockHitResultValue.getBlockPos())
                && blockhitresult.getSide() == blockHitResultValue.getSide();
    }

    private boolean isShieldConfirmed() {
        return this.shieldPosition != null
                && this.isShieldBlock(
                        this.shieldPosition, client.world.getBlockState(this.shieldPosition));
    }

    private boolean ensureShieldBlock(BlockPos blockpos, long lastSwitchMillisValue) {
        if (Math.abs(blockpos.getY() - client.player.getBlockPos().getY()) >= 1) {
            this.shieldPosition = null;
            this.shieldItem = null;
            this.shieldPlacedAtMillis = 0L;
            this.shieldConfirmed = false;
            this.heightProtected = true;
            return true;
        } else {
            this.heightProtected = false;
            BlockPos blockPosValue = this.findExistingShieldBlock(blockpos);
            if (blockPosValue != null) {
                this.shieldPosition = blockPosValue;
                this.shieldItem = null;
                this.shieldPlacedAtMillis = 0L;
                this.shieldConfirmed = true;
                return true;
            } else {
                if (this.shieldPosition != null
                        && (!this.blocksExplosion(blockpos, this.shieldPosition)
                                || this.shieldConfirmed && !this.isShieldConfirmed())) {
                    this.resetShieldBlock();
                }

                if (this.shieldPosition != null && this.shieldPlacedAtMillis != 0L) {
                    if (this.isShieldConfirmed()) {
                        this.shieldConfirmed = true;
                        return true;
                    }

                    if (lastSwitchMillisValue - this.shieldPlacedAtMillis < (500L)) {
                        return false;
                    }

                    this.resetShieldBlock();
                }

                if (this.shieldPosition == null) {
                    this.shieldItem =
                            this.findHotbarItem(Items.GLOWSTONE) != -1
                                    ? Items.GLOWSTONE
                                    : (this.findHotbarItem(Items.OBSIDIAN) != -1
                                            ? Items.OBSIDIAN
                                            : null);
                    if (this.shieldItem == null) {
                        return false;
                    }

                    BlockPos blockPos4 = client.player.getBlockPos();
                    double MAX_VALUE = Double.MAX_VALUE;

                    for (int j = -2; j <= 2; j++) {
                        for (int k = -2; k <= 2; k++) {
                            int l1 = Math.abs(j) + Math.abs(k);
                            if (l1 >= 1 && l1 <= 2) {
                                BlockPos blockposValue = blockPos4.add(j, 0, k);
                                if (this.blocksExplosion(blockpos, blockposValue)
                                        && this.canPlaceShieldBlock(blockposValue)
                                        && this.findPlacementHit(blockposValue, this.shieldItem)
                                                != null) {
                                    double MAX_VALUEValue =
                                            blockposValue
                                                    .toCenterPos()
                                                    .squaredDistanceTo(
                                                            client.player.getEntityPos());
                                    if (!(MAX_VALUEValue >= MAX_VALUE)) {
                                        MAX_VALUE = MAX_VALUEValue;
                                        this.shieldPosition = blockposValue;
                                        this.shieldConfirmed = false;
                                    }
                                }
                            }
                        }
                    }
                }

                if (this.shieldPosition == null) {
                    return false;
                } else if (!this.canPlaceShieldBlock(this.shieldPosition)) {
                    this.resetShieldBlock();
                    return false;
                } else if (!this.selectItem(this.shieldItem, lastSwitchMillisValue)) {
                    return false;
                } else {
                    BlockHitResult blockhitresult =
                            this.findPlacementHit(this.shieldPosition, this.shieldItem);
                    if (blockhitresult == null) {
                        return false;
                    } else {
                        BlockHitResult blockhitresultValue = this.alignToHit(blockhitresult);
                        if (blockhitresultValue == null
                                || !this.canPlaceAt(
                                        blockhitresultValue, this.shieldPosition, this.shieldItem)
                                || !this.canPlaceShieldBlock(this.shieldPosition)) {
                            return false;
                        } else if (!this.interactOnce(blockhitresultValue)) {
                            this.resetShieldBlock();
                            return false;
                        } else {
                            this.shieldPlacedAtMillis = lastSwitchMillisValue;
                            this.shieldConfirmed = this.isShieldConfirmed();
                            return false;
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.resetState();
    }

    @EventHandler
    public void onMovementInput(MovementInputEvent movementInputEvent) {
        if (this.rotating
                && client.player != null
                && TargetRingRenderer.rotationPriority == 35
                && TargetRingRenderer.rotationTask == TargetRingRenderer.RotationTask.AIM) {
            MovementUtils.correctMovementInput(
                    movementInputEvent,
                    client.player.getYaw(),
                    client.gameRenderer.getCamera().getYaw());
        }
    }

    private boolean blocksExplosion(BlockPos blockpos, BlockPos blockPosValue) {
        if (blockPosValue != null && !blockpos.equals(blockPosValue)) {
            Vec3d vec3d = blockpos.toCenterPos();
            Vec3d vec3d1 = client.player.getEntityPos().add(0.0, 0.5, 0.0);
            Box box = new Box(blockPosValue);
            return !box.intersects(client.player.getBoundingBox())
                    && !box.contains(vec3d)
                    && box.raycast(vec3d, vec3d1).isPresent();
        } else {
            return false;
        }
    }

    private boolean placeAnchor(long lastSwitchMillisValue) {
        if (this.lastAnchorPlaceMillis != 0L
                && lastSwitchMillisValue - this.lastAnchorPlaceMillis < 500L) {
            return false;
        } else if (!this.selectItem(Items.RESPAWN_ANCHOR, lastSwitchMillisValue)) {
            return false;
        } else {
            if (!this.canPlaceAt(this.placementHit, this.anchorPosition, Items.RESPAWN_ANCHOR)) {
                this.placementHit =
                        this.findPlacementHit(this.anchorPosition, Items.RESPAWN_ANCHOR);
            }

            if (this.placementHit == null) {
                return false;
            } else {
                BlockHitResult blockhitresult = this.alignToHit(this.placementHit);
                if (blockhitresult == null
                        || !this.canPlaceAt(
                                blockhitresult, this.anchorPosition, Items.RESPAWN_ANCHOR)
                        || !this.isPlacementSpaceClear(this.anchorPosition)) {
                    return false;
                } else if (!this.interactOnce(blockhitresult)) {
                    return false;
                } else {
                    this.lastAnchorPlaceMillis = lastSwitchMillisValue;
                    return client.world
                            .getBlockState(this.anchorPosition)
                            .isOf(Blocks.RESPAWN_ANCHOR);
                }
            }
        }
    }

    private void rotateTo(Rotation rotationValue) {
        this.rotating = true;
        float f = this.rotationSetting.getFloat();
        TargetRingRenderer.aim(
                rotationValue,
                MathHelper.lerp(f, 180.0F, 65.0F),
                MathHelper.lerp(f, 180.0F, 70.0F),
                MathHelper.lerp(f, 180.0F, 50.0F),
                MathHelper.lerp(f, 180.0F, 55.0F),
                1,
                35,
                false);
    }

    private void resetState() {
        this.active = false;
        this.activationQueued = false;
        this.activationConsumed = false;
        this.queuedActivationHit = null;
        this.sequenceStartedAtMillis = 0L;
        this.lastChargeMillis = 0L;
        this.lastSwitchMillis = 0L;
        this.switchedSlot = -1;
        this.interactedThisTick = false;
        this.hasServerRotation = false;
        this.serverYaw = 0.0F;
        this.serverPitch = 0.0F;
        this.resetAnchor();
    }

    private boolean canPlaceShieldBlock(BlockPos blockpos) {
        return this.shieldItem != null
                && this.isPlacementSpaceClear(blockpos)
                && this.isReplaceable(blockpos, this.shieldItem);
    }

    private BlockHitResult getExplosionHit(BlockHitResult blockhitresult) {
        if (TargetRingRenderer.rotationPriority > 35) {
            return null;
        } else {
            BlockHitResult blockHitResult7 = this.alignToHit(blockhitresult);
            if (blockHitResult7 != null) {
                return blockHitResult7;
            } else if (!this.heightProtected
                    && this.shieldConfirmed
                    && this.shieldPosition != null
                    && this.isShieldConfirmed()) {
                double blockInteractionRange = client.player.getBlockInteractionRange();
                if (client.player.getEyePos().squaredDistanceTo(blockhitresult.getPos())
                        > blockInteractionRange * blockInteractionRange) {
                    return null;
                } else {
                    Rotation rotation = this.rotationTo(blockhitresult.getPos());
                    return this.hasServerRotation
                                    && !(new Rotation(client.player).angularDistanceTo(rotation)
                                            > 1.5F)
                                    && !(new Rotation(this.serverYaw, this.serverPitch)
                                                    .angularDistanceTo(rotation)
                                            > 2.5F)
                            ? blockhitresult
                            : null;
                }
            } else {
                return null;
            }
        }
    }

    private void queueActivation() {
        if (client.player != null
                && client.world != null
                && client.interactionManager != null
                && !this.active
                && !this.activationQueued
                && !DoubleAnchorModule.isActive()
                && this.isHoldingAnchor()) {
            BlockHitResult blockhitresult = this.getCrosshairBlock();
            if (this.canStartAt(blockhitresult)) {
                this.queuedActivationHit = blockhitresult;
                this.activationQueued = true;
                this.activationConsumed = true;
            }
        }
    }

    private BlockHitResult alignToHit(BlockHitResult blockhitresult) {
        if (blockhitresult != null && TargetRingRenderer.rotationPriority <= 35) {
            BlockHitResult blockhitresultValue =
                    this.raycastRotation(client.player.getPitch(), client.player.getYaw());
            if (this.hasServerRotation) {
                BlockHitResult blockhitresult3 =
                        this.raycastRotation(this.serverPitch, this.serverYaw);
                if (this.isSameBlockFace(blockhitresultValue, blockhitresult)
                        && this.isSameBlockFace(blockhitresult3, blockhitresult)) {
                    this.rotateTo(new Rotation(client.player));
                    return blockhitresultValue;
                }
            }

            this.rotateTo(this.rotationTo(blockhitresult.getPos()));
            return null;
        } else {
            return null;
        }
    }

    private boolean startSequence(
            BlockHitResult blockhitresult, long sequenceStartedAtMillisValue) {
        if (blockhitresult != null && this.isHoldingAnchor()) {
            this.resetAnchor();
            BlockState blockstate = client.world.getBlockState(blockhitresult.getBlockPos());
            if (blockstate.isOf(Blocks.RESPAWN_ANCHOR)) {
                this.anchorPosition = blockhitresult.getBlockPos().toImmutable();
                this.anchorHit = blockhitresult;
                this.anchorConfirmed = true;
            } else {
                ItemStack itemstack = client.player.getMainHandStack();
                if (itemstack.isEmpty()) {
                    return false;
                }

                ItemPlacementContext itemplacementcontext =
                        new ItemPlacementContext(
                                client.player, Hand.MAIN_HAND, itemstack, blockhitresult);
                BlockPos blockpos = itemplacementcontext.getBlockPos().toImmutable();
                BlockState blockState = client.world.getBlockState(blockpos);
                if (blockState.isOf(Blocks.RESPAWN_ANCHOR)) {
                    this.anchorPosition = blockpos;
                    this.anchorHit = this.findAnchorHit(blockpos);
                    this.anchorConfirmed = true;
                } else {
                    if (!itemplacementcontext.canPlace() || !this.isPlacementSpaceClear(blockpos)) {
                        return false;
                    }

                    this.anchorPosition = blockpos;
                    this.placementHit = blockhitresult;
                }
            }

            this.sequenceStartedAtMillis = sequenceStartedAtMillisValue;
            this.active = true;
            this.activationConsumed = true;
            return true;
        } else {
            return false;
        }
    }

    private void finishSequence() {
        this.active = false;
        this.activationQueued = false;
        this.queuedActivationHit = null;
        this.sequenceStartedAtMillis = 0L;
        if (client.player != null && this.isActivationHeld()) {
            this.activationConsumed = true;
        } else {
            this.activationConsumed = false;
        }

        this.resetAnchor();
    }

    private void handleBlockUpdate(BlockPos blockpos, BlockState blockstate) {
        BlockPos blockposValue = blockpos.toImmutable();
        ClientWorld clientworld = client.world;
        client.execute(
                () -> {
                    if (this.isEnabled()
                            && clientworld != null
                            && client.world == clientworld
                            && this.shieldPosition != null
                            && this.shieldPosition.equals(blockposValue)) {
                        this.shieldConfirmed = this.isShieldBlock(blockposValue, blockstate);
                    }
                });
    }
}
