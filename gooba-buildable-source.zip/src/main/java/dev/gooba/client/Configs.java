package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

import java.util.List;

@Environment(EnvType.CLIENT)
public class Configs extends Command {

    private static boolean listening;

    private static final List<String> SUBCOMMANDS = List.of("copy", "listen");

    @Override
    public void execute(String[] astring) {
        if (astring.length != 1) {
            this.showUsage();
        } else {
            String text = astring[0].toLowerCase();
            switch (text.hashCode()) {
                case -1102508601:
                    if (text.equals("listen")) {
                        listening = true;
                        ChatMessages.send("Listening for the config");
                        return;
                    }
                    break;
                case 3059573:
                    if (text.equals("copy")) {
                        this.copyToClipboard();
                        return;
                    }
            }

            this.showUsage();
        }
    }

    public Configs() {
        super("cfg", ".cfg <copy|listen>", "Configs");
    }

    @Override
    public List suggest(String text) {

        String textValue = text.toLowerCase();

        return SUBCOMMANDS.stream().filter(text2 -> text2.startsWith(textValue)).toList();
    }

    public static boolean isListening() {
        return listening;
    }

    public static void importClipboard() {
        if (listening) {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (minecraftclient.keyboard != null) {
                if (Gooba.getInstance()
                        .getConfigManager()
                        .importConfig(minecraftclient.keyboard.getClipboard())) {
                    listening = false;
                    ChatMessages.send("Successfully loaded");
                    SoundPlayer.playDefaultPitch("cfgload", 0.5F);
                } else {
                    ChatMessages.send("Invalid config");
                }
            }
        }
    }

    private void copyToClipboard() {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient.keyboard != null) {
            minecraftclient.keyboard.setClipboard(
                    Gooba.getInstance().getConfigManager().exportConfig());
            ChatMessages.send("Successfully copied");
        }
    }

    private void showUsage() {
        ChatMessages.send(".cfg <copy|listen>");
    }
}
