package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@ModuleInfo(
        name = "Fireflies",
        desc = "Spawns animated glowing fireflies around the player",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class FirefliesModule extends Module {
    private static final RenderPipeline PARTICLE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("mytheria", "pipeline/fireflies"))
                            .withVertexShader("core/position_tex_color")
                            .withFragmentShader("core/position_tex_color")
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
                            .build());
    private static final Identifier GLOW_TEXTURE =
            Identifier.of("client", "textures/particles/glow.png");
    private static final RenderPipeline TRAIL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("mytheria", "pipeline/fireflies_trail"))
                            .withVertexShader("core/position_color")
                            .withFragmentShader("core/position_color")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .build());
    private static final RenderPipeline SPARK_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("mytheria", "pipeline/fireflies_spark"))
                            .withVertexShader("core/position_color")
                            .withFragmentShader("core/position_color")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .build());
    private static final RenderLayer BLOOM_LAYER =
            RenderLayer.of(
                    "mytheria_fireflies_bloom",
                    RenderSetup.builder(PARTICLE_PIPELINE)
                            .texture("Sampler0", GLOW_TEXTURE)
                            .translucent()
                            .expectedBufferSize(8192)
                            .build());
    public SliderSetting spawnDelaySetting =
            new SliderSetting(this, "Spawn delay", 3.0F, 1.0F, 10.0F, 1.0F);
    private static final RenderLayer SPARK_LAYER =
            RenderLayer.of(
                    "mytheria_fireflies_spark",
                    RenderSetup.builder(SPARK_PIPELINE)
                            .translucent()
                            .expectedBufferSize(16384)
                            .build());
    private static final Identifier SPARK_GLOW_TEXTURE =
            Identifier.of("client", "textures/particles/glow.png");
    private final List<FirefliesModule.FirePart> fireflies = new ArrayList<>();
    private static final RenderLayer SPARK_GLOW_LAYER =
            RenderLayer.of(
                    "mytheria_fireflies_spark_glow",
                    RenderSetup.builder(PARTICLE_PIPELINE)
                            .texture("Sampler0", FirefliesModule.SPARK_GLOW_TEXTURE)
                            .translucent()
                            .expectedBufferSize(8192)
                            .build());
    private static final Identifier CIRCLE_TEXTURE =
            Identifier.of("client", "textures/particles/circle.png");
    private static final RenderLayer PARTICLE_LAYER =
            RenderLayer.of(
                    "mytheria_fireflies",
                    RenderSetup.builder(PARTICLE_PIPELINE)
                            .texture("Sampler0", FirefliesModule.CIRCLE_TEXTURE)
                            .translucent()
                            .expectedBufferSize(8192)
                            .build());
    private static final RenderLayer TRAIL_LAYER =
            RenderLayer.of(
                    "mytheria_fireflies_trail",
                    RenderSetup.builder(TRAIL_PIPELINE)
                            .translucent()
                            .expectedBufferSize(16384)
                            .build());

    private boolean isBehindCamera(
            FirefliesModule.FirePart firePart, Vec3d vec3d, Vector3f vector3f) {
        float f = (float) (firePart.position.x - vec3d.x);
        float f1 = (float) (firePart.position.y - vec3d.y);
        float f2 = (float) (firePart.position.z - vec3d.z);
        return f * vector3f.x + f1 * vector3f.y + f2 * vector3f.z < -2.0F;
    }

    private void drawTrailSegment(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            FirefliesModule.TrailPart trailPart,
            FirefliesModule.TrailPart trailPartValue,
            Vec3d vec3d,
            float f,
            int i,
            int j) {
        float f1 = (float) (trailPart.x - vec3d.x);
        float f2 = (float) (trailPart.y - vec3d.y);
        float f3 = (float) (trailPart.z - vec3d.z);
        float f4 = (float) (trailPartValue.x - vec3d.x);
        float f5 = (float) (trailPartValue.y - vec3d.y);
        float f6 = (float) (trailPartValue.z - vec3d.z);
        float f7 = f4 - f1;
        float f8 = f5 - f2;
        float f9 = f6 - f3;
        float f10 = f2 * f9 - f3 * f8;
        float f11 = f3 * f7 - f1 * f9;
        float f12 = f1 * f8 - f2 * f7;
        float f13 = (float) Math.sqrt((double) (f10 * f10 + f11 * f11 + f12 * f12));
        if (!(f13 < 1.0E-6F)) {
            f10 = f10 / f13 * f;
            f11 = f11 / f13 * f;
            f12 = f12 / f13 * f;
            this.putVertex(vertexconsumer, matrix4f, f1 - f10, f2 - f11, f3 - f12, i);
            this.putVertex(vertexconsumer, matrix4f, f1 + f10, f2 + f11, f3 + f12, i);
            this.putVertex(vertexconsumer, matrix4f, f4 + f10, f5 + f11, f6 + f12, j);
            this.putVertex(vertexconsumer, matrix4f, f4 - f10, f5 - f11, f6 - f12, j);
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null) {
            if (client.player.age == 1) {
                this.fireflies.forEach(FirefliesModule.FirePart::expire);
            }

            this.fireflies.forEach(FirefliesModule.FirePart::tick);
            this.fireflies.removeIf(FirefliesModule.FirePart::isExpired);
            if (client.player.age % (this.spawnDelaySetting.getFloat().intValue() + 1) == 0) {
                int particleColor = this.getParticleColor();
                this.fireflies.add(
                        new FirefliesModule.FirePart(
                                this.findSpawnPosition(10.0, 4.0), 5500.0F, particleColor));
                this.fireflies.add(
                        new FirefliesModule.FirePart(
                                this.findSpawnPosition(6.0, 5.0), 5500.0F, particleColor));
            }
        }
    }

    private int getParticleColor() {
        return ColorUtils.themeAccent();
    }

    private static int brighten(int i, float f) {
        int j = i >>> 24 & 0xFF;
        int k = interpolateColor(i, -1, MathHelper.clamp(f, 0.0F, 1.0F));
        return k & 16777215 | j << 24;
    }

    private Vec3d randomSpawnPosition(double d0, double d1) {
        return client.player
                .getEntityPos()
                .add(
                        (double) randomFloat(-d0, d0),
                        (double) randomFloat(-d1 / 3.0, d1),
                        (double) randomFloat(-d0, d0));
    }

    private void drawFirefly(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            FirefliesModule.FirePart firePart,
            Vec3d vec3d,
            Vector3f vector3f,
            Vector3f vector3f1,
            float f,
            boolean flag) {
        float opacity = firePart.getOpacity();
        if (!(opacity <= 0.004F)) {
            int i = withAlpha(firePart.color, alpha(firePart.color) * opacity);
            float f2 = brightness(i);
            int j = brighten(i, alpha(i) / 255.0F * f2 * 0.3F);
            Vec3d vec3d1 = firePart.interpolatePosition(f);
            float f3 = 0.04F * opacity;
            if (flag) {
                j = withAlpha(j, alpha(j) * 0.3F);
                f3 *= 5.0F;
            }

            this.drawTexturedBillboard(
                    vertexconsumer, matrix4f, vec3d1, vec3d, vector3f, vector3f1, f3, j);
        }
    }

    private void drawSparkGlow(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            FirefliesModule.FirePart firePart,
            Vec3d vec3d,
            Vector3f vector3f,
            Vector3f vector3f1,
            float f) {
        if (!firePart.sparks.isEmpty()) {
            double d0 =
                    client.player.squaredDistanceTo(
                            firePart.position.x, firePart.position.y + 1.6, firePart.position.z);
            float f1 =
                    0.035F
                            + 0.02F
                                    * MathHelper.clamp(
                                            1.0F - ((float) Math.sqrt(d0) - 3.0F) / 10.0F,
                                            0.0F,
                                            1.0F);

            for (FirefliesModule.SparkPart sparkPart : firePart.sparks) {
                float lifetimeProgress = (float) sparkPart.getLifetimeProgress();
                int i =
                        withAlpha(
                                firePart.color,
                                alpha(firePart.color) * (1.0F - lifetimeProgress) * 0.3F);
                Vec3d vec3d1 =
                        new Vec3d(
                                sparkPart.interpolateX(f),
                                sparkPart.interpolateY(f),
                                sparkPart.interpolateZ(f));
                this.drawTexturedBillboard(
                        vertexconsumer,
                        matrix4f,
                        vec3d1,
                        vec3d,
                        vector3f,
                        vector3f1,
                        f1 * (1.4F - lifetimeProgress),
                        i);
            }
        }
    }

    private Vec3d findSpawnPosition(double d0, double d1) {
        Vec3d vec3d = this.randomSpawnPosition(d0, d1);

        for (int i = 0; i < 30; i++) {
            double d2 = vec3d.x - client.player.getX();
            double d3 = vec3d.z - client.player.getZ();
            if (this.isSolidAt(vec3d.x, vec3d.y, vec3d.z)
                    || Math.sqrt(d2 * d2 + d3 * d3) < d0 / 3.0) {
                vec3d = this.randomSpawnPosition(d0, d1);
            }
        }

        return vec3d;
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null && !this.fireflies.isEmpty()) {
            float tickDelta = render3DEvent.getTickDelta();
            Vec3d vec3d = client.gameRenderer.getCamera().getCameraPos();
            Quaternionf quaternionf = client.gameRenderer.getCamera().getRotation();
            Vector3f vector3f = quaternionf.transform(new Vector3f(1.0F, 0.0F, 0.0F));
            Vector3f vector3f1 = quaternionf.transform(new Vector3f(0.0F, 1.0F, 0.0F));
            Vector3f vector3f2 = quaternionf.transform(new Vector3f(0.0F, 0.0F, -1.0F));
            MatrixStack matrixstack = render3DEvent.getMatrixStack();
            Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
            Immediate immediate = client.getBufferBuilders().getEntityVertexConsumers();
            VertexConsumer vertexconsumer = immediate.getBuffer(TRAIL_LAYER);

            for (FirefliesModule.FirePart firePart : this.fireflies) {
                if (!this.isBehindCamera(firePart, vec3d, vector3f2)) {
                    this.drawTrail(vertexconsumer, matrix4f, firePart, vec3d);
                }
            }

            immediate.draw(TRAIL_LAYER);
            VertexConsumer buffer = immediate.getBuffer(SPARK_GLOW_LAYER);

            for (FirefliesModule.FirePart firePartValue : this.fireflies) {
                if (!this.isBehindCamera(firePartValue, vec3d, vector3f2)) {
                    this.drawSparkGlow(
                            buffer, matrix4f, firePartValue, vec3d, vector3f, vector3f1, tickDelta);
                }
            }

            immediate.draw(SPARK_GLOW_LAYER);
            VertexConsumer bufferValue = immediate.getBuffer(SPARK_LAYER);

            for (FirefliesModule.FirePart firePart2 : this.fireflies) {
                if (!this.isBehindCamera(firePart2, vec3d, vector3f2)) {
                    this.drawSparks(
                            bufferValue,
                            matrix4f,
                            firePart2,
                            vec3d,
                            vector3f,
                            vector3f1,
                            tickDelta);
                }
            }

            immediate.draw(SPARK_LAYER);
            VertexConsumer buffer2 = immediate.getBuffer(PARTICLE_LAYER);

            for (FirefliesModule.FirePart firePart3 : this.fireflies) {
                if (!this.isBehindCamera(firePart3, vec3d, vector3f2)) {
                    this.drawFirefly(
                            buffer2, matrix4f, firePart3, vec3d, vector3f, vector3f1, tickDelta,
                            false);
                }
            }

            immediate.draw(PARTICLE_LAYER);
            VertexConsumer buffer3 = immediate.getBuffer(BLOOM_LAYER);

            for (FirefliesModule.FirePart firePart4 : this.fireflies) {
                if (!this.isBehindCamera(firePart4, vec3d, vector3f2)) {
                    this.drawFirefly(
                            buffer3, matrix4f, firePart4, vec3d, vector3f, vector3f1, tickDelta,
                            true);
                }
            }

            immediate.draw(BLOOM_LAYER);
        }
    }

    private void drawTexturedBillboard(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            Vec3d vec3d,
            Vec3d vec3d1,
            Vector3f vector3f,
            Vector3f vector3f1,
            float f,
            int i) {
        float f1 = (float) (vec3d.x - vec3d1.x);
        float f2 = (float) (vec3d.y - vec3d1.y);
        float f3 = (float) (vec3d.z - vec3d1.z);
        float f4 = vector3f.x * f;
        float f5 = vector3f.y * f;
        float f6 = vector3f.z * f;
        float f7 = vector3f1.x * f;
        float f8 = vector3f1.y * f;
        float f9 = vector3f1.z * f;
        float f10 = (float) (i >> 16 & 0xFF) / 255.0F;
        float f11 = (float) (i >> 8 & 0xFF) / 255.0F;
        float f12 = (float) (i & 0xFF) / 255.0F;
        float f13 = (float) (i >>> 24 & 0xFF) / 255.0F;
        vertexconsumer
                .vertex(matrix4f, f1 - f4 - f7, f2 - f5 - f8, f3 - f6 - f9)
                .texture(0.0F, 0.0F)
                .color(f10, f11, f12, f13);
        vertexconsumer
                .vertex(matrix4f, f1 - f4 + f7, f2 - f5 + f8, f3 - f6 + f9)
                .texture(0.0F, 1.0F)
                .color(f10, f11, f12, f13);
        vertexconsumer
                .vertex(matrix4f, f1 + f4 + f7, f2 + f5 + f8, f3 + f6 + f9)
                .texture(1.0F, 1.0F)
                .color(f10, f11, f12, f13);
        vertexconsumer
                .vertex(matrix4f, f1 + f4 - f7, f2 + f5 - f8, f3 + f6 - f9)
                .texture(1.0F, 0.0F)
                .color(f10, f11, f12, f13);
    }

    private static float alpha(int i) {
        return (float) (i >>> 24 & 0xFF);
    }

    private static float brightness(int i) {
        float[] afloat = Color.RGBtoHSB(i >> 16 & 0xFF, i >> 8 & 0xFF, i & 0xFF, null);
        return afloat[2];
    }

    private boolean isSolidAt(double d0, double d1, double d2) {
        BlockState blockstate = client.world.getBlockState(BlockPos.ofFloored(d0, d1, d2));
        return !blockstate.isAir()
                && blockstate.getFluidState().isEmpty()
                && !blockstate.isReplaceable();
    }

    private void putVertex(
            VertexConsumer vertexconsumer, Matrix4f matrix4f, float f, float f1, float f2, int i) {
        vertexconsumer
                .vertex(matrix4f, f, f1, f2)
                .color(
                        (float) (i >> 16 & 0xFF) / 255.0F,
                        (float) (i >> 8 & 0xFF) / 255.0F,
                        (float) (i & 0xFF) / 255.0F,
                        (float) (i >>> 24 & 0xFF) / 255.0F);
    }

    private static int withAlpha(int i, float f) {
        int j = MathHelper.clamp(Math.round(f), 0, 255);
        return i & 16777215 | j << 24;
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.fireflies.clear();
    }

    private void drawSparks(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            FirefliesModule.FirePart firePart,
            Vec3d vec3d,
            Vector3f vector3f,
            Vector3f vector3f1,
            float f) {
        if (firePart.sparks.size() >= 2) {
            double d0 =
                    client.player.squaredDistanceTo(
                            firePart.position.x, firePart.position.y + 1.6, firePart.position.z);
            float f1 =
                    0.25F
                            + 5.0F
                                    * MathHelper.clamp(
                                            1.0F - ((float) Math.sqrt(d0) - 3.0F) / 10.0F,
                                            0.0F,
                                            1.0F);
            float f2 = f1 * 0.0012F;
            float opacity = firePart.getOpacity();

            for (FirefliesModule.SparkPart sparkPart : firePart.sparks) {
                float lifetimeProgress = (float) sparkPart.getLifetimeProgress();
                int i = interpolateColor(-1, firePart.color, lifetimeProgress);
                i =
                        withAlpha(
                                i,
                                alpha(firePart.color)
                                        * opacity
                                        * (1.0F
                                                - lifetimeProgress
                                                        * lifetimeProgress
                                                        * lifetimeProgress));
                Vec3d vec3d1 =
                        new Vec3d(
                                sparkPart.interpolateX(f),
                                sparkPart.interpolateY(f),
                                sparkPart.interpolateZ(f));
                this.drawBillboard(
                        vertexconsumer, matrix4f, vec3d1, vec3d, vector3f, vector3f1, f2, i);
            }
        }
    }

    private void drawBillboard(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            Vec3d vec3d,
            Vec3d vec3d1,
            Vector3f vector3f,
            Vector3f vector3f1,
            float f,
            int i) {
        float f1 = (float) (vec3d.x - vec3d1.x);
        float f2 = (float) (vec3d.y - vec3d1.y);
        float f3 = (float) (vec3d.z - vec3d1.z);
        float f4 = vector3f.x * f;
        float f5 = vector3f.y * f;
        float f6 = vector3f.z * f;
        float f7 = vector3f1.x * f;
        float f8 = vector3f1.y * f;
        float f9 = vector3f1.z * f;
        this.putVertex(vertexconsumer, matrix4f, f1 - f4 - f7, f2 - f5 - f8, f3 - f6 - f9, i);
        this.putVertex(vertexconsumer, matrix4f, f1 - f4 + f7, f2 - f5 + f8, f3 - f6 + f9, i);
        this.putVertex(vertexconsumer, matrix4f, f1 + f4 + f7, f2 + f5 + f8, f3 + f6 + f9, i);
        this.putVertex(vertexconsumer, matrix4f, f1 + f4 - f7, f2 + f5 - f8, f3 + f6 - f9, i);
    }

    private void drawTrail(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            FirefliesModule.FirePart firePart,
            Vec3d vec3d) {
        if (firePart.trail.size() >= 2) {
            int i = withAlpha(firePart.color, alpha(firePart.color) * firePart.getOpacity());
            double d0 =
                    client.player.squaredDistanceTo(
                            firePart.position.x, firePart.position.y + 1.6, firePart.position.z);
            float f = MathHelper.clamp(1.0F - ((float) Math.sqrt(d0) - 3.0F) / 20.0F, 0.0F, 1.0F);
            float f1 = 0.012F * f + 1.0E-4F;
            int count = firePart.trail.size();

            for (int k = 0; k < count - 1; k++) {
                FirefliesModule.TrailPart trailPart = firePart.trail.get(k);
                FirefliesModule.TrailPart trailPartValue = firePart.trail.get(k + 1);
                float f2 = (float) k / (float) count;
                float f3 = (float) (k + 1) / (float) count;
                int l = this.trailColor(i, firePart.getOpacity(), f2);
                int i1 = this.trailColor(i, firePart.getOpacity(), f3);
                this.drawTrailSegment(
                        vertexconsumer, matrix4f, trailPart, trailPartValue, vec3d, f1, l, i1);
            }
        }
    }

    private int trailColor(int i, float f, float f1) {
        float f2 = parabolicFade(f1);
        int j = withAlpha(i, alpha(i) * f * f2);
        return brighten(j, alpha(j) / 255.0F * brightness(j) * 0.25F * f1);
    }

    private static float parabolicFade(float f) {
        float f1 = 2.0F * f - 1.0F;
        return 1.0F - f1 * f1;
    }

    private static float randomFloat(double d0, double d1) {
        return (float) ThreadLocalRandom.current().nextDouble(d0, Math.max(d1, d0 + 1.0E-6));
    }

    private static int interpolateColor(int i, int j, float f) {
        f = MathHelper.clamp(f, 0.0F, 1.0F);
        int k = MathHelper.lerp(f, i >> 16 & 0xFF, j >> 16 & 0xFF);
        int l = MathHelper.lerp(f, i >> 8 & 0xFF, j >> 8 & 0xFF);
        int i11 = MathHelper.lerp(f, i & 0xFF, j & 0xFF);
        int j1 = MathHelper.lerp(f, i >>> 24 & 0xFF, j >>> 24 & 0xFF);
        return j1 << 24 | k << 16 | l << 8 | i11;
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        this.fireflies.clear();
    }

    @Environment(EnvType.CLIENT)
    private class FirePart {
        float speed;
        final float lifetimeMillis;
        long lastTurnMillis;
        float targetYaw;
        Vec3d position;
        final List<FirefliesModule.SparkPart> sparks;
        float yaw;
        float verticalVelocity;
        final long createdAtMillis;
        int turnDelayMillis;
        final List<FirefliesModule.TrailPart> trail = new ArrayList<>();
        boolean expired;
        float targetOpacity;
        Vec3d previousPosition;
        final int color;
        float opacity;

        void tick() {
            this.opacity =
                    this.opacity
                            + MathHelper.clamp(this.targetOpacity - this.opacity, -0.02F, 0.02F)
                                    * 2.0F;
            this.opacity = MathHelper.clamp(this.opacity, 0.0F, 1.0F);
            if (System.currentTimeMillis() - this.lastTurnMillis >= (long) this.turnDelayMillis) {
                this.turnDelayMillis = this.randomTurnDelay();
                this.lastTurnMillis = System.currentTimeMillis();
                this.targetYaw = FirefliesModule.randomFloat(0.0, 360.0);
            }

            this.yaw = MathHelper.lerp(0.065F, this.yaw, this.targetYaw);
            this.speed /= 1.005F;
            float f =
                    -MathHelper.sin((double) ((float) Math.toRadians((double) this.yaw)))
                            * this.speed;
            float f1 =
                    MathHelper.cos((double) ((float) Math.toRadians((double) this.yaw)))
                            * this.speed;
            this.previousPosition = this.position;
            float f2 = 0.1F;
            boolean flagx;
            flagx =
                    (!MinecraftAccess.client.world.isSpaceEmpty(
                            new Box(
                                    this.position.x - (double) (f2 / 2.0F),
                                    this.position.y,
                                    this.position.z - (double) (f2 / 2.0F),
                                    this.position.x + (double) (f2 / 2.0F),
                                    this.position.y + (double) f2,
                                    this.position.z + (double) (f2 / 2.0F))));

            float f3 = flagx ? 0.3F : 1.0F;
            this.verticalVelocity /= 1.02F;
            this.position =
                    this.position.add(
                            (double) (f / f3),
                            (double) (this.verticalVelocity / f3),
                            (double) (f1 / f3));
            if (this.getLifetimeProgress() >= 1.0F) {
                this.targetOpacity = 0.0F;
                if (this.getOpacity() < 0.004F) {
                    this.expire();
                }
            }

            this.trail.add(new FirefliesModule.TrailPart(this, 500));
            this.trail.removeIf(FirefliesModule.TrailPart::isExpired);

            for (int i = 0; i < 2; i++) {
                this.sparks.add(new FirefliesModule.SparkPart(this, 600));
            }

            this.sparks.forEach(FirefliesModule.SparkPart::tick);
            this.sparks.removeIf(FirefliesModule.SparkPart::isExpired);
        }

        FirePart(Vec3d vec3d, float lifetimeMillisValue, int colorValue) {
            this.sparks = new ArrayList<>();
            this.opacity = 0.0F;
            this.targetOpacity = 1.0F;
            this.turnDelayMillis = this.randomTurnDelay();
            this.targetYaw = FirefliesModule.randomFloat(0.0, 360.0);
            this.speed = FirefliesModule.randomFloat(0.08, 0.175);
            this.verticalVelocity = FirefliesModule.randomFloat(-0.075, 0.1);
            this.yaw = this.targetYaw;
            this.createdAtMillis = System.currentTimeMillis();
            this.lastTurnMillis = this.createdAtMillis;
            this.color = colorValue;
            this.position = vec3d;
            this.previousPosition = vec3d;
            this.lifetimeMillis = lifetimeMillisValue;
        }

        boolean isExpired() {
            return this.expired;
        }

        void expire() {
            this.expired = true;
        }

        float getLifetimeProgress() {
            return MathHelper.clamp(
                    (float) (System.currentTimeMillis() - this.createdAtMillis)
                            / this.lifetimeMillis,
                    0.0F,
                    1.0F);
        }

        int randomTurnDelay() {
            return (int) FirefliesModule.randomFloat(300.5, 900.5);
        }

        Vec3d interpolatePosition(float f) {
            return this.position.add(
                    -(this.previousPosition.x - this.position.x) * (double) f,
                    -(this.previousPosition.y - this.position.y) * (double) f,
                    -(this.previousPosition.z - this.position.z) * (double) f);
        }

        float getOpacity() {
            return this.opacity;
        }
    }

    @Environment(EnvType.CLIENT)
    private static class SparkPart {
        double speed = Math.random() / 50.0;
        double previousX;
        double y;
        final float yaw = (float) Math.random() * 360.0F;
        final long createdAtMillis;
        double previousZ;
        final float pitch = -45.0F + (float) Math.random() * 90.0F;
        double previousY;
        double x;
        double z;
        final int lifetimeMillis;

        double interpolateZ(float f) {
            return this.previousZ + (this.z - this.previousZ) * (double) f;
        }

        double interpolateX(float f) {
            return this.previousX + (this.x - this.previousX) * (double) f;
        }

        SparkPart(FirefliesModule.FirePart firePart, int lifetimeMillisValue) {
            this.createdAtMillis = System.currentTimeMillis();
            this.lifetimeMillis = lifetimeMillisValue;
            this.x = firePart.position.x;
            this.y = firePart.position.y;
            this.z = firePart.position.z;
            this.previousX = this.x;
            this.previousY = this.y;
            this.previousZ = this.z;
        }

        double interpolateY(float f) {
            return this.previousY + (this.y - this.previousY) * (double) f;
        }

        double getLifetimeProgress() {
            return (double)
                    MathHelper.clamp(
                            (float) (System.currentTimeMillis() - this.createdAtMillis)
                                    / (float) this.lifetimeMillis,
                            0.0F,
                            1.0F);
        }

        boolean isExpired() {
            return this.getLifetimeProgress() >= 1.0;
        }

        void tick() {
            float f = (float) Math.toRadians((double) this.yaw);
            this.previousX = this.x;
            this.previousY = this.y;
            this.previousZ = this.z;
            this.x = this.x + (double) MathHelper.sin((double) f) * this.speed;
            this.y =
                    this.y
                            + (double)
                                            MathHelper.cos(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    (this.pitch
                                                                                            - 90.0F))))
                                    * this.speed;
            this.z = this.z + (double) MathHelper.cos((double) f) * this.speed;
            this.speed /= 1.2;
        }
    }

    @Environment(EnvType.CLIENT)
    private static class TrailPart {
        final double y;
        final int lifetimeMillis;
        final double x;
        final long createdAtMillis = System.currentTimeMillis();
        final double z;

        TrailPart(FirefliesModule.FirePart firePart, int lifetimeMillisValue) {
            this.lifetimeMillis = lifetimeMillisValue;
            this.x = firePart.position.x;
            this.y = firePart.position.y;
            this.z = firePart.position.z;
        }

        boolean isExpired() {
            return System.currentTimeMillis() - this.createdAtMillis >= (long) this.lifetimeMillis;
        }
    }
}
