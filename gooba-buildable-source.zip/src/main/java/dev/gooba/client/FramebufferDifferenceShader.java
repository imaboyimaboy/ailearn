package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public class FramebufferDifferenceShader {
    private static final Identifier VERTEX_SHADER = Identifier.of("client", "core/mask_diff");

    private boolean initialized = false;
    private GpuBuffer vertexBuffer;
    private static final Identifier PIPELINE_ID = Identifier.of("client", "pipeline/mask_diff");
    private GpuBuffer uniformBuffer;
    private static final Identifier FRAGMENT_SHADER = Identifier.of("client", "core/mask_diff");
    private static final BlendFunction REPLACE_BLEND =
            new BlendFunction(SourceFactor.ONE, DestFactor.ZERO, SourceFactor.ONE, DestFactor.ZERO);
    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(FramebufferDifferenceShader.PIPELINE_ID)
                            .withVertexShader(FramebufferDifferenceShader.FRAGMENT_SHADER)
                            .withFragmentShader(VERTEX_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("MaskData", UniformType.UNIFORM_BUFFER)
                            .withSampler("BeforeSampler")
                            .withSampler("AfterSampler")
                            .withSampler("DepthBeforeSampler")
                            .withSampler("DepthAfterSampler")
                            .withBlend(FramebufferDifferenceShader.REPLACE_BLEND)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private static final Vector3f MODEL_OFFSET = new Vector3f(0.0F, 0.0F, 0.0F);

    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
    private ByteBuffer uniformData;
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);

    private void writeUniforms(int i, int j) {
        this.uniformData.clear();
        this.uniformData.putFloat((float) i);
        this.uniformData.putFloat((float) j);
        this.uniformData.putFloat(0.0F);
        this.uniformData.putFloat(0.0F);
        this.uniformData.flip();
    }

    private void initialize() {
        if (!this.initialized) {
            this.uniformData = MemoryUtil.memAlloc(16);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.vertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:mask_diff_dummy_vertex", 32, bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.initialized = true;
        }
    }

    public void close() {
        if (this.uniformBuffer != null) {
            this.uniformBuffer.close();
            this.uniformBuffer = null;
        }

        if (this.vertexBuffer != null) {
            this.vertexBuffer.close();
            this.vertexBuffer = null;
        }

        if (this.uniformData != null) {
            MemoryUtil.memFree(this.uniformData);
            this.uniformData = null;
        }

        this.initialized = false;
    }

    public void renderMask(
            GpuTextureView gputextureview,
            GpuTextureView gpuTextureView,
            GpuTextureView gpuTextureViewValue,
            GpuTextureView gpuTextureView2,
            GpuTextureView gpuTextureView3,
            int i,
            int j) {
        this.initialize();
        CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
        GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
        GpuSampler gpuSampler = RenderSystem.getSamplerCache().get(FilterMode.NEAREST);
        this.writeUniforms(i, j);
        int k = this.uniformData.remaining();
        if (this.uniformBuffer == null || this.uniformBuffer.size() < (long) k) {
            if (this.uniformBuffer != null) {
                this.uniformBuffer.close();
            }

            this.uniformBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:mask_diff_uniform", 136, (long) k);
        }

        commandencoder.writeToBuffer(this.uniformBuffer.slice(), this.uniformData);
        GpuBufferSlice gpubufferslice =
                RenderSystem.getDynamicUniforms()
                        .write(
                                RenderSystem.getModelViewMatrix(),
                                COLOR_MODULATOR,
                                MODEL_OFFSET,
                                TEXTURE_MATRIX);

        try (RenderPass renderpass =
                commandencoder.createRenderPass(
                        () -> "minecraft:mask_diff_pass", gputextureview, OptionalInt.of(0))) {
            renderpass.setPipeline(PIPELINE);
            renderpass.setVertexBuffer(0, this.vertexBuffer);
            renderpass.bindTexture("BeforeSampler", gpuTextureView, gpusampler);
            renderpass.bindTexture("AfterSampler", gpuTextureViewValue, gpusampler);
            renderpass.bindTexture("DepthBeforeSampler", gpuTextureView2, gpuSampler);
            renderpass.bindTexture("DepthAfterSampler", gpuTextureView3, gpuSampler);
            RenderSystem.bindDefaultUniforms(renderpass);
            renderpass.setUniform("DynamicTransforms", gpubufferslice);
            renderpass.setUniform("MaskData", this.uniformBuffer);
            renderpass.draw(0, 6);
        }
    }
}
