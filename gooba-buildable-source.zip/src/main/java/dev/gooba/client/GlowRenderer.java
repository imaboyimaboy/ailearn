package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public final class GlowRenderer {
    public static void drawCornerBlur(
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float f8,
            int i) {
        drawCornerBlurWithOpacity(f, f1, f2, f3, f4, f5, f6, f7, f8, i, -1.0F);
    }

    public static void drawImage(
            Identifier identifier, float f, float f1, float f2, float f3, int i) {
        int[] aint = new int[] {i, i, i, i};
        float[] afloat = new float[] {0.0F, 0.0F, 0.0F, 0.0F};
        getHudManager()
                .getTextureBatchRenderer()
                .drawAntialiased(
                        identifier, f, f1, f2, f3, 0.0F, 0.0F, 1.0F, 1.0F, aint, afloat, 1.0F);
    }

    public static void drawShadow(
            float innerX,
            float innerY,
            float width,
            float height,
            int color,
            float f4,
            float spread,
            float softness) {
        drawCornerShadow(
                innerX, innerY, width, height, color, f4, f4, f4, f4, spread, softness, 1.0F);
    }

    private GlowRenderer() {}

    private static HudManager getHudManager() {
        return Gooba.getInstance().getHudManager();
    }

    public static void drawCornerGradient(
            float innerX,
            float innerY,
            float width,
            float height,
            int[] aint,
            float f4,
            float f5,
            float f6,
            float f7) {
        float[] afloat = new float[] {f4, f5, f6, f7};
        getHudManager().getRectData().drawRect(innerX, innerY, width, height, aint, afloat);
    }

    public static void drawBlurMask(
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float f8,
            float f9) {
        float[] afloat = new float[] {f5, f6, f7, f8};
        getHudManager().getBlurBatchRenderer().drawLightSweep(f, f1, f2, f3, f4, afloat, f9);
    }

    public static void drawCornerBlurWithOpacity(
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float f8,
            int i,
            float f9) {
        float[] afloat = new float[] {f5, f6, f7, f8};
        BlurBatchRenderer blurBatchRenderer2 = getHudManager().getBlurBatchRenderer();
        if (ThemeColors.isDistortionEnabled()) {
            blurBatchRenderer2.drawGlassRect(
                    f, f1, f2, f3, f4, afloat, i, 125.0F, 75.0F, 0.0F, 0.0F, f9);
        } else {
            blurBatchRenderer2.drawSweepTintedRect(f, f1, f2, f3, f4, afloat, i, f9);
        }
    }

    public static void drawRoundedRegion(
            Identifier identifier,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            int i,
            float f8) {
        int[] aint = new int[] {i, i, i, i};
        float[] afloat = new float[] {f8, f8, f8, f8};
        getHudManager()
                .getTextureBatchRenderer()
                .drawNearest(identifier, f, f1, f2, f3, f4, f5, f6, f7, aint, afloat, 1.0F);
    }

    public static void drawRoundedGradient(
            float innerX, float innerY, float width, float height, int[] aint, float f4) {
        drawCornerGradient(innerX, innerY, width, height, aint, f4, f4, f4, f4);
    }

    public static void drawShadowWithOpacity(
            float innerX,
            float innerY,
            float width,
            float height,
            int color,
            float f4,
            float spread,
            float softness,
            float opacity) {
        drawCornerShadow(
                innerX, innerY, width, height, color, f4, f4, f4, f4, spread, softness, opacity);
    }

    public static void drawRoundedBlur(
            float f, float f1, float f2, float f3, float f4, float f5, int i) {
        drawCornerBlur(f, f1, f2, f3, f4, f5, f5, f5, f5, i);
    }

    public static void drawRoundedRect(
            float innerX, float innerY, float width, float height, int color, float f4) {
        drawCornerRect(innerX, innerY, width, height, color, f4, f4, f4, f4);
    }

    public static void drawCornerOutline(
            float f,
            float f1,
            float width,
            float height,
            float f4,
            int color,
            float f5,
            float f6,
            float f7,
            float f8) {
        int[] aint = ColorUtils.repeatEight(color);
        float[] afloat = new float[] {f4, f4, f4, f4, f4, f4, f4, f4};
        float[] values = new float[] {f5, f6, f7, f8};
        getHudManager()
                .getOutlineData()
                .drawOutline(f, f1, width, height, aint, afloat, values, 1.0F);
    }

    public static void drawCornerShadow(
            float innerX,
            float innerY,
            float width,
            float height,
            int color,
            float f4,
            float f5,
            float f6,
            float f7,
            float spread,
            float softness,
            float opacity) {
        float[] afloat = new float[] {f4, f5, f6, f7};
        getHudManager()
                .getRectData()
                .drawShadow(
                        innerX, innerY, width, height, color, afloat, spread, softness, opacity);
    }

    public static void drawImageRegion(
            Identifier identifier,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            int i,
            float f8,
            float f9) {
        int[] aint = new int[] {i, i, i, i};
        float[] afloat = new float[] {f9, f9, f9, f9};
        getHudManager()
                .getTextureBatchRenderer()
                .draw(identifier, f, f1, f2, f3, f4, f5, f6, f7, aint, afloat, f8);
    }

    public static void drawRoundedOutline(
            float f, float f1, float width, float height, float f4, int color, float f5) {
        drawCornerOutline(f, f1, width, height, f4, color, f5, f5, f5, f5);
    }

    public static void drawRect(float innerX, float innerY, float width, float height, int color) {
        drawRoundedRect(innerX, innerY, width, height, color, 0.0F);
    }

    public static void drawCornerRect(
            float innerX,
            float innerY,
            float width,
            float height,
            int color,
            float f4,
            float f5,
            float f6,
            float f7) {
        int[] aint = ColorUtils.repeatNine(color);
        float[] afloat = new float[] {f4, f5, f6, f7};
        getHudManager().getRectData().drawRect(innerX, innerY, width, height, aint, afloat);
    }
}
