package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

@ModuleInfo(
        name = "Fast Place",
        category = ModuleCategory.OTHER,
        desc = "Allows you to place blocks and use items at high speeds.")
@Environment(EnvType.CLIENT)
public class FastPlaceModule extends Module {
    public final BooleanSetting xPSetting;
    public final BooleanSetting blocksSetting = new BooleanSetting(this, "Blocks", true);
    public final SliderSetting delaySetting;

    public int getUseDelay(ItemStack itemstack) {
        if (itemstack == null || itemstack.isEmpty()) {
            return 4;
        } else if (client.player != null && itemstack.getMaxUseTime(client.player) > 0) {
            return 4;
        } else if (this.blocksSetting.isOn() && itemstack.getItem() instanceof BlockItem) {
            return Math.round(this.delaySetting.getFloat());
        } else {
            return this.xPSetting.isOn() && itemstack.isOf(Items.EXPERIENCE_BOTTLE)
                    ? Math.round(this.delaySetting.getFloat())
                    : 4;
        }
    }

    public FastPlaceModule() {
        this.xPSetting = new BooleanSetting(this, "XP", true);
        this.delaySetting = new SliderSetting(this, "Delay", 0.0F, 0.0F, 4.0F, 1.0F);
    }
}
