package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import java.nio.ByteBuffer;

@Environment(EnvType.CLIENT)
public class OutlineData extends UniformBatchRenderer {

    private static final Identifier VERTEX_SHADER = Identifier.of("client", "core/outline");
    private static final Identifier FRAGMENT_SHADER = Identifier.of("client", "core/outline");
    private static final Identifier PIPELINE_ID = Identifier.of("client", "pipeline/outline");
    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(OutlineData.PIPELINE_ID)
                            .withVertexShader(VERTEX_SHADER)
                            .withFragmentShader(FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("OutlineData", UniformType.UNIFORM_BUFFER)
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());

    public OutlineData() {
        super("outline", PIPELINE, "OutlineData", 64, 208, 32);
    }

    public void drawOutline(
            float f,
            float f1,
            float width,
            float height,
            int[] aint,
            float[] afloat,
            float[] values,
            float opacity) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient.getFramebuffer() != null) {
            ByteBuffer bytebuffer = this.beginInstance();
            bytebuffer.putFloat(f);
            bytebuffer.putFloat(f1);
            bytebuffer.putFloat(width);
            bytebuffer.putFloat(height);
            bytebuffer.putFloat(values[0]);
            bytebuffer.putFloat(values[1]);
            bytebuffer.putFloat(values[2]);
            bytebuffer.putFloat(values[3]);

            for (int i = 0; i < 8; i++) {
                int j = i < aint.length ? aint[i] : aint[aint.length - 1];
                float f5 = (float) (j >> 24 & 0xFF) / 255.0F;
                float f6 = (float) (j >> 16 & 0xFF) / 255.0F;
                float f7 = (float) (j >> 8 & 0xFF) / 255.0F;
                float f8 = (float) (j & 0xFF) / 255.0F;
                bytebuffer.putFloat(f6);
                bytebuffer.putFloat(f7);
                bytebuffer.putFloat(f8);
                bytebuffer.putFloat(f5);
            }

            for (int k = 0; k < 8; k++) {
                float f9 = k < afloat.length ? afloat[k] : afloat[afloat.length - 1];
                bytebuffer.putFloat(f9);
            }

            bytebuffer.putFloat(opacity);
            bytebuffer.putFloat(0.0F);
            bytebuffer.putFloat(0.0F);
            bytebuffer.putFloat(0.0F);
            this.finishInstance();
        }
    }

    @Override
    public int getSortOrder() {
        return 1;
    }
}
