package dev.gooba.client;

import dev.gooba.client.mixin.InputMixin;
import dev.gooba.client.mixin.KeyBindingMixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.InputUtil.Key;
import net.minecraft.client.world.ClientChunkManager;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;

@ModuleInfo(
        name = "Freecam",
        category = ModuleCategory.OTHER,
        desc = "Detached camera (WASD = fly).")
@Environment(EnvType.CLIENT)
public class FreecamModule extends Module {
    private double previousCameraZ;
    private double cameraX;
    private boolean previousChunkCulling;
    private double lastMouseY;
    private float originalYaw;
    public final BooleanSetting smoothingSetting;
    private boolean originalSneaking;
    public final BooleanSetting sneakWhileMiningSetting;
    private int chunkLoadDistance;
    private static FreecamModule instance;
    private float originalPitch;
    public final SliderSetting verticalSpeedSetting;
    private float cameraYaw;
    private boolean sentSneaking;
    private double cameraZ;
    public final BooleanSetting showHandsSetting;
    public final BooleanSetting showOwnBodySetting;
    private boolean mouseInitialized;
    private double movementSpeed;
    private double originalPlayerX;
    private boolean initializationPending;
    private float cameraPitch;
    public final SliderSetting lookSensitivitySetting;

    private boolean active;
    private double lastMouseX;
    private float previousCameraPitch;
    private double cameraY;
    private double originalPlayerY;
    private double previousCameraX;
    private double originalPlayerZ;
    private float previousCameraYaw;
    private ChunkPos chunkMapCenter;
    public final SliderSetting speedSetting =
            new SliderSetting(this, "Speed", 2.0F, 0.1F, 50.0F, 0.1F);
    public final SliderSetting chunkDistanceSetting;
    private double previousCameraY;
    private boolean originalFlying;

    public void adjustSpeed(double d0) {
        if (d0 != 0.0) {
            double minValue = (double) this.speedSetting.minValue;
            double maxValue = (double) this.speedSetting.maxValue;
            this.movementSpeed =
                    Math.max(
                            minValue,
                            Math.min(maxValue, this.movementSpeed + Math.signum(d0) * 0.5));
        }
    }

    @Override
    protected void onEnable() {
        this.initializationPending = true;
        this.active = false;
        this.mouseInitialized = false;
    }

    private boolean isSprintKeyDown() {
        Key key = ((KeyBindingMixin) client.options.sprintKey).goobaa$getBoundKey();
        return key.getCode() >= 0 && InputUtil.isKeyPressed(client.getWindow(), key.getCode());
    }

    public FreecamModule() {
        this.verticalSpeedSetting =
                new SliderSetting(this, "Vertical Speed", 1.0F, 0.2F, 5.0F, 0.05F);
        this.smoothingSetting = new BooleanSetting(this, "Smoothing", true);
        this.showOwnBodySetting = new BooleanSetting(this, "Show Own Body", true);
        this.showHandsSetting = new BooleanSetting(this, "Show Hands", true);
        this.sneakWhileMiningSetting = new BooleanSetting(this, "Sneak While Mining", false);
        this.lookSensitivitySetting =
                new SliderSetting(this, "Look Sensitivity", 0.5F, 0.1F, 2.0F, 0.05F);
        this.chunkDistanceSetting =
                new SliderSetting(this, "Chunk Distance", 12.0F, 2.0F, 32.0F, 1.0F);
        this.chunkLoadDistance = Integer.MIN_VALUE;
        instance = this;
    }

    public static FreecamModule getInstance() {
        return instance;
    }

    public void freezePlayerInput(ClientPlayerEntity clientplayerentity) {
        boolean sentSneakingValue;
        sentSneakingValue =
                (this.isSneakKeyDown()
                        || this.sneakWhileMiningSetting.isOn()
                                && client.options.attackKey.isPressed());

        this.sendSneaking(sentSneakingValue);
        clientplayerentity.input.playerInput =
                new PlayerInput(false, false, false, false, false, sentSneakingValue, false);
        ((InputMixin) clientplayerentity.input).goobaa$setMovementVector(new Vec2f(0.0F, 0.0F));
        clientplayerentity.setSneaking(sentSneakingValue);
    }

    public double interpolatedX(float f) {
        return MathHelper.lerp((double) f, this.previousCameraX, this.cameraX);
    }

    public boolean shouldShowHands() {
        return !this.isActive() || this.showHandsSetting.isOn();
    }

    public void setCameraRotation(float cameraYawValue, float f1) {
        this.cameraYaw = cameraYawValue;
        this.cameraPitch = MathHelper.clamp(f1, -90.0F, 90.0F);
    }

    public float interpolatedPitch(float f) {
        return MathHelper.lerp(f, this.previousCameraPitch, this.cameraPitch);
    }

    public Vec3d interpolatedPosition(float f) {
        return new Vec3d(this.interpolatedX(f), this.interpolatedY(f), this.interpolatedZ(f));
    }

    @Override
    protected void onDisable() {
        boolean activeValue = this.active;
        this.initializationPending = this.active = false;
        this.mouseInitialized = false;
        client.chunkCullingEnabled = this.previousChunkCulling;
        if (client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }

        this.restoreChunkLoading();
        if (activeValue && client.player != null) {
            this.sendSneaking(this.originalSneaking);
            client.player.setYaw(this.originalYaw);
            client.player.setPitch(this.originalPitch);
            client.player.setSneaking(this.originalSneaking);
            client.player.getAbilities().flying = this.originalFlying;
        }

        client.mouse.setResolutionChanged();
    }

    public float interpolatedYaw(float f) {
        return MathHelper.lerp(f, this.previousCameraYaw, this.cameraYaw);
    }

    private void restoreChunkLoading() {
        this.chunkMapCenter = null;
        this.chunkLoadDistance = Integer.MIN_VALUE;
        if (client.world != null) {
            ClientChunkManager clientchunkmanager = client.world.getChunkManager();
            if (client.player != null) {
                ChunkPos chunkpos = client.player.getChunkPos();
                clientchunkmanager.setChunkMapCenter(chunkpos.x, chunkpos.z);
            }

            clientchunkmanager.updateLoadDistance(client.options.getClampedViewDistance());
            if (client.worldRenderer != null) {
                client.worldRenderer.scheduleTerrainUpdate();
            }
        }
    }

    public boolean isActive() {
        return this.isEnabled() && this.active;
    }

    private void initializeCamera() {
        if (this.initializationPending && client.player != null && client.world != null) {
            ClientPlayerEntity clientplayerentity = client.player;
            this.movementSpeed = (double) this.speedSetting.getFloat().floatValue();
            this.originalPlayerX = clientplayerentity.getX();
            this.originalPlayerY = clientplayerentity.getY();
            this.originalPlayerZ = clientplayerentity.getZ();
            this.originalYaw = clientplayerentity.getYaw();
            this.originalPitch = clientplayerentity.getPitch();
            this.originalSneaking = clientplayerentity.isSneaking();
            this.sentSneaking = this.originalSneaking;
            this.cameraX = this.previousCameraX = clientplayerentity.getX();
            this.cameraY =
                    this.previousCameraY =
                            clientplayerentity.getY()
                                    + (double) clientplayerentity.getStandingEyeHeight();
            this.cameraZ = this.previousCameraZ = clientplayerentity.getZ();
            this.cameraYaw = this.previousCameraYaw = clientplayerentity.getYaw();
            this.cameraPitch = this.previousCameraPitch = clientplayerentity.getPitch();
            this.originalFlying = clientplayerentity.getAbilities().flying;
            this.previousChunkCulling = client.chunkCullingEnabled;
            this.initializationPending = false;
            this.active = true;
            this.chunkMapCenter = null;
            this.chunkLoadDistance = Integer.MIN_VALUE;
            client.chunkCullingEnabled = false;
            this.updateChunkLoading();
        }
    }

    private void updateChunkLoading() {
        if (this.active && client.world != null && client.player != null) {
            ClientChunkManager clientchunkmanager = client.world.getChunkManager();
            ChunkPos chunkpos =
                    new ChunkPos(
                            (int) Math.floor(this.cameraX) >> 4,
                            (int) Math.floor(this.cameraZ) >> 4);
            ChunkPos chunkPosValue = client.player.getChunkPos();
            ChunkPos chunkposValue = chunkpos;
            int i =
                    Math.max(
                            Math.abs(chunkpos.x - chunkPosValue.x),
                            Math.abs(chunkpos.z - chunkPosValue.z));
            int j;
            int k;
            if (i + 4 > 32) {
                chunkposValue =
                        new ChunkPos(
                                (chunkpos.x + chunkPosValue.x) / 2,
                                (chunkpos.z + chunkPosValue.z) / 2);
                j =
                        Math.max(
                                        Math.max(
                                                Math.abs(chunkposValue.x - chunkpos.x),
                                                Math.abs(chunkposValue.z - chunkpos.z)),
                                        Math.max(
                                                Math.abs(chunkposValue.x - chunkPosValue.x),
                                                Math.abs(chunkposValue.z - chunkPosValue.z)))
                                + 4;
                k = Math.min(32, Math.max(2, this.chunkDistanceSetting.getFloat().intValue()));
            } else {
                j =
                        Math.max(
                                        Math.max(
                                                Math.abs(chunkpos.x - chunkpos.x),
                                                Math.abs(chunkpos.z - chunkpos.z)),
                                        Math.max(
                                                Math.abs(chunkpos.x - chunkPosValue.x),
                                                Math.abs(chunkpos.z - chunkPosValue.z)))
                                + 4;
                k = Math.min(32, Math.max(2, this.chunkDistanceSetting.getFloat().intValue()));
            }

            int chunkLoadDistanceValue = Math.min(32, Math.max(k, j));
            if (chunkLoadDistanceValue != this.chunkLoadDistance) {
                clientchunkmanager.updateLoadDistance(chunkLoadDistanceValue);
                this.chunkLoadDistance = chunkLoadDistanceValue;
            }

            if (!chunkposValue.equals(this.chunkMapCenter)) {
                clientchunkmanager.setChunkMapCenter(chunkposValue.x, chunkposValue.z);
                this.chunkMapCenter = chunkposValue;
                if (client.worldRenderer != null) {
                    client.worldRenderer.scheduleTerrainUpdate();
                }
            }
        }
    }

    private void sendSneaking(boolean sentSneakingValue) {
        if (client.player != null
                && client.getNetworkHandler() != null
                && this.sentSneaking != sentSneakingValue) {
            client.getNetworkHandler()
                    .sendPacket(
                            new PlayerInputC2SPacket(
                                    new PlayerInput(
                                            false,
                                            false,
                                            false,
                                            false,
                                            false,
                                            sentSneakingValue,
                                            false)));
            this.sentSneaking = sentSneakingValue;
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        this.initializeCamera();
        if (this.active && client.player != null) {
            this.freezePlayerInput(client.player);
            client.player.setVelocity(0.0, client.player.getVelocity().y, 0.0);
            this.previousCameraX = this.cameraX;
            this.previousCameraY = this.cameraY;
            this.previousCameraZ = this.cameraZ;
            this.previousCameraYaw = this.cameraYaw;
            this.previousCameraPitch = this.cameraPitch;
            GameOptions gameoptions = client.options;
            double d0 =
                    (double)
                            ((gameoptions.forwardKey.isPressed() ? 1 : 0)
                                    - (gameoptions.backKey.isPressed() ? 1 : 0));
            double d1 =
                    (double)
                            ((gameoptions.leftKey.isPressed() ? 1 : 0)
                                    - (gameoptions.rightKey.isPressed() ? 1 : 0));
            double d2 =
                    (double)
                            ((gameoptions.jumpKey.isPressed() ? 1 : 0)
                                    - (gameoptions.sneakKey.isPressed() ? 1 : 0));
            double d3 = this.isSprintKeyDown() ? 1.25 : 1.0;
            double d4 = this.movementSpeed * d3;
            double d5 = Math.toRadians((double) this.cameraYaw);
            double d6 = d4 * (this.smoothingSetting.isOn() ? 0.5 : 1.0);
            this.cameraX = this.cameraX + (-Math.sin(d5) * d0 + Math.cos(d5) * d1) * d6;
            this.cameraY =
                    this.cameraY
                            + d2
                                    * d4
                                    * (double) this.verticalSpeedSetting.getFloat().floatValue()
                                    * (this.smoothingSetting.isOn() ? 0.5 : 1.0);
            this.cameraZ = this.cameraZ + (Math.cos(d5) * d0 + Math.sin(d5) * d1) * d6;
            this.updateChunkLoading();
        }
    }

    private boolean isSneakKeyDown() {
        Key key = ((KeyBindingMixin) client.options.sneakKey).goobaa$getBoundKey();
        return key.getCode() >= 0 && InputUtil.isKeyPressed(client.getWindow(), key.getCode());
    }

    public double interpolatedZ(float f) {
        return MathHelper.lerp((double) f, this.previousCameraZ, this.cameraZ);
    }

    public void onMousePosition(double lastMouseXValue, double lastMouseYValue) {
        if (!this.mouseInitialized) {
            this.lastMouseX = lastMouseXValue;
            this.lastMouseY = lastMouseYValue;
            this.mouseInitialized = true;
        } else {
            double d2 = lastMouseXValue - this.lastMouseX;
            double d3 = lastMouseYValue - this.lastMouseY;
            this.lastMouseX = lastMouseXValue;
            this.lastMouseY = lastMouseYValue;
            if (!(Math.abs(d2) > 200.0) && !(Math.abs(d3) > 200.0)) {
                this.setCameraRotation(
                        this.cameraYaw + (float) (d2 * (double) this.getLookSensitivity() * 0.15),
                        this.cameraPitch
                                + (float) (d3 * (double) this.getLookSensitivity() * 0.15));
            }
        }
    }

    public double interpolatedY(float f) {
        return MathHelper.lerp((double) f, this.previousCameraY, this.cameraY);
    }

    public float getLookSensitivity() {
        return this.lookSensitivitySetting.getFloat();
    }

    public boolean shouldShowOwnBody() {
        return this.showOwnBodySetting.isOn();
    }
}
