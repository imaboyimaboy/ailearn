package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public final class EntityRaycast implements MinecraftAccess {
    public static Vec3d rotationVector(float f, float f1) {
        float f2 = -f1 * (float) (Math.PI / 180.0) - (float) Math.PI;
        float f3 = -f * (float) (Math.PI / 180.0);
        float f4 = MathHelper.cos((double) f2);
        float f5 = MathHelper.sin((double) f2);
        float f6 = -MathHelper.cos((double) f3);
        float f7 = MathHelper.sin((double) f3);
        return new Vec3d((double) (f5 * f6), (double) f7, (double) (f4 * f6));
    }

    public static boolean intersectsTarget(float f, float f1, double d0, Entity entity) {
        float tickProgress = client.getRenderTickCounter().getTickProgress(true);
        Vec3d vec3d = client.player.getCameraPosVec(tickProgress);
        Vec3d vec3d1 = rotationVector(f1, f);
        Vec3d vec3d2 = vec3d.add(vec3d1.multiply(d0));
        if (client.player != null
                && client.player.isGliding()
                && (double) entity.distanceTo(entity) > d0 * 3.0) {
            return true;
        } else {
            Box box = entity.getBoundingBox();
            return box.contains(vec3d) || box.raycast(vec3d, vec3d2).isPresent();
        }
    }

    private EntityRaycast() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    private static boolean isRaycastTarget(Entity entity) {
        return !entity.isSpectator() && entity.isAlive() && entity.canHit();
    }
}
