package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;

@Environment(EnvType.CLIENT)
public final class MovementUtils implements MinecraftAccess {
    public static double movementYawRadians(float f, float f1, float f2) {
        if (f1 < 0.0F) {
            f += 180.0F;
        }

        float f3 = 1.0F;
        if (f1 < 0.0F) {
            f3 = -0.5F;
        }

        if (f1 > 0.0F) {
            f3 = 0.5F;
        }

        if (f2 > 0.0F) {
            f -= 90.0F * f3;
        }

        if (f2 < 0.0F) {
            f += 90.0F * f3;
        }

        return Math.toRadians((double) f);
    }

    public static void correctMovementInput(
            MovementInputEvent movementInputEvent, float f, float f1) {
        float forward = movementInputEvent.getForward();
        float strafe = movementInputEvent.getStrafe();
        double d0;
        if (client.player.isGliding()) {
            d0 = MathHelper.wrapDegrees(Math.toDegrees(movementYawRadians(f, forward, strafe)));
        } else {
            d0 = MathHelper.wrapDegrees(Math.toDegrees(movementYawRadians(f1, forward, strafe)));
        }

        if (forward != 0.0F || strafe != 0.0F) {
            float forwardValue = 0.0F;
            float strafeValue = 0.0F;
            float MAX_VALUE = Float.MAX_VALUE;

            for (float forwardValueValue = -1.0F; forwardValueValue <= 1.0F; forwardValueValue++) {
                for (float strafeValueValue = -1.0F; strafeValueValue <= 1.0F; strafeValueValue++) {
                    if (strafeValueValue != 0.0F || forwardValueValue != 0.0F) {
                        double d1 =
                                MathHelper.wrapDegrees(
                                        Math.toDegrees(
                                                movementYawRadians(
                                                        f, forwardValueValue, strafeValueValue)));
                        double d2 = Math.abs(d0 - d1);
                        if (d2 < (double) MAX_VALUE) {
                            MAX_VALUE = (float) d2;
                            forwardValue = forwardValueValue;
                            strafeValue = strafeValueValue;
                        }
                    }
                }
            }

            movementInputEvent.setForward(forwardValue);
            movementInputEvent.setStrafe(strafeValue);
        }
    }

    private MovementUtils() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static void setHorizontalSpeed(double d0) {
        if (client.player != null) {
            float yaw = client.player.getYaw();
            double d1 = Math.toRadians((double) yaw);
            double d2 = 0.0;
            double d3 = 0.0;
            Vec2f vec2f = client.player.input.getMovementInput();
            float f1 = vec2f.y;
            float f2 = vec2f.x;
            if (f1 > 0.0F) {
                d2 -= Math.sin(d1) * d0;
                d3 += Math.cos(d1) * d0;
            }

            if (f1 < 0.0F) {
                d2 += Math.sin(d1) * d0;
                d3 -= Math.cos(d1) * d0;
            }

            if (f2 > 0.0F) {
                d2 += Math.cos(d1) * d0;
                d3 += Math.sin(d1) * d0;
            }

            if (f2 < 0.0F) {
                d2 -= Math.cos(d1) * d0;
                d3 -= Math.sin(d1) * d0;
            }

            if (f2 > 0.0F && f1 > 0.0F) {
                d2 = Math.cos(Math.toRadians((double) (yaw + 45.0F))) * d0;
                d3 = Math.sin(Math.toRadians((double) (yaw + 45.0F))) * d0;
            }

            if (f2 < 0.0F && f1 > 0.0F) {
                d2 = -Math.cos(Math.toRadians((double) (yaw - 45.0F))) * d0;
                d3 = -Math.sin(Math.toRadians((double) (yaw - 45.0F))) * d0;
            }

            if (f2 > 0.0F && f1 < 0.0F) {
                d2 = -Math.cos(Math.toRadians((double) (yaw + 135.0F))) * d0;
                d3 = -Math.sin(Math.toRadians((double) (yaw + 135.0F))) * d0;
            }

            if (f2 < 0.0F && f1 < 0.0F) {
                d2 = Math.cos(Math.toRadians((double) (yaw - 135.0F))) * d0;
                d3 = Math.sin(Math.toRadians((double) (yaw - 135.0F))) * d0;
            }

            client.player.setVelocity(d2, client.player.getVelocity().y, d3);
        }
    }
}
