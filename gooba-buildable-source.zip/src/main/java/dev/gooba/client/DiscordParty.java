package dev.gooba.client;

import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FieldOrder({"id", "size"})
@Environment(EnvType.CLIENT)
public class DiscordParty extends Structure {
    public byte[] id = new byte[128];

    public DiscordPartySize size = new DiscordPartySize();
}
