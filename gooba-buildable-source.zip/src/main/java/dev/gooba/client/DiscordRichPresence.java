package dev.gooba.client;

import com.sun.jna.Structure;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Arrays;
import java.util.List;

@Environment(EnvType.CLIENT)
public class DiscordRichPresence extends Structure {
    public String button_label_2;
    public String details;
    public int partyMax;
    public String joinSecret;
    public byte instance;
    public long endTimestamp;
    public String matchSecret;
    public String spectateSecret;
    public String largeImageKey;
    public long startTimestamp;
    public String smallImageText;
    public String state;
    public String button_url_2;
    public String partyId;
    public String button_label_1;

    public String largeImageText;
    public int partySize;
    public int partyPrivacy;
    public String smallImageKey;
    public String button_url_1;

    protected List<String> getFieldOrder() {
        return Arrays.asList(
                "state",
                "details",
                "startTimestamp",
                "endTimestamp",
                "largeImageKey",
                "largeImageText",
                "smallImageKey",
                "smallImageText",
                "partyId",
                "partySize",
                "partyMax",
                "partyPrivacy",
                "matchSecret",
                "joinSecret",
                "spectateSecret",
                "button_label_1",
                "button_url_1",
                "button_label_2",
                "button_url_2",
                "instance");
    }

    public DiscordRichPresence() {
        this.setStringEncoding("UTF-8");
    }
}
