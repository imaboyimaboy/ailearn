package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;

import org.joml.Vector2f;

@ModuleInfo(
        name = "HUD",
        desc = "Configures draggable HUD elements, colors, scale, opacity, and notifications",
        category = ModuleCategory.CLIENT,
        autoEnabled = true)
@Environment(EnvType.CLIENT)
public class HUDModule extends Module {
    private final ArmorHud armorHud;
    public SliderSetting hudSizeSetting;
    public PositionSetting coordinatesSetting;
    public BooleanSetting lightSweepSetting;
    public PositionSetting regionMapSetting;
    public PositionSetting arrayListSetting;
    public PositionSetting notificationsSetting;
    public SliderSetting regionMapLabelSizeSetting;
    public PositionSetting targetHUDSetting;
    private final CooldownsHud cooldownsHud;
    public BooleanSetting modulesSetting;
    public ModeSetting notificationTypeSetting;
    public SliderSetting regionMapPlayerSizeSetting;
    public SliderSetting regionMapCellSizeSetting;
    public BooleanSetting alwaysShowSetting;
    public PositionSetting keybindsSetting;
    public ColorSetting moduleCardsSetting;
    public PositionSetting staffListSetting;
    private final ServerNavigationHud serverNavigationHud;
    private final CoordinatesHud coordinatesHud;
    public BooleanSetting effectsSetting;
    public SliderSetting notificationVolumeSetting;
    public SliderSetting regionMapOpacitySetting;
    private final NotificationsHud notificationsHud;
    private final ModuleListHud moduleListHud;
    public MultiBooleanSetting elementsSetting =
            new MultiBooleanSetting(
                    this,
                    "Elements",
                    new BooleanSetting[] {
                        new BooleanSetting("Watermark", true),
                        new BooleanSetting("Coordinates", true),
                        new BooleanSetting("Keybinds", true),
                        new BooleanSetting("Potions", true),
                        new BooleanSetting("Staff List", true),
                        new BooleanSetting("Cooldowns", true),
                        new BooleanSetting("Array List", true),
                        new BooleanSetting("Notifications", true),
                        new BooleanSetting("RegionMap", false),
                        new BooleanSetting("Target HUD", true),
                        new BooleanSetting("Armor HUD", true)
                    });
    public ColorSetting clientColorSetting;
    public PositionSetting cooldownsSetting;
    private long lightSweepStartedMillis;
    public PositionSetting watermarkSetting;
    private final PotionEffectsHud potionEffectsHud;
    public PositionSetting armorHUDSetting;
    public ColorSetting backgroundColorSetting;
    private final StaffHud staffHud;
    private final WatermarkHud watermarkHud;
    public PositionSetting potionsSetting;
    public BooleanSetting armorSetting;
    private final TargetHud targetHud;
    private final KeybindsHud keybindsHud;
    public SliderSetting lightSweepSpeedSetting;
    public MultiBooleanSetting regionMapDisplaySetting =
            new MultiBooleanSetting(
                            this,
                            "RegionMap Display",
                            new BooleanSetting[] {
                                new BooleanSetting("Coordinates", true),
                                new BooleanSetting("Region Labels", true),
                                new BooleanSetting("Grid", true),
                                new BooleanSetting("Player Indicator", true),
                                new BooleanSetting("Advanced Map", false)
                            })
                    .visibleWhen(() -> this.elementsSetting.isOn("RegionMap"));
    private boolean lightSweepStarted;

    public int getAccentColor(float f) {
        return ColorUtils.multiplyAlpha(
                this.clientColorSetting.getColor(), Math.max(0.0F, Math.min(1.0F, f)));
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (client.player != null && client.world != null && this.isEnabled()) {
            if (this.elementsSetting.isOn("Notifications")) {
                this.notificationsHud.updateNotifications(
                        this.modulesSetting, this.armorSetting, this.effectsSetting);
            }
        }
    }

    public int getBackgroundColor(float f) {
        float opacity = Math.max(0.0F, Math.min(1.0F, this.getBackgroundOpacity() * f));
        return ColorUtils.withOpacity(this.backgroundColorSetting.getColor(), opacity);
    }

    public void drawRoundedBackground(
            float innerX, float innerY, float f2, float f3, float radius, int color) {
        if (!(f2 <= 0.0F) && !(f3 <= 0.0F)) {
            RenderUtils.Render2D.drawRoundedRect(
                    innerX, innerY, f2 + 0.5F, f3 + 0.25F, color, radius);
        }
    }

    public void drawTintedBlur(
            float innerX, float innerY, float width, float height, float f4, float f5, int color) {
        this.drawCornerBlur(innerX, innerY, width, height, f4, f4, f4, f4, f5, color);
    }

    private void initializePositions() {
        float f = 2.0F / (float) client.getWindow().getScaleFactor();
        float f1 = (float) client.getWindow().getScaledWidth() / f;
        float f2 = (float) client.getWindow().getScaledHeight() / f;
        float f3 = 0.0F;
        if (this.elementsSetting.isOn("Watermark") && isPositionUnset(this.watermarkSetting)) {
            setPosition(this.watermarkSetting, f3, f3);
        }

        if (this.elementsSetting.isOn("Coordinates") && isPositionUnset(this.coordinatesSetting)) {
            setPosition(this.coordinatesSetting, f3, f2 - this.coordinatesSetting.size.y - f3);
        }

        if (this.elementsSetting.isOn("Keybinds") && isPositionUnset(this.keybindsSetting)) {
            setPosition(this.keybindsSetting, 20.0F, 40.0F);
        }

        if (this.elementsSetting.isOn("Cooldowns") && isPositionUnset(this.cooldownsSetting)) {
            setPosition(this.cooldownsSetting, 20.0F, 170.0F);
        }

        if (this.elementsSetting.isOn("Staff List") && isPositionUnset(this.staffListSetting)) {
            setPosition(this.staffListSetting, 20.0F, 105.0F);
        }

        if (this.elementsSetting.isOn("Potions") && isPositionUnset(this.potionsSetting)) {
            setPosition(
                    this.potionsSetting,
                    f1 - this.potionsSetting.size.x,
                    f2 - this.potionsSetting.size.y);
        }

        if (this.elementsSetting.isOn("Array List") && isPositionUnset(this.arrayListSetting)) {
            setPosition(this.arrayListSetting, f1 - this.arrayListSetting.size.x, 0.0F);
        }

        if (this.elementsSetting.isOn("Target HUD") && isPositionUnset(this.targetHUDSetting)) {
            setPosition(this.targetHUDSetting, 100.0F, 130.0F);
        }

        if (this.elementsSetting.isOn("Armor HUD") && isPositionUnset(this.armorHUDSetting)) {
            float f4 = Math.min(f1 - this.armorHUDSetting.size.x - f3, f1 * 0.5F + 124.0F);
            setPosition(this.armorHUDSetting, f4, f2 - this.armorHUDSetting.size.y - 2.0F);
        }

        if (this.elementsSetting.isOn("Notifications")
                && isPositionUnset(this.notificationsSetting)) {
            setPosition(
                    this.notificationsSetting,
                    (f1 - this.notificationsSetting.size.x) * 0.5F,
                    2.0F);
        }

        if (this.elementsSetting.isOn("RegionMap") && isPositionUnset(this.regionMapSetting)) {
            setPosition(this.regionMapSetting, 10.0F, 90.0F);
        }
    }

    public void drawLightSweep(float f, float f1, float f2, float f3, float f4, float f5) {
        if (!(f2 <= 0.0F) && !(f3 <= 0.0F) && !(f5 <= 0.0F)) {
            float lightSweepProgress = this.getLightSweepProgress();
            if (!(lightSweepProgress < 0.0F)) {
                RenderUtils.Blur.drawCornerBlur(
                        f,
                        f1,
                        f2,
                        f3,
                        Math.max(0.0F, Math.min(1.0F, f5)),
                        f4,
                        f4,
                        f4,
                        f4,
                        lightSweepProgress);
            }
        }
    }

    public void drawCornerBlur(
            float innerX,
            float innerY,
            float width,
            float height,
            float f4,
            float f5,
            float f6,
            float f7,
            float f8,
            int color) {
        if (!(width <= 0.0F) && !(height <= 0.0F) && !(f8 <= 0.0F) && color >>> 24 != 0) {
            float factor = Math.max(0.0F, Math.min(1.0F, f8));
            Gooba.getInstance()
                    .getHudManager()
                    .getBlurBatchRenderer()
                    .drawTintedRect(
                            innerX,
                            innerY,
                            width,
                            height,
                            factor,
                            new float[] {f4, f5, f6, f7},
                            color,
                            0.8F);
        }
    }

    public static HUDModule getInstance() {
        return (HUDModule) ModuleLookup.getModule(HUDModule.class);
    }

    private float getLightSweepProgress() {
        if (!this.lightSweepSetting.isOn()) {
            this.lightSweepStarted = false;
            return -1.0F;
        } else {
            long nowMillis = System.currentTimeMillis();
            if (!this.lightSweepStarted) {
                this.lightSweepStarted = true;
                this.lightSweepStartedMillis = nowMillis;
            }

            long j =
                    Math.max(
                            1L, (long) Math.round(700.0F / this.lightSweepSpeedSetting.getFloat()));
            long k = (nowMillis - this.lightSweepStartedMillis) % (j + 2000L);
            return k >= j ? -1.0F : (float) k / (float) j;
        }
    }

    public float getBackgroundOpacity() {
        return (float) ColorUtils.alpha(this.backgroundColorSetting.getColor()) / 255.0F;
    }

    public void drawBackground(
            float innerX, float innerY, float width, float height, float f4, float f5) {
        this.drawTintedBlur(innerX, innerY, width, height, f4, f5, this.getTintedBackgroundColor());
    }

    public void renderRegionMap() {
        if (client.player != null
                && client.world != null
                && this.isEnabled()
                && this.elementsSetting.isOn("RegionMap")) {
            this.serverNavigationHud.render(this.regionMapSetting, this);
        }
    }

    private static boolean isPositionUnset(PositionSetting positionSetting2) {
        return positionSetting2.position.x < 0.0F || positionSetting2.position.y < 0.0F;
    }

    private static void setPosition(PositionSetting positionSetting2, float f, float f1) {
        float f2 = Math.max(0.0F, f);
        float f3 = Math.max(0.0F, f1);
        positionSetting2.position.set(f2, f3);
        positionSetting2.targetPosition.set(f2, f3);
        positionSetting2.xAnimation.snapTo((double) f2);
        positionSetting2.yAnimation.snapTo((double) f3);
    }

    public int getTintedBackgroundColor() {
        int integer = this.backgroundColorSetting.getColor();
        int integerValue = this.clientColorSetting.getColor();
        int k =
                ColorUtils.interpolateAwt(
                        integer, integerValue, (float) (integerValue >>> 24) / 255.0F * 0.25F);
        return integer & 0xFF000000 | k & 16777215;
    }

    public HUDModule() {
        this.regionMapCellSizeSetting =
                new SliderSetting(this, "RegionMap Cell Size", 22.0F, 12.0F, 30.0F, 1.0F)
                        .visibleWhen(() -> this.elementsSetting.isOn("RegionMap"));
        this.regionMapOpacitySetting =
                new SliderSetting(this, "RegionMap Opacity", 0.75F, 0.1F, 1.0F, 0.05F)
                        .visibleWhen(() -> this.elementsSetting.isOn("RegionMap"));
        this.regionMapLabelSizeSetting =
                new SliderSetting(this, "RegionMap Label Size", 0.9F, 0.5F, 1.5F, 0.05F)
                        .visibleWhen(() -> this.elementsSetting.isOn("RegionMap"));
        this.regionMapPlayerSizeSetting =
                new SliderSetting(this, "RegionMap Player Size", 9.0F, 5.0F, 20.0F, 0.5F)
                        .visibleWhen(
                                () ->
                                        (this.elementsSetting.isOn("RegionMap")
                                                && this.regionMapDisplaySetting.isOn(
                                                        "Player Indicator")));
        this.notificationVolumeSetting =
                new SliderSetting(this, "Notification volume", 0.5F, 0.1F, 1.0F, 0.1F);
        this.notificationTypeSetting =
                new ModeSetting(
                        this, "Notification type", new String[] {"First", "Second", "Third"});
        this.hudSizeSetting = new SliderSetting(this, "HUD Size", 1.0F, 0.5F, 1.5F, 0.05F);
        this.effectsSetting = new BooleanSetting(this, "Effects", true);
        this.modulesSetting = new BooleanSetting(this, "Modules", true);
        this.armorSetting = new BooleanSetting(this, "Armor", true);
        this.alwaysShowSetting = new BooleanSetting(this, "Always Show", false);
        this.lightSweepSetting = new BooleanSetting(this, "Light Sweep", false);
        this.lightSweepSpeedSetting =
                new SliderSetting(this, "Light Sweep Speed", 1.0F, 0.25F, 3.0F, 0.05F)
                        .visibleWhen(() -> this.lightSweepSetting.isOn());
        this.backgroundColorSetting =
                new ColorSetting(this, "Background Color", ColorUtils.cachedRgba(22, 12, 28, 220));
        this.moduleCardsSetting =
                new ColorSetting(this, "Module Cards", ColorUtils.cachedRgba(55, 30, 68, 105));
        this.clientColorSetting =
                new ColorSetting(this, "Client Color", ColorUtils.rgb(190, 100, 225));
        this.watermarkSetting = new PositionSetting(this, "Watermark", new Vector2f(-1.0F, -1.0F));
        this.coordinatesSetting =
                new PositionSetting(this, "Coordinates", new Vector2f(-1.0F, -1.0F));
        this.keybindsSetting = new PositionSetting(this, "Keybinds", new Vector2f(-1.0F, -1.0F));
        this.potionsSetting = new PositionSetting(this, "Potions", new Vector2f(-1.0F, -1.0F));
        this.staffListSetting = new PositionSetting(this, "Staff List", new Vector2f(-1.0F, -1.0F));
        this.cooldownsSetting = new PositionSetting(this, "Cooldowns", new Vector2f(-1.0F, -1.0F));
        this.arrayListSetting = new PositionSetting(this, "Array List", new Vector2f(-1.0F, -1.0F));
        this.notificationsSetting =
                new PositionSetting(this, "Notifications", new Vector2f(-1.0F, -1.0F));
        this.regionMapSetting = new PositionSetting(this, "RegionMap", new Vector2f(-1.0F, -1.0F));
        this.targetHUDSetting = new PositionSetting(this, "Target HUD", new Vector2f(-1.0F, -1.0F));
        this.armorHUDSetting = new PositionSetting(this, "Armor HUD", new Vector2f(-1.0F, -1.0F));
        this.watermarkHud = new WatermarkHud();
        this.coordinatesHud = new CoordinatesHud();
        this.keybindsHud = new KeybindsHud();
        this.potionEffectsHud = new PotionEffectsHud();
        this.staffHud = new StaffHud();
        this.cooldownsHud = new CooldownsHud();
        this.moduleListHud = new ModuleListHud();
        this.notificationsHud = new NotificationsHud();
        this.serverNavigationHud = new ServerNavigationHud();
        this.targetHud = new TargetHud();
        this.armorHud = new ArmorHud();
        this.notificationsSetting.lockHorizontal = true;
    }

    @EventHandler
    public void onRender2D(Render2DEvent render2DEvent) {
        if (client.player != null && client.world != null && this.isEnabled()) {
            if (this.elementsSetting.isOn("Potions")) {
                this.potionEffectsHud.render(this.potionsSetting, this, render2DEvent);
            }

            if (this.elementsSetting.isOn("Staff List")) {
                this.staffHud.renderStaff(this.staffListSetting, this);
            }

            if (this.elementsSetting.isOn("Cooldowns")) {
                this.cooldownsHud.render(this.cooldownsSetting, this, render2DEvent);
            }

            if (this.elementsSetting.isOn("Coordinates")) {
                this.coordinatesHud.render(this.coordinatesSetting, this);
            }

            if (this.elementsSetting.isOn("Keybinds")) {
                this.keybindsHud.render(this.keybindsSetting, this);
            }

            if (this.elementsSetting.isOn("Watermark")) {
                this.watermarkHud.render(this.watermarkSetting, this);
            }

            if (this.elementsSetting.isOn("Array List")) {
                this.moduleListHud.render(this.arrayListSetting, this);
            }

            if (this.elementsSetting.isOn("Notifications")) {
                this.notificationsHud.render(this.notificationsSetting, this, render2DEvent);
            }

            if (!(client.currentScreen instanceof InventoryScreen)) {
                this.renderRegionMap();
            }

            if (this.elementsSetting.isOn("Target HUD")) {
                this.targetHud.render(this.targetHUDSetting, this, render2DEvent);
            }

            if (this.elementsSetting.isOn("Armor HUD")) {
                this.armorHud.render(this.armorHUDSetting, this, render2DEvent);
            }

            this.initializePositions();
        }
    }
}
