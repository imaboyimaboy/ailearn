package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.effect.StatusEffects;

@ModuleInfo(
        name = "Gamma",
        desc = "Sets world brightness to its maximum value",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class GammaModule extends Module {
    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (client.player != null) {
            client.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (client.worldRenderer != null) {
            client.worldRenderer.reload();
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (client.worldRenderer != null) {
            client.worldRenderer.reload();
        }
    }
}
