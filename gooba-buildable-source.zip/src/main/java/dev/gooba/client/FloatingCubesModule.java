package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap.Type;

import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@ModuleInfo(
        name = "Floating Cubes",
        desc = "Spawns glowing floating cubes with physics around the player",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class FloatingCubesModule extends Module {
    private static final int[][] EDGE_INDICES =
            new int[][] {
                {0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5},
                {2, 6}, {3, 7}
            };
    private final List<FloatingCubesModule.Particle> particles;
    private static final Identifier SMALL_GLOW_TEXTURE =
            Identifier.of("client", "textures/visuals/particles_2.png");
    public SliderSetting cubeSizeSetting;
    private final BufferAllocator bufferAllocator;
    private final List<FloatingCubesModule.Particle> visibleParticles;
    private static final RenderPipeline FILL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "svetoch_fill"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    public ModeSetting colorModeSetting =
            new ModeSetting(this, "Color Mode", new String[] {"Theme", "Custom"});
    private static final RenderLayer FILL_LAYER =
            RenderLayer.of(
                    "svetoch_fill",
                    RenderSetup.builder(FloatingCubesModule.FILL_PIPELINE)
                            .expectedBufferSize(8192)
                            .build());
    private static final Identifier LARGE_GLOW_TEXTURE =
            Identifier.of("client", "textures/particles/glow.png");
    private static final RenderPipeline LINE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "svetoch_lines"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.DEBUG_LINES)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    private static final float[][] CUBE_CORNERS =
            new float[][] {
                {-1.0F, -1.0F, -1.0F},
                {1.0F, -1.0F, -1.0F},
                {1.0F, -1.0F, 1.0F},
                {-1.0F, -1.0F, 1.0F},
                {-1.0F, 1.0F, -1.0F},
                {1.0F, 1.0F, -1.0F},
                {1.0F, 1.0F, 1.0F},
                {-1.0F, 1.0F, 1.0F}
            };
    private long lastFrameNanos;
    private static final RenderPipeline GLOW_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_TEX_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "svetoch_glow"))
                            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    public SliderSetting cubeCountSetting;

    public ColorSetting colorSetting =
            new ColorSetting(this, "Color", -16711681)
                    .visibleWhen(() -> this.colorModeSetting.isSelected("Custom"));

    private static final RenderLayer SMALL_GLOW_LAYER =
            RenderLayer.of(
                    "svetoch_glow_small",
                    RenderSetup.builder(GLOW_PIPELINE)
                            .texture("Sampler0", SMALL_GLOW_TEXTURE)
                            .translucent()
                            .expectedBufferSize(4096)
                            .build());
    private static final RenderLayer LARGE_GLOW_LAYER =
            RenderLayer.of(
                    "svetoch_glow_big",
                    RenderSetup.builder(GLOW_PIPELINE)
                            .texture("Sampler0", LARGE_GLOW_TEXTURE)
                            .translucent()
                            .expectedBufferSize(4096)
                            .build());
    private static final RenderLayer LINE_LAYER =
            RenderLayer.of(
                    "svetoch_lines",
                    RenderSetup.builder(LINE_PIPELINE).expectedBufferSize(8192).build());
    private static final int[][] FACE_INDICES =
            new int[][] {
                {0, 1, 2, 3}, {4, 5, 6, 7}, {0, 1, 5, 4}, {2, 3, 7, 6}, {1, 2, 6, 5}, {3, 0, 4, 7}
            };

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.particles.clear();
    }

    public FloatingCubesModule() {
        this.cubeCountSetting = new SliderSetting(this, "Cube Count", 100.0F, 50.0F, 300.0F, 1.0F);
        this.cubeSizeSetting = new SliderSetting(this, "Cube size", 0.26F, 0.1F, 0.6F, 0.02F);
        this.particles = new ArrayList<>();
        this.visibleParticles = new ArrayList<>();
        this.bufferAllocator = new BufferAllocator(65536);
        this.lastFrameNanos = System.nanoTime();
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (!this.particles.isEmpty() && client.player != null && client.world != null) {
            long nowMillis = System.currentTimeMillis();
            long nowNanos = System.nanoTime();
            float f =
                    (float) Math.min((double) (nowNanos - this.lastFrameNanos) / 1.0E9, 0.1)
                            * 60.0F;
            this.lastFrameNanos = nowNanos;
            MatrixStack matrixstack = render3DEvent.getMatrixStack();
            Vec3d vec3d = client.gameRenderer.getCamera().getCameraPos();
            Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
            Quaternionf quaternionf = client.gameRenderer.getCamera().getRotation();
            float f1 = (float) (nowMillis % 9000L) / 9000.0F * 360.0F;
            float f2 = (float) Math.toRadians((double) (f1 * 0.5F));
            int k = this.cubeColor();
            int l = k >> 16 & 0xFF;
            int i1 = k >> 8 & 0xFF;
            int j1 = k & 0xFF;
            float f3 = this.cubeSizeSetting.getFloat();
            Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);
            this.visibleParticles.clear();
            Iterator iterator = this.particles.iterator();

            while (iterator.hasNext()) {
                FloatingCubesModule.Particle particle =
                        (FloatingCubesModule.Particle) iterator.next();
                particle.update(nowMillis, f);
                if (particle.isExpired()) {
                    iterator.remove();
                } else if (!(particle.opacity <= 0.01F)) {
                    double d0 = particle.x - vec3d.x;
                    double d1 = particle.y - vec3d.y;
                    double d2 = particle.z - vec3d.z;
                    if (!(d0 * d0 + d1 * d1 + d2 * d2 > 9216.0)) {
                        particle.cubeTransform
                                .set(matrix4f)
                                .translate((float) d0, (float) d1, (float) d2)
                                .rotateY(
                                        (float)
                                                Math.toRadians(
                                                        (double) (f1 + particle.rotationOffset)))
                                .rotateX(f2);
                        particle.glowTransform
                                .set(matrix4f)
                                .translate((float) d0, (float) d1, (float) d2)
                                .rotate(quaternionf);
                        this.visibleParticles.add(particle);
                    }
                }
            }

            if (!this.visibleParticles.isEmpty()) {
                VertexConsumer vertexconsumer = immediate.getBuffer(FILL_LAYER);

                for (FloatingCubesModule.Particle particleValue : this.visibleParticles) {
                    int l1 = (int) (particleValue.opacity * 0.2F * 255.0F);
                    if (l1 > 0) {
                        for (int[] aint : FACE_INDICES) {
                            for (int k1 : aint) {
                                float[] afloat = CUBE_CORNERS[k1];
                                vertexconsumer
                                        .vertex(
                                                particleValue.cubeTransform,
                                                afloat[0] * f3,
                                                afloat[1] * f3,
                                                afloat[2] * f3)
                                        .color(l, i1, j1, l1);
                            }
                        }
                    }
                }

                vertexconsumer = immediate.getBuffer(LINE_LAYER);

                for (FloatingCubesModule.Particle particle2 : this.visibleParticles) {
                    int i2 = (int) (particle2.opacity * 255.0F);
                    if (i2 > 0) {
                        for (int[] values : EDGE_INDICES) {
                            float[] valuesValue = CUBE_CORNERS[values[0]];
                            float[] values2 = CUBE_CORNERS[values[1]];
                            vertexconsumer
                                    .vertex(
                                            particle2.cubeTransform,
                                            valuesValue[0] * f3,
                                            valuesValue[1] * f3,
                                            valuesValue[2] * f3)
                                    .color(l, i1, j1, i2);
                            vertexconsumer
                                    .vertex(
                                            particle2.cubeTransform,
                                            values2[0] * f3,
                                            values2[1] * f3,
                                            values2[2] * f3)
                                    .color(l, i1, j1, i2);
                        }
                    }
                }

                vertexconsumer = immediate.getBuffer(LARGE_GLOW_LAYER);

                for (FloatingCubesModule.Particle particle3 : this.visibleParticles) {
                    drawGlowQuad(
                            vertexconsumer,
                            particle3.glowTransform,
                            l,
                            i1,
                            j1,
                            (int) (80.0F * particle3.opacity),
                            f3 * 6.0F);
                }

                immediate.draw();
            }
        }
    }

    public int cubeColor() {
        return this.colorModeSetting.isSelected("Theme")
                ? ColorUtils.hudAccent()
                : this.colorSetting.getColor();
    }

    @Override
    public void toggle() {
        super.toggle();
        this.particles.clear();
    }

    private static void drawGlowQuad(
            VertexConsumer vertexconsumer, Matrix4f matrix4f, int i, int j, int k, int l, float f) {
        if (l > 0) {
            vertexconsumer
                    .vertex(matrix4f, -f, -f, 0.0F)
                    .color(i, j, k, l)
                    .texture(0.0F, 1.0F)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(15728880)
                    .normal(0.0F, 0.0F, 1.0F);
            vertexconsumer
                    .vertex(matrix4f, f, -f, 0.0F)
                    .color(i, j, k, l)
                    .texture(1.0F, 1.0F)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(15728880)
                    .normal(0.0F, 0.0F, 1.0F);
            vertexconsumer
                    .vertex(matrix4f, f, f, 0.0F)
                    .color(i, j, k, l)
                    .texture(1.0F, 0.0F)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(15728880)
                    .normal(0.0F, 0.0F, 1.0F);
            vertexconsumer
                    .vertex(matrix4f, -f, f, 0.0F)
                    .color(i, j, k, l)
                    .texture(0.0F, 0.0F)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(15728880)
                    .normal(0.0F, 0.0F, 1.0F);
        }
    }

    @EventHandler
    public void onPlayerMotion(PlayerMotionEvent playerMotionEvent) {
        if (client.player != null && client.world != null) {
            int i = this.cubeCountSetting.getFloat().intValue();
            byte b0 = 24;

            for (int j = 0; j < 3 && this.particles.size() < i; j++) {
                Vec3d vec3d =
                        client.player
                                .getEntityPos()
                                .add(
                                        (double) MathUtils.randomFloat((float) (-b0), (float) b0),
                                        0.0,
                                        (double) MathUtils.randomFloat((float) (-b0), (float) b0));
                BlockPos blockpos =
                        client.world.getTopPosition(
                                Type.MOTION_BLOCKING, BlockPos.ofFloored(vec3d));
                double d0 = (double) ((float) blockpos.getX() + MathUtils.randomFloat(-3.0F, 3.0F));
                double d1 = (double) ((float) blockpos.getZ() + MathUtils.randomFloat(-3.0F, 3.0F));
                double d2 =
                        client.player.getY()
                                + (double)
                                        MathUtils.randomFloat(
                                                client.player.getHeight(), (float) b0);
                Vec3d vec3d1 = new Vec3d(d0, d2, d1);

                while (!client.world.isAir(BlockPos.ofFloored(vec3d1))
                        && vec3d1.y < (double) client.world.getTopYInclusive()) {
                    vec3d1 = vec3d1.add(0.0, 1.0, 0.0);
                }

                Vec3d vec3d2 =
                        new Vec3d(
                                client.player.getVelocity().x
                                        + (double) MathUtils.randomFloat(-0.6F, 0.6F),
                                MathUtils.randomDouble(-0.01, 0.44),
                                client.player.getVelocity().z
                                        + (double) MathUtils.randomFloat(-0.6F, 0.6F));
                this.particles.add(new FloatingCubesModule.Particle(vec3d1, vec3d2));
            }
        }
    }

    @Environment(EnvType.CLIENT)
    private static class Particle {
        double z;
        double velocityZ;
        final EasingAnimation fadeAnimation = new EasingAnimation();
        final long createdAtMillis;
        boolean fading;
        double velocityY;
        double y;
        float opacity;
        final Matrix4f cubeTransform = new Matrix4f();
        double velocityX;
        final float rotationOffset;
        double x;
        final Matrix4f glowTransform = new Matrix4f();

        Particle(Vec3d vec3d, Vec3d vec3d1) {
            this.createdAtMillis = System.currentTimeMillis();
            this.rotationOffset = (float) (Math.random() * 100.0);
            this.x = vec3d.x;
            this.y = vec3d.y;
            this.z = vec3d.z;
            this.velocityX = vec3d1.x * 0.05;
            this.velocityY = vec3d1.y * 0.05;
            this.velocityZ = vec3d1.z * 0.05;
            this.fadeAnimation.snapTo(0.0);
            this.fadeAnimation.animateTo(1.0, 0.5, Easings.LINEAR, true);
        }

        void update(long i, float f) {
            double d0 = this.x + this.velocityX * (double) f;
            double d1 = this.y + this.velocityY * (double) f;
            double d2 = this.z + this.velocityZ * (double) f;
            if (Math.floor(d0) == Math.floor(this.x)
                    && Math.floor(d1) == Math.floor(this.y)
                    && Math.floor(d2) == Math.floor(this.z)) {
                if (isSolidAt(d0, d1, d2)) {
                    this.velocityX = -this.velocityX * 0.85;
                    this.velocityY = -this.velocityY * 0.85;
                    this.velocityZ = -this.velocityZ * 0.85;
                } else {
                    this.x = d0;
                    this.y = d1;
                    this.z = d2;
                }
            } else {
                if (isSolidAt(d0, this.y, this.z)) {
                    this.velocityX = -this.velocityX * 0.85;
                } else {
                    this.x = d0;
                }

                if (isSolidAt(this.x, d1, this.z)) {
                    this.velocityY = -this.velocityY * 0.85;
                } else {
                    this.y = d1;
                }

                if (isSolidAt(this.x, this.y, d2)) {
                    this.velocityZ = -this.velocityZ * 0.85;
                } else {
                    this.z = d2;
                }
            }

            this.velocityY -= 1.0E-4 * (double) f;
            if (!this.fading && i - this.createdAtMillis > 1500L) {
                this.fading = true;
                this.fadeAnimation.animateTo(0.0, 2.0, Easings.LINEAR, true);
            }

            this.fadeAnimation.update();
            this.opacity = this.fadeAnimation.getFloatValue();
        }

        boolean isExpired() {
            return this.fading && this.opacity <= 0.01F;
        }

        private static boolean isSolidAt(double d0, double d1, double d2) {
            BlockPos blockpos = BlockPos.ofFloored(d0, d1, d2);
            return MinecraftAccess.client
                    .world
                    .getBlockState(blockpos)
                    .isFullCube(MinecraftAccess.client.world, blockpos);
        }
    }
}
