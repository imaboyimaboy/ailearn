package dev.gooba.client;

import com.mojang.blaze3d.pipeline.RenderPipeline;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

import org.joml.Matrix3x2fStack;

import java.awt.Color;

@Environment(EnvType.CLIENT)
public final class ToggleIconRenderer {

    private static final Identifier ICON_ATLAS = Identifier.of("client", "fonts/toggle_icons.png");

    private static void drawIcon(DrawContext drawcontext, float f, float f1, int i) {
        Matrix3x2fStack matrix3x2fstack = drawcontext.getMatrices();
        matrix3x2fstack.pushMatrix();
        matrix3x2fstack.translate(f, f1);
        matrix3x2fstack.scale(0.1015625F, 0.10156251F);
        drawcontext.drawTexture(
                ColorPickerRenderer.MSDF_ICON_PIPELINE,
                ICON_ATLAS,
                0,
                0,
                473.5F,
                0.5F,
                58,
                59,
                532,
                532,
                i);
        matrix3x2fstack.popMatrix();
    }

    public static void drawToggle(
            DrawContext drawcontext, float f, float f1, int i, Color color, float f2, float f3) {
        float f4 = clampUnit(f2);
        if (!(f4 <= 0.0F)) {
            Matrix3x2fStack matrix3x2fstack = drawcontext.getMatrices();
            matrix3x2fstack.pushMatrix();
            matrix3x2fstack.translate(f, f1);
            matrix3x2fstack.scale(f3, f3);
            drawIcon(
                    drawcontext,
                    2.554688F,
                    2.453125F,
                    new Color(
                                    color.getRed(),
                                    color.getGreen(),
                                    color.getBlue(),
                                    Math.round(255.0F * f4))
                            .getRGB());
            int j = Math.round((float) (i >>> 24 & 0xFF) * f4);
            int k = i & 16777215 | j << 24;
            drawScaledRect(
                    drawcontext,
                    ColorPickerRenderer.ICON_FILL_PIPELINE,
                    6.75F,
                    6.75F,
                    3.0F,
                    3.0F,
                    11.0F,
                    11.0F,
                    k);
            matrix3x2fstack.popMatrix();
        }
    }

    private static void drawScaledRect(
            DrawContext drawcontext,
            RenderPipeline renderpipeline,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            int i) {
        Matrix3x2fStack matrix3x2fstack = drawcontext.getMatrices();
        matrix3x2fstack.pushMatrix();
        matrix3x2fstack.translate(f, f1);
        matrix3x2fstack.scale(f2 / f4, f3 / f5);
        drawcontext.fill(renderpipeline, 0, 0, Math.round(f4), Math.round(f5), i);
        matrix3x2fstack.popMatrix();
    }

    private static float clampUnit(float f) {
        return Math.max(0.0F, Math.min(1.0F, f));
    }

    private static Color lerpColor(Color color, Color colorValue, float f) {
        float f1 = clampUnit(f);
        return new Color(
                Math.round(
                        (float) color.getRed()
                                + (float) (colorValue.getRed() - color.getRed()) * f1),
                Math.round(
                        (float) color.getGreen()
                                + (float) (colorValue.getGreen() - color.getGreen()) * f1),
                Math.round(
                        (float) color.getBlue()
                                + (float) (colorValue.getBlue() - color.getBlue()) * f1));
    }

    private ToggleIconRenderer() {}

    public static void drawColorPicker(
            DrawContext drawcontext,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            Color color,
            float f8) {
        float f9 = clampUnit(f8);
        if (!(f9 <= 0.0F)) {
            float f10 = f - 5.0F;
            float f11 = f1 - 5.0F;
            float f12 = 0.85F + f9 * 0.15F;
            float f13 = f10 + 42.0F;
            float f14 = f11 + 33.0F;
            Matrix3x2fStack matrix3x2fstack = drawcontext.getMatrices();
            matrix3x2fstack.pushMatrix();
            matrix3x2fstack.translate(f13, f14 + (1.0F - f9) * 6.0F);
            matrix3x2fstack.scale(f12, f12);
            matrix3x2fstack.translate(-f13, -f14);
            Color colorValue = lerpColor(new Color(2, 10, 17), color, 0.05F);
            drawScaledRect(
                    drawcontext,
                    ColorPickerRenderer.BACKGROUND_PIPELINE,
                    f10,
                    f11,
                    84.0F,
                    66.0F,
                    84.0F,
                    66.0F,
                    new Color(
                                    colorValue.getRed(),
                                    colorValue.getGreen(),
                                    colorValue.getBlue(),
                                    Math.round(210.0F * f9))
                            .getRGB());
            int i = Color.HSBtoRGB(clampUnit(f4), 1.0F, 1.0F);
            int j = i & 16777215 | Math.round(255.0F * f9) << 24;
            drawScaledRect(
                    drawcontext,
                    ColorPickerRenderer.AREA_PIPELINE,
                    f,
                    f1,
                    56.0F,
                    56.0F,
                    56.0F,
                    56.0F,
                    j);
            float f15 = f + 2.0F + clampUnit(f5) * 52.0F;
            float f16 = f1 + 2.0F + (1.0F - clampUnit(f6)) * 52.0F;
            drawScaledRect(
                    drawcontext,
                    ColorPickerRenderer.CURSOR_PIPELINE,
                    f15 - 2.0F,
                    f16 - 2.0F,
                    4.0F,
                    4.0F,
                    4.0F,
                    4.0F,
                    new Color(255, 255, 255, Math.round(255.0F * f9)).getRGB());
            drawScaledRect(
                    drawcontext,
                    ColorPickerRenderer.HUE_PIPELINE,
                    f2,
                    f1,
                    4.0F,
                    56.0F,
                    4.0F,
                    56.0F,
                    new Color(255, 255, 255, Math.round(255.0F * f9)).getRGB());
            int k = Color.HSBtoRGB(clampUnit(f4), clampUnit(f5), clampUnit(f6));
            int l = k & 16777215 | Math.round(255.0F * f9) << 24;
            drawScaledRect(
                    drawcontext,
                    ColorPickerRenderer.ALPHA_PIPELINE,
                    f3,
                    f1,
                    4.0F,
                    56.0F,
                    4.0F,
                    56.0F,
                    l);
            int rGB = new Color(255, 255, 255, Math.round(255.0F * f9)).getRGB();
            drawcontext.fill(
                    Math.round(f2 - 1.0F),
                    Math.round(f1 + clampUnit(f4) * 55.0F - 0.5F),
                    Math.round(f2 + 5.0F),
                    Math.round(f1 + clampUnit(f4) * 55.0F + 0.5F) + 1,
                    rGB);
            float f17 = f1 + (1.0F - clampUnit(f7)) * 55.0F;
            drawcontext.fill(
                    Math.round(f3 - 1.0F),
                    Math.round(f17 - 0.5F),
                    Math.round(f3 + 5.0F),
                    Math.round(f17 + 0.5F) + 1,
                    rGB);
            matrix3x2fstack.popMatrix();
        }
    }
}
