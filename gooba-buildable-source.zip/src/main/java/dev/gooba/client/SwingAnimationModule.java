package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

@ModuleInfo(
        name = "Swing Animation",
        category = ModuleCategory.RENDER,
        desc = "Customizes first-person hand swing animations")
@Environment(EnvType.CLIENT)
public class SwingAnimationModule extends Module {
    public SliderSetting angleSetting;
    public ModeSetting typeSetting;
    public SliderSetting animationStrengthSetting;
    public SliderSetting animationSpeedSetting;
    public BooleanSetting onlyWithAuraSetting;
    public ModeSetting interpolationModeSetting;
    public ModeSetting animationModeSetting =
            new ModeSetting(
                    this,
                    "Animation mode",
                    new String[] {"First", "Second", "Third", "Fourth", "Fifth", "Sixth"});

    public boolean shouldAnimate() {
        if (!this.onlyWithAuraSetting.isOn()) {
            return true;
        } else {
            AttackAuraModule attackAuraModule = AttackAuraModule.getInstance();
            return attackAuraModule != null
                    && attackAuraModule.isEnabled()
                    && AttackAuraModule.target != null;
        }
    }

    private void applyEquipOffset(MatrixStack matrixstack, Arm arm, float f) {
        int i = arm == Arm.RIGHT ? 1 : -1;
        matrixstack.translate((float) i * 0.56F, -0.52F + f * -0.6F, -0.72F);
    }

    private static Packet interactionPacket(Hand hand, int i) {
        return new PlayerInteractItemC2SPacket(
                hand, i, client.player.getYaw(), client.player.getPitch());
    }

    @EventHandler
    public void onFirstPersonItem(FirstPersonItemEvent firstPersonItemEvent) {
        if (this.isEnabled()) {
            if (this.shouldAnimate()) {
                boolean flag;
                ModeSetting modeSetting2;
                MatrixStack matrixstack;
                float f;
                byte b0;
                float f1;
                label73:
                {
                    label72:
                    {
                        label71:
                        {
                            if (firstPersonItemEvent.getArm() == Arm.RIGHT) {
                                flag = true;
                                modeSetting2 = this.animationModeSetting;
                                client.player.getStackInHand(firstPersonItemEvent.getHand());
                                matrixstack = firstPersonItemEvent.getMatrices();
                                f = firstPersonItemEvent.getSwingProgress();
                                if (!flag) {
                                    break label71;
                                }
                            } else {
                                flag = false;
                                modeSetting2 = this.animationModeSetting;
                                client.player.getStackInHand(firstPersonItemEvent.getHand());
                                matrixstack = firstPersonItemEvent.getMatrices();
                                f = firstPersonItemEvent.getSwingProgress();
                                if (!flag) {
                                    break label71;
                                }
                            }

                            b0 = 1;
                            if (this.interpolationModeSetting.isSelected("First")) {
                                f1 = (float) Easings.OUT_SINE.ease((double) f);
                                break label73;
                            }
                            break label72;
                        }

                        b0 = -1;
                        if (this.interpolationModeSetting.isSelected("First")) {
                            f1 = (float) Easings.OUT_SINE.ease((double) f);
                            break label73;
                        }
                    }

                    if (this.interpolationModeSetting.isSelected("Third")) {
                        f1 = f;
                    } else {
                        f1 = (float) Easings.OUT_BACK_ALT.ease((double) f);
                    }
                }

                float f2 = MathHelper.sin((double) (f1 * f1 * (float) Math.PI));
                float f3 = MathHelper.sin((double) (MathHelper.sqrt(f1) * (float) Math.PI));
                float f4 = f2 * f3;
                if (this.interpolationModeSetting.isSelected("Third")) {
                    f4 = (float) Math.sin((double) f * (Math.PI / 2) * 2.0);
                }

                float f5 = this.animationStrengthSetting.getFloat();
                Arm arm = firstPersonItemEvent.getArm();
                String string = modeSetting2.getSelectedMode();
                switch (string.hashCode()) {
                    case -1822412652:
                        if (string.equals("Second")) {
                            matrixstack.translate((float) b0 * 0.56F, -0.42F, -0.72F);
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_X.rotationDegrees(f4 * -(24.0F * f5)));
                            matrixstack.translate(0.0, -0.1, 0.0);
                            firstPersonItemEvent.cancel();
                            return;
                        }
                        break;
                    case 67876247:
                        if (string.equals("Fifth")) {
                            matrixstack.translate((float) b0 * 0.56F, -0.42F, -0.72F);
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_X.rotationDegrees(0.0F + f1 * 360.0F));
                            matrixstack.translate(0.0, -0.1, 0.0);
                            firstPersonItemEvent.cancel();
                            return;
                        }
                        break;
                    case 67887760:
                        if (string.equals("First")) {
                            matrixstack.translate((float) b0 * 0.56F, -0.52F, -0.72F);
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_X.rotationDegrees(
                                            f4 * -180.0F * f5 / 10.0F));
                            matrixstack.multiply(
                                    RotationAxis.NEGATIVE_Z.rotationDegrees(
                                            f4
                                                    * (flag
                                                            ? -60.0F * f5 / 10.0F
                                                            : 60.0F * f5 / 10.0F)));
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_Y.rotationDegrees(
                                            f4
                                                    * (flag
                                                            ? -60.0F * f5 / 10.0F
                                                            : 60.0F * f5 / 10.0F)));
                            firstPersonItemEvent.cancel();
                            return;
                        }
                        break;
                    case 79899318:
                        if (string.equals("Sixth")) {
                            matrixstack.translate((double) ((float) b0 * 0.7F), -0.35F, -0.9);
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_Y.rotationDegrees((float) (b0 * 65)));
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_Z.rotationDegrees((float) (b0 * -10)));
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_X.rotationDegrees(
                                            -90.0F - f5 * 24.0F * f4));
                            firstPersonItemEvent.cancel();
                            return;
                        }
                        break;
                    case 80778567:
                        if (string.equals("Third")) {
                            matrixstack.translate((double) ((float) b0 * 0.7F), -0.35F, -0.9);
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_Y.rotationDegrees((float) (b0 * 60)));
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_Z.rotationDegrees((float) (b0 * -60)));
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_X.rotationDegrees(
                                            -this.angleSetting.getFloat()
                                                    - (this.typeSetting.isSelected("First")
                                                            ? f5 * 24.0F * f4
                                                            : -(f5 * 24.0F) * f4)));
                            firstPersonItemEvent.cancel();
                            return;
                        }
                        break;
                    case 2110150202:
                        if (string.equals("Fourth")) {
                            matrixstack.translate(
                                    (double) b0
                                            * (0.2F - 0.1 * (double) f4 * (double) (0.25F * f5)),
                                    0.0,
                                    -0.2F - 0.2 * (double) f4 * (double) (0.25F * f5));
                            this.applyEquipOffset(matrixstack, arm, 0.0F);
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_X.rotationDegrees(
                                            50.0F - 4.0F * f4 * 0.35F * f5));
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_Y.rotationDegrees(
                                            (float) b0 * (-60.0F + 0.6F * f5 * f4)));
                            matrixstack.multiply(
                                    RotationAxis.POSITIVE_Z.rotationDegrees(
                                            (float) b0 * (110.0F + 40.0F * f4 * 0.2F * f5)));
                            firstPersonItemEvent.cancel();
                            return;
                        }
                }

                firstPersonItemEvent.cancel();
            }
        }
    }

    public static SwingAnimationModule getInstance() {
        return (SwingAnimationModule) ModuleLookup.getModule(SwingAnimationModule.class);
    }

    public SwingAnimationModule() {
        this.typeSetting =
                new ModeSetting(this, "Type", new String[] {"First", "Second"})
                        .visibleWhen(() -> this.animationModeSetting.isSelected("Third"));
        this.angleSetting =
                new SliderSetting(this, "Angle", 90.0F, -180.0F, 180.0F, 1.0F)
                        .visibleWhen(() -> this.animationModeSetting.isSelected("Third"));
        this.interpolationModeSetting =
                new ModeSetting(
                        this, "Interpolation mode", new String[] {"First", "Second", "Third"});
        this.onlyWithAuraSetting = new BooleanSetting(this, "Only with aura", false);
        this.animationSpeedSetting =
                new SliderSetting(this, "Animation speed", 1.0F, 0.1F, 4.0F, 0.1F);
        this.animationStrengthSetting =
                new SliderSetting(this, "Animation Strength", 6.0F, 0.1F, 10.0F, 0.1F);
    }

    @EventHandler
    public void onHandSwing(HandSwingEvent handSwingEvent) {
        if (this.shouldAnimate()) {
            Item item = client.player.getStackInHand(Hand.MAIN_HAND).getItem();
            Item itemValue = client.player.getStackInHand(Hand.OFF_HAND).getItem();
            if (item != Items.AIR || itemValue != Items.AIR) {
                float animationValue = this.animationSpeedSetting.getFloat();
                handSwingEvent.setAnimation(animationValue);
                handSwingEvent.cancel();
            }
        }
    }
}
