package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public final class ModuleSettingsPanel {
    private float scrollTarget;
    private float maxScroll;
    private float minimumPanelHeight;
    private boolean showModuleToggle;
    private Rectangle bounds;
    private float x;
    private boolean positionInitialized;
    private SliderSetting draggedSlider;
    private Rectangle headerBounds;
    private float y;
    private String title = "";
    private float dragOffsetX;
    private Rectangle sliderBounds;
    private float scroll;
    private float dragOffsetY;
    private final List<ModuleSettingsPanel.PanelRow> rows;
    private Module module;
    private int colorChannel;
    private Rectangle colorBounds;
    private Rectangle toggleBounds;
    private boolean dragging;
    private ColorSetting draggedColor;

    private void drawRow(
            AnimationRegistry animationRegistry2, ModuleSettingsPanel.PanelRow panelRow, float f) {
        String name = this.module.getName();
        String stringValue = panelRow.label;
        String nameValue = name;
        String text = nameValue + ":" + stringValue;
        Setting setting = panelRow.setting;
        Rectangle rectangleValue = panelRow.bounds;
        float opacity = f * panelRow.opacity;
        if (!(opacity <= 0.01F)) {
            if (setting instanceof ButtonSetting) {
                Font font = Fonts.SF_REGULAR;
                String label = panelRow.label;
                float f16 = font.measureWidth(label, 5.5F);
                float f27 = rectangleValue.x() + 2.0F;
                float f29 = rectangleValue.y() + 4.0F;
                ColorUtils.withOpacity(ColorUtils.themeAccent(), opacity * 0.85F);
                font.drawText(label, f27, f29, 5.5F);
                RenderUtils.Render2D.drawRoundedRect(
                        rectangleValue.x() + f16 + 6.0F,
                        rectangleValue.y() + 5.75F,
                        Math.max(0.0F, rectangleValue.width() - f16 - 8.0F),
                        0.5F,
                        ColorUtils.grayscaleOpacity(255, opacity * 0.12F),
                        0.25F);
            } else if (setting instanceof BooleanSetting booleanSetting) {
                animationRegistry2.drawToggle(
                        rectangleValue, panelRow.label, booleanSetting.isOn(), text, opacity);
            } else if (setting instanceof SliderSetting sliderSetting2) {
                float hoverProgress = animationRegistry2.updateHover(text, rectangleValue);
                animationRegistry2.drawHoverBackground(rectangleValue, hoverProgress, opacity);
                Font fontValue = Fonts.SF_REGULAR;
                String labelValue = panelRow.label;
                float f26 = rectangleValue.x() + 6.0F;
                float f28 = rectangleValue.y() + 3.2F;
                ColorUtils.grayscaleOpacity(255, opacity * (0.5F + 0.5F * hoverProgress));
                fontValue.drawText(labelValue, f26, f28, 6.0F);
                String string =
                        String.valueOf(
                                (double)
                                                Math.round(
                                                        (double)
                                                                        sliderSetting2
                                                                                .getFloat()
                                                                                .floatValue()
                                                                * 100.0)
                                        / 100.0);
                f26 =
                        rectangleValue.x()
                                + rectangleValue.width()
                                - 6.0F
                                - fontValue.measureWidth(string, 5.5F);
                f28 = rectangleValue.y() + 3.5F;
                ColorUtils.withOpacity(
                        ColorUtils.themeAccent(), opacity * (0.6F + 0.4F * hoverProgress));
                fontValue.drawText(string, f26, f28, 5.5F);
                float width = rectangleValue.width() - 12.0F;
                float target =
                        MathHelper.clamp(
                                (sliderSetting2.getFloat() - sliderSetting2.minValue)
                                        / (sliderSetting2.maxValue - sliderSetting2.minValue),
                                0.0F,
                                1.0F);
                float f19 = animationRegistry2.smoothValue(text + ":pc", target);
                RenderUtils.Render2D.drawRoundedRect(
                        rectangleValue.x() + 6.0F,
                        rectangleValue.y() + 13.0F,
                        width,
                        2.5F,
                        ColorUtils.grayscaleOpacity(0, opacity * 0.15F),
                        1.25F);
                RenderUtils.Render2D.drawRoundedRect(
                        rectangleValue.x() + 6.0F,
                        rectangleValue.y() + 13.0F,
                        width * f19,
                        2.5F,
                        ColorUtils.withOpacity(
                                ColorUtils.themeAccent(), opacity * (0.5F + 0.5F * hoverProgress)),
                        1.25F);
                RenderUtils.Render2D.drawRoundedRect(
                        rectangleValue.x() + 6.0F + width * f19 - 2.5F,
                        rectangleValue.y() + 11.75F,
                        5.0F,
                        5.0F,
                        ColorUtils.grayscaleOpacity(
                                (int) (200.0F + 55.0F * hoverProgress), opacity),
                        5.0F);
                RenderUtils.Render2D.drawRoundedRect(
                        rectangleValue.x() + 6.0F + width * f19 - 1.75F,
                        rectangleValue.y() + 12.5F,
                        3.5F,
                        3.5F,
                        ColorUtils.withOpacity(
                                ColorUtils.themeAccent(), opacity * (0.7F + 0.3F * hoverProgress)),
                        5.0F);
            } else if (setting instanceof ModeSetting modeSetting2) {
                float hoverProgressValue = animationRegistry2.updateHover(text, rectangleValue);
                animationRegistry2.drawHoverBackground(rectangleValue, hoverProgressValue, opacity);
                Font SF_REGULAR = Fonts.SF_REGULAR;
                String selectedMode = modeSetting2.getSelectedMode();
                SF_REGULAR.drawFadedText(
                        panelRow.label,
                        rectangleValue.x() + 6.0F,
                        rectangleValue.y() + 3.2F,
                        rectangleValue.width()
                                - SF_REGULAR.measureWidth(selectedMode, 5.5F)
                                - 16.0F,
                        ColorUtils.grayscaleOpacity(
                                255, opacity * (0.5F + 0.5F * hoverProgressValue)),
                        6.0F);
                float f30 =
                        rectangleValue.x()
                                + rectangleValue.width()
                                - 6.0F
                                - SF_REGULAR.measureWidth(selectedMode, 5.5F);
                float f31 = rectangleValue.y() + 3.5F;
                ColorUtils.withOpacity(
                        ColorUtils.themeAccent(), opacity * (0.6F + 0.4F * hoverProgressValue));
                SF_REGULAR.drawText(selectedMode, f30, f31, 5.5F);

                for (int j2 = 0; j2 < panelRow.optionBounds.size(); j2++) {
                    Rectangle rectangle = panelRow.optionBounds.get(j2);
                    String string2 = modeSetting2.modes.get(j2);
                    TimedAnimation timedAnimation4 =
                            animationRegistry2.getOrCreateAnimation(text + ":chip:" + string2);
                    timedAnimation4.setDirection(
                            string2.equals(modeSetting2.getSelectedMode())
                                    ? AnimationDirection.FORWARDS
                                    : AnimationDirection.BACKWARDS);
                    float value = timedAnimation4.getValue();
                    RenderUtils.Render2D.drawRoundedRect(
                            rectangle.x(),
                            rectangle.y(),
                            rectangle.width(),
                            rectangle.height(),
                            ColorUtils.interpolate(
                                    ColorUtils.grayscaleOpacity(0, 0.25F * opacity),
                                    ColorUtils.withOpacity(
                                            ColorUtils.themeAccent(),
                                            opacity * (0.5F + 0.5F * hoverProgressValue)),
                                    value),
                            2.5F);
                    SF_REGULAR.drawCenteredText(
                            string2,
                            rectangle.centerX(),
                            rectangle.y() + 1.4F,
                            5.5F,
                            ColorUtils.grayscaleOpacity(
                                    255,
                                    opacity
                                            * (0.35F + 0.65F * value)
                                            * (0.7F + 0.3F * hoverProgressValue)));
                }
            } else if (setting instanceof ColorSetting colorSetting4) {
                float hoverProgress2 = animationRegistry2.updateHover(text, rectangleValue);
                animationRegistry2.drawHoverBackground(rectangleValue, hoverProgress2, opacity);
                Font SF_REGULARValue = Fonts.SF_REGULAR;
                SF_REGULARValue.drawFadedText(
                        panelRow.label,
                        rectangleValue.x() + 6.0F,
                        rectangleValue.y() + 3.2F,
                        rectangleValue.width() - 30.0F,
                        ColorUtils.grayscaleOpacity(255, opacity * (0.5F + 0.5F * hoverProgress2)),
                        6.0F);
                int integer = colorSetting4.getColor();
                int red =
                        (int)
                                animationRegistry2.smoothValue(
                                        text + ":r", (float) (integer >> 16 & 0xFF));
                int green =
                        (int)
                                animationRegistry2.smoothValue(
                                        text + ":g", (float) (integer >> 8 & 0xFF));
                int blue =
                        (int) animationRegistry2.smoothValue(text + ":b", (float) (integer & 0xFF));
                float innerX = rectangleValue.x() + rectangleValue.width() - 6.0F - 7.0F;
                float innerYValue = rectangleValue.y() + 3.0F;
                RenderUtils.Render2D.drawRoundedRect(
                        innerX,
                        innerYValue,
                        7.0F,
                        7.0F,
                        ColorUtils.cachedRgbaOpacity(red, green, blue, opacity),
                        7.0F);
                RenderUtils.Render2D.drawRoundedOutline(
                        innerX - 0.75F,
                        innerYValue - 0.75F,
                        8.5F,
                        8.5F,
                        0.25F,
                        ColorUtils.cachedRgbaOpacity(
                                red, green, blue, opacity * (0.4F + 0.6F * hoverProgress2)),
                        7.0F);
                RenderUtils.Render2D.drawShadow(
                        innerX,
                        innerYValue,
                        7.0F,
                        7.0F,
                        ColorUtils.cachedRgbaOpacity(red, green, blue, 0.1F * opacity),
                        7.0F,
                        6.0F,
                        1.0F);
                if (colorSetting4.expanded) {
                    float[] afloat =
                            Color.RGBtoHSB(
                                    integer >> 16 & 0xFF,
                                    integer >> 8 & 0xFF,
                                    integer & 0xFF,
                                    null);
                    float f5 = animationRegistry2.smoothValue(text + ":h", afloat[0]);
                    float f6 = animationRegistry2.smoothValue(text + ":s", afloat[1]);
                    float f7 = animationRegistry2.smoothValue(text + ":v", afloat[2]);
                    float[] values = new float[] {f5, f6, f7};
                    float f8 = rectangleValue.x() + 6.0F;
                    float f9 = rectangleValue.width() - 12.0F;
                    byte b0 = 16;
                    float f10 = f9 / (float) b0;
                    float innerY = rectangleValue.y() + 13.0F + 2.0F + (float) 0 * 10.0F;

                    for (int i1 = 0; i1 < b0; i1++) {
                        float f12 = (float) i1 / (float) b0;
                        float f13 = (float) (i1 + 1) / (float) b0;
                        int color = Color.HSBtoRGB(f12, 1.0F, 1.0F);
                        int colorValue = Color.HSBtoRGB(f13, 1.0F, 1.0F);
                        int l1 = ColorUtils.withOpacity(color, opacity);
                        int i2 = ColorUtils.withOpacity(colorValue, opacity);
                        RenderUtils.Render2D.drawCornerGradient(
                                f8 + (float) i1 * f10,
                                innerY,
                                f10 + (i1 == b0 - 1 ? 0.0F : 0.5F),
                                3.5F,
                                new int[] {l1, i2, i2, l1},
                                i1 == 0 ? 2.0F : 0.0F,
                                i1 == b0 - 1 ? 2.0F : 0.0F,
                                i1 == b0 - 1 ? 2.0F : 0.0F,
                                i1 == 0 ? 2.0F : 0.0F);
                    }

                    float f21 = f8 + f9 * values[0];
                    int color7 = Color.HSBtoRGB(f5, 1.0F, 1.0F);
                    RenderUtils.Render2D.drawRoundedRect(
                            f21 - 2.5F,
                            innerY - 0.75F,
                            5.0F,
                            5.0F,
                            ColorUtils.grayscaleOpacity(255, opacity),
                            5.0F);
                    RenderUtils.Render2D.drawRoundedRect(
                            f21 - 1.75F,
                            innerY,
                            3.5F,
                            3.5F,
                            ColorUtils.withOpacity(color7, opacity),
                            5.0F);
                    innerY = rectangleValue.y() + 13.0F + 2.0F + (float) 1 * 10.0F;

                    for (int k2 = 0; k2 < b0; k2++) {
                        float f22 = (float) k2 / (float) b0;
                        float f24 = (float) (k2 + 1) / (float) b0;
                        int color8 = Color.HSBtoRGB(f5, f22, f7);
                        int color9 = Color.HSBtoRGB(f5, f24, f7);
                        int j4 = ColorUtils.withOpacity(color8, opacity);
                        int l4 = ColorUtils.withOpacity(color9, opacity);
                        RenderUtils.Render2D.drawCornerGradient(
                                f8 + (float) k2 * f10,
                                innerY,
                                f10 + (k2 == b0 - 1 ? 0.0F : 0.5F),
                                3.5F,
                                new int[] {j4, l4, l4, j4},
                                k2 == 0 ? 2.0F : 0.0F,
                                k2 == b0 - 1 ? 2.0F : 0.0F,
                                k2 == b0 - 1 ? 2.0F : 0.0F,
                                k2 == 0 ? 2.0F : 0.0F);
                    }

                    f21 = f8 + f9 * values[1];
                    color7 = Color.HSBtoRGB(f5, f6, f7);
                    RenderUtils.Render2D.drawRoundedRect(
                            f21 - 2.5F,
                            innerY - 0.75F,
                            5.0F,
                            5.0F,
                            ColorUtils.grayscaleOpacity(255, opacity),
                            5.0F);
                    RenderUtils.Render2D.drawRoundedRect(
                            f21 - 1.75F,
                            innerY,
                            3.5F,
                            3.5F,
                            ColorUtils.withOpacity(color7, opacity),
                            5.0F);
                    innerY = rectangleValue.y() + 13.0F + 2.0F + (float) 2 * 10.0F;

                    for (int l2 = 0; l2 < b0; l2++) {
                        float f23 = (float) l2 / (float) b0;
                        float f25 = (float) (l2 + 1) / (float) b0;
                        int color10 = Color.HSBtoRGB(f5, f6, f23);
                        int color11 = Color.HSBtoRGB(f5, f6, f25);
                        int k4 = ColorUtils.withOpacity(color10, opacity);
                        int i5 = ColorUtils.withOpacity(color11, opacity);
                        RenderUtils.Render2D.drawCornerGradient(
                                f8 + (float) l2 * f10,
                                innerY,
                                f10 + (l2 == b0 - 1 ? 0.0F : 0.5F),
                                3.5F,
                                new int[] {k4, i5, i5, k4},
                                l2 == 0 ? 2.0F : 0.0F,
                                l2 == b0 - 1 ? 2.0F : 0.0F,
                                l2 == b0 - 1 ? 2.0F : 0.0F,
                                l2 == 0 ? 2.0F : 0.0F);
                    }

                    f21 = f8 + f9 * values[2];
                    color7 = Color.HSBtoRGB(f5, f6, f7);
                    RenderUtils.Render2D.drawRoundedRect(
                            f21 - 2.5F,
                            innerY - 0.75F,
                            5.0F,
                            5.0F,
                            ColorUtils.grayscaleOpacity(255, opacity),
                            5.0F);
                    RenderUtils.Render2D.drawRoundedRect(
                            f21 - 1.75F,
                            innerY,
                            3.5F,
                            3.5F,
                            ColorUtils.withOpacity(color7, opacity),
                            5.0F);
                }
            }
        }
    }

    public void render(AnimationRegistry animationRegistry2, float strength) {
        if (this.module != null && !(this.bounds.width() <= 0.0F)) {
            Rectangle rectangleValue = this.bounds;
            RenderUtils.Render2D.drawShadow(
                    rectangleValue.x(),
                    rectangleValue.y(),
                    rectangleValue.width(),
                    rectangleValue.height() - 0.5F,
                    ColorUtils.grayscaleOpacity(0, 0.15F * strength),
                    8.0F,
                    15.0F,
                    1.0F);
            RenderUtils.Blur.drawRoundedBlur(
                    rectangleValue.x(),
                    rectangleValue.y(),
                    rectangleValue.width(),
                    rectangleValue.height(),
                    strength,
                    8.0F,
                    ColorUtils.scaleAlpha(
                            ColorUtils.darken(ColorUtils.themeBackground(), 0.6F), strength));
            RenderUtils.Render2D.drawRoundedOutline(
                    rectangleValue.x(),
                    rectangleValue.y(),
                    rectangleValue.width(),
                    rectangleValue.height(),
                    0.5F,
                    ColorUtils.withOpacity(ColorUtils.themeAccent(), strength * 0.35F),
                    8.0F);
            Rectangle headerBoundsValue = this.headerBounds;
            String name = this.module.getName();
            animationRegistry2.drawHoverBackground(
                    headerBoundsValue,
                    animationRegistry2.updateHover(name + ":header", headerBoundsValue),
                    strength);
            Font font = Fonts.CATEGORY_ICONS;
            float f1 = headerBoundsValue.x() + 6.0F;
            float f2 = headerBoundsValue.y() + 5.2F;
            ColorUtils.scaleAlpha(ColorUtils.themeAccent(), strength);
            font.drawText("U", f1, f2, 6.5F);
            font = Fonts.SF_REGULAR;
            String stringValue = this.title;
            f1 = headerBoundsValue.x() + 17.0F;
            f2 = headerBoundsValue.y() + 4.4F;
            ColorUtils.grayscaleOpacity(200, strength);
            font.drawText(stringValue, f1, f2, 6.5F);
            ScissorStack.push(
                    rectangleValue.x(),
                    rectangleValue.y() + 5.0F + 16.0F + 3.0F,
                    rectangleValue.width(),
                    rectangleValue.height() - 24.0F - 5.0F,
                    2.0F);
            if (this.showModuleToggle) {
                Rectangle toggleBoundsValue = this.toggleBounds;
                String nameValue = this.module.getName();
                animationRegistry2.drawToggle(
                        toggleBoundsValue,
                        "On/Off",
                        this.module.isEnabled(),
                        nameValue + ":enabled",
                        strength);
            }

            for (ModuleSettingsPanel.PanelRow panelRow : this.rows) {
                this.drawRow(animationRegistry2, panelRow, strength);
            }

            ScissorStack.pop();
        }
    }

    private float getOptionsHeight(List<String> list, float f) {
        Font font = Fonts.SF_REGULAR;
        float f1 = 0.0F;
        float f2 = 0.0F;

        for (String stringValue : list) {
            float f3 = font.measureWidth(stringValue, 5.5F) + 7.0F;
            if (f1 + f3 > f && f1 > 0.0F) {
                f1 = 0.0F;
                f2 += 10.5F;
            }

            f1 += f3 + 2.5F;
        }

        return f2 + 9.0F;
    }

    public boolean mouseDragged(float f, float f1) {
        if (this.dragging) {
            this.x = f - this.dragOffsetX;
            this.y = f1 - this.dragOffsetY;
            return true;
        } else if (this.draggedSlider != null) {
            this.updateSlider(this.draggedSlider, this.sliderBounds, f);
            return true;
        } else if (this.draggedColor != null) {
            this.updateColorChannel(f);
            return true;
        } else {
            return false;
        }
    }

    public ModuleSettingsPanel() {
        this.bounds = Rectangle.EMPTY;
        this.headerBounds = Rectangle.EMPTY;
        this.toggleBounds = Rectangle.EMPTY;
        this.rows = new ArrayList<>();
        this.minimumPanelHeight = 82.0F;
        this.showModuleToggle = true;
        this.sliderBounds = Rectangle.EMPTY;
        this.colorBounds = Rectangle.EMPTY;
    }

    public void closeColorPickers() {
        for (ModuleSettingsPanel.PanelRow panelRow : this.rows) {
            if (panelRow.setting instanceof ColorSetting colorSetting4) {
                colorSetting4.expanded = false;
            }
        }

        this.draggedColor = null;
    }

    private void updateSlider(SliderSetting sliderSetting2, Rectangle rectangleValue, float f) {
        float f1 = rectangleValue.x() + 6.0F;
        float f2 = Math.max(1.0F, rectangleValue.width() - 12.0F);
        float f3 = MathHelper.clamp((f - f1) / f2, 0.0F, 1.0F);
        sliderSetting2.setValue(
                MathHelper.clamp(
                        MathUtils.quantize(
                                sliderSetting2.minValue
                                        + (sliderSetting2.maxValue - sliderSetting2.minValue) * f3,
                                sliderSetting2.step),
                        sliderSetting2.minValue,
                        sliderSetting2.maxValue));
    }

    public boolean mouseScrolled(float mouseX, float mouseY, double d0) {
        if (this.module != null && this.bounds.contains(mouseX, mouseY)) {
            this.scrollTarget =
                    MathUtils.clamp(
                            (float) ((double) this.scrollTarget - d0 * 18.0), 0.0F, this.maxScroll);
            return true;
        } else {
            return false;
        }
    }

    private void layoutOptions(
            ModuleSettingsPanel.PanelRow panelRow,
            ModeSetting modeSetting2,
            float f,
            float f1,
            float f2) {
        panelRow.optionBounds.clear();
        Font font = Fonts.SF_REGULAR;
        float f3 = 0.0F;
        float f4 = 0.0F;

        for (String stringValue : modeSetting2.modes) {
            float f5 = font.measureWidth(stringValue, 5.5F) + 7.0F;
            if (f3 + f5 > f2 && f3 > 0.0F) {
                f3 = 0.0F;
                f4 += 10.5F;
            }

            panelRow.optionBounds.add(new Rectangle(f + f3, f1 + f4, f5, 9.0F));
            f3 += f5 + 2.5F;
        }
    }

    public Rectangle getBounds() {
        return this.bounds;
    }

    public void stopDragging() {
        this.dragging = false;
        this.draggedSlider = null;
        this.draggedColor = null;
    }

    public void layout(
            Module moduleValue,
            String stringValue,
            float f,
            float f1,
            float f2,
            float f3,
            AnimationRegistry animationRegistry2) {
        this.scroll = this.scroll + (this.scrollTarget - this.scroll) * 0.2F;
        this.rows.clear();
        this.module = moduleValue;
        this.title = stringValue;
        if (moduleValue == null) {
            this.bounds = Rectangle.EMPTY;
            this.toggleBounds = Rectangle.EMPTY;
            this.headerBounds = Rectangle.EMPTY;
        } else {
            if (!this.positionInitialized) {
                this.x = f;
                this.y = f1;
                this.positionInitialized = true;
            }

            this.x = MathUtils.clamp(this.x, 4.0F, Math.max(4.0F, f2 - 168.0F - 4.0F));
            this.y = MathUtils.clamp(this.y, 4.0F, Math.max(4.0F, f3 - 16.0F - 30.0F));
            float f4 = this.x + 6.0F;
            float f5 = 156.0F;
            float f6 = this.y + 5.0F + 16.0F + 3.0F;
            this.headerBounds = new Rectangle(f4, this.y + 5.0F, f5, 16.0F);
            float f7 = f3 - this.minimumPanelHeight;
            float f8 = Math.max(60.0F, f7 - f6);
            float f9 = f6 - this.scroll;
            if (this.showModuleToggle) {
                this.toggleBounds = new Rectangle(f4, f9, f5, 13.0F);
                f9 += 16.0F;
            } else {
                this.toggleBounds = Rectangle.EMPTY;
            }

            for (Setting setting : moduleValue.getSettings()) {
                boolean flagx;
                flagx =
                        !(!(setting instanceof BooleanSetting)
                                && !(setting instanceof SliderSetting)
                                && !(setting instanceof ModeSetting)
                                && !(setting instanceof ColorSetting)
                                && !(setting instanceof ButtonSetting));

                if (flagx) {
                    String name = moduleValue.getName();
                    String nameValue = setting.getName();
                    String name2 = name;
                    TimedAnimation timedAnimation4 =
                            animationRegistry2.getOrCreateAnimation(
                                    name2 + ":" + nameValue + ":vis");
                    timedAnimation4.setDirection(
                            (Boolean) setting.getVisibility().get()
                                    ? AnimationDirection.FORWARDS
                                    : AnimationDirection.BACKWARDS);
                    float value = timedAnimation4.getValue();
                    if (!(value <= 0.01F)) {
                        ModuleSettingsPanel.PanelRow panelRow =
                                new ModuleSettingsPanel.PanelRow(setting, setting.getName());
                        panelRow.opacity = value;
                        float f11 = 13.0F;
                        if (setting instanceof SliderSetting) {
                            f11 = 20.0F;
                        } else if (setting instanceof ButtonSetting) {
                            f11 = 11.0F;
                        } else if (setting instanceof ModeSetting modeSetting2) {
                            f11 =
                                    15.0F
                                            + this.getOptionsHeight(modeSetting2.modes, f5 - 12.0F)
                                            + 2.0F;
                        } else if (setting instanceof ColorSetting colorSetting4
                                && colorSetting4.expanded) {
                            f11 = 40.0F;
                        }

                        panelRow.bounds = new Rectangle(f4, f9, f5, f11);
                        if (setting instanceof ModeSetting modeSetting3) {
                            this.layoutOptions(
                                    panelRow,
                                    modeSetting3,
                                    f4 + 6.0F,
                                    f9 + 13.0F + 2.0F,
                                    f5 - 12.0F);
                        }

                        this.rows.add(panelRow);
                        f9 += (f11 + 3.0F) * value;
                    }
                }
            }

            float f12 = f9 + this.scroll - f6;
            this.maxScroll = Math.max(0.0F, f12 - f8);
            this.scrollTarget = MathUtils.clamp(this.scrollTarget, 0.0F, this.maxScroll);
            float f13 = 24.0F + Math.min(f12, f8) + 5.0F;
            this.bounds = new Rectangle(this.x, this.y, 168.0F, f13);
        }
    }

    private void updateColorChannel(float f) {
        if (this.draggedColor != null) {
            int integer = this.draggedColor.getColor();
            float[] afloat =
                    Color.RGBtoHSB(integer >> 16 & 0xFF, integer >> 8 & 0xFF, integer & 0xFF, null);
            float value =
                    MathUtils.clamp(
                            (f - (this.colorBounds.x() + 6.0F))
                                    / Math.max(1.0F, this.colorBounds.width() - 12.0F),
                            0.0F,
                            1.0F);
            float[] values = new float[] {afloat[0], afloat[1], afloat[2]};
            values[this.colorChannel] = value;
            int j = Color.HSBtoRGB(values[0], values[1], values[2]);
            this.draggedColor.setValue(integer & 0xFF000000 | j & 16777215);
        }
    }

    public boolean mouseClicked(float mouseX, float mouseY, int i) {
        if (this.module != null && this.bounds.contains(mouseX, mouseY)) {
            if (this.headerBounds.contains(mouseX, mouseY)) {
                if (i == 0) {
                    this.dragging = true;
                    this.dragOffsetX = mouseX - this.x;
                    this.dragOffsetY = mouseY - this.y;
                }

                return true;
            } else if (this.showModuleToggle && this.toggleBounds.contains(mouseX, mouseY)) {
                if (i == 0) {
                    Module moduleValue = this.module;
                    if (!this.module.isEnabled()) {
                        moduleValue.setEnabled(true, false);
                    } else {
                        moduleValue.setEnabled(false, false);
                    }
                }

                return true;
            } else {
                for (ModuleSettingsPanel.PanelRow panelRow : this.rows) {
                    if (panelRow.bounds.contains(mouseX, mouseY)) {
                        Setting setting = panelRow.setting;
                        if (setting instanceof BooleanSetting booleanSetting) {
                            if (i == 0) {
                                if (!booleanSetting.isOn()) {
                                    booleanSetting.setValue(true);
                                } else {
                                    booleanSetting.setValue(false);
                                }
                            }
                        } else if (setting instanceof SliderSetting sliderSetting2) {
                            if (i == 0) {
                                this.draggedSlider = sliderSetting2;
                                this.sliderBounds = panelRow.bounds;
                                this.updateSlider(sliderSetting2, panelRow.bounds, mouseX);
                            }
                        } else if (setting instanceof ModeSetting modeSetting2) {
                            if (i == 0) {
                                for (int j = 0; j < panelRow.optionBounds.size(); j++) {
                                    if (panelRow.optionBounds.get(j).contains(mouseX, mouseY)) {
                                        modeSetting2.setValue(modeSetting2.modes.get(j));
                                        break;
                                    }
                                }
                            }
                        } else if (setting instanceof ColorSetting colorSetting4 && i == 0) {
                            if (mouseY <= panelRow.bounds.y() + 13.0F) {
                                if (!colorSetting4.expanded) {
                                    colorSetting4.expanded = true;
                                } else {
                                    colorSetting4.expanded = false;
                                }
                            } else if (colorSetting4.expanded) {
                                for (int colorChannelValue = 0;
                                        colorChannelValue < 3;
                                        colorChannelValue++) {
                                    float f2 =
                                            panelRow.bounds.y()
                                                    + 13.0F
                                                    + 2.0F
                                                    + (float) colorChannelValue * 10.0F;
                                    if (MathUtils.containsPoint(
                                            mouseX,
                                            mouseY,
                                            panelRow.bounds.x() + 6.0F,
                                            f2 - 2.5F,
                                            panelRow.bounds.width() - 12.0F,
                                            9.0F)) {
                                        this.draggedColor = colorSetting4;
                                        this.colorChannel = colorChannelValue;
                                        this.colorBounds = panelRow.bounds;
                                        this.updateColorChannel(mouseX);
                                    }
                                }
                            }
                        }

                        return true;
                    }
                }

                return true;
            }
        } else {
            return false;
        }
    }

    @Environment(EnvType.CLIENT)
    private static final class PanelRow {
        private final List<Rectangle> optionBounds = new ArrayList<>();
        private float opacity;
        private Rectangle bounds;
        private final String label;
        private final Setting<?> setting;

        private PanelRow(Setting<?> settingValue, String stringValue) {
            this.bounds = Rectangle.EMPTY;
            this.opacity = 1.0F;
            this.setting = settingValue;
            this.label = stringValue;
        }
    }
}
