package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Block Outlines",
        category = ModuleCategory.RENDER,
        desc = "Replaces block outlines with animated theme-colored lines and smooth transitions.")
@Environment(EnvType.CLIENT)
public class BlockOutlinesModule extends Module {
    public final SliderSetting transitionSpeedSetting;
    public final BooleanSetting transitionsSetting = new BooleanSetting(this, "Transitions", true);
    public final SliderSetting alphaSetting;
    public final SliderSetting lineWidthSetting;

    public BlockOutlinesModule() {
        this.transitionSpeedSetting =
                new SliderSetting(this, "Transition Speed", 15.0F, 2.0F, 30.0F, 1.0F);
        this.lineWidthSetting = new SliderSetting(this, "Line Width", 2.0F, 0.5F, 5.0F, 0.5F);
        this.alphaSetting = new SliderSetting(this, "Alpha", 1.0F, 0.1F, 1.0F, 0.05F);
    }
}
