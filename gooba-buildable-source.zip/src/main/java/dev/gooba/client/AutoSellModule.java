package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@ModuleInfo(
        name = "Auto Sell",
        category = ModuleCategory.DONUT,
        desc = "Automatically runs /sell macro for supported sell menus")
@Environment(EnvType.CLIENT)
public class AutoSellModule extends Module {
    private AutoSellModule.State state;
    public final BooleanSetting randomizeDelaysSetting;
    private long startedAtMillis;

    public final BooleanSetting showStatsSetting;
    private int completedCycles;
    private final List<Integer> transferSlots;
    public final SliderSetting minClickDelaySetting;
    private boolean previousPauseOnLostFocus;
    public final BooleanSetting showMessagesSetting;
    public final SliderSetting maxClickDelaySetting;

    public final BooleanSetting backgroundModeSetting;

    private int transferredStacks;
    public final SliderSetting minCycleDelaySetting;
    private int stateTicks;
    public final SliderSetting maxCycleDelaySetting;
    private int stateDelayTicks;
    public final TextSetting menuTitleSetting = new TextSetting(this, "Menu Title", "Sell");

    public final SliderSetting menuOpenWaitSetting;

    private int sellButtonRetries;

    private void tickIdle() {
        if (this.stateTicks >= this.stateDelayTicks) {
            if (!this.isSellMenuOpen()) {
                if (!this.hasInventoryItems()) {
                    this.stateTicks = 0;
                    this.stateDelayTicks =
                            this.randomDelayBetween(
                                    (int) this.minCycleDelaySetting.getFloat().floatValue(),
                                    (int) this.maxCycleDelaySetting.getFloat().floatValue());
                } else {
                    this.sellButtonRetries = 0;
                    this.state = AutoSellModule.State.SEND_COMMAND;
                    this.stateTicks = 0;
                }
            } else if (!this.hasInventoryItems() && !this.hasMenuItems()) {
                this.stateTicks = 0;
                this.stateDelayTicks =
                        this.randomDelayBetween(
                                (int) this.minCycleDelaySetting.getFloat().floatValue(),
                                (int) this.maxCycleDelaySetting.getFloat().floatValue());
            } else {
                this.state = AutoSellModule.State.FILLING_ITEMS;
                this.stateTicks = 0;
                this.collectTransferSlots();
            }
        }
    }

    private void tickPostFillWait() {
        if (this.stateTicks >= this.stateDelayTicks) {
            this.state = AutoSellModule.State.CLICK_SELL;
            this.stateTicks = 0;
        }
    }

    private boolean isSellMenuOpen() {
        return !(client.currentScreen instanceof GenericContainerScreen)
                ? false
                : client.currentScreen
                        .getTitle()
                        .getString()
                        .trim()
                        .equalsIgnoreCase(this.menuTitleSetting.getText().trim());
    }

    private int randomizeDelay(int i) {
        if (!this.randomizeDelaysSetting.isOn()) {
            return Math.max(0, i);
        } else {
            byte b0 = 1;
            return Math.max(0, i + ThreadLocalRandom.current().nextInt(-b0, b0 + 1));
        }
    }

    private GenericContainerScreenHandler getContainerHandler() {
        return client.currentScreen instanceof GenericContainerScreen genericcontainerscreen
                ? genericcontainerscreen.getScreenHandler()
                : null;
    }

    private void tickReopenWait() {
        if (this.stateTicks >= this.stateDelayTicks) {
            this.state = AutoSellModule.State.SEND_COMMAND;
            this.stateTicks = 0;
        }
    }

    private int randomDelayBetween(int i, int j) {
        int k = Math.min(i, j);
        int l = Math.max(i, j);
        int i11;
        if (k == l) {
            i11 = k;
        } else {
            i11 = ThreadLocalRandom.current().nextInt(k, l + 1);
        }

        if (this.randomizeDelaysSetting.isOn()) {
            i11 += ThreadLocalRandom.current().nextInt(-2, 3);
        }

        return Math.max(0, i11);
    }

    public AutoSellModule() {
        this.minCycleDelaySetting =
                new SliderSetting(this, "Min Cycle Delay", 1.0F, 0.0F, 20.0F, 1.0F);
        this.maxCycleDelaySetting =
                new SliderSetting(this, "Max Cycle Delay", 3.0F, 0.0F, 20.0F, 1.0F);
        this.minClickDelaySetting =
                new SliderSetting(this, "Min Click Delay", 1.0F, 0.0F, 20.0F, 1.0F);
        this.maxClickDelaySetting =
                new SliderSetting(this, "Max Click Delay", 3.0F, 0.0F, 20.0F, 1.0F);
        this.menuOpenWaitSetting =
                new SliderSetting(this, "Menu Open Wait", 3.0F, 0.0F, 20.0F, 1.0F);
        this.randomizeDelaysSetting = new BooleanSetting(this, "Randomize Delays", true);
        this.showMessagesSetting = new BooleanSetting(this, "Show Messages", true);
        this.showStatsSetting = new BooleanSetting(this, "Show Stats", true);
        this.backgroundModeSetting = new BooleanSetting(this, "Background Mode", true);

        this.state = AutoSellModule.State.IDLE;
        this.stateDelayTicks = 1;
        this.transferSlots = new ArrayList<>();
        this.previousPauseOnLostFocus = true;
    }

    private int findSellButton(GenericContainerScreenHandler genericcontainerscreenhandler) {
        byte b0 = -1;
        if (b0 >= 0) {
            return b0;
        } else {
            int i = -1;

            for (int j = 0; j < genericcontainerscreenhandler.getRows() * 9; j++) {
                Slot slot = genericcontainerscreenhandler.getSlot(j);
                if (slot != null && slot.hasStack()) {
                    ItemStack itemstack = slot.getStack();
                    if (itemstack.getItem() == Items.LIME_STAINED_GLASS_PANE
                            || itemstack.getItem() == Items.GREEN_STAINED_GLASS_PANE) {
                        i = j;
                    }
                }
            }

            return i;
        }
    }

    private void tickPostSellWait() {
        if (this.stateTicks >= this.stateDelayTicks) {
            if (this.isSellMenuOpen()) {
                if (!this.hasInventoryItems() && !this.hasMenuItems()) {
                    this.state = AutoSellModule.State.IDLE;
                    this.stateTicks = 0;
                    this.stateDelayTicks =
                            this.randomDelayBetween(
                                    (int) this.minCycleDelaySetting.getFloat().floatValue(),
                                    (int) this.maxCycleDelaySetting.getFloat().floatValue());
                } else {
                    this.state = AutoSellModule.State.FILLING_ITEMS;
                    this.stateTicks = 0;
                    this.collectTransferSlots();
                }
            } else {
                this.state = AutoSellModule.State.IDLE;
                this.stateTicks = 0;
                this.stateDelayTicks = this.randomizeDelay(1);
            }
        }
    }

    private void tickWaitMenu() {
        if (this.isSellMenuOpen()) {
            this.state = AutoSellModule.State.FILLING_ITEMS;
            this.stateTicks = 0;
            this.collectTransferSlots();
        } else if (this.stateTicks >= this.stateDelayTicks + 20) {
            if (this.showMessagesSetting.isOn()) {
                this.sendMessage("§8[§a$§8] §cMenu did not open, retrying.");
            }

            this.state = AutoSellModule.State.IDLE;
            this.stateTicks = 0;
            this.stateDelayTicks = this.randomizeDelay(3);
        }
    }

    private void clickSellButton() {
        if (!this.isSellMenuOpen()) {
            this.state = AutoSellModule.State.IDLE;
            this.stateTicks = 0;
            this.stateDelayTicks = this.randomizeDelay(2);
        } else {
            GenericContainerScreenHandler genericcontainerscreenhandler =
                    this.getContainerHandler();
            if (genericcontainerscreenhandler == null) {
                this.state = AutoSellModule.State.IDLE;
                this.stateTicks = 0;
            } else {
                int i = this.findSellButton(genericcontainerscreenhandler);
                if (i == -1) {
                    this.sellButtonRetries++;
                    if (this.sellButtonRetries > 3) {
                        if (this.showMessagesSetting.isOn()) {
                            this.sendMessage(
                                    "§8[§a$§8] §cSell button not found after §e3 §cretries.");
                        }

                        this.sellButtonRetries = 0;
                        if (client.player != null && client.currentScreen != null) {
                            client.player.closeHandledScreen();
                        }

                        this.state = AutoSellModule.State.COOLDOWN;
                        this.stateTicks = 0;
                        this.stateDelayTicks =
                                this.randomDelayBetween(
                                        (int) this.minCycleDelaySetting.getFloat().floatValue(),
                                        (int) this.maxCycleDelaySetting.getFloat().floatValue());
                    } else {
                        if (this.showMessagesSetting.isOn()) {
                            int sellButtonRetriesValue = this.sellButtonRetries;
                            this.sendMessage(
                                    "§8[§a$§8] §eSell button not found, reopening menu. §7Retry §e"
                                            + sellButtonRetriesValue
                                            + "§7/§e3");
                        }

                        if (client.player != null && client.currentScreen != null) {
                            client.player.closeHandledScreen();
                        }

                        this.state = AutoSellModule.State.REOPEN_MENU;
                        this.stateTicks = 0;
                        this.stateDelayTicks = this.randomizeDelay(3);
                    }
                } else {
                    this.sellButtonRetries = 0;
                    if (client.interactionManager != null && client.player != null) {
                        client.interactionManager.clickSlot(
                                genericcontainerscreenhandler.syncId,
                                i,
                                0,
                                SlotActionType.PICKUP,
                                client.player);
                    }

                    this.completedCycles++;
                    if (this.showMessagesSetting.isOn()) {
                        int completedCyclesValue = this.completedCycles;
                        this.sendMessage("§8[§a$§8] §aSold! §7Cycle §e#" + completedCyclesValue);
                    }

                    this.state = AutoSellModule.State.POST_SELL_WAIT;
                    this.stateTicks = 0;
                    this.stateDelayTicks = this.randomizeDelay(1);
                }
            }
        }
    }

    private void closeMenu() {
        if (client.player != null && client.currentScreen != null) {
            client.player.closeHandledScreen();
        }

        this.state = AutoSellModule.State.COOLDOWN;
        this.stateTicks = 0;
        this.stateDelayTicks =
                this.randomDelayBetween(
                        (int) this.minCycleDelaySetting.getFloat().floatValue(),
                        (int) this.maxCycleDelaySetting.getFloat().floatValue());
    }

    private boolean hasMenuItems() {
        GenericContainerScreenHandler genericcontainerscreenhandler = this.getContainerHandler();
        if (genericcontainerscreenhandler == null) {
            return false;
        } else {
            for (int i = 0; i < genericcontainerscreenhandler.getRows() * 9; i++) {
                Slot slot = genericcontainerscreenhandler.getSlot(i);
                if (slot != null && slot.hasStack()) {
                    ItemStack itemstack = slot.getStack();
                    if (itemstack.getItem() != Items.LIME_STAINED_GLASS_PANE
                            && itemstack.getItem() != Items.GREEN_STAINED_GLASS_PANE
                            && itemstack.getItem() != Items.GRAY_STAINED_GLASS_PANE
                            && itemstack.getItem() != Items.BLACK_STAINED_GLASS_PANE
                            && itemstack.getItem() != Items.RED_STAINED_GLASS_PANE
                            && itemstack.getItem() != Items.AIR) {
                        return true;
                    }
                }
            }

            return false;
        }
    }

    private void tickCooldown() {
        if (this.stateTicks >= this.stateDelayTicks) {
            this.state = AutoSellModule.State.IDLE;
            this.stateTicks = 0;
            this.stateDelayTicks =
                    this.randomDelayBetween(
                            (int) this.minCycleDelaySetting.getFloat().floatValue(),
                            (int) this.maxCycleDelaySetting.getFloat().floatValue());
        }
    }

    @Override
    protected void onEnable() {
        this.state = AutoSellModule.State.IDLE;
        this.stateTicks = 0;
        this.stateDelayTicks = 1;
        this.transferSlots.clear();
        this.sellButtonRetries = 0;
        this.completedCycles = 0;
        this.transferredStacks = 0;
        this.startedAtMillis = System.currentTimeMillis();
        if (this.backgroundModeSetting.isOn() && client.options != null) {
            this.previousPauseOnLostFocus = client.options.pauseOnLostFocus;
            client.options.pauseOnLostFocus = false;
        }

        if (this.showMessagesSetting.isOn()) {
            int stateDelayTicksValue = this.stateDelayTicks;
            this.sendMessage(
                    "§8[§a$§8] §aAuto Sell §7activated. First cycle in §e"
                            + stateDelayTicksValue
                            + " §7ticks.");
            if (this.backgroundModeSetting.isOn()) {
                this.sendMessage("§8[§a$§8] §7Background mode §aenabled§7.");
            }
        }
    }

    @Override
    protected void onDisable() {
        if (this.backgroundModeSetting.isOn() && client.options != null) {
            client.options.pauseOnLostFocus = this.previousPauseOnLostFocus;
        }

        if (this.showMessagesSetting.isOn() && this.showStatsSetting.isOn()) {
            long i = (System.currentTimeMillis() - this.startedAtMillis) / 1000L;
            int completedCyclesValue = this.completedCycles;
            int transferredStacksValue = this.transferredStacks;
            String string = this.formatDuration(i);
            int transferredStacksValueValue = transferredStacksValue;
            int completedCyclesValueValue = completedCyclesValue;
            this.sendMessage(
                    "§8[§a$§8] §cAuto Sell §7deactivated. §eCycles: §a"
                            + completedCyclesValueValue
                            + " §8| §eItems: §a"
                            + transferredStacksValueValue
                            + " §8| §eTime: §a"
                            + string);
        }

        this.state = AutoSellModule.State.IDLE;
        this.stateTicks = 0;
        this.sellButtonRetries = 0;
    }

    private void sendMessage(String text) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal(text), false);
        }
    }

    private boolean hasInventoryItems() {
        if (client.player == null) {
            return false;
        } else {
            for (int i = 0; i < 36; i++) {
                ItemStack itemstack = client.player.getInventory().getStack(i);
                if (itemstack != null && !itemstack.isEmpty()) {
                    return true;
                }
            }

            return false;
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null) {
            this.stateTicks++;
            switch (this.state) {
                case IDLE:
                    this.tickIdle();
                    break;
                case SEND_COMMAND:
                    this.sendSellCommand();
                    break;
                case WAIT_MENU_OPEN:
                    this.tickWaitMenu();
                    break;
                case FILLING_ITEMS:
                    this.fillMenu();
                    break;
                case POST_FILL_WAIT:
                    this.tickPostFillWait();
                    break;
                case CLICK_SELL:
                    this.clickSellButton();
                    break;
                case POST_SELL_WAIT:
                    this.tickPostSellWait();
                    break;
                case CLOSE_MENU:
                    this.closeMenu();
                    break;
                case COOLDOWN:
                    this.tickCooldown();
                    break;
                case REOPEN_MENU:
                    this.tickReopenWait();
            }
        }
    }

    private String formatDuration(long i) {
        long j = i / 3600L;
        long k = i % 3600L / 60L;
        long l1 = i % 60L;
        if (j > 0L) {
            return j + "h " + k + "m " + l1 + "s";
        } else {
            return k > 0L ? k + "m " + l1 + "s" : l1 + "s";
        }
    }

    private void sendSellCommand() {
        if (client.player != null) {
            if (client.currentScreen != null) {
                client.player.closeHandledScreen();
                this.stateTicks = 0;
                this.stateDelayTicks = this.randomizeDelay(2);
                this.state = AutoSellModule.State.IDLE;
            } else if (client.player.networkHandler != null) {
                client.player.networkHandler.sendChatCommand("sell");
                this.state = AutoSellModule.State.WAIT_MENU_OPEN;
                this.stateTicks = 0;
                this.stateDelayTicks =
                        this.randomizeDelay((int) this.menuOpenWaitSetting.getFloat().floatValue());
                if (this.showMessagesSetting.isOn()) {
                    this.sendMessage("§8[§a$§8] §7Sent §e/sell §7command.");
                }
            }
        }
    }

    private void collectTransferSlots() {
        this.transferSlots.clear();
        GenericContainerScreenHandler genericcontainerscreenhandler = this.getContainerHandler();
        if (genericcontainerscreenhandler != null) {
            int i = genericcontainerscreenhandler.getRows() * 9;

            for (int j = i; j < genericcontainerscreenhandler.slots.size(); j++) {
                Slot slot = genericcontainerscreenhandler.getSlot(j);
                if (slot != null && slot.hasStack() && !slot.getStack().isEmpty()) {
                    this.transferSlots.add(j);
                }
            }

            if (this.showMessagesSetting.isOn() && !this.transferSlots.isEmpty()) {
                int count = this.transferSlots.size();
                this.sendMessage("§8[§a$§8] §7Filling §e" + count + " §7items into sell menu.");
            }
        }
    }

    private void fillMenu() {
        if (!this.isSellMenuOpen()) {
            this.state = AutoSellModule.State.IDLE;
            this.stateTicks = 0;
            this.stateDelayTicks = this.randomizeDelay(2);
        } else {
            GenericContainerScreenHandler genericcontainerscreenhandler =
                    this.getContainerHandler();
            if (genericcontainerscreenhandler == null) {
                this.state = AutoSellModule.State.IDLE;
                this.stateTicks = 0;
            } else {
                if (this.transferSlots.isEmpty()) {
                    this.collectTransferSlots();
                }

                if (this.transferSlots.isEmpty()) {
                    this.state = AutoSellModule.State.POST_FILL_WAIT;
                    this.stateTicks = 0;
                    this.stateDelayTicks = this.randomizeDelay(1);
                } else {
                    int i = 0;

                    for (int j : this.transferSlots) {
                        Slot slot = genericcontainerscreenhandler.getSlot(j);
                        if (slot != null && slot.hasStack() && !slot.getStack().isEmpty()) {
                            if (client.interactionManager != null && client.player != null) {
                                client.interactionManager.clickSlot(
                                        genericcontainerscreenhandler.syncId,
                                        j,
                                        0,
                                        SlotActionType.QUICK_MOVE,
                                        client.player);
                            }

                            this.transferredStacks++;
                            i++;
                        }
                    }

                    if (this.showMessagesSetting.isOn() && i > 0) {
                        this.sendMessage("§8[§a$§8] §7Moved §e" + i + " §7stacks into sell menu.");
                    }

                    this.state = AutoSellModule.State.POST_FILL_WAIT;
                    this.stateTicks = 0;
                    this.stateDelayTicks = this.randomizeDelay(1);
                }
            }
        }
    }

    @Environment(EnvType.CLIENT)
    private static enum State {
        IDLE,
        SEND_COMMAND,
        WAIT_MENU_OPEN,
        FILLING_ITEMS,
        POST_FILL_WAIT,
        CLICK_SELL,
        POST_SELL_WAIT,
        CLOSE_MENU,
        COOLDOWN,
        REOPEN_MENU;

        static {
        }
    }
}
