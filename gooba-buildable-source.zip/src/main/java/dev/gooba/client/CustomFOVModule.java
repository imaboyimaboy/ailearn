package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Custom FOV",
        category = ModuleCategory.OTHER,
        desc = "Changes your field of view.")
@Environment(EnvType.CLIENT)
public class CustomFOVModule extends Module {
    private static CustomFOVModule customFOVModule;
    public final SliderSetting fOVSetting =
            new SliderSetting(this, "FOV", 110.0F, 30.0F, 160.0F, 1.0F);

    public CustomFOVModule() {
        customFOVModule = this;
    }
}
