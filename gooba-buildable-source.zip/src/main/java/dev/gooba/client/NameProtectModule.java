package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Name Protect",
        category = ModuleCategory.PLAYER,
        desc = "Replaces your name and friend names in rendered text")
@Environment(EnvType.CLIENT)
public class NameProtectModule extends Module {
    public BooleanSetting everyoneSetting;
    public BooleanSetting hideFriendNamesSetting;
    public TextSetting protectedNameSetting = new TextSetting(this, "Protected Name", "goobaa");

    public NameProtectModule() {
        this.everyoneSetting = new BooleanSetting(this, "Everyone", false);
        this.hideFriendNamesSetting =
                new BooleanSetting(this, "Hide Friend Names", true)
                        .visibleWhen(() -> (!this.everyoneSetting.isOn()));
    }

    private void replacePlayerNames(TextRenderEvent textRenderEvent) {
        if (client.getNetworkHandler() != null) {
            client.getNetworkHandler()
                    .getPlayerList()
                    .forEach(
                            playerlistentry -> {
                                String text = playerlistentry.getProfile().name();
                                if (text != null && !text.isBlank()) {
                                    textRenderEvent.replaceText(text, this.protectedName());
                                }
                            });
        }
    }

    private void replaceFriendNames(TextRenderEvent textRenderEvent) {
        Gooba.getInstance()
                .getFriendManager()
                .getFriends()
                .forEach(text -> textRenderEvent.replaceText(text, "Friend"));
    }

    @EventHandler
    public void onTextRender(TextRenderEvent textRenderEvent) {
        textRenderEvent.replaceText(client.getSession().getUsername(), this.protectedName());
        if (this.everyoneSetting.isOn()) {
            this.replacePlayerNames(textRenderEvent);
        } else if (this.hideFriendNamesSetting.isOn()) {
            this.replaceFriendNames(textRenderEvent);
        }
    }

    public String protectedName() {
        String string = this.protectedNameSetting.getText();
        return string != null && !string.isBlank() ? string : "goobaa";
    }
}
