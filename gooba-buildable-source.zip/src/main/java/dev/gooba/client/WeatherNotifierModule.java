package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

@ModuleInfo(
        name = "Weather Notifier",
        category = ModuleCategory.OTHER,
        desc = "Notifies when rain or a thunderstorm starts and when rain ends.")
@Environment(EnvType.CLIENT)
public class WeatherNotifierModule extends Module {
    private boolean wasRaining;
    private boolean wasThundering;
    private ClientWorld lastWorld;

    private void reset() {
        this.lastWorld = null;
        this.wasRaining = false;
        this.wasThundering = false;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        ClientWorld clientworld = client.world;
        if (clientworld == null) {
            this.reset();
        } else {
            if (clientworld != this.lastWorld) {
                this.lastWorld = clientworld;
                this.wasRaining = false;
                this.wasThundering = false;
            }

            boolean isRaining = clientworld.isRaining();
            boolean isThundering = clientworld.isThundering();
            if (isThundering && !this.wasThundering) {
                this.notifyWeather(
                        "Weather Alert",
                        "Thunderstorm started!",
                        new ItemStack(Items.LIGHTNING_ROD));
            } else if (isRaining && !this.wasRaining) {
                this.notifyWeather(
                        "Weather Alert",
                        "It has started raining!",
                        new ItemStack(Items.WATER_BUCKET));
            }

            if (!isRaining && this.wasRaining) {
                this.notifyWeather("Weather Alert", "Rain ended!", new ItemStack(Items.SUNFLOWER));
            }

            this.wasRaining = isRaining;
            this.wasThundering = isThundering;
        }
    }

    private void notifyWeather(String text, String textValue, ItemStack itemstack) {
        NotificationManager.showItem(
                text + ": " + textValue, NotificationManager.Type.INFO, itemstack);
    }

    @Override
    protected void onDisable() {
        this.reset();
    }

    @Override
    protected void onEnable() {
        this.reset();
    }
}
