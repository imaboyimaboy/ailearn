package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public class FontInitializer {
    private static final Logger logger = LoggerFactory.getLogger("client/FontInitializer");

    private static void initializeOnRenderThread(MinecraftClient minecraftclient) {}

    public static void initialize() {}
}
