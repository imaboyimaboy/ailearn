package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class TickRateState implements MinecraftAccess {
    public static float multiplier = 1.0F;
}
