package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.List;

@ModuleInfo(
        name = "Panic",
        category = ModuleCategory.OTHER,
        desc = "Immediately disables every enabled module")
@Environment(EnvType.CLIENT)
public class PanicModule extends Module {
    private boolean pending;
    public final BooleanSetting resetSetting = new BooleanSetting(this, "Reset", false);

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (this.pending) {
            this.pending = false;
            if (this.resetSetting.isOn()) {
                resetAndDisableModules();
            } else {
                disableAllModules();
            }
        }
    }

    public static void resetAndDisableModules() {
        Gooba.getInstance().getConfigManager().restoreDefaults();
        disableAllModules();
        Gooba.getInstance().getConfigManager().saveState();
    }

    private static void disableAllModules() {
        for (Module module : List.copyOf(Gooba.getInstance().getModuleRegistry().values())) {
            if (module.isEnabled()) {
                module.setEnabled(false, false);
            }
        }
    }

    @Override
    protected void onDisable() {
        this.pending = false;
    }

    @Override
    protected void onEnable() {
        this.pending = true;
    }
}
