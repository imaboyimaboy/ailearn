package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Environment(EnvType.CLIENT)
public class FriendsList extends Command {

    private static final List<String> SUBCOMMANDS = List.of("add", "remove", "list");

    @Override
    public void execute(String[] astring) {
        if (astring.length == 0) {
            this.showUsage();
        } else {
            String text = astring[0].toLowerCase();
            switch (text.hashCode()) {
                case -934610812:
                    if (text.equals("remove")) {
                        if (astring.length < 2) {
                            ChatMessages.send("Usage: .friend remove <nickname>");
                            return;
                        }

                        String textValue = astring[1];
                        boolean flag1 =
                                Gooba.getInstance().getFriendManager().removeFriend(textValue);
                        if (flag1) {
                            ChatMessages.send(
                                    "§c" + textValue + "§r has been removed from friends");
                        } else {
                            ChatMessages.send("§7" + textValue + " not friends");
                        }

                        return;
                    }
                    break;
                case 96417:
                    if (text.equals("add")) {
                        if (astring.length < 2) {
                            ChatMessages.send("Usage: .friend add <nickname>");
                            return;
                        }

                        String text2 = astring[1];
                        boolean flag = Gooba.getInstance().getFriendManager().addFriend(text2);
                        if (flag) {
                            ChatMessages.send("§a" + text2 + "§r added as a friend");
                        } else {
                            ChatMessages.send("§7" + text2 + " already friends");
                        }

                        return;
                    }
                    break;
                case 3322014:
                    if (text.equals("list")) {
                        Set set = Gooba.getInstance().getFriendManager().getFriends();
                        if (set.isEmpty()) {
                            ChatMessages.send("§7Friend list is empty");
                        } else {
                            int count = set.size();
                            ChatMessages.send("§7Friends §8[" + count + "§8]§7:");
                            set.forEach(object -> ChatMessages.send("§a" + object));
                        }

                        return;
                    }
            }

            this.showUsage();
        }
    }

    public FriendsList() {
        super("friend", ".friend <add|remove|list> [name]", "Friends list");
    }

    @Override
    public List suggest(String text) {
        return SUBCOMMANDS.stream()
                .filter(textValue -> textValue.startsWith(text.toLowerCase()))
                .collect(Collectors.toList());
    }

    private void showUsage() {
        ChatMessages.send("§7.friend add/remove §f<nickname> §8| §7.friend list");
    }
}
