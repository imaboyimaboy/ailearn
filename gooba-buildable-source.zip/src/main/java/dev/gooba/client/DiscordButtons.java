package dev.gooba.client;

import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

@FieldOrder({"numButtons", "buttons"})
@Environment(EnvType.CLIENT)
public class DiscordButtons extends Structure {
    public byte[] buttons = new byte[2560];
    public int numButtons;

    /** 8-slot native layout: 256 UTF-8 URL bytes and 64 label bytes per slot. */
    public void setButtons(int count, String[] labels, String[] urls) {
        Arrays.fill(buttons, (byte) 0);
        numButtons = Math.min(Math.max(0, count), 8);
        for (int index = 0; index < 8; index++) {
            boolean present =
                    index < numButtons
                            && labels != null
                            && urls != null
                            && index < labels.length
                            && index < urls.length
                            && labels[index] != null
                            && urls[index] != null
                            && !labels[index].isEmpty()
                            && !urls[index].isEmpty();
            int offset = index * 320;
            copyUtf8(buttons, offset, 256, present ? urls[index] : "");
            copyUtf8(buttons, offset + 256, 64, present ? labels[index] : "");
        }
    }

    private static void copyUtf8(byte[] destination, int offset, int capacity, String value) {
        Arrays.fill(destination, offset, offset + capacity, (byte) 0);
        byte[] encoded = (value == null ? "" : value).getBytes(StandardCharsets.UTF_8);
        System.arraycopy(encoded, 0, destination, offset, Math.min(encoded.length, capacity - 1));
    }
}
