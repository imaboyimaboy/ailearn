package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@ModuleInfo(
        name = "Spawner Protect",
        category = ModuleCategory.DONUT,
        desc = "Protects your spawners.")
@Environment(EnvType.CLIENT)
public class SpawnerProtectModule extends Module {
    public final SliderSetting rotationSpeedSetting;
    public final SliderSetting depositDelaySetting;
    private double yawJitter;
    private int chestOpenTicks;
    public final SliderSetting breakDelaySetting =
            new SliderSetting(this, "Break Delay", 2.0F, 0.0F, 20.0F, 1.0F);
    private SpawnerProtectModule.State state;
    private final Set<BlockPos> brokenBlocks;
    private int depositDelayTicks;
    private int emptyScanCount;
    private String triggerReason;

    private BlockPos targetSpawner;
    private final Set<BlockPos> spawners;
    private boolean confirmingEmpty;
    private BlockPos blockPos2;
    private boolean miningStarted;
    private boolean attackPressed;
    private BlockPos targetChest;
    private int minedSpawnerCount;
    private boolean positionCalibrated;
    private Vec3d basePosition;
    public final TextSetting webhookURLSetting;
    private int depositedCount;
    private int miningDelayTicks;

    private int ticks;
    private int lastDepositSlot;
    private double pitchJitter;
    private boolean sneaking;
    private long triggeredAtMillis;

    private void depositNextStack(GenericContainerScreenHandler genericcontainerscreenhandler) {
        if (client.player != null) {
            int count = genericcontainerscreenhandler.slots.size();
            int j = count - 36;
            int k = Math.max(this.lastDepositSlot + 1, j);

            for (int l = 0; l < 36; l++) {
                int lastDepositSlotValue = j + (k - j + l) % 36;
                ItemStack itemstack =
                        genericcontainerscreenhandler.getSlot(lastDepositSlotValue).getStack();
                if (itemstack.isOf(Items.SPAWNER)) {
                    this.depositedCount = this.depositedCount + itemstack.getCount();
                    this.sendMessage(
                            String.format(
                                    "§8[§6SP§8] §eTransferring %d spawners from slot %d (Total:"
                                        + " %d)",
                                    itemstack.getCount(),
                                    lastDepositSlotValue,
                                    this.depositedCount));
                    if (client.interactionManager != null) {
                        client.interactionManager.clickSlot(
                                genericcontainerscreenhandler.syncId,
                                lastDepositSlotValue,
                                0,
                                SlotActionType.QUICK_MOVE,
                                client.player);
                    }

                    this.lastDepositSlot = lastDepositSlotValue;
                    return;
                }
            }

            if (this.lastDepositSlot >= j) {
                this.lastDepositSlot = j - 1;
            }
        }
    }

    private void walkToChest() {
        if (this.targetChest == null) {
            this.targetChest = this.findNearestEnderChest();
            if (this.targetChest == null) {
                this.sendMessage("§8[§6SP§8] §cNo ender chest found nearby!");
                this.state = SpawnerProtectModule.State.DISCONNECTING;
                return;
            }

            this.sendMessage("§8[§6SP§8] §aFound ender chest.");
        }

        this.walkToward(this.targetChest);
        if (client.player != null
                && client.player.getBlockPos().getSquaredDistance(this.targetChest) <= 9.0) {
            this.state = SpawnerProtectModule.State.OPENING_CHEST;
            this.chestOpenTicks = 0;
            this.stopWalking();
            this.sendMessage("§8[§6SP§8] §aReached ender chest. Attempting to open...");
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (!this.brokenBlocks.isEmpty() && client.world != null && client.player != null) {
            int i = 1442783778;
            WorldEspRenderer.clear();

            for (BlockPos blockpos : this.brokenBlocks) {
                Box box =
                        new Box(
                                (double) blockpos.getX(),
                                (double) blockpos.getY(),
                                (double) blockpos.getZ(),
                                (double) blockpos.getX() + 1.0,
                                (double) blockpos.getY() + 1.0,
                                (double) blockpos.getZ() + 1.0);
                WorldEspRenderer.enqueueBox(box, i, false);
            }

            WorldEspRenderer.flush(render3DEvent.getMatrixStack());
        }
    }

    private boolean isAimingAt(BlockPos blockpos) {
        if (client.player == null) {
            return false;
        } else {
            Vec3d vec3dx = Vec3d.ofCenter(blockpos);
            Vec3d vec3d1 = client.player.getEyePos();
            Vec3d vec3d2 = vec3dx.subtract(vec3d1).normalize();
            double d0 = Math.toDegrees(Math.atan2(-vec3d2.x, vec3d2.z)) + this.yawJitter;
            double d1 = Math.toDegrees(-Math.asin(vec3d2.y)) + this.pitchJitter;
            float f = MathHelper.wrapDegrees((float) (d0 - (double) client.player.getYaw()));
            float f1 = (float) (d1 - (double) client.player.getPitch());
            return (double) Math.abs(f) < 1.0 && (double) Math.abs(f1) < 1.0;
        }
    }

    public SpawnerProtectModule() {
        this.rotationSpeedSetting =
                new SliderSetting(this, "Rotation Speed", 22.5F, 1.0F, 90.0F, 0.5F);
        this.depositDelaySetting =
                new SliderSetting(this, "Deposit Delay", 0.0F, 0.0F, 20.0F, 1.0F);
        this.webhookURLSetting = new TextSetting(this, "Webhook URL", "");
        this.state = SpawnerProtectModule.State.AWAITING_RECALIBRATION;
        this.triggerReason = "";
        this.triggeredAtMillis = 0L;

        this.ticks = 0;
        this.lastDepositSlot = -1;
        this.sneaking = false;
        this.targetSpawner = null;
        this.emptyScanCount = 0;
        this.confirmingEmpty = false;
        this.miningStarted = false;
        this.targetChest = null;
        this.blockPos2 = null;
        this.chestOpenTicks = 0;
        this.miningDelayTicks = 0;
        this.depositDelayTicks = 0;
        this.attackPressed = false;
        this.depositedCount = 0;
        this.minedSpawnerCount = 0;
        this.yawJitter = 0.0;
        this.pitchJitter = 0.0;
        this.positionCalibrated = false;
        this.basePosition = null;
        this.spawners = new HashSet<>();
        this.brokenBlocks = ConcurrentHashMap.newKeySet();
    }

    @Override
    protected void onEnable() {
        this.brokenBlocks.clear();
        this.resetState();
        if (client.player != null) {
            this.state = SpawnerProtectModule.State.AWAITING_RECALIBRATION;
            this.sendMessage(
                    "§8[§6SP§8] §eSpawnerProtect activated. Calibrating position... Stand at your"
                        + " base.");
        }

        this.sendMessage(
                "§8[§6SP§8] §cEnsure your inventory is empty except for a silk touch pickaxe and an"
                    + " ender chest nearby!");
    }

    private BlockPos findNearestSpawner() {
        if (!this.spawners.isEmpty() && client.player != null) {
            BlockPos blockpos = null;
            double MAX_VALUE = Double.MAX_VALUE;
            Vec3d vec3dx =
                    new Vec3d(client.player.getX(), client.player.getY(), client.player.getZ());

            for (BlockPos blockposValue : this.spawners) {
                double squaredDistance = blockposValue.getSquaredDistance(vec3dx);
                if (squaredDistance < MAX_VALUE) {
                    MAX_VALUE = squaredDistance;
                    blockpos = blockposValue;
                }
            }

            return blockpos;
        } else {
            return null;
        }
    }

    private void mineSpawner() {
        if (!this.miningStarted && this.targetSpawner == null) {
            this.targetSpawner = this.findNearestSpawner();
            if (this.targetSpawner == null && !this.confirmingEmpty) {
                this.confirmingEmpty = true;
                this.emptyScanCount = 0;
                this.sendMessage("§8[§6SP§8] §eNo spawners found, waiting to confirm...");
            } else if (this.targetSpawner != null) {
                this.sendMessage("§8[§6SP§8] §aTargeting spawner.");
                this.randomizeAim();
                this.state = SpawnerProtectModule.State.GOING_TO_SPAWNERS;
            }
        } else if (this.targetSpawner != null) {
            double d0 =
                    new Vec3d(client.player.getX(), client.player.getY(), client.player.getZ())
                            .distanceTo(Vec3d.ofCenter(this.targetSpawner));
            if (d0 > 4.5 && this.state == SpawnerProtectModule.State.GOING_TO_SPAWNERS) {
                this.walkToward(this.targetSpawner);
            } else {
                if (this.state == SpawnerProtectModule.State.GOING_TO_SPAWNERS) {
                    this.state = SpawnerProtectModule.State.MINING_SPAWNER;
                    this.miningDelayTicks = 0;
                    this.stopWalking();
                }

                if (this.state == SpawnerProtectModule.State.MINING_SPAWNER
                        && !this.miningStarted) {
                    this.rotateToward(this.targetSpawner);
                    if (this.miningDelayTicks
                            < (int) this.breakDelaySetting.getFloat().floatValue()) {
                        this.miningDelayTicks++;
                    } else {
                        this.stopMining();
                        this.miningStarted = true;
                        this.sendMessage("§8[§6SP§8] §aInitiating mining of spawner.");
                        if (client.interactionManager != null) {
                            client.interactionManager.attackBlock(this.targetSpawner, Direction.UP);
                        }
                    }
                }
            }
        }

        if (this.state == SpawnerProtectModule.State.MINING_SPAWNER
                && this.miningStarted
                && this.targetSpawner != null) {
            this.rotateToward(this.targetSpawner);
            this.startMining(this.targetSpawner);
            if (client.world.getBlockState(this.targetSpawner).isAir()) {
                this.sendMessage("§8[§6SP§8] §aSpawner mined!");
                this.minedSpawnerCount++;
                this.blockPos2 = this.targetSpawner;
                this.randomizeAim();
                this.stopMining();
                this.miningStarted = false;
                this.targetSpawner = null;
                this.sendMessage("§8[§6SP§8] §eChecking for next spawner immediately...");
                this.state = SpawnerProtectModule.State.GOING_TO_SPAWNERS;
            }
        }

        if (this.confirmingEmpty) {
            this.confirmMiningComplete();
        }
    }

    private void confirmMiningComplete() {
        BlockPos blockpos = this.findNearestSpawner();
        if (blockpos != null) {
            this.confirmingEmpty = false;
            this.targetSpawner = blockpos;
            this.state = SpawnerProtectModule.State.GOING_TO_SPAWNERS;
            this.sendMessage("§8[§6SP§8] §aFound spawner.");
        } else {
            this.emptyScanCount++;
            if (this.emptyScanCount >= 5) {
                this.stopMining();
                this.miningStarted = false;
                this.setSneaking(false);
                this.randomizeAim();
                this.state = SpawnerProtectModule.State.GOING_TO_CHEST;
                this.sendMessage("§8[§6SP§8] §eAll spawners mined. Moving to ender chest...");
            }
        }
    }

    @Override
    protected void onDisable() {
        this.releaseInputs();
        this.spawners.clear();
        this.sendMessage("§8[§6SP§8] §eSpawnerProtect deactivated.");
    }

    private void walkToward(BlockPos blockpos) {
        if (client.player != null && client.options != null) {
            Vec3d vec3dx =
                    new Vec3d(client.player.getX(), client.player.getY(), client.player.getZ());
            Vec3d vec3d1 = Vec3d.ofCenter(blockpos);
            Vec3d vec3d2 = vec3d1.subtract(vec3dx).normalize();
            double d0 = Math.toDegrees(Math.atan2(-vec3d2.x, vec3d2.z));
            client.player.setYaw((float) d0);
            client.options.forwardKey.setPressed(true);
        }
    }

    private void resetState() {
        this.state = SpawnerProtectModule.State.AWAITING_RECALIBRATION;
        this.triggerReason = "";
        this.triggeredAtMillis = 0L;

        this.ticks = 0;
        this.lastDepositSlot = -1;
        this.setSneaking(false);
        this.targetSpawner = null;
        this.emptyScanCount = 0;
        this.confirmingEmpty = false;
        this.miningStarted = false;
        this.targetChest = null;
        this.blockPos2 = null;
        this.chestOpenTicks = 0;
        this.miningDelayTicks = 0;
        this.depositDelayTicks = 0;
        this.attackPressed = false;
        this.depositedCount = 0;
        this.minedSpawnerCount = 0;
        this.yawJitter = 0.0;
        this.pitchJitter = 0.0;
        this.positionCalibrated = false;
        this.basePosition = null;
        this.spawners.clear();
        this.releaseInputs();
    }

    private boolean hasSpawners() {
        if (client.player == null) {
            return false;
        } else {
            for (int i = 0; i < 36; i++) {
                ItemStack itemstack = client.player.getInventory().getStack(i);
                if (itemstack.isOf(Items.SPAWNER)) {
                    return true;
                }
            }

            return false;
        }
    }

    private void randomizeAim() {
        this.yawJitter = (Math.random() * 2.0 - 1.0) * 1.5;
        this.pitchJitter = (Math.random() * 2.0 - 1.0) * 1.5;
    }

    private void stopMining() {
        if (client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }

        if (this.attackPressed && client.options != null) {
            client.options.attackKey.setPressed(false);
            this.attackPressed = false;
        }
    }

    private void sendWebhook(String text, String textValue) {
        String stringValue = this.webhookURLSetting.getText();
        if (stringValue != null && !stringValue.isBlank()) {
            Thread thread =
                    new Thread(
                            () -> {
                                try {
                                    String text2 = this.escapeJson(text);
                                    String text3 = this.escapeJson(textValue);
                                    String text6 = text2;
                                    String text7 =
                                            "{\"content\":\""
                                                    + text6
                                                    + "\",\"allowed_mentions\":{\"parse\":[\"everyone\",\"roles\",\"users\"]},\"embeds\":[{\"title\":\""
                                                    + text3
                                                    + "\",\"color\":65280}]}";
                                    HttpClient httpclient = HttpClient.newHttpClient();
                                    HttpRequest httprequest =
                                            HttpRequest.newBuilder()
                                                    .uri(URI.create(stringValue.trim()))
                                                    .header("Content-Type", "application/json")
                                                    .POST(
                                                            BodyPublishers.ofString(
                                                                    text7, StandardCharsets.UTF_8))
                                                    .build();
                                    httpclient.send(httprequest, BodyHandlers.discarding());
                                } catch (Exception exception) {
                                }
                            },
                            "Goobaa-SpawnerProtect-WebhookThread");
            thread.setDaemon(true);
            thread.start();
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null) {
            this.ticks++;
            Vec3d vec3dx =
                    new Vec3d(client.player.getX(), client.player.getY(), client.player.getZ());
            this.scanSpawners();
            if (this.state == SpawnerProtectModule.State.AWAITING_RECALIBRATION) {
                if (this.ticks >= 10) {
                    this.basePosition = vec3dx;
                    this.positionCalibrated = true;
                    this.state = SpawnerProtectModule.State.IDLE;
                    this.sendMessage("§8[§6SP§8] §aBase position calibrated.");
                    this.sendMessage(
                            "§8[§6SP§8] §aSpawnerProtect now ACTIVE and monitoring for broken"
                                + " blocks!");
                } else if (this.ticks == 1) {
                    this.sendMessage("§8[§6SP§8] §eCalibrating position...");
                }
            } else if (this.positionCalibrated && this.basePosition != null) {
                double d0 = vec3dx.distanceTo(this.basePosition);
                if (d0 > 5.0) {
                    if (this.state == SpawnerProtectModule.State.IDLE) {
                        this.state = SpawnerProtectModule.State.POSITION_DISPLACED;
                        this.sendMessage(
                                String.format(
                                        "§8[§6SP§8] §eLeft protected zone (%.1fm away). Paused"
                                            + " until return.",
                                        d0));
                    }
                } else if (this.state == SpawnerProtectModule.State.POSITION_DISPLACED) {
                    this.state = SpawnerProtectModule.State.IDLE;
                    this.sendMessage(
                            "§8[§6SP§8] §aReturned to protected zone. Protection RESUMED.");
                }

                switch (this.state) {
                    case IDLE:
                    case AWAITING_RECALIBRATION:
                    default:
                        break;
                    case GOING_TO_SPAWNERS:
                    case MINING_SPAWNER:
                        this.mineSpawner();
                        break;
                    case GOING_TO_CHEST:
                        this.walkToChest();
                        break;
                    case OPENING_CHEST:
                        this.openChest();
                        break;
                    case DEPOSITING_ITEMS:
                        this.depositSpawners();
                        break;
                    case DISCONNECTING:
                        this.disconnectAfterProtection();
                        break;
                    case POSITION_DISPLACED:
                        this.releaseInputs();
                }
            } else {
                this.state = SpawnerProtectModule.State.AWAITING_RECALIBRATION;
                this.ticks = 0;
                this.sendMessage("§8[§6SP§8] §cPosition lost. Recalibrating...");
            }
        }
    }

    private BlockPos findNearestEnderChest() {
        if (client.player != null && client.world != null) {
            BlockPos blockpos = client.player.getBlockPos();
            BlockPos blockPos2Value = null;
            double MAX_VALUE = Double.MAX_VALUE;

            for (int i = -16; i <= 16; i++) {
                for (int j = -8; j <= 8; j++) {
                    for (int k = -16; k <= 16; k++) {
                        BlockPos blockPosValue = blockpos.add(i, j, k);
                        double squaredDistance =
                                blockPosValue.getSquaredDistance(
                                        new Vec3d(
                                                client.player.getX(),
                                                client.player.getY(),
                                                client.player.getZ()));
                        if (client.world.getBlockState(blockPosValue).isOf(Blocks.ENDER_CHEST)
                                && squaredDistance < MAX_VALUE) {
                            MAX_VALUE = squaredDistance;
                            blockPos2Value = blockPosValue.toImmutable();
                        }
                    }
                }
            }

            return blockPos2Value;
        } else {
            return null;
        }
    }

    private void rotateToward(BlockPos blockpos) {
        if (client.player != null) {
            Vec3d vec3dx = Vec3d.ofCenter(blockpos);
            Vec3d vec3d1 = client.player.getEyePos();
            Vec3d vec3d2 = vec3dx.subtract(vec3d1).normalize();
            double d0 = Math.toDegrees(Math.atan2(-vec3d2.x, vec3d2.z)) + this.yawJitter;
            double d1 = Math.toDegrees(-Math.asin(vec3d2.y)) + this.pitchJitter;
            float f = MathHelper.wrapDegrees(client.player.getYaw());
            float pitch = client.player.getPitch();
            float f2 = MathHelper.wrapDegrees((float) (d0 - (double) f));
            float f3 = (float) (d1 - (double) pitch);
            float f4 = this.rotationSpeedSetting.getFloat();
            client.player.setYaw(f + MathHelper.clamp(f2, -f4, f4));
            client.player.setPitch(pitch + MathHelper.clamp(f3, -f4, f4));
        }
    }

    private void startMining(BlockPos blockpos) {
        if (client.interactionManager != null && client.options != null && !this.attackPressed) {
            client.options.attackKey.setPressed(true);
            this.attackPressed = true;
            client.interactionManager.updateBlockBreakingProgress(blockpos, Direction.UP);
        }
    }

    private void scanSpawners() {
        if (client.world != null && client.player != null) {
            if (this.ticks % 20 == 0) {
                this.spawners.clear();
                BlockPos blockpos = client.player.getBlockPos();
                byte b0 = 50;

                for (int i = -b0; i <= b0; i++) {
                    for (int j = -b0; j <= b0; j++) {
                        for (int k = -b0; k <= b0; k++) {
                            BlockPos blockPosValue = blockpos.add(i, j, k);
                            if (client.world.getBlockState(blockPosValue).isOf(Blocks.SPAWNER)) {
                                this.spawners.add(blockPosValue.toImmutable());
                            }
                        }
                    }
                }
            }
        }
    }

    private void setSneaking(boolean sneakingValue) {
        if (client.options != null) {
            client.options.sneakKey.setPressed(sneakingValue);
            this.sneaking = sneakingValue;
        }
    }

    private void openChest() {
        if (this.targetChest != null && client.player != null) {
            this.rotateToward(this.targetChest);
            if (this.isAimingAt(this.targetChest)) {
                if (this.chestOpenTicks % 5 == 0 && client.interactionManager != null) {
                    BlockHitResult blockhitresult =
                            new BlockHitResult(
                                    Vec3d.ofCenter(this.targetChest),
                                    Direction.UP,
                                    this.targetChest,
                                    false);
                    client.interactionManager.interactBlock(
                            client.player, Hand.MAIN_HAND, blockhitresult);
                    this.sendMessage(
                            String.format(
                                    "§8[§6SP§8] §eAttempting to open ender chest (attempt %d)",
                                    this.chestOpenTicks / 5 + 1));
                }

                this.chestOpenTicks++;
            }

            if (client.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
                this.state = SpawnerProtectModule.State.DEPOSITING_ITEMS;
                this.lastDepositSlot = -1;
                this.depositDelayTicks = 0;
                this.sendMessage("§8[§6SP§8] §aEnder chest opened successfully!");
            }

            if (this.chestOpenTicks > 200) {
                this.sendMessage(
                        "§8[§6SP§8] §cFailed to open ender chest after multiple attempts!");
                this.state = SpawnerProtectModule.State.DISCONNECTING;
            }
        } else {
            this.state = SpawnerProtectModule.State.GOING_TO_CHEST;
        }
    }

    @EventHandler
    public void onBlockUpdate(BlockUpdateEvent blockUpdateEvent) {
        if (client.player != null
                && client.world != null
                && this.state == SpawnerProtectModule.State.IDLE) {
            BlockState blockstate = blockUpdateEvent.getState();
            BlockState oldState = blockUpdateEvent.getOldState();
            BlockPos blockpos = blockUpdateEvent.getPos();
            if (blockstate.isAir()
                    && oldState != null
                    && (oldState.isOf(Blocks.STONE) || oldState.isOf(Blocks.DEEPSLATE))) {
                this.triggerReason = "BLOCK_BREAK";
                this.triggeredAtMillis = System.currentTimeMillis();
                this.brokenBlocks.add(blockpos.toImmutable());
                String stringValue = oldState.getBlock().getName().getString();
                this.sendMessage(
                        String.format(
                                "§8[§6SP§8] §cBroken block detected: %s at [%d, %d, %d]",
                                stringValue, blockpos.getX(), blockpos.getY(), blockpos.getZ()));
                this.state = SpawnerProtectModule.State.GOING_TO_SPAWNERS;
                this.setSneaking(true);
                this.sendMessage(
                        "§8[§6SP§8] §eStarting protection sequence due to broken block...");
            }
        }
    }

    private void depositSpawners() {
        if (client.player != null) {
            if (client.player.currentScreenHandler
                    instanceof GenericContainerScreenHandler genericcontainerscreenhandler) {
                if (!this.hasSpawners()) {

                    this.sendMessage(
                            String.format(
                                    "§8[§6SP§8] §aAll items deposited successfully! Transferred %d"
                                        + " spawners to ender chest.",
                                    this.depositedCount));
                    client.player.closeHandledScreen();
                    this.state = SpawnerProtectModule.State.DISCONNECTING;
                } else {
                    if (this.depositDelayTicks > 0) {
                        this.depositDelayTicks--;
                        return;
                    }

                    this.depositNextStack(genericcontainerscreenhandler);
                    this.depositDelayTicks = (int) this.depositDelaySetting.getFloat().floatValue();
                }
            } else {
                this.state = SpawnerProtectModule.State.OPENING_CHEST;
                this.chestOpenTicks = 0;
            }
        }
    }

    private void releaseInputs() {
        if (client.options != null) {
            client.options.forwardKey.setPressed(false);
            client.options.jumpKey.setPressed(false);
            client.options.sneakKey.setPressed(false);
            client.options.attackKey.setPressed(false);
        }
    }

    private void sendMessage(String text) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal(text), false);
        }
    }

    private String escapeJson(String text) {
        return text == null
                ? ""
                : text.replace("\\", "\\\\")
                        .replace("\"", "\\\"")
                        .replace("\n", "\\n")
                        .replace("\r", "\\r")
                        .replace("\t", "\\t");
    }

    private void disconnectAfterProtection() {
        this.releaseInputs();
        int i;
        if (this.depositedCount > 0) {
            i = this.depositedCount;
        } else {
            i = this.minedSpawnerCount;
        }

        String text = i + " Spawners Protected!";
        this.sendMessage("§8[§6SP§8] §c" + text);
        this.sendWebhook("@everyone " + text, text);
        if (client.getNetworkHandler() != null) {
            client.getNetworkHandler().getConnection().disconnect(Text.literal(text));
        }

        this.resetState();
        this.toggle();
    }

    private void stopWalking() {
        if (client.options != null) {
            client.options.forwardKey.setPressed(false);
            client.options.jumpKey.setPressed(false);
        }
    }

    @Environment(EnvType.CLIENT)
    private static enum State {
        IDLE,
        GOING_TO_SPAWNERS,
        MINING_SPAWNER,
        GOING_TO_CHEST,
        OPENING_CHEST,
        DEPOSITING_ITEMS,
        DISCONNECTING,
        POSITION_DISPLACED,
        AWAITING_RECALIBRATION;
    }
}
