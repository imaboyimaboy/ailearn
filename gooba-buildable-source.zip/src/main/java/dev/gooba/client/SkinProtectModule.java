package dev.gooba.client;

import com.mojang.authlib.GameProfile;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@ModuleInfo(
        name = "Skin Protect",
        category = ModuleCategory.PLAYER,
        desc = "Replaces player skins with an official Minecraft skin")
@Environment(EnvType.CLIENT)
public class SkinProtectModule extends Module {
    private volatile String requestedUsername;
    public final ModeSetting targetSetting =
            new ModeSetting(this, "Target", new String[] {"Urself", "Everyone"});
    public final TextSetting officialSkinNameSetting =
            new TextSetting(this, "Official Skin Name", "Steve").onChange(this::loadSkin);
    private volatile SkinTextures replacementSkin;

    public void loadSkin() {
        String stringValue =
                this.officialSkinNameSetting.getText() == null
                        ? ""
                        : this.officialSkinNameSetting.getText().trim();
        this.replacementSkin = null;
        this.requestedUsername = stringValue;
        if (!stringValue.isEmpty()) {
            CompletableFuture.<Optional<GameProfile>>supplyAsync(
                            () ->
                                    client.getApiServices()
                                            .profileResolver()
                                            .getProfileByName(stringValue))
                    .thenCompose(optional -> this.fetchSkin((Optional<GameProfile>) optional))
                    .thenAccept(
                            optional -> {
                                if (stringValue.equalsIgnoreCase(this.requestedUsername)) {
                                    this.replacementSkin = optional.orElse(null);
                                }
                            });
        }
    }

    public SkinTextures getSkinTextures(AbstractClientPlayerEntity abstractclientplayerentity) {
        if (this.isEnabled() && this.replacementSkin != null && client.player != null) {
            return !this.targetSetting.isSelected("Everyone")
                            && !abstractclientplayerentity.getUuid().equals(client.player.getUuid())
                    ? null
                    : this.replacementSkin;
        } else {
            return null;
        }
    }

    @Override
    protected void onEnable() {
        this.loadSkin();
        super.onEnable();
    }

    private CompletableFuture<Optional<SkinTextures>> fetchSkin(Optional<GameProfile> optional) {
        return optional.<CompletableFuture<Optional<SkinTextures>>>map(
                        gameprofile -> client.getSkinProvider().fetchSkinTextures(gameprofile))
                .orElseGet(() -> CompletableFuture.completedFuture(Optional.empty()));
    }

    public SkinProtectModule() {
        this.requestedUsername = "";
    }

    @Override
    protected void onDisable() {
        this.requestedUsername = "";
        this.replacementSkin = null;
        super.onDisable();
    }
}
