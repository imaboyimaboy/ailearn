package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Better Trident",
        category = ModuleCategory.DONUT,
        desc = "Riptide out of water and instant trident charge")
@Environment(EnvType.CLIENT)
public class BetterTridentModule extends Module {}
