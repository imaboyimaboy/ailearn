package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

@Environment(EnvType.CLIENT)
public class ImmutableListView<T> implements List<T> {
    private final T[] array;

    @Override
    public void clear() {
        throw new UnsupportedOperationException();
    }

    @Override
    public ListIterator<T> listIterator() {
        return new ImmutableListView.ArrayBackedIterator<>(this.array);
    }

    @Override
    public T remove(int i) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Object[] toArray() {
        return Arrays.copyOf(this.array, this.array.length);
    }

    @Override
    public T set(int i, T object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean addAll(Collection<? extends T> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean isEmpty() {
        return this.array.length == 0;
    }

    public ImmutableListView(Collection<T> collection) {
        this((T[]) collection.toArray());
    }

    @Override
    public int lastIndexOf(Object object) {
        for (int i = this.array.length - 1; i >= 0; i--) {
            if (object == this.array[i]) {
                return i;
            }
        }

        return -1;
    }

    @Override
    public boolean containsAll(Collection<?> collection) {
        for (Object object : collection) {
            if (!this.contains(object)) {
                return false;
            }
        }

        return true;
    }

    @Override
    public void add(int i, T object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Iterator<T> iterator() {
        return new ImmutableListView.ArrayBackedIterator<>(this.array);
    }

    @Override
    public ListIterator<T> listIterator(int i) {
        return new ImmutableListView.ArrayBackedIterator<>(this.array);
    }

    public static <T> ImmutableListView<T> copy(T[] aobject) {
        return new ImmutableListView<>((T[]) Arrays.copyOf(aobject, aobject.length));
    }

    public ImmutableListView(T[] aobject) {
        this.array = (T[]) aobject;
    }

    @Override
    public <T1> T1[] toArray(T1[] aobject) {
        return (T1[]) this.toArray();
    }

    @Override
    public boolean removeAll(Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int size() {
        return this.array.length;
    }

    @Override
    public List<T> subList(int i, int j) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean contains(Object object) {
        for (Object objectValue : this.array) {
            if (object == objectValue) {
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean addAll(int i, Collection<? extends T> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean retainAll(Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean remove(Object object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean add(T object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int indexOf(Object object) {
        for (int i = 0; i < this.array.length; i++) {
            if (object == this.array[i]) {
                return i;
            }
        }

        return -1;
    }

    @Override
    public T get(int i) {
        return this.array[i];
    }

    @Environment(EnvType.CLIENT)
    private static final class ArrayBackedIterator<T> implements ListIterator<T> {
        private int cursor;
        private final T[] array;

        @Override
        public void add(T object) {
            throw new UnsupportedOperationException();
        }

        private ArrayBackedIterator(Object[] aobject) {
            this.array = (T[]) aobject;
            this.cursor = 0;
        }

        private ArrayBackedIterator(T[] values, int initialIndex) {
            this.array = values;
            this.cursor = initialIndex;
        }

        @Override
        public boolean hasNext() {
            return this.cursor < this.array.length;
        }

        @Override
        public T previous() {
            if (!this.hasPrevious()) {
                throw new NoSuchElementException();
            } else {
                return this.array[--this.cursor];
            }
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean hasPrevious() {
            return this.cursor > 0;
        }

        @Override
        public void set(T object) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int nextIndex() {
            return this.cursor;
        }

        @Override
        public T next() {
            if (!this.hasNext()) {
                throw new NoSuchElementException();
            } else {
                return this.array[this.cursor++];
            }
        }

        @Override
        public int previousIndex() {
            return this.cursor - 1;
        }
    }
}
