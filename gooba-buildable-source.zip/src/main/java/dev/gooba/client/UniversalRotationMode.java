package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class UniversalRotationMode implements RotationModeHandler {

    private float pitchSpeed;
    private float yawSpeed = 24.0F;

    public UniversalRotationMode() {
        this.pitchSpeed = 6.0F;
    }

    @Override
    public void updateRotation(
            AttackAuraModule attackAuraModule,
            LivingEntity livingentity,
            float[] afloat,
            boolean flag) {
        if (client.player != null && livingentity != null) {
            Vec3d vec3d = TargetPositionUtils.relativeEyeOffset(livingentity);
            float f = MathUtils.secureRandomFloat(35.0F, 40.0F);
            float f1 = MathUtils.secureRandomFloat(4.0F, 8.0F);
            float f2 = (float) Math.toDegrees(Math.atan2(-vec3d.x, vec3d.z));
            float f3 =
                    (float)
                            MathHelper.clamp(
                                    -Math.toDegrees(
                                            Math.atan2(vec3d.y, Math.hypot(vec3d.x, vec3d.z))),
                                    -90.0,
                                    90.0);
            float f4 = 0.3F;
            if (EntityRaycast.intersectsTarget(
                    client.player.getYaw(), client.player.getPitch(), 5.0, livingentity)) {
                f = 0.0F;
                f1 = 0.0F;
            }

            this.yawSpeed = this.yawSpeed + (f - this.yawSpeed) * f4;
            this.pitchSpeed = this.pitchSpeed + (f1 - this.pitchSpeed) * f4;
            TargetRingRenderer.aim(
                    new Rotation(f2, f3),
                    this.yawSpeed,
                    this.pitchSpeed,
                    MathUtils.randomInterpolated(360.0, 390.0),
                    MathUtils.randomInterpolated(360.0, 390.0),
                    (int) MathUtils.randomInterpolated(3.0, 5.0),
                    1,
                    false);
        }
    }
}
