package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class PlayerRotationEvent extends CancellableEvent {
    private float bodyaw;
    private float yaw;
    private float pitch;

    public void setBodyaw(float bodyawValue) {
        this.bodyaw = bodyawValue;
    }

    public void setPitch(float pitchValue) {
        this.pitch = pitchValue;
    }

    public PlayerRotationEvent(float yawValue, float pitchValue, float bodyawValue) {
        this.yaw = yawValue;
        this.pitch = pitchValue;
        this.bodyaw = bodyawValue;
    }

    public float getPitch() {
        return this.pitch;
    }

    public float getBodyaw() {
        return this.bodyaw;
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setYaw(float yawValue) {
        this.yaw = yawValue;
    }
}
