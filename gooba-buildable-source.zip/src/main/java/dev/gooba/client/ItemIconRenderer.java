package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;

import org.joml.Matrix3x2fStack;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Environment(EnvType.CLIENT)
public class ItemIconRenderer {
    private static final Random random = Random.create();
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Map<String, ItemIconRenderer.CachedSprite> spriteCache =
            new ConcurrentHashMap<>();

    public static void drawCentered(
            DrawContext drawcontext, ItemStack itemstack, float f, float f1, float f2, float f3) {
        if (!itemstack.isEmpty() && !(f3 <= 0.01F)) {
            float f4 = 16.0F * f2;
            Sprite sprite = resolveSprite(itemstack);
            if (sprite != null) {
                HudManager.drawSprite(
                        sprite, f - f4 * 0.5F, f1 - f4 * 0.5F, f4, f4, multiplyAlpha(-1, f3), true);
            } else {
                drawCenteredItem(drawcontext, itemstack, f, f1, f2, f3);
            }
        }
    }

    private static float guiScaleCorrection() {
        return 2.0F / (float) guiScale();
    }

    private static int guiScale() {
        int value = mc.options.getGuiScale().getValue();
        if (value == 0) {
            value = mc.getWindow().calculateScaleFactor(0, mc.forcesUnicodeFont());
        }

        return value;
    }

    public static Sprite resolveSprite(ItemStack itemstack) {
        String string = spriteKey(itemstack);
        ItemIconRenderer.CachedSprite cachedSprite = spriteCache.get(string);
        if (cachedSprite != null) {
            return cachedSprite.sprite;
        } else {
            try {
                ItemRenderState itemrenderstate = new ItemRenderState();
                mc.getItemModelManager()
                        .clearAndUpdate(
                                itemrenderstate,
                                itemstack,
                                ItemDisplayContext.GUI,
                                mc.world,
                                null,
                                0);
                Sprite sprite = itemrenderstate.getParticleSprite(random);
                if (sprite != null) {
                    spriteCache.put(string, new ItemIconRenderer.CachedSprite(sprite));
                    return sprite;
                }
            } catch (Exception exception) {
            }

            return null;
        }
    }

    public static void drawItem(
            DrawContext drawcontext, ItemStack itemstack, float f, float f1, float f2, float f3) {
        if (!itemstack.isEmpty() && !(f3 <= 0.01F)) {
            float f4 = guiScaleCorrection();
            float f5 = f2 * f4;
            float f6 = 16.0F * f2;
            float f7 = f + f6 / 2.0F;
            float f8 = f1 + f6 / 2.0F;
            Matrix3x2fStack matrix3x2fstack = drawcontext.getMatrices();
            matrix3x2fstack.pushMatrix();
            matrix3x2fstack.translate(f7, f8);
            matrix3x2fstack.scale(f5, f5);
            matrix3x2fstack.translate(-8.0F, -8.0F);
            drawcontext.drawItem(itemstack, 0, 0);
            matrix3x2fstack.popMatrix();
        }
    }

    private static String spriteKey(ItemStack itemstack) {
        int i = itemstack.getComponents().hashCode();
        String text = itemstack.getItem().toString();
        return text + "_" + i;
    }

    public static void drawCenteredItem(
            DrawContext drawcontext, ItemStack itemstack, float f, float f1, float f2, float f3) {
        float f4 = 16.0F * f2;
        float f5 = f - f4 / 2.0F;
        float f6 = f1 - f4 / 2.0F;
        drawItem(drawcontext, itemstack, f5, f6, f2, f3);
    }

    private static int multiplyAlpha(int i, float f) {
        int j = (int) ((float) (i >> 24 & 0xFF) * f);
        return j << 24 | i & 16777215;
    }

    @Environment(EnvType.CLIENT)
    private static record CachedSprite(Sprite sprite) {}
}
