package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Font {
    private final String fontName;

    public float measureWidth(String string, float size) {
        return Gooba.getInstance()
                .getHudManager()
                .getFontRenderer()
                .measureWidth(this.fontName, string, size);
    }

    public void drawCenteredText(String string, float f, float f1, float size, int color) {
        Gooba.getInstance()
                .getHudManager()
                .getFontRenderer()
                .drawCenteredText(this.fontName, string, f, f1, size, color);
    }

    public void drawFadedText(
            String string, float f, float f1, float size, int color, float maxWidth) {
        Gooba.getInstance()
                .getHudManager()
                .getFontRenderer()
                .drawFadedText(this.fontName, string, f, f1, maxWidth, size, color);
    }

    public float measureVisibleWidth(String string, float size) {

        FontAtlas fontAtlas2 =
                Gooba.getInstance().getHudManager().getFontRenderer().getFontAtlas(this.fontName);
        if (fontAtlas2 != null && string != null && !string.isEmpty()) {
            fontAtlas2.ensureLoaded();
            float MAX_VALUE = Float.MAX_VALUE;
            float f2 = -Float.MAX_VALUE;
            float f3 = 0.0F;
            int i = 0;

            while (i < string.length()) {
                int codePoint = string.codePointAt(i);
                GlyphMetrics glyphMetrics = fontAtlas2.getGlyphMetrics(codePoint);
                if (glyphMetrics != null) {
                    if (glyphMetrics.width > 0.0F && glyphMetrics.height > 0.0F) {
                        float f4 =
                                Math.min(fontAtlas2.getDistanceRange(), glyphMetrics.width / 2.0F);
                        MAX_VALUE = Math.min(MAX_VALUE, f3 + glyphMetrics.offsetX + f4);
                        f2 = Math.max(f2, f3 + glyphMetrics.offsetX + glyphMetrics.width - f4);
                    }

                    f3 += glyphMetrics.advance;
                }

                i += Character.charCount(codePoint);
            }

            return MAX_VALUE == Float.MAX_VALUE
                    ? this.measureWidth(string, size)
                    : (f2 - MAX_VALUE) * size / fontAtlas2.getFontSize();
        } else {
            return string == null ? 0.0F : this.measureWidth(string, size);
        }
    }

    public float getLineHeight(float size) {
        return Gooba.getInstance()
                .getHudManager()
                .getFontRenderer()
                .getLineHeight(this.fontName, size);
    }

    public Font(String fontNameValue) {
        this.fontName = fontNameValue;
    }

    public float centerFirstGlyphY(String text, float centerY, float size) {

        FontAtlas fontAtlas2 =
                Gooba.getInstance().getHudManager().getFontRenderer().getFontAtlas(this.fontName);
        if (fontAtlas2 != null && text != null && !text.isEmpty()) {
            fontAtlas2.ensureLoaded();
            GlyphMetrics glyphMetrics = fontAtlas2.getGlyphMetrics(text.codePointAt(0));
            if (glyphMetrics == null) {
                return centerY - size * 0.5F;
            } else {
                float f2 = size / fontAtlas2.getFontSize();
                return centerY - (glyphMetrics.offsetY + glyphMetrics.height * 0.5F) * f2;
            }
        } else {
            return centerY - size * 0.5F;
        }
    }

    public float centerFirstGlyphX(String text, float f, float width, float size) {

        FontAtlas fontAtlas2 =
                Gooba.getInstance().getHudManager().getFontRenderer().getFontAtlas(this.fontName);
        if (fontAtlas2 != null && text != null && !text.isEmpty()) {
            fontAtlas2.ensureLoaded();
            GlyphMetrics glyphMetrics = fontAtlas2.getGlyphMetrics(text.codePointAt(0));
            if (glyphMetrics == null) {
                return f + width * 0.5F;
            } else {
                float f3 = size / fontAtlas2.getFontSize();
                return f + (width - glyphMetrics.width * f3) * 0.5F - glyphMetrics.offsetX * f3;
            }
        } else {
            return f + width * 0.5F;
        }
    }

    public float centerTextY(String text, float f, float height, float size) {

        FontAtlas fontAtlas2 =
                Gooba.getInstance().getHudManager().getFontRenderer().getFontAtlas(this.fontName);
        if (fontAtlas2 != null && text != null && !text.isEmpty()) {
            fontAtlas2.ensureLoaded();
            float MAX_VALUE = Float.MAX_VALUE;
            float f4 = -Float.MAX_VALUE;
            int i = 0;

            while (i < text.length()) {
                int codePoint = text.codePointAt(i);
                GlyphMetrics glyphMetrics = fontAtlas2.getGlyphMetrics(codePoint);
                if (glyphMetrics != null
                        && glyphMetrics.width > 0.0F
                        && glyphMetrics.height > 0.0F) {
                    MAX_VALUE = Math.min(MAX_VALUE, glyphMetrics.offsetY);
                    f4 = Math.max(f4, glyphMetrics.offsetY + glyphMetrics.height);
                }

                i += Character.charCount(codePoint);
            }

            if (MAX_VALUE == Float.MAX_VALUE) {
                return f + (height - this.getLineHeight(size)) / 2.0F;
            } else {
                float f5 = size / fontAtlas2.getFontSize();
                return f + (height - (f4 - MAX_VALUE) * f5) / 2.0F - MAX_VALUE * f5;
            }
        } else {
            return f + (height - this.getLineHeight(size)) / 2.0F;
        }
    }

    public float centerTextX(String string, float f, float width, float size) {

        FontAtlas fontAtlas2 =
                Gooba.getInstance().getHudManager().getFontRenderer().getFontAtlas(this.fontName);
        if (fontAtlas2 != null && string != null && !string.isEmpty()) {
            fontAtlas2.ensureLoaded();
            float MAX_VALUE = Float.MAX_VALUE;
            float f4 = -Float.MAX_VALUE;
            float f5 = 0.0F;
            int i = 0;

            while (i < string.length()) {
                int codePoint = string.codePointAt(i);
                GlyphMetrics glyphMetrics = fontAtlas2.getGlyphMetrics(codePoint);
                if (glyphMetrics != null) {
                    if (glyphMetrics.width > 0.0F && glyphMetrics.height > 0.0F) {
                        float f6 =
                                Math.min(fontAtlas2.getDistanceRange(), glyphMetrics.width / 2.0F);
                        MAX_VALUE = Math.min(MAX_VALUE, f5 + glyphMetrics.offsetX + f6);
                        f4 = Math.max(f4, f5 + glyphMetrics.offsetX + glyphMetrics.width - f6);
                    }

                    f5 += glyphMetrics.advance;
                }

                i += Character.charCount(codePoint);
            }

            if (MAX_VALUE == Float.MAX_VALUE) {
                return f + (width - this.measureWidth(string, size)) / 2.0F;
            } else {
                float f8 = size / fontAtlas2.getFontSize();
                return f + (width - (f4 - MAX_VALUE) * f8) / 2.0F - MAX_VALUE * f8;
            }
        } else {
            float f3 = string == null ? 0.0F : this.measureWidth(string, size);
            return f + (width - f3) / 2.0F;
        }
    }

    public void drawText(String string, float f, float f1, float size) {
        Gooba.getInstance()
                .getHudManager()
                .getFontRenderer()
                .drawText(this.fontName, string, f, f1, size, -657931);
    }
}
