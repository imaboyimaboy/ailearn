package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class Render2DEvent extends Event {
    private DrawContext drawContext;
    private float partialTicks;

    public Render2DEvent(DrawContext drawcontext, float partialTicksValue) {
        this.drawContext = drawcontext;
        this.partialTicks = partialTicksValue;
    }

    public float getPartialTicks() {
        return this.partialTicks;
    }

    public DrawContext getDrawContext() {
        return this.drawContext;
    }
}
