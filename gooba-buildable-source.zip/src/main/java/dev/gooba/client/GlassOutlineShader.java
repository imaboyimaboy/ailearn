package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public class GlassOutlineShader {
    private GpuBuffer blurUniformBuffer;
    private final int[] mipWidths;
    private GpuBuffer outlineUniformBuffer;
    private ByteBuffer blurData;
    private static final Identifier DOWNSAMPLE_PIPELINE_ID =
            Identifier.of("client", "pipeline/glass_outline_down");
    private int height;
    private boolean initialized;
    private ByteBuffer outlineData;
    private static final Identifier UPSAMPLE_FRAGMENT_SHADER =
            Identifier.of("client", "core/glass_outline_up");
    private final int[] mipHeights;
    private static final Identifier COMBINE_FRAGMENT_SHADER =
            Identifier.of("client", "core/glass_outline_combine");

    private static final Identifier DOWNSAMPLE_VERTEX_SHADER =
            Identifier.of("client", "core/glass_outline");
    private static final Identifier COMBINE_VERTEX_SHADER =
            Identifier.of("client", "core/glass_outline");
    private static final Vector3f MODEL_OFFSET = new Vector3f(0.0F, 0.0F, 0.0F);
    private float shimmerPeriodSeconds;
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
    private final GpuTextureView[] mipViews;
    private static final Identifier DOWNSAMPLE_FRAGMENT_SHADER =
            Identifier.of("client", "core/glass_outline_down");
    private float shimmerWidth;
    private static final RenderPipeline DOWNSAMPLE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(DOWNSAMPLE_PIPELINE_ID)
                            .withVertexShader(DOWNSAMPLE_VERTEX_SHADER)
                            .withFragmentShader(GlassOutlineShader.DOWNSAMPLE_FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("KawaseOutlineData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private static final Identifier COMBINE_PIPELINE_ID =
            Identifier.of("client", "pipeline/glass_outline_combine");
    private int width;
    private static final RenderPipeline COMBINE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(COMBINE_PIPELINE_ID)
                            .withVertexShader(COMBINE_VERTEX_SHADER)
                            .withFragmentShader(COMBINE_FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("OutlineData", UniformType.UNIFORM_BUFFER)
                            .withSampler("maskTexture")
                            .withSampler("glowTexture")
                            .withSampler("sceneTexture")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private static final Identifier UPSAMPLE_PIPELINE_ID =
            Identifier.of("client", "pipeline/glass_outline_up");
    private final GpuTexture[] mipTextures = new GpuTexture[3];

    private GpuBuffer vertexBuffer;
    private int friendCount;
    private static final Identifier UPSAMPLE_VERTEX_SHADER =
            Identifier.of("client", "core/glass_outline");
    private static final RenderPipeline UPSAMPLE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(UPSAMPLE_PIPELINE_ID)
                            .withVertexShader(GlassOutlineShader.UPSAMPLE_VERTEX_SHADER)
                            .withFragmentShader(UPSAMPLE_FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("KawaseOutlineData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private final float[] friendRects;
    private boolean shimmerEnabled;
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

    public void close() {
        this.closeTextures();
        if (this.blurUniformBuffer != null) {
            this.blurUniformBuffer.close();
            this.blurUniformBuffer = null;
        }

        if (this.outlineUniformBuffer != null) {
            this.outlineUniformBuffer.close();
            this.outlineUniformBuffer = null;
        }

        if (this.vertexBuffer != null) {
            this.vertexBuffer.close();
            this.vertexBuffer = null;
        }

        if (this.blurData != null) {
            MemoryUtil.memFree(this.blurData);
            this.blurData = null;
        }

        if (this.outlineData != null) {
            MemoryUtil.memFree(this.outlineData);
            this.outlineData = null;
        }

        this.initialized = false;
        this.width = 0;
        this.height = 0;
    }

    private void initialize() {
        if (!this.initialized) {
            this.blurData = MemoryUtil.memAlloc(16);
            this.outlineData = MemoryUtil.memAlloc(208);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.vertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "minecraft:glass_outline_dummy_vertex", 32, bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.blurUniformBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:glass_outline_kawase_ubo", 136, 16L);
            this.outlineUniformBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:glass_outline_combine_ubo", 136, 208L);
            this.initialized = true;
        }
    }

    private void uploadOutlineUniforms(
            CommandEncoder commandencoder,
            int i,
            int j,
            int k,
            int l,
            int i1,
            int j1,
            float f,
            boolean flag,
            float f1) {
        this.outlineData.clear();
        this.putColor(k);
        this.putColor(l);
        this.outlineData.putFloat(1.0F / (float) i);
        this.outlineData.putFloat(1.0F / (float) j);
        this.outlineData.putFloat((float) i1);
        this.outlineData.putFloat((float) this.friendCount);
        this.outlineData.putFloat((float) j1);
        this.outlineData.putFloat(0.0F);
        this.outlineData.putFloat(f);
        this.outlineData.putFloat(this.shimmerEnabled ? 1.0F : 0.0F);
        this.outlineData.putFloat(this.shimmerWidth);
        this.outlineData.putFloat(flag ? 1.0F : 0.0F);
        this.outlineData.putFloat(f1);
        this.outlineData.putFloat(0.0F);

        for (int k1 = 0; k1 < 8; k1++) {
            int l1 = k1 * 4;
            if (k1 < this.friendCount) {
                this.outlineData.putFloat(this.friendRects[l1]);
                this.outlineData.putFloat(this.friendRects[l1 + 1]);
                this.outlineData.putFloat(this.friendRects[l1 + 2]);
                this.outlineData.putFloat(this.friendRects[l1 + 3]);
            } else {
                this.outlineData.putFloat(0.0F);
                this.outlineData.putFloat(0.0F);
                this.outlineData.putFloat(0.0F);
                this.outlineData.putFloat(0.0F);
            }
        }

        this.outlineData.flip();
        commandencoder.writeToBuffer(this.outlineUniformBuffer.slice(), this.outlineData);
    }

    public void render(
            GpuTextureView gputextureview,
            GpuTextureView gpuTextureView,
            int widthValue,
            int heightValue,
            float f,
            int k,
            int l,
            int i1,
            int j1,
            GpuTextureView gpuTextureViewValue,
            boolean flag) {
        this.initialize();
        this.resize(widthValue, heightValue);
        CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
        GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
        GpuTextureView gputextureviewValue = gputextureview;
        int widthValueValue = widthValue;
        int heightValueValue = heightValue;

        for (int i21 = 0; i21 < 3; i21++) {
            this.uploadBlurUniforms(
                    commandencoder,
                    0.5F / (float) widthValueValue,
                    0.5F / (float) heightValueValue,
                    1.0F);
            GpuBufferSlice gpubufferslice =
                    RenderSystem.getDynamicUniforms()
                            .write(
                                    RenderSystem.getModelViewMatrix(),
                                    COLOR_MODULATOR,
                                    MODEL_OFFSET,
                                    TEXTURE_MATRIX);
            GpuTextureView gputextureviewValueValue = gputextureviewValue;

            int i22 = i21;

            try (RenderPass renderpass =
                    commandencoder.createRenderPass(
                            () -> "minecraft:glass_outline_down_" + i22,
                            this.mipViews[i21],
                            OptionalInt.of(0))) {
                renderpass.setPipeline(DOWNSAMPLE_PIPELINE);
                renderpass.setVertexBuffer(0, this.vertexBuffer);
                renderpass.bindTexture("Sampler0", gputextureviewValueValue, gpusampler);
                RenderSystem.bindDefaultUniforms(renderpass);
                renderpass.setUniform("DynamicTransforms", gpubufferslice);
                renderpass.setUniform("KawaseOutlineData", this.blurUniformBuffer);
                renderpass.draw(0, 6);
            }

            gputextureviewValue = this.mipViews[i21];
            widthValueValue = this.mipWidths[i21];
            heightValueValue = this.mipHeights[i21];
        }

        int j2 = 2;

        RenderPass renderPass;
        while (true) {
            Throwable throwableValue;
            label66:
            if (j2 > 0) {
                float f1 = Math.max(0.5F, f / 4.0F);
                float f2 = Math.min(f1, 4.0F);
                this.uploadBlurUniforms(
                        commandencoder,
                        0.5F / (float) this.mipWidths[j2],
                        0.5F / (float) this.mipHeights[j2],
                        f2);
                GpuBufferSlice gpuBufferSlice =
                        RenderSystem.getDynamicUniforms()
                                .write(
                                        RenderSystem.getModelViewMatrix(),
                                        COLOR_MODULATOR,
                                        MODEL_OFFSET,
                                        TEXTURE_MATRIX);
                int l2 = j2;
                renderPass =
                        commandencoder.createRenderPass(
                                () -> {
                                    int j3 = l2 - 1;
                                    return "minecraft:glass_outline_up_" + j3;
                                },
                                this.mipViews[l2 - 1],
                                OptionalInt.of(0));

                try {
                    renderPass.setPipeline(UPSAMPLE_PIPELINE);
                    renderPass.setVertexBuffer(0, this.vertexBuffer);
                    renderPass.bindTexture("Sampler0", this.mipViews[l2], gpusampler);
                    RenderSystem.bindDefaultUniforms(renderPass);
                    renderPass.setUniform("DynamicTransforms", gpuBufferSlice);
                    renderPass.setUniform("KawaseOutlineData", this.blurUniformBuffer);
                    renderPass.draw(0, 6);
                } catch (Throwable throwableValueValue) {
                    throwableValue = throwableValueValue;
                    boolean flag2x = false;
                    break label66;
                }

                if (renderPass != null) {
                    renderPass.close();
                }

                j2--;
                continue;
            } else {
                long k2 = (long) (this.shimmerPeriodSeconds * 1000.0F);
                float f3 = (float) (System.currentTimeMillis() % k2) / (float) k2;
                float f4 = Math.max(8.0F, f + (float) k + 6.0F);
                this.uploadOutlineUniforms(
                        commandencoder, widthValue, heightValue, i1, j1, k, l, f3, flag, f4);
                GpuBufferSlice gpuBufferSliceValue =
                        RenderSystem.getDynamicUniforms()
                                .write(
                                        RenderSystem.getModelViewMatrix(),
                                        COLOR_MODULATOR,
                                        MODEL_OFFSET,
                                        TEXTURE_MATRIX);
                renderPass =
                        commandencoder.createRenderPass(
                                () -> "minecraft:glass_outline_combine",
                                gpuTextureView,
                                OptionalInt.empty());

                try {
                    renderPass.setPipeline(COMBINE_PIPELINE);
                    renderPass.setVertexBuffer(0, this.vertexBuffer);
                    renderPass.bindTexture("maskTexture", gputextureview, gpusampler);
                    renderPass.bindTexture("glowTexture", this.mipViews[0], gpusampler);
                    renderPass.bindTexture("sceneTexture", gpuTextureViewValue, gpusampler);
                    RenderSystem.bindDefaultUniforms(renderPass);
                    renderPass.setUniform("DynamicTransforms", gpuBufferSliceValue);
                    renderPass.setUniform("OutlineData", this.outlineUniformBuffer);
                    renderPass.draw(0, 6);
                    break;
                } catch (Throwable throwableValue2) {
                    throwableValue = throwableValue2;
                    boolean flag1 = false;
                }
            }

            Throwable throwable = throwableValue;
            if (renderPass != null) {
                try {
                    renderPass.close();
                } catch (Throwable throwable2) {
                    throwable.addSuppressed(throwable2);
                }
            }

            throw dev.gooba.client.Sneaky.rethrow(throwable);
        }

        if (renderPass != null) {
            renderPass.close();
        }
    }

    private void uploadBlurUniforms(CommandEncoder commandencoder, float f, float f1, float f2) {
        this.blurData.clear();
        this.blurData.putFloat(f);
        this.blurData.putFloat(f1);
        this.blurData.putFloat(f2);
        this.blurData.putFloat(0.0F);
        this.blurData.flip();
        commandencoder.writeToBuffer(this.blurUniformBuffer.slice(), this.blurData);
    }

    public GlassOutlineShader() {
        this.mipViews = new GpuTextureView[3];
        this.mipWidths = new int[3];
        this.mipHeights = new int[3];
        this.initialized = false;
        this.width = 0;
        this.height = 0;
        this.shimmerEnabled = false;
        this.shimmerWidth = 0.04F;
        this.shimmerPeriodSeconds = 5.0F;
        this.friendRects = new float[32];
        this.friendCount = 0;
    }

    public void setShimmerEnabled(boolean shimmerEnabledValue) {
        this.shimmerEnabled = shimmerEnabledValue;
    }

    private void resize(int widthValue, int heightValue) {
        if (widthValue != this.width || heightValue != this.height || this.mipTextures[0] == null) {
            this.closeTextures();
            int mipWidth = widthValue;
            int mipHeight = heightValue;

            for (int i11 = 0; i11 < 3; i11++) {
                mipWidth = Math.max(1, mipWidth / 2);
                mipHeight = Math.max(1, mipHeight / 2);
                this.mipWidths[i11] = mipWidth;
                this.mipHeights[i11] = mipHeight;
                int j1 = i11;
                this.mipTextures[i11] =
                        RenderSystem.getDevice()
                                .createTexture(
                                        () -> "minecraft:glass_outline_mip_" + j1,
                                        12,
                                        TextureFormat.RGBA8,
                                        mipWidth,
                                        mipHeight,
                                        1,
                                        1);
                this.mipViews[i11] =
                        RenderSystem.getDevice().createTextureView(this.mipTextures[i11]);
            }

            this.width = widthValue;
            this.height = heightValue;
        }
    }

    private void putColor(int i) {
        this.outlineData.putFloat((float) (i >> 16 & 0xFF) / 255.0F);
        this.outlineData.putFloat((float) (i >> 8 & 0xFF) / 255.0F);
        this.outlineData.putFloat((float) (i & 0xFF) / 255.0F);
        this.outlineData.putFloat((float) (i >> 24 & 0xFF) / 255.0F);
    }

    private void closeTextures() {
        for (int i = 0; i < 3; i++) {
            if (this.mipViews[i] != null) {
                this.mipViews[i].close();
                this.mipViews[i] = null;
            }

            if (this.mipTextures[i] != null) {
                this.mipTextures[i].close();
                this.mipTextures[i] = null;
            }
        }
    }
}
