package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class Setting<Value> implements ConditionalSetting, MinecraftAccess {
    private Runnable visibilityChanged;
    private Supplier<Boolean> visibility = () -> true;
    private Value value;

    public final String name;
    private Runnable valueChanged;
    private Module module;
    private final TimedAnimation appearanceAnimation;
    private final EasingAnimation visibilityAnimation = new EasingAnimation();

    public Setting setValue(Object object) {
        this.value = (Value) object;
        if (client.world != null && client.player != null && this.valueChanged != null) {
            this.valueChanged.run();
        }

        return this;
    }

    public Setting(String nameValue, Value object) {
        this.appearanceAnimation = new DecelerateAnimation(300, 1.0);
        this.name = nameValue;
        this.value = (Value) object;
    }

    @Override
    public Setting visibleWhen(Supplier supplier) {
        this.visibility = supplier;
        if (client.world != null && client.player != null && this.visibilityChanged != null) {
            this.visibilityChanged.run();
        }

        return this;
    }

    public Supplier<Boolean> getVisibility() {
        return this.visibility;
    }

    public Setting(Module moduleValue, String nameValue, Value object) {
        this.appearanceAnimation = new DecelerateAnimation(300, 1.0);
        this.module = moduleValue;
        this.name = nameValue;
        this.value = (Value) object;
        moduleValue.getSettings().add(this);
    }

    public Setting onChange(Runnable runnable) {
        this.valueChanged = runnable;
        return this;
    }

    public Object getValue() {
        return this.value;
    }

    public String getName() {
        return this.name;
    }

    public Module getModule() {
        return this.module;
    }

    public EasingAnimation getAnimation() {
        return this.visibilityAnimation;
    }

    public Setting<Value> onVisibilityChanged(Runnable callback) {
        this.visibilityChanged = callback;
        return this;
    }
}
