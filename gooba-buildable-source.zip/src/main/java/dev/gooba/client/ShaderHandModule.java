package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "ShaderHand",
        category = ModuleCategory.RENDER,
        desc = "Applies configurable edge glow to held items")
@Environment(EnvType.CLIENT)
public class ShaderHandModule extends Module {
    public ModeSetting glowColorSetting;
    public BooleanSetting edgeGlowSetting = new BooleanSetting(this, "Edge glow", true);
    public ColorSetting customGlowColorSetting;
    private static ShaderHandModule instance;
    public SliderSetting glowStrengthSetting =
            new SliderSetting(this, "Glow Strength", 0.2F, 0.0F, 1.0F, 0.01F)
                    .visibleWhen(() -> this.edgeGlowSetting.isOn());

    @EventHandler
    public void onHandRenderPhase(HandRenderPhaseEvent handRenderPhaseEvent) {
        if (this.isEnabled()) {
            HandEffectFramebuffer handEffectFramebuffer2 = HandEffectFramebuffer.getInstance();
            this.applyEffectSettings();
            if (handRenderPhaseEvent.getPhase() == HandRenderPhaseEvent.Phase.PRE) {
                handEffectFramebuffer2.captureBeforeHands();
            } else if (handRenderPhaseEvent.getPhase() == HandRenderPhaseEvent.Phase.POST) {
                handEffectFramebuffer2.captureAfterHands();
                handEffectFramebuffer2.compositeEffects();
            }
        }
    }

    public void applyEffectSettings() {
        HandEffectFramebuffer handEffectFramebuffer2 = HandEffectFramebuffer.getInstance();
        handEffectFramebuffer2.setGlassEnabled(false);
        handEffectFramebuffer2.setReflectionEnabled(false);
        handEffectFramebuffer2.setIceIntensity(0.0F);
        handEffectFramebuffer2.setFrostScale(0.0F);
        handEffectFramebuffer2.setCrackIntensity(0.0F);
        handEffectFramebuffer2.setSmokeAmount(0.0F);
        handEffectFramebuffer2.setBurnEnabled(false);
        handEffectFramebuffer2.setTintColor(0);
        handEffectFramebuffer2.setTintIntensity(0.0F);
        handEffectFramebuffer2.setShimmerEnabled(false);
        handEffectFramebuffer2.setOutlineEnabled(this.edgeGlowSetting.isOn());
        if (this.edgeGlowSetting.isOn()) {
            float glowStrengthValue = this.glowStrengthSetting.getFloat() * 20.0F;
            handEffectFramebuffer2.setGlowStrength(glowStrengthValue);
            if (this.glowColorSetting.isSelected("Theme")) {
                handEffectFramebuffer2.setUseItemColor(false);
                handEffectFramebuffer2.setGlowColors(
                        0xFF000000 | ColorUtils.hudAccent() & 16777215);
            } else {
                handEffectFramebuffer2.setUseItemColor(false);
                handEffectFramebuffer2.setGlowColors(
                        0xFF000000 | this.customGlowColorSetting.getColor() & 16777215);
            }
        }
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        if (this.isEnabled()) {
            HandEffectFramebuffer handEffectFramebuffer2 = HandEffectFramebuffer.getInstance();
            handEffectFramebuffer2.close();
            handEffectFramebuffer2.setEnabled(true);
            this.applyEffectSettings();
        }
    }

    @Override
    protected void onEnable() {
        HandEffectFramebuffer handEffectFramebuffer2 = HandEffectFramebuffer.getInstance();
        handEffectFramebuffer2.close();
        handEffectFramebuffer2.setEnabled(true);
        this.applyEffectSettings();
    }

    @Override
    protected void onDisable() {
        HandEffectFramebuffer.getInstance().setEnabled(false);
    }

    public ShaderHandModule() {
        this.glowColorSetting =
                new ModeSetting(this, "Glow Color", new String[] {"Theme", "Custom"})
                        .visibleWhen(() -> this.edgeGlowSetting.isOn());
        this.customGlowColorSetting =
                new ColorSetting(this, "Custom Glow Color", -16711681)
                        .visibleWhen(
                                () ->
                                        (this.edgeGlowSetting.isOn()
                                                && this.glowColorSetting.isSelected("Custom")));
        instance = this;
    }

    public static ShaderHandModule getInstance() {
        return instance;
    }
}
