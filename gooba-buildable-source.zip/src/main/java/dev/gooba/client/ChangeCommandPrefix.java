package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.List;

@Environment(EnvType.CLIENT)
public class ChangeCommandPrefix extends Command {
    @Override
    public List suggest(String text) {
        return List.of();
    }

    @Override
    public void execute(String[] astring) {
        if (astring.length != 0 && !astring[0].isEmpty()) {
            char prefixValue = astring[0].charAt(0);
            Gooba.getInstance().getCommandManager().setPrefix(prefixValue);
            ChatMessages.send("§7Prefix changed to: §a" + prefixValue);
        } else {
            char prefix = Gooba.getInstance().getCommandManager().getPrefix();
            ChatMessages.send("§7Current prefix: §a" + prefix);
            ChatMessages.send("§7Usage: " + prefix + "prefix <character>");
        }
    }

    public ChangeCommandPrefix() {
        super("prefix", ".prefix <character>", "Change command prefix");
    }
}
