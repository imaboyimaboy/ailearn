package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.InputUtil;

import org.joml.Matrix3x2f;
import org.joml.Vector2f;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Environment(EnvType.CLIENT)
public class HudDragManager extends ClientComponent implements MinecraftAccess {
    private final List<Float> verticalGuides;
    private final EasingAnimation verticalGuidePosition;
    private final EasingAnimation gridOpacity;
    private final EasingAnimation verticalGuideOpacity;
    private final List<Module> draggableModules;
    private final EasingAnimation horizontalGuidePosition;
    private final List<Float> horizontalGuides;
    public static List<HudDragManager.Line> snapLines = new CopyOnWriteArrayList<>();
    private final Vector2f dragOffset = new Vector2f();
    private final Script releaseSequence;

    private PositionSetting draggedPosition;
    private final EasingAnimation horizontalGuideOpacity;

    public static boolean contains(
            double d0, double d1, double d2, double d3, double d4, double d5) {
        return d0 >= d2 && d0 <= d2 + d4 && d1 >= d3 && d1 <= d3 + d5;
    }

    private void drawSnapGuides(int i, int j, float f) {
        if (!(f <= 0.01F)) {
            float f1 = this.verticalGuideOpacity.getFloatValue() * f;
            float f2 = this.horizontalGuideOpacity.getFloatValue() * f;
            if (f1 > 0.01F) {
                int color = ColorUtils.cachedRgba(255, 120, 200, (int) (200.0F * f1));
                RenderUtils.Render2D.drawRect(
                        this.verticalGuidePosition.getFloatValue() - 0.3F,
                        0.0F,
                        0.6F,
                        (float) j,
                        color);
            }

            if (f2 > 0.01F) {
                int colorValue = ColorUtils.cachedRgba(255, 120, 200, (int) (200.0F * f2));
                RenderUtils.Render2D.drawRect(
                        0.0F,
                        this.horizontalGuidePosition.getFloatValue() - 0.3F,
                        (float) i,
                        0.6F,
                        colorValue);
            }
        }
    }

    public Vector2f screenToHud(double d0, double d1) {
        return new Vector2f(
                (float) (d0 * (double) client.getWindow().getScaleFactor() / 2.0),
                (float) (d1 * (double) client.getWindow().getScaleFactor() / 2.0));
    }

    private void clampPositions(int i, int j) {
        for (Module module : this.draggableModules) {
            for (Setting setting : module.getSettings()) {
                if (setting instanceof PositionSetting) {
                    PositionSetting positionSetting2 = (PositionSetting) setting;
                    if (positionSetting2.visible) {
                        positionSetting2.position.x =
                                (float) positionSetting2.xAnimation.getValue();
                        positionSetting2.position.y =
                                (float) positionSetting2.yAnimation.getValue();
                        positionSetting2.position.x =
                                Math.max(
                                        0.0F,
                                        Math.min(
                                                (float) i - positionSetting2.size.x,
                                                positionSetting2.position.x));
                        positionSetting2.position.y =
                                Math.max(
                                        0.0F,
                                        Math.min(
                                                (float) j - positionSetting2.size.y,
                                                positionSetting2.position.y));
                        positionSetting2.targetPosition.x =
                                Math.max(
                                        0.0F,
                                        Math.min(
                                                (float) i - positionSetting2.size.x,
                                                positionSetting2.targetPosition.x));
                        positionSetting2.targetPosition.y =
                                Math.max(
                                        0.0F,
                                        Math.min(
                                                (float) j - positionSetting2.size.y,
                                                positionSetting2.targetPosition.y));
                    }
                }
            }
        }
    }

    private void updateAnimations() {
        this.draggableModules.forEach(
                module ->
                        module.getSettings()
                                .forEach(
                                        setting -> {
                                            if (setting
                                                    instanceof PositionSetting positionSetting2) {
                                                positionSetting2.xAnimation.update();
                                                positionSetting2.yAnimation.update();
                                                if (this.releaseSequence.isFinished()) {
                                                    positionSetting2.xAnimation.animateTo(
                                                            (double)
                                                                    positionSetting2
                                                                            .targetPosition
                                                                            .x,
                                                            0.06,
                                                            true);
                                                    positionSetting2.yAnimation.animateTo(
                                                            (double)
                                                                    positionSetting2
                                                                            .targetPosition
                                                                            .y,
                                                            0.06,
                                                            true);
                                                }
                                            }
                                        }));
    }

    private void drawGrid(int i, int j, float f) {
        int k = ColorUtils.cachedRgba(255, 255, 255, (int) (16.0F * f));
        int l = ColorUtils.cachedRgba(255, 255, 255, (int) (34.0F * f));
        int i11 = 0;

        for (float innerX = 0.0F; innerX <= (float) i; i11++) {
            RenderUtils.Render2D.drawRect(innerX, 0.0F, 0.5F, (float) j, i11 % 5 == 0 ? l : k);
            innerX += 8.0F;
        }

        i11 = 0;

        for (float innerY = 0.0F; innerY <= (float) j; i11++) {
            RenderUtils.Render2D.drawRect(0.0F, innerY, (float) i, 0.5F, i11 % 5 == 0 ? l : k);
            innerY += 8.0F;
        }

        int color = ColorUtils.cachedRgba(255, 120, 170, (int) (70.0F * f));
        RenderUtils.Render2D.drawRect((float) i / 2.0F, 0.0F, 0.6F, (float) j, color);
        RenderUtils.Render2D.drawRect(0.0F, (float) j / 2.0F, (float) i, 0.6F, color);
    }

    private void refreshDraggableModules() {
        this.draggableModules.clear();
        Gooba.getInstance().getModuleRegistry().values().stream()
                .filter(
                        module ->
                                module.isEnabled()
                                        && module.getSettings().stream()
                                                .anyMatch(
                                                        setting ->
                                                                setting instanceof PositionSetting))
                .forEach(this.draggableModules::add);
    }

    public void render(Matrix3x2f matrix3x2f) {
        this.releaseSequence.tick();
        client.getWindow();
        float f = 2.0F;
        float scaleFactor = (float) client.getWindow().getScaleFactor();
        float f2 = f / scaleFactor;
        int i = (int) ((float) client.getWindow().getScaledWidth() / f2);
        int j = (int) ((float) client.getWindow().getScaledHeight() / f2);
        boolean flag = client.currentScreen instanceof ChatScreen;
        if (!flag) {
            this.draggedPosition = null;
        }

        this.refreshDraggableModules();
        this.updateAnimations();
        boolean flag1;
        flag1 = (flag && this.draggedPosition != null && this.draggedPosition.visible);

        this.gridOpacity.update();
        this.gridOpacity.animateTo(flag1 ? 1.0 : 0.0, 0.25, Easings.OUT_SINE, true);
        if (this.gridOpacity.getFloatValue() > 0.01F) {
            this.drawGrid(i, j, this.gridOpacity.getFloatValue());
        }

        this.verticalGuides.clear();
        this.horizontalGuides.clear();
        boolean flag2;
        flag2 =
                !(!InputUtil.isKeyPressed(client.getWindow(), 342)
                        && !InputUtil.isKeyPressed(client.getWindow(), 346));

        if (this.draggedPosition != null && this.draggedPosition.visible) {
            float f3 = (float) (client.mouse.getX() / 2.0);
            float f4 = (float) (client.mouse.getY() / 2.0);
            float f5 = f3 + this.dragOffset.x;
            float f6 = f4 + this.dragOffset.y;
            if (!this.draggedPosition.lockHorizontal) {
                this.draggedPosition.targetPosition.x = f5;
            }

            this.draggedPosition.targetPosition.y = f6;
            snapLines.clear();
            if (!flag2) {
                this.snapToElements();
            }

            this.clampPositions(i, j);
        }

        this.animateSnapGuides();
        this.drawSnapGuides(i, j, this.gridOpacity.getFloatValue());
    }

    @EventHandler
    public void onMouseButton(MouseButtonEvent mouseButtonEvent) {
        if (mouseButtonEvent.getMouseButton() == 0) {
            if (mouseButtonEvent.getScreen() instanceof ChatScreen) {
                for (Module module : this.draggableModules) {
                    for (Setting setting : module.getSettings()) {
                        if (setting instanceof PositionSetting) {
                            PositionSetting positionSetting2 = (PositionSetting) setting;
                            if (positionSetting2.visible) {
                                Vector2f vector2fx = positionSetting2.position;
                                Vector2f vector2f1 = positionSetting2.size;
                                Vector2f vector2f2 =
                                        this.screenToHud(
                                                (double) ((float) mouseButtonEvent.getMouseX()),
                                                (double) ((float) mouseButtonEvent.getMouseY()));
                                double d0 = (double) vector2f2.x;
                                double d1 = (double) vector2f2.y;
                                if (!positionSetting2.visible) {
                                    return;
                                }

                                if (!positionSetting2.locked
                                        && contains(
                                                d0,
                                                d1,
                                                (double) vector2fx.x,
                                                (double) vector2fx.y,
                                                (double) vector2f1.x,
                                                (double) vector2f1.y)) {
                                    this.draggedPosition = positionSetting2;
                                    this.dragOffset.set(
                                            (double) vector2fx.x - d0, (double) vector2fx.y - d1);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void animateSnapGuides() {
        boolean flag;
        flag = (!this.verticalGuides.isEmpty());

        boolean flag1;
        flag1 = (!this.horizontalGuides.isEmpty());

        this.verticalGuideOpacity.update();
        this.horizontalGuideOpacity.update();
        this.verticalGuidePosition.update();
        this.horizontalGuidePosition.update();
        if (flag) {
            float f = this.verticalGuides.get(0);
            if (this.verticalGuideOpacity.getFloatValue() <= 0.01F) {
                this.verticalGuidePosition.snapTo((double) f);
            } else {
                this.verticalGuidePosition.animateTo((double) f, 0.15, Easings.OUT_BACK_ALT, true);
            }
        }

        if (flag1) {
            float f1 = this.horizontalGuides.get(0);
            if (this.horizontalGuideOpacity.getFloatValue() <= 0.01F) {
                this.horizontalGuidePosition.snapTo((double) f1);
            } else {
                this.horizontalGuidePosition.animateTo(
                        (double) f1, 0.15, Easings.OUT_BACK_ALT, true);
            }
        }

        this.verticalGuideOpacity.animateTo(flag ? 1.0 : 0.0, 0.2, Easings.OUT_SINE, true);
        this.horizontalGuideOpacity.animateTo(flag1 ? 1.0 : 0.0, 0.2, Easings.OUT_SINE, true);
    }

    private void snapToElements() {
        float f = this.draggedPosition.targetPosition.x;
        float f1 = this.draggedPosition.targetPosition.y;
        float f2 = this.draggedPosition.size.x;
        float f3 = this.draggedPosition.size.y;
        float[] afloat = new float[] {f, f + f2 / 2.0F, f + f2};
        float[] values = new float[] {f1, f1 + f3 / 2.0F, f1 + f3};
        Float value = null;
        float f5 = 5.0F;
        float f6 = 0.0F;
        Float valueValue = null;
        float f8 = 5.0F;
        float f9 = 0.0F;

        for (Module module : this.draggableModules) {
            for (Setting setting : module.getSettings()) {
                if (setting instanceof PositionSetting positionSetting2
                        && positionSetting2 != this.draggedPosition
                        && positionSetting2.visible) {
                    float[] valuesValue =
                            new float[] {
                                positionSetting2.position.x,
                                positionSetting2.position.x + positionSetting2.size.x / 2.0F,
                                positionSetting2.position.x + positionSetting2.size.x
                            };
                    float[] values2 =
                            new float[] {
                                positionSetting2.position.y,
                                positionSetting2.position.y + positionSetting2.size.y / 2.0F,
                                positionSetting2.position.y + positionSetting2.size.y
                            };

                    for (float f10 : valuesValue) {
                        for (float f11 : afloat) {
                            float f12 = Math.abs(f11 - f10);
                            if (f12 < f5) {
                                f5 = f12;
                                value = f + (f10 - f11);
                                f6 = f10;
                            }
                        }
                    }

                    for (float f13 : values2) {
                        for (float f14 : values) {
                            float f15 = Math.abs(f14 - f13);
                            if (f15 < f8) {
                                f8 = f15;
                                valueValue = f1 + (f13 - f14);
                                f9 = f13;
                            }
                        }
                    }
                }
            }
        }

        if (!this.draggedPosition.lockHorizontal) {
            if (value != null) {
                this.draggedPosition.targetPosition.x = value;
                this.verticalGuides.add(f6);
            } else {
                this.draggedPosition.targetPosition.x = (float) Math.round(f / 8.0F) * 8.0F;
            }
        }

        if (valueValue != null) {
            this.draggedPosition.targetPosition.y = valueValue;
            this.horizontalGuides.add(f9);
        } else {
            this.draggedPosition.targetPosition.y = (float) Math.round(f1 / 8.0F) * 8.0F;
        }
    }

    @EventHandler
    public void onMouseRelease(MouseReleaseEvent mouseReleaseEvent) {
        if (this.draggedPosition != null) {
            this.releaseSequence
                    .clear()
                    .addTickStep(
                            0,
                            () -> {
                                this.draggedPosition.targetPosition.set(
                                        this.draggedPosition.position);
                                Gooba.getInstance().getConfigManager().saveState();
                                this.draggedPosition = null;
                            },
                            () ->
                                    this.draggedPosition != null
                                            && this.draggedPosition.xAnimation.isFinished()
                                            && this.draggedPosition.yAnimation.isFinished());
        }
    }

    public HudDragManager() {
        this.draggableModules = new CopyOnWriteArrayList<>();
        this.releaseSequence = new Script();
        this.verticalGuides = new CopyOnWriteArrayList<>();
        this.horizontalGuides = new CopyOnWriteArrayList<>();
        this.gridOpacity = new EasingAnimation();
        this.verticalGuideOpacity = new EasingAnimation();
        this.horizontalGuideOpacity = new EasingAnimation();
        this.verticalGuidePosition = new EasingAnimation();
        this.horizontalGuidePosition = new EasingAnimation();
    }

    @Environment(EnvType.CLIENT)
    public static enum Direction {
        VERTICAL,
        HORIZONTAL;

        private static HudDragManager.Direction[] getDirectionArray() {
            return new HudDragManager.Direction[] {VERTICAL, HORIZONTAL};
        }
    }

    @Environment(EnvType.CLIENT)
    public static class Line {
        public float fVal;
        public HudDragManager.Direction direction;
        public float fVal2;
        public boolean flag;
        public boolean flag2;
        public boolean flag3;

        public Line(
                float f,
                float f1,
                HudDragManager.Direction directionValue,
                boolean flag,
                boolean flag1,
                boolean flag2) {
            this.fVal2 = f;
            this.fVal = f1;
            this.direction = directionValue;
            this.flag = flag;
            this.flag2 = flag1;
            this.flag3 = flag2;
        }
    }
}
