package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.BlockView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@ModuleInfo(
        name = "X-Ray",
        category = ModuleCategory.OTHER,
        desc = "Only renders specified blocks. Good for mining.")
@Environment(EnvType.CLIENT)
public class XRayModule extends Module {
    private double previousTransparency;
    private volatile Set<Block> visibleBlocks;
    public final SliderSetting transparencySetting =
            new SliderSetting(this, "Transparency", 128.0F, 0.0F, 255.0F, 1.0F);
    public static final List<Block> DEFAULT_BLOCKS =
            List.of(
                    Blocks.COAL_ORE,
                    Blocks.DEEPSLATE_COAL_ORE,
                    Blocks.IRON_ORE,
                    Blocks.DEEPSLATE_IRON_ORE,
                    Blocks.GOLD_ORE,
                    Blocks.DEEPSLATE_GOLD_ORE,
                    Blocks.LAPIS_ORE,
                    Blocks.DEEPSLATE_LAPIS_ORE,
                    Blocks.REDSTONE_ORE,
                    Blocks.DEEPSLATE_REDSTONE_ORE,
                    Blocks.DIAMOND_ORE,
                    Blocks.DEEPSLATE_DIAMOND_ORE,
                    Blocks.EMERALD_ORE,
                    Blocks.DEEPSLATE_EMERALD_ORE,
                    Blocks.COPPER_ORE,
                    Blocks.DEEPSLATE_COPPER_ORE,
                    Blocks.NETHER_GOLD_ORE,
                    Blocks.NETHER_QUARTZ_ORE,
                    Blocks.ANCIENT_DEBRIS,
                    Blocks.RAW_IRON_BLOCK,
                    Blocks.RAW_COPPER_BLOCK,
                    Blocks.RAW_GOLD_BLOCK,
                    Blocks.AMETHYST_CLUSTER,
                    Blocks.BUDDING_AMETHYST,
                    Blocks.SPAWNER,
                    Blocks.CHEST,
                    Blocks.TRAPPED_CHEST,
                    Blocks.ENDER_CHEST);
    private static XRayModule instance;
    private static final ThreadLocal<Mutable> mutablePosition =
            ThreadLocal.withInitial(Mutable::new);
    private int previousWhitelistHash;
    public final BlockListSetting whitelistSetting =
            new BlockListSetting(this, "Whitelist", defaultWhitelist());

    private static List<BlockListSetting.Entry> defaultWhitelist() {
        ArrayList arraylist = new ArrayList();

        for (Block block : DEFAULT_BLOCKS) {
            Identifier identifier = Registries.BLOCK.getId(block);
            arraylist.add(new BlockListSetting.Entry(identifier.toString(), -1));
        }

        return arraylist;
    }

    public boolean shouldHide(Block block, BlockView blockview, BlockPos blockpos) {
        return !this.isWhitelisted(block);
    }

    public void rebuildWhitelist() {
        HashSet hashset = new HashSet();
        List listx = this.whitelistSetting.getEntries();
        if (listx != null && !listx.isEmpty()) {
            for (BlockListSetting.Entry entry :
                    (Iterable<BlockListSetting.Entry>) (Iterable) listx) {
                Block block = entry.getBlock();
                if (block != null) {
                    hashset.add(block);
                }
            }
        }

        if (hashset.isEmpty()) {
            hashset.addAll(DEFAULT_BLOCKS);
        }

        this.visibleBlocks = hashset;
    }

    private int whitelistHash() {
        int i = 1;

        for (BlockListSetting.Entry entry : this.whitelistSetting.getEntries()) {
            int j = 31 * i;
            if (entry.getBlockId() == null) {
                i = j + 0;
            } else {
                i = j + entry.getBlockId().hashCode();
            }
        }

        return i;
    }

    public boolean shouldHide(Block block, BlockPos blockpos) {
        return this.shouldHide(block, null, blockpos);
    }

    public XRayModule() {
        this.previousTransparency = 128.0;
        this.previousWhitelistHash = 0;
        this.visibleBlocks = new HashSet<>();
        instance = this;
        this.rebuildWhitelist();
    }

    @Override
    protected void onDisable() {
        this.reloadChunks();
    }

    @Override
    protected void onEnable() {
        this.previousTransparency = (double) this.transparencySetting.getFloat().floatValue();
        this.previousWhitelistHash = this.whitelistHash();
        this.rebuildWhitelist();
        this.reloadChunks();
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        int previousWhitelistHashValue = this.whitelistHash();
        if ((double) this.transparencySetting.getFloat().floatValue() != this.previousTransparency
                || previousWhitelistHashValue != this.previousWhitelistHash) {
            this.previousTransparency = (double) this.transparencySetting.getFloat().floatValue();
            this.previousWhitelistHash = previousWhitelistHashValue;
            this.rebuildWhitelist();
            this.reloadChunks();
        }
    }

    public static XRayModule getInstance() {
        return instance;
    }

    public void reloadChunks() {
        if (client.worldRenderer != null) {
            client.worldRenderer.reload();
        }
    }

    public static int blockOpacity(BlockState blockstate, BlockPos blockpos) {
        XRayModule xRayModule2 = instance;
        return xRayModule2 != null
                        && xRayModule2.isEnabled()
                        && xRayModule2.shouldHide(blockstate.getBlock(), blockpos)
                ? Math.round(xRayModule2.transparencySetting.getFloat())
                : -1;
    }

    public boolean isWhitelisted(Block block) {
        if (block == null) {
            return false;
        } else {
            if (this.visibleBlocks.isEmpty()) {
                this.rebuildWhitelist();
            }

            return this.visibleBlocks.contains(block);
        }
    }
}
