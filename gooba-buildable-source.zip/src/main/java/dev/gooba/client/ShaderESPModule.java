package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

@ModuleInfo(
        name = "Shader ESP",
        category = ModuleCategory.RENDER,
        desc =
                "Highlights entities, crystals, and dropped items with glow, outlines, and optional"
                    + " fill")
@Environment(EnvType.CLIENT)
public class ShaderESPModule extends Module {
    public final ColorSetting colorSetting =
            new ColorSetting(this, "Color", ColorUtils.hudAccent());
    private static ShaderESPModule instance;
    private static final Set<Entity> entities =
            Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap<>()));
    public final SliderSetting outlineWidthSetting;
    public final SliderSetting glowStrengthSetting =
            new SliderSetting(this, "Glow Strength", 1.6F, 0.0F, 4.0F, 0.05F);
    public final BooleanSetting fillSetting;
    public Framebuffer maskFramebuffer;

    public void renderEffects() {
        if (client.world != null && client.player != null) {
            if (!entities.isEmpty()) {
                Framebuffer framebufferx = client.getFramebuffer();
                if (framebufferx != null) {
                    Framebuffer framebufferValue = this.maskFramebuffer;
                    if (framebufferValue != null
                            && framebufferValue.getColorAttachmentView() != null) {
                        ShaderEspRenderer shaderEspRenderer2 = ShaderEspRenderer.getInstance();
                        this.configureEffect(shaderEspRenderer2.params);
                        shaderEspRenderer2.render(
                                framebufferValue,
                                framebufferx.textureWidth,
                                framebufferx.textureHeight);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        entities.clear();
        if (this.isEnabled()) {
            ShaderEspRenderer.getInstance().reset();
        }
    }

    public ShaderESPModule() {
        this.outlineWidthSetting = new SliderSetting(this, "Outline Width", 2.0F, 0.0F, 5.0F, 1.0F);
        this.fillSetting = new BooleanSetting(this, "Fill", false);
        instance = this;
    }

    private boolean isEligible(Entity entity) {
        return entity instanceof PlayerEntity playerentity
                ? playerentity.getCustomName() == null
                        || !playerentity.getCustomName().getString().startsWith("Ghost_")
                : entity instanceof LivingEntity
                        || entity instanceof ItemEntity
                        || entity instanceof EndCrystalEntity;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        entities.clear();
        if (client.world != null && client.player != null) {
            for (Entity entity : client.world.getEntities()) {
                if (!FakeLagModule.isGhost(entity) && this.isEligible(entity)) {
                    entities.add(entity);
                }
            }
        }
    }

    public static boolean isTracked(Entity entity) {
        return entities.contains(entity);
    }

    public int effectColor() {
        return this.colorSetting.getColor();
    }

    private void configureEffect(ShaderEspPipeline.Params params) {
        params.mainColor = this.effectColor();
        params.highlightFriends = true;
        params.friendColor = -11141291;
        params.opacity = (float) (this.effectColor() >>> 24) / 255.0F;
        params.saturation = 1.15F;
        params.glowEnabled = true;
        params.blurRadius = 0.55F;
        params.glowStrength = this.glowStrengthSetting.getFloat();
        params.glowFalloff = 1.1F;
        params.fillEnabled = this.fillSetting.isOn();
        params.fillOpacity = this.fillSetting.isOn() ? 0.45F : 0.0F;
        params.innerGlow = this.fillSetting.isOn() ? 0.6F : 0.0F;
        if (this.outlineWidthSetting.getFloat() > 0.0F) {
            params.outlineEnabled = true;
        } else {
            params.outlineEnabled = false;
        }

        params.outlineMode = 0;
        params.outlineWidth = this.outlineWidthSetting.getFloat().intValue();
        params.outlineStrength = 1.8F;
        params.outlineWhite = 0.45F;
        params.pulseEnabled = false;
        params.shimmerEnabled = false;
    }

    @Override
    protected void onDisable() {
        entities.clear();
    }

    public static Set<Entity> trackedEntities() {
        return entities;
    }

    public static ShaderESPModule getInstance() {
        return instance;
    }

    @Override
    protected void onEnable() {
        ShaderEspRenderer.getInstance().reset();
    }
}
