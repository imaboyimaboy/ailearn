package dev.gooba.client;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Path;

public final class GoobaPaths {
    public static final Path CONFIG_DIRECTORY =
            FabricLoader.getInstance().getConfigDir().resolve("goobaa");

    private GoobaPaths() {}
}
