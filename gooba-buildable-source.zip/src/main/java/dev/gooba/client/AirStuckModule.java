package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

@ModuleInfo(
        name = "Air Stuck",
        category = ModuleCategory.OTHER,
        desc = "Freezes your player in mid-air")
@Environment(EnvType.CLIENT)
public class AirStuckModule extends Module {
    @EventHandler
    public void onPlayerMotion(PlayerMotionEvent playerMotionEvent) {
        if (!client.player.isOnGround()) {
            playerMotionEvent.ground(false);
        }
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (!client.player.isOnGround()) {
            client.player.setVelocity(0.0, 0.0, 0.0);
        }
    }

    @EventHandler
    public void onPacket(PacketEvent packetEvent) {
        if (!client.player.isOnGround() && packetEvent.getPacket() instanceof PlayerMoveC2SPacket) {
            packetEvent.cancel();
        }
    }
}
