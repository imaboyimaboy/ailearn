package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.WorldChunk;

import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentHashMap.KeySetView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

@ModuleInfo(
        name = "Suspicious ESP",
        category = ModuleCategory.DONUT,
        desc = "Highlights suspicious grown blocks.")
@Environment(EnvType.CLIENT)
public final class SuspiciousESPModule extends Module {
    public final BooleanSetting bambooSetting;
    private final LinkedBlockingQueue<ChunkPos> amethystScanQueue;
    private int cleanupTicks;
    private int rescanTicks;
    public final BooleanSetting beehivesSetting = new BooleanSetting(this, "Beehives", true);
    private final KeySetView<ChunkPos, Boolean> queuedChunks;
    public final SliderSetting tracersAlphaSetting;
    public final BooleanSetting kelpSetting;
    public final BooleanSetting tracersSetting;
    public final SliderSetting alphaSetting;
    private static final int[][] NEIGHBOR_OFFSETS =
            new int[][] {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    public final BooleanSetting vinesSetting;
    private final KeySetView<ChunkPos, Boolean> bambooChunks;
    private final ConcurrentHashMap<ChunkPos, Set<BlockPos>> amethystPositions;
    private ExecutorService scanExecutor;
    private final KeySetView<ChunkPos, Boolean> vineChunks;
    public final BooleanSetting amethystSetting = new BooleanSetting(this, "Amethyst", true);
    private final ConcurrentHashMap<BlockPos, Integer> suspiciousBlocks;
    private final ConcurrentHashMap<ChunkPos, SuspiciousESPModule.KelpResult> kelpChunks;

    @EventHandler
    public void onBlockUpdate(BlockUpdateEvent blockUpdateEvent) {
        BlockPos blockpos = blockUpdateEvent.getPos();
        BlockState blockstate = blockUpdateEvent.getState();
        Integer integer = this.classifyBlock(blockstate);
        if (integer != null) {
            this.suspiciousBlocks.put(blockpos.toImmutable(), integer);
        } else {
            this.suspiciousBlocks.remove(blockpos);
        }

        if (blockstate.isOf(Blocks.AMETHYST_BLOCK)
                || blockstate.isOf(Blocks.BUDDING_AMETHYST)
                || blockstate.isOf(Blocks.AMETHYST_CLUSTER)) {
            ChunkPos chunkpos = new ChunkPos(blockpos);
            this.amethystPositions.remove(chunkpos);
            this.queueAmethystScan(chunkpos.x, chunkpos.z);
        }

        if (this.kelpSetting.isOn()
                && (blockstate.isOf(Blocks.KELP) || blockstate.isOf(Blocks.KELP_PLANT))) {
            ChunkPos chunkPos = new ChunkPos(blockpos);
            this.kelpChunks.remove(chunkPos);
            if (client.world != null && client.world.isChunkLoaded(chunkPos.x, chunkPos.z)) {
                WorldChunk worldchunk = client.world.getChunk(chunkPos.x, chunkPos.z);
                if (this.scanExecutor != null && !this.scanExecutor.isShutdown()) {
                    this.scanExecutor.submit(() -> this.scanKelp(worldchunk));
                }
            }
        }

        if (this.vinesSetting.isOn() && blockstate.isOf(Blocks.VINE)) {
            ChunkPos chunkPosValue = new ChunkPos(blockpos);
            this.vineChunks.remove(chunkPosValue);
            if (client.world != null
                    && client.world.isChunkLoaded(chunkPosValue.x, chunkPosValue.z)) {
                WorldChunk chunk = client.world.getChunk(chunkPosValue.x, chunkPosValue.z);
                if (this.scanExecutor != null && !this.scanExecutor.isShutdown()) {
                    this.scanExecutor.submit(() -> this.scanVines(chunk));
                }
            }
        }

        if (this.bambooSetting.isOn()
                && (blockstate.isOf(Blocks.BAMBOO) || blockstate.isOf(Blocks.BAMBOO_SAPLING))) {
            ChunkPos chunkPos2 = new ChunkPos(blockpos);
            this.bambooChunks.remove(chunkPos2);
            if (client.world != null && client.world.isChunkLoaded(chunkPos2.x, chunkPos2.z)) {
                WorldChunk chunkValue = client.world.getChunk(chunkPos2.x, chunkPos2.z);
                if (this.scanExecutor != null && !this.scanExecutor.isShutdown()) {
                    this.scanExecutor.submit(() -> this.scanBamboo(chunkValue));
                }
            }
        }
    }

    @Override
    protected void onEnable() {
        this.suspiciousBlocks.clear();
        this.amethystPositions.clear();
        this.amethystScanQueue.clear();
        this.queuedChunks.clear();
        this.kelpChunks.clear();
        this.vineChunks.clear();
        this.bambooChunks.clear();
        this.rescanTicks = 0;
        this.cleanupTicks = 0;
        this.scanExecutor =
                Executors.newSingleThreadExecutor(
                        runnable -> {
                            Thread thread =
                                    new Thread(runnable, "Goobaa-SuspiciousESP-BlockScanner");
                            thread.setDaemon(true);
                            return thread;
                        });
        if (client.world != null && client.player != null) {
            int value = client.options.getViewDistance().getValue();
            ChunkPos chunkpos = client.player.getChunkPos();

            for (int j = chunkpos.x - value; j <= chunkpos.x + value; j++) {
                for (int k = chunkpos.z - value; k <= chunkpos.z + value; k++) {
                    if (client.world.isChunkLoaded(j, k)) {
                        WorldChunk worldchunk = client.world.getChunk(j, k);
                        if (worldchunk != null) {
                            this.queueChunkScan(worldchunk);
                        }
                    }

                    this.queueAmethystScan(j, k);
                }
            }
        }
    }

    private void queueChunkScan(WorldChunk worldchunk) {
        if (this.scanExecutor != null && !this.scanExecutor.isShutdown()) {
            this.scanExecutor.submit(() -> this.scanChunk(worldchunk));
        }
    }

    public SuspiciousESPModule() {
        this.bambooSetting = new BooleanSetting(this, "Bamboo", true);
        this.kelpSetting = new BooleanSetting(this, "Kelp", true);
        this.vinesSetting = new BooleanSetting(this, "Vines", true);
        this.tracersSetting = new BooleanSetting(this, "Tracers", true);
        this.tracersAlphaSetting =
                new SliderSetting(this, "Tracers Alpha", 70.0F, 0.0F, 255.0F, 1.0F);
        this.alphaSetting = new SliderSetting(this, "Alpha", 80.0F, 0.0F, 255.0F, 1.0F);
        this.suspiciousBlocks = new ConcurrentHashMap<>();
        this.amethystPositions = new ConcurrentHashMap<>();
        this.kelpChunks = new ConcurrentHashMap<>();
        this.vineChunks = ConcurrentHashMap.newKeySet();
        this.bambooChunks = ConcurrentHashMap.newKeySet();
        this.amethystScanQueue = new LinkedBlockingQueue<>();
        this.queuedChunks = ConcurrentHashMap.newKeySet();
        this.rescanTicks = 0;
        this.cleanupTicks = 0;
    }

    private void scanChunk(WorldChunk worldchunk) {
        if (worldchunk != null && !worldchunk.isEmpty()) {
            int startX = worldchunk.getPos().getStartX();
            int startZ = worldchunk.getPos().getStartZ();
            int bottomY = worldchunk.getBottomY();
            int l = bottomY + worldchunk.getHeight();
            Mutable mutable = new Mutable();

            for (int startXValue = startX; startXValue < startX + 16; startXValue++) {
                for (int startZValue = startZ; startZValue < startZ + 16; startZValue++) {
                    for (int bottomYValue = bottomY; bottomYValue < l; bottomYValue++) {
                        mutable.set(startXValue, bottomYValue, startZValue);
                        BlockState blockstate = worldchunk.getBlockState(mutable);
                        Integer integer = this.classifyBlock(blockstate);
                        if (integer != null) {
                            BlockPos blockpos = mutable.toImmutable();
                            this.suspiciousBlocks.put(blockpos, integer);
                        }
                    }
                }
            }

            this.scanKelp(worldchunk);
            this.scanVines(worldchunk);
            this.scanBamboo(worldchunk);
        }
    }

    private void queueAmethystScan(int i, int j) {
        ChunkPos chunkpos = new ChunkPos(i, j);
        if (this.queuedChunks.add(chunkpos)) {
            this.amethystScanQueue.offer(chunkpos);
        }
    }

    private static boolean isOutsideViewDistance(BlockPos blockpos, ChunkPos chunkpos, int i) {
        return Math.abs((blockpos.getX() >> 4) - chunkpos.x) > i
                || Math.abs((blockpos.getZ() >> 4) - chunkpos.z) > i;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null) {
            if (++this.cleanupTicks >= 20) {
                this.cleanupTicks = 0;
                int value = client.options.getViewDistance().getValue();
                ChunkPos chunkpos = client.player.getChunkPos();
                this.suspiciousBlocks
                        .keySet()
                        .removeIf(blockpos -> isOutsideViewDistance(blockpos, chunkpos, value));
                this.amethystPositions
                        .keySet()
                        .removeIf(
                                chunkpos1x ->
                                        Math.abs(chunkpos1x.x - chunkpos.x) > value
                                                || Math.abs(chunkpos1x.z - chunkpos.z) > value);
                this.kelpChunks
                        .keySet()
                        .removeIf(
                                chunkpos4 ->
                                        Math.abs(chunkpos4.x - chunkpos.x) > value
                                                || Math.abs(chunkpos4.z - chunkpos.z) > value);
                this.vineChunks.removeIf(
                        chunkpos1x ->
                                Math.abs(chunkpos1x.x - chunkpos.x) > value
                                        || Math.abs(chunkpos1x.z - chunkpos.z) > value);
                this.bambooChunks.removeIf(
                        chunkpos4 ->
                                Math.abs(chunkpos4.x - chunkpos.x) > value
                                        || Math.abs(chunkpos4.z - chunkpos.z) > value);
            }

            if (this.amethystSetting.isOn()) {
                int i1 = 0;

                ChunkPos chunkPos3;
                while (i1 < 4 && (chunkPos3 = this.amethystScanQueue.poll()) != null) {
                    this.queuedChunks.remove(chunkPos3);
                    if (this.isWithinViewDistance(chunkPos3.x, chunkPos3.z)
                            && client.world.isChunkLoaded(chunkPos3.x, chunkPos3.z)) {
                        WorldChunk worldchunk = client.world.getChunk(chunkPos3.x, chunkPos3.z);
                        if (worldchunk != null) {
                            this.scanAmethyst(worldchunk);
                        }

                        i1++;
                    }
                }

                if (++this.rescanTicks % 60 == 0) {
                    ChunkPos chunkPos = client.player.getChunkPos();
                    int valueValue = client.options.getViewDistance().getValue();

                    for (int k = chunkPos.x - valueValue; k <= chunkPos.x + valueValue; k++) {
                        for (int l = chunkPos.z - valueValue; l <= chunkPos.z + valueValue; l++) {
                            this.queueAmethystScan(k, l);
                        }
                    }
                }
            }
        }
    }

    private void scanKelp(WorldChunk worldchunk) {
        if (this.kelpSetting.isOn() && worldchunk != null && !worldchunk.isEmpty()) {
            ChunkPos chunkpos = worldchunk.getPos();
            int startX = chunkpos.getStartX();
            int startZ = chunkpos.getStartZ();
            int bottomY = worldchunk.getBottomY();
            int l = bottomY + worldchunk.getHeight();
            int i1 = 0;
            int j1 = 0;
            Mutable mutable = new Mutable();

            for (int startXValue = startX; startXValue < startX + 16; startXValue++) {
                for (int startZValue = startZ; startZValue < startZ + 16; startZValue++) {
                    int i2 = -1;
                    int j2 = -1;

                    for (int bottomYValue = bottomY; bottomYValue < l; bottomYValue++) {
                        mutable.set(startXValue, bottomYValue, startZValue);
                        BlockState blockstate = worldchunk.getBlockState(mutable);
                        if (blockstate.isOf(Blocks.KELP) || blockstate.isOf(Blocks.KELP_PLANT)) {
                            if (i2 < 0) {
                                i2 = bottomYValue;
                            }

                            j2 = bottomYValue;
                        }
                    }

                    if (i2 >= 0 && j2 - i2 + 1 >= 8) {
                        i1++;
                        if (j2 == 62) {
                            j1++;
                        }
                    }
                }
            }

            if (i1 >= 10 && (double) j1 / (double) i1 >= 0.6) {
                this.kelpChunks.put(chunkpos, new SuspiciousESPModule.KelpResult(i1, j1));
            } else {
                this.kelpChunks.remove(chunkpos);
            }
        }
    }

    private boolean isWithinViewDistance(int i, int j) {
        if (client.player == null) {
            return false;
        } else {
            int value = client.options.getViewDistance().getValue();
            ChunkPos chunkpos = client.player.getChunkPos();
            return Math.abs(i - chunkpos.x) <= value && Math.abs(j - chunkpos.z) <= value;
        }
    }

    @Override
    protected void onDisable() {
        if (this.scanExecutor != null) {
            this.scanExecutor.shutdownNow();

            try {
                this.scanExecutor.awaitTermination(1L, TimeUnit.SECONDS);
            } catch (InterruptedException interruptedexception) {
            }

            this.scanExecutor = null;
        }

        this.suspiciousBlocks.clear();
        this.amethystPositions.clear();
        this.amethystScanQueue.clear();
        this.queuedChunks.clear();
        this.kelpChunks.clear();
        this.vineChunks.clear();
        this.bambooChunks.clear();
    }

    private static boolean isInChunk(ChunkPos chunkpos, BlockPos blockpos) {
        return blockpos.getX() >> 4 == chunkpos.x && blockpos.getZ() >> 4 == chunkpos.z;
    }

    private void scanBamboo(WorldChunk worldchunk) {
        if (this.bambooSetting.isOn() && worldchunk != null && !worldchunk.isEmpty()) {
            ChunkPos chunkpos = worldchunk.getPos();
            int startX = chunkpos.getStartX();
            int startZ = chunkpos.getStartZ();
            int bottomY = worldchunk.getBottomY();
            int l = bottomY + worldchunk.getHeight();
            Mutable mutable = new Mutable();
            boolean flag = false;

            label48:
            for (int startXValue = startX; startXValue < startX + 16; startXValue++) {
                for (int startZValue = startZ; startZValue < startZ + 16; startZValue++) {
                    int k1 = 0;

                    for (int bottomYValue = bottomY; bottomYValue < l; bottomYValue++) {
                        mutable.set(startXValue, bottomYValue, startZValue);
                        BlockState blockstate = worldchunk.getBlockState(mutable);
                        if (!blockstate.isOf(Blocks.BAMBOO)
                                && !blockstate.isOf(Blocks.BAMBOO_SAPLING)) {
                            k1 = 0;
                        } else if (++k1 >= 15) {
                            flag = true;
                            break label48;
                        }
                    }
                }
            }

            if (flag) {
                this.bambooChunks.add(chunkpos);
            } else {
                this.bambooChunks.remove(chunkpos);
            }
        }
    }

    private void scanAmethyst(WorldChunk worldchunk) {
        if (client.world != null) {
            ChunkPos chunkpos = worldchunk.getPos();
            BlockPos blockpos = this.findGeodeCenter(worldchunk);
            if (blockpos == null) {
                this.amethystPositions.remove(chunkpos);
            } else {
                HashSet hashset = new HashSet();
                Mutable mutable = new Mutable();
                Mutable mutableValue = new Mutable();
                Mutable mutable3 = new Mutable();

                label98:
                for (int i = -8; i <= 8; i++) {
                    for (int j = -8; j <= 8; j++) {
                        for (int k = -8; k <= 8; k++) {
                            mutable.set(
                                    blockpos.getX() + i, blockpos.getY() + j, blockpos.getZ() + k);
                            BlockState blockstate = client.world.getBlockState(mutable);
                            if ((blockstate.isOf(Blocks.AIR)
                                            || blockstate.isOf(Blocks.AMETHYST_CLUSTER))
                                    && client.world.getLightLevel(LightType.BLOCK, mutable) == 0) {
                                boolean flag = false;
                                int MIN_VALUE = Integer.MIN_VALUE;
                                int i1 = 0;
                                int j1 = 0;

                                for (int[] aint : NEIGHBOR_OFFSETS) {
                                    mutableValue.set(
                                            mutable.getX() + aint[0],
                                            mutable.getY() + aint[1],
                                            mutable.getZ() + aint[2]);
                                    int lightLevel =
                                            client.world.getLightLevel(
                                                    LightType.BLOCK, mutableValue);
                                    if (lightLevel > 4) {
                                        flag = true;
                                        break;
                                    }

                                    if (MIN_VALUE == Integer.MIN_VALUE
                                            && lightLevel == 4
                                            && client.world
                                                    .getBlockState(mutableValue)
                                                    .isOf(Blocks.AIR)) {
                                        MIN_VALUE = mutableValue.getX();
                                        i1 = mutableValue.getY();
                                        j1 = mutableValue.getZ();
                                    }
                                }

                                if (!flag && MIN_VALUE != Integer.MIN_VALUE) {
                                    boolean flag1 = false;

                                    for (int[] values : NEIGHBOR_OFFSETS) {
                                        mutable3.set(
                                                MIN_VALUE + values[0],
                                                i1 + values[1],
                                                j1 + values[2]);
                                        if (client.world.getLightLevel(LightType.BLOCK, mutable3)
                                                > 4) {
                                            flag1 = true;
                                            break;
                                        }
                                    }

                                    if (!flag1) {
                                        hashset.add(mutable.toImmutable());
                                        if (hashset.size() >= 9000) {
                                            break label98;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (!hashset.isEmpty()) {
                    this.amethystPositions.put(chunkpos, hashset);
                } else {
                    this.amethystPositions.remove(chunkpos);
                }
            }
        }
    }

    private BlockPos findGeodeCenter(WorldChunk worldchunk) {
        long i = 0L;
        long j = 0L;
        long k = 0L;
        int l = 0;
        Mutable mutable = new Mutable();
        ChunkPos chunkpos = worldchunk.getPos();

        for (int i1 = -58; i1 <= 30; i1++) {
            for (int j1 = 0; j1 < 16; j1++) {
                for (int k1 = 0; k1 < 16; k1++) {
                    mutable.set(chunkpos.getStartX() + j1, i1, chunkpos.getStartZ() + k1);
                    BlockState blockstate = worldchunk.getBlockState(mutable);
                    if (blockstate.isOf(Blocks.AMETHYST_BLOCK)
                            || blockstate.isOf(Blocks.BUDDING_AMETHYST)) {
                        i += (long) mutable.getX();
                        j += (long) mutable.getY();
                        k += (long) mutable.getZ();
                        l++;
                    }
                }
            }
        }

        return l == 0
                ? null
                : new BlockPos((int) (i / (long) l), (int) (j / (long) l), (int) (k / (long) l));
    }

    private void scanVines(WorldChunk worldchunk) {
        if (this.vinesSetting.isOn() && worldchunk != null && !worldchunk.isEmpty()) {
            ChunkPos chunkpos = worldchunk.getPos();
            int startX = chunkpos.getStartX();
            int startZ = chunkpos.getStartZ();
            int bottomY = worldchunk.getBottomY();
            int l = bottomY + worldchunk.getHeight();
            Mutable mutable = new Mutable();
            boolean flag = false;

            label43:
            for (int startXValue = startX; startXValue < startX + 16; startXValue++) {
                for (int startZValue = startZ; startZValue < startZ + 16; startZValue++) {
                    int k1 = 0;

                    for (int bottomYValue = bottomY; bottomYValue < l; bottomYValue++) {
                        mutable.set(startXValue, bottomYValue, startZValue);
                        if (worldchunk.getBlockState(mutable).isOf(Blocks.VINE)) {
                            if (++k1 >= 30) {
                                flag = true;
                                break label43;
                            }
                        } else {
                            k1 = 0;
                        }
                    }
                }
            }

            if (flag) {
                this.vineChunks.add(chunkpos);
            } else {
                this.vineChunks.remove(chunkpos);
            }
        }
    }

    private static int colorForKind(int i) {
        switch (i) {
            case 0:
                return 16766720;
            case 1:
                return 10181046;
            case 2:
                return 8308816;
            case 3:
                return 3066993;
            case 4:
                return 25600;
            default:
                return 16777215;
        }
    }

    private Integer classifyBlock(BlockState blockstate) {
        return this.beehivesSetting.isOn()
                        && (blockstate.isOf(Blocks.BEEHIVE) || blockstate.isOf(Blocks.BEE_NEST))
                        && blockstate.get(BeehiveBlock.HONEY_LEVEL) >= 5
                ? 0
                : null;
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null) {
            if (!this.suspiciousBlocks.isEmpty()
                    || !this.amethystPositions.isEmpty()
                    || !this.kelpChunks.isEmpty()
                    || !this.vineChunks.isEmpty()
                    || !this.bambooChunks.isEmpty()) {
                int value = client.options.getViewDistance().getValue();
                ChunkPos chunkpos = client.player.getChunkPos();
                int j = Math.round(this.alphaSetting.getFloat());
                Math.max(0, Math.min(255, Math.round(this.tracersAlphaSetting.getFloat())));
                WorldEspRenderer.clear();
                this.suspiciousBlocks.forEach(
                        (blockposx, integer) -> {
                            if (!isOutsideViewDistance(blockposx, chunkpos, value)) {
                                int kx = colorForKind(integer);
                                int lx = j << 24 | kx;
                                Box boxx =
                                        new Box(
                                                (double) blockposx.getX() + 0.05,
                                                (double) blockposx.getY() + 0.05,
                                                (double) blockposx.getZ() + 0.05,
                                                (double) blockposx.getX() + 0.95,
                                                (double) blockposx.getY() + 0.95,
                                                (double) blockposx.getZ() + 0.95);
                                WorldEspRenderer.enqueueBox(boxx, lx, this.tracersSetting.isOn());
                            }
                        });
                if (this.amethystSetting.isOn()) {
                    int k = j << 24 | 10181046;

                    for (Entry entry : this.amethystPositions.entrySet()) {
                        ChunkPos key = (ChunkPos) entry.getKey();
                        if (Math.abs(key.x - chunkpos.x) <= value
                                && Math.abs(key.z - chunkpos.z) <= value) {
                            Set set = (Set) entry.getValue();
                            if (set != null) {
                                for (BlockPos blockpos : (Iterable<BlockPos>) (Iterable) set) {
                                    Box box =
                                            new Box(
                                                    (double) blockpos.getX() + 0.0625,
                                                    (double) blockpos.getY(),
                                                    (double) blockpos.getZ() + 0.0625,
                                                    (double) blockpos.getX() + 0.9375,
                                                    (double) blockpos.getY() + 0.875,
                                                    (double) blockpos.getZ() + 0.9375);
                                    WorldEspRenderer.enqueueBox(box, k, this.tracersSetting.isOn());
                                }
                            }
                        }
                    }
                }

                if (this.kelpSetting.isOn() && !this.kelpChunks.isEmpty()) {
                    int l = j << 24 | 3066993;
                    this.kelpChunks.forEach(
                            (chunkpos1x, kelpresult) -> {
                                if (Math.abs(chunkpos1x.x - chunkpos.x) <= value
                                        && Math.abs(chunkpos1x.z - chunkpos.z) <= value) {
                                    Box boxx =
                                            new Box(
                                                    (double) chunkpos1x.getStartX(),
                                                    63.0,
                                                    (double) chunkpos1x.getStartZ(),
                                                    (double) chunkpos1x.getStartX() + 16.0,
                                                    63.05,
                                                    (double) chunkpos1x.getStartZ() + 16.0);
                                    WorldEspRenderer.enqueueBox(boxx, l, false);
                                }
                            });
                }

                if (this.vinesSetting.isOn() && !this.vineChunks.isEmpty()) {
                    int i1 = j << 24 | 25600;

                    for (ChunkPos chunkPos : this.vineChunks) {
                        if (Math.abs(chunkPos.x - chunkpos.x) <= value
                                && Math.abs(chunkPos.z - chunkpos.z) <= value) {
                            Box boxValue =
                                    new Box(
                                            (double) chunkPos.getStartX(),
                                            63.0,
                                            (double) chunkPos.getStartZ(),
                                            (double) chunkPos.getStartX() + 16.0,
                                            63.05,
                                            (double) chunkPos.getStartZ() + 16.0);
                            WorldEspRenderer.enqueueBox(boxValue, i1, false);
                        }
                    }
                }

                if (this.bambooSetting.isOn() && !this.bambooChunks.isEmpty()) {
                    int j1 = j << 24 | 8308816;

                    for (ChunkPos chunkPosValue : this.bambooChunks) {
                        if (Math.abs(chunkPosValue.x - chunkpos.x) <= value
                                && Math.abs(chunkPosValue.z - chunkpos.z) <= value) {
                            Box box3 =
                                    new Box(
                                            (double) chunkPosValue.getStartX(),
                                            63.0,
                                            (double) chunkPosValue.getStartZ(),
                                            (double) chunkPosValue.getStartX() + 16.0,
                                            63.05,
                                            (double) chunkPosValue.getStartZ() + 16.0);
                            WorldEspRenderer.enqueueBox(box3, j1, false);
                        }
                    }
                }

                WorldEspRenderer.flush(render3DEvent.getMatrixStack());
            }
        }
    }

    @Environment(EnvType.CLIENT)
    private static record KelpResult(int columns, int topsAt62) {}
}
