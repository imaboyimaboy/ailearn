package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.LightData;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

@ModuleInfo(
        name = "Motion Scanner",
        category = ModuleCategory.DONUT,
        desc = "Detects suspicious activity from light updates")
@Environment(EnvType.CLIENT)
public class MotionScannerModule extends Module {
    public final SliderSetting tracersAlphaSetting;
    public final BooleanSetting showCoordsSetting;
    private ClientWorld lastWorld;
    private final Set<Long> detectedChunks;
    private final ConcurrentLinkedQueue<MotionScannerModule.PendingLight> pendingLights;
    public final BooleanSetting soundNotificationSetting;
    public final SliderSetting opacitySetting =
            new SliderSetting(this, "Opacity", 140.0F, 10.0F, 255.0F, 1.0F);
    public final SliderSetting sensitivitySetting =
            new SliderSetting(this, "Sensitivity", 1.0F, 1.0F, 5.0F, 1.0F);
    public final BooleanSetting hUDNotificationSetting =
            new BooleanSetting(this, "HUD Notification", true);
    private final Set<Long> notifiedChunks;
    private final Map<Long, MotionScannerModule.ChunkLightSnapshot> lightSnapshots;
    public final BooleanSetting showTracersSetting;
    public final BooleanSetting chatNotificationsSetting;

    private final Set<Long> groupedChunks;
    private final Set<Long> suspiciousChunks;

    private static void applySkyLight(
            LightData lightdata, MotionScannerModule.ChunkLightSnapshot chunkLightSnapshot) {
        BitSet bitset = lightdata.getInitedSky();
        BitSet uninitedSky = lightdata.getUninitedSky();
        List list = lightdata.getSkyNibbles();
        int i = 0;

        for (int j = 0; j < chunkLightSnapshot.skyLightSections.length; j++) {
            if (bitset != null && bitset.get(j)) {
                byte[] abyte;
                if (list != null && i < list.size()) {
                    abyte = (byte[]) list.get(i);
                } else {
                    abyte = null;
                }

                i++;
                chunkLightSnapshot.skyLightSections[j] = classifySection(abyte);
            } else if (uninitedSky != null && uninitedSky.get(j)) {
                chunkLightSnapshot.skyLightSections[j] =
                        MotionScannerModule.SectionStatus.EMPTY_MASK;
            }
        }
    }

    private int getSensitivity() {
        return Math.round(this.sensitivitySetting.getFloat());
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.world == null) {
            this.pendingLights.clear();
        } else {
            ClientWorld clientworld = client.world;
            if (clientworld != this.lastWorld) {
                this.lightSnapshots.clear();
                this.suspiciousChunks.clear();
                this.groupedChunks.clear();
                this.pendingLights.clear();
                this.lastWorld = clientworld;
            }

            if (client.player != null && client.player.getY() < 0.0) {
                this.pendingLights.clear();
            } else {
                int i = clientworld.countVerticalSections();
                int bottomSectionCoord = clientworld.getBottomSectionCoord();

                for (int k = 0; k < 4096; k++) {
                    MotionScannerModule.PendingLight pendingLight = this.pendingLights.poll();
                    if (pendingLight == null) {
                        break;
                    }

                    this.processLightUpdate(pendingLight, i, bottomSectionCoord);
                }

                this.updateDetections();
            }
        }
    }

    private void notifyDetection(int i, int j) {
        int k = i * 16 + 8;
        int l = j * 16 + 8;
        this.playDetectionSound();
        if (this.chatNotificationsSetting.isOn() && client.player != null) {
            if (this.showCoordsSetting.isOn()) {
                String text = String.format("(Motion Scanner) Base detected: %d, %d", k, l);
                client.player.sendMessage(Text.literal(text), false);
            } else {
                String textValue = "(Motion Scanner) Base detected";
                client.player.sendMessage(Text.literal(textValue), false);
            }
        }

        if (this.hUDNotificationSetting.isOn()) {
            NotificationManager.showItem(
                    "Motion Scanner: Base detected",
                    NotificationManager.Type.INFO,
                    new ItemStack(Blocks.CHEST));
        }
    }

    private static MotionScannerModule.SectionStatus classifySection(byte[] abyte) {
        if (abyte != null && abyte.length == 2048) {
            boolean flag = true;
            boolean flag1 = true;

            for (byte b0 : abyte) {
                if (b0 != 0) {
                    flag = false;
                }

                if (b0 != -1) {
                    flag1 = false;
                }

                if (!flag && !flag1) {
                    return MotionScannerModule.SectionStatus.NORMAL;
                }
            }

            if (flag) {
                return MotionScannerModule.SectionStatus.ZEROED_PRESENT;
            } else {
                return flag1
                        ? MotionScannerModule.SectionStatus.UNIFORM_MAX
                        : MotionScannerModule.SectionStatus.NORMAL;
            }
        } else {
            return MotionScannerModule.SectionStatus.UNKNOWN;
        }
    }

    private void processLightUpdate(MotionScannerModule.PendingLight pendingLight, int i, int j) {
        if (i > 0) {
            long k = ChunkPos.toLong(pendingLight.chunkX, pendingLight.chunkZ);
            MotionScannerModule.ChunkLightSnapshot chunkLightSnapshot = this.lightSnapshots.get(k);
            if (chunkLightSnapshot == null
                    || chunkLightSnapshot.sectionCount != i
                    || chunkLightSnapshot.bottomSection != j) {
                chunkLightSnapshot =
                        new MotionScannerModule.ChunkLightSnapshot(
                                pendingLight.chunkX, pendingLight.chunkZ, i, j);
                this.lightSnapshots.put(k, chunkLightSnapshot);
            }

            try {
                applySkyLight(pendingLight.data, chunkLightSnapshot);
            } catch (Throwable throwable) {
                return;
            }

            if (hasSuspiciousSkyLight(chunkLightSnapshot)) {
                this.suspiciousChunks.add(k);
            }
        }
    }

    private long nearestChunk(List<Long> list) {
        if (client.player == null) {
            return (Long) list.get(0);
        } else {
            ChunkPos chunkpos = client.player.getChunkPos();
            long i = (Long) list.get(0);
            double d0 = chunkDistanceSquared(i, chunkpos);

            for (int j = 1; j < list.size(); j++) {
                long k = (Long) list.get(j);
                double d1 = chunkDistanceSquared(k, chunkpos);
                if (d1 < d0) {
                    i = k;
                    d0 = d1;
                }
            }

            return i;
        }
    }

    public MotionScannerModule() {
        this.soundNotificationSetting = new BooleanSetting(this, "Sound Notification", true);
        this.chatNotificationsSetting = new BooleanSetting(this, "Chat Notifications", true);
        this.showCoordsSetting = new BooleanSetting(this, "Show Coords", true);
        this.showTracersSetting = new BooleanSetting(this, "Show Tracers", false);
        this.tracersAlphaSetting =
                new SliderSetting(this, "Tracers Alpha", 70.0F, 0.0F, 255.0F, 1.0F);
        this.pendingLights = new ConcurrentLinkedQueue<>();
        this.lightSnapshots = new ConcurrentHashMap<>();
        this.suspiciousChunks = ConcurrentHashMap.newKeySet();
        this.groupedChunks = ConcurrentHashMap.newKeySet();
        this.detectedChunks = ConcurrentHashMap.newKeySet();
        this.notifiedChunks = ConcurrentHashMap.newKeySet();
    }

    private static boolean hasSuspiciousSkyLight(
            MotionScannerModule.ChunkLightSnapshot chunkLightSnapshot) {
        int i =
                Math.min(
                        chunkLightSnapshot.sectionCount,
                        chunkLightSnapshot.skyLightSections.length - 1);

        for (int j = 1; j <= i; j++) {
            int k = (chunkLightSnapshot.bottomSection + j - 1) * 16;
            int l = k + 15;
            if (l >= -64
                    && k <= 184
                    && l < 62
                    && chunkLightSnapshot.skyLightSections[j]
                            == MotionScannerModule.SectionStatus.ZEROED_PRESENT) {
                return true;
            }
        }

        return false;
    }

    private void detectGroups() {
        for (List list : this.groupSuspiciousChunks()) {
            if (list.size() >= this.getSensitivity()) {
                boolean flag = false;

                for (long i : (Iterable<Long>) (Iterable) list) {
                    if (this.groupedChunks.contains(i)) {
                        flag = true;
                        break;
                    }
                }

                this.groupedChunks.addAll(list);
                if (!flag) {
                    long j = this.nearestChunk(list);
                    if (this.detectedChunks.add(j) && this.notifiedChunks.add(j)) {
                        this.notifyDetection(ChunkPos.getPackedX(j), ChunkPos.getPackedZ(j));
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPacket(PacketEvent packetEvent) {
        if (!packetEvent.isSend() && packetEvent.getPacket() != null) {
            if (packetEvent.getPacket() instanceof ChunkDataS2CPacket chunkdatas2cpacket) {
                this.queueLightUpdate(
                        chunkdatas2cpacket.getChunkX(),
                        chunkdatas2cpacket.getChunkZ(),
                        chunkdatas2cpacket.getLightData());
            } else if (packetEvent.getPacket()
                    instanceof LightUpdateS2CPacket lightupdates2cpacket) {
                this.queueLightUpdate(
                        lightupdates2cpacket.getChunkX(),
                        lightupdates2cpacket.getChunkZ(),
                        lightupdates2cpacket.getData());
            }
        }
    }

    private static double chunkDistanceSquared(long i, ChunkPos chunkpos) {
        double d0 = (double) (ChunkPos.getPackedX(i) - chunkpos.x);
        double d1 = (double) (ChunkPos.getPackedZ(i) - chunkpos.z);
        return d0 * d0 + d1 * d1;
    }

    public void queueLightUpdate(int i, int j, LightData lightdata) {
        if (lightdata != null) {
            this.pendingLights.offer(new MotionScannerModule.PendingLight(i, j, lightdata));
        }
    }

    private void playDetectionSound() {
        if (this.soundNotificationSetting.isOn() && client.player != null) {
            client.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.2F, 1.2F);
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.world != null
                && client.player != null
                && (!this.suspiciousChunks.isEmpty() || !this.detectedChunks.isEmpty())) {
            ChunkPos chunkpos = client.player.getChunkPos();
            if (!this.detectedChunks.isEmpty()) {
                int alpha = Math.round(this.opacitySetting.getFloat());
                int j = ColorUtils.cachedRgba(40, 130, 255, alpha);
                WorldEspRenderer.clear();

                for (long k : this.detectedChunks) {
                    int packedX = ChunkPos.getPackedX(k);
                    int packedZ = ChunkPos.getPackedZ(k);
                    if (Math.abs(packedX - chunkpos.x) <= 17
                            && Math.abs(packedZ - chunkpos.z) <= 17) {
                        double d0 = (double) packedX * 16.0;
                        double d1 = (double) packedZ * 16.0;
                        Box box = new Box(d0, -64.0, d1, d0 + 16.0, 320.0, d1 + 16.0);
                        WorldEspRenderer.enqueueBox(box, j, this.showTracersSetting.isOn());
                    }
                }

                WorldEspRenderer.flush(render3DEvent.getMatrixStack());
            }
        }
    }

    private List<List<Long>> groupSuspiciousChunks() {
        HashSet hashset = new HashSet<>(this.suspiciousChunks);
        ArrayList arraylist = new ArrayList();

        while (!hashset.isEmpty()) {
            long i = (Long) hashset.iterator().next();
            ArrayList arrayList = new ArrayList();
            ArrayDeque arraydeque = new ArrayDeque();
            hashset.remove(i);
            arraydeque.add(i);

            while (!arraydeque.isEmpty()) {
                long j = (Long) arraydeque.removeFirst();
                arrayList.add(j);
                int packedX = ChunkPos.getPackedX(j);
                int packedZ = ChunkPos.getPackedZ(j);

                for (int i1 = -2; i1 <= 2; i1++) {
                    for (int j1 = -2; j1 <= 2; j1++) {
                        if (i1 != 0 || j1 != 0) {
                            long k1 = ChunkPos.toLong(packedX + i1, packedZ + j1);
                            if (hashset.remove(k1)) {
                                arraydeque.addLast(k1);
                            }
                        }
                    }
                }
            }

            arraylist.add(arrayList);
        }

        return arraylist;
    }

    private void updateDetections() {
        this.detectGroups();
    }

    @Environment(EnvType.CLIENT)
    private static final class ChunkLightSnapshot {
        private final int chunkX;
        private final int sectionCount;
        private final int chunkZ;
        private final MotionScannerModule.SectionStatus[] skyLightSections;
        private final int bottomSection;

        private ChunkLightSnapshot(
                int chunkXValue, int chunkZValue, int sectionCountValue, int bottomSectionValue) {
            this.chunkX = chunkXValue;
            this.chunkZ = chunkZValue;
            this.sectionCount = sectionCountValue;
            this.bottomSection = bottomSectionValue;
            this.skyLightSections = new MotionScannerModule.SectionStatus[sectionCountValue + 2];
            Arrays.fill(this.skyLightSections, MotionScannerModule.SectionStatus.UNKNOWN);
        }
    }

    @Environment(EnvType.CLIENT)
    private static record PendingLight(int chunkX, int chunkZ, LightData data) {}

    @Environment(EnvType.CLIENT)
    private static enum SectionStatus {
        UNKNOWN,
        EMPTY_MASK,
        ZEROED_PRESENT,
        UNIFORM_MAX,
        NORMAL;
    }
}
