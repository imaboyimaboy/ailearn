package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class BooleanSetting extends Setting<Boolean> {
    public TimedAnimation timedAnimation = new DecelerateAnimation(300, 1.0);
    public TimedAnimation timedAnimation2 = new DecelerateAnimation(300, 1.0);

    private Boolean cachedValue;
    public TimedAnimation timedAnimation3 = new DecelerateAnimation(300, 1.0);

    public static BooleanSetting create(String text, Boolean obool) {
        return new BooleanSetting(text, obool);
    }

    public BooleanSetting(String nameValue, Boolean obool) {
        super(nameValue, obool);
        this.cachedValue = obool;
    }

    public Boolean isOn() {
        if (this.cachedValue == null) {
            this.cachedValue = (Boolean) super.getValue();
        }

        return (this.cachedValue && this.getVisibility().get());
    }

    public BooleanSetting onChange(Runnable runnable) {
        return (BooleanSetting)
                super.onChange(
                        () -> {
                            runnable.run();
                            if ((Boolean) super.getValue() && this.getVisibility().get()) {
                                this.cachedValue = true;
                            } else {
                                this.cachedValue = false;
                            }
                        });
    }

    public BooleanSetting setValue(Boolean obool) {
        if (obool && this.getVisibility().get()) {
            this.cachedValue = true;
        } else {
            this.cachedValue = false;
        }

        return (BooleanSetting) super.setValue(obool);
    }

    public BooleanSetting visibleWhen(Supplier supplier) {
        return (BooleanSetting) super.visibleWhen(supplier);
    }

    public BooleanSetting(Module moduleValue, String nameValue, Boolean obool) {
        super(moduleValue, nameValue, obool);
        this.cachedValue = obool;
    }
}
