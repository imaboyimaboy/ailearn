package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

@Environment(EnvType.CLIENT)
public interface MinecraftAccess {
    MinecraftClient client = MinecraftClient.getInstance();
}
