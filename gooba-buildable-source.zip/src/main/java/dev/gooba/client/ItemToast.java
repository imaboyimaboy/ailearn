package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.Toast.Visibility;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class ItemToast implements Toast {
    private final ItemStack itemStack;
    private static final Identifier textureId = Identifier.of("minecraft", "toast/advancement");

    private Visibility visibility;

    private final String title;
    private final String description;

    @Override
    public Visibility getVisibility() {
        return this.visibility;
    }

    @Override
    public void draw(DrawContext drawcontext, TextRenderer textrenderer, long i) {
        drawcontext.drawGuiTexture(RenderPipelines.GUI_TEXTURED, textureId, 0, 0, 160, 32);
        if (this.itemStack != null && !this.itemStack.isEmpty()) {
            drawcontext.drawItem(this.itemStack, 8, 8);
        }

        drawcontext.drawText(textrenderer, this.title, 34, 7, -5157633, false);
        drawcontext.drawText(textrenderer, this.description, 34, 18, -6564, false);
    }

    @Override
    public void update(ToastManager toastmanager, long i) {
        if (i >= 5000L) {
            this.visibility = Visibility.HIDE;
        }
    }

    public ItemToast(String titleValue, String descriptionValue, ItemStack itemStack) {
        this.title = titleValue;
        this.description = descriptionValue;
        this.itemStack = itemStack;
    }
}
