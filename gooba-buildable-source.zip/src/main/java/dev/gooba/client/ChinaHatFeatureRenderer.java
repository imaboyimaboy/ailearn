package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public class ChinaHatFeatureRenderer
        extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
    public static final RenderPipeline OUTLINE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation("pipeline/china_hat_outline")
                            .withVertexShader("core/position_color")
                            .withFragmentShader("core/position_color")
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(true)
                            .withCull(false)
                            .withVertexFormat(
                                    VertexFormats.POSITION_COLOR, DrawMode.DEBUG_LINE_STRIP)
                            .build());
    public static final RenderPipeline FILL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation("pipeline/china_hat")
                            .withVertexShader("core/position_color")
                            .withFragmentShader("core/position_color")
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(true)
                            .withCull(false)
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.TRIANGLE_FAN)
                            .build());
    public static final RenderLayer FILL_LAYER =
            RenderLayer.of(
                    "china_hat",
                    RenderSetup.builder(FILL_PIPELINE)
                            .translucent()
                            .expectedBufferSize(8192)
                            .build());
    public static final RenderLayer OUTLINE_LAYER =
            RenderLayer.of(
                    "china_hat_outline",
                    RenderSetup.builder(OUTLINE_PIPELINE)
                            .translucent()
                            .expectedBufferSize(4096)
                            .build());

    private boolean isFriend(PlayerEntityRenderState playerentityrenderstate) {
        try {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (minecraftclient.world == null) {
                return false;
            }

            if (minecraftclient.world.getEntityById(playerentityrenderstate.id)
                    instanceof PlayerEntity playerentity) {
                return Gooba.getInstance()
                        .getFriendManager()
                        .isFriend(playerentity.getName().getString());
            }
        } catch (Exception exception) {
        }

        return false;
    }

    private int hatColor(int i, int j, ChinaHatModule chinaHatModule, float f) {
        long nowMillis = System.currentTimeMillis();
        float f1 = (float) nowMillis / (1000.0F / f) % (float) j;
        return ColorUtils.animatedAccent(
                (int) ((float) i * (360.0F / (float) j) + f1 * (360.0F / (float) j)));
    }

    private void drawOutline(
            MatrixStack matrixstack,
            VertexConsumerProvider vertexconsumerprovider,
            ChinaHatModule chinaHatModule) {
        VertexConsumer vertexconsumer = vertexconsumerprovider.getBuffer(OUTLINE_LAYER);
        Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
        float f = 0.55F;
        float f1 = 5.0F;
        short alpha = 255;

        for (int i = 0; i <= 64; i++) {
            int color = this.hatColor(i * 2, 128, chinaHatModule, f1);
            color = ColorUtils.withAlpha(color, alpha);
            float f2 = (float) i * (float) (Math.PI * 2) / 64.0F;
            float f3 = -MathHelper.sin((double) f2) * f;
            float f4 = MathHelper.cos((double) f2) * f;
            vertexconsumer.vertex(matrix4f, f3, 0.0F, f4).color(color);
        }
    }

    private void drawCone(
            MatrixStack matrixstack,
            VertexConsumerProvider vertexconsumerprovider,
            ChinaHatModule chinaHatModule) {
        VertexConsumer vertexconsumer = vertexconsumerprovider.getBuffer(FILL_LAYER);
        Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
        float f = 0.55F;
        float f1 = 0.31F;
        short alpha = 200;
        float f2 = 5.0F;
        int color = this.hatColor(0, 128, chinaHatModule, f2);
        color = ColorUtils.withAlpha(color, alpha);
        vertexconsumer.vertex(matrix4f, 0.0F, f1, 0.0F).color(color);

        for (int j = 0; j <= 128; j++) {
            int colorValue = this.hatColor(j, 128, chinaHatModule, f2);
            colorValue = ColorUtils.withAlpha(colorValue, alpha);
            float f3 = (float) j * (float) (Math.PI * 2) / 128.0F;
            float f4 = -MathHelper.sin((double) f3) * f;
            float f5 = MathHelper.cos((double) f3) * f;
            vertexconsumer.vertex(matrix4f, f4, 0.0F, f5).color(colorValue);
        }

        for (int l = 128; l >= 0; l--) {
            int color3 = this.hatColor(l, 128, chinaHatModule, f2);
            color3 = ColorUtils.withAlpha(color3, alpha);
            float f6 = (float) l * (float) (Math.PI * 2) / 128.0F;
            float f7 = -MathHelper.sin((double) f6) * f;
            float f8 = MathHelper.cos((double) f6) * f;
            vertexconsumer.vertex(matrix4f, f7, 0.0F, f8).color(color3);
        }

        vertexconsumer.vertex(matrix4f, 0.0F, f1, 0.0F).color(color);
    }

    @Override
    public void render(
            MatrixStack matrixstack,
            OrderedRenderCommandQueue orderedrendercommandqueue,
            int i,
            PlayerEntityRenderState playerentityrenderstate,
            float f,
            float f1) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        ChinaHatModule chinaHatModule = ChinaHatModule.getInstance();
        if (chinaHatModule != null && chinaHatModule.isEnabled()) {
            if (minecraftclient.player != null) {
                boolean isLocalPlayer =
                        this.isLocalPlayer(playerentityrenderstate, minecraftclient);
                boolean isFriend = this.isFriend(playerentityrenderstate);
                if (isLocalPlayer || isFriend) {
                    FreecamModule freecamModule2 = FreecamModule.getInstance();
                    boolean flag2;
                    flag2 = (freecamModule2 != null && freecamModule2.isActive());

                    if (!isLocalPlayer
                            || !minecraftclient.options.getPerspective().isFirstPerson()
                            || flag2) {
                        if (!isLocalPlayer || !flag2 || freecamModule2.showOwnBodySetting.isOn()) {
                            matrixstack.push();
                            this.getContextModel().head.applyTransform(matrixstack);
                            matrixstack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180.0F));
                            matrixstack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90.0F));
                            matrixstack.translate(0.0F, 0.5F, 0.0F);
                            Immediate immediate =
                                    minecraftclient.getBufferBuilders().getEntityVertexConsumers();
                            this.drawCone(matrixstack, immediate, chinaHatModule);
                            this.drawOutline(matrixstack, immediate, chinaHatModule);
                            immediate.draw();
                            matrixstack.pop();
                        }
                    }
                }
            }
        }
    }

    private boolean isLocalPlayer(
            PlayerEntityRenderState playerentityrenderstate, MinecraftClient minecraftclient) {
        try {
            if (playerentityrenderstate.id == minecraftclient.player.getId()) {
                return true;
            }
        } catch (Exception exceptionValue) {
        }

        try {
            if (playerentityrenderstate.playerName != null
                    && minecraftclient.player.getName() != null) {
                return playerentityrenderstate
                        .playerName
                        .getString()
                        .equals(minecraftclient.player.getName().getString());
            }
        } catch (Exception exception) {
        }

        return false;
    }

    public ChinaHatFeatureRenderer(
            FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel>
                    featurerenderercontext) {
        super(featurerenderercontext);
    }
}
