package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface OverlayEditor {
    void saveAndClose();

    boolean mouseScrolled(float f, float f1, double d0);

    default void handleMouseButton(float f, float f1, int i, boolean flag) {}

    default void handleMouseMove(float f, float f1) {}

    void saveAndCloseOnKey(int i);

    boolean isActive();

    boolean mouseClicked(float f, float f1, int i);

    void render(float f, float f1, float f2, float f3, float f4);

    default boolean capturesMouse(float f, float f1) {
        return this.isActive();
    }

    boolean mouseReleased(int i);
}
