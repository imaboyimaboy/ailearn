package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class FogEvent extends CancellableEvent {
    private int color;
    private float distance;

    public int getColor() {
        return this.color;
    }

    public void setColor(int colorValue) {
        this.color = colorValue;
    }

    public void setDistance(float distanceValue) {
        this.distance = distanceValue;
    }

    public float getDistance() {
        return this.distance;
    }
}
