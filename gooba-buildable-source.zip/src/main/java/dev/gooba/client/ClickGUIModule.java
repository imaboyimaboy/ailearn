package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "ClickGUI",
        category = ModuleCategory.CLIENT,
        key = 344,
        desc = "Controls the ClickGUI scale",
        autoEnabled = true,
        allowDisable = false)
@Environment(EnvType.CLIENT)
public class ClickGUIModule extends Module {
    public BooleanSetting soundsSetting;
    public SliderSetting sizeSetting = new SliderSetting(this, "Size", 1.0F, 0.5F, 1.5F, 0.1F);

    @EventHandler
    public void onKeyPress(KeyPressEvent keyPressEvent) {
        if (keyPressEvent.getKey() == this.getKey()) {
            client.setScreen(Gooba.instance.getClickGui());
        }
    }

    public ClickGUIModule() {
        this.soundsSetting = new BooleanSetting(this, "Sounds", true);
    }
}
