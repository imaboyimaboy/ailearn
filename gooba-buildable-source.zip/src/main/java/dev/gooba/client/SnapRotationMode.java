package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class SnapRotationMode implements RotationModeHandler {

    private void updateFovSnap(
            AttackAuraModule attackAuraModule, LivingEntity livingentity, boolean flag) {
        Vec3d vec3d =
                RaycastUtils.findAimPoint(livingentity.getBoundingBox(), false)
                        .add(
                                0.3F * Math.sin((double) System.currentTimeMillis() / 50.0),
                                0.1F * Math.sin((double) System.currentTimeMillis() / 50.0)
                                        + 0.3F
                                                * Math.cos(
                                                        (double) System.currentTimeMillis() / 50.0),
                                0.3F * Math.cos((double) System.currentTimeMillis() / 50.0))
                        .subtract(client.player.getEyePos());
        float f = (float) Math.toDegrees(Math.atan2(-vec3d.x, vec3d.z));
        float f1 =
                (float)
                        MathHelper.clamp(
                                -Math.toDegrees(Math.atan2(vec3d.y, Math.hypot(vec3d.x, vec3d.z))),
                                -90.0,
                                90.0);
        float f2 = (float) Math.cos((double) System.currentTimeMillis() / 40.0) * 4.0F;
        float f3 = (float) Math.sin((double) System.currentTimeMillis() / 70.0) * 4.0F;
        if (!flag
                || attackAuraModule.angularDistanceToTarget(livingentity)
                        >= (double) attackAuraModule.fOVSetting.getFloat().floatValue()) {
            f2 = 0.0F;
            f3 = 0.0F;
            f = RotationStateManager.yaw;
            f1 = RotationStateManager.pitch;
        }

        TargetRingRenderer.aim(
                new Rotation(f + f2, f1 + f3), 30.0F, 30.0F, 30.0F, 30.0F, 1, 15, false);
    }

    private void updateAttackSnap(
            AttackAuraModule attackAuraModule, LivingEntity livingentity, float[] afloat) {
        boolean canAttack = CombatUtils.canAttack(livingentity, false, true, true, -100L, afloat);
        Vec3d vec3d = TargetPositionUtils.relativeFeetOffset(livingentity);
        float f = (float) Math.toDegrees(Math.atan2(-vec3d.x, vec3d.z));
        float f1 =
                (float)
                        MathHelper.clamp(
                                -Math.toDegrees(Math.atan2(vec3d.y, Math.hypot(vec3d.x, vec3d.z))),
                                -90.0,
                                90.0);
        float aimYawSpeedValue = MathUtils.secureRandomFloat(80.0F, 90.0F);
        float aimPitchSpeedValue = MathUtils.secureRandomFloat(80.0F, 90.0F);
        float f4 = (float) Math.cos((double) System.currentTimeMillis() / 30.0);
        float f5 = (float) Math.sin((double) System.currentTimeMillis() / 30.0);
        float f6 = f4 * MathUtils.secureRandomFloat(8.0F, 16.0F);
        float f7 = f5 * MathUtils.secureRandomFloat(8.0F, 16.0F);
        boolean flag1 = false;
        if (canAttack) {
            attackAuraModule.snapTicksRemaining = 1.0F;
        }

        if (attackAuraModule.snapTicksRemaining > 0.0F) {
            flag1 = true;
            attackAuraModule.snapTicksRemaining--;
        }

        if (!flag1) {
            f6 = 0.0F;
            f7 = 0.0F;
            f = RotationStateManager.yaw;
            f1 = RotationStateManager.pitch;
        }

        Rotation rotation = new Rotation(f + f6, f1 + f7);
        TargetRingRenderer.aim(
                rotation,
                aimYawSpeedValue,
                aimPitchSpeedValue,
                (float) MathUtils.randomIntInclusive(90, 180),
                (float) MathUtils.randomIntInclusive(90, 180),
                MathUtils.randomIntInclusive(0, 3),
                15,
                false);
    }

    @Override
    public void updateRotation(
            AttackAuraModule attackAuraModule,
            LivingEntity livingentity,
            float[] afloat,
            boolean flag) {
        if (attackAuraModule.snapModeSetting.isSelected("Fov")) {
            this.updateFovSnap(attackAuraModule, livingentity, flag);
        } else {
            this.updateAttackSnap(attackAuraModule, livingentity, afloat);
        }
    }
}
