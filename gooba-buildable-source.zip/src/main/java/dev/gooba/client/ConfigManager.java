package dev.gooba.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

@Environment(EnvType.CLIENT)
public class ConfigManager {

    private final Map<String, String> presets;
    private String defaultConfig;
    private static final Gson gson = new GsonBuilder().disableHtmlEscaping().create();

    private final Path stateFile = GoobaPaths.CONFIG_DIRECTORY.resolve("state.json");

    private final Map<String, float[]> positions;
    private int ticksSinceSave;
    private final Map<String, float[]> defaultPositions;
    private String activeConfig = "";

    private boolean isString(JsonElement jsonelement) {
        return jsonelement != null
                && jsonelement.isJsonPrimitive()
                && jsonelement.getAsJsonPrimitive().isString();
    }

    public synchronized boolean deletePreset(String text) {
        if (text != null && this.presets.containsKey(text)) {
            this.presets.remove(text);
            this.writeState();
            return true;
        } else {
            return false;
        }
    }

    private boolean isFiniteNumber(JsonElement jsonelement) {
        return this.isNumber(jsonelement) && Float.isFinite(jsonelement.getAsFloat());
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (++this.ticksSinceSave >= 1200) {
            this.ticksSinceSave = 0;
            this.saveState();
        }
    }

    private boolean isBoolean(JsonElement jsonelement) {
        return jsonelement != null
                && jsonelement.isJsonPrimitive()
                && jsonelement.getAsJsonPrimitive().isBoolean();
    }

    private boolean validateConfig(JsonObject jsonobject) {
        if (jsonobject.has("format")
                && jsonobject.get("format").isJsonPrimitive()
                && "x7Qm2".equals(jsonobject.get("format").getAsString())) {
            if (jsonobject.has("version")
                    && jsonobject.get("version").isJsonPrimitive()
                    && jsonobject.get("version").getAsInt() == 1) {
                if (jsonobject.has("modules") && jsonobject.get("modules").isJsonObject()) {
                    JsonObject modules = jsonobject.getAsJsonObject("modules");

                    for (Module module : Gooba.getInstance().getModuleRegistry().values()) {
                        if (modules.has(module.getName())) {
                            JsonElement jsonelement = modules.get(module.getName());
                            if (!jsonelement.isJsonObject()) {
                                return false;
                            }

                            JsonObject asJsonObject = jsonelement.getAsJsonObject();
                            if (asJsonObject.has("enabled")
                                    && !this.isBoolean(asJsonObject.get("enabled"))) {
                                return false;
                            }

                            if (asJsonObject.has("key")
                                    && !this.isNumber(asJsonObject.get("key"))) {
                                return false;
                            }

                            if (asJsonObject.has("settings")) {
                                if (!asJsonObject.get("settings").isJsonObject()) {
                                    return false;
                                }

                                JsonObject settings = asJsonObject.getAsJsonObject("settings");

                                for (Setting setting : module.getSettings()) {
                                    if (setting != module.keybind
                                            && settings.has(setting.getName())
                                            && !this.validateSetting(
                                                    setting, settings.get(setting.getName()))) {
                                        return false;
                                    }
                                }
                            }
                        }
                    }

                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public ConfigManager() {
        this.defaultConfig = "";
        this.positions = new HashMap<>();
        this.defaultPositions = new HashMap<>();
        this.presets = new LinkedHashMap<>();
    }

    public synchronized boolean importConfig(String text) {
        if (text != null && !text.isBlank()) {
            try {
                JsonElement jsonelement = JsonParser.parseString(text.trim());
                if (!jsonelement.isJsonObject()) {
                    return false;
                } else {
                    JsonObject jsonobject = jsonelement.getAsJsonObject();
                    if (!this.validateConfig(jsonobject)) {
                        return false;
                    } else {
                        this.capturePositions();
                        this.applyModules(jsonobject.getAsJsonObject("modules"));
                        this.restorePositions();
                        this.activeConfig = this.serializeModules();
                        this.writeState();
                        return true;
                    }
                }
            } catch (RuntimeException runtimeexception) {
                return false;
            }
        } else {
            return false;
        }
    }

    private void copyPositions(Map<String, float[]> map, Map<String, float[]> mapValue) {
        mapValue.clear();

        for (Entry entry : map.entrySet()) {
            mapValue.put(
                    (String) entry.getKey(),
                    new float[] {((float[]) entry.getValue())[0], ((float[]) entry.getValue())[1]});
        }
    }

    public synchronized void restoreDefaults() {
        if (!this.defaultConfig.isBlank()) {
            JsonObject jsonobject = JsonParser.parseString(this.defaultConfig).getAsJsonObject();
            this.applyModules(jsonobject.getAsJsonObject("modules"));
            this.positions.clear();
            this.copyPositions(this.defaultPositions, this.positions);
            this.restorePositions();
            this.activeConfig = this.serializeModules();
            this.writeState();
        }
    }

    public synchronized void savePreset(String text, String textValue) {
        if (text != null && !text.isBlank() && textValue != null && !textValue.isBlank()) {
            try {
                JsonElement jsonelement = JsonParser.parseString(textValue);
                if (!jsonelement.isJsonObject()) {
                    return;
                }

                if (!this.validateConfig(jsonelement.getAsJsonObject())) {
                    return;
                }

                this.presets.put(text, gson.toJson(jsonelement));
            } catch (RuntimeException runtimeException) {
                return;
            }

            try {
                this.writeState();
            } catch (RuntimeException runtimeexception) {
            }
        }
    }

    private void readSetting(JsonObject jsonobject, Setting<?> setting) {
        if (jsonobject.has(setting.getName())) {
            JsonElement jsonelement = jsonobject.get(setting.getName());
            if (setting instanceof PositionSetting positionSetting2) {
                JsonObject asJsonObject = jsonelement.getAsJsonObject();
                positionSetting2.position.set(
                        asJsonObject.get("x").getAsFloat(), asJsonObject.get("y").getAsFloat());
                positionSetting2.targetPosition.set(positionSetting2.position);
            } else if (setting instanceof MultiBooleanSetting multiBooleanSetting) {
                JsonObject asJsonObjectValue = jsonelement.getAsJsonObject();

                for (BooleanSetting booleanSetting :
                        (Iterable<BooleanSetting>) (Iterable) multiBooleanSetting.getOptions()) {
                    String text = booleanSetting.getName().toLowerCase();
                    if (asJsonObjectValue.has(text)) {
                        booleanSetting.setValue(asJsonObjectValue.get(text).getAsBoolean());
                    }
                }
            } else if (setting instanceof StringListSetting stringListSetting2) {
                stringListSetting2.getSelectedIds().clear();
                stringListSetting2.getColorSettings().clear();
                JsonElement jsonElement;
                if (jsonelement.isJsonObject()) {
                    jsonElement = jsonelement.getAsJsonObject().get("blocks");
                } else {
                    jsonElement = jsonelement;
                }

                for (JsonElement jsonElementValue : jsonElement.getAsJsonArray()) {
                    stringListSetting2.addBlock(jsonElementValue.getAsString());
                }

                if (jsonelement.isJsonObject()) {
                    for (Entry entry :
                            jsonelement.getAsJsonObject().getAsJsonObject("colors").entrySet()) {
                        String string = StringListSetting.normalizeBlockId((String) entry.getKey());
                        if (string != null) {
                            stringListSetting2
                                    .getOrCreateColorSetting(string)
                                    .setValue(((JsonElement) entry.getValue()).getAsInt());
                        }
                    }
                }
            } else if (setting instanceof BlockListSetting blockListSetting2) {
                ArrayList arraylist = new ArrayList();

                for (JsonElement jsonElement2 : jsonelement.getAsJsonArray()) {
                    JsonObject asJsonObject2 = jsonElement2.getAsJsonObject();
                    arraylist.add(
                            new BlockListSetting.Entry(
                                    asJsonObject2.get("block").getAsString(),
                                    asJsonObject2.get("color").getAsInt()));
                }

                blockListSetting2.setEntries(arraylist);
            } else if (setting instanceof MatrixSetting matrixSetting) {
                ArrayList arrayList = new ArrayList();

                for (JsonElement jsonElement3 : jsonelement.getAsJsonArray()) {
                    arrayList.add(jsonElement3.getAsString());
                }

                matrixSetting.loadRows(arrayList);
            } else if (setting instanceof BooleanSetting booleanSetting2) {
                booleanSetting2.setValue(jsonelement.getAsBoolean());
            } else if (setting instanceof ConditionalBooleanSetting conditionalBooleanSetting) {
                conditionalBooleanSetting.setValue(jsonelement.getAsBoolean());
            } else if (setting instanceof SliderSetting sliderSetting2) {
                sliderSetting2.setValue(jsonelement.getAsFloat());
            } else if (setting instanceof ModeSetting modeSetting2) {
                modeSetting2.setValue(jsonelement.getAsString());
            } else if (setting instanceof OptionSetting optionSetting) {
                optionSetting.setValue(jsonelement.getAsString());
            } else if (setting instanceof KeybindSetting keybindSetting2) {
                keybindSetting2.setValue(jsonelement.getAsInt());
            } else if (setting instanceof ColorSetting colorSetting4) {
                if (colorSetting4.getModule() instanceof ShaderESPModule
                        && jsonobject.has("Color Mode")
                        && "Theme".equals(jsonobject.get("Color Mode").getAsString())) {
                    colorSetting4.setValue(ColorUtils.hudAccent());
                } else {
                    colorSetting4.setValue(jsonelement.getAsInt());
                }
            } else if (setting instanceof TextSetting textSetting2) {
                textSetting2.setValue(jsonelement.getAsString());
            } else if (setting instanceof ButtonSetting buttonSetting) {
                buttonSetting.setValue(jsonelement.getAsString());
            }
        }
    }

    private void writeState() {
        JsonObject jsonobject;
        try {
            Files.createDirectories(this.stateFile.getParent());
            jsonobject = new JsonObject();
            jsonobject.addProperty("format", "p9Lm4V");
            jsonobject.addProperty("version", 1);
            JsonElement jsonelement;
            if (this.activeConfig.isBlank()) {
                jsonelement = JsonParser.parseString(this.serializeModules());
            } else {
                jsonelement = JsonParser.parseString(this.activeConfig);
            }

            jsonobject.add("active", jsonelement);
            JsonObject jsonObject = new JsonObject();

            for (Entry entry : this.positions.entrySet()) {
                JsonObject jsonObjectValue = new JsonObject();
                jsonObjectValue.addProperty("x", ((float[]) entry.getValue())[0]);
                jsonObjectValue.addProperty("y", ((float[]) entry.getValue())[1]);
                jsonObject.add((String) entry.getKey(), jsonObjectValue);
            }

            jsonobject.add("layout", jsonObject);
            JsonArray jsonarray = new JsonArray();

            for (Entry entryValue : this.presets.entrySet()) {
                JsonObject jsonObject2 = new JsonObject();
                jsonObject2.addProperty("name", (String) entryValue.getKey());
                jsonObject2.add("data", JsonParser.parseString((String) entryValue.getValue()));
                jsonarray.add(jsonObject2);
            }

            jsonobject.add("configs", jsonarray);
        } catch (RuntimeException | IOException exception) {
            return;
        }

        try {
            Files.writeString(this.stateFile, gson.toJson((JsonElement) jsonobject));
        } catch (RuntimeException | IOException ioexception) {
        }
    }

    public void subscribe() {
        Gooba.getEventBus().subscribe(this);
    }

    public void initializeState() {
        this.capturePositions();
        this.defaultConfig = this.serializeModules();
        this.copyPositions(this.positions, this.defaultPositions);
        if (!this.loadState()) {
            this.saveState();
        }
    }

    private void capturePositions() {
        for (Module module : Gooba.getInstance().getModuleRegistry().values()) {
            for (Setting setting : module.getSettings()) {
                if (setting instanceof PositionSetting positionSetting2) {
                    Map mapx = this.positions;
                    String name = module.getName();
                    String nameValue = setting.getName();
                    String name2 = name;
                    mapx.put(
                            name2 + "\u0000" + nameValue,
                            new float[] {
                                positionSetting2.targetPosition.x, positionSetting2.targetPosition.y
                            });
                }
            }
        }
    }

    private void applyModules(JsonObject jsonobject) {
        for (Module module : Gooba.getInstance().getModuleRegistry().values()) {
            if (jsonobject.has(module.getName())) {
                JsonObject asJsonObject = jsonobject.getAsJsonObject(module.getName());
                if (asJsonObject.has("key")) {
                    module.setKey(asJsonObject.get("key").getAsInt());
                }

                if (asJsonObject.has("settings")) {
                    JsonObject settings = asJsonObject.getAsJsonObject("settings");

                    for (Setting setting : module.getSettings()) {
                        if (!(setting instanceof PositionSetting)) {
                            this.readSetting(settings, setting);
                        }
                    }
                }
            }
        }

        for (Module moduleValue : Gooba.getInstance().getModuleRegistry().values()) {
            if (jsonobject.has(moduleValue.getName())) {
                JsonObject asJsonObjectValue = jsonobject.getAsJsonObject(moduleValue.getName());
                if (asJsonObjectValue.has("enabled")) {
                    moduleValue.setEnabled(asJsonObjectValue.get("enabled").getAsBoolean(), false);
                }
            }
        }
    }

    private boolean isAllowedOption(JsonElement jsonelement, List<String> list) {
        if (!this.isString(jsonelement)) {
            return false;
        } else {
            String jsonelementValue = jsonelement.getAsString();
            return list.stream().anyMatch(text -> text.equalsIgnoreCase(jsonelementValue));
        }
    }

    private void writeSetting(JsonObject jsonobject, Setting<?> setting) {
        if (setting instanceof PositionSetting positionSetting2) {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("x", positionSetting2.position.x);
            jsonObject.addProperty("y", positionSetting2.position.y);
            jsonobject.add(setting.getName(), jsonObject);
        } else if (setting instanceof MultiBooleanSetting multiBooleanSetting) {
            JsonObject jsonObjectValue = new JsonObject();

            for (BooleanSetting booleanSetting :
                    (Iterable<BooleanSetting>) (Iterable) multiBooleanSetting.getOptions()) {
                jsonObjectValue.addProperty(
                        booleanSetting.getName().toLowerCase(), booleanSetting.isOn());
            }

            jsonobject.add(setting.getName(), jsonObjectValue);
        } else if (setting instanceof StringListSetting stringListSetting2) {
            JsonArray jsonArray = new JsonArray();

            for (String text : stringListSetting2.getSelectedIds()) {
                jsonArray.add(text);
            }

            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.add("blocks", jsonArray);
            JsonObject jsonObject3 = new JsonObject();
            stringListSetting2
                    .getColorSettings()
                    .forEach(
                            (sx, colorSetting4) ->
                                    jsonObject3.addProperty(sx, colorSetting4.getColor()));
            jsonObject2.add("colors", jsonObject3);
            jsonobject.add(setting.getName(), jsonObject2);
        } else if (setting instanceof BlockListSetting blockListSetting2) {
            JsonArray jsonArrayValue = new JsonArray();

            for (BlockListSetting.Entry entry : blockListSetting2.getEntries()) {
                JsonObject jsonObject4 = new JsonObject();
                jsonObject4.addProperty("block", entry.getBlockId());
                jsonObject4.addProperty("color", entry.color());
                jsonArrayValue.add(jsonObject4);
            }

            jsonobject.add(setting.getName(), jsonArrayValue);
        } else if (!(setting instanceof MatrixSetting matrixSetting)) {
            Object object = setting.getValue();
            if (object instanceof Boolean obool) {
                jsonobject.addProperty(setting.getName(), obool);
            } else if (object instanceof Float value) {
                jsonobject.addProperty(setting.getName(), value);
            } else if (object instanceof String textValue) {
                jsonobject.addProperty(setting.getName(), textValue);
            } else if (object instanceof Integer integer) {
                jsonobject.addProperty(setting.getName(), integer);
            }
        } else {
            JsonArray jsonarray = new JsonArray();

            for (String text2 : matrixSetting.serializeRows()) {
                jsonarray.add(text2);
            }

            jsonobject.add(setting.getName(), jsonarray);
        }
    }

    public synchronized String exportConfig() {
        this.saveState();
        return this.activeConfig;
    }

    private boolean loadState() {
        if (!Files.isRegularFile(this.stateFile)) {
            return false;
        } else {
            try {
                JsonElement jsonelement = JsonParser.parseString(Files.readString(this.stateFile));
                if (!jsonelement.isJsonObject()) {
                    return false;
                } else {
                    JsonObject jsonobject = jsonelement.getAsJsonObject();
                    if (jsonobject.has("format")
                            && "p9Lm4V".equals(jsonobject.get("format").getAsString())) {
                        if (jsonobject.has("version")
                                && jsonobject.get("version").getAsInt() == 1) {
                            this.positions.clear();
                            if (jsonobject.has("layout")
                                    && jsonobject.get("layout").isJsonObject()) {
                                for (Entry entry :
                                        jsonobject.getAsJsonObject("layout").entrySet()) {
                                    if (((JsonElement) entry.getValue()).isJsonObject()) {
                                        JsonObject asJsonObject =
                                                ((JsonElement) entry.getValue()).getAsJsonObject();
                                        if (asJsonObject.has("x")
                                                && asJsonObject.has("y")
                                                && this.isFiniteNumber(asJsonObject.get("x"))
                                                && this.isFiniteNumber(asJsonObject.get("y"))) {
                                            this.positions.put(
                                                    (String) entry.getKey(),
                                                    new float[] {
                                                        asJsonObject.get("x").getAsFloat(),
                                                        asJsonObject.get("y").getAsFloat()
                                                    });
                                        }
                                    }
                                }
                            }

                            this.presets.clear();
                            if (jsonobject.has("configs")
                                    && jsonobject.get("configs").isJsonArray()) {
                                for (JsonElement jsonElement :
                                        jsonobject.getAsJsonArray("configs")) {
                                    if (jsonElement.isJsonObject()) {
                                        JsonObject asJsonObjectValue =
                                                jsonElement.getAsJsonObject();
                                        if (asJsonObjectValue.has("name")
                                                && this.isString(asJsonObjectValue.get("name"))
                                                && asJsonObjectValue.has("data")
                                                && asJsonObjectValue.get("data").isJsonObject()) {
                                            JsonObject data =
                                                    asJsonObjectValue.getAsJsonObject("data");
                                            if (this.validateConfig(data)) {
                                                this.presets.put(
                                                        asJsonObjectValue.get("name").getAsString(),
                                                        gson.toJson((JsonElement) data));
                                            }
                                        }
                                    }
                                }
                            }

                            if (jsonobject.has("active")
                                    && jsonobject.get("active").isJsonObject()
                                    && this.validateConfig(jsonobject.getAsJsonObject("active"))) {
                                this.applyModules(
                                        jsonobject
                                                .getAsJsonObject("active")
                                                .getAsJsonObject("modules"));
                            }

                            this.restorePositions();
                            this.activeConfig = this.serializeModules();
                            return true;
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                }
            } catch (RuntimeException | IOException ioexception) {
                return false;
            }
        }
    }

    private String serializeModules() {
        JsonObject jsonobject = new JsonObject();
        jsonobject.addProperty("format", "x7Qm2");
        jsonobject.addProperty("version", 1);
        JsonObject jsonObject = new JsonObject();

        for (Module module : Gooba.getInstance().getModuleRegistry().values()) {
            JsonObject jsonObjectValue = new JsonObject();
            jsonObjectValue.addProperty("enabled", module.isEnabled());
            jsonObjectValue.addProperty("key", module.getKey());
            JsonObject jsonObject2 = new JsonObject();

            for (Setting setting : module.getSettings()) {
                if (setting != module.keybind && !(setting instanceof PositionSetting)) {
                    this.writeSetting(jsonObject2, setting);
                }
            }

            jsonObjectValue.add("settings", jsonObject2);
            jsonObject.add(module.getName(), jsonObjectValue);
        }

        jsonobject.add("modules", jsonObject);
        return gson.toJson((JsonElement) jsonobject);
    }

    private void restorePositions() {
        for (Module module : Gooba.getInstance().getModuleRegistry().values()) {
            for (Setting setting : module.getSettings()) {
                if (setting instanceof PositionSetting) {
                    PositionSetting positionSetting2 = (PositionSetting) setting;
                    Map mapx = this.positions;
                    String name = module.getName();
                    String nameValue = setting.getName();
                    String name2 = name;
                    float[] afloat = (float[]) mapx.get(name2 + "\u0000" + nameValue);
                    if (afloat != null) {
                        positionSetting2.position.set(afloat[0], afloat[1]);
                        positionSetting2.targetPosition.set(afloat[0], afloat[1]);
                        positionSetting2.xAnimation.snapTo((double) afloat[0]);
                        positionSetting2.yAnimation.snapTo((double) afloat[1]);
                    }
                }
            }
        }
    }

    private boolean isNumber(JsonElement jsonelement) {
        return jsonelement != null
                && jsonelement.isJsonPrimitive()
                && jsonelement.getAsJsonPrimitive().isNumber();
    }

    public synchronized Map<String, String> getPresets() {
        return new LinkedHashMap<>(this.presets);
    }

    private boolean validateSetting(Setting<?> setting, JsonElement jsonelement) {
        if (setting instanceof PositionSetting) {
            if (!jsonelement.isJsonObject()) {
                return false;
            } else {
                JsonObject jsonobject = jsonelement.getAsJsonObject();
                return jsonobject.has("x")
                        && jsonobject.has("y")
                        && this.isFiniteNumber(jsonobject.get("x"))
                        && this.isFiniteNumber(jsonobject.get("y"));
            }
        } else if (setting instanceof MultiBooleanSetting multiBooleanSetting) {
            if (!jsonelement.isJsonObject()) {
                return false;
            } else {
                JsonObject asJsonObject = jsonelement.getAsJsonObject();

                for (BooleanSetting booleanSetting :
                        (Iterable<BooleanSetting>) (Iterable) multiBooleanSetting.getOptions()) {
                    String text = booleanSetting.getName().toLowerCase();
                    if (asJsonObject.has(text) && !this.isBoolean(asJsonObject.get(text))) {
                        return false;
                    }
                }

                return true;
            }
        } else if (setting instanceof StringListSetting) {
            JsonElement jsonelementValue = jsonelement;
            if (jsonelement.isJsonObject()) {
                JsonObject asJsonObjectValue = jsonelement.getAsJsonObject();
                if (!asJsonObjectValue.has("blocks")
                        || !asJsonObjectValue.has("colors")
                        || !asJsonObjectValue.get("colors").isJsonObject()) {
                    return false;
                }

                jsonelementValue = asJsonObjectValue.get("blocks");

                for (Entry entry : asJsonObjectValue.getAsJsonObject("colors").entrySet()) {
                    if (StringListSetting.normalizeBlockId((String) entry.getKey()) == null
                            || !this.isNumber((JsonElement) entry.getValue())) {
                        return false;
                    }
                }
            }

            if (!jsonelementValue.isJsonArray()) {
                return false;
            } else {
                for (JsonElement jsonelement6 : jsonelementValue.getAsJsonArray()) {
                    if (!this.isString(jsonelement6)) {
                        return false;
                    }
                }

                return true;
            }
        } else if (setting instanceof BlockListSetting) {
            if (!jsonelement.isJsonArray()) {
                return false;
            } else {
                for (JsonElement jsonElement : jsonelement.getAsJsonArray()) {
                    if (!jsonElement.isJsonObject()) {
                        return false;
                    }

                    JsonObject asJsonObject2 = jsonElement.getAsJsonObject();
                    if (!asJsonObject2.has("block")
                            || !this.isString(asJsonObject2.get("block"))
                            || !asJsonObject2.has("color")
                            || !this.isNumber(asJsonObject2.get("color"))) {
                        return false;
                    }
                }

                return true;
            }
        } else if (!(setting instanceof MatrixSetting matrixSetting)) {
            if (setting instanceof BooleanSetting || setting instanceof ConditionalBooleanSetting) {
                return this.isBoolean(jsonelement);
            } else if (setting instanceof SliderSetting sliderSetting2) {
                if (!this.isFiniteNumber(jsonelement)) {
                    return false;
                } else {
                    float jsonelement5 = jsonelement.getAsFloat();
                    return jsonelement5 >= sliderSetting2.minValue
                            && jsonelement5 <= sliderSetting2.maxValue;
                }
            } else if (setting instanceof ModeSetting modeSetting2) {
                return this.isAllowedOption(jsonelement, modeSetting2.modes);
            } else if (setting instanceof OptionSetting optionSetting) {
                return this.isAllowedOption(jsonelement, optionSetting.options);
            } else if (setting instanceof KeybindSetting || setting instanceof ColorSetting) {
                return this.isNumber(jsonelement);
            } else if (setting instanceof TextSetting) {
                return this.isString(jsonelement);
            } else {
                return setting instanceof ButtonSetting ? this.isString(jsonelement) : false;
            }
        } else if (jsonelement.isJsonArray()
                && jsonelement.getAsJsonArray().size() <= matrixSetting.size) {
            for (JsonElement jsonelement7 : jsonelement.getAsJsonArray()) {
                if (!this.isString(jsonelement7)) {
                    return false;
                }

                String textValue = jsonelement7.getAsString();
                if (textValue.length() > matrixSetting.size || !textValue.matches("[01]*")) {
                    return false;
                }
            }

            return true;
        } else {
            return false;
        }
    }

    public synchronized void saveState() {
        this.capturePositions();
        this.activeConfig = this.serializeModules();
        this.writeState();
    }
}
