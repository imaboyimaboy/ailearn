package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ElapsedClock {
    public long startedAtMillis = System.currentTimeMillis();

    public ElapsedClock() {
        this.reset();
    }

    public void reset() {
        this.startedAtMillis = System.currentTimeMillis();
    }
}
