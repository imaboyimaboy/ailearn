package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class ThemeColors {
    public static float getOpacity() {
        return ThemeConfig.getInstance().getActiveTheme().getValue(0);
    }

    public static int textWithOpacity(float opacity) {
        return ColorUtils.withOpacity(
                ThemeConfig.getInstance().getActiveTheme().getColor(3), opacity);
    }

    public static boolean isDistortionEnabled() {
        return ThemeConfig.getInstance().getActiveTheme().isEffectEnabled(1);
    }

    public static int getBlurRadius() {
        return Math.round(ThemeConfig.getInstance().getActiveTheme().getValue(1));
    }

    public static int outlineWithOpacity(float factor) {
        return ColorUtils.scaleAlpha(
                ThemeConfig.getInstance().getActiveTheme().getColor(2), factor);
    }

    private ThemeColors() {}

    public static int getElementColor() {
        return ColorUtils.themeElement();
    }

    public static int getBackgroundColor() {
        return ThemeConfig.getInstance().getActiveTheme().getColor(1);
    }

    public static int getAccentColor() {
        return ColorUtils.themeAccent();
    }

    public static int secondaryTextWithOpacity(float opacity) {
        return ColorUtils.withOpacity(
                ThemeConfig.getInstance().getActiveTheme().getColor(4), opacity);
    }
}
