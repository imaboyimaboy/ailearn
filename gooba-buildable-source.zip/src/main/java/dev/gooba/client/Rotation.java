package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class Rotation implements MinecraftAccess {
    public float yaw;

    public float pitch;

    public float angularDistanceTo(Rotation rotation) {
        float f = MathHelper.wrapDegrees(rotation.yaw - this.yaw);
        float f1 = rotation.pitch - this.pitch;
        return (float) Math.hypot((double) Math.abs(f), (double) Math.abs(f1));
    }

    public float getYaw() {
        return this.yaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public static float getCameraYaw() {
        float yaw = client.gameRenderer.getCamera().getYaw();
        return client.options.getPerspective().isFrontView()
                ? MathHelper.wrapDegrees(yaw + (float) 180)
                : MathHelper.wrapDegrees(yaw + (float) 0);
    }

    public Rotation(Entity entity) {
        this.yaw = entity.getYaw();
        this.pitch = entity.getPitch();
    }

    public static float getCameraPitch() {
        return client.options.getPerspective().isFrontView()
                ? (float) -1 * client.gameRenderer.getCamera().getPitch()
                : (float) 1 * client.gameRenderer.getCamera().getPitch();
    }

    public Rotation(float yawValue, float pitchValue) {
        this.yaw = yawValue;
        this.pitch = pitchValue;
    }
}
