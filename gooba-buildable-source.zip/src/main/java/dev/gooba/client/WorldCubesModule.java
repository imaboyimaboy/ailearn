package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.function.Function;

@ModuleInfo(
        name = "World Cubes",
        desc = "Draws a glowing configurable grid across the world",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class WorldCubesModule extends Module {
    private static final RenderPipeline GRID_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "world_cubes_grid"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.DEBUG_LINES)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    private int previousZ;
    private static final RenderLayer GRID_LAYER =
            RenderLayer.of(
                    "world_cubes_lines",
                    RenderSetup.builder(WorldCubesModule.GRID_PIPELINE)
                            .expectedBufferSize(16384)
                            .build());
    private final BufferAllocator bufferAllocator;
    public static final Function<Identifier, RenderLayer> textureLayer =
            Util.memoize(
                    identifier -> {
                        RenderSetup rendersetup =
                                RenderSetup.builder(WorldCubesModule.GLOW_PIPELINE)
                                        .texture("Sampler0", identifier)
                                        .translucent()
                                        .expectedBufferSize(1536)
                                        .build();
                        return RenderLayer.of("wtex", rendersetup);
                    });
    private int currentZ;
    public SliderSetting glowSizeSetting;
    private final EasingAnimation transitionAnimation;
    private boolean needsInitialization;
    public static final RenderPipeline GLOW_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation("pipeline/wtex")
                            .withVertexShader("core/position_tex_color")
                            .withFragmentShader("core/position_tex_color")
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withCull(false)
                            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
                            .build());
    private int currentY;
    public ModeSetting colorModeSetting =
            new ModeSetting(this, "Color Mode", new String[] {"Theme", "Custom"});
    public SliderSetting glowBrightnessSetting;
    public SliderSetting heightCellsSetting;
    private int currentX;
    public SliderSetting radiusCellsSetting;
    public SliderSetting lineOpacitySetting;
    private int previousX;
    private int previousY;
    public ColorSetting colorSetting =
            new ColorSetting(this, "Color", -16711681)
                    .visibleWhen(() -> this.colorModeSetting.isSelected("Custom"));
    public BooleanSetting cornerGlowSetting;

    private void drawGrid(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            Vec3d vec3d,
            int i,
            int j,
            int k,
            int l,
            int i1,
            int j1,
            int k1,
            int l1,
            int i2) {
        if (k1 > 0) {
            int j2 = i - l1 * 12;
            int k2 = i + l1 * 12;
            int l2 = k - l1 * 12;
            int i31 = k + l1 * 12;
            int j3 = j - (i2 - 1) * 12;
            int k3 = j + i2 * 12;

            for (int l3 = j2; l3 <= k2; l3 += 12) {
                for (int i41 = l2; i41 <= i31; i41 += 12) {
                    float f = (float) ((double) l3 - vec3d.x);
                    float f1 = (float) ((double) i41 - vec3d.z);
                    vertexconsumer
                            .vertex(matrix4f, f, (float) ((double) j3 - vec3d.y), f1)
                            .color(l, i1, j1, k1);
                    vertexconsumer
                            .vertex(matrix4f, f, (float) ((double) k3 - vec3d.y), f1)
                            .color(l, i1, j1, k1);
                }
            }

            for (int j4 = j3; j4 <= k3; j4 += 12) {
                float f2 = (float) ((double) j4 - vec3d.y);

                for (int l4 = l2; l4 <= i31; l4 += 12) {
                    float f4 = (float) ((double) l4 - vec3d.z);
                    vertexconsumer
                            .vertex(matrix4f, (float) ((double) j2 - vec3d.x), f2, f4)
                            .color(l, i1, j1, k1);
                    vertexconsumer
                            .vertex(matrix4f, (float) ((double) k2 - vec3d.x), f2, f4)
                            .color(l, i1, j1, k1);
                }
            }

            for (int k4 = j3; k4 <= k3; k4 += 12) {
                float f3 = (float) ((double) k4 - vec3d.y);

                for (int i51 = j2; i51 <= k2; i51 += 12) {
                    float f5 = (float) ((double) i51 - vec3d.x);
                    vertexconsumer
                            .vertex(matrix4f, f5, f3, (float) ((double) l2 - vec3d.z))
                            .color(l, i1, j1, k1);
                    vertexconsumer
                            .vertex(matrix4f, f5, f3, (float) ((double) i31 - vec3d.z))
                            .color(l, i1, j1, k1);
                }
            }
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null) {
            int currentXValue = cellOrigin(client.player.getX());
            int currentYValue = cellOrigin(client.player.getY());
            int currentZValue = cellOrigin(client.player.getZ());
            if (this.needsInitialization) {
                this.currentX = currentXValue;
                this.currentY = currentYValue;
                this.currentZ = currentZValue;
                this.previousX = currentXValue;
                this.previousY = currentYValue;
                this.previousZ = currentZValue;
                this.transitionAnimation.snapTo(1.0);
                this.needsInitialization = false;
            } else if (currentXValue != this.currentX
                    || currentYValue != this.currentY
                    || currentZValue != this.currentZ) {
                this.previousX = this.currentX;
                this.previousY = this.currentY;
                this.previousZ = this.currentZ;
                this.currentX = currentXValue;
                this.currentY = currentYValue;
                this.currentZ = currentZValue;
                this.transitionAnimation.snapTo(0.0);
                this.transitionAnimation.animateTo(1.0, 0.25, Easings.OUT_QUAD);
            }

            this.transitionAnimation.update();
            float floatValue = this.transitionAnimation.getFloatValue();
            int l = this.gridColor();
            int i1 = l >> 16 & 0xFF;
            int j1 = l >> 8 & 0xFF;
            int k1 = l & 0xFF;
            float f1 = this.lineOpacitySetting.getFloat() * 255.0F;
            int l1 = this.radiusCellsSetting.getFloat().intValue();
            int i2 = this.heightCellsSetting.getFloat().intValue();
            Vec3d vec3d = client.gameRenderer.getCamera().getCameraPos();
            MatrixStack matrixstack = render3DEvent.getMatrixStack();
            Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
            Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);
            VertexConsumer vertexconsumer = immediate.getBuffer(GRID_LAYER);
            if (floatValue < 0.999F) {
                int j2 = (int) (f1 * (1.0F - floatValue));
                this.drawGrid(
                        vertexconsumer,
                        matrix4f,
                        vec3d,
                        this.previousX,
                        this.previousY,
                        this.previousZ,
                        i1,
                        j1,
                        k1,
                        j2,
                        l1,
                        i2);
            }

            int l2 = (int) (f1 * floatValue);
            this.drawGrid(
                    vertexconsumer,
                    matrix4f,
                    vec3d,
                    this.currentX,
                    this.currentY,
                    this.currentZ,
                    i1,
                    j1,
                    k1,
                    l2,
                    l1,
                    i2);
            if (this.cornerGlowSetting.isOn()) {
                float f2 = this.glowSizeSetting.getFloat();
                float f3 = this.glowBrightnessSetting.getFloat();
                int k2 = Math.min(255, (int) (15.0F * floatValue * f3));
                this.drawCornerGlows(
                        immediate,
                        textureLayer.apply(ParticlesModule.ParticleType.BLOOM.getTexture()),
                        matrix4f,
                        vec3d,
                        this.currentX,
                        this.currentY,
                        this.currentZ,
                        i1,
                        j1,
                        k1,
                        k2,
                        f2 * 2.0F,
                        l1,
                        i2);
                k2 = Math.min(255, (int) (255.0F * floatValue * f3));
                this.drawCornerGlows(
                        immediate,
                        textureLayer.apply(ParticlesModule.ParticleType.CIRCLE.getTexture()),
                        matrix4f,
                        vec3d,
                        this.currentX,
                        this.currentY,
                        this.currentZ,
                        i1,
                        j1,
                        k1,
                        k2,
                        f2,
                        l1,
                        i2);
            }

            immediate.draw();
        }
    }

    private static int cellOrigin(double d0) {
        return (int) Math.floor(d0 / 12.0) * 12;
    }

    public WorldCubesModule() {
        this.radiusCellsSetting =
                new SliderSetting(this, "Radius (cells)", 4.0F, 1.0F, 30.0F, 1.0F);
        this.heightCellsSetting =
                new SliderSetting(this, "Height (cells)", 2.0F, 1.0F, 20.0F, 1.0F);
        this.lineOpacitySetting =
                new SliderSetting(this, "Line Opacity", 0.22F, 0.04F, 1.0F, 0.02F);
        this.cornerGlowSetting = new BooleanSetting(this, "Corner Glow", true);
        this.glowSizeSetting =
                new SliderSetting(this, "Glow size", 0.08F, 0.02F, 1.0F, 0.02F)
                        .visibleWhen(() -> this.cornerGlowSetting.isOn());
        this.glowBrightnessSetting =
                new SliderSetting(this, "Glow brightness", 1.8F, 0.5F, 4.0F, 0.1F)
                        .visibleWhen(() -> this.cornerGlowSetting.isOn());
        this.transitionAnimation = new EasingAnimation();
        this.needsInitialization = true;
        this.bufferAllocator = new BufferAllocator(262144);
    }

    public int gridColor() {
        return this.colorModeSetting.isSelected("Theme")
                ? ColorUtils.hudAccent()
                : this.colorSetting.getColor();
    }

    private void drawCornerGlows(
            Immediate immediate,
            RenderLayer renderlayer,
            Matrix4f matrix4f,
            Vec3d vec3d,
            int i,
            int j,
            int k,
            int l,
            int i1,
            int j1,
            int k1,
            float f,
            int l1,
            int i2) {
        if (k1 > 0) {
            int j2 = i - l1 * 12;
            int k2 = i + l1 * 12;
            int l2 = k - l1 * 12;
            int i31 = k + l1 * 12;
            int j3 = j - (i2 - 1) * 12;
            int k3 = j + i2 * 12;
            Camera camera = client.gameRenderer.getCamera();
            Quaternionf quaternionf = camera.getRotation();
            Vector3f vector3f = new Vector3f(-f, -f, 0.0F).rotate(quaternionf);
            Vector3f vector3f1 = new Vector3f(f, -f, 0.0F).rotate(quaternionf);
            Vector3f vector3f2 = new Vector3f(f, f, 0.0F).rotate(quaternionf);
            Vector3f vector3f3 = new Vector3f(-f, f, 0.0F).rotate(quaternionf);
            float f1 = (float) Math.toRadians((double) camera.getYaw());
            float f2 = (float) Math.toRadians((double) camera.getPitch());
            float f3 = (float) Math.cos((double) f2);
            float f4 = (float) (-Math.sin((double) f1) * (double) f3);
            float f5 = (float) (-Math.sin((double) f2));
            float f6 = (float) (Math.cos((double) f1) * (double) f3);
            VertexConsumer vertexconsumer = immediate.getBuffer(renderlayer);

            for (int l3 = j2; l3 <= k2; l3 += 12) {
                for (int i41 = j3; i41 <= k3; i41 += 12) {
                    for (int j4 = l2; j4 <= i31; j4 += 12) {
                        float f7 = (float) ((double) l3 - vec3d.x);
                        float f8 = (float) ((double) i41 - vec3d.y);
                        float f9 = (float) ((double) j4 - vec3d.z);
                        if (!(f7 * f4 + f8 * f5 + f9 * f6 < -f * 2.0F)) {
                            vertexconsumer
                                    .vertex(
                                            matrix4f,
                                            f7 + vector3f.x,
                                            f8 + vector3f.y,
                                            f9 + vector3f.z)
                                    .color(l, i1, j1, k1)
                                    .texture(0.0F, 1.0F)
                                    .overlay(OverlayTexture.DEFAULT_UV)
                                    .light(15728880)
                                    .normal(0.0F, 0.0F, 1.0F);
                            vertexconsumer
                                    .vertex(
                                            matrix4f,
                                            f7 + vector3f1.x,
                                            f8 + vector3f1.y,
                                            f9 + vector3f1.z)
                                    .color(l, i1, j1, k1)
                                    .texture(1.0F, 1.0F)
                                    .overlay(OverlayTexture.DEFAULT_UV)
                                    .light(15728880)
                                    .normal(0.0F, 0.0F, 1.0F);
                            vertexconsumer
                                    .vertex(
                                            matrix4f,
                                            f7 + vector3f2.x,
                                            f8 + vector3f2.y,
                                            f9 + vector3f2.z)
                                    .color(l, i1, j1, k1)
                                    .texture(1.0F, 0.0F)
                                    .overlay(OverlayTexture.DEFAULT_UV)
                                    .light(15728880)
                                    .normal(0.0F, 0.0F, 1.0F);
                            vertexconsumer
                                    .vertex(
                                            matrix4f,
                                            f7 + vector3f3.x,
                                            f8 + vector3f3.y,
                                            f9 + vector3f3.z)
                                    .color(l, i1, j1, k1)
                                    .texture(0.0F, 0.0F)
                                    .overlay(OverlayTexture.DEFAULT_UV)
                                    .light(15728880)
                                    .normal(0.0F, 0.0F, 1.0F);
                        }
                    }
                }
            }
        }
    }

    @Override
    protected void onEnable() {
        this.needsInitialization = true;
    }
}
