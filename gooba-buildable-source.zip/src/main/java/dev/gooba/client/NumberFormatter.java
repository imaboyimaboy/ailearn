package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Locale;

@Environment(EnvType.CLIENT)
public final class NumberFormatter {

    public static String formatCompact(double d0) {
        if (d0 >= 1.0E9) {
            String text = formatDecimal(d0 / 1.0E9);
            return text + "B";
        } else if (d0 >= 1000000.0) {
            String textValue = formatDecimal(d0 / 1000000.0);
            return textValue + "M";
        } else if (d0 >= 1000.0) {
            String text2 = formatDecimal(d0 / 1000.0);
            return text2 + "k";
        } else {
            return formatDecimal(d0);
        }
    }

    private NumberFormatter() {}

    private static String formatDecimal(double d0) {
        if (d0 == Math.floor(d0) && !Double.isInfinite(d0)) {
            return Long.toString((long) d0);
        } else {
            String text = String.format(Locale.ROOT, "%.2f", d0);
            if (text.contains(".")) {
                text = text.replaceAll("0+$", "").replaceAll("\\.$", "");
            }

            return text;
        }
    }

    public static Double parseCompact(String text) {
        if (text == null) {
            return null;
        } else {
            String textValue = text.trim().replace("$", "").replace(",", "").replace(" ", "");
            if (textValue.isEmpty()) {
                return null;
            } else {
                double d0 = 1.0;
                char c0 = Character.toLowerCase(textValue.charAt(textValue.length() - 1));
                if (c0 == 'k') {
                    d0 = 1000.0;
                } else if (c0 == 'm') {
                    d0 = 1000000.0;
                } else if (c0 == 'b') {
                    d0 = 1.0E9;
                }

                if (d0 != 1.0) {
                    textValue = textValue.substring(0, textValue.length() - 1);
                }

                try {
                    return Double.parseDouble(textValue) * d0;
                } catch (NumberFormatException numberformatexception) {
                    return null;
                }
            }
        }
    }
}
