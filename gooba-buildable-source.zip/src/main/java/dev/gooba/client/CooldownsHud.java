package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

@Environment(EnvType.CLIENT)
public class CooldownsHud implements MinecraftAccess {
    private final Map<Identifier, CooldownsHud.CooldownData> cooldowns;
    private final EasingAnimation visibilityAnimation = createAnimation(0.0F);
    private final EasingAnimation widthAnimation = new EasingAnimation().resetValue(0.0F);
    private final EasingAnimation heightAnimation = new EasingAnimation().resetValue(15.0F);

    public void render(
            PositionSetting positionSetting2, HUDModule hUDModule, Render2DEvent render2DEvent) {
        if (client.player != null) {
            float f = hUDModule.hudSizeSetting.getFloat();
            float innerX = positionSetting2.position.x;
            float innerY = positionSetting2.position.y;
            this.cooldowns.values().forEach(cqq$cooldowndata3 -> cqq$cooldowndata3.active = false);
            ItemCooldownManager itemcooldownmanager = client.player.getItemCooldownManager();

            for (Entry entry : itemcooldownmanager.entries.entrySet()) {
                Item item = Registries.ITEM.get((Identifier) entry.getKey());
                CooldownsHud.CooldownData cooldownDataValue =
                        this.cooldowns.computeIfAbsent(
                                (Identifier) entry.getKey(),
                                identifier -> new CooldownsHud.CooldownData(item));
                cooldownDataValue.item = item;
                cooldownDataValue.remainingTicks =
                        Math.max(
                                0,
                                ((net.minecraft.entity.player.ItemCooldownManager.Entry)
                                                        entry.getValue())
                                                .endTick
                                        - itemcooldownmanager.tick);
                cooldownDataValue.remainingFraction =
                        Math.max(
                                0.0F,
                                Math.min(
                                        1.0F,
                                        itemcooldownmanager.getCooldownProgress(
                                                item.getDefaultStack(),
                                                render2DEvent.getPartialTicks())));
                if (cooldownDataValue.remainingTicks > 0) {
                    cooldownDataValue.active = true;
                } else {
                    cooldownDataValue.active = false;
                }
            }

            ArrayList<CooldownsHud.CooldownData> arraylist =
                    new ArrayList<>(this.cooldowns.values());
            arraylist.sort(
                    Comparator.comparing(
                            cqq$cooldowndata3 -> itemName(cqq$cooldowndata3.item),
                            String.CASE_INSENSITIVE_ORDER));
            float f36 = 0.0F;
            float f37 =
                    16.0F
                            + Fonts.INTER_SEMIBOLD.measureWidth("  ", 7.5F)
                            + Fonts.INTER_SEMIBOLD.measureVisibleWidth("Cooldowns", 7.5F);
            float f38 = 0.0F;
            boolean flag = false;

            for (CooldownsHud.CooldownData cooldownData3 :
                    (Iterable<CooldownsHud.CooldownData>) (Iterable) arraylist) {
                float f3 =
                        cooldownData3.visibilityAnimation.approach(
                                cooldownData3.active ? 1.0F : 0.0F, 2.5F);
                if (cooldownData3.active) {
                    flag = true;
                }

                if (cooldownData3.active || !(f3 <= 0.001F)) {
                    f36 += 14.0F * f3;
                    float f4 =
                            Fonts.INTER_SEMIBOLD.measureVisibleWidth(
                                    itemName(cooldownData3.item), 7.2F);
                    float f5 =
                            Fonts.INTER_SEMIBOLD.measureVisibleWidth(
                                    formatDuration(cooldownData3.remainingTicks), 7.2F);
                    float f6 =
                            22.0F
                                    + f4
                                    + 0.5F
                                    + 8.0F
                                    + f5
                                    + Fonts.INTER_SEMIBOLD.measureWidth("  ", 7.2F)
                                    + 6.0F;
                    f38 = Math.max(f38, f6);
                }
            }

            float target = Math.max(f37, f38);
            float targetValue = 15.0F + f36;
            boolean flag1;
            flag1 =
                    !(!hUDModule.alwaysShowSetting.isOn()
                            && !flag
                            && !(f36 > 0.001F)
                            && !(client.currentScreen instanceof ChatScreen));

            if (flag1 && this.visibilityAnimation.getFloatValue() <= 0.001F) {
                this.widthAnimation.resetValue(target);
                this.heightAnimation.resetValue(targetValue);
            }

            float factor = animate(this.visibilityAnimation, flag1 ? 1.0F : 0.0F);
            if (!flag1 && !(factor > 0.01F)) {
                positionSetting2.visible = false;
            } else {
                positionSetting2.visible = true;
            }

            if (factor <= 0.01F) {
                this.cooldowns
                        .entrySet()
                        .removeIf(
                                entry1 ->
                                        !entry1.getValue().active
                                                && entry1.getValue()
                                                                .visibilityAnimation
                                                                .getFloatValue()
                                                        <= 0.001F);
                positionSetting2.size.set(f37 * f, 15.0F * f);
            } else {
                float f42 = this.widthAnimation.approach(target, 2.5F) * f;
                float f43 = this.heightAnimation.approach(targetValue, 2.5F) * f;
                float height = 15.0F * f;
                float f8 = 4.0F * f;
                String stringValue = "U";
                float size = 7.5F * f;
                float f10 = Fonts.INTER_SEMIBOLD.measureWidth("  ", 7.5F * f);
                float width7 =
                        16.0F * f
                                + f10
                                + Fonts.INTER_SEMIBOLD.measureVisibleWidth("Cooldowns", 7.5F * f);
                hUDModule.drawBackground(innerX, innerY, width7, height, f8, factor);
                float f12 = innerX + 4.0F * f;
                Font font = Fonts.GOOBA_ICONS;
                float f44 = Fonts.GOOBA_ICONS.centerTextX(stringValue, f12, 8.0F * f, size);
                float f45 = Fonts.GOOBA_ICONS.centerTextY(stringValue, innerY, height, size);
                hUDModule.getAccentColor(factor);
                font.drawText(stringValue, f44, f45, size);
                float f13 = f12 + 8.0F * f + f10;
                float width = Fonts.INTER_SEMIBOLD.measureVisibleWidth("Cooldowns", 7.5F * f);
                float f15 = Fonts.INTER_SEMIBOLD.centerTextX("Cooldowns", f13, width, 7.5F * f);
                float f16 = centerTextY(innerY, height, 7.5F * f);
                font = Fonts.INTER_SEMIBOLD;
                float sizeValue = 7.5F * f;
                ColorUtils.multiplyAlpha(-657931, factor);
                font.drawText("Cooldowns", f15, f16, sizeValue);
                float innerYValue = innerY + height;

                for (CooldownsHud.CooldownData cooldownData4 :
                        (Iterable<CooldownsHud.CooldownData>) (Iterable) arraylist) {
                    float floatValue = cooldownData4.visibilityAnimation.getFloatValue();
                    if (!(floatValue <= 0.001F)) {
                        float f19 = 13.5F * floatValue * f;
                        float factorValue = factor * floatValue;
                        innerYValue += 0.5F * floatValue * f;
                        float f21 = (1.0F - floatValue) * 8.0F * f;
                        innerX += f21;
                        float f22 = innerYValue + 13.5F * f * 0.5F;
                        String string = itemName(cooldownData4.item);
                        String string2 = formatDuration(cooldownData4.remainingTicks);
                        float size3 = 7.2F * f;
                        float width8 = 13.5F * f;
                        float innerXValue = innerX + width8 + 0.5F * f;
                        float widthValue = Fonts.INTER_SEMIBOLD.measureVisibleWidth(string, size3);
                        float width9 = 8.0F * f + widthValue;
                        float innerX2 = innerXValue + width9 + 0.5F * f;
                        float width11 = Fonts.INTER_SEMIBOLD.measureVisibleWidth(string2, size3);
                        float f30 = Fonts.INTER_SEMIBOLD.measureWidth("  ", size3);
                        float width10 = 8.0F * f + width11 + f30 + 6.0F * f;
                        hUDModule.drawBackground(
                                innerX, innerYValue, width8, 13.5F * f, f8, factorValue);
                        hUDModule.drawBackground(
                                innerXValue, innerYValue, width9, 13.5F * f, f8, factorValue);
                        hUDModule.drawBackground(
                                innerX2, innerYValue, width10, 13.5F * f, f8, factorValue);
                        ItemStack itemstack = cooldownData4.item.getDefaultStack();
                        ItemIconRenderer.drawCentered(
                                render2DEvent.getDrawContext(),
                                itemstack,
                                innerX + width8 * 0.5F,
                                f22,
                                0.5F * f * Math.max(0.35F, floatValue),
                                factorValue);
                        float f32 = centerTextY(innerYValue, 13.5F * f, size3);
                        float f33 =
                                Fonts.INTER_SEMIBOLD.centerTextX(
                                        string, innerXValue + 4.0F * f, widthValue, size3);
                        font = Fonts.INTER_SEMIBOLD;
                        ColorUtils.multiplyAlpha(-657931, factorValue);
                        font.drawText(string, f33, f32, size3);
                        float centerX = innerX2 + width10 - 7.0F * f;
                        float f35 =
                                Fonts.INTER_SEMIBOLD.centerTextX(
                                        string2, innerX2 + 4.0F * f, width11, size3);
                        font = Fonts.INTER_SEMIBOLD;
                        ColorUtils.multiplyAlpha(-657931, factorValue);
                        font.drawText(string2, f35, f32, size3);
                        Gooba.getInstance()
                                .getHudManager()
                                .getCircleData()
                                .drawProgressArc(
                                        centerX,
                                        f22 - 0.3F * f,
                                        3.0F * f,
                                        1.0F * f,
                                        1.0F,
                                        ColorUtils.multiplyAlpha(-13092808, factorValue));
                        Gooba.getInstance()
                                .getHudManager()
                                .getCircleData()
                                .drawProgressArc(
                                        centerX,
                                        f22 - 0.3F * f,
                                        3.0F * f,
                                        1.0F * f,
                                        cooldownData4.remainingFraction,
                                        hUDModule.getAccentColor(factorValue));
                        innerX -= f21;
                        innerYValue += f19;
                    }
                }

                this.cooldowns
                        .entrySet()
                        .removeIf(
                                entry1 ->
                                        !entry1.getValue().active
                                                && entry1.getValue()
                                                                .visibilityAnimation
                                                                .getFloatValue()
                                                        <= 0.001F);
                positionSetting2.size.set(f42, f43);
            }
        }
    }

    private static float centerTextY(float f, float height, float size) {
        return Fonts.INTER_SEMIBOLD.centerTextY("Ag09:", f, height, size) + 0.45F * size / 7.2F;
    }

    private static String itemName(Item item) {
        String stringValue = item.getName().getString().toLowerCase(Locale.ROOT);
        String string;
        if (stringValue.isEmpty()) {
            string = stringValue;
        } else {
            char c1 = Character.toUpperCase(stringValue.charAt(0));
            String text = stringValue.substring(1);
            char c0 = c1;
            string = c0 + text;
        }

        return string;
    }

    private static EasingAnimation createAnimation(float f) {
        return new EasingAnimation()
                .setCurrentValue((double) f)
                .setStartValue((double) f)
                .setTargetValue((double) f)
                .setDurationMillis(1.0);
    }

    public CooldownsHud() {
        this.cooldowns = new LinkedHashMap<>();
    }

    private static String formatDuration(int i) {
        int j = Math.max(0, (i + 19) / 20);
        return String.format(Locale.ROOT, "%d:%02d", j / 60, j % 60);
    }

    private static float animate(EasingAnimation easingAnimation2, float f) {
        easingAnimation2.animateTo((double) f, 0.3F, Easings.OUT_EXPO, true);
        easingAnimation2.update();
        return easingAnimation2.getFloatValue();
    }

    @Environment(EnvType.CLIENT)
    private static class CooldownData {
        private float remainingFraction;
        private Item item;
        private final EasingAnimation visibilityAnimation = new EasingAnimation().resetValue(0.0F);
        private int remainingTicks;
        private boolean active;

        private CooldownData(Item item) {
            this.item = item;
        }
    }
}
