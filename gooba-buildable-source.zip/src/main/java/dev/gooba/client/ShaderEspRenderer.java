package dev.gooba.client;

import com.mojang.blaze3d.textures.GpuTextureView;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;

@Environment(EnvType.CLIENT)
public class ShaderEspRenderer {
    private ShaderEspPipeline pipeline;
    public final ShaderEspPipeline.Params params = new ShaderEspPipeline.Params();
    private static ShaderEspRenderer instance;

    public static ShaderEspRenderer getInstance() {
        if (instance == null) {
            instance = new ShaderEspRenderer();
        }

        return instance;
    }

    public void reset() {
        if (this.pipeline != null) {
            this.pipeline.close();
            this.pipeline = null;
        }
    }

    public ShaderEspRenderer() {
        instance = this;
    }

    public void render(Framebuffer framebuffer, int widthValue, int heightValue) {
        if (framebuffer != null) {
            this.initialize();
            GpuTextureView gputextureview = framebuffer.getColorAttachmentView();
            if (gputextureview != null) {
                Framebuffer framebufferValue = MinecraftClient.getInstance().getFramebuffer();
                if (framebufferValue != null && framebufferValue.getColorAttachmentView() != null) {
                    this.pipeline.render(
                            gputextureview,
                            framebufferValue.getColorAttachmentView(),
                            widthValue,
                            heightValue,
                            this.params);
                }
            }
        }
    }

    private void initialize() {
        if (this.pipeline == null) {
            this.pipeline = new ShaderEspPipeline();
        }
    }
}
