package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImage.Format;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadataNode;
import javax.imageio.stream.ImageInputStream;

@Environment(EnvType.CLIENT)
public class AnimatedGifTexture {
    public AnimatedGifTexture(InputStream input) {
        loadFrames(input);
    }

    private int width;
    private int height;

    private final List<Integer> frameDelays = new ArrayList<>();
    private final List<Identifier> frameTextures = new ArrayList<>();
    private int totalDuration;

    private BufferedImage copyImage(BufferedImage original) {
        BufferedImage copy =
                new BufferedImage(
                        original.getWidth(), original.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = copy.createGraphics();
        graphics.drawImage(original, 0, 0, null);
        graphics.dispose();
        return copy;
    }

    private IIOMetadataNode findMetadata(IIOMetadataNode parent, String name) {
        for (int index = 0; index < parent.getLength(); index++) {
            if (parent.item(index).getNodeName().equalsIgnoreCase(name)) {
                return (IIOMetadataNode) parent.item(index);
            }
            if (parent.item(index) instanceof IIOMetadataNode child) {
                IIOMetadataNode match = findMetadata(child, name);
                if (match != null) return match;
            }
        }
        return null;
    }

    private int readFrameDelay(ImageReader reader, int index) {
        try {
            IIOMetadataNode metadata =
                    (IIOMetadataNode)
                            reader.getImageMetadata(index)
                                    .getAsTree(
                                            reader.getImageMetadata(index)
                                                    .getNativeMetadataFormatName());
            IIOMetadataNode control = findMetadata(metadata, "GraphicControlExtension");
            if (control != null) {
                int centiseconds = Integer.parseInt(control.getAttribute("delayTime"));
                return Math.max(centiseconds * 10, 20);
            }
        } catch (Exception ignored) {
        }
        return 100;
    }

    private void loadFrames(InputStream input) {
        try (ImageInputStream imageInput = ImageIO.createImageInputStream(input)) {
            Iterator<ImageReader> readers = ImageIO.getImageReadersByFormatName("gif");
            if (!readers.hasNext()) return;
            ImageReader reader = readers.next();
            try {
                reader.setInput(imageInput, false);
                int frameCount = reader.getNumImages(true);
                String textureId = UUID.randomUUID().toString().replace("-", "").substring(0, 8);
                IIOMetadataNode streamMetadata = null;
                try {
                    streamMetadata =
                            (IIOMetadataNode)
                                    reader.getStreamMetadata()
                                            .getAsTree(
                                                    reader.getStreamMetadata()
                                                            .getNativeMetadataFormatName());
                } catch (Exception ignored) {
                }
                BufferedImage firstFrame = reader.read(0);
                int canvasWidth = firstFrame.getWidth();
                int canvasHeight = firstFrame.getHeight();
                if (streamMetadata != null) {
                    IIOMetadataNode screen =
                            findMetadata(streamMetadata, "LogicalScreenDescriptor");
                    if (screen != null) {
                        try {
                            canvasWidth =
                                    Integer.parseInt(screen.getAttribute("logicalScreenWidth"));
                        } catch (Exception ignored) {
                        }
                        try {
                            canvasHeight =
                                    Integer.parseInt(screen.getAttribute("logicalScreenHeight"));
                        } catch (Exception ignored) {
                        }
                    }
                }
                width = canvasWidth;
                height = canvasHeight;
                List<int[]> pixels = new ArrayList<>();
                BufferedImage canvas =
                        new BufferedImage(canvasWidth, canvasHeight, BufferedImage.TYPE_INT_ARGB);
                BufferedImage previous = null;
                for (int index = 0; index < frameCount; index++) {
                    BufferedImage frame = index == 0 ? firstFrame : reader.read(index);
                    IIOMetadataNode metadata = null;
                    try {
                        metadata =
                                (IIOMetadataNode)
                                        reader.getImageMetadata(index)
                                                .getAsTree(
                                                        reader.getImageMetadata(index)
                                                                .getNativeMetadataFormatName());
                    } catch (Exception ignored) {
                    }
                    int left = 0;
                    int top = 0;
                    String disposal = "none";
                    if (metadata != null) {
                        IIOMetadataNode descriptor = findMetadata(metadata, "ImageDescriptor");
                        if (descriptor != null) {
                            try {
                                left =
                                        Integer.parseInt(
                                                descriptor.getAttribute("imageLeftPosition"));
                            } catch (Exception ignored) {
                            }
                            try {
                                top = Integer.parseInt(descriptor.getAttribute("imageTopPosition"));
                            } catch (Exception ignored) {
                            }
                        }
                        IIOMetadataNode control = findMetadata(metadata, "GraphicControlExtension");
                        if (control != null) disposal = control.getAttribute("disposalMethod");
                    }
                    if ("restoreToPrevious".equalsIgnoreCase(disposal))
                        previous = copyImage(canvas);
                    Graphics2D graphics = canvas.createGraphics();
                    graphics.drawImage(frame, left, top, null);
                    graphics.dispose();
                    pixels.add(
                            canvas.getRGB(0, 0, canvasWidth, canvasHeight, null, 0, canvasWidth));
                    frameDelays.add(readFrameDelay(reader, index));
                    frameTextures.add(
                            Identifier.of("avdeeeeeva", "gif/" + textureId + "/" + index));
                    Graphics2D cleanup = canvas.createGraphics();
                    cleanup.setComposite(AlphaComposite.Clear);
                    if ("restoreToBackgroundColor".equalsIgnoreCase(disposal)) {
                        cleanup.fillRect(left, top, frame.getWidth(), frame.getHeight());
                    } else if ("restoreToPrevious".equalsIgnoreCase(disposal) && previous != null) {
                        cleanup.setComposite(AlphaComposite.Src);
                        cleanup.drawImage(previous, 0, 0, null);
                    }
                    cleanup.dispose();
                }
                for (int delay : frameDelays) totalDuration += delay;
                int uploadWidth = canvasWidth;
                int uploadHeight = canvasHeight;
                MinecraftClient.getInstance()
                        .execute(() -> uploadFrames(pixels, uploadWidth, uploadHeight, textureId));
            } finally {
                reader.dispose();
            }
        } catch (Exception ignored) {
            // The original loader silently leaves the texture unloaded on invalid input.
        }
    }

    private static void destroyTextures(List<Identifier> list, MinecraftClient minecraftclient) {
        list.forEach(identifier -> minecraftclient.getTextureManager().destroyTexture(identifier));
    }

    private void uploadFrames(List list, int i, int j, String text) {
        for (int k = 0; k < list.size(); k++) {
            int[] aint = (int[]) list.get(k);
            NativeImage nativeimage = new NativeImage(Format.RGBA, i, j, false);

            for (int l = 0; l < j; l++) {
                for (int i11 = 0; i11 < i; i11++) {
                    nativeimage.setColorArgb(i11, l, aint[l * i + i11]);
                }
            }

            int j1 = k;
            NativeImageBackedTexture nativeimagebackedtexture =
                    new NativeImageBackedTexture(
                            () -> "avdeeeeeva:gif_" + text + "_" + j1, nativeimage);
            nativeimagebackedtexture.upload();
            MinecraftClient.getInstance()
                    .getTextureManager()
                    .registerTexture(this.frameTextures.get(j1), nativeimagebackedtexture);
        }
    }
}
