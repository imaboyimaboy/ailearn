package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class MenuButton {
    private final EasingAnimation hoverAnimation = new EasingAnimation();
    private float y;
    private final EasingAnimation clickAnimation = new EasingAnimation();
    private final String label;
    private final boolean selected;
    private float width;
    private float x;
    private float height;

    public void setBounds(float f, float f1, float widthValue, float heightValue) {
        this.x = f;
        this.y = f1;
        this.width = widthValue;
        this.height = heightValue;
    }

    public void animateClick() {
        this.clickAnimation.snapTo(1.0);
        this.clickAnimation.animateTo(0.0, 0.35F, Easings.OUT_QUAD);
    }

    public float getX() {
        return this.x;
    }

    public String getLabel() {
        return this.label;
    }

    public void updateAnimations(float mouseX, float mouseY) {
        this.hoverAnimation.update();
        this.hoverAnimation.animateTo(
                this.contains(mouseX, mouseY) ? 1.0 : 0.0, 0.18F, Easings.OUT_QUAD, true);
        this.clickAnimation.update();
    }

    public float getClickProgress() {
        return this.clickAnimation.getFloatValue();
    }

    public MenuButton(String labelValue, boolean selectedValue) {
        this.label = labelValue;
        this.selected = selectedValue;
    }

    public float getWidth() {
        return this.width;
    }

    public float getHeight() {
        return this.height;
    }

    public float getY() {
        return this.y;
    }

    public boolean contains(float mouseX, float mouseY) {
        return MathUtils.containsPoint(mouseX, mouseY, this.x, this.y, this.width, this.height);
    }

    public boolean isSelected() {
        return this.selected;
    }

    public float getHoverProgress() {
        return this.hoverAnimation.getFloatValue();
    }
}
