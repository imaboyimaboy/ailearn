package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Collections;
import java.util.List;

@Environment(EnvType.CLIENT)
public abstract class Command {
    private final String usage;
    private final String description;
    private final String name;

    public List<String> suggest(String text) {
        return Collections.emptyList();
    }

    public String getName() {
        return this.name;
    }

    public Command(String nameValue, String usageValue, String descriptionValue) {
        this.name = nameValue;
        this.usage = usageValue;
        this.description = descriptionValue;
    }

    public abstract void execute(String[] astring) throws CloneNotSupportedException;
}
