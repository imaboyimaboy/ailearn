package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Environment(EnvType.CLIENT)
public class RotationModelStore {
    public static final Path MODEL_DIRECTORY = GoobaPaths.CONFIG_DIRECTORY.resolve("neuro");
    public final String name;
    private int strokeCursor;
    public FeedForwardNetwork feedForwardNetwork;
    private int sampleCursor;
    private final List<float[]> strokes;

    private final List<float[]> trajectories;
    private int trajectoryCursor;
    private static final Path CURRENT_MODEL_FILE =
            RotationModelStore.MODEL_DIRECTORY.resolve("current.txt");
    private final List<double[]> trainingOutputs;
    private final List<double[]> trainingInputs;
    public double trainingLoss = -1.0;
    public int trainingSampleCount;

    public RotationModelStore(String stringValue) {
        this.trainingInputs = new ArrayList<>();
        this.trainingOutputs = new ArrayList<>();
        this.sampleCursor = -1;
        this.strokes = new ArrayList<>();
        this.strokeCursor = -1;
        this.trajectories = new ArrayList<>();
        this.trajectoryCursor = -1;
        this.name = stringValue;
        this.feedForwardNetwork = new FeedForwardNetwork(14, 20, 13);
    }

    public int getStrokeCount() {
        return this.strokes.size();
    }

    public RotationModelStore.Prediction predict(double[] adouble) {
        RotationModelStore.Prediction prediction = this.predictFromNetwork(adouble);
        RotationModelStore.Prediction predictionValue = this.predictFromMemory(adouble);
        return predictionValue != null
                ? predictionValue.withSpeedLimits(prediction.maxYawSpeed, prediction.maxPitchSpeed)
                : prediction;
    }

    public float[] sampleStroke(float f) {
        if (this.strokes.isEmpty()) {
            return new float[] {0.0F, 0.0F};
        } else {
            if (this.strokeCursor >= 0 && this.strokeCursor < this.strokes.size()) {
                float[] afloat = this.strokes.get(this.strokeCursor);
                if (Math.abs(afloat[2] - f) <= strokeMatchThreshold(f)) {
                    this.strokeCursor++;
                    return new float[] {afloat[0], afloat[1]};
                }
            }

            int l = 0;
            float MAX_VALUE = Float.MAX_VALUE;
            int i = ThreadLocalRandom.current().nextInt(this.strokes.size());

            for (int j = 0; j < this.strokes.size(); j++) {
                int k = (i + j) % this.strokes.size();
                float MAX_VALUEValue = Math.abs(this.strokes.get(k)[2] - f);
                if (MAX_VALUEValue < MAX_VALUE) {
                    MAX_VALUE = MAX_VALUEValue;
                    l = k;
                }

                if (MAX_VALUEValue <= strokeMatchThreshold(f) * 0.25F) {
                    l = k;
                    break;
                }
            }

            this.strokeCursor = l + 1;
            float[] values = this.strokes.get(l);
            return new float[] {values[0], values[1]};
        }
    }

    public static double normalizeSigned(float f, float f1) {
        return f1 <= 0.0F ? 0.5 : (double) ((clamp(f / f1, -1.0F, 1.0F) + 1.0F) * 0.5F);
    }

    private static float trajectoryDistanceSquared(float[] afloat, float f, float f1, float f2) {

        float f3 = afloat[0] - f;

        float f4 = afloat[1] - f1;

        float f5 = (Math.min(afloat[4], 40.0F) - Math.min(f2, 40.0F)) * 1.2F;

        return f3 * f3 + f4 * f4 + f5 * f5;
    }

    private static float clampUnit(float f) {
        return clamp(f, 0.0F, 1.0F);
    }

    public static double[] encodeFeatures(
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float f8,
            float f9,
            float f10,
            float f11) {
        return new double[] {
            Math.min((double) Math.abs(f) / 180.0, 1.0),
            Math.min((double) Math.abs(f1) / 90.0, 1.0),
            normalizeSigned(f, 180.0F),
            normalizeSigned(f1, 90.0F),
            normalizeSigned(f2, 35.0F),
            normalizeSigned(f3, 22.0F),
            normalizeSigned(f2 - f4, 35.0F),
            normalizeSigned(f3 - f5, 22.0F),
            (double) clampUnit(f6),
            (double) clampUnit(f7),
            (double) clampUnit(f8),
            Math.min((double) Math.max(f9, 0.0F) / 8.0, 1.0),
            (double) clampUnit(f10),
            (double) clampUnit(f11)
        };
    }

    private String serializeStrokes() {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("STROKES ").append(this.strokes.size()).append('\n');

        for (float[] afloat : this.strokes) {
            stringbuilder
                    .append(afloat[0])
                    .append(' ')
                    .append(afloat[1])
                    .append(' ')
                    .append(afloat[2])
                    .append('\n');
        }

        return stringbuilder.toString();
    }

    public static RotationModelStore load(String text) {
        try {
            Path pathx = MODEL_DIRECTORY.resolve(text + ".neuro");
            if (!Files.exists(pathx)) {
                return null;
            } else {
                String textValue = Files.readString(pathx, StandardCharsets.UTF_8);
                int i = textValue.indexOf(10);
                String text2 = textValue.substring(0, i).trim();
                String[] astring = text2.split("\\s+");
                RotationModelStore rotationModelStore2 = new RotationModelStore(text);
                rotationModelStore2.trainingSampleCount = Integer.parseInt(astring[0]);
                rotationModelStore2.trainingLoss = Double.parseDouble(astring[1]);
                rotationModelStore2.feedForwardNetwork =
                        FeedForwardNetwork.deserialize(textValue.substring(i + 1));
                rotationModelStore2.readTrainingSamples(textValue.substring(i + 1));
                rotationModelStore2.readStrokes(textValue.substring(i + 1));
                rotationModelStore2.readTrajectories(textValue.substring(i + 1));
                return rotationModelStore2;
            }
        } catch (Exception exception) {
            return null;
        }
    }

    private void readStrokes(String text) {
        String[] astring = text.split("\n");
        int i = -1;

        for (int j = 0; j < astring.length; j++) {
            if (astring[j].startsWith("STROKES ")) {
                i = j + 1;
                break;
            }
        }

        if (i >= 0) {
            this.strokes.clear();

            for (int k = i; k < astring.length && this.strokes.size() < 50000; k++) {
                String textValue = astring[k].trim();
                if (!textValue.isEmpty()) {
                    if (textValue.startsWith("TRAJ ")) {
                        break;
                    }

                    String[] texts = textValue.split("\\s+");
                    if (texts.length >= 3) {
                        try {
                            this.strokes.add(
                                    new float[] {
                                        Float.parseFloat(texts[0]),
                                        Float.parseFloat(texts[1]),
                                        Float.parseFloat(texts[2])
                                    });
                        } catch (Exception exception) {
                        }
                    }
                }
            }
        }
    }

    private static float trajectoryMatchThresholdSquared(float f, float f1) {
        float f2 = (float) Math.hypot((double) f, (double) f1);
        float f3 = 6.0F + f2 * 0.35F;
        return f3 * f3;
    }

    private String serializeTrajectories() {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("TRAJ ").append(this.trajectories.size()).append('\n');

        for (float[] afloat : this.trajectories) {
            stringbuilder
                    .append(afloat[0])
                    .append(' ')
                    .append(afloat[1])
                    .append(' ')
                    .append(afloat[2])
                    .append(' ')
                    .append(afloat[3])
                    .append(' ')
                    .append(afloat[4])
                    .append('\n');
        }

        return stringbuilder.toString();
    }

    private void readTrajectories(String text) {
        String[] astring = text.split("\n");
        int i = -1;

        for (int j = 0; j < astring.length; j++) {
            if (astring[j].startsWith("TRAJ ")) {
                i = j + 1;
                break;
            }
        }

        if (i >= 0) {
            this.trajectories.clear();

            for (int k = i; k < astring.length && this.trajectories.size() < 60000; k++) {
                String textValue = astring[k].trim();
                if (!textValue.isEmpty()) {
                    String[] texts = textValue.split("\\s+");
                    if (texts.length >= 5) {
                        try {
                            this.trajectories.add(
                                    new float[] {
                                        Float.parseFloat(texts[0]),
                                        Float.parseFloat(texts[1]),
                                        Float.parseFloat(texts[2]),
                                        Float.parseFloat(texts[3]),
                                        Float.parseFloat(texts[4])
                                    });
                        } catch (Exception exception) {
                        }
                    }
                }
            }
        }
    }

    public int getTrajectoryCount() {
        return this.trajectories.size();
    }

    public void save() {
        try {
            Files.createDirectories(MODEL_DIRECTORY);
        } catch (Exception exceptionValue) {
            return;
        }

        try {
            int trainingSampleCountValue = this.trainingSampleCount;
            double trainingLossValue = this.trainingLoss;
            String stringValue = this.feedForwardNetwork.serialize();
            String text = this.serializeTrainingSamples();
            String textValue = this.serializeTrajectories();
            String text3 = this.serializeStrokes();
            String text2 = text;
            String stringValueValue = stringValue;
            double trainingLossValueValue = trainingLossValue;
            int trainingSampleCountValueValue = trainingSampleCountValue;
            String text6 =
                    trainingSampleCountValueValue
                            + " "
                            + trainingLossValueValue
                            + "\n"
                            + stringValueValue
                            + text2
                            + text3
                            + textValue;
            Files.writeString(this.getPath(), text6, StandardCharsets.UTF_8);
        } catch (Exception exception) {
        }
    }

    private static float strokeMatchThreshold(float f) {
        return Math.max(3.0F, f * 0.6F);
    }

    public static void setCurrentModel(String text) {
        try {
            Files.createDirectories(MODEL_DIRECTORY);
            if (text != null && !text.isBlank()) {
                Files.writeString(CURRENT_MODEL_FILE, text, StandardCharsets.UTF_8);
            } else {
                Files.deleteIfExists(CURRENT_MODEL_FILE);
            }
        } catch (Exception exception) {
        }
    }

    private static double[] parseVector(String text, int i) {
        String[] astring = text.trim().split("\\s+");
        if (astring.length < i) {
            return null;
        } else {
            double[] adouble = new double[i];

            try {
                for (int j = 0; j < i; j++) {
                    adouble[j] = Double.parseDouble(astring[j]);
                }

                return adouble;
            } catch (Exception exception) {
                return null;
            }
        }
    }

    private static float clamp(float f, float f1, float f2) {
        return f < f1 ? f1 : Math.min(f, f2);
    }

    public float[] sampleTrajectory(float f, float f1, float f2) {
        if (this.trajectories.isEmpty()) {
            return null;
        } else {
            if (this.trajectoryCursor >= 0 && this.trajectoryCursor < this.trajectories.size()) {
                float[] afloat = this.trajectories.get(this.trajectoryCursor);
                if (afloat[4] >= 0.0F
                        && trajectoryDistanceSquared(afloat, f, f1, f2)
                                <= trajectoryMatchThresholdSquared(f, f1)) {
                    this.trajectoryCursor++;
                    return scaleTrajectory(afloat, f, f1);
                }
            }

            int l = -1;
            float MAX_VALUE = Float.MAX_VALUE;
            int i = ThreadLocalRandom.current().nextInt(this.trajectories.size());

            for (int j = 0; j < this.trajectories.size(); j++) {
                int k = (i + j) % this.trajectories.size();
                float[] afloatValue = this.trajectories.get(k);
                if (!(afloatValue[4] < 0.0F)) {
                    float MAX_VALUEValue = trajectoryDistanceSquared(afloatValue, f, f1, f2);
                    if (MAX_VALUEValue < MAX_VALUE) {
                        MAX_VALUE = MAX_VALUEValue;
                        l = k;
                    }

                    if (MAX_VALUEValue <= trajectoryMatchThresholdSquared(f, f1) * 0.2F) {
                        l = k;
                        break;
                    }
                }
            }

            if (l >= 0 && !(MAX_VALUE > trajectoryMatchThresholdSquared(f, f1) * 4.0F)) {
                this.trajectoryCursor = l + 1;
                return scaleTrajectory(this.trajectories.get(l), f, f1);
            } else {
                this.trajectoryCursor = -1;
                return null;
            }
        }
    }

    private static double featureDistanceSquared(double[] adouble, double[] values) {
        double d0 = 0.0;

        for (int i = 0; i < 14; i++) {
            double d1;
            double d2;
            switch (i) {
                case 0:
                case 1:
                case 2:
                case 3:
                    d1 = 3.0;
                    d2 = adouble[i] - values[i];
                    break;
                case 4:
                case 5:
                case 6:
                case 7:
                    d1 = 2.4;
                    d2 = adouble[i] - values[i];
                    break;
                case 8:
                case 9:
                case 10:
                    d1 = 1.8;
                    d2 = adouble[i] - values[i];
                    break;
                case 11:
                default:
                    d1 = 1.0;
                    d2 = adouble[i] - values[i];
                    break;
                case 12:
                case 13:
                    d1 = 1.5;
                    d2 = adouble[i] - values[i];
            }

            d0 += d2 * d2 * d1;
        }

        return d0;
    }

    public static String getCurrentModel() {
        try {
            if (!Files.exists(CURRENT_MODEL_FILE)) {
                return null;
            } else {
                String text = Files.readString(CURRENT_MODEL_FILE, StandardCharsets.UTF_8).trim();
                return text.isEmpty() ? null : text;
            }
        } catch (Exception exception) {
            return null;
        }
    }

    public void addStrokes(List<float[]> list) throws CloneNotSupportedException {
        for (float[] afloat : list) {
            if (afloat.length == 3) {
                if (this.strokes.size() >= 50000) {
                    this.strokes.remove(0);
                }

                this.strokes.add((float[]) afloat.clone());
            }
        }
    }

    public void addTrainingSamples(double[][] adouble, double[][] valuesArray)
            throws CloneNotSupportedException {
        for (int i = 0; i < adouble.length && i < valuesArray.length; i++) {
            if (adouble[i].length == 14 && valuesArray[i].length == 13) {
                if (this.trainingInputs.size() >= 60000) {
                    this.trainingInputs.remove(0);
                    this.trainingOutputs.remove(0);
                }

                this.trainingInputs.add((double[]) adouble[i].clone());
                this.trainingOutputs.add((double[]) valuesArray[i].clone());
            }
        }
    }

    private static float decodeSigned(float f) {
        return clampUnit(f) * 2.0F - 1.0F;
    }

    private RotationModelStore.Prediction predictFromMemory(double[] adouble) {
        if (!this.trainingInputs.isEmpty() && adouble.length == 14) {
            if (this.sampleCursor >= 0 && this.sampleCursor < this.trainingInputs.size()) {
                double d0 =
                        featureDistanceSquared(adouble, this.trainingInputs.get(this.sampleCursor));
                if (d0 < 8.0) {
                    return decodePrediction(this.trainingOutputs.get(this.sampleCursor++));
                }
            }

            double MAX_VALUE = Double.MAX_VALUE;
            double[] adoubleValue = null;
            int i = -1;

            for (int j = 0; j < this.trainingInputs.size(); j++) {
                double MAX_VALUEValue = featureDistanceSquared(adouble, this.trainingInputs.get(j));
                if (MAX_VALUEValue < MAX_VALUE) {
                    MAX_VALUE = MAX_VALUEValue;
                    adoubleValue = this.trainingOutputs.get(j);
                    i = j;
                }
            }

            if (i >= 0) {
                this.sampleCursor = i + 1;
            } else {
                this.sampleCursor = -1;
            }

            return adoubleValue == null ? null : decodePrediction(adoubleValue);
        } else {
            return null;
        }
    }

    public void ensureNetworkDimensions() {
        if (this.feedForwardNetwork.inputSize != 14 || this.feedForwardNetwork.outputSize != 13) {
            this.feedForwardNetwork = new FeedForwardNetwork(14, 20, 13);
            this.trainingSampleCount = 0;
            this.trainingLoss = -1.0;
            this.trainingInputs.clear();
            this.trainingOutputs.clear();
        }
    }

    private static RotationModelStore.Prediction decodePrediction(double[] adouble) {
        return new RotationModelStore.Prediction(
                Math.max((float) adouble[0] * 180.0F, 12.0F),
                Math.max((float) adouble[1] * 120.0F, 10.0F),
                clampUnit((float) adouble[2]),
                clampUnit((float) adouble[3]),
                clampUnit((float) adouble[4]),
                decodeSigned((float) adouble[5]) * 8.0F,
                decodeSigned((float) adouble[6]) * 5.0F,
                decodeSigned((float) adouble[7]) * 35.0F,
                decodeSigned((float) adouble[8]) * 22.0F,
                decodeSigned((float) adouble[9]) * 35.0F,
                decodeSigned((float) adouble[10]) * 22.0F,
                adouble.length > 11 ? clampUnit((float) adouble[11]) : 1.0F,
                adouble.length > 12 ? clampUnit((float) adouble[12]) : 0.0F,
                true);
    }

    private void readTrainingSamples(String text) {
        String[] astring = text.split("\n");
        int i = -1;

        for (int j = 0; j < astring.length; j++) {
            if (astring[j].startsWith("MEMORY ")) {
                i = j + 1;
                break;
            }
        }

        if (i >= 0) {
            this.trainingInputs.clear();
            this.trainingOutputs.clear();

            for (int l = i; l < astring.length && this.trainingInputs.size() < 60000; l++) {
                String textValue = astring[l].trim();
                if (!textValue.isEmpty()) {
                    if (textValue.startsWith("STROKES ")) {
                        break;
                    }

                    int k = textValue.indexOf(124);
                    if (k >= 0) {
                        double[] adouble = parseVector(textValue.substring(0, k), 14);
                        double[] values = parseVector(textValue.substring(k + 1), 13);
                        if (adouble != null && values != null) {
                            this.trainingInputs.add(adouble);
                            this.trainingOutputs.add(values);
                        }
                    }
                }
            }
        }
    }

    private RotationModelStore.Prediction predictFromNetwork(double[] adouble) {
        double[] values = this.feedForwardNetwork.predict(adouble);
        float f = (float) (values[0] * 180.0);
        float f1 = (float) (values[1] * 120.0);
        return values.length < 13
                ? new RotationModelStore.Prediction(
                        Math.max(f, 12.0F),
                        Math.max(f1, 10.0F),
                        0.5F,
                        0.5F,
                        0.5F,
                        0.0F,
                        0.0F,
                        0.0F,
                        0.0F,
                        0.0F,
                        0.0F,
                        1.0F,
                        0.0F,
                        false)
                : new RotationModelStore.Prediction(
                        Math.max(f, 12.0F),
                        Math.max(f1, 10.0F),
                        clampUnit((float) values[2]),
                        clampUnit((float) values[3]),
                        clampUnit((float) values[4]),
                        decodeSigned((float) values[5]) * 8.0F,
                        decodeSigned((float) values[6]) * 5.0F,
                        decodeSigned((float) values[7]) * 35.0F,
                        decodeSigned((float) values[8]) * 22.0F,
                        decodeSigned((float) values[9]) * 35.0F,
                        decodeSigned((float) values[10]) * 22.0F,
                        clampUnit((float) values[11]),
                        clampUnit((float) values[12]),
                        false);
    }

    public void addTrajectories(List<float[]> list) throws CloneNotSupportedException {
        for (float[] afloat : list) {
            if (afloat.length == 5) {
                if (this.trajectories.size() >= 60000) {
                    this.trajectories.remove(0);
                }

                this.trajectories.add((float[]) afloat.clone());
            }
        }
    }

    private String serializeTrainingSamples() {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("MEMORY ").append(this.trainingInputs.size()).append('\n');

        for (int i = 0; i < this.trainingInputs.size(); i++) {
            for (double d0 : this.trainingInputs.get(i)) {
                stringbuilder.append(d0).append(' ');
            }

            stringbuilder.append("| ");

            for (double d1 : this.trainingOutputs.get(i)) {
                stringbuilder.append(d1).append(' ');
            }

            stringbuilder.append('\n');
        }

        return stringbuilder.toString();
    }

    public Path getPath() {
        String stringValue = this.name;
        return MODEL_DIRECTORY.resolve(stringValue + ".neuro");
    }

    private static float[] scaleTrajectory(float[] afloat, float f, float f1) {
        float f2 = (float) Math.hypot((double) afloat[0], (double) afloat[1]);
        float f3 = (float) Math.hypot((double) f, (double) f1);
        float f4;
        if (f2 < 1.0F) {
            f4 = 1.0F;
        } else {
            f4 = clamp(f3 / f2, 0.5F, 2.0F);
        }

        return new float[] {afloat[2] * f4, afloat[3] * f4};
    }

    @Environment(EnvType.CLIENT)
    public static class Prediction {
        public final float yawVelocity;
        public final float pitchVelocity;
        public final float targetX;
        public final float pitchOffset;
        public final float maxYawSpeed;
        public final boolean fromMemory;
        public final float yawAcceleration;
        public final float targetY;
        public final float pitchAcceleration;
        public final float targetZ;
        public final float stability;
        public final float aggression;
        public final float maxPitchSpeed;
        public final float yawOffset;

        public Prediction(
                float maxYawSpeedValue,
                float maxPitchSpeedValue,
                float targetXValue,
                float targetYValue,
                float targetZValue,
                float yawOffsetValue,
                float pitchOffsetValue,
                float yawVelocityValue,
                float pitchVelocityValue,
                float yawAccelerationValue,
                float pitchAccelerationValue) {
            this(
                    maxYawSpeedValue,
                    maxPitchSpeedValue,
                    targetXValue,
                    targetYValue,
                    targetZValue,
                    yawOffsetValue,
                    pitchOffsetValue,
                    yawVelocityValue,
                    pitchVelocityValue,
                    yawAccelerationValue,
                    pitchAccelerationValue,
                    1.0F,
                    0.0F,
                    false);
        }

        public RotationModelStore.Prediction withSpeedLimits(float f, float f1) {
            return new RotationModelStore.Prediction(
                    f,
                    f1,
                    this.targetX,
                    this.targetY,
                    this.targetZ,
                    this.yawOffset,
                    this.pitchOffset,
                    this.yawVelocity,
                    this.pitchVelocity,
                    this.yawAcceleration,
                    this.pitchAcceleration,
                    this.stability,
                    this.aggression,
                    this.fromMemory);
        }

        public Prediction(
                float maxYawSpeedValue,
                float maxPitchSpeedValue,
                float targetXValue,
                float targetYValue,
                float targetZValue,
                float yawOffsetValue,
                float pitchOffsetValue,
                float yawVelocityValue,
                float pitchVelocityValue,
                float yawAccelerationValue,
                float pitchAccelerationValue,
                float stabilityValue,
                float aggressionValue,
                boolean fromMemoryValue) {
            this.maxYawSpeed = maxYawSpeedValue;
            this.maxPitchSpeed = maxPitchSpeedValue;
            this.targetX = targetXValue;
            this.targetY = targetYValue;
            this.targetZ = targetZValue;
            this.yawOffset = yawOffsetValue;
            this.pitchOffset = pitchOffsetValue;
            this.yawVelocity = yawVelocityValue;
            this.pitchVelocity = pitchVelocityValue;
            this.yawAcceleration = yawAccelerationValue;
            this.pitchAcceleration = pitchAccelerationValue;
            this.stability = stabilityValue;
            this.aggression = aggressionValue;
            this.fromMemory = fromMemoryValue;
        }
    }
}
