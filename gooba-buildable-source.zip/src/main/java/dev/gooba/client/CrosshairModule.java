package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Crosshair",
        desc = "Replaces the default crosshair with an animated circle",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class CrosshairModule extends Module {
    private final EasingAnimation attackAnimation = new EasingAnimation();

    public static CrosshairModule getInstance() {
        return (CrosshairModule) ModuleLookup.getModule(CrosshairModule.class);
    }

    @EventHandler
    public void onRender2D(Render2DEvent render2DEvent) {
        float f = 2.0F / (float) client.getWindow().getScaleFactor();
        float centerX = (float) ((int) ((float) client.getWindow().getScaledWidth() / f)) / 2.0F;
        float centerY = (float) ((int) ((float) client.getWindow().getScaledHeight() / f)) / 2.0F;
        this.attackAnimation.update();
        this.attackAnimation.animateTo(
                (double) (1.0F - client.player.getAttackCooldownProgress(0.0F)), 0.01F);
        RenderUtils.Render2D.drawProgressCircle(
                render2DEvent.getDrawContext(),
                centerX,
                centerY,
                4.0F,
                1.0F,
                this.attackAnimation.getFloatValue(),
                ThemeColors.getElementColor(),
                ColorUtils.opaqueGrayscale(0),
                ColorUtils.opaqueGrayscale(0));
    }
}
