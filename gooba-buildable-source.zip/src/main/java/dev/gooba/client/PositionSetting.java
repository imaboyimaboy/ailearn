package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.joml.Vector2f;

@Environment(EnvType.CLIENT)
public class PositionSetting extends Setting<Vector2f> {
    public boolean lockHorizontal;
    public EasingAnimation yAnimation;
    public boolean locked;
    public boolean visible;
    public final Vector2f size;
    public final Vector2f targetPosition = new Vector2f();
    public EasingAnimation xAnimation;
    public final Vector2f position = new Vector2f();

    public PositionSetting(Module moduleValue, String nameValue, Vector2f vector2f) {
        super(moduleValue, nameValue, vector2f);
        this.size = new Vector2f();
        this.visible = true;
        this.locked = false;
        this.lockHorizontal = false;
        this.xAnimation = new EasingAnimation();
        this.yAnimation = new EasingAnimation();
        this.position.set(vector2f);
        this.targetPosition.set(vector2f);
    }

    public PositionSetting(Module moduleValue, String nameValue) {
        super(moduleValue, nameValue, new Vector2f());
        this.size = new Vector2f();
        this.visible = true;
        this.locked = false;
        this.lockHorizontal = false;
        this.xAnimation = new EasingAnimation();
        this.yAnimation = new EasingAnimation();
    }

    public PositionSetting onChange(Runnable runnable) {
        return (PositionSetting) super.onChange(runnable);
    }

    public Setting setPosition(Vector2f vector2f) {
        this.position.set(vector2f);
        this.targetPosition.set(vector2f);
        return super.setValue(vector2f);
    }

    public Vector2f getPosition() {
        return this.position;
    }

    public PositionSetting(
            Module moduleValue,
            String nameValue,
            Vector2f vector2f,
            boolean flag,
            boolean lockedValue) {
        super(moduleValue, nameValue, vector2f);
        this.size = new Vector2f();
        this.visible = true;
        this.locked = false;
        this.lockHorizontal = false;
        this.xAnimation = new EasingAnimation();
        this.yAnimation = new EasingAnimation();
        this.position.set(vector2f);
        this.targetPosition.set(vector2f);
        if (flag && !lockedValue) {
            this.visible = true;
        } else {
            this.visible = false;
        }

        this.locked = lockedValue;
    }

    public PositionSetting(
            Module moduleValue, String nameValue, Vector2f vector2f, boolean visibleValue) {
        super(moduleValue, nameValue, vector2f);
        this.size = new Vector2f();
        this.visible = true;
        this.locked = false;
        this.lockHorizontal = false;
        this.xAnimation = new EasingAnimation();
        this.yAnimation = new EasingAnimation();
        this.position.set(vector2f);
        this.targetPosition.set(vector2f);
        this.visible = visibleValue;
    }
}
