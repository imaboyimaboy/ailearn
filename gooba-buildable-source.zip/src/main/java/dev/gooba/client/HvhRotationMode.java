package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class HvhRotationMode implements RotationModeHandler {

    @Override
    public void updateRotation(
            AttackAuraModule attackAuraModule,
            LivingEntity livingentity,
            float[] afloat,
            boolean flag) {
        Vec3d vec3d = TargetPositionUtils.relativeEyeOffset(livingentity);
        float f = (float) Math.toDegrees(Math.atan2(-vec3d.x, vec3d.z));
        float f1 =
                (float)
                        MathHelper.clamp(
                                -Math.toDegrees(Math.atan2(vec3d.y, Math.hypot(vec3d.x, vec3d.z))),
                                -90.0,
                                90.0);
        Rotation rotation = new Rotation(f, f1);
        float aimYawSpeedValue = MathUtils.randomFloatUnchecked(480.0F, 625.0F);
        float aimPitchSpeedValue = MathUtils.randomFloatUnchecked(455.0F, 555.0F);
        if (EntityRaycast.intersectsTarget(
                client.player.getYaw(),
                client.player.getPitch(),
                (double) attackAuraModule.attackRangeSetting.getFloat().floatValue(),
                livingentity)) {
            aimPitchSpeedValue = 0.0F;
            aimYawSpeedValue = MathUtils.secureRandomFloat(450.0F, 700.0F);
        }

        TargetRingRenderer.aim(
                rotation, aimYawSpeedValue, aimPitchSpeedValue, 425.0F, 425.0F, 0, 1, false);
    }

    public HvhRotationMode() {}
}
