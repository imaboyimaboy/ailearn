package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.Window;

@Environment(EnvType.CLIENT)
public interface WindowAccess extends MinecraftAccess {
    Window window = client.getWindow();
}
