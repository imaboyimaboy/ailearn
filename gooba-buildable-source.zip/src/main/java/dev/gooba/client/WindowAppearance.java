package dev.gooba.client;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.WinDef.HWND;
import com.sun.jna.win32.StdCallLibrary;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.lwjgl.glfw.GLFWNativeWin32;

@Environment(EnvType.CLIENT)
public class WindowAppearance {

    public static void enableDarkTitleBar(long i) {
        if (Platform.isWindows()) {
            try {
                long j = GLFWNativeWin32.glfwGetWin32Window(i);
                HWND hwnd = new HWND(new Pointer(j));
                byte b0 = 20;
                Memory memory = new Memory(4L);
                memory.setInt(0L, 1);
                WindowAppearance.DwmApi.dwmApi.DwmSetWindowAttribute(hwnd, b0, memory);
            } catch (Throwable throwable) {
            }
        }
    }

    @Environment(EnvType.CLIENT)
    public interface DwmApi extends StdCallLibrary {
        WindowAppearance.DwmApi dwmApi =
                (WindowAppearance.DwmApi)
                        Native.loadLibrary("dwmapi", WindowAppearance.DwmApi.class);

        int DwmSetWindowAttribute(HWND hwnd, int i, Pointer pointer);
    }
}
