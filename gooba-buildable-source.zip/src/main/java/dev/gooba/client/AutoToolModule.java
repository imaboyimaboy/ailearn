package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;

@ModuleInfo(
        name = "Auto Tool",
        desc = "Automatically selects the best tool for the block being mined",
        category = ModuleCategory.PLAYER)
@Environment(EnvType.CLIENT)
public class AutoToolModule extends Module {
    private int previousSlot;
    private final MillisecondTimer swapTimer;
    private AutoToolModule.State state = AutoToolModule.State.IDLE;

    private int toolSlot;

    private void restoreHotbarSlot() {
        if (this.previousSlot >= 0 && this.previousSlot <= 8) {
            client.player.getInventory().setSelectedSlot(this.previousSlot);
            client.interactionManager.syncSelectedSlot();
        }
    }

    private void restoreAndReset() {
        if (client.player != null && client.interactionManager != null) {
            if (this.state == AutoToolModule.State.MINING
                    || this.state == AutoToolModule.State.PREPARE_RESTORE) {
                if (this.toolSlot >= 9) {
                    this.swapInventoryTool();
                    this.closeInventory();
                } else {
                    this.restoreHotbarSlot();
                }
            }

            this.setMovementEnabled(true);
        }

        this.state = AutoToolModule.State.IDLE;
        this.toolSlot = -1;
        this.previousSlot = -1;
    }

    private void resetState() {
        this.setMovementEnabled(true);
        this.state = AutoToolModule.State.IDLE;
        this.toolSlot = -1;
        this.previousSlot = -1;
    }

    private void prepareSwap() {
        if (client.options.attackKey.isPressed() && this.getTargetBlockState() != null) {
            this.setMovementEnabled(false);
            if (this.swapTimer.hasElapsed(60L)) {
                this.setMovementEnabled(true);
                this.swapInventoryTool();
                this.state = AutoToolModule.State.MINING;
            }
        } else {
            this.resetState();
        }
    }

    private int findBestTool(BlockState blockstate) {
        int selectedSlot = client.player.getInventory().getSelectedSlot();
        int j;
        if (this.isUsableTool(client.player.getInventory().getStack(selectedSlot))) {
            j = selectedSlot;
        } else {
            j = -1;
        }

        float f;
        if (j == -1) {
            f = 1.0F;
        } else {
            f = client.player.getInventory().getStack(j).getMiningSpeedMultiplier(blockstate);
        }

        boolean flag;
        int k;
        if (j != -1
                && (!blockstate.isToolRequired()
                        || client.player.getInventory().getStack(j).isSuitableFor(blockstate))) {
            flag = true;
            k = 0;
        } else {
            flag = false;
            k = 0;
        }

        for (; k < 36; k++) {
            ItemStack itemstack = client.player.getInventory().getStack(k);
            if (this.isUsableTool(itemstack)) {
                float miningSpeedMultiplier = itemstack.getMiningSpeedMultiplier(blockstate);
                boolean flag1;
                flag1 = !(blockstate.isToolRequired() && !itemstack.isSuitableFor(blockstate));

                if (flag1 && !flag || flag1 == flag && miningSpeedMultiplier > f) {
                    j = k;
                    f = miningSpeedMultiplier;
                    flag = flag1;
                }
            }
        }

        return j;
    }

    public AutoToolModule() {
        this.swapTimer = new MillisecondTimer();
        this.toolSlot = -1;
        this.previousSlot = -1;
    }

    private BlockState getTargetBlockState() {
        if (client.crosshairTarget instanceof BlockHitResult blockhitresult
                && blockhitresult.getType() == Type.BLOCK) {
            return client.world.getBlockState(blockhitresult.getBlockPos());
        }

        return null;
    }

    private void setMovementEnabled(boolean flag) {
        KeyBinding[] akeybinding =
                new KeyBinding[] {
                    client.options.forwardKey,
                    client.options.backKey,
                    client.options.leftKey,
                    client.options.rightKey,
                    client.options.jumpKey
                };

        for (KeyBinding keybinding : akeybinding) {
            boolean flag1;
            flag1 =
                    (flag
                            && InputUtil.isKeyPressed(
                                    client.getWindow(), keybinding.getDefaultKey().getCode()));

            keybinding.setPressed(flag1);
        }
    }

    private void selectTool() {
        BlockState blockstate = this.getTargetBlockState();
        if (blockstate != null && client.options.attackKey.isPressed()) {
            int toolSlotValue = this.findBestTool(blockstate);
            int selectedSlot = client.player.getInventory().getSelectedSlot();
            if (toolSlotValue != -1 && toolSlotValue != selectedSlot) {
                this.toolSlot = toolSlotValue;
                this.previousSlot = selectedSlot;
                if (toolSlotValue < 9) {
                    client.player.getInventory().setSelectedSlot(toolSlotValue);
                    client.interactionManager.syncSelectedSlot();
                    this.state = AutoToolModule.State.MINING;
                } else {
                    this.swapTimer.reset();
                    this.state = AutoToolModule.State.PREPARE_SWAP;
                }
            }
        }
    }

    @Override
    public void onDisable() {
        this.restoreAndReset();
        super.onDisable();
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (client.player == null || client.world == null || client.interactionManager == null) {
            this.state = AutoToolModule.State.IDLE;
            this.toolSlot = -1;
            this.previousSlot = -1;
        } else if (client.currentScreen == null) {
            switch (this.state) {
                case IDLE:
                    this.selectTool();
                    break;
                case PREPARE_SWAP:
                    this.prepareSwap();
                    break;
                case MINING:
                    this.tickMining();
                    break;
                case PREPARE_RESTORE:
                    this.prepareRestore();
            }
        }
    }

    private void prepareRestore() {
        this.setMovementEnabled(false);
        if (this.swapTimer.hasElapsed(60L)) {
            this.swapInventoryTool();
            this.closeInventory();
            this.resetState();
        }
    }

    private void swapInventoryTool() {
        if (this.toolSlot >= 9 && this.previousSlot >= 0 && this.previousSlot <= 8) {
            client.interactionManager.clickSlot(
                    client.player.playerScreenHandler.syncId,
                    this.toolSlot,
                    this.previousSlot,
                    SlotActionType.SWAP,
                    client.player);
        }
    }

    private boolean isUsableTool(ItemStack itemstack) {
        return !itemstack.isEmpty()
                && (!itemstack.isDamageable()
                        || itemstack.getMaxDamage() - itemstack.getDamage() > 1);
    }

    private void tickMining() {
        BlockState blockstate = this.getTargetBlockState();
        if (client.options.attackKey.isPressed() && blockstate != null) {
            if (this.toolSlot < 9) {
                int toolSlotValue = this.findBestTool(blockstate);
                if (toolSlotValue != -1
                        && toolSlotValue < 9
                        && toolSlotValue != client.player.getInventory().getSelectedSlot()) {
                    this.toolSlot = toolSlotValue;
                    client.player.getInventory().setSelectedSlot(toolSlotValue);
                    client.interactionManager.syncSelectedSlot();
                }
            }
        } else {
            if (this.toolSlot < 9) {
                this.restoreHotbarSlot();
                this.resetState();
            } else {
                this.swapTimer.reset();
                this.state = AutoToolModule.State.PREPARE_RESTORE;
            }
        }
    }

    private void closeInventory() {
        client.player.networkHandler.sendPacket(
                new CloseHandledScreenC2SPacket(client.player.playerScreenHandler.syncId));
        client.player.closeHandledScreen();
    }

    @Environment(EnvType.CLIENT)
    private static enum State {
        IDLE,
        PREPARE_SWAP,
        MINING,
        PREPARE_RESTORE;
    }
}
