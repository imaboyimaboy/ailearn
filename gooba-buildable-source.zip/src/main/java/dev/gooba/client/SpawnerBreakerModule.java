package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.ActionResult.Fail;
import net.minecraft.util.ActionResult.Success;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;

@ModuleInfo(
        name = "Spawner Breaker",
        category = ModuleCategory.DONUT,
        desc = "Breaks spawners through bedrock and walls")
@Environment(EnvType.CLIENT)
public class SpawnerBreakerModule extends Module {
    private final Set<BlockPos> visitedBlocks;
    public final SliderSetting rangeSetting =
            new SliderSetting(this, "Range", 4.5F, 1.0F, 6.0F, 0.1F);
    private int miningTicks;
    private int minedSpawners;
    private BlockPos targetPosition;
    public final BooleanSetting ghostHandSetting = new BooleanSetting(this, "Ghost Hand", true);

    @Override
    protected void onEnable() {
        this.targetPosition = null;
        this.miningTicks = 0;
        this.minedSpawners = 0;
        this.notifyPlayer("§aEnabled §7— hold attack key while looking towards spawners.");
    }

    private void interactThroughBlocks() {
        if (client.interactionManager != null && client.player != null && client.world != null) {
            float tickProgress = client.getRenderTickCounter().getTickProgress(true);
            Vec3d vec3d =
                    new Vec3d(0.0, 0.0, 0.1)
                            .rotateX(-((float) Math.toRadians((double) client.player.getPitch())))
                            .rotateY(-((float) Math.toRadians((double) client.player.getYaw())));
            this.visitedBlocks.clear();
            double d0 = (double) this.rangeSetting.getFloat().floatValue();

            for (int i = 1; (double) i < d0 * 10.0; i++) {
                BlockPos blockpos =
                        BlockPos.ofFloored(
                                client.player
                                        .getCameraPosVec(tickProgress)
                                        .add(vec3d.multiply((double) i)));
                if (!this.visitedBlocks.contains(blockpos)) {
                    this.visitedBlocks.add(blockpos);
                    if (client.world.getBlockState(blockpos).hasBlockEntity()) {
                        for (Hand hand : Hand.values()) {
                            ActionResult actionresult =
                                    client.interactionManager.interactBlock(
                                            client.player,
                                            hand,
                                            new BlockHitResult(
                                                    new Vec3d(
                                                            (double) blockpos.getX() + 0.5,
                                                            (double) blockpos.getY() + 0.5,
                                                            (double) blockpos.getZ() + 0.5),
                                                    Direction.UP,
                                                    blockpos,
                                                    true));
                            if (actionresult instanceof Success || actionresult instanceof Fail) {
                                client.player.swingHand(hand);
                                return;
                            }
                        }
                    }
                }
            }
        }
    }

    private void notifyPlayer(String text) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal("§7[§6Spawner Breaker§7] §f" + text), false);
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.world != null
                && client.player != null
                && client.getNetworkHandler() != null
                && client.options != null) {
            if (this.ghostHandSetting.isOn()
                    && client.options.useKey.isPressed()
                    && !client.player.isSneaking()
                    && client.currentScreen == null) {
                this.interactThroughBlocks();
            }

            if (!client.options.attackKey.isPressed()) {
                if (this.targetPosition != null) {
                    client.getNetworkHandler()
                            .sendPacket(
                                    new PlayerActionC2SPacket(
                                            Action.ABORT_DESTROY_BLOCK,
                                            this.targetPosition,
                                            Direction.UP));
                    this.targetPosition = null;
                    this.miningTicks = 0;
                }
            } else {
                float tickProgress = client.getRenderTickCounter().getTickProgress(true);
                Vec3d vec3d =
                        new Vec3d(0.0, 0.0, 0.1)
                                .rotateX(
                                        -((float)
                                                Math.toRadians((double) client.player.getPitch())))
                                .rotateY(
                                        -((float) Math.toRadians((double) client.player.getYaw())));
                this.visitedBlocks.clear();
                BlockPos blockpos = null;
                double d0 = (double) this.rangeSetting.getFloat().floatValue();

                for (int i = 1; (double) i < d0 * 10.0; i++) {
                    BlockPos blockposValue =
                            BlockPos.ofFloored(
                                    client.player
                                            .getCameraPosVec(tickProgress)
                                            .add(vec3d.multiply((double) i)));
                    if (!this.visitedBlocks.contains(blockposValue)) {
                        this.visitedBlocks.add(blockposValue);
                        BlockState blockstate = client.world.getBlockState(blockposValue);
                        if (!blockstate.isAir() && blockstate.isOf(Blocks.SPAWNER)) {
                            blockpos = blockposValue;
                            break;
                        }
                    }
                }

                if (blockpos == null) {
                    if (this.targetPosition != null) {
                        client.getNetworkHandler()
                                .sendPacket(
                                        new PlayerActionC2SPacket(
                                                Action.ABORT_DESTROY_BLOCK,
                                                this.targetPosition,
                                                Direction.UP));
                        this.targetPosition = null;
                        this.miningTicks = 0;
                    }
                } else {
                    if (!blockpos.equals(this.targetPosition)) {
                        if (this.targetPosition != null) {
                            client.getNetworkHandler()
                                    .sendPacket(
                                            new PlayerActionC2SPacket(
                                                    Action.ABORT_DESTROY_BLOCK,
                                                    this.targetPosition,
                                                    Direction.UP));
                        }

                        this.targetPosition = blockpos;
                        this.miningTicks = 0;
                        client.getNetworkHandler()
                                .sendPacket(
                                        new PlayerActionC2SPacket(
                                                Action.START_DESTROY_BLOCK,
                                                this.targetPosition,
                                                Direction.UP));
                        client.player.sendMessage(
                                Text.literal(
                                        "§6[SpawnerBreaker] §7Breaking spawner at §e"
                                                + this.targetPosition.getX()
                                                + ", "
                                                + this.targetPosition.getY()
                                                + ", "
                                                + this.targetPosition.getZ()),
                                true);
                    }

                    this.miningTicks++;
                    if (this.miningTicks > 5) {
                        client.getNetworkHandler()
                                .sendPacket(
                                        new PlayerActionC2SPacket(
                                                Action.STOP_DESTROY_BLOCK,
                                                this.targetPosition,
                                                Direction.UP));
                        this.minedSpawners++;
                        if (this.minedSpawners % 64 == 0) {
                            client.player.sendMessage(
                                    Text.literal(
                                            "§c§l⚠ RELOG EVERY 1 STACK MINED! §7("
                                                    + this.minedSpawners
                                                    + " spawners total)"),
                                    false);
                        }

                        this.targetPosition = null;
                        this.miningTicks = 0;
                    }
                }
            }
        }
    }

    public SpawnerBreakerModule() {
        this.visitedBlocks = new HashSet<>();
        this.targetPosition = null;
        this.miningTicks = 0;
        this.minedSpawners = 0;
    }

    @Override
    protected void onDisable() {
        if (this.targetPosition != null && client.getNetworkHandler() != null) {
            client.getNetworkHandler()
                    .sendPacket(
                            new PlayerActionC2SPacket(
                                    Action.ABORT_DESTROY_BLOCK, this.targetPosition, Direction.UP));
        }

        this.targetPosition = null;
        this.miningTicks = 0;
        int minedSpawnersValue = this.minedSpawners;
        this.notifyPlayer(
                "§cDisabled §7— mined §e" + minedSpawnersValue + " §7spawners this session.");
    }
}
