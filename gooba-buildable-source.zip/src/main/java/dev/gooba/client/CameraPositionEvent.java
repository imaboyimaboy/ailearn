package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class CameraPositionEvent extends Event {
    private Vec3d pos;

    public void setPos(Vec3d vec3d) {
        this.pos = vec3d;
    }

    public CameraPositionEvent(Vec3d vec3d) {
        this.pos = vec3d;
    }

    public Vec3d getPos() {
        return this.pos;
    }
}
