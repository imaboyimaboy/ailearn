package dev.gooba.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;

@Environment(EnvType.CLIENT)
public class Gooba implements ClientModInitializer {
    private ThemeManager themeManager;
    public static String VERSION = "5.0";
    private ConfigManager configManager;
    private ComponentManager componentManager;
    private ClickGuiScreen clickGui;
    private CommandManager commandManager;
    private FriendManager friendManager;
    private static final EventBus eventBus = EventBus.threadSafe();
    public static Gooba instance;
    private final DiscordPresenceManager discordPresenceManager = new DiscordPresenceManager();
    private HudManager hudManager;
    private ModuleManager moduleRegistry;

    public DiscordPresenceManager getDiscordPresenceManager() {
        return this.discordPresenceManager;
    }

    public void saveOnShutdown() {
        this.discordPresenceManager.stop();
        if (this.configManager != null) {
            this.configManager.saveState();
        }
    }

    public void initializeEventBusAndFonts() {
        eventBus.registerLambdaFactory(
                "",
                (method, oclass) -> (Lookup) method.invoke(null, oclass, MethodHandles.lookup()));
        FontInitializer.initialize();
    }

    public static Gooba getInstance() {
        return instance;
    }

    public ClickGuiScreen getClickGui() {
        return this.clickGui;
    }

    public ModuleManager getModuleRegistry() {
        return this.moduleRegistry;
    }

    public CommandManager getCommandManager() {
        return this.commandManager;
    }

    public ThemeManager getThemeManager() {
        return this.themeManager;
    }

    @Override
    public void onInitializeClient() {
        Runtime.getRuntime().addShutdownHook(new Thread(this::saveOnShutdown));
        instance = this;
        this.initializeEventBusAndFonts();
        this.configManager = new ConfigManager();
        this.configManager.subscribe();
        this.friendManager = new FriendManager();
        this.friendManager.initialize();
        this.moduleRegistry = new ModuleManager();
        this.moduleRegistry.initialize();
        this.componentManager = new ComponentManager();
        this.componentManager.initialize();
        this.commandManager = new CommandManager();
        this.commandManager.initialize();
        this.configManager.initializeState();
        this.themeManager = new ThemeManager();
        this.themeManager.initialize();
        this.hudManager = new HudManager();
        this.clickGui = new ClickGuiScreen();
        ClickGuiScreen.themePreset = this.themeManager.getThemePreset();
        ClickGuiScreen.themePreset2 = this.themeManager.getThemePreset();
    }

    public ComponentManager getComponentManager() {
        return this.componentManager;
    }

    public HudManager getHudManager() {
        return this.hudManager;
    }

    public FriendManager getFriendManager() {
        return this.friendManager;
    }

    public ConfigManager getConfigManager() {
        return this.configManager;
    }

    public static EventBus getEventBus() {
        return eventBus;
    }
}
