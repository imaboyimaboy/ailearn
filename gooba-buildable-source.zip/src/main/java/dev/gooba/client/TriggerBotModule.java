package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

@ModuleInfo(
        name = "Trigger Bot",
        desc = "Attacks valid targets under your crosshair",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class TriggerBotModule extends Module {

    public final BooleanSetting shieldBreakSetting;
    public final MultiBooleanSetting attackSettingsSetting =
            new MultiBooleanSetting(
                    this,
                    "Attack Settings",
                    new BooleanSetting[] {
                        new BooleanSetting("Only Critical", false),
                        new BooleanSetting("Smart Criticals", true),
                        new BooleanSetting("No Attack While Using", true)
                    });
    public static LivingEntity target;
    private int attackIndex;
    private int cooldownTicks;
    private static final int[] ATTACK_DELAYS = new int[] {10, 10, 10, 10, 12};

    private boolean isValidTarget(LivingEntity livingentity) {
        if (livingentity != client.player
                && livingentity.isAlive()
                && !livingentity.isInvulnerable()) {
            if (client.player.distanceTo(livingentity) > 4.0F
                    || !client.player.canSee(livingentity)) {
                return false;
            } else if (livingentity instanceof PlayerEntity playerentity) {
                return playerentity.isCreative()
                        ? false
                        : !Gooba.getInstance()
                                .getFriendManager()
                                .isFriend(playerentity.getName().getString());
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    private void attackTarget(LivingEntity livingentity) {
        if (!this.attackSettingsSetting.isOn("No Attack While Using")
                || !client.player.isUsingItem()) {
            if (!this.attackSettingsSetting.isOn("Only Critical")
                    || this.canCriticalHit(this.attackSettingsSetting.isOn("Smart Criticals"))) {
                if (this.cooldownTicks <= 0
                        && !(client.player.getAttackCooldownProgress(0.5F) <= 0.9F)) {
                    Runnable[] arunnable;
                    if (this.shieldBreakSetting.isOn()) {
                        arunnable = ShieldBreaker.swapActions(livingentity, true);
                    } else {
                        arunnable = new Runnable[] {() -> {}, () -> {}};
                    }

                    arunnable[0].run();
                    client.interactionManager.attackEntity(client.player, livingentity);
                    client.player.swingHand(Hand.MAIN_HAND);
                    arunnable[1].run();
                    this.cooldownTicks = ATTACK_DELAYS[this.attackIndex % ATTACK_DELAYS.length];
                    this.attackIndex++;
                }
            }
        }
    }

    @Override
    protected void onDisable() {
        target = null;
        this.cooldownTicks = 0;
        this.attackIndex = 0;
    }

    private boolean canCriticalHit(boolean flag) {
        boolean flag1;
        flag1 =
                !(!client.player.isClimbing()
                        && !client.player.isTouchingWater()
                        && !client.player.isInLava()
                        && !client.player.hasVehicle()
                        && !client.player.getAbilities().flying);

        if (flag1) {
            return false;
        } else {
            return flag && client.player.isOnGround() && !client.options.jumpKey.isPressed()
                    ? true
                    : !client.player.isOnGround() && client.player.fallDistance > 0.0;
        }
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (this.cooldownTicks > 0) {
            this.cooldownTicks--;
        }

        if (client.player != null && client.world != null) {
            if (client.crosshairTarget instanceof EntityHitResult entityhitresult
                    && entityhitresult.getEntity() instanceof LivingEntity livingentity
                    && this.isValidTarget(livingentity)) {
                target = livingentity;
                this.attackTarget(livingentity);
                return;
            }

            target = null;
        } else {
            target = null;
        }
    }

    public TriggerBotModule() {
        this.shieldBreakSetting = new BooleanSetting(this, "Shield Break", true);
    }
}
