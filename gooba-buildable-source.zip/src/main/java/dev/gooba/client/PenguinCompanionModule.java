package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4f;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@ModuleInfo(
        name = "Penguin Companion",
        desc = "Renders an animated penguin companion beside the player",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class PenguinCompanionModule extends Module {
    private float walkPhase;

    private static final Logger logger = LoggerFactory.getLogger("client/PenguinCompanion");
    private long lastFrameNanos;
    public SliderSetting scaleSetting = new SliderSetting(this, "Scale", 2.45F, 0.35F, 4.0F, 0.05F);
    private float walkAmplitude;
    private float yaw;
    private boolean loadAttempted;
    private Vec3d position;
    private PenguinCompanionModule.NanalyMesh mesh;
    private static final RenderPipeline MODEL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_TEX_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "nanaly_model"))
                            .withVertexFormat(
                                    VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.TRIANGLES)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(true)
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .build());

    private static final Identifier MESH_RESOURCE =
            Identifier.of("client", "model_new/companion_mesh.bin");
    private final BufferAllocator bufferAllocator = new BufferAllocator(1048576);
    private static final Map<Identifier, RenderLayer> textureLayers = new HashMap<>();

    private Vec3d followPosition(LivingEntity livingentity, float f) {
        Vec3d vec3dx = livingentity.getLerpedPos(f);
        if (livingentity == client.player) {
            float yaw = client.player.getYaw();
            double d0 = Math.toRadians((double) yaw);
            Vec3d vec3d2 = new Vec3d(-Math.sin(d0), 0.0, Math.cos(d0));
            return vec3dx.add(vec3d2.multiply(1.15));
        } else {
            Vec3d vec3d1 = vec3dx.subtract(client.player.getLerpedPos(f));
            if (vec3d1.horizontalLengthSquared() < 1.0E-4) {
                vec3d1 = new Vec3d(0.0, 0.0, 1.0);
            } else {
                vec3d1 = vec3d1.normalize();
            }

            return vec3dx.add(vec3d1.multiply(0.95));
        }
    }

    @Override
    protected void onEnable() {
        this.position = null;
        this.walkPhase = 0.0F;
        this.walkAmplitude = 0.0F;
    }

    private static float[] adjustArms(
            PenguinCompanionModule.NanalyMesh nanalyMeshValue,
            Identifier identifier,
            float f,
            float f1,
            float f2,
            float f3,
            float f4) {
        float f5 =
                (f1 - nanalyMeshValue.minY)
                        / Math.max(nanalyMeshValue.maxY - nanalyMeshValue.minY, 1.0E-4F);
        float f6 = Math.abs(f);
        String path = identifier.getPath();
        boolean flagx = path.contains("cloth");
        if (flagx && !(f6 < 0.16F) && !(f5 < 0.22F) && !(f5 > 0.72F)) {
            float f7 = Math.signum(f);
            float f8 = smoothstep(0.16F, 0.42F, f6);
            float f9 = smoothBand(f5, 0.22F, 0.34F, 0.58F, 0.72F);
            float f10 = f8 * f9 * 0.72F;
            float f11 = f7 * 0.15F;
            float f12 = f4 + 0.08F;
            return new float[] {
                MathHelper.lerp(f10, f2, f11), f3 - 0.015F * f10, MathHelper.lerp(f10, f4, f12)
            };
        } else {
            return new float[] {f2, f3, f4};
        }
    }

    private PenguinCompanionModule.NanalyMesh loadMesh() {
        if (this.mesh == null && !this.loadAttempted) {
            this.loadAttempted = true;

            try {
                Optional optional =
                        MinecraftClient.getInstance()
                                .getResourceManager()
                                .getResource(MESH_RESOURCE);
                if (optional.isEmpty()) {
                    logger.warn("Nanaly mesh not found: {}", MESH_RESOURCE);
                    if (client.player != null) {
                        String identifierValue = String.valueOf(MESH_RESOURCE);
                        ChatMessages.send(
                                "§cPenguin Companion: mesh not found §7" + identifierValue);
                    }

                    return null;
                }

                try (InputStream inputstream = ((Resource) optional.get()).getInputStream()) {
                    this.mesh =
                            PenguinCompanionModule.NanalyMesh.decode(inputstream.readAllBytes());
                    if (client.player != null) {
                        int length = this.mesh.groups.length;
                        ChatMessages.send(
                                "§aPenguin Companion: mesh loaded §7(" + length + " groups)");
                    }
                }
            } catch (RuntimeException | IOException ioexception) {
                logger.error("Failed to load Nanaly mesh", (Throwable) ioexception);
                if (client.player != null) {
                    ChatMessages.send("§cPenguin Companion: error loading mesh, see latest.log");
                }
            }

            return this.mesh;
        } else {
            return this.mesh;
        }
    }

    private static float smoothBand(float f, float f1, float f2, float f3, float f4) {
        return smoothstep(f1, f2, f) * (1.0F - smoothstep(f3, f4, f));
    }

    private LivingEntity followTarget() {
        AttackAuraModule attackAuraModule = AttackAuraModule.getInstance();
        return (LivingEntity)
                (attackAuraModule != null
                                && attackAuraModule.isEnabled()
                                && AttackAuraModule.target != null
                                && AttackAuraModule.target.isAlive()
                        ? AttackAuraModule.target
                        : client.player);
    }

    private static float[] animateWalking(
            PenguinCompanionModule.NanalyMesh nanalyMeshValue,
            Identifier identifier,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6) {
        if (f6 <= 0.0F) {
            return new float[] {f2, f3, f4};
        } else {
            float f7 =
                    (f1 - nanalyMeshValue.minY)
                            / Math.max(nanalyMeshValue.maxY - nanalyMeshValue.minY, 1.0E-4F);
            float f8 = Math.abs(f);
            float f9 = f >= 0.0F ? 1.0F : -1.0F;
            float f10 = MathHelper.sin((double) (f5 + (f9 > 0.0F ? 0.0F : (float) Math.PI)));
            float f11 = Math.max(f10, 0.0F);
            String path = identifier.getPath();
            if (path.contains("cloth") && f7 < 0.2F && f8 > 0.025F && f8 < 0.22F) {
                float f14 = smoothBand(f7, 0.0F, 0.03F, 0.16F, 0.22F);
                return new float[] {
                    f2 + f9 * 0.01F * f11 * f14 * f6,
                    f3 + 0.045F * f11 * f14 * f6,
                    f4 + f10 * 0.07F * f14 * f6
                };
            } else if (path.contains("cloth") && f7 >= 0.22F && f7 <= 0.62F && f8 > 0.16F) {
                float f13 =
                        smoothBand(f7, 0.22F, 0.34F, 0.54F, 0.66F) * smoothstep(0.16F, 0.38F, f8);
                return new float[] {
                    f2 + f9 * 0.012F * f10 * f13 * f6,
                    f3 + 0.01F * f11 * f13 * f6,
                    f4 - f10 * 0.035F * f13 * f6
                };
            } else if (f7 > 0.18F && f7 < 0.78F && f8 < 0.34F) {
                float f12 = smoothBand(f7, 0.18F, 0.36F, 0.62F, 0.78F);
                return new float[] {
                    f2 + f9 * 0.002F * f10 * f12 * f6, f3, f4 - Math.abs(f10) * 0.01F * f12 * f6
                };
            } else {
                return new float[] {f2, f3, f4};
            }
        }
    }

    private static RenderLayer layerForTexture(Identifier identifier) {
        return textureLayers.computeIfAbsent(
                identifier,
                identifierx -> {
                    String text = identifierx.getPath().replace('/', '_').replace('.', '_');
                    return RenderLayer.of(
                            "nanaly_model_" + text,
                            RenderSetup.builder(MODEL_PIPELINE)
                                    .texture("Sampler0", identifierx)
                                    .translucent()
                                    .expectedBufferSize(1048576)
                                    .build());
                });
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null) {
            PenguinCompanionModule.NanalyMesh nanalyMeshValue = this.loadMesh();
            if (nanalyMeshValue != null) {
                MatrixStack matrixstack = render3DEvent.getMatrixStack();
                Vec3d vec3dx = client.gameRenderer.getCamera().getCameraPos();
                LivingEntity livingentity = this.followTarget();
                Vec3d vec3d1 = this.followPosition(livingentity, render3DEvent.getTickDelta());
                this.updatePosition(vec3d1, livingentity);
                Vec3d vec3d2 = this.position;
                Vec3d vec3d3 = vec3d2.subtract(vec3dx);
                matrixstack.push();
                matrixstack.translate(vec3d3.x, vec3d3.y, vec3d3.z);
                matrixstack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F - this.yaw));
                matrixstack.scale(
                        this.scaleSetting.getFloat(),
                        this.scaleSetting.getFloat(),
                        this.scaleSetting.getFloat());
                Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
                Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);

                for (PenguinCompanionModule.MeshGroup meshGroup : nanalyMeshValue.groups) {
                    VertexConsumer vertexconsumer =
                            immediate.getBuffer(layerForTexture(meshGroup.texture));

                    for (byte b0 = 0; b0 < meshGroup.vertices.length; b0 += 8) {
                        float vertice = meshGroup.vertices[b0];
                        float verticeValue = meshGroup.vertices[b0 + 1];
                        float vertice2 = meshGroup.vertices[b0 + 2];
                        float vertice3 = meshGroup.vertices[b0 + 3];
                        float vertice4 = meshGroup.vertices[b0 + 4];
                        float f5 = vertice2 - nanalyMeshValue.minY;
                        float f6 = -(verticeValue - nanalyMeshValue.centerZ);
                        float[] afloat =
                                adjustArms(
                                        nanalyMeshValue,
                                        meshGroup.texture,
                                        vertice,
                                        vertice2,
                                        vertice,
                                        f5,
                                        f6);
                        float[] values =
                                animateWalking(
                                        nanalyMeshValue,
                                        meshGroup.texture,
                                        vertice,
                                        vertice2,
                                        afloat[0],
                                        afloat[1],
                                        afloat[2],
                                        this.walkPhase,
                                        this.walkAmplitude);
                        vertexconsumer
                                .vertex(matrix4f, values[0], values[1], values[2])
                                .color(255, 255, 255, 255)
                                .texture(vertice3, vertice4);
                    }
                }

                immediate.draw();
                matrixstack.pop();
            }
        }
    }

    private static float lerpAngle(float f, float f1, float f2) {
        float f3 = MathHelper.wrapDegrees(f1 - f);
        return f + f3 * f2;
    }

    private static float smoothstep(float f, float f1, float f2) {
        float f3 = MathHelper.clamp((f2 - f) / Math.max(f1 - f, 1.0E-4F), 0.0F, 1.0F);
        return f3 * f3 * (3.0F - 2.0F * f3);
    }

    private void updatePosition(Vec3d vec3d, LivingEntity livingentity) {
        long nowNanos = System.nanoTime();
        float f =
                this.lastFrameNanos == 0L
                        ? 0.05F
                        : MathHelper.clamp(
                                (float) (nowNanos - this.lastFrameNanos) / 1.0E9F, 0.0F, 0.08F);
        this.lastFrameNanos = nowNanos;
        Vec3d vec3d1 = this.position;
        if (this.position != null && !(this.position.squaredDistanceTo(vec3d) > 256.0)) {
            Vec3d vec3d2 = vec3d.subtract(this.position);
            double d0 = Math.sqrt(vec3d2.x * vec3d2.x + vec3d2.z * vec3d2.z);
            if (d0 > 0.24) {
                double d2 = livingentity == client.player ? 4.6 : 6.2;
                double d4 = Math.min(d0, d2 * (double) f);
                this.position =
                        this.position.add(new Vec3d(vec3d2.x / d0 * d4, 0.0, vec3d2.z / d0 * d4));
            }

            this.position = new Vec3d(this.position.x, vec3d.y, this.position.z);
        } else {
            this.position = vec3d;
        }

        double d5 = 0.0;
        if (vec3d1 != null) {
            double d1 = this.position.x - vec3d1.x;
            double d3 = this.position.z - vec3d1.z;
            d5 = Math.sqrt(d1 * d1 + d3 * d3);
        }

        float f1 =
                f <= 0.0F ? 0.0F : MathHelper.clamp((float) (d5 / (double) f) * 0.22F, 0.0F, 1.0F);
        this.walkAmplitude = MathHelper.lerp(0.2F, this.walkAmplitude, f1);
        if (this.walkAmplitude < 0.03F) {
            this.walkAmplitude = 0.0F;
        }

        this.walkPhase += (float) d5 * 9.0F;
        Vec3d vec3d3 =
                livingentity.getEntityPos().add(0.0, (double) livingentity.getHeight() * 0.45, 0.0);
        Vec3d vec3d4 = vec3d3.subtract(this.position);
        float f2 = (float) Math.toDegrees(Math.atan2(vec3d4.x, vec3d4.z));
        this.yaw = lerpAngle(this.yaw, f2, 0.2F);
    }

    @Environment(EnvType.CLIENT)
    private static record MeshGroup(Identifier texture, float[] vertices) {}

    @Environment(EnvType.CLIENT)
    private static class NanalyMesh {
        final PenguinCompanionModule.MeshGroup[] groups;
        final float centerZ;
        final float maxY;
        final float minY;

        NanalyMesh(
                PenguinCompanionModule.MeshGroup[] meshGroupArrayValue,
                float minYValue,
                float maxYValue,
                float centerZValue) {
            this.groups = meshGroupArrayValue;
            this.minY = minYValue;
            this.maxY = maxYValue;
            this.centerZ = centerZValue;
        }

        static PenguinCompanionModule.NanalyMesh decode(byte[] abyte) {
            ByteBuffer bytebuffer = ByteBuffer.wrap(abyte).order(ByteOrder.LITTLE_ENDIAN);
            byte[] values = new byte[5];
            bytebuffer.get(values);
            if (!"NMSH1".equals(new String(values, StandardCharsets.US_ASCII))) {
                throw new IllegalArgumentException("Bad Nanaly mesh magic");
            } else {
                int i = bytebuffer.getInt();
                PenguinCompanionModule.MeshGroup[] meshGroups =
                        new PenguinCompanionModule.MeshGroup[i];
                float POSITIVE_INFINITY = Float.POSITIVE_INFINITY;
                float NEGATIVE_INFINITY = Float.NEGATIVE_INFINITY;
                float POSITIVE_INFINITYValue = Float.POSITIVE_INFINITY;
                float NEGATIVE_INFINITYValue = Float.NEGATIVE_INFINITY;

                for (int j = 0; j < i; j++) {
                    int k = Short.toUnsignedInt(bytebuffer.getShort());
                    byte[] valuesValue = new byte[k];
                    bytebuffer.get(valuesValue);
                    String string = new String(valuesValue, StandardCharsets.UTF_8);
                    int l = bytebuffer.getInt();
                    float[] afloat = new float[l * 8];

                    for (int i1 = 0; i1 < afloat.length; i1++) {
                        afloat[i1] = bytebuffer.getFloat();
                    }

                    for (byte b0 = 0; b0 < afloat.length; b0 += 8) {
                        POSITIVE_INFINITYValue = Math.min(POSITIVE_INFINITYValue, afloat[b0 + 1]);
                        NEGATIVE_INFINITYValue = Math.max(NEGATIVE_INFINITYValue, afloat[b0 + 1]);
                        POSITIVE_INFINITY = Math.min(POSITIVE_INFINITY, afloat[b0 + 2]);
                        NEGATIVE_INFINITY = Math.max(NEGATIVE_INFINITY, afloat[b0 + 2]);
                    }

                    Identifier identifier = Identifier.of("client", "model_new/textures/" + string);
                    meshGroups[j] = new PenguinCompanionModule.MeshGroup(identifier, afloat);
                }

                return new PenguinCompanionModule.NanalyMesh(
                        meshGroups,
                        POSITIVE_INFINITY,
                        NEGATIVE_INFINITY,
                        (POSITIVE_INFINITYValue + NEGATIVE_INFINITYValue) * 0.5F);
            }
        }
    }
}
