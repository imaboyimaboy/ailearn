package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Environment(EnvType.CLIENT)
public final class ModuleLookup {
    private static final ConcurrentMap<Class<? extends Module>, Module> modules =
            new ConcurrentHashMap<>();

    private ModuleLookup() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static Module getModule(Class oclass) {
        return (Module)
                oclass.cast(
                        modules.computeIfAbsent(
                                oclass,
                                oclassx ->
                                        Gooba.getInstance()
                                                .getModuleRegistry()
                                                .findModule((Class<? extends Module>) oclassx)));
    }
}
