package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class Easings {
    public static final EasingFunction IN_OUT_SINE = d0 -> -(Math.cos(Math.PI * d0) - 1.0) / 2.0;
    public static final EasingFunction IN_EXPO =
            d0 -> d0 != 0.0 ? Math.pow(2.0, 10.0 * d0 - 10.0) : d0;
    public static final EasingFunction IN_BACK =
            d0 -> 2.70158 * Math.pow(d0, 3.0) - 1.70158 * Math.pow(d0, 2.0);
    public static final EasingFunction IN_CUBIC = inPower(3);
    public static final EasingFunction IN_OUT_QUAD = inOutPower(2.0);
    public static final EasingFunction OUT_BACK =
            d0 -> 1.0 + 2.70158 * Math.pow(d0 - 1.0, 3.0) + 1.70158 * Math.pow(d0 - 1.0, 2.0);
    public static final EasingFunction IN_SINE = d0 -> 1.0 - Math.cos(d0 * Math.PI / 2.0);
    public static final EasingFunction IN_OUT_BACK =
            d0 ->
                    d0 < 0.5
                            ? Math.pow(2.0 * d0, 2.0) * (7.189819 * d0 - 2.5949095) / 2.0
                            : (Math.pow(2.0 * d0 - 2.0, 2.0)
                                                    * (3.5949095 * (d0 * 2.0 - 2.0) + 2.5949095)
                                            + 2.0)
                                    / 2.0;
    public static final EasingFunction OUT_BOUNCE =
            d0 -> {
                double d1 = 7.5625;
                double d2 = 2.75;
                if (d0 < 1.0 / d2) {
                    return d1 * Math.pow(d0, 2.0);
                } else if (d0 < 2.0 / d2) {
                    return d1 * Math.pow(d0 - 1.5 / d2, 2.0) + 0.75;
                } else {
                    return d0 < 2.5 / d2
                            ? d1 * Math.pow(d0 - 2.25 / d2, 2.0) + 0.9375
                            : d1 * Math.pow(d0 - 2.625 / d2, 2.0) + 0.984375;
                }
            };
    public static final EasingFunction OUT_CUBIC = outPower(3);
    public static final EasingFunction IN_OUT_QUINT = inOutPower(5.0);
    public static final EasingFunction IN_BOUNCE = d0 -> 1.0 - OUT_BOUNCE.ease(1.0 - d0);
    public static final EasingFunction IN_QUART = inPower(4);
    public static final EasingFunction IN_QUAD = inPower(2);
    public static final EasingFunction IN_OUT_CUBIC = inOutPower(3.0);
    public static final EasingFunction IN_OUT_CIRC =
            d0 ->
                    d0 < 0.5
                            ? (1.0 - Math.sqrt(1.0 - Math.pow(2.0 * d0, 2.0))) / 2.0
                            : (Math.sqrt(1.0 - Math.pow(-2.0 * d0 + 2.0, 2.0)) + 1.0) / 2.0;
    public static final EasingFunction IN_OUT_QUART = inOutPower(4.0);
    public static final EasingFunction OUT_ELASTIC =
            d0 ->
                    d0 != 0.0 && d0 != 1.0
                            ? Math.pow(2.0, -10.0 * d0)
                                            * Math.sin((d0 * 10.0 - 0.75) * (Math.PI * 2.0 / 3.0))
                                    + 1.0
                            : d0;
    public static final EasingFunction IN_OUT_ELASTIC =
            d0 -> {
                if (d0 != 0.0 && d0 != 1.0) {
                    return d0 < 0.5
                            ? -(Math.pow(2.0, 20.0 * d0 - 10.0)
                                            * Math.sin(
                                                    (20.0 * d0 - 11.125) * (Math.PI * 4.0 / 9.0)))
                                    / 2.0
                            : Math.pow(2.0, -20.0 * d0 + 10.0)
                                            * Math.sin((20.0 * d0 - 11.125) * (Math.PI * 4.0 / 9.0))
                                            / 2.0
                                    + 1.0;
                } else {
                    return d0;
                }
            };
    public static final EasingFunction IN_OUT_BOUNCE =
            d0 ->
                    d0 < 0.5
                            ? (1.0 - OUT_BOUNCE.ease(1.0 - 2.0 * d0)) / 2.0
                            : (1.0 + OUT_BOUNCE.ease(2.0 * d0 - 1.0)) / 2.0;
    public static final EasingFunction OUT_EXPO =
            d0 -> d0 != 1.0 ? 1.0 - Math.pow(2.0, -10.0 * d0) : d0;
    public static final EasingFunction LINEAR = d0 -> d0;
    public static final EasingFunction OUT_QUART = outPower(4);
    public static final EasingFunction IN_OUT_EXPO =
            d0 -> {
                if (d0 != 0.0 && d0 != 1.0) {
                    return d0 < 0.5
                            ? Math.pow(2.0, 20.0 * d0 - 10.0) / 2.0
                            : (2.0 - Math.pow(2.0, -20.0 * d0 + 10.0)) / 2.0;
                } else {
                    return d0;
                }
            };
    public static final EasingFunction OUT_QUAD = outPower(2);
    public static final EasingFunction OUT_BACK_ALT =
            d0 -> 1.0 + 2.70158 * Math.pow(d0 - 1.0, 3.0) + 1.70158 * Math.pow(d0 - 1.0, 2.0);
    public static final EasingFunction OUT_CIRC = d0 -> Math.sqrt(1.0 - Math.pow(d0 - 1.0, 2.0));
    public static final EasingFunction IN_ELASTIC =
            d0 ->
                    d0 != 0.0 && d0 != 1.0
                            ? Math.pow(-2.0, 10.0 * d0 - 10.0)
                                    * Math.sin((d0 * 10.0 - 10.75) * (Math.PI * 2.0 / 3.0))
                            : d0;
    public static final EasingFunction OUT_SINE = d0 -> Math.sin(d0 * Math.PI / 2.0);
    public static final EasingFunction IN_CIRC = d0 -> 1.0 - Math.sqrt(1.0 - Math.pow(d0, 2.0));
    public static final EasingFunction OUT_QUINT = outPower(5);
    public static final EasingFunction IN_QUINT = inPower(5);

    public static EasingFunction inOutPower(double d0) {
        return d1 ->
                d1 < 0.5
                        ? Math.pow(2.0, d0 - 1.0) * Math.pow(d1, d0)
                        : 1.0 - Math.pow(-2.0 * d1 + 2.0, d0) / 2.0;
    }

    public static EasingFunction outPower(int i) {
        return outPower((double) i);
    }

    public static EasingFunction outPower(double d0) {
        return d2 -> 1.0 - Math.pow(1.0 - d2, d0);
    }

    public static EasingFunction inPower(int i) {
        return inPower((double) i);
    }

    public static EasingFunction inPower(double d0) {
        return d2 -> Math.pow(d2, d0);
    }

    private Easings() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }
}
