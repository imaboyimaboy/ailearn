package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.jetbrains.annotations.NotNull;

@Environment(EnvType.CLIENT)
public record BorderRadius(
        float topLeftRadius,
        float topRightRadius,
        float bottomRightRadius,
        float bottomLeftRadius) {
    public static final BorderRadius borderRadius = new BorderRadius(0.0F, 0.0F, 0.0F, 0.0F);

    @NotNull
    @Override
    public String toString() {
        float bottomLeftRadiusValue = this.bottomLeftRadius;
        float bottomRightRadiusValue = this.bottomRightRadius;
        float topRightRadiusValue = this.topRightRadius;
        float topLeftRadiusValue = this.topLeftRadius;
        return "BorderRadius{topLeftRadius="
                + topLeftRadiusValue
                + ", topRightRadius="
                + topRightRadiusValue
                + ", bottomRightRadius="
                + bottomRightRadiusValue
                + ", bottomLeftRadius="
                + bottomLeftRadiusValue
                + "}";
    }
}
