package dev.gooba.client;

import dev.gooba.client.mixin.SpriteContentsMixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.Sprite;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class StringListSetting extends Setting<List<String>> {
    private static final Map<String, Integer> defaultColors = new HashMap<>();
    private static String[] searchIndex;
    private static List<String> allBlockIds;
    private static final Map<String, String> displayNames = new HashMap<>();

    private final Map<String, ColorSetting> colorSettings;
    private final List<String> allowedBlockIds;
    public String searchQuery = "";

    public int getBlockColor(String text) {
        ColorSetting colorSetting4 = this.colorSettings.get(text);
        return colorSetting4 == null ? getDefaultBlockColor(text) : colorSetting4.getColor();
    }

    public Map<String, ColorSetting> getColorSettings() {
        return this.colorSettings;
    }

    private static int computeBlockColor(String text) {
        Identifier identifier = Identifier.tryParse(text);
        if (identifier != null) {
            Optional optional = Registries.BLOCK.getOptionalValue(identifier);
            if (optional.isPresent()) {
                int color = ((Block) optional.get()).getDefaultMapColor().color;
                ItemStack itemstack = new ItemStack(((Block) optional.get()).asItem());
                Sprite sprite = ItemIconRenderer.resolveSprite(itemstack);
                if (sprite != null) {
                    NativeImage[] anativeimage =
                            ((SpriteContentsMixin) sprite.getContents())
                                    .goobaa$getMipmapLevelsImages();
                    if (anativeimage != null
                            && anativeimage.length > 0
                            && anativeimage[0] != null) {
                        int j = averageTextureColor(anativeimage[0]);
                        if (j != 0) {
                            return j;
                        }
                    }
                }

                if (color != 0) {
                    return 0xFF000000 | color & 16777215;
                }
            }
        }

        return -11184811;
    }

    public static List<String> getAllBlockIds() {
        if (allBlockIds == null) {
            initializeBlockCatalog();
        }

        return allBlockIds;
    }

    private static void initializeBlockCatalog() {
        ArrayList<String> arraylist = new ArrayList<>();

        label43:
        {
            Iterator iterator;
            try {
                iterator = Registries.BLOCK.getIds().iterator();
            } catch (Exception exceptionValue) {
                break label43;
            }

            while (true) {
                try {
                    if (!iterator.hasNext()) {
                        break;
                    }
                } catch (Exception exception5) {
                    break;
                }

                try {
                    Identifier identifier = (Identifier) iterator.next();
                    arraylist.add(identifier.toString());
                } catch (Exception exception6) {
                    break;
                }
            }
        }

        arraylist.sort(
                (text, textValue) -> {
                    try {
                        return resolveBlockName(text)
                                .compareToIgnoreCase(resolveBlockName(textValue));
                    } catch (Exception exception7) {
                        return text.compareTo(textValue);
                    }
                });
        String[] astring = new String[arraylist.size()];

        for (int i = 0; i < arraylist.size(); i++) {
            String text2 = (String) arraylist.get(i);

            String text3;
            try {
                text3 = resolveBlockName(text2);
            } catch (Exception exception) {
                text3 = removeNamespace(text2);
            }

            displayNames.put(text2, text3);
            String text4 = removeNamespace(text2);
            astring[i] = (text4 + " " + text3 + " " + text2).toLowerCase();
        }

        searchIndex = astring;
        allBlockIds = arraylist;
    }

    public List<String> getSelectedIds() {
        return (List<String>) this.getValue();
    }

    private static int averageTextureColor(NativeImage nativeimage) {
        float f = 0.0F;

        for (int i = 0; i < nativeimage.getHeight(); i++) {
            for (int j = 0; j < nativeimage.getWidth(); j++) {
                int colorArgb = nativeimage.getColorArgb(j, i);
                if (colorArgb >>> 24 >= 32) {
                    float[] afloat =
                            Color.RGBtoHSB(
                                    colorArgb >> 16 & 0xFF,
                                    colorArgb >> 8 & 0xFF,
                                    colorArgb & 0xFF,
                                    null);
                    f = Math.max(f, afloat[1]);
                }
            }
        }

        boolean flag;
        flag = (f >= 0.18F);

        float f1 = Math.max(0.12F, f * 0.55F);
        double d4 = 0.0;
        double d0 = 0.0;
        double d1 = 0.0;
        double d2 = 0.0;

        for (int l = 0; l < nativeimage.getHeight(); l++) {
            for (int i1 = 0; i1 < nativeimage.getWidth(); i1++) {
                int colorArgbValue = nativeimage.getColorArgb(i1, l);
                int k1 = colorArgbValue >>> 24;
                if (k1 >= 32) {
                    int l1 = colorArgbValue >> 16 & 0xFF;
                    int i2 = colorArgbValue >> 8 & 0xFF;
                    int j2 = colorArgbValue & 0xFF;
                    float[] values = Color.RGBtoHSB(l1, i2, j2, null);
                    if (!flag || !(values[1] < f1)) {
                        double d3 = (double) k1 / 255.0;
                        if (flag) {
                            d3 *=
                                    (0.35 + (double) (values[1] * values[1]) * 4.0)
                                            * (0.65 + (double) values[2] * 0.35);
                        }

                        d4 += (double) l1 * d3;
                        d0 += (double) i2 * d3;
                        d1 += (double) j2 * d3;
                        d2 += d3;
                    }
                }
            }
        }

        if (d2 <= 0.0) {
            return 0;
        } else {
            int k2 = Math.max(0, Math.min(255, (int) Math.round(d4 / d2)));
            int l2 = Math.max(0, Math.min(255, (int) Math.round(d0 / d2)));
            int i3 = Math.max(0, Math.min(255, (int) Math.round(d1 / d2)));
            return 0xFF000000 | k2 << 16 | l2 << 8 | i3;
        }
    }

    public static String normalizeBlockId(String text) {
        if (text == null) {
            return null;
        } else {
            String textValue = text.trim().toLowerCase();
            if (textValue.isEmpty()) {
                return null;
            } else {
                if (!textValue.contains(":")) {
                    textValue = "minecraft:" + textValue;
                }

                Identifier identifier = Identifier.tryParse(textValue);
                return identifier != null && Registries.BLOCK.containsId(identifier)
                        ? textValue
                        : null;
            }
        }
    }

    public StringListSetting(Module moduleValue, String nameValue) {
        super(moduleValue, nameValue, new ArrayList<>());
        this.colorSettings = new LinkedHashMap<>();
        this.allowedBlockIds = null;
    }

    public StringListSetting visibleWhen(Supplier supplier) {
        return (StringListSetting) super.visibleWhen(supplier);
    }

    public void removeBlock(String text) {
        ((List) this.getValue()).remove(text);
    }

    public boolean addBlock(String text) {
        String stringValue = normalizeBlockId(text);
        if (stringValue == null
                || ((List) this.getValue()).contains(stringValue)
                || this.allowedBlockIds != null && !this.allowedBlockIds.contains(stringValue)) {
            return false;
        } else {
            ((List) this.getValue()).add(stringValue);
            return true;
        }
    }

    private static String resolveBlockName(String text) {
        Identifier identifier = Identifier.tryParse(text);
        if (identifier != null) {
            Optional optional = Registries.BLOCK.getOptionalValue(identifier);
            if (optional.isPresent()) {
                return ((Block) optional.get()).getName().getString();
            }
        }

        return removeNamespace(text);
    }

    public List<String> searchBlocks(String text) {
        String textValue;
        if (text == null) {
            textValue = "";
        } else {
            textValue = text.trim().toLowerCase();
        }

        if (textValue.isEmpty()) {
            return this.getAvailableBlockIds();
        } else {
            ArrayList arraylist = new ArrayList();

            for (String text2 : this.getAvailableBlockIds()) {
                String blockName = getBlockName(text2);
                String text3 = removeNamespace(text2);
                String text4 = (text3 + " " + blockName + " " + text2).toLowerCase();
                if (text4.contains(textValue)) {
                    arraylist.add(text2);
                }
            }

            return arraylist;
        }
    }

    public StringListSetting(
            Module moduleValue,
            String nameValue,
            Collection<String> collection,
            Collection<String> collectionValue) {
        super(moduleValue, nameValue, new ArrayList<>());
        this.colorSettings = new LinkedHashMap<>();
        ArrayList arraylist = new ArrayList();

        for (String text : collection) {
            String stringValue = normalizeBlockId(text);
            if (stringValue != null && !arraylist.contains(stringValue)) {
                arraylist.add(stringValue);
            }
        }

        this.allowedBlockIds = Collections.unmodifiableList(arraylist);

        for (String textValue : collectionValue) {
            this.addBlock(textValue);
        }
    }

    public static String getBlockName(String text) {
        return displayNames.computeIfAbsent(text, StringListSetting::resolveBlockName);
    }

    public static int getDefaultBlockColor(String text) {
        return defaultColors.computeIfAbsent(text, StringListSetting::computeBlockColor);
    }

    public static String removeNamespace(String text) {
        int i = text.indexOf(58);
        return i >= 0 ? text.substring(i + 1) : text;
    }

    public List<String> getAvailableBlockIds() {
        return this.allowedBlockIds == null ? getAllBlockIds() : this.allowedBlockIds;
    }

    public Set<Block> getSelectedBlocks() {
        HashSet hashset = new HashSet();

        for (String text : (Iterable<String>) (Iterable) (List) this.getValue()) {
            Identifier identifier = Identifier.tryParse(text);
            if (identifier != null) {
                Registries.BLOCK.getOptionalValue(identifier).ifPresent(hashset::add);
            }
        }

        return hashset;
    }

    public ColorSetting getOrCreateColorSetting(String text) {
        return this.colorSettings.computeIfAbsent(
                text, sx -> new ColorSetting(getBlockName(sx), getDefaultBlockColor(sx)));
    }
}
