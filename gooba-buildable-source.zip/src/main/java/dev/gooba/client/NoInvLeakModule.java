package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "No Inv Leak",
        category = ModuleCategory.OTHER,
        desc =
                "Replaces all inventory item textures with Totem of Undying. Items held in-hand"
                    + " still show normally.")
@Environment(EnvType.CLIENT)
public class NoInvLeakModule extends Module {
    private static NoInvLeakModule noInvLeakModule;

    public NoInvLeakModule() {
        noInvLeakModule = this;
    }

    public static NoInvLeakModule getInstance() {
        return noInvLeakModule;
    }
}
