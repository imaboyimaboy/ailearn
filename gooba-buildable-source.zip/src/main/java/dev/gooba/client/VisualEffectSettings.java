package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class VisualEffectSettings {
    public static final float[] MAX_VALUES = new float[] {1.0F, 6.0F};
    public final int[] colors = new int[8];
    public static final float[] DEFAULT_VALUES = new float[] {1.0F, 0.0F};
    public final float[] values = new float[2];
    public final boolean[] enabledEffects;
    public static final boolean[] DEFAULT_EFFECTS = new boolean[2];
    public static final float[] MIN_VALUES = new float[] {0.1F, 0.0F};
    public String name;

    public static final float[] VALUE_STEPS = new float[] {0.0F, 1.0F};
    public static final String[] EFFECT_NAMES = new String[] {"Shadow effect", "Distortion effect"};
    public boolean builtIn;

    public float getValue(int i) {
        return clampValue(i, this.values[i]);
    }

    public VisualEffectSettings(String nameValue) {
        this.enabledEffects = new boolean[EFFECT_NAMES.length];
        this.builtIn = false;
        this.name = nameValue;
        this.colors[0] = rgb(92, 160, 245);
        this.colors[1] = rgb(20, 23, 32);
        this.colors[2] = -1;
        this.colors[3] = -1;
        this.colors[4] = -1;
        this.colors[5] = rgb(118, 142, 203);
        this.colors[6] = -1;
        this.colors[7] = -15066592;
        System.arraycopy(DEFAULT_VALUES, 0, this.values, 0, this.values.length);
        System.arraycopy(DEFAULT_EFFECTS, 0, this.enabledEffects, 0, this.enabledEffects.length);
    }

    public int getColor(int i) {
        return this.colors[i];
    }

    private static float clampValue(int i, float f) {
        float f1 = VALUE_STEPS[i];
        if (f1 > 0.0F) {
            f = (float) Math.round(f / f1) * f1;
        }

        if (f < MIN_VALUES[i]) {
            return MIN_VALUES[i];
        } else {
            return f > MAX_VALUES[i] ? MAX_VALUES[i] : f;
        }
    }

    public boolean isEffectEnabled(int i) {
        return this.enabledEffects[i];
    }

    public void setValue(int i, float f) {
        this.values[i] = clampValue(i, f);
    }

    public static int rgb(int i, int j, int k) {

        return -16777216 | (i & 255) << 16 | (j & 255) << 8 | k & 255;
    }

    public void setEffectEnabled(int i, boolean enabledEffect) {
        this.enabledEffects[i] = enabledEffect;
    }
}
