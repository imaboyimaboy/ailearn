package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class BlockListSetting extends Setting<List<BlockListSetting.Entry>> {

    private final Set<String> blockIds;

    public BlockListSetting(
            Module moduleValue,
            String nameValue,
            Collection<BlockListSetting.Entry> collection,
            Collection<String> collectionValue) {
        super(moduleValue, nameValue, new ArrayList<>());
        HashSet hashset = new HashSet();
        if (collectionValue != null) {
            for (String text : collectionValue) {
                if (text != null && !text.isBlank()) {
                    hashset.add(text.toLowerCase());
                }
            }
        }

        this.blockIds = Collections.unmodifiableSet(hashset);
        this.setEntries(collection);
    }

    public List<BlockListSetting.Entry> getEntries() {
        return Collections.unmodifiableList(
                (List<? extends BlockListSetting.Entry>) this.getValue());
    }

    public void setEntries(Collection<BlockListSetting.Entry> collection) {
        ((List) this.getValue()).clear();
        if (collection != null) {
            for (BlockListSetting.Entry entry : collection) {
                if (entry != null
                        && entry.getBlockId() != null
                        && !entry.getBlockId().trim().isEmpty()) {
                    ((List) this.getValue()).add(entry);
                }
            }
        }
    }

    private static boolean matchesBlockId(String text, BlockListSetting.Entry entry, int i) {
        return text.equalsIgnoreCase(entry.getBlockId());
    }

    private static boolean matchesEntryBlockId(String text, BlockListSetting.Entry entry, int i) {
        return text.equalsIgnoreCase(entry.getBlockId());
    }

    public BlockListSetting(
            Module moduleValue, String nameValue, Collection<BlockListSetting.Entry> collection) {
        this(moduleValue, nameValue, collection, List.of());
    }

    static {
    }

    public BlockListSetting visibleWhen(Supplier supplier) {
        return (BlockListSetting) super.visibleWhen(supplier);
    }

    @Environment(EnvType.CLIENT)
    public static record Entry(String blockId, int color) {
        public String getBlockId() {
            return this.blockId;
        }

        public Block getBlock() {
            try {
                Identifier identifier = Identifier.tryParse(this.blockId);
                if (identifier == null) {
                    return null;
                } else {
                    return !Registries.BLOCK.containsId(identifier)
                            ? null
                            : Registries.BLOCK.get(identifier);
                }
            } catch (Exception exception) {
                return null;
            }
        }
    }

    public BlockListSetting(Module moduleValue, String nameValue) {
        this(moduleValue, nameValue, List.of());
    }
}
