package dev.gooba.client;

import it.unimi.dsi.fastutil.chars.Char2IntArrayMap;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

@Environment(EnvType.CLIENT)
public final class ColorUtils {
    private static final DelayQueue<ColorUtils.CacheEntry> expiredColors = new DelayQueue<>();
    private static final ScheduledExecutorService cacheCleaner =
            Executors.newScheduledThreadPool(1);
    private static final ConcurrentHashMap<ColorUtils.ColorKey, ColorUtils.CacheEntry> colorCache =
            new ConcurrentHashMap<>();
    public static final int BLACK = opaqueGrayscale(0);
    public static final int WHITE = opaqueGrayscale(255);
    public static final int GREEN = rgb(0, 255, 0);
    public static final int RED = rgb(255, 0, 0);
    public static final int YELLOW = rgb(255, 255, 0);
    public static final Pattern formattingCodePattern = Pattern.compile("(?i)§[0-9a-f-or]");
    public static final int BLUE = rgb(0, 0, 255);
    public static Char2IntArrayMap legacyFormattingColors =
            new Char2IntArrayMap() {
                {
                    this.put('0', 0);
                    this.put('1', 170);
                    this.put('2', 43520);
                    this.put('3', 43690);
                    this.put('4', 11141120);
                    this.put('5', 11141290);
                    this.put('6', 16755200);
                    this.put('7', 11184810);
                    this.put('8', 5592405);
                    this.put('9', 5592575);
                    this.put('A', 5635925);
                    this.put('B', 5636095);
                    this.put('C', 16733525);
                    this.put('D', 16733695);
                    this.put('E', 16777045);
                    this.put('F', 16777215);
                }
            };

    public static int interpolate(int startColor, int endColor, float progress) {
        float f1 = MathHelper.clamp(progress, 0.0F, 1.0F);
        return rgba(
                (Integer)
                        NumberInterpolation.getNumber(red(startColor), red(endColor), (double) f1),
                (Integer)
                        NumberInterpolation.getNumber(
                                green(startColor), green(endColor), (double) f1),
                (Integer)
                        NumberInterpolation.getNumber(
                                blue(startColor), blue(endColor), (double) f1),
                (Integer)
                        NumberInterpolation.getNumber(
                                alpha(startColor), alpha(endColor), (double) f1));
    }

    public static int grayscale(int brightness, int alpha) {
        return cachedRgba(brightness, brightness, brightness, alpha);
    }

    public static int withRawAlpha(int color, float alpha) {
        int red = color >> 16 & 0xFF;
        int green = color >> 8 & 0xFF;
        int blue = color & 0xFF;
        return packRgba(red, green, blue, (int) alpha);
    }

    public static int opaqueGrayscale(int brightness) {
        return rgb(brightness, brightness, brightness);
    }

    private static ThemePreset getPreviousTheme() {
        return ClickGuiScreen.themePreset2 != null
                ? ClickGuiScreen.themePreset2
                : ThemePreset.Purple;
    }

    public static int withOpacity(int color, float opacity) {
        return rgba(red(color), green(color), blue(color), Math.round(opacity * 255.0F));
    }

    public static int[] repeatEight(int color) {
        return new int[] {color, color, color, color, color, color, color, color};
    }

    public static float alphaFloat(int color) {
        return (float) alpha(color) / 255.0F;
    }

    static {
        cacheCleaner.scheduleWithFixedDelay(
                () -> {
                    for (ColorUtils.CacheEntry cacheEntry = expiredColors.poll();
                            cacheEntry != null;
                            cacheEntry = expiredColors.poll()) {
                        if (cacheEntry.isExpired()) {
                            colorCache.remove(cacheEntry.getColorKey());
                        }
                    }
                },
                0L,
                1L,
                TimeUnit.SECONDS);
    }

    public static int rgba(int red, int green, int blue, int alpha) {
        return MathHelper.clamp(alpha, 0, 255) << 24
                | MathHelper.clamp(red, 0, 255) << 16
                | MathHelper.clamp(green, 0, 255) << 8
                | MathHelper.clamp(blue, 0, 255);
    }

    public static int grayscaleOpacity(int brightness, float opacity) {
        return grayscale(brightness, Math.round(opacity * 255.0F));
    }

    public static int withAlpha(int color, int alpha) {
        return rgba(red(color), green(color), blue(color), alpha);
    }

    public static int themeBackground() {
        ThemePreset themePreset3 = getCurrentTheme();
        ThemePreset themePreset4 = getPreviousTheme();
        return interpolateDouble(
                themePreset3.getBackgroundColor(),
                themePreset4.getBackgroundColor(),
                (double) (1.0F - ClickGuiScreen.timedAnimation.getValue()));
    }

    public static float blueFloat(int color) {
        return (float) blue(color) / 255.0F;
    }

    public static int blue(int color) {
        return color & 0xFF;
    }

    public static int themeAccent() {
        ThemePreset themePreset3 = getCurrentTheme();
        ThemePreset themePreset4 = getPreviousTheme();
        return interpolateDouble(
                themePreset3.getAccentColor(),
                themePreset4.getAccentColor(),
                (double) (1.0F - ClickGuiScreen.timedAnimation.getValue()));
    }

    public static String stripFormatting(String text) {
        return text != null && !text.isEmpty()
                ? formattingCodePattern.matcher(text).replaceAll("")
                : null;
    }

    private static ThemePreset getCurrentTheme() {
        return ClickGuiScreen.themePreset != null ? ClickGuiScreen.themePreset : ThemePreset.Purple;
    }

    public static float redFloat(int color) {
        return (float) red(color) / 255.0F;
    }

    public static int green(int color) {
        return color >> 8 & 0xFF;
    }

    public static int hudBackground(float f) {
        return withOpacity(
                ThemeColors.getBackgroundColor(), f * LegacyHudModule.backgroundOpacity());
    }

    public static float greenFloat(int color) {
        return (float) green(color) / 255.0F;
    }

    private ColorUtils() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static int oscillate(int periodMillis, int phase, int startColor, int endColor) {
        int i11 = (int) ((System.currentTimeMillis() / (long) periodMillis + (long) phase) % 360L);
        i11 = i11 >= 180 ? 360 - i11 : i11;
        return interpolate(startColor, endColor, (float) i11 / 180.0F);
    }

    public static int interpolateAwt(int startColor, int endColor, float progress) {
        progress = MathHelper.clamp(progress, 0.0F, 1.0F);
        Color color = new Color(startColor, true);
        Color colorValue = new Color(endColor, true);
        int k =
                (int)
                        ((float) color.getRed()
                                + (float) (colorValue.getRed() - color.getRed()) * progress);
        int l =
                (int)
                        ((float) color.getGreen()
                                + (float) (colorValue.getGreen() - color.getGreen()) * progress);
        int i11 =
                (int)
                        ((float) color.getBlue()
                                + (float) (colorValue.getBlue() - color.getBlue()) * progress);
        int j1 =
                (int)
                        ((float) color.getAlpha()
                                + (float) (colorValue.getAlpha() - color.getAlpha()) * progress);
        return new Color(k, l, i11, j1).getRGB();
    }

    public static int multiplyAlpha(int color, float factor) {
        int j = color >> 24 & 0xFF;
        int k = (int) ((float) j * factor);
        k = Math.max(0, Math.min(255, k));
        return color & 16777215 | k << 24;
    }

    public static int cachedRgba(int red, int green, int blue, int alpha) {
        ColorUtils.ColorKey colorKey = new ColorUtils.ColorKey(red, green, blue, alpha);
        ColorUtils.CacheEntry cacheEntryValue =
                colorCache.computeIfAbsent(
                        colorKey,
                        colorKeyValue -> {
                            ColorUtils.CacheEntry cacheEntry =
                                    new ColorUtils.CacheEntry(
                                            colorKeyValue,
                                            packClampedRgba(red, green, blue, alpha),
                                            60000L);
                            expiredColors.offer(cacheEntry);
                            return cacheEntry;
                        });
        return cacheEntryValue.getColor();
    }

    public static int animatedAccent(int phase) {
        return oscillate(10, phase, hudAccent(), brighten(hudAccent(), 0.75F));
    }

    public static int cachedRgbaOpacity(int red, int green, int blue, float opacity) {
        return cachedRgba(red, green, blue, Math.round(opacity * 255.0F));
    }

    public static int rgb(int red, int green, int blue) {
        return cachedRgba(red, green, blue, 255);
    }

    public static int darken(int color, float factor) {
        return rgba(
                Math.round((float) red(color) * factor),
                Math.round((float) green(color) * factor),
                Math.round((float) blue(color) * factor),
                alpha(color));
    }

    public static int interpolateDouble(int startColor, int endColor, double progress) {
        progress = (double) ((float) MathHelper.clamp(progress, 0.0, 1.0));
        return rgba(
                (Integer) NumberInterpolation.getNumber(red(startColor), red(endColor), progress),
                (Integer)
                        NumberInterpolation.getNumber(green(startColor), green(endColor), progress),
                (Integer) NumberInterpolation.getNumber(blue(startColor), blue(endColor), progress),
                (Integer)
                        NumberInterpolation.getNumber(
                                alpha(startColor), alpha(endColor), progress));
    }

    public static int saturatedGradient(int startColor, int endColor, int phase, int periodMillis) {
        int i11 = (int) ((System.currentTimeMillis() / (long) periodMillis + (long) phase) % 360L);
        i11 = (i11 > 180 ? 360 - i11 : i11) + 180;
        int color =
                interpolateDouble(
                        startColor,
                        endColor,
                        (double) MathHelper.clamp((float) i11 / 180.0F - 1.0F, 0.0F, 1.0F));
        float[] afloat = normalizedRgba(color);
        float[] values =
                Color.RGBtoHSB(
                        (int) (afloat[0] * 255.0F),
                        (int) (afloat[1] * 255.0F),
                        (int) (afloat[2] * 255.0F),
                        null);
        values[1] *= 1.5F;
        values[1] = Math.min(values[1], 1.0F);
        return Color.HSBtoRGB(values[0], values[1], values[2]);
    }

    public static int alpha(int color) {
        return color >> 24 & 0xFF;
    }

    public static int brighten(int color, float factor) {
        return rgba(
                Math.min(255, Math.round((float) red(color) / factor)),
                Math.min(255, Math.round((float) green(color) / factor)),
                Math.min(255, Math.round((float) blue(color) / factor)),
                alpha(color));
    }

    public static int red(int color) {
        return color >> 16 & 0xFF;
    }

    private static int packClampedRgba(int red, int green, int blue, int alpha) {
        return MathHelper.clamp(alpha, 0, 255) << 24
                | MathHelper.clamp(red, 0, 255) << 16
                | MathHelper.clamp(green, 0, 255) << 8
                | MathHelper.clamp(blue, 0, 255);
    }

    public static int[] repeatNine(int color) {
        return new int[] {color, color, color, color, color, color, color, color, color};
    }

    public static int packRgba(int red, int green, int blue, int alpha) {
        int i11 = 0;
        i11 |= alpha << 24;
        i11 |= red << 16;
        i11 |= green << 8;
        int j1;
        return j1 = i11 | blue;
    }

    public static int themeElement() {
        ThemePreset themePreset3 = getCurrentTheme();
        ThemePreset themePreset4 = getPreviousTheme();
        return interpolateDouble(
                themePreset3.getElementColor(),
                themePreset4.getElementColor(),
                (double) (1.0F - ClickGuiScreen.timedAnimation.getValue()));
    }

    public static float[] normalizedRgba(int color) {
        return new float[] {
            (float) (color >> 16 & 0xFF) / 255.0F,
            (float) (color >> 8 & 0xFF) / 255.0F,
            (float) (color & 0xFF) / 255.0F,
            (float) (color >> 24 & 0xFF) / 255.0F
        };
    }

    public static int scaleAlpha(int color, float factor) {
        return rgba(
                red(color), green(color), blue(color), Math.round((float) alpha(color) * factor));
    }

    public static int hudAccent() {
        return LegacyHudModule.accentColor();
    }

    @Environment(EnvType.CLIENT)
    private static class CacheEntry implements Delayed {
        private final int color;
        private final ColorUtils.ColorKey colorKey;
        private final long expiresAtMillis;

        public int getColor() {
            return this.color;
        }

        public boolean isExpired() {
            return System.currentTimeMillis() > this.expiresAtMillis;
        }

        public ColorUtils.ColorKey getColorKey() {
            return this.colorKey;
        }

        @Override
        public long getDelay(TimeUnit timeunit) {
            long i = this.expiresAtMillis - System.currentTimeMillis();
            return timeunit.convert(i, TimeUnit.MILLISECONDS);
        }

        CacheEntry(ColorUtils.ColorKey colorKeyValue, int colorValue, long j) {
            this.colorKey = colorKeyValue;
            this.color = colorValue;
            this.expiresAtMillis = System.currentTimeMillis() + j;
        }

        @Override
        public int compareTo(Delayed delayed) {
            return delayed instanceof ColorUtils.CacheEntry
                    ? Long.compare(
                            this.expiresAtMillis, ((ColorUtils.CacheEntry) delayed).expiresAtMillis)
                    : 0;
        }
    }

    @Environment(EnvType.CLIENT)
    private static class ColorKey {
        final int red;
        final int blue;
        final int green;
        final int alpha;

        @Override
        public boolean equals(Object object) {
            if (object == this) {
                return true;
            } else if (!(object instanceof ColorUtils.ColorKey colorKey)) {
                return false;
            } else if (!colorKey.canEqual(this)) {
                return false;
            } else if (this.getRed() != colorKey.getRed()) {
                return false;
            } else if (this.getGreen() != colorKey.getGreen()) {
                return false;
            } else {
                return this.getBlue() != colorKey.getBlue()
                        ? false
                        : this.getAlpha() == colorKey.getAlpha();
            }
        }

        protected boolean canEqual(Object object) {
            return object instanceof ColorUtils.ColorKey;
        }

        public ColorKey(int redValue, int greenValue, int blueValue, int alphaValue) {
            this.red = redValue;
            this.green = greenValue;
            this.blue = blueValue;
            this.alpha = alphaValue;
        }

        public int getBlue() {
            return this.blue;
        }

        public int getGreen() {
            return this.green;
        }

        @Override
        public int hashCode() {
            int i = 1;
            i = i * 59 + this.getRed();
            i = i * 59 + this.getGreen();
            i = i * 59 + this.getBlue();
            return i * 59 + this.getAlpha();
        }

        public int getRed() {
            return this.red;
        }

        public int getAlpha() {
            return this.alpha;
        }
    }
}
