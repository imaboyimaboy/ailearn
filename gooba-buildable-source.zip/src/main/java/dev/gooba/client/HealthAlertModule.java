package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.joml.Matrix3x2fStack;

@ModuleInfo(
        name = "Health Alert",
        category = ModuleCategory.RENDER,
        desc = "Displays a warning effect when your health falls below the selected value")
@Environment(EnvType.CLIENT)
public class HealthAlertModule extends Module {
    public EasingAnimation reservedPulseAnimation;
    public EasingAnimation alertOpacityAnimation;
    public EasingAnimation reservedHealthAnimation;
    public SliderSetting healthThresholdSetting =
            new SliderSetting(this, "Health Threshold", 5.0F, 1.0F, 15.0F, 1.0F);

    public HealthAlertModule() {
        this.alertOpacityAnimation = new EasingAnimation();
        this.reservedHealthAnimation = new EasingAnimation();
        this.reservedPulseAnimation = new EasingAnimation();
    }

    @EventHandler
    public void onRender2D(Render2DEvent render2DEvent) {
        Matrix3x2fStack matrix3x2fstack = render2DEvent.getDrawContext().getMatrices();
        matrix3x2fstack.pushMatrix();
        if (client.player != null && client.world != null) {
            float f = client.player.getHealth() + client.player.getAbsorptionAmount();
            boolean flag = false;
            if (f < this.healthThresholdSetting.getFloat()) {
                flag = true;
            }

            this.alertOpacityAnimation.update();
            this.alertOpacityAnimation.animateTo(flag ? 1.0 : 0.0, 0.15F, Easings.OUT_SINE);
            if (this.alertOpacityAnimation.getFloatValue() > 0.0F) {
                float f1 =
                        (float)
                                (0.6F
                                        + 0.15F
                                                * Math.sin(
                                                        (double) System.currentTimeMillis()
                                                                / 150.0));
                float f2 =
                        (float)
                                (0.0
                                        + 0.2F
                                                * Math.sin(
                                                        (double) System.currentTimeMillis()
                                                                / 300.0));
                RenderUtils.Render2D.drawRoundedGradient(
                        0.0F,
                        0.0F,
                        (float) client.getWindow().getScaledWidth(),
                        (float) client.getWindow().getScaledHeight(),
                        new int[] {
                            ColorUtils.grayscaleOpacity(
                                    0, f1 * this.alertOpacityAnimation.getFloatValue()),
                            0,
                            0,
                            0
                        },
                        0.0F);
                RenderUtils.Render2D.drawRoundedGradient(
                        0.0F,
                        0.0F,
                        (float) client.getWindow().getScaledWidth(),
                        (float) client.getWindow().getScaledHeight(),
                        new int[] {
                            0,
                            ColorUtils.grayscaleOpacity(
                                    0, f1 * this.alertOpacityAnimation.getFloatValue()),
                            0,
                            0
                        },
                        0.0F);
                RenderUtils.Render2D.drawRoundedGradient(
                        0.0F,
                        0.0F,
                        (float) client.getWindow().getScaledWidth(),
                        (float) client.getWindow().getScaledHeight(),
                        new int[] {
                            0,
                            0,
                            ColorUtils.grayscaleOpacity(
                                    0, f1 * this.alertOpacityAnimation.getFloatValue()),
                            0
                        },
                        0.0F);
                RenderUtils.Render2D.drawRoundedGradient(
                        0.0F,
                        0.0F,
                        (float) client.getWindow().getScaledWidth(),
                        (float) client.getWindow().getScaledHeight(),
                        new int[] {
                            0,
                            0,
                            0,
                            ColorUtils.grayscaleOpacity(
                                    0, f1 * this.alertOpacityAnimation.getFloatValue())
                        },
                        0.0F);
                RenderUtils.Render2D.drawRoundedGradient(
                        0.0F,
                        0.0F,
                        (float) client.getWindow().getScaledWidth(),
                        (float) client.getWindow().getScaledHeight(),
                        new int[] {
                            ColorUtils.cachedRgbaOpacity(
                                    255, 0, 0, f2 * this.alertOpacityAnimation.getFloatValue()),
                            0,
                            0,
                            0
                        },
                        0.0F);
                RenderUtils.Render2D.drawRoundedGradient(
                        0.0F,
                        0.0F,
                        (float) client.getWindow().getScaledWidth(),
                        (float) client.getWindow().getScaledHeight(),
                        new int[] {
                            0,
                            ColorUtils.cachedRgbaOpacity(
                                    255, 0, 0, f2 * this.alertOpacityAnimation.getFloatValue()),
                            0,
                            0
                        },
                        0.0F);
                RenderUtils.Render2D.drawRoundedGradient(
                        0.0F,
                        0.0F,
                        (float) client.getWindow().getScaledWidth(),
                        (float) client.getWindow().getScaledHeight(),
                        new int[] {
                            0,
                            0,
                            ColorUtils.cachedRgbaOpacity(
                                    255, 0, 0, f2 * this.alertOpacityAnimation.getFloatValue()),
                            0
                        },
                        0.0F);
                RenderUtils.Render2D.drawRoundedGradient(
                        0.0F,
                        0.0F,
                        (float) client.getWindow().getScaledWidth(),
                        (float) client.getWindow().getScaledHeight(),
                        new int[] {
                            0,
                            0,
                            0,
                            ColorUtils.cachedRgbaOpacity(
                                    255, 0, 0, f2 * this.alertOpacityAnimation.getFloatValue())
                        },
                        0.0F);
            }
        }

        matrix3x2fstack.popMatrix();
    }
}
