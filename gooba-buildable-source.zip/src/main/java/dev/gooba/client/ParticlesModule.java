package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap.Type;

import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

@ModuleInfo(
        name = "Particles",
        desc =
                "Spawns customizable particles for attacks, totem pops, throws, movement, and the"
                    + " world",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class ParticlesModule extends Module {
    public BooleanSetting onTotemPopSetting;
    public static final Function<Identifier, RenderLayer> particleLayer =
            Util.memoize(
                    identifier -> {
                        RenderSetup rendersetup =
                                RenderSetup.builder(ParticlesModule.PARTICLE_PIPELINE)
                                        .texture("Sampler0", identifier)
                                        .translucent()
                                        .expectedBufferSize(1536)
                                        .build();
                        return RenderLayer.of("wtex", rendersetup);
                    });
    public BooleanSetting ambientParticlesSetting;
    private long lastFrameNanos;
    private long totemStartedMillis;
    public BooleanSetting whileMovingSetting;
    public SliderSetting ambientParticleCountSetting;
    private final ModeSetting particleTypeSetting;
    public SliderSetting throwParticleCountSetting;
    public final List<ParticlesModule.Particle> ambientParticles;
    private static final Vector3f normal = new Vector3f(0.0F, 0.0F, 1.0F);
    public final List<ParticlesModule.Particle> totemParticles;
    public SliderSetting totemParticleCountSetting;
    public BooleanSetting rotationSetting;
    public SliderSetting attackParticleCountSetting;
    private final SliderSetting glowStrengthSetting;
    public BooleanSetting onProjectileThrowSetting;
    public final List<ParticlesModule.Particle> attackParticles;
    private int totemTotalCount;
    private final SliderSetting sizeSetting;
    public BooleanSetting glowSetting;
    private final BufferAllocator bufferAllocator;
    private Entity totemEntity;
    private int remainingTotemParticles;
    private static final Map<ParticlesModule.ParticleType, RenderLayer> particleLayers =
            new ConcurrentHashMap<>();
    public final List<ParticlesModule.Particle> movementParticles;
    public BooleanSetting onAttackSetting = new BooleanSetting(this, "On Attack", true);
    private static final RenderPipeline PARTICLE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_TEX_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/world/textured_quads"))
                            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());

    @EventHandler
    public void onAttack(AttackEvent attackEvent) {
        if (this.onAttackSetting.isOn()) {
            this.spawnAttackParticles(attackEvent.getTarget());
        }
    }

    private void drawParticleGlow(
            MatrixStack matrixstack,
            Immediate immediate,
            ParticlesModule.Particle particle,
            float f,
            float f1,
            float f2,
            float f3,
            int i,
            int j) {
        matrixstack.push();
        translateToCamera(matrixstack, f, f1, f2);
        matrixstack.multiply(client.gameRenderer.getCamera().getRotation());
        if (this.rotationSetting.isOn()) {
            matrixstack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(particle.getRotation()));
        }

        Entry entry = matrixstack.peek();
        Matrix4f matrix4f = entry.getPositionMatrix();
        Matrix3f matrix3f = entry.getNormalMatrix();
        VertexConsumer vertexconsumer =
                immediate.getBuffer(
                        particleLayer.apply(ParticlesModule.ParticleType.BLOOM.texture));
        this.drawTexturedQuad(
                vertexconsumer,
                matrix4f,
                matrix3f,
                -f3 * 3.0F,
                -f3 * 3.0F,
                f3 * 6.0F,
                f3 * 6.0F,
                i,
                j);
        matrixstack.pop();
    }

    public void spawnAttackParticles(Entity entity) {
        if (entity != null) {
            float f = 1.1F;

            for (int i = 0; (float) i < this.attackParticleCountSetting.getFloat(); i++) {
                this.spawnParticle(
                        this.attackParticles,
                        new Vec3d(
                                entity.getX() + (double) MathUtils.randomFloat(-0.035F, 0.035F),
                                entity.getY()
                                        + (double) MathUtils.randomFloat(0.1F, entity.getHeight()),
                                entity.getZ() + (double) MathUtils.randomFloat(-0.035F, 0.035F)),
                        new Vec3d(
                                (double) MathUtils.randomFloat(-f + 0.2F, f - 0.2F),
                                (double) MathUtils.randomFloat(-f, f / 2.0F),
                                (double) MathUtils.randomFloat(-f + 0.2F, f - 0.2F)),
                        false);
            }
        }
    }

    public static void translateToCamera(MatrixStack matrixstack, float f, float f1, float f2) {
        translateToCamera(matrixstack, (double) f, (double) f1, (double) f2);
    }

    @EventHandler
    public void onPacket(PacketEvent packetEvent) {
        if (packetEvent.getPacket() instanceof EntityStatusS2CPacket entitystatuss2cpacket) {
            if (entitystatuss2cpacket.getStatus() == 35) {
                Entity entityx = entitystatuss2cpacket.getEntity(client.world);
                if (entityx == null) {
                    return;
                }

                if (this.onTotemPopSetting.isOn()) {
                    this.totemEntity = entityx;
                    this.totemTotalCount = this.totemParticleCountSetting.getFloat().intValue();
                    this.remainingTotemParticles = this.totemTotalCount;
                    this.totemStartedMillis = System.currentTimeMillis();
                }
            }
        }
    }

    public static void translateToCamera(MatrixStack matrixstack, double d0, double d1, double d2) {
        Vec3d vec3d = client.getEntityRenderDispatcher().camera.getCameraPos();
        matrixstack.translate(d0 - vec3d.x, d1 - vec3d.y, d2 - vec3d.z);
    }

    private boolean isPlayerMoving() {
        return client.player.lastRenderX != client.player.getX()
                || client.player.lastRenderY != client.player.getY()
                || client.player.lastRenderZ != client.player.getZ();
    }

    @Override
    public void toggle() {
        super.toggle();
        this.clearParticles();
    }

    public ParticlesModule() {
        this.attackParticleCountSetting =
                new SliderSetting(this, "Attack Particle Count", 20.0F, 5.0F, 50.0F, 1.0F)
                        .visibleWhen(() -> this.onAttackSetting.isOn());
        this.onTotemPopSetting = new BooleanSetting(this, "On Totem Pop", true);
        this.totemParticleCountSetting =
                new SliderSetting(this, "Totem Particle Count", 75.0F, 20.0F, 150.0F, 1.0F)
                        .visibleWhen(() -> this.onTotemPopSetting.isOn());
        this.onProjectileThrowSetting = new BooleanSetting(this, "On Projectile Throw", true);
        this.throwParticleCountSetting =
                new SliderSetting(this, "Throw Particle Count", 3.0F, 1.0F, 8.0F, 1.0F)
                        .visibleWhen(() -> this.onProjectileThrowSetting.isOn());
        this.ambientParticlesSetting = new BooleanSetting(this, "Ambient Particles", true);
        this.ambientParticleCountSetting =
                new SliderSetting(this, "Ambient Particle Count", 10.0F, 2.0F, 60.0F, 1.0F)
                        .visibleWhen(() -> this.ambientParticlesSetting.isOn());
        this.whileMovingSetting = new BooleanSetting(this, "While Moving", true);
        this.particleTypeSetting =
                new ModeSetting(
                        this,
                        "Particle Type",
                        new String[] {
                            "Client",
                            "Small Circle",
                            "Bloom",
                            "Star",
                            "Heart",
                            "Snow",
                            "Dollar",
                            "Pumpkin"
                        });
        this.sizeSetting = new SliderSetting(this, "Size", 0.5F, 0.0F, 1.0F, 0.1F);
        this.glowSetting = new BooleanSetting(this, "Glow", true);
        this.glowStrengthSetting =
                new SliderSetting(this, "Glow Strength", 0.5F, 0.0F, 1.0F, 0.1F)
                        .visibleWhen(() -> this.glowSetting.isOn());
        this.rotationSetting = new BooleanSetting(this, "Rotation", true);
        this.attackParticles = new ArrayList<>();
        this.totemParticles = new ArrayList<>();
        this.movementParticles = new ArrayList<>();
        this.ambientParticles = new ArrayList<>();
        this.totemStartedMillis = 0L;
        this.totemEntity = null;
        this.remainingTotemParticles = 0;
        this.totemTotalCount = 0;
        this.lastFrameNanos = System.nanoTime();
        this.bufferAllocator = new BufferAllocator(4096);
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.clearParticles();
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        ClientPlayerEntity clientplayerentity = client.player;
        if (clientplayerentity != null && client.world != null) {
            if (this.onProjectileThrowSetting.isOn()) {
                for (Entity entityx : client.world.getEntities()) {
                    if ((entityx instanceof EnderPearlEntity
                                    || entityx instanceof ArrowEntity
                                    || entityx instanceof TridentEntity)
                            && (!(entityx instanceof TridentEntity tridententity)
                                    || !tridententity.isOnGround())) {
                        boolean flag =
                                entityx.lastRenderX != entityx.getX()
                                        || entityx.lastRenderY != entityx.getY()
                                        || entityx.lastRenderZ != entityx.getZ();
                        if (flag) {
                            Vec3d vec3d = entityx.getEntityPos();

                            for (int i = 0;
                                    (float) i < this.throwParticleCountSetting.getFloat();
                                    i++) {
                                this.spawnParticle(
                                        this.movementParticles,
                                        new Vec3d(
                                                vec3d.x
                                                        + MathHelper.nextDouble(
                                                                Random.create(), -0.1, 0.1),
                                                vec3d.y
                                                        + MathHelper.nextDouble(
                                                                Random.create(), -0.1, 0.1),
                                                vec3d.z
                                                        + MathHelper.nextDouble(
                                                                Random.create(), -0.1, 0.1)),
                                        new Vec3d(
                                                MathHelper.nextDouble(Random.create(), -0.15, 0.15),
                                                MathHelper.nextDouble(Random.create(), -0.15, 0.15),
                                                MathHelper.nextDouble(
                                                        Random.create(), -0.15, 0.15)),
                                        true);
                            }
                        }
                    }
                }
            }
        }
    }

    private void drawTexturedQuad(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            Matrix3f matrix3f,
            float f,
            float f1,
            float f2,
            float f3,
            int i,
            int j) {
        int k = i >> 16 & 0xFF;
        int l = i >> 8 & 0xFF;
        int i11 = i & 0xFF;
        normal.set(0.0F, 0.0F, 1.0F);
        matrix3f.transform(normal);
        normal.normalize();
        float f4 = f + f2;
        float f5 = f1 + f3;
        vertexconsumer
                .vertex(matrix4f, f, f1, 0.0F)
                .color(k, l, i11, j)
                .texture(0.0F, 1.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(normal.x, normal.y, normal.z);
        vertexconsumer
                .vertex(matrix4f, f4, f1, 0.0F)
                .color(k, l, i11, j)
                .texture(1.0F, 1.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(normal.x, normal.y, normal.z);
        vertexconsumer
                .vertex(matrix4f, f4, f5, 0.0F)
                .color(k, l, i11, j)
                .texture(1.0F, 0.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(normal.x, normal.y, normal.z);
        vertexconsumer
                .vertex(matrix4f, f, f5, 0.0F)
                .color(k, l, i11, j)
                .texture(0.0F, 0.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(normal.x, normal.y, normal.z);
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        MatrixStack matrixstack = render3DEvent.getMatrixStack();
        long nowNanos = System.nanoTime();
        double d0 = (double) (nowNanos - this.lastFrameNanos) / 1.0E9;
        this.lastFrameNanos = nowNanos;
        matrixstack.push();
        Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);
        if (this.glowSetting.isOn()) {
            this.drawGlows(matrixstack, immediate, this.attackParticles, (long) d0);
            this.drawGlows(matrixstack, immediate, this.totemParticles, (long) d0);
            this.drawGlows(matrixstack, immediate, this.ambientParticles, (long) d0);
            this.drawGlows(matrixstack, immediate, this.movementParticles, (long) d0);
        }

        this.updateAndDrawParticles(matrixstack, immediate, this.attackParticles, 2000L, 2500L, d0);
        this.updateAndDrawParticles(matrixstack, immediate, this.totemParticles, 1000L, 1500L, d0);
        this.updateAndDrawParticles(
                matrixstack, immediate, this.ambientParticles, 1000L, 1500L, d0);
        this.updateAndDrawParticles(
                matrixstack, immediate, this.movementParticles, 750L, 1000L, d0);
        immediate.draw();
        matrixstack.pop();
    }

    private void spawnParticle(
            List<ParticlesModule.Particle> list, Vec3d vec3d, Vec3d vec3d1, boolean flag) {
        float f = 0.05F + this.sizeSetting.getFloat() * 0.2F;
        int i = ColorUtils.animatedAccent(list.size() * 100);
        String string = this.particleTypeSetting.getSelectedMode();
        switch (string.hashCode()) {
            case -389846455:
                if (string.equals("Small Circle")) {
                    ParticlesModule.ParticleType CIRCLE = ParticlesModule.ParticleType.CIRCLE;
                    list.add(
                            new ParticlesModule.Particle(
                                    CIRCLE,
                                    vec3d.add(0.0, (double) f, 0.0),
                                    vec3d1,
                                    list.size(),
                                    (int)
                                            MathUtils.roundToStep(
                                                    MathUtils.randomFloat(0.0F, 360.0F), 15.0F),
                                    i,
                                    f,
                                    1.1F,
                                    flag,
                                    false));
                    return;
                }
                break;
            case 2581923:
                if (string.equals("Snow")) {
                    ParticlesModule.ParticleType SNOOW = ParticlesModule.ParticleType.SNOOW;
                    list.add(
                            new ParticlesModule.Particle(
                                    SNOOW,
                                    vec3d.add(0.0, (double) f, 0.0),
                                    vec3d1,
                                    list.size(),
                                    (int)
                                            MathUtils.roundToStep(
                                                    MathUtils.randomFloat(0.0F, 360.0F), 15.0F),
                                    i,
                                    f,
                                    1.1F,
                                    flag,
                                    false));
                    return;
                }
                break;
            case 2587250:
                if (string.equals("Star")) {
                    ParticlesModule.ParticleType STAR = ParticlesModule.ParticleType.STAR;
                    list.add(
                            new ParticlesModule.Particle(
                                    STAR,
                                    vec3d.add(0.0, (double) f, 0.0),
                                    vec3d1,
                                    list.size(),
                                    (int)
                                            MathUtils.roundToStep(
                                                    MathUtils.randomFloat(0.0F, 360.0F), 15.0F),
                                    i,
                                    f,
                                    1.1F,
                                    flag,
                                    false));
                    return;
                }
                break;
            case 64280035:
                if (string.equals("Bloom")) {
                    ParticlesModule.ParticleType BLOOM = ParticlesModule.ParticleType.BLOOM;
                    list.add(
                            new ParticlesModule.Particle(
                                    BLOOM,
                                    vec3d.add(0.0, (double) f, 0.0),
                                    vec3d1,
                                    list.size(),
                                    (int)
                                            MathUtils.roundToStep(
                                                    MathUtils.randomFloat(0.0F, 360.0F), 15.0F),
                                    i,
                                    f,
                                    1.1F,
                                    flag,
                                    false));
                    return;
                }
                break;
            case 69599270:
                if (string.equals("Heart")) {
                    ParticlesModule.ParticleType HEART = ParticlesModule.ParticleType.HEART;
                    list.add(
                            new ParticlesModule.Particle(
                                    HEART,
                                    vec3d.add(0.0, (double) f, 0.0),
                                    vec3d1,
                                    list.size(),
                                    (int)
                                            MathUtils.roundToStep(
                                                    MathUtils.randomFloat(0.0F, 360.0F), 15.0F),
                                    i,
                                    f,
                                    1.1F,
                                    flag,
                                    false));
                    return;
                }
                break;
            case 1439567688:
                if (string.equals("Pumpkin")) {
                    ParticlesModule.ParticleType PUMPKIN = ParticlesModule.ParticleType.PUMPKIN;
                    list.add(
                            new ParticlesModule.Particle(
                                    PUMPKIN,
                                    vec3d.add(0.0, (double) f, 0.0),
                                    vec3d1,
                                    list.size(),
                                    (int)
                                            MathUtils.roundToStep(
                                                    MathUtils.randomFloat(0.0F, 360.0F), 15.0F),
                                    i,
                                    f,
                                    1.1F,
                                    flag,
                                    false));
                    return;
                }
                break;
            case 2021122027:
                if (string.equals("Client")) {
                    ParticlesModule.ParticleType STAR_NEW = ParticlesModule.ParticleType.STAR_NEW;
                    list.add(
                            new ParticlesModule.Particle(
                                    STAR_NEW,
                                    vec3d.add(0.0, (double) f, 0.0),
                                    vec3d1,
                                    list.size(),
                                    (int)
                                            MathUtils.roundToStep(
                                                    MathUtils.randomFloat(0.0F, 360.0F), 15.0F),
                                    i,
                                    f,
                                    1.1F,
                                    flag,
                                    false));
                    return;
                }
                break;
            case 2052617436:
                if (string.equals("Dollar")) {
                    ParticlesModule.ParticleType DOLLAR = ParticlesModule.ParticleType.DOLLAR;
                    list.add(
                            new ParticlesModule.Particle(
                                    DOLLAR,
                                    vec3d.add(0.0, (double) f, 0.0),
                                    vec3d1,
                                    list.size(),
                                    (int)
                                            MathUtils.roundToStep(
                                                    MathUtils.randomFloat(0.0F, 360.0F), 15.0F),
                                    i,
                                    f,
                                    1.1F,
                                    flag,
                                    false));
                    return;
                }
        }

        ParticlesModule.ParticleType BLOOMValue = ParticlesModule.ParticleType.BLOOM;
        list.add(
                new ParticlesModule.Particle(
                        BLOOMValue,
                        vec3d.add(0.0, (double) f, 0.0),
                        vec3d1,
                        list.size(),
                        (int) MathUtils.roundToStep(MathUtils.randomFloat(0.0F, 360.0F), 15.0F),
                        i,
                        f,
                        1.1F,
                        flag,
                        false));
    }

    @EventHandler
    public void onWorldLoad2(WorldLoadEvent worldLoadEvent) {
        this.bufferAllocator.clear();
    }

    @EventHandler
    public void onPlayerMotion(PlayerMotionEvent playerMotionEvent) {
        if (this.whileMovingSetting.isOn() && this.isPlayerMoving()) {
            this.spawnParticle(
                    this.movementParticles,
                    new Vec3d(
                            client.player.getX() + MathUtils.randomDouble(-0.1, 0.1),
                            client.player.getY()
                                    + (double)
                                            MathUtils.randomFloat(0.0F, client.player.getHeight()),
                            client.player.getZ() + MathUtils.randomDouble(-0.1, 0.1)),
                    new Vec3d(
                            MathUtils.randomDouble(-0.3, 0.3),
                            MathUtils.randomDouble(-0.03, 0.3),
                            MathUtils.randomDouble(-0.3, 0.3)),
                    true);
        }

        if (this.ambientParticlesSetting.isOn()) {
            if (client.world == null || client.player == null) {
                return;
            }

            byte b0 = 24;

            for (int i = 0; (float) i < this.ambientParticleCountSetting.getFloat(); i++) {
                Vec3d vec3d =
                        client.player
                                .getEntityPos()
                                .add(
                                        (double) MathUtils.randomFloat((float) (-b0), (float) b0),
                                        0.0,
                                        (double) MathUtils.randomFloat((float) (-b0), (float) b0));
                BlockPos blockpos =
                        client.world.getTopPosition(
                                Type.MOTION_BLOCKING, BlockPos.ofFloored(vec3d));
                double d0 = (double) ((float) blockpos.getX() + MathUtils.randomFloat(-3.0F, 3.0F));
                double d1 = (double) ((float) blockpos.getZ() + MathUtils.randomFloat(-3.0F, 3.0F));
                double d2 =
                        client.player.getY()
                                + (double)
                                        MathUtils.randomFloat(
                                                client.player.getHeight(), (float) b0);
                Vec3d vec3d1 = new Vec3d(d0, d2, d1);

                while (!client.world.isAir(BlockPos.ofFloored(vec3d1))
                        && vec3d1.y < (double) client.world.getTopYInclusive()) {
                    vec3d1 = vec3d1.add(0.0, 1.0, 0.0);
                }

                this.spawnParticle(
                        this.ambientParticles,
                        vec3d1,
                        new Vec3d(
                                client.player.getVelocity().x
                                        + (double) MathUtils.randomFloat(-0.6F, 0.6F),
                                MathUtils.randomDouble(-0.01, 0.44),
                                client.player.getVelocity().z
                                        + (double) MathUtils.randomFloat(-0.6F, 0.6F)),
                        true);
            }
        }

        if (this.remainingTotemParticles > 0 && this.totemEntity != null) {
            if (!this.totemEntity.isAlive()
                    && client.world.getEntityById(this.totemEntity.getId()) == null) {
                this.remainingTotemParticles = 0;
                this.totemEntity = null;
            } else {
                long l = System.currentTimeMillis() - this.totemStartedMillis;
                long i1 = 1500L;
                if (l < i1) {
                    int j1 = (int) ((double) l / (double) i1 * (double) this.totemTotalCount);
                    int j = this.totemTotalCount - this.remainingTotemParticles;
                    int l1 = j1 - j;
                    if (l1 > this.remainingTotemParticles) {
                        l1 = this.remainingTotemParticles;
                    }

                    for (int k = 0; k < l1; k++) {
                        double d11 = MathUtils.randomDouble(0.0, Math.PI * 2);
                        double d12 = MathUtils.randomDouble(2.5, 4.0) * 0.1F;
                        double d5 = Math.cos(d11) * d12;
                        double d7 = Math.sin(d11) * d12;
                        double d8 =
                                MathUtils.randomDouble(
                                        0.0, (double) (this.totemEntity.getHeight() / 4.0F));
                        this.spawnTotemParticle(
                                this.totemParticles,
                                new Vec3d(
                                        this.totemEntity.getX() + MathUtils.randomDouble(-0.2, 0.2),
                                        this.totemEntity.getY()
                                                + (double)
                                                        MathUtils.randomFloat(
                                                                0.1F, this.totemEntity.getHeight()),
                                        this.totemEntity.getZ()
                                                + MathUtils.randomDouble(-0.2, 0.2)),
                                new Vec3d(d5, d8, d7));
                        this.remainingTotemParticles--;
                    }
                } else {
                    for (int k1 = 0; k1 < this.remainingTotemParticles; k1++) {
                        double d9 = MathUtils.randomDouble(0.0, Math.PI * 2);
                        double d10 = MathUtils.randomDouble(2.5, 4.0) * 0.1F;
                        double d3 = Math.cos(d9) * d10;
                        double d4 = Math.sin(d9) * d10;
                        double d6 =
                                MathUtils.randomDouble(
                                        0.0, (double) (this.totemEntity.getHeight() / 4.0F));
                        this.spawnTotemParticle(
                                this.totemParticles,
                                new Vec3d(
                                        this.totemEntity.getX() + MathUtils.randomDouble(-0.2, 0.2),
                                        this.totemEntity.getY()
                                                + (double)
                                                        MathUtils.randomFloat(
                                                                0.1F, this.totemEntity.getHeight()),
                                        this.totemEntity.getZ()
                                                + MathUtils.randomDouble(-0.2, 0.2)),
                                new Vec3d(d3, d6, d4));
                    }

                    this.remainingTotemParticles = 0;
                    this.totemEntity = null;
                }
            }
        }

        this.removeExpiredParticles(this.movementParticles, 3000L);
        this.removeExpiredParticles(this.totemParticles, 3500L);
        this.removeExpiredParticles(this.ambientParticles, 3500L);
        this.removeExpiredParticles(this.attackParticles, 6000L);
    }

    private void updateAndDrawParticles(
            MatrixStack matrixstack,
            Immediate immediate,
            List<ParticlesModule.Particle> list,
            long i,
            long j,
            double d0) {
        if (!list.isEmpty()) {
            matrixstack.push();

            for (ParticlesModule.Particle particle : list) {
                particle.update(d0);
                boolean flag;
                flag = (!particle.getAgeTimer().hasElapsed((double) i));

                boolean hasElapsed = particle.getAgeTimer().hasElapsed((double) j);
                if (flag) {
                    particle.getFadeAnimation().animateTo(1.0, 0.5, Easings.LINEAR, true);
                } else if (hasElapsed) {
                    particle.getFadeAnimation().animateTo(0.0, 2.0, Easings.LINEAR, true);
                }

                if (particle.fadeAnimation.isRunning()) {
                    particle.fadeAnimation.update();
                }

                float floatValue = particle.fadeAnimation.getFloatValue();
                int alpha = (int) (floatValue * 255.0F);
                if (alpha > 0) {
                    int l1x = ColorUtils.withAlpha(particle.getColor(), alpha);
                    Vec3d vec3d = particle.getPosition();
                    this.drawParticle(
                            matrixstack,
                            immediate,
                            particle,
                            (float) vec3d.x,
                            (float) vec3d.y,
                            (float) vec3d.z,
                            particle.size * floatValue,
                            l1x,
                            alpha);
                }
            }

            matrixstack.pop();
        }
    }

    private void removeExpiredParticles(List<ParticlesModule.Particle> list, long i) {
        list.removeIf(particle -> particle.getAgeTimer().hasElapsed((double) i));
    }

    private void drawParticle(
            MatrixStack matrixstack,
            Immediate immediate,
            ParticlesModule.Particle particle,
            float f,
            float f1,
            float f2,
            float f3,
            int i,
            int j) {
        matrixstack.push();
        translateToCamera(matrixstack, f, f1, f2);
        matrixstack.multiply(client.gameRenderer.getCamera().getRotation());
        if (this.rotationSetting.isOn()) {
            matrixstack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(particle.getRotation()));
        }

        Entry entry = matrixstack.peek();
        Matrix4f matrix4f = entry.getPositionMatrix();
        Matrix3f matrix3f = entry.getNormalMatrix();
        VertexConsumer vertexconsumer =
                immediate.getBuffer(particleLayer.apply(particle.getParticleType().getTexture()));
        this.drawTexturedQuad(
                vertexconsumer, matrix4f, matrix3f, -f3, -f3, f3 * 2.0F, f3 * 2.0F, i, j);
        if (particle.particleType == ParticlesModule.ParticleType.BLOOM
                && this.glowSetting.isOn()) {
            this.drawTexturedQuad(
                    vertexconsumer, matrix4f, matrix3f, -f3 / 2.0F, -f3 / 2.0F, f3, f3, i, j);
        }

        matrixstack.pop();
    }

    private void drawGlows(
            MatrixStack matrixstack,
            Immediate immediate,
            List<ParticlesModule.Particle> list,
            long d0) {
        if (!list.isEmpty()) {
            matrixstack.push();

            for (ParticlesModule.Particle particle : list) {
                float floatValue = particle.fadeAnimation.getFloatValue();
                int alpha = (int) (floatValue * 255.0F * this.glowStrengthSetting.getFloat());
                if (alpha > 0) {
                    int j = ColorUtils.withAlpha(particle.getColor(), alpha);
                    Vec3d vec3d = particle.getPosition();
                    this.drawParticleGlow(
                            matrixstack,
                            immediate,
                            particle,
                            (float) vec3d.x,
                            (float) vec3d.y,
                            (float) vec3d.z,
                            particle.size * floatValue,
                            j,
                            alpha);
                }
            }

            matrixstack.pop();
        }
    }

    private void clearParticles() {
        this.attackParticles.clear();
        this.movementParticles.clear();
        this.totemParticles.clear();
        this.ambientParticles.clear();
        this.remainingTotemParticles = 0;
        this.totemTotalCount = 0;
        this.totemEntity = null;
        this.totemStartedMillis = 0L;
    }

    public void spawnTotemParticle(List<ParticlesModule.Particle> list, Vec3d vec3d, Vec3d vec3d1) {
        float f = 0.05F + this.sizeSetting.getFloat() * 0.2F;
        String string = this.particleTypeSetting.getSelectedMode();

        ParticlesModule.ParticleType particleType =
                switch (string) {
                    case "Heart" -> ParticlesModule.ParticleType.HEART;
                    case "Star" -> ParticlesModule.ParticleType.STAR;
                    case "Snow" -> ParticlesModule.ParticleType.SNOOW;
                    case "Small Circle" -> ParticlesModule.ParticleType.CIRCLE;
                    case "Bloom" -> ParticlesModule.ParticleType.BLOOM;
                    case "Client" -> ParticlesModule.ParticleType.STAR_NEW;
                    case "Dollar" -> ParticlesModule.ParticleType.DOLLAR;
                    case "Pumpkin" -> ParticlesModule.ParticleType.PUMPKIN;
                    default -> ParticlesModule.ParticleType.BLOOM;
                };
        int[] aint =
                new int[] {
                    ColorUtils.rgb(221, 218, 127),
                    ColorUtils.rgb(127, 221, 144),
                    ColorUtils.rgb(255, 215, 0),
                    ColorUtils.rgb(50, 205, 50)
                };
        int i = aint[MathUtils.randomIntInclusive(0, aint.length - 1)];
        list.add(
                new ParticlesModule.Particle(
                        particleType,
                        vec3d.add(0.0, (double) f, 0.0),
                        vec3d1,
                        list.size(),
                        (int) MathUtils.roundToStep(MathUtils.randomFloat(0.0F, 360.0F), 15.0F),
                        i,
                        f,
                        1.1F,
                        false,
                        true));
    }

    public static boolean isSolidAt(double d0, double d1, double d2) {
        if (client.world == null) {
            return false;
        } else {
            BlockPos blockpos = BlockPos.ofFloored(d0, d1, d2);
            return client.world.getBlockState(blockpos).isFullCube(client.world, blockpos);
        }
    }

    @Environment(EnvType.CLIENT)
    public static class Particle {
        private final boolean slowGravity;
        private final ParticlesModule.ParticleType particleType;
        private float rotation;
        private final EasingAnimation fadeAnimation;
        private Vec3d velocity;
        private final int spawnIndex;
        private Vec3d position;
        private final ElapsedTimer ageTimer = new ElapsedTimer();
        private final boolean totemParticle;
        private final int color;
        private final float size;
        private final double initialScale;

        public Vec3d getPosition() {
            return this.position;
        }

        public int getColor() {
            return this.color;
        }

        public EasingAnimation getFadeAnimation() {
            return this.fadeAnimation;
        }

        public ParticlesModule.ParticleType getParticleType() {
            return this.particleType;
        }

        public ElapsedTimer getAgeTimer() {
            return this.ageTimer;
        }

        public float getRotation() {
            return this.rotation;
        }

        public Particle(
                ParticlesModule.ParticleType particleTypeValue,
                Vec3d vec3d,
                Vec3d vec3d1,
                int spawnIndexValue,
                int j,
                int colorValue,
                float sizeValue,
                double initialScaleValue,
                boolean slowGravityValue,
                boolean totemParticleValue) {
            this.fadeAnimation = new EasingAnimation();
            this.rotation = 0.0F;
            this.particleType = particleTypeValue;
            this.position = vec3d;
            this.velocity = totemParticleValue ? vec3d1.multiply(0.08) : vec3d1.multiply(0.05);
            this.spawnIndex = spawnIndexValue;
            this.color = colorValue;
            this.rotation = (float) j;
            this.size = sizeValue;
            this.initialScale = initialScaleValue;
            this.slowGravity = slowGravityValue;
            this.totemParticle = totemParticleValue;
            this.ageTimer.reset();
        }

        public void update(double d0) {
            double d1 = d0 * 120.0;
            if (!(d1 <= 0.0)) {
                double d2 = 0.85;
                double d3 = this.slowGravity ? 1.0E-4 : 5.0E-4;
                double d4 = this.position.x + this.velocity.x * d1;
                double d5 = this.position.y + this.velocity.y * d1;
                double d6 = this.position.z + this.velocity.z * d1;
                if (ParticlesModule.isSolidAt(d4, this.position.y, this.position.z)) {
                    this.velocity =
                            new Vec3d(-this.velocity.x * d2, this.velocity.y, this.velocity.z);
                } else {
                    this.position = new Vec3d(d4, this.position.y, this.position.z);
                }

                if (ParticlesModule.isSolidAt(this.position.x, d5, this.position.z)) {
                    this.velocity =
                            new Vec3d(this.velocity.x, -this.velocity.y * d2, this.velocity.z);
                } else {
                    this.position = new Vec3d(this.position.x, d5, this.position.z);
                }

                if (ParticlesModule.isSolidAt(this.position.x, this.position.y, d6)) {
                    this.velocity =
                            new Vec3d(this.velocity.x, this.velocity.y, -this.velocity.z * d2);
                } else {
                    this.position = new Vec3d(this.position.x, this.position.y, d6);
                }

                this.velocity = this.velocity.subtract(0.0, d3 * d1, 0.0);
                this.rotation = (float) ((double) this.rotation + 2.0 * d1);
            }
        }
    }

    @Environment(EnvType.CLIENT)
    public static enum ParticleType {
        HEART("heart", true),
        STAR("star", true),
        BLOOM("glow", true),
        CIRCLE("circle", true),
        STAR_NEW("client", true),
        SNOOW("snowflake", true),
        DOLLAR("dollar", true),
        PUMPKIN("pumpkin", true);
        private final Identifier texture;
        private final boolean enabled;

        private ParticleType(String text, boolean enabledValue) {
            this.texture = Identifier.of("client", "textures/particles/" + text + ".png");
            this.enabled = enabledValue;
        }

        public Identifier getTexture() {
            return this.texture;
        }
    }
}
