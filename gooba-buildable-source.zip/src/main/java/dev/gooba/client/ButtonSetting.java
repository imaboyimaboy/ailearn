package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class ButtonSetting extends Setting<String> {
    public ButtonSetting visibleWhen(Supplier supplier) {
        return (ButtonSetting) super.visibleWhen(supplier);
    }

    public String getLabel(int i) {
        return (String) super.getValue();
    }

    public ButtonSetting onChange(Runnable runnable) {
        return (ButtonSetting) super.onChange(runnable);
    }

    public ButtonSetting(Module moduleValue, String nameValue) {
        super(moduleValue, nameValue, "");
    }
}
