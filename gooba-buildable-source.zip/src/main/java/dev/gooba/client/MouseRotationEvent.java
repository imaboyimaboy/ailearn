package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class MouseRotationEvent extends CancellableEvent {
    public double pitch;
    public double yaw;

    public void setPitch(double pitchValue) {
        this.pitch = pitchValue;
    }

    public MouseRotationEvent(double yawValue, double pitchValue) {
        this.yaw = yawValue;
        this.pitch = pitchValue;
    }

    public double getYaw() {
        return this.yaw;
    }

    public double getPitch() {
        return this.pitch;
    }

    public void setYaw(double yawValue) {
        this.yaw = yawValue;
    }
}
