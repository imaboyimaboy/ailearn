package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface Cancellable {
    void setCancelled(boolean flag);

    boolean isCancelled();

    default void cancel() {
        this.setCancelled(true);
    }
}
