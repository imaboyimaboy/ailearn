package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

@ModuleInfo(
        name = "Chunk Finder",
        category = ModuleCategory.DONUT,
        desc = "Detects suspicious chunks via geode light anomalies")
@Environment(EnvType.CLIENT)
public class ChunkFinderModule extends Module {
    private final Set<ChunkPos> notifiedChunks;
    private final Map<ChunkPos, Integer> detectedChunks;
    public final SliderSetting tracersAlphaSetting;
    public final ColorSetting chunkColorSetting;
    public final SliderSetting simDistanceSetting;

    private final Set<ChunkPos> queuedChunks;
    public final BooleanSetting showTracersSetting;
    private int ticks;
    public final SliderSetting alphaSetting;
    private final Map<ChunkPos, ChunkFinderModule.ScanResult> scanResults;
    private static final int[][] NEIGHBOR_OFFSETS =
            new int[][] {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    private final LinkedBlockingQueue<ChunkPos> scanQueue;
    public final SliderSetting sensitivitySetting =
            new SliderSetting(this, "Sensitivity", 12.0F, 1.0F, 100.0F, 1.0F);
    private final Set<ChunkPos> processedGroups;

    private BlockPos findGeodeCenter(WorldChunk worldchunk) {
        long i = 0L;
        long j = 0L;
        long k = 0L;
        int l = 0;
        ChunkPos chunkpos = worldchunk.getPos();
        Mutable mutable = new Mutable();

        for (int i1 = -58; i1 <= 30; i1++) {
            for (int j1 = 0; j1 < 16; j1++) {
                for (int k1 = 0; k1 < 16; k1++) {
                    mutable.set(chunkpos.getStartX() + j1, i1, chunkpos.getStartZ() + k1);
                    BlockState blockstate = worldchunk.getBlockState(mutable);
                    if (blockstate.isOf(Blocks.AMETHYST_BLOCK)
                            || blockstate.isOf(Blocks.BUDDING_AMETHYST)) {
                        i += (long) mutable.getX();
                        j += (long) mutable.getY();
                        k += (long) mutable.getZ();
                        l++;
                    }
                }
            }
        }

        return l == 0
                ? null
                : new BlockPos((int) (i / (long) l), (int) (j / (long) l), (int) (k / (long) l));
    }

    private void notifyDetection() {
        client.execute(
                () -> {
                    if (client.player != null) {
                        client.player.playSound(
                                SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.2F, 1.2F);
                        NotificationManager.showItem(
                                "Chunk Finder: Chunk found!",
                                NotificationManager.Type.INFO,
                                new ItemStack(Blocks.CHEST));
                    }
                });
    }

    private int[] dominantDirection(Set<BlockPos> set) {
        int[][] aint = new int[3][3];

        for (BlockPos blockpos : set) {
            int[] values;
            label48:
            {
                int i = blockpos.getX() & 15;
                int j = blockpos.getZ() & 15;
                if (i < 6) {
                    values = aint[0];
                    if (j < 6) {
                        break label48;
                    }
                } else if (i < 11) {
                    values = aint[1];
                    if (j < 6) {
                        break label48;
                    }
                } else {
                    values = aint[2];
                    if (j < 6) {
                        break label48;
                    }
                }

                if (j < 11) {
                    values[1]++;
                } else {
                    values[2]++;
                }
                continue;
            }

            values[0]++;
        }

        int l = 1;
        int i1 = 1;
        int j1 = -1;

        for (int k1 = 0; k1 < 3; k1++) {
            for (int k = 0; k < 3; k++) {
                if (aint[k1][k] > j1) {
                    j1 = aint[k1][k];
                    l = k1;
                    i1 = k;
                }
            }
        }

        return new int[] {l - 1, i1 - 1};
    }

    private void queueChunk(int i, int j) {
        ChunkPos chunkpos = new ChunkPos(i, j);
        if (this.queuedChunks.add(chunkpos)) {
            this.scanQueue.offer(chunkpos);
        }
    }

    public ChunkFinderModule() {
        this.simDistanceSetting = new SliderSetting(this, "Sim Distance", 8.0F, 1.0F, 32.0F, 1.0F);
        this.chunkColorSetting = new ColorSetting(this, "Chunk Color", 65280);
        this.alphaSetting = new SliderSetting(this, "Alpha", 40.0F, 0.0F, 255.0F, 1.0F);
        this.showTracersSetting = new BooleanSetting(this, "Show Tracers", false);
        this.tracersAlphaSetting =
                new SliderSetting(this, "Tracers Alpha", 70.0F, 0.0F, 255.0F, 1.0F);
        this.detectedChunks = new ConcurrentHashMap<>();
        this.notifiedChunks = ConcurrentHashMap.newKeySet();
        this.scanResults = new ConcurrentHashMap<>();
        this.processedGroups = ConcurrentHashMap.newKeySet();
        this.scanQueue = new LinkedBlockingQueue<>();
        this.queuedChunks = ConcurrentHashMap.newKeySet();
    }

    private Set<BlockPos> findLightAnomalies(WorldChunk worldchunk) {
        HashSet hashset = new HashSet();
        BlockPos blockpos = this.findGeodeCenter(worldchunk);
        if (blockpos != null && client.world != null) {
            Mutable mutable = new Mutable();
            Mutable mutableValue = new Mutable();
            Mutable mutable3 = new Mutable();

            for (int i = -8; i <= 8; i++) {
                for (int j = -8; j <= 8; j++) {
                    for (int k = -8; k <= 8; k++) {
                        mutable.set(blockpos.getX() + i, blockpos.getY() + j, blockpos.getZ() + k);
                        BlockState blockstate = client.world.getBlockState(mutable);
                        if ((blockstate.isOf(Blocks.AIR)
                                        || blockstate.isOf(Blocks.AMETHYST_CLUSTER))
                                && client.world.getLightLevel(LightType.BLOCK, mutable) == 0) {
                            boolean flag = false;
                            int MIN_VALUE = Integer.MIN_VALUE;
                            int i1 = 0;
                            int j1 = 0;

                            for (int[] aint : NEIGHBOR_OFFSETS) {
                                mutableValue.set(
                                        mutable.getX() + aint[0],
                                        mutable.getY() + aint[1],
                                        mutable.getZ() + aint[2]);
                                int lightLevel =
                                        client.world.getLightLevel(LightType.BLOCK, mutableValue);
                                if (lightLevel > 4) {
                                    flag = true;
                                    break;
                                }

                                if (MIN_VALUE == Integer.MIN_VALUE
                                        && lightLevel == 4
                                        && client.world
                                                .getBlockState(mutableValue)
                                                .isOf(Blocks.AIR)) {
                                    MIN_VALUE = mutableValue.getX();
                                    i1 = mutableValue.getY();
                                    j1 = mutableValue.getZ();
                                }
                            }

                            if (!flag && MIN_VALUE != Integer.MIN_VALUE) {
                                boolean flag1 = false;

                                for (int[] values : NEIGHBOR_OFFSETS) {
                                    mutable3.set(
                                            MIN_VALUE + values[0], i1 + values[1], j1 + values[2]);
                                    if (client.world.getLightLevel(LightType.BLOCK, mutable3) > 4) {
                                        flag1 = true;
                                        break;
                                    }
                                }

                                if (!flag1) {
                                    hashset.add(mutable.toImmutable());
                                    if (hashset.size() >= 9000) {
                                        return hashset;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return hashset;
        } else {
            return hashset;
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && !this.detectedChunks.isEmpty()) {
            int integer = this.chunkColorSetting.getColor();
            int alpha = Math.round(this.alphaSetting.getFloat());
            int k = ColorUtils.withAlpha(integer, alpha);
            WorldEspRenderer.clear();

            for (ChunkPos chunkpos : this.detectedChunks.keySet()) {
                Box box =
                        new Box(
                                (double) chunkpos.getStartX(),
                                60.0,
                                (double) chunkpos.getStartZ(),
                                (double) chunkpos.getStartX() + 16.0,
                                60.05,
                                (double) chunkpos.getStartZ() + 16.0);
                WorldEspRenderer.enqueueBox(box, k, this.showTracersSetting.isOn());
            }

            WorldEspRenderer.flush(render3DEvent.getMatrixStack());
        }
    }

    private boolean isInViewDistance(int i, int j) {
        if (client.player == null) {
            return false;
        } else {
            int value = client.options.getViewDistance().getValue();
            ChunkPos chunkpos = client.player.getChunkPos();
            return Math.abs(i - chunkpos.x) <= value && Math.abs(j - chunkpos.z) <= value;
        }
    }

    private void scanChunk(WorldChunk worldchunk) {
        if (client.world != null) {
            ChunkPos chunkpos = worldchunk.getPos();
            Set setx = this.findLightAnomalies(worldchunk);
            int count = setx.size();
            ChunkFinderModule.ScanResult scanResult =
                    new ChunkFinderModule.ScanResult(
                            count, count > 0 ? this.dominantDirection(setx) : new int[] {0, 0});
            this.scanResults.put(chunkpos, scanResult);
            int j = Math.round(this.sensitivitySetting.getFloat());
            if (count >= j) {
                List list = this.collectConnectedChunks(chunkpos, j);
                if (!list.isEmpty()) {
                    ChunkPos chunkPos = this.strongestChunk(list);
                    if (this.processedGroups.add(chunkPos)) {
                        long k = 0L;
                        long l = 0L;
                        long i1 = 0L;

                        for (ChunkPos chunkPos2 : (Iterable<ChunkPos>) (Iterable) list) {
                            ChunkFinderModule.ScanResult scanResultValue =
                                    this.scanResults.get(chunkPos2);
                            if (scanResultValue != null) {
                                k += (long) chunkPos2.x * (long) scanResultValue.hits;
                                l += (long) chunkPos2.z * (long) scanResultValue.hits;
                                i1 += (long) scanResultValue.hits;
                            }
                        }

                        int[] aint;
                        int j1;
                        ChunkPos chunkPos3;
                        ChunkPos chunkPos4;
                        int l1;
                        if (i1 == 0L) {
                            chunkPos3 = chunkPos;
                            chunkPos4 = chunkPos;
                            l1 = -1;
                            aint = new int[] {0, 0};
                            j1 = -1;
                        } else {
                            chunkPos3 =
                                    new ChunkPos(
                                            (int) Math.round((double) k / (double) i1),
                                            (int) Math.round((double) l / (double) i1));
                            chunkPos4 = chunkPos3;
                            l1 = -1;
                            aint = new int[] {0, 0};
                            j1 = -1;
                        }

                        while (j1 <= 1) {
                            for (int k1 = -1; k1 <= 1; k1++) {
                                ChunkPos chunkPosValue =
                                        new ChunkPos(chunkPos3.x + j1, chunkPos3.z + k1);
                                ChunkFinderModule.ScanResult scanResult2 =
                                        this.scanResults.get(chunkPosValue);
                                if (scanResult2 == null
                                        && client.world.isChunkLoaded(
                                                chunkPosValue.x, chunkPosValue.z)) {
                                    Set setValue =
                                            this.findLightAnomalies(
                                                    client.world.getChunk(
                                                            chunkPosValue.x, chunkPosValue.z));
                                    scanResult2 =
                                            new ChunkFinderModule.ScanResult(
                                                    setValue.size(),
                                                    setValue.isEmpty()
                                                            ? new int[] {0, 0}
                                                            : this.dominantDirection(setValue));
                                    this.scanResults.put(chunkPosValue, scanResult2);
                                }

                                if (scanResult2 != null && scanResult2.hits > l1) {
                                    l1 = scanResult2.hits;
                                    chunkPos4 = chunkPosValue;
                                    aint = scanResult2.dir;
                                }
                            }

                            j1++;
                        }

                        if (l1 > 0) {
                            this.recordDetection(
                                    new ChunkPos(chunkPos4.x + aint[0], chunkPos4.z + aint[1]), l1);
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onBlockUpdate(BlockUpdateEvent blockUpdateEvent) {
        if (client.world != null) {
            BlockState blockstate = blockUpdateEvent.getState();
            if (blockstate.isOf(Blocks.AMETHYST_BLOCK)
                    || blockstate.isOf(Blocks.BUDDING_AMETHYST)
                    || blockstate.isOf(Blocks.AMETHYST_CLUSTER)) {
                ChunkPos chunkpos = new ChunkPos(blockUpdateEvent.getPos());
                this.scanResults.remove(chunkpos);
                this.processedGroups.clear();
                this.queueChunk(chunkpos.x, chunkpos.z);
            }
        }
    }

    private void recordDetection(ChunkPos chunkpos, int i) {
        Integer integer = this.detectedChunks.get(chunkpos);
        if (integer == null || integer < i) {
            this.detectedChunks.put(chunkpos, i);
            if (this.notifiedChunks.add(chunkpos)) {
                this.notifyDetection();
            }

            this.mergeNearbyDetections();
        }
    }

    @Override
    protected void onEnable() {
        this.resetState();
        this.queueNearbyChunks();
    }

    private List<ChunkPos> collectConnectedChunks(ChunkPos chunkpos, int i) {
        ArrayList arraylist = new ArrayList();
        HashSet hashset = new HashSet();
        ArrayDeque arraydeque = new ArrayDeque();
        arraydeque.push(chunkpos);
        hashset.add(chunkpos);

        while (!arraydeque.isEmpty()) {
            ChunkPos chunkPosValue = (ChunkPos) arraydeque.pop();
            ChunkFinderModule.ScanResult scanResult = this.scanResults.get(chunkPosValue);
            if (scanResult != null && scanResult.hits >= i) {
                arraylist.add(chunkPosValue);

                for (int j = -1; j <= 1; j++) {
                    for (int k = -1; k <= 1; k++) {
                        if (j != 0 || k != 0) {
                            ChunkPos chunkPos =
                                    new ChunkPos(chunkPosValue.x + j, chunkPosValue.z + k);
                            if (hashset.add(chunkPos)
                                    && this.scanResults.get(chunkPos) != null
                                    && this.scanResults.get(chunkPos).hits >= i) {
                                arraydeque.push(chunkPos);
                            }
                        }
                    }
                }
            }
        }

        return arraylist;
    }

    private void queueNearbyChunks() {
        if (client.player != null && client.world != null) {
            ChunkPos chunkpos = client.player.getChunkPos();
            int i = Math.round(this.simDistanceSetting.getFloat());

            for (int j = chunkpos.x - i; j <= chunkpos.x + i; j++) {
                for (int k = chunkpos.z - i; k <= chunkpos.z + i; k++) {
                    this.queueChunk(j, k);
                }
            }
        }
    }

    @Override
    protected void onDisable() {
        this.resetState();
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null) {
            int i = 0;

            ChunkPos chunkpos;
            while (i < 4 && (chunkpos = this.scanQueue.poll()) != null) {
                this.queuedChunks.remove(chunkpos);
                if (this.isInViewDistance(chunkpos.x, chunkpos.z)
                        && client.world.isChunkLoaded(chunkpos.x, chunkpos.z)) {
                    this.scanChunk(client.world.getChunk(chunkpos.x, chunkpos.z));
                    i++;
                }
            }

            if (++this.ticks % 60 == 0) {
                this.queueNearbyChunks();
            }
        }
    }

    private void mergeNearbyDetections() {
        ArrayList<java.util.Map.Entry<ChunkPos, Integer>> arraylist =
                new ArrayList<>(this.detectedChunks.entrySet());
        arraylist.sort(
                (entry, entryValue) ->
                        Integer.compare(
                                (Integer) entryValue.getValue(), (Integer) entry.getValue()));
        HashSet hashset = new HashSet();

        for (int i = 0; i < arraylist.size(); i++) {
            if (!hashset.contains(((Entry) arraylist.get(i)).getKey())) {
                for (int j = i + 1; j < arraylist.size(); j++) {
                    ChunkPos chunkpos = (ChunkPos) ((Entry) arraylist.get(i)).getKey();
                    ChunkPos key = (ChunkPos) ((Entry) arraylist.get(j)).getKey();
                    if (Math.max(Math.abs(chunkpos.x - key.x), Math.abs(chunkpos.z - key.z)) <= 2) {
                        hashset.add(key);
                    }
                }
            }
        }

        hashset.forEach(this.detectedChunks::remove);
    }

    private ChunkPos strongestChunk(List<ChunkPos> list) {
        return Collections.min(
                list,
                Comparator.<ChunkPos>comparingInt(chunkpos -> -this.scanResults.get(chunkpos).hits)
                        .thenComparingInt(chunkpos -> chunkpos.x)
                        .thenComparingInt(chunkpos -> chunkpos.z));
    }

    private void resetState() {
        this.scanQueue.clear();
        this.queuedChunks.clear();
        this.detectedChunks.clear();
        this.notifiedChunks.clear();
        this.scanResults.clear();
        this.processedGroups.clear();
        this.ticks = 0;
    }

    @Environment(EnvType.CLIENT)
    private static record ScanResult(int hits, int[] dir) {}
}
