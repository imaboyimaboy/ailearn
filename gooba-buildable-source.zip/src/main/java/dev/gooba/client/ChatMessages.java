package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

@Environment(EnvType.CLIENT)
public final class ChatMessages implements MinecraftAccess {
    private ChatMessages() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static void send(String text) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient.inGameHud != null && minecraftclient.inGameHud.getChatHud() != null) {
            MutableText mutabletext =
                    Text.literal("Goobaa")
                            .formatted(Formatting.DARK_PURPLE)
                            .append(Text.literal(" » ").formatted(Formatting.GRAY))
                            .append(Text.literal(text).formatted(Formatting.WHITE));
            minecraftclient.inGameHud.getChatHud().addMessage(mutabletext);
        }
    }
}
