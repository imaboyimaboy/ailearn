package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;

@ModuleInfo(
        name = "Home Macro",
        category = ModuleCategory.DONUT,
        desc = "Automatically runs /delhome and /sethome for a selected slot")
@Environment(EnvType.CLIENT)
public class HomeMacroModule extends Module {
    public final SliderSetting homeSlotSetting;
    public final BooleanSetting chatFeedbackSetting =
            new BooleanSetting(this, "Chat Feedback", true);

    @Override
    protected void onEnable() {
        if (client.player != null && client.world != null && client.getNetworkHandler() != null) {
            int i = (int) this.homeSlotSetting.getFloat().floatValue();
            client.execute(
                    () -> {
                        this.sendCommand("delhome " + i);
                        Thread thread =
                                new Thread(
                                        () -> {
                                            try {
                                                Thread.sleep(1000L);
                                            } catch (InterruptedException interruptedexception) {
                                            }

                                            client.execute(
                                                    () -> {
                                                        if (client.player != null
                                                                && client.getNetworkHandler()
                                                                        != null) {
                                                            this.sendCommand("sethome " + i);
                                                            if (this.chatFeedbackSetting.isOn()
                                                                    && client.player != null) {
                                                                client.player.sendMessage(
                                                                        Text.literal(
                                                                                "§7[§6Goobaa§7]"
                                                                                    + " §fHome "
                                                                                        + i
                                                                                        + " deleted"
                                                                                        + " and set"
                                                                                        + " successfully!"),
                                                                        false);
                                                            }
                                                        }

                                                        this.setEnabled(false);
                                                    });
                                        },
                                        "Goobaa-HomeMacro-DelayThread");
                        thread.setDaemon(true);
                        thread.start();
                    });
        } else {
            this.setEnabled(false);
        }
    }

    private void sendCommand(String text) {
        if (client.getNetworkHandler() != null) {
            String textValue;
            if (text.startsWith("/")) {
                textValue = text.substring(1);
            } else {
                textValue = text;
            }

            client.getNetworkHandler().sendChatCommand(textValue);
        }
    }

    public HomeMacroModule() {
        this.homeSlotSetting = new SliderSetting(this, "Home Slot", 1.0F, 1.0F, 5.0F, 1.0F);
    }
}
