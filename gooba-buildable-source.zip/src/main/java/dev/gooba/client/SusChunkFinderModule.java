package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

@ModuleInfo(
        name = "Sus Chunk Finder",
        category = ModuleCategory.DONUT,
        desc = "Detects suspicious player-loaded chunks")
@Environment(EnvType.CLIENT)
public class SusChunkFinderModule extends Module {
    private static final int[][] NEIGHBOR_OFFSETS =
            new int[][] {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    public final Map<ChunkPos, Integer> missingClusterCounts;
    public final Set<Long> queuedChunks;
    public final Set<ChunkPos> confirmedGeodeChunks;
    public final Set<ChunkPos> rejectedGeodeChunks;
    public final Set<ChunkPos> structureChunks;
    public final SliderSetting simulationDistanceSetting;
    public final Map<ChunkPos, Set<BlockPos>> missingClusterPositions;
    public final Set<ChunkPos> scannedChunks;
    public final SliderSetting alphaSetting;
    private final AtomicBoolean scanning;
    public final Map<ChunkPos, Integer> amethystCounts;

    public final SliderSetting sensitivitySetting =
            new SliderSetting(this, "Sensitivity", 4.0F, 1.0F, 20.0F, 1.0F);
    private final LinkedBlockingQueue<long[]> scanQueue;
    public final ColorSetting chunkColorSetting;
    private final ExecutorService scanner;
    private int ticks;

    public void forgetChunk(ChunkPos chunkpos) {
        this.missingClusterPositions.remove(chunkpos);
        this.missingClusterCounts.remove(chunkpos);
        this.amethystCounts.remove(chunkpos);
        this.structureChunks.remove(chunkpos);
        this.rejectedGeodeChunks.remove(chunkpos);
        this.confirmedGeodeChunks.remove(chunkpos);
        this.scannedChunks.remove(chunkpos);
        this.queuedChunks.remove(chunkKey(chunkpos.x, chunkpos.z));
    }

    private int findLightBoundaryZ(World world, int i, int j, int k) {
        int l = k + 1;
        Mutable mutable = new Mutable();

        while (true) {
            mutable.set(i, j, l);
            BlockState blockstate = world.getBlockState(mutable);
            if (!blockstate.isAir() && !blockstate.isOf(Blocks.AMETHYST_CLUSTER)) {
                return l;
            }

            if (world.getLightLevel(LightType.BLOCK, mutable) != 4) {
                return l - 1;
            }

            l++;
        }
    }

    public int getSimulationDistance() {
        return Math.round(this.simulationDistanceSetting.getFloat());
    }

    public void processScanQueue() {
        if (this.isEnabled() && !this.scanning.get() && !this.scanQueue.isEmpty()) {
            if (this.scanning.compareAndSet(false, true)) {
                this.scanner.submit(
                        () -> {
                            try {
                                while (this.isEnabled() && !this.scanQueue.isEmpty()) {
                                    long[] along = this.scanQueue.poll();
                                    if (along == null) {
                                        break;
                                    }

                                    int i = (int) along[0];
                                    int j = (int) along[1];
                                    this.queuedChunks.remove(chunkKey(i, j));
                                    if (client.world != null && client.world.isChunkLoaded(i, j)) {
                                        WorldChunk worldchunk = client.world.getChunk(i, j);
                                        if (worldchunk != null) {
                                            this.scanChunk(client.world, worldchunk);
                                        }
                                    }
                                }
                            } catch (Throwable throwable) {
                            } finally {
                                this.scanning.set(false);
                            }
                        });
            }
        }
    }

    public int getViewDistance() {
        if (client.options == null) {
            return 16;
        } else {
            try {
                return Math.max(2, Math.min(32, client.options.getViewDistance().getValue()));
            } catch (Throwable throwable) {
                return 16;
            }
        }
    }

    private void queueVisibleChunks() {
        if (client.player != null && client.world != null) {
            int viewDistance = this.getViewDistance();
            ChunkPos chunkpos = client.player.getChunkPos();

            for (int j = -viewDistance; j <= viewDistance; j++) {
                for (int k = -viewDistance; k <= viewDistance; k++) {
                    this.queueChunk(chunkpos.x + j, chunkpos.z + k);
                }
            }
        }
    }

    private static void findMaximalCliques(
            Set<Integer> set,
            Set<Integer> setValue,
            Set<Integer> set2,
            boolean[][] aboolean,
            List<Set<Integer>> list) {
        if (setValue.isEmpty() && set2.isEmpty()) {
            if (!set.isEmpty()) {
                list.add(new HashSet(set));
            }
        } else {
            for (int i : (Iterable<Integer>) (Iterable) new ArrayList(setValue)) {
                HashSet hashset = new HashSet(set);
                hashset.add(i);
                HashSet hashSet = new HashSet();

                for (int j : setValue) {
                    if (aboolean[i][j]) {
                        hashSet.add(j);
                    }
                }

                HashSet hashSetValue = new HashSet();

                for (int k : set2) {
                    if (aboolean[i][k]) {
                        hashSetValue.add(k);
                    }
                }

                findMaximalCliques(hashset, hashSet, hashSetValue, aboolean, list);
                setValue.remove(i);
                set2.add(i);
            }
        }
    }

    private void scanChunk(World world, WorldChunk worldchunk) {
        if (worldchunk != null) {
            ChunkPos chunkpos = worldchunk.getPos();
            if (!this.confirmedGeodeChunks.contains(chunkpos)) {
                BlockPos blockpos = this.findGeodeCenter(world, worldchunk);
                if (blockpos != null) {
                    this.scanGeodeLighting(world, worldchunk, blockpos);
                    if (!this.confirmedGeodeChunks.contains(chunkpos)) {
                        this.scanChunkLighting(world, worldchunk);
                    }
                } else {
                    this.scanChunkLighting(world, worldchunk);
                }
            }
        }
    }

    @Override
    protected void onEnable() {
        this.scanQueue.clear();
        this.queuedChunks.clear();
        this.missingClusterPositions.clear();
        this.missingClusterCounts.clear();
        this.amethystCounts.clear();
        this.structureChunks.clear();
        this.rejectedGeodeChunks.clear();
        this.confirmedGeodeChunks.clear();
        this.scannedChunks.clear();
        this.ticks = 0;
        this.queueVisibleChunks();
    }

    private BlockPos findGeodeCenter(World world, WorldChunk worldchunk) {
        ChunkPos chunkpos = worldchunk.getPos();
        int startX = chunkpos.getStartX();
        int startZ = chunkpos.getStartZ();
        Mutable mutable = new Mutable();
        int k = 0;
        int l = 0;
        int i1 = 0;
        int j1 = 0;

        for (int k1 = -64; k1 <= 64; k1++) {
            for (int startXValue = startX; startXValue < startX + 16; startXValue++) {
                for (int startZValue = startZ; startZValue < startZ + 16; startZValue++) {
                    mutable.set(startXValue, k1, startZValue);
                    BlockState blockstate = world.getBlockState(mutable);
                    if (blockstate.isOf(Blocks.AMETHYST_BLOCK)
                            || blockstate.isOf(Blocks.BUDDING_AMETHYST)
                            || blockstate.isOf(Blocks.BLACK_CANDLE_CAKE)
                            || blockstate.isOf(Blocks.RED_CANDLE_CAKE)) {
                        k += startXValue;
                        l += k1;
                        i1 += startZValue;
                        j1++;
                    }
                }
            }
        }

        return j1 < 5 ? null : new BlockPos(k / j1, l / j1, i1 / j1);
    }

    private void scanGeodeLighting(World world, WorldChunk worldchunk, BlockPos blockpos) {
        ChunkPos chunkpos = worldchunk.getPos();
        HashSet hashset = new HashSet();
        HashSet hashSet = new HashSet();
        Mutable mutable = new Mutable();
        Mutable mutableValue = new Mutable();
        int startX = chunkpos.getStartX();
        int startZ = chunkpos.getStartZ();
        int k = Math.max(startX - 2, blockpos.getX() - 8);
        int l = Math.min(startX + 17, blockpos.getX() + 8);
        int i1 = Math.max(-64, blockpos.getY() - 8);
        int j1 = Math.min(64, blockpos.getY() + 8);
        int k1 = Math.max(startZ - 2, blockpos.getZ() - 8);
        int l1 = Math.min(startZ + 17, blockpos.getZ() + 8);

        for (int i2 = i1; i2 <= j1; i2++) {
            for (int j2 = k; j2 <= l; j2++) {
                for (int k2 = k1; k2 <= l1; k2++) {
                    mutable.set(j2, i2, k2);
                    BlockState blockstate = world.getBlockState(mutable);
                    if (blockstate.isOf(Blocks.RED_CANDLE_CAKE)) {
                        boolean flag2 = false;

                        for (int[] values : NEIGHBOR_OFFSETS) {
                            mutableValue.set(j2 + values[0], i2 + values[1], k2 + values[2]);
                            BlockState blockState = world.getBlockState(mutableValue);
                            if ((blockState.isAir()
                                            || blockState.isOf(Blocks.WATER)
                                            || blockState.isOf(Blocks.SOUL_SAND)
                                            || !blockState.getFluidState().isEmpty())
                                    && !blockState.isOf(Blocks.AMETHYST_CLUSTER)) {
                                flag2 = true;
                                break;
                            }
                        }

                        if (flag2) {
                            hashSet.add(mutable.toImmutable());
                        }
                    } else if (blockstate.isOf(Blocks.AMETHYST_CLUSTER)) {
                        hashset.add(mutable.toImmutable());
                        if (hashset.size() >= 9000) {
                            break;
                        }
                    } else {
                        if (hashset.size() >= 9000) {
                            break;
                        }

                        boolean flag;
                        flag =
                                !(!blockstate.isAir()
                                        && !blockstate.isOf(Blocks.WATER)
                                        && !blockstate.isOf(Blocks.SOUL_SAND));

                        if (!flag) {
                            k2 = this.findLightBoundaryZ(world, j2, i2, k2);
                        } else {
                            int lightLevel = world.getLightLevel(LightType.BLOCK, mutable);
                            if (lightLevel == 4) {
                                k2 = this.findLightBoundaryZ(world, j2, i2, k2);
                            } else if (lightLevel != 0) {
                                if (lightLevel < 4) {
                                    k2 = this.findLightBoundaryZ(world, j2, i2, k2);
                                }
                            } else {
                                int i3 = 0;
                                boolean flag1 = false;

                                for (int[] aint : NEIGHBOR_OFFSETS) {
                                    mutableValue.set(j2 + aint[0], i2 + aint[1], k2 + aint[2]);
                                    int lightLevelValue =
                                            world.getLightLevel(LightType.BLOCK, mutableValue);
                                    if (lightLevelValue > i3) {
                                        i3 = lightLevelValue;
                                        if (lightLevelValue == 4) {
                                            BlockState blockStateValue =
                                                    world.getBlockState(mutableValue);
                                            if (blockStateValue.isAir()
                                                    && !blockStateValue.isOf(
                                                            Blocks.AMETHYST_CLUSTER)) {
                                                flag1 = true;
                                            }
                                        }
                                    }
                                }

                                if (i3 == 4 && flag1) {
                                    hashset.add(mutable.toImmutable());
                                }
                            }
                        }
                    }
                }
            }
        }

        int k3 = Math.max(6, Math.round(this.sensitivitySetting.getFloat()) * 3);
        ArrayList arraylist = new ArrayList(hashset);
        ArrayList arrayList = new ArrayList();
        boolean[] aboolean = new boolean[arraylist.size()];

        for (int l3 = 0; l3 < arraylist.size(); l3++) {
            if (!aboolean[l3]) {
                HashSet hashSetValue = new HashSet();
                ArrayDeque arraydeque = new ArrayDeque();
                arraydeque.add(l3);
                aboolean[l3] = true;

                while (!arraydeque.isEmpty()) {
                    int j4 = (Integer) arraydeque.poll();
                    BlockPos blockPos = (BlockPos) arraylist.get(j4);
                    hashSetValue.add(blockPos);

                    for (int k4 = 0; k4 < arraylist.size(); k4++) {
                        if (!aboolean[k4]) {
                            BlockPos blockPosValue = (BlockPos) arraylist.get(k4);
                            if (blockPos.getSquaredDistance(blockPosValue) <= 36.0) {
                                aboolean[k4] = true;
                                arraydeque.add(k4);
                            }
                        }
                    }
                }

                if (hashSetValue.size() >= k3) {
                    arrayList.add(hashSetValue);
                }
            }
        }

        Set setx = null;
        int i4 = 0;

        for (Set setxValue : (Iterable<Set>) (Iterable) arrayList) {
            if (setxValue.size() > i4) {
                i4 = setxValue.size();
                setx = setxValue;
            }
        }

        this.missingClusterCounts.put(chunkpos, i4);
        if (setx != null && i4 >= k3) {
            this.amethystCounts.put(chunkpos, hashSet.size());
            this.missingClusterPositions.put(chunkpos, setx);
            this.confirmedGeodeChunks.add(chunkpos);
            this.rejectedGeodeChunks.remove(chunkpos);
            this.scannedChunks.add(chunkpos);
        } else if (!this.confirmedGeodeChunks.contains(chunkpos)) {
            this.missingClusterCounts.put(chunkpos, 0);
            this.amethystCounts.put(chunkpos, Math.max(1, hashSet.size()));
            this.rejectedGeodeChunks.add(chunkpos);
            this.missingClusterPositions.remove(chunkpos);
            this.scannedChunks.add(chunkpos);
        }
    }

    private void collectConnectedPositions(
            boolean[] aboolean,
            int i,
            Queue<Integer> queue,
            List<BlockPos> list,
            int j,
            List<List<BlockPos>> listValue) {
        ArrayList arraylist = new ArrayList();
        queue.add(i);
        aboolean[i] = true;

        while (!queue.isEmpty()) {
            int k = (Integer) queue.poll();
            BlockPos blockpos = (BlockPos) list.get(k);
            arraylist.add(blockpos);

            for (int l = 0; l < list.size(); l++) {
                if (!aboolean[l]) {
                    BlockPos blockPos = (BlockPos) list.get(l);
                    if (blockpos.getSquaredDistance(blockPos) <= 121.0) {
                        aboolean[l] = true;
                        queue.add(l);
                    }
                }
            }
        }

        if (arraylist.size() >= j) {
            listValue.add(arraylist);
        }
    }

    @Override
    protected void onDisable() {
        this.scanQueue.clear();
        this.queuedChunks.clear();
        this.missingClusterPositions.clear();
        this.missingClusterCounts.clear();
        this.amethystCounts.clear();
        this.structureChunks.clear();
        this.rejectedGeodeChunks.clear();
        this.confirmedGeodeChunks.clear();
        this.scannedChunks.clear();
    }

    public List<SusChunkFinderModule.SusRegion> findSuspiciousRegions() {
        if (this.missingClusterCounts.isEmpty()
                && this.rejectedGeodeChunks.isEmpty()
                && this.confirmedGeodeChunks.isEmpty()) {
            return Collections.emptyList();
        } else {
            int simulationDistance = this.getSimulationDistance();
            int j = Math.max(1, Math.round(this.sensitivitySetting.getFloat()) * 3);
            HashSet hashset = new HashSet<>(this.missingClusterCounts.keySet());
            hashset.addAll(this.rejectedGeodeChunks);
            hashset.addAll(this.confirmedGeodeChunks);
            ArrayList arraylist = new ArrayList(hashset);
            ArrayList arrayList = new ArrayList();
            HashSet hashSet = new HashSet();

            for (ChunkPos chunkpos : (Iterable<ChunkPos>) (Iterable) arraylist) {
                if (!hashSet.contains(chunkpos)) {
                    ArrayList arrayListValue = new ArrayList();
                    ArrayDeque arraydeque = new ArrayDeque();
                    arraydeque.add(chunkpos);
                    hashSet.add(chunkpos);
                    int k = chunkpos.x;
                    int l = chunkpos.x;
                    int i1 = chunkpos.z;
                    int j1 = chunkpos.z;
                    int k1 = 0;
                    int l1 = 0;
                    int i2 = 0;

                    while (!arraydeque.isEmpty()) {
                        ChunkPos chunkPos = (ChunkPos) arraydeque.poll();
                        arrayListValue.add(chunkPos);
                        k = Math.min(k, chunkPos.x);
                        l = Math.max(l, chunkPos.x);
                        i1 = Math.min(i1, chunkPos.z);
                        j1 = Math.max(j1, chunkPos.z);
                        int orDefault = this.missingClusterCounts.getOrDefault(chunkPos, 0);
                        k1 += orDefault;
                        l1 = Math.max(l1, orDefault);
                        i2 += this.amethystCounts.getOrDefault(chunkPos, 0);

                        for (ChunkPos chunkPosValue : (Iterable<ChunkPos>) (Iterable) arraylist) {
                            if (!hashSet.contains(chunkPosValue)
                                    && Math.abs(chunkPos.x - chunkPosValue.x) <= 1
                                    && Math.abs(chunkPos.z - chunkPosValue.z) <= 1
                                    && Math.max(l, chunkPosValue.x) - Math.min(k, chunkPosValue.x)
                                            <= 1
                                    && Math.max(j1, chunkPosValue.z) - Math.min(i1, chunkPosValue.z)
                                            <= 1) {
                                hashSet.add(chunkPosValue);
                                arraydeque.add(chunkPosValue);
                            }
                        }
                    }

                    boolean flag1;
                    flag1 = !(l1 < j && k1 < j);

                    for (ChunkPos chunkPos2 : (Iterable<ChunkPos>) (Iterable) arrayListValue) {
                        if (this.confirmedGeodeChunks.contains(chunkPos2)) {
                            flag1 = true;
                            break;
                        }
                    }

                    arrayList.add(
                            new SusChunkFinderModule.GeodeStructure(
                                    k, l, i1, j1, arrayListValue, k1, l1, i2, flag1));
                }
            }

            ArrayList arrayList2 = new ArrayList();
            ArrayList arrayList3 = new ArrayList();
            HashSet hashSetValue = new HashSet();
            HashSet hashSet2 = new HashSet();

            for (SusChunkFinderModule.GeodeStructure geodeStructure :
                    (Iterable<SusChunkFinderModule.GeodeStructure>) (Iterable) arrayList) {
                if (geodeStructure.confirmed) {
                    arrayList2.add(geodeStructure);
                    hashSetValue.addAll(geodeStructure.chunks);
                    this.confirmedGeodeChunks.addAll(geodeStructure.chunks);
                } else {
                    arrayList3.add(geodeStructure);
                    hashSet2.addAll(geodeStructure.chunks);
                }
            }

            this.structureChunks.clear();
            this.structureChunks.addAll(hashSetValue);
            this.rejectedGeodeChunks.clear();
            this.rejectedGeodeChunks.addAll(hashSet2);
            int count = arrayList2.size();
            if (count == 0) {
                return Collections.emptyList();
            } else {
                ArrayList arrayList4 = new ArrayList();
                ArrayList arrayList5 = new ArrayList();
                if (count == 1) {
                    SusChunkFinderModule.GeodeStructure geodeStructureValue =
                            (SusChunkFinderModule.GeodeStructure) arrayList2.get(0);
                    arrayList4.add(
                            new int[] {
                                geodeStructureValue.centerChunkX - simulationDistance,
                                geodeStructureValue.centerChunkZ - simulationDistance,
                                geodeStructureValue.centerChunkX + simulationDistance,
                                geodeStructureValue.centerChunkZ + simulationDistance
                            });
                    arrayList5.add(1);
                } else {
                    boolean[][] aboolean = new boolean[count][count];

                    for (int l4 = 0; l4 < count; l4++) {
                        SusChunkFinderModule.GeodeStructure geodeStructure2 =
                                (SusChunkFinderModule.GeodeStructure) arrayList2.get(l4);

                        for (int j5 = l4 + 1; j5 < count; j5++) {
                            SusChunkFinderModule.GeodeStructure geodeStructure3 =
                                    (SusChunkFinderModule.GeodeStructure) arrayList2.get(j5);
                            int j6 =
                                    Math.abs(
                                            geodeStructure2.centerChunkX
                                                    - geodeStructure3.centerChunkX);
                            int l6 =
                                    Math.abs(
                                            geodeStructure2.centerChunkZ
                                                    - geodeStructure3.centerChunkZ);
                            if (j6 <= 2 * simulationDistance && l6 <= 2 * simulationDistance) {
                                aboolean[l4][j5] = true;
                                aboolean[j5][l4] = true;
                            }
                        }
                    }

                    ArrayList arrayList6 = new ArrayList();
                    HashSet hashSet3 = new HashSet();

                    for (int k5 = 0; k5 < count; k5++) {
                        hashSet3.add(k5);
                    }

                    findMaximalCliques(
                            new HashSet<>(), hashSet3, new HashSet<>(), aboolean, arrayList6);
                    HashSet hashSet4 = new HashSet();

                    for (Set setx : (Iterable<Set>) (Iterable) arrayList6) {
                        if (setx.size() > 1) {
                            int MIN_VALUE = Integer.MIN_VALUE;
                            int MAX_VALUE = Integer.MAX_VALUE;
                            int MIN_VALUEValue = Integer.MIN_VALUE;
                            int MAX_VALUEValue = Integer.MAX_VALUE;

                            for (int i3 : (Iterable<Integer>) (Iterable) setx) {
                                SusChunkFinderModule.GeodeStructure geodeStructure4 =
                                        (SusChunkFinderModule.GeodeStructure) arrayList2.get(i3);
                                MIN_VALUE =
                                        Math.max(
                                                MIN_VALUE,
                                                geodeStructure4.centerChunkX - simulationDistance);
                                MAX_VALUE =
                                        Math.min(
                                                MAX_VALUE,
                                                geodeStructure4.centerChunkX + simulationDistance);
                                MIN_VALUEValue =
                                        Math.max(
                                                MIN_VALUEValue,
                                                geodeStructure4.centerChunkZ - simulationDistance);
                                MAX_VALUEValue =
                                        Math.min(
                                                MAX_VALUEValue,
                                                geodeStructure4.centerChunkZ + simulationDistance);
                            }

                            if (MIN_VALUE <= MAX_VALUE && MIN_VALUEValue <= MAX_VALUEValue) {
                                arrayList4.add(
                                        new int[] {
                                            MIN_VALUE, MIN_VALUEValue, MAX_VALUE, MAX_VALUEValue
                                        });
                                arrayList5.add(setx.size());
                                hashSet4.addAll(setx);
                            }
                        }
                    }

                    for (int l5 = 0; l5 < count; l5++) {
                        if (!hashSet4.contains(l5)) {
                            SusChunkFinderModule.GeodeStructure geodeStructure5 =
                                    (SusChunkFinderModule.GeodeStructure) arrayList2.get(l5);
                            arrayList4.add(
                                    new int[] {
                                        geodeStructure5.centerChunkX - simulationDistance,
                                        geodeStructure5.centerChunkZ - simulationDistance,
                                        geodeStructure5.centerChunkX + simulationDistance,
                                        geodeStructure5.centerChunkZ + simulationDistance
                                    });
                            arrayList5.add(1);
                        }
                    }
                }

                ArrayList arrayList7 = new ArrayList();
                HashSet hashSet5 = new HashSet();

                for (int i5 = 0; i5 < arrayList4.size(); i5++) {
                    int[] aint = (int[]) arrayList4.get(i5);
                    int i6 = aint[0];
                    int k6 = aint[1];
                    int j7 = aint[2];
                    int l7 = aint[3];
                    int i8 = (Integer) arrayList5.get(i5);
                    int j8 = j7 - i6 + 1;
                    int k8 = l7 - k6 + 1;
                    if (j8 > 0 && k8 > 0) {
                        ArrayList arrayList8 = new ArrayList();

                        for (SusChunkFinderModule.GeodeStructure geodeStructure6 :
                                (Iterable<SusChunkFinderModule.GeodeStructure>)
                                        (Iterable) arrayList3) {
                            int j3 = geodeStructure6.centerChunkX - simulationDistance;
                            int k3 = geodeStructure6.centerChunkX + simulationDistance;
                            int l3 = geodeStructure6.centerChunkZ - simulationDistance;
                            int i4 = geodeStructure6.centerChunkZ + simulationDistance;
                            if (j3 <= j7 && k3 >= i6 && l3 <= l7 && i4 >= k6) {
                                arrayList8.add(geodeStructure6);
                            }
                        }

                        if (arrayList8.isEmpty()) {
                            String text = i6 + ":" + k6 + ":" + j7 + ":" + l7;
                            if (hashSet5.add(text)) {
                                arrayList7.add(
                                        new SusChunkFinderModule.SusRegion(
                                                i6, k6, j7, l7, i8, simulationDistance));
                            }
                        } else {
                            boolean[][] valuesArray = new boolean[j8][k8];
                            int l8 = 0;

                            for (int i9 = 0; i9 < j8; i9++) {
                                int k9 = i6 + i9;

                                for (int i10 = 0; i10 < k8; i10++) {
                                    int k10 = k6 + i10;
                                    boolean flag = false;

                                    for (SusChunkFinderModule.GeodeStructure geodeStructure7 :
                                            (Iterable<SusChunkFinderModule.GeodeStructure>)
                                                    (Iterable) arrayList8) {
                                        if (k9 >= geodeStructure7.centerChunkX - simulationDistance
                                                && k9
                                                        <= geodeStructure7.centerChunkX
                                                                + simulationDistance
                                                && k10
                                                        >= geodeStructure7.centerChunkZ
                                                                - simulationDistance
                                                && k10
                                                        <= geodeStructure7.centerChunkZ
                                                                + simulationDistance) {
                                            flag = true;
                                            break;
                                        }
                                    }

                                    boolean[] values = valuesArray[i9];
                                    if (!flag) {
                                        values[i10] = true;
                                    } else {
                                        values[i10] = false;
                                    }

                                    if (!flag) {
                                        l8++;
                                    }
                                }
                            }

                            if (l8 == 0) {
                                String textValue = i6 + ":" + k6 + ":" + j7 + ":" + l7;
                                if (hashSet5.add(textValue)) {
                                    arrayList7.add(
                                            new SusChunkFinderModule.SusRegion(
                                                    i6, k6, j7, l7, i8, simulationDistance));
                                }
                            } else {
                                for (int j9 = 0; j9 < k8; j9++) {
                                    for (int l9 = 0; l9 < j8; l9++) {
                                        if (valuesArray[l9][j9]) {
                                            int j10 = 0;

                                            while (l9 + j10 < j8 && valuesArray[l9 + j10][j9]) {
                                                j10++;
                                            }

                                            int l10;
                                            for (l10 = 1; j9 + l10 < k8; l10++) {
                                                boolean flag2 = true;

                                                for (int k11 = 0; k11 < j10; k11++) {
                                                    if (!valuesArray[l9 + k11][j9 + l10]) {
                                                        flag2 = false;
                                                        break;
                                                    }
                                                }

                                                if (!flag2) {
                                                    break;
                                                }
                                            }

                                            for (int i11 = 0; i11 < l10; i11++) {
                                                for (int l11 = 0; l11 < j10; l11++) {
                                                    valuesArray[l9 + l11][j9 + i11] = false;
                                                }
                                            }

                                            int j11 = i6 + l9;
                                            int i12 = i6 + l9 + j10 - 1;
                                            int j12 = k6 + j9;
                                            int j4 = k6 + j9 + l10 - 1;
                                            String text2 = j11 + ":" + j12 + ":" + i12 + ":" + j4;
                                            if (hashSet5.add(text2)) {
                                                arrayList7.add(
                                                        new SusChunkFinderModule.SusRegion(
                                                                j11,
                                                                j12,
                                                                i12,
                                                                j4,
                                                                i8,
                                                                simulationDistance));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                return arrayList7;
            }
        }
    }

    private void scanChunkLighting(World world, WorldChunk worldchunk) {
        if (worldchunk != null) {
            ChunkPos chunkpos = worldchunk.getPos();
            int startX = chunkpos.getStartX();
            int startZ = chunkpos.getStartZ();
            Mutable mutable = new Mutable();
            Mutable mutableValue = new Mutable();
            ArrayList arraylist = new ArrayList();
            HashSet hashset = new HashSet();

            for (int k = -64; k <= 64; k++) {
                for (int l = 0; l < 16; l++) {
                    int i1 = startX + l;

                    for (int j1 = 0; j1 < 16; j1++) {
                        int k1 = startZ + j1;
                        mutable.set(i1, k, k1);
                        BlockState blockstate = world.getBlockState(mutable);
                        if (blockstate.isOf(Blocks.MAGMA_BLOCK)
                                || blockstate.isOf(Blocks.CRYING_OBSIDIAN)) {
                            this.forgetChunk(chunkpos);
                            return;
                        }

                        int lightLevel = world.getLightLevel(LightType.BLOCK, mutable);
                        if (lightLevel >= 6) {
                            hashset.add(chunkKey(i1 >> 3, k1 >> 3));
                        } else if (lightLevel >= 3 && lightLevel <= 5) {
                            boolean flag = false;

                            for (int[] aint : NEIGHBOR_OFFSETS) {
                                mutableValue.set(i1 + aint[0], k + aint[1], k1 + aint[2]);
                                BlockState blockState = world.getBlockState(mutableValue);
                                if (blockState.isOf(Blocks.MAGMA_BLOCK)
                                        || blockState.isOf(Blocks.CRYING_OBSIDIAN)) {
                                    flag = true;
                                    break;
                                }
                            }

                            if (flag) {
                                this.forgetChunk(chunkpos);
                                return;
                            }

                            boolean flag1 = true;

                            for (int[] values : NEIGHBOR_OFFSETS) {
                                mutableValue.set(i1 + values[0], k + values[1], k1 + values[2]);
                                int lightLevelValue =
                                        world.getLightLevel(LightType.BLOCK, mutableValue);
                                if (lightLevelValue >= 6) {
                                    hashset.add(chunkKey(i1 >> 3, k1 >> 3));
                                    flag1 = false;
                                    break;
                                }

                                if (lightLevelValue > lightLevel) {
                                    flag1 = false;
                                    break;
                                }
                            }

                            if (flag1) {
                                arraylist.add(new BlockPos(i1, k, k1));
                            }
                        }
                    }
                }
            }

            ArrayList arrayList = new ArrayList();

            for (BlockPos blockPos : (Iterable<BlockPos>) (Iterable) arraylist) {
                long j5 = chunkKey(blockPos.getX() >> 3, blockPos.getZ() >> 3);
                if (!hashset.contains(j5)) {
                    arrayList.add(blockPos);
                }
            }

            int i5 = Math.max(6, Math.round(this.sensitivitySetting.getFloat()) * 3);
            if (arrayList.size() < i5) {
                if (!this.confirmedGeodeChunks.contains(chunkpos)
                        && !this.rejectedGeodeChunks.contains(chunkpos)) {
                    this.forgetChunk(chunkpos);
                }
            } else {
                ArrayList arrayListValue = new ArrayList();
                boolean[] aboolean = new boolean[arrayList.size()];

                for (int k5 = 0; k5 < arrayList.size(); k5++) {
                    if (!aboolean[k5]) {
                        new ArrayList();
                        ArrayDeque arraydeque = new ArrayDeque();
                        arraydeque.add(k5);
                        this.collectConnectedPositions(
                                aboolean, k5, arraydeque, arrayList, i5, arrayListValue);
                    }
                }

                int l5 = 0;
                HashSet hashSet = new HashSet();

                for (List list : (Iterable<List>) (Iterable) arrayListValue) {
                    int count = list.size();
                    if (count >= i5) {
                        double d20 = 0.0;
                        double d21 = 0.0;
                        double d22 = 0.0;

                        for (BlockPos blockpos : (Iterable<BlockPos>) (Iterable) list) {
                            d20 += (double) blockpos.getX();
                            d21 += (double) blockpos.getY();
                            d22 += (double) blockpos.getZ();
                        }

                        double d23 = d20 / (double) count;
                        double d0 = d21 / (double) count;
                        double d1 = d22 / (double) count;
                        double[][] adouble = new double[4][4];
                        double[] valuesValue = new double[4];

                        for (BlockPos blockPosValue : (Iterable<BlockPos>) (Iterable) list) {
                            double d2 = (double) blockPosValue.getX() - d23;
                            double d4 = (double) blockPosValue.getY() - d0;
                            double d6 = (double) blockPosValue.getZ() - d1;
                            double d8 = d2 * d2 + d4 * d4 + d6 * d6;
                            double[] values2 = new double[] {d2, d4, d6, 1.0};

                            for (int j2 = 0; j2 < 4; j2++) {
                                for (int k2 = 0; k2 < 4; k2++) {
                                    adouble[j2][k2] = adouble[j2][k2] + values2[j2] * values2[k2];
                                }

                                valuesValue[j2] += values2[j2] * d8;
                            }
                        }

                        double[] dValArray = solveLinearSystem(adouble, valuesValue);
                        if (dValArray != null) {
                            double d24 = dValArray[0] / 2.0;
                            double d3 = dValArray[1] / 2.0;
                            double d5 = dValArray[2] / 2.0;
                            double d7 = dValArray[3] + d24 * d24 + d3 * d3 + d5 * d5;
                            if (!(d7 <= 0.0)) {
                                double d9 = Math.sqrt(d7);
                                double d25 = d23 + d24;
                                double d10 = d0 + d3;
                                double d11 = d1 + d5;
                                if (!(d9 < 3.0) && !(d9 > 7.0)) {
                                    double d12 = 0.0;
                                    double d13 = 0.0;
                                    double d14 = 0.0;
                                    double d15 = 0.0;
                                    HashSet hashSetValue = new HashSet();
                                    int MAX_VALUE = Integer.MAX_VALUE;
                                    int MIN_VALUE = Integer.MIN_VALUE;
                                    int MAX_VALUEValue = Integer.MAX_VALUE;
                                    int MIN_VALUEValue = Integer.MIN_VALUE;
                                    int MAX_VALUE2 = Integer.MAX_VALUE;
                                    int MIN_VALUE2 = Integer.MIN_VALUE;

                                    for (BlockPos blockPos2 :
                                            (Iterable<BlockPos>) (Iterable) list) {
                                        double d16 = (double) blockPos2.getX() - d25;
                                        double d17 = (double) blockPos2.getY() - d10;
                                        double d18 = (double) blockPos2.getZ() - d11;
                                        double d19 = Math.sqrt(d16 * d16 + d17 * d17 + d18 * d18);
                                        if (d19 < 1.0E-4) {
                                            d19 = 1.0;
                                        }

                                        int b0;
                                        int l4;
                                        label197:
                                        {
                                            int l6;
                                            label196:
                                            {
                                                label195:
                                                {
                                                    label194:
                                                    {
                                                        d12 += Math.abs(d19 - d9);
                                                        d13 += d16 / d19;
                                                        d14 += d17 / d19;
                                                        d15 += d18 / d19;
                                                        if (d16 >= 0.0) {
                                                            b0 = 1;
                                                            if (!(d17 >= 0.0)) {
                                                                break label194;
                                                            }
                                                        } else {
                                                            b0 = 0;
                                                            if (!(d17 >= 0.0)) {
                                                                break label194;
                                                            }
                                                        }

                                                        l6 = b0 | 2;
                                                        if (d18 >= 0.0) {
                                                            break label196;
                                                        }
                                                        break label195;
                                                    }

                                                    l6 = b0 | 0;
                                                    if (d18 >= 0.0) {
                                                        break label196;
                                                    }
                                                }

                                                l4 = l6 | 0;
                                                break label197;
                                            }

                                            l4 = l6 | 4;
                                        }

                                        hashSetValue.add(l4);
                                        MAX_VALUE = Math.min(MAX_VALUE, blockPos2.getX());
                                        MIN_VALUE = Math.max(MIN_VALUE, blockPos2.getX());
                                        MAX_VALUEValue = Math.min(MAX_VALUEValue, blockPos2.getY());
                                        MIN_VALUEValue = Math.max(MIN_VALUEValue, blockPos2.getY());
                                        MAX_VALUE2 = Math.min(MAX_VALUE2, blockPos2.getZ());
                                        MIN_VALUE2 = Math.max(MIN_VALUE2, blockPos2.getZ());
                                    }

                                    double d26 = d12 / (double) count;
                                    if (!(d26 > 1.35) && hashSetValue.size() >= 3) {
                                        double d27 =
                                                Math.sqrt(d13 * d13 + d14 * d14 + d15 * d15)
                                                        / (double) count;
                                        if (!(d27 > 0.72)) {
                                            mutable.set(
                                                    (int) Math.round(d25),
                                                    (int) Math.round(d10),
                                                    (int) Math.round(d11));
                                            int lightLevel2 =
                                                    world.getLightLevel(LightType.BLOCK, mutable);
                                            if (lightLevel2 <= 3) {
                                                int j4 = MIN_VALUE - MAX_VALUE + 1;
                                                int k6 = MIN_VALUEValue - MAX_VALUEValue + 1;
                                                int k4 = MIN_VALUE2 - MAX_VALUE2 + 1;
                                                if ((j4 >= 3 || k4 >= 3)
                                                        && j4 + k4 >= 6
                                                        && k6 >= 2
                                                        && count > l5) {
                                                    l5 = count;
                                                    hashSet = new HashSet(list);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (l5 >= i5) {
                    this.missingClusterCounts.put(chunkpos, l5);
                    this.amethystCounts.put(chunkpos, 0);
                    this.missingClusterPositions.put(chunkpos, hashSet);
                    this.confirmedGeodeChunks.add(chunkpos);
                    this.rejectedGeodeChunks.remove(chunkpos);
                    this.scannedChunks.add(chunkpos);
                } else if (!this.confirmedGeodeChunks.contains(chunkpos)
                        && !this.rejectedGeodeChunks.contains(chunkpos)) {
                    this.forgetChunk(chunkpos);
                }
            }
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null) {
            List list = this.findSuspiciousRegions();
            if (!list.isEmpty()) {
                int integer = this.chunkColorSetting.getColor();
                int alpha = Math.round(this.alphaSetting.getFloat());
                int k = ColorUtils.withAlpha(integer, alpha);
                WorldEspRenderer.clear();

                for (SusChunkFinderModule.SusRegion susRegion :
                        (Iterable<SusChunkFinderModule.SusRegion>) (Iterable) list) {
                    Box box =
                            new Box(
                                    susRegion.minBlockX(),
                                    60.0,
                                    susRegion.minBlockZ(),
                                    susRegion.maxBlockX(),
                                    60.05,
                                    susRegion.maxBlockZ());
                    WorldEspRenderer.enqueueBox(box, k, false);
                }

                WorldEspRenderer.flush(render3DEvent.getMatrixStack());
            }
        }
    }

    private static double[] solveLinearSystem(double[][] adouble, double[] values) {
        byte b0 = 4;
        double[][] valuesArray = new double[4][5];

        for (int i = 0; i < 4; i++) {
            System.arraycopy(adouble[i], 0, valuesArray[i], 0, 4);
            valuesArray[i][4] = values[i];
        }

        for (int j1 = 0; j1 < b0; j1++) {
            int j = j1;

            for (int k = j1 + 1; k < b0; k++) {
                if (Math.abs(valuesArray[k][j1]) > Math.abs(valuesArray[j][j1])) {
                    j = k;
                }
            }

            double[] valuesValue = valuesArray[j1];
            valuesArray[j1] = valuesArray[j];
            valuesArray[j] = valuesValue;
            if (Math.abs(valuesArray[j1][j1]) < 1.0E-9) {
                return null;
            }

            for (int l = j1 + 1; l < b0; l++) {
                double d0 = valuesArray[l][j1] / valuesArray[j1][j1];

                for (int i1 = j1; i1 <= b0; i1++) {
                    valuesArray[l][i1] = valuesArray[l][i1] - d0 * valuesArray[j1][i1];
                }
            }
        }

        double[] dValArray = new double[b0];

        for (int k1 = b0 - 1; k1 >= 0; k1--) {
            double d1 = 0.0;

            for (int l1 = k1 + 1; l1 < b0; l1++) {
                d1 += valuesArray[k1][l1] * dValArray[l1];
            }

            dValArray[k1] = (valuesArray[k1][b0] - d1) / valuesArray[k1][k1];
        }

        return dValArray;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null) {
            this.ticks++;
            if (this.ticks % 10 == 0) {
                this.pruneDistantChunks();
                int viewDistance = this.getViewDistance();
                ChunkPos chunkpos = client.player.getChunkPos();

                for (int j = -viewDistance; j <= viewDistance; j++) {
                    for (int k = -viewDistance; k <= viewDistance; k++) {
                        this.queueChunk(chunkpos.x + j, chunkpos.z + k);
                    }
                }
            }

            this.processScanQueue();
        }
    }

    public SusChunkFinderModule() {
        this.simulationDistanceSetting =
                new SliderSetting(this, "Simulation Distance", 4.0F, 2.0F, 16.0F, 1.0F);
        this.chunkColorSetting = new ColorSetting(this, "Chunk Color", 16711680);
        this.alphaSetting = new SliderSetting(this, "Alpha", 100.0F, 0.0F, 255.0F, 1.0F);
        this.queuedChunks = ConcurrentHashMap.newKeySet();
        this.scannedChunks = ConcurrentHashMap.newKeySet();
        this.structureChunks = ConcurrentHashMap.newKeySet();
        this.rejectedGeodeChunks = ConcurrentHashMap.newKeySet();
        this.confirmedGeodeChunks = ConcurrentHashMap.newKeySet();
        this.missingClusterCounts = new ConcurrentHashMap<>();
        this.amethystCounts = new ConcurrentHashMap<>();
        this.missingClusterPositions = new ConcurrentHashMap<>();
        this.scanner =
                Executors.newSingleThreadExecutor(
                        runnable -> {
                            Thread thread = new Thread(runnable, "Goobaa-SusChunkFinder-Scanner");
                            thread.setDaemon(true);
                            return thread;
                        });
        this.scanQueue = new LinkedBlockingQueue<>();
        this.scanning = new AtomicBoolean(false);
    }

    @EventHandler
    public void onBlockUpdate(BlockUpdateEvent blockUpdateEvent) {
        if (client.world != null) {
            BlockPos blockpos = blockUpdateEvent.getPos();
            int i = blockpos.getX() >> 4;
            int j = blockpos.getZ() >> 4;
            this.queueChunk(i, j);
        }
    }

    public void queueChunk(int i, int j) {
        long k = chunkKey(i, j);
        if (this.queuedChunks.add(k)) {
            this.scanQueue.offer(new long[] {(long) i, (long) j});
        }
    }

    private static long chunkKey(int i, int j) {

        return (long) i << 32 | (long) j & ((4294967295L));
    }

    private void pruneDistantChunks() {
        if (client.player != null) {
            int i = this.getViewDistance() + 6;
            ChunkPos chunkpos = client.player.getChunkPos();
            HashSet hashset = new HashSet();
            hashset.addAll(this.structureChunks);
            hashset.addAll(this.rejectedGeodeChunks);
            hashset.addAll(this.confirmedGeodeChunks);
            hashset.addAll(this.missingClusterPositions.keySet());
            hashset.addAll(this.missingClusterCounts.keySet());
            hashset.addAll(this.amethystCounts.keySet());

            for (ChunkPos chunkposValue : (Iterable<ChunkPos>) (Iterable) hashset) {
                int j = Math.abs(chunkposValue.x - chunkpos.x);
                int k = Math.abs(chunkposValue.z - chunkpos.z);
                if (Math.max(j, k) > i) {
                    this.forgetChunk(chunkposValue);
                }
            }
        }
    }

    @Environment(EnvType.CLIENT)
    public static class GeodeStructure {
        public final boolean confirmed;
        public final int totalMissingClusters;
        public final int maxChunkZ;
        public final List<ChunkPos> chunks;
        public final int maxChunkX;
        public final int minChunkX;
        public final int amethystCount;
        public final int minChunkZ;
        public final int largestMissingClusterCount;
        public final int centerChunkZ;
        public final int centerChunkX;

        public GeodeStructure(
                int minChunkXValue,
                int maxChunkXValue,
                int minChunkZValue,
                int maxChunkZValue,
                List<ChunkPos> list,
                int totalMissingClustersValue,
                int largestMissingClusterCountValue,
                int amethystCountValue,
                boolean confirmedValue) {
            this.minChunkX = minChunkXValue;
            this.maxChunkX = maxChunkXValue;
            this.minChunkZ = minChunkZValue;
            this.maxChunkZ = maxChunkZValue;
            this.centerChunkX = (int) Math.round((double) (minChunkXValue + maxChunkXValue) / 2.0);
            this.centerChunkZ = (int) Math.round((double) (minChunkZValue + maxChunkZValue) / 2.0);
            this.chunks = list;
            this.totalMissingClusters = totalMissingClustersValue;
            this.largestMissingClusterCount = largestMissingClusterCountValue;
            this.amethystCount = amethystCountValue;
            this.confirmed = confirmedValue;
        }
    }

    @Environment(EnvType.CLIENT)
    public static record SusRegion(
            int minChunkX,
            int minChunkZ,
            int maxChunkX,
            int maxChunkZ,
            int geodeCount,
            int radiusUsed) {
        public double minBlockZ() {
            return (double) this.minChunkZ * 16.0;
        }

        public double maxBlockX() {
            return (double) (this.maxChunkX + 1) * 16.0;
        }

        public double minBlockX() {
            return (double) this.minChunkX * 16.0;
        }

        public double maxBlockZ() {
            return (double) (this.maxChunkZ + 1) * 16.0;
        }
    }
}
