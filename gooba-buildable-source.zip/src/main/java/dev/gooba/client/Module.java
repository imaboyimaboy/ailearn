package dev.gooba.client;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.apache.commons.lang3.NotImplementedException;

import java.util.List;

@Environment(EnvType.CLIENT)
public abstract class Module implements MinecraftAccess {
    public TimedAnimation animation16;
    private boolean enabled;
    public final EasingAnimation animation_new_1;
    public final KeybindSetting keybind;
    public TimedAnimation animation15;
    public final EasingAnimation expandedAnimation;
    public final EasingAnimation toggleAnimation;

    public TimedAnimation animation12;
    public final EasingAnimation hoverModule;
    public final EasingAnimation animtoP8;
    private String description;
    private boolean hidden;
    private final List<Setting<?>> settings = new ObjectArrayList<>();
    public TimedAnimation animation2;
    public TimedAnimation animation;
    private boolean expanded;
    public TimedAnimation animation3;
    private ModuleInfo moduleInfo;
    public TimedAnimation animation14;
    private ModuleCategory category;
    private boolean allowDisable;
    public final EasingAnimation animtoP7;
    private boolean autoEnabled;
    public TimedAnimation animation1;
    private String bigName;
    private String name;
    private int key;
    public final EasingAnimation animation_new;

    public TimedAnimation getAnimation() {
        return this.animation;
    }

    public TimedAnimation getAnimation16() {
        return this.animation16;
    }

    protected void onDisable() {}

    public EasingAnimation getAnimtoP7() {
        return this.animtoP7;
    }

    public void toggle() {
        if (!this.enabled) {
            this.setEnabled(true);
        } else {
            this.setEnabled(false);
        }
    }

    @Override
    public String toString() {
        String settingsValue = String.valueOf(this.getSettings());
        String moduleInfoValue = String.valueOf(this.getModuleInfo());
        String nameValue = this.getName();
        String bigNameValue = this.getBigName();
        String descriptionValue = this.getDescription();
        String categoryValue = String.valueOf(this.getCategory());
        boolean isEnabled = this.isEnabled();
        boolean isAutoEnabled = this.isAutoEnabled();
        boolean isAllowDisable = this.isAllowDisable();
        boolean isHidden = this.isHidden();
        int keyValue = this.getKey();
        String keybindValue = String.valueOf(this.getKeybind());
        String animation_newValue = String.valueOf(this.getAnimation_new());
        String animation_new_1Value = String.valueOf(this.getAnimation_new_1());
        String toggleAnimationValue = String.valueOf(this.getToggleAnimation());
        String hoverModuleValue = String.valueOf(this.getHoverModule());
        String expandedAnimationValue = String.valueOf(this.getExpandedAnimation());
        String text = String.valueOf(this.getAnimtoP7());
        String textValue = String.valueOf(this.getAnimtoP8());
        String animationValue = String.valueOf(this.getAnimation());
        String text3 = String.valueOf(this.getAnimation1());
        String text4 = String.valueOf(this.getAnimation2());
        String text5 = String.valueOf(this.getAnimation3());
        String text6 = String.valueOf(this.getAnimation12());
        String text7 = String.valueOf(this.getAnimation14());
        String text8 = String.valueOf(this.getAnimation15());
        String text9 = String.valueOf(this.getAnimation16());
        boolean isExpanded = this.isExpanded();
        String text10 = text9;
        String text11 = text8;
        String text12 = text7;
        String text13 = text6;
        String text14 = text5;
        String text15 = text4;
        String text16 = text3;
        String animationValueValue = animationValue;
        String textValueValue = textValue;
        String text2 = text;
        String expandedAnimationValueValue = expandedAnimationValue;
        String hoverModuleValueValue = hoverModuleValue;
        String toggleAnimationValueValue = toggleAnimationValue;
        String animation_new_1ValueValue = animation_new_1Value;
        String animation_newValueValue = animation_newValue;
        String keybindValueValue = keybindValue;
        int keyValueValue = keyValue;
        boolean isHiddenValue = isHidden;
        boolean isAllowDisableValue = isAllowDisable;
        boolean isAutoEnabledValue = isAutoEnabled;
        boolean isEnabledValue = isEnabled;
        String categoryValueValue = categoryValue;
        String descriptionValueValue = descriptionValue;
        String bigNameValueValue = bigNameValue;
        String nameValueValue = nameValue;
        String moduleInfoValueValue = moduleInfoValue;
        String settingsValueValue = settingsValue;
        return "Module(settings="
                + settingsValueValue
                + ", moduleInfo="
                + moduleInfoValueValue
                + ", name="
                + nameValueValue
                + ", bigName="
                + bigNameValueValue
                + ", desc="
                + descriptionValueValue
                + ", category="
                + categoryValueValue
                + ", enabled="
                + isEnabledValue
                + ", autoEnabled="
                + isAutoEnabledValue
                + ", allowDisable="
                + isAllowDisableValue
                + ", hidden="
                + isHiddenValue
                + ", key="
                + keyValueValue
                + ", keybind="
                + keybindValueValue
                + ", animation_new="
                + animation_newValueValue
                + ", animation_new_1="
                + animation_new_1ValueValue
                + ", toggleAnimation="
                + toggleAnimationValueValue
                + ", hoverModule="
                + hoverModuleValueValue
                + ", expandedAnimation="
                + expandedAnimationValueValue
                + ", animtoP7="
                + text2
                + ", animtoP8="
                + textValueValue
                + ", animation="
                + animationValueValue
                + ", animation1="
                + text16
                + ", animation2="
                + text15
                + ", animation3="
                + text14
                + ", animation12="
                + text13
                + ", animation14="
                + text12
                + ", animation15="
                + text11
                + ", animation16="
                + text10
                + ", expanded="
                + isExpanded
                + ")";
    }

    public String getBigName() {
        return this.bigName;
    }

    public Module() {
        this.keybind = new KeybindSetting("Keybind", -1);
        this.animation_new = new EasingAnimation();
        this.animation_new_1 = new EasingAnimation();
        this.toggleAnimation = new EasingAnimation();
        this.hoverModule = new EasingAnimation();
        this.expandedAnimation = new EasingAnimation();
        this.animtoP7 = new EasingAnimation();
        this.animtoP8 = new EasingAnimation();
        this.animation = new DecelerateAnimation(300, 1.0);
        this.animation1 = new DecelerateAnimation(300, 1.0);
        this.animation2 = new DecelerateAnimation(300, 1.0);
        this.animation3 = new DecelerateAnimation(300, 1.0);
        this.animation12 = new DecelerateAnimation(300, 1.0);
        this.animation14 = new DecelerateAnimation(300, 1.0);
        this.animation15 = new DecelerateAnimation(300, 1.0);
        this.animation16 = new DecelerateAnimation(300, 1.0);
        Class oclass = this.getClass();
        ModuleInfo moduleInfo2 = (ModuleInfo) oclass.getAnnotation(ModuleInfo.class);
        if (moduleInfo2 == null) {
            String simpleName = oclass.getSimpleName();
            throw new NotImplementedException("@ModuleInfo annotation not found on " + simpleName);
        } else {
            this.moduleInfo = moduleInfo2;
            this.name = moduleInfo2.name().trim().replaceAll(" ", "");
            this.bigName = moduleInfo2.name();
            this.description = moduleInfo2.desc();
            this.category = moduleInfo2.category();
            this.autoEnabled = moduleInfo2.autoEnabled();
            this.allowDisable = moduleInfo2.allowDisable();
            this.hidden = moduleInfo2.hidden();
            this.key = moduleInfo2.key();
            this.keybind.setValue(this.key);
            this.initializeSettings();
        }
    }

    public TimedAnimation getAnimation14() {
        return this.animation14;
    }

    public void initializeSettings() {}

    private void enable() {
        if (client.player != null) {
            this.onEnable();
        }

        this.subscribe();
    }

    public EasingAnimation getToggleAnimation() {
        return this.toggleAnimation;
    }

    protected boolean canEqual(Object object) {
        return object instanceof Module;
    }

    public TimedAnimation getAnimation15() {
        return this.animation15;
    }

    public boolean isExpanded() {
        return this.expanded;
    }

    public void setEnabled(boolean enabledValue) {
        this.setEnabled(enabledValue, true);
    }

    public EasingAnimation getHoverModule() {
        return this.hoverModule;
    }

    public TimedAnimation getAnimation12() {
        return this.animation12;
    }

    public ModuleCategory getCategory() {
        return this.category;
    }

    private void disable() {
        if (client.player != null) {
            this.onDisable();
        }

        this.unsubscribe();
    }

    public String getDescription() {
        return this.description;
    }

    public boolean isAutoEnabled() {
        return this.autoEnabled;
    }

    @Override
    public int hashCode() {
        int i = 1;
        i = i * 59 + (this.isEnabled() ? 79 : 97);
        i = i * 59 + (this.isAutoEnabled() ? 79 : 97);
        i = i * 59 + (this.isAllowDisable() ? 79 : 97);
        i = i * 59 + (this.isHidden() ? 79 : 97);
        i = i * 59 + this.getKey();
        i = i * 59 + (this.isExpanded() ? 79 : 97);
        List list = this.getSettings();
        i = i * 59 + (list == null ? 43 : list.hashCode());
        ModuleInfo moduleInfo2 = this.getModuleInfo();
        i = i * 59 + (moduleInfo2 == null ? 43 : moduleInfo2.hashCode());
        String nameValue = this.getName();
        i = i * 59 + (nameValue == null ? 43 : nameValue.hashCode());
        String bigNameValue = this.getBigName();
        i = i * 59 + (bigNameValue == null ? 43 : bigNameValue.hashCode());
        String descriptionValue = this.getDescription();
        i = i * 59 + (descriptionValue == null ? 43 : descriptionValue.hashCode());
        ModuleCategory moduleCategory2 = this.getCategory();
        i = i * 59 + (moduleCategory2 == null ? 43 : moduleCategory2.hashCode());
        KeybindSetting keybindSetting2 = this.getKeybind();
        i = i * 59 + (keybindSetting2 == null ? 43 : keybindSetting2.hashCode());
        EasingAnimation easingAnimation2 = this.getAnimation_new();
        i = i * 59 + (easingAnimation2 == null ? 43 : easingAnimation2.hashCode());
        EasingAnimation easingAnimation3 = this.getAnimation_new_1();
        i = i * 59 + (easingAnimation3 == null ? 43 : easingAnimation3.hashCode());
        EasingAnimation easingAnimation4 = this.getToggleAnimation();
        i = i * 59 + (easingAnimation4 == null ? 43 : easingAnimation4.hashCode());
        EasingAnimation easingAnimation5 = this.getHoverModule();
        i = i * 59 + (easingAnimation5 == null ? 43 : easingAnimation5.hashCode());
        EasingAnimation easingAnimation6 = this.getExpandedAnimation();
        i = i * 59 + (easingAnimation6 == null ? 43 : easingAnimation6.hashCode());
        EasingAnimation easingAnimation7 = this.getAnimtoP7();
        i = i * 59 + (easingAnimation7 == null ? 43 : easingAnimation7.hashCode());
        EasingAnimation easingAnimation8 = this.getAnimtoP8();
        i = i * 59 + (easingAnimation8 == null ? 43 : easingAnimation8.hashCode());
        TimedAnimation timedAnimation4 = this.getAnimation();
        i = i * 59 + (timedAnimation4 == null ? 43 : timedAnimation4.hashCode());
        TimedAnimation timedAnimation5 = this.getAnimation1();
        i = i * 59 + (timedAnimation5 == null ? 43 : timedAnimation5.hashCode());
        TimedAnimation timedAnimation6 = this.getAnimation2();
        i = i * 59 + (timedAnimation6 == null ? 43 : timedAnimation6.hashCode());
        TimedAnimation timedAnimation7 = this.getAnimation3();
        i = i * 59 + (timedAnimation7 == null ? 43 : timedAnimation7.hashCode());
        TimedAnimation timedAnimation8 = this.getAnimation12();
        i = i * 59 + (timedAnimation8 == null ? 43 : timedAnimation8.hashCode());
        TimedAnimation timedAnimation9 = this.getAnimation14();
        i = i * 59 + (timedAnimation9 == null ? 43 : timedAnimation9.hashCode());
        TimedAnimation timedAnimation10 = this.getAnimation15();
        i = i * 59 + (timedAnimation10 == null ? 43 : timedAnimation10.hashCode());
        TimedAnimation timedAnimation11 = this.getAnimation16();
        return i * 59 + (timedAnimation11 == null ? 43 : timedAnimation11.hashCode());
    }

    public EasingAnimation getAnimtoP8() {
        return this.animtoP8;
    }

    public boolean isAllowDisable() {
        return this.allowDisable;
    }

    public TimedAnimation getAnimation3() {
        return this.animation3;
    }

    protected void onEnable() {}

    public String getName() {
        return this.name;
    }

    public void setKey(int keyValue) {
        this.key = keyValue;
        if (this.keybind != null) {
            this.keybind.setValue(keyValue);
        }
    }

    public int getKey() {
        return this.keybind != null ? this.keybind.getKeyCode() : this.key;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    private void unsubscribe() {
        Gooba.getEventBus().unsubscribe(this);
    }

    public EasingAnimation getExpandedAnimation() {
        return this.expandedAnimation;
    }

    public void setEnabled(boolean enabledValue, boolean flag1) {
        if (this.enabled != enabledValue && (this.allowDisable || enabledValue)) {
            this.enabled = enabledValue;
            if (enabledValue) {
                this.enable();
                if (client.player != null && flag1) {
                    SoundPlayer.playDefaultPitch("enable_module", 5.75F);
                }
            } else {
                this.disable();
                if (client.player != null && flag1) {
                    SoundPlayer.playDefaultPitch("disable_module", 5.75F);
                }
            }
        }
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public EasingAnimation getAnimation_new_1() {
        return this.animation_new_1;
    }

    public ModuleInfo getModuleInfo() {
        return this.moduleInfo;
    }

    private void subscribe() {
        Gooba.getEventBus().subscribe(this);
    }

    public TimedAnimation getAnimation1() {
        return this.animation1;
    }

    public TimedAnimation getAnimation2() {
        return this.animation2;
    }

    public KeybindSetting getKeybind() {
        return this.keybind;
    }

    public void setExpanded(boolean expandedValue) {
        this.expanded = expandedValue;
    }

    public EasingAnimation getAnimation_new() {
        return this.animation_new;
    }

    public List<Setting<?>> getSettings() {
        this.settings.remove(this.keybind);
        this.settings.add(this.keybind);
        return this.settings;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        } else if (!(object instanceof Module module)) {
            return false;
        } else if (!module.canEqual(this)) {
            return false;
        } else if (this.isEnabled() != module.isEnabled()) {
            return false;
        } else if (this.isAutoEnabled() != module.isAutoEnabled()) {
            return false;
        } else if (this.isAllowDisable() != module.isAllowDisable()) {
            return false;
        } else if (this.isHidden() != module.isHidden()) {
            return false;
        } else if (this.getKey() != module.getKey()) {
            return false;
        } else if (this.isExpanded() != module.isExpanded()) {
            return false;
        } else {
            List list = this.getSettings();
            List settingsValue = module.getSettings();
            if (list == null ? settingsValue == null : list.equals(settingsValue)) {
                ModuleInfo moduleInfo2 = this.getModuleInfo();
                ModuleInfo moduleInfo3 = module.getModuleInfo();
                if (moduleInfo2 == null ? moduleInfo3 == null : moduleInfo2.equals(moduleInfo3)) {
                    String nameValue = this.getName();
                    String name2 = module.getName();
                    if (nameValue == null ? name2 == null : nameValue.equals(name2)) {
                        String bigNameValue = this.getBigName();
                        String bigName2 = module.getBigName();
                        if (bigNameValue == null
                                ? bigName2 == null
                                : bigNameValue.equals(bigName2)) {
                            String descriptionValue = this.getDescription();
                            String description2 = module.getDescription();
                            if (descriptionValue == null
                                    ? description2 == null
                                    : descriptionValue.equals(description2)) {
                                ModuleCategory moduleCategory2 = this.getCategory();
                                ModuleCategory moduleCategory3 = module.getCategory();
                                if (moduleCategory2 == null
                                        ? moduleCategory3 == null
                                        : moduleCategory2.equals(moduleCategory3)) {
                                    KeybindSetting keybindSetting2 = this.getKeybind();
                                    KeybindSetting keybindSetting3 = module.getKeybind();
                                    if (keybindSetting2 == null
                                            ? keybindSetting3 == null
                                            : keybindSetting2.equals(keybindSetting3)) {
                                        EasingAnimation easingAnimation2 = this.getAnimation_new();
                                        EasingAnimation easingAnimation3 =
                                                module.getAnimation_new();
                                        if (easingAnimation2 == null
                                                ? easingAnimation3 == null
                                                : easingAnimation2.equals(easingAnimation3)) {
                                            EasingAnimation easingAnimation4 =
                                                    this.getAnimation_new_1();
                                            EasingAnimation easingAnimation5 =
                                                    module.getAnimation_new_1();
                                            if (easingAnimation4 == null
                                                    ? easingAnimation5 == null
                                                    : easingAnimation4.equals(easingAnimation5)) {
                                                EasingAnimation easingAnimation6 =
                                                        this.getToggleAnimation();
                                                EasingAnimation easingAnimation7 =
                                                        module.getToggleAnimation();
                                                if (easingAnimation6 == null
                                                        ? easingAnimation7 == null
                                                        : easingAnimation6.equals(
                                                                easingAnimation7)) {
                                                    EasingAnimation easingAnimation8 =
                                                            this.getHoverModule();
                                                    EasingAnimation easingAnimation9 =
                                                            module.getHoverModule();
                                                    if (easingAnimation8 == null
                                                            ? easingAnimation9 == null
                                                            : easingAnimation8.equals(
                                                                    easingAnimation9)) {
                                                        EasingAnimation easingAnimation10 =
                                                                this.getExpandedAnimation();
                                                        EasingAnimation easingAnimation11 =
                                                                module.getExpandedAnimation();
                                                        if (easingAnimation10 == null
                                                                ? easingAnimation11 == null
                                                                : easingAnimation10.equals(
                                                                        easingAnimation11)) {
                                                            EasingAnimation easingAnimation20 =
                                                                    this.getAnimtoP7();
                                                            EasingAnimation easingAnimation21 =
                                                                    module.getAnimtoP7();
                                                            if (easingAnimation20 == null
                                                                    ? easingAnimation21 == null
                                                                    : easingAnimation20.equals(
                                                                            easingAnimation21)) {
                                                                EasingAnimation easingAnimation22 =
                                                                        this.getAnimtoP8();
                                                                EasingAnimation easingAnimation23 =
                                                                        module.getAnimtoP8();
                                                                if (easingAnimation22 == null
                                                                        ? easingAnimation23 == null
                                                                        : easingAnimation22.equals(
                                                                                easingAnimation23)) {
                                                                    TimedAnimation timedAnimation4 =
                                                                            this.getAnimation();
                                                                    TimedAnimation timedAnimation5 =
                                                                            module.getAnimation();
                                                                    if (timedAnimation4 == null
                                                                            ? timedAnimation5
                                                                                    == null
                                                                            : timedAnimation4
                                                                                    .equals(
                                                                                            timedAnimation5)) {
                                                                        TimedAnimation
                                                                                timedAnimation6 =
                                                                                        this
                                                                                                .getAnimation1();
                                                                        TimedAnimation
                                                                                timedAnimation7 =
                                                                                        module
                                                                                                .getAnimation1();
                                                                        if (timedAnimation6 == null
                                                                                ? timedAnimation7
                                                                                        == null
                                                                                : timedAnimation6
                                                                                        .equals(
                                                                                                timedAnimation7)) {
                                                                            TimedAnimation
                                                                                    timedAnimation8 =
                                                                                            this
                                                                                                    .getAnimation2();
                                                                            TimedAnimation
                                                                                    timedAnimation9 =
                                                                                            module
                                                                                                    .getAnimation2();
                                                                            if (timedAnimation8
                                                                                            == null
                                                                                    ? timedAnimation9
                                                                                            == null
                                                                                    : timedAnimation8
                                                                                            .equals(
                                                                                                    timedAnimation9)) {
                                                                                TimedAnimation
                                                                                        timedAnimation10 =
                                                                                                this
                                                                                                        .getAnimation3();
                                                                                TimedAnimation
                                                                                        timedAnimation11 =
                                                                                                module
                                                                                                        .getAnimation3();
                                                                                if (timedAnimation10
                                                                                                == null
                                                                                        ? timedAnimation11
                                                                                                == null
                                                                                        : timedAnimation10
                                                                                                .equals(
                                                                                                        timedAnimation11)) {
                                                                                    TimedAnimation
                                                                                            timedAnimation12 =
                                                                                                    this
                                                                                                            .getAnimation12();
                                                                                    TimedAnimation
                                                                                            timedAnimation13 =
                                                                                                    module
                                                                                                            .getAnimation12();
                                                                                    if (timedAnimation12
                                                                                                    == null
                                                                                            ? timedAnimation13
                                                                                                    == null
                                                                                            : timedAnimation12
                                                                                                    .equals(
                                                                                                            timedAnimation13)) {
                                                                                        TimedAnimation
                                                                                                timedAnimation14 =
                                                                                                        this
                                                                                                                .getAnimation14();
                                                                                        TimedAnimation
                                                                                                timedAnimation15 =
                                                                                                        module
                                                                                                                .getAnimation14();
                                                                                        if (timedAnimation14
                                                                                                        == null
                                                                                                ? timedAnimation15
                                                                                                        == null
                                                                                                : timedAnimation14
                                                                                                        .equals(
                                                                                                                timedAnimation15)) {
                                                                                            TimedAnimation
                                                                                                    timedAnimation16 =
                                                                                                            this
                                                                                                                    .getAnimation15();
                                                                                            TimedAnimation
                                                                                                    timedAnimation17 =
                                                                                                            module
                                                                                                                    .getAnimation15();
                                                                                            if (timedAnimation16
                                                                                                            == null
                                                                                                    ? timedAnimation17
                                                                                                            == null
                                                                                                    : timedAnimation16
                                                                                                            .equals(
                                                                                                                    timedAnimation17)) {
                                                                                                TimedAnimation
                                                                                                        timedAnimation18 =
                                                                                                                this
                                                                                                                        .getAnimation16();
                                                                                                TimedAnimation
                                                                                                        timedAnimation19 =
                                                                                                                module
                                                                                                                        .getAnimation16();
                                                                                                return timedAnimation18
                                                                                                                == null
                                                                                                        ? timedAnimation19
                                                                                                                == null
                                                                                                        : timedAnimation18
                                                                                                                .equals(
                                                                                                                        timedAnimation19);
                                                                                            } else {
                                                                                                return false;
                                                                                            }
                                                                                        } else {
                                                                                            return false;
                                                                                        }
                                                                                    } else {
                                                                                        return false;
                                                                                    }
                                                                                } else {
                                                                                    return false;
                                                                                }
                                                                            } else {
                                                                                return false;
                                                                            }
                                                                        } else {
                                                                            return false;
                                                                        }
                                                                    } else {
                                                                        return false;
                                                                    }
                                                                } else {
                                                                    return false;
                                                                }
                                                            } else {
                                                                return false;
                                                            }
                                                        } else {
                                                            return false;
                                                        }
                                                    } else {
                                                        return false;
                                                    }
                                                } else {
                                                    return false;
                                                }
                                            } else {
                                                return false;
                                            }
                                        } else {
                                            return false;
                                        }
                                    } else {
                                        return false;
                                    }
                                } else {
                                    return false;
                                }
                            } else {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }
}
