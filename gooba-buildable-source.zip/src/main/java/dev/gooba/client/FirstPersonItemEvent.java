package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;

@Environment(EnvType.CLIENT)
public class FirstPersonItemEvent extends CancellableEvent {
    private Arm arm;
    private float equipProgress;
    private Hand hand;
    private MatrixStack matrices;
    private float swingProgress;

    public void setHand(Hand hand) {
        this.hand = hand;
    }

    public MatrixStack getMatrices() {
        return this.matrices;
    }

    public void setArm(Arm arm) {
        this.arm = arm;
    }

    public void setMatrices(MatrixStack matrixstack) {
        this.matrices = matrixstack;
    }

    public Arm getArm() {
        return this.arm;
    }

    public float getEquipProgress() {
        return this.equipProgress;
    }

    public FirstPersonItemEvent(
            MatrixStack matrixstack,
            Hand hand,
            float swingProgressValue,
            float equipProgressValue,
            Arm arm) {
        this.matrices = matrixstack;
        this.hand = hand;
        this.swingProgress = swingProgressValue;
        this.equipProgress = equipProgressValue;
        this.arm = arm;
    }

    public Hand getHand() {
        return this.hand;
    }

    public void setSwingProgress(float swingProgressValue) {
        this.swingProgress = swingProgressValue;
    }

    public void setEquipProgress(float equipProgressValue) {
        this.equipProgress = equipProgressValue;
    }

    public float getSwingProgress() {
        return this.swingProgress;
    }
}
