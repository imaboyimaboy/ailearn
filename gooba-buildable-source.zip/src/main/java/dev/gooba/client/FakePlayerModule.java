package dev.gooba.client;

import com.mojang.authlib.GameProfile;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.CaveSpiderEntity;
import net.minecraft.entity.mob.DrownedEntity;
import net.minecraft.entity.mob.EndermiteEntity;
import net.minecraft.entity.mob.HuskEntity;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.entity.mob.SilverfishEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.mob.StrayEntity;
import net.minecraft.entity.mob.WitherSkeletonEntity;
import net.minecraft.entity.mob.ZoglinEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.mob.ZombieHorseEntity;
import net.minecraft.entity.mob.ZombieVillagerEntity;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket.Handler;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

import java.util.UUID;

@ModuleInfo(
        name = "Fake Player",
        desc = "Spawns a local fake player for combat and visual-effect testing",
        category = ModuleCategory.OTHER)
@Environment(EnvType.CLIENT)
public class FakePlayerModule extends Module {
    public static OtherClientPlayerEntity fakePlayer;

    private long lastAttackSoundMillis;
    private int regenerationTicks = 0;

    private void applyDamage(OtherClientPlayerEntity otherclientplayerentity, float f) {
        float absorptionAmount = otherclientplayerentity.getAbsorptionAmount();
        if (absorptionAmount > 0.0F) {
            float f2 = Math.min(absorptionAmount, f);
            otherclientplayerentity.setAbsorptionAmount(absorptionAmount - f2);
            f -= f2;
        }

        if (f > 0.0F) {
            float health = otherclientplayerentity.getHealth();
            float f3 = Math.max(otherclientplayerentity.getHealth() - f, 0.5F);
            otherclientplayerentity.setHealth(f3);
        }

        otherclientplayerentity.hurtTime = 10;
        otherclientplayerentity.timeUntilRegen = 10;
        if (!otherclientplayerentity.hasStatusEffect(StatusEffects.REGENERATION)
                || otherclientplayerentity.getStatusEffect(StatusEffects.REGENERATION).getDuration()
                        < 100) {
            otherclientplayerentity.addStatusEffect(
                    new StatusEffectInstance(StatusEffects.REGENERATION, 900, 1));
        }

        if (!otherclientplayerentity.hasStatusEffect(StatusEffects.ABSORPTION)
                || otherclientplayerentity.getStatusEffect(StatusEffects.ABSORPTION).getDuration()
                        < 20) {
            otherclientplayerentity.addStatusEffect(
                    new StatusEffectInstance(StatusEffects.ABSORPTION, 100, 1));
        }

        if (otherclientplayerentity.getHealth() <= 1.0F
                && otherclientplayerentity.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            this.popTotem(otherclientplayerentity);
        }
    }

    private void applyExplosionDamage(ExplosionS2CPacket explosions2cpacket) {
        Vec3d vec3d = explosions2cpacket.center();
        double d0 = fakePlayer.getEntityPos().distanceTo(vec3d);
        if (!(d0 > 11.0)) {
            float f = (float) ((1.0 - d0 / 11.0) * 12.0);
            this.applyDamage(fakePlayer, f);
            client.player.playSound(SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.7F, 1.0F);
        }
    }

    public void setSpawned(boolean flag) {
        if (client.player != null && client.world != null) {
            if (!flag) {
                if (fakePlayer != null) {
                    fakePlayer.discard();
                    fakePlayer = null;
                }
            } else {
                GameProfile gameprofile =
                        new GameProfile(
                                UUID.fromString("32d0a964-137a-2c03-7cc9-df6700000000"),
                                "GOOBAA_NPC");
                fakePlayer = new OtherClientPlayerEntity(client.world, gameprofile);
                fakePlayer.refreshPositionAndAngles(
                        client.player.getX(),
                        client.player.getY(),
                        client.player.getZ(),
                        client.player.getYaw(),
                        client.player.getPitch());
                fakePlayer.setStackInHand(Hand.MAIN_HAND, new ItemStack(Items.NETHERITE_SWORD));
                fakePlayer.setStackInHand(Hand.OFF_HAND, new ItemStack(Items.TOTEM_OF_UNDYING));
                fakePlayer.setHealth(20.0F);
                fakePlayer.setAbsorptionAmount(0.0F);
                client.world.addEntity(fakePlayer);
            }
        }
    }

    @EventHandler
    public void onPacket(PacketEvent packetEvent) {
        if (client.player != null && client.world != null && fakePlayer != null) {
            if (packetEvent.isSend()) {
                if (packetEvent.getPacket()
                                instanceof
                                PlayerInteractEntityC2SPacket playerinteractentityc2spacket
                        && client.crosshairTarget instanceof EntityHitResult entityhitresult) {
                    Entity entity = entityhitresult.getEntity();
                    if (entity != null && entity.getId() == fakePlayer.getId()) {
                        playerinteractentityc2spacket.handle(
                                new Handler() {

                                    @Override
                                    public void attack() {
                                        FakePlayerModule.this.handleAttack();
                                    }

                                    @Override
                                    public void interact(Hand hand) {}

                                    static {
                                    }

                                    @Override
                                    public void interactAt(Hand hand, Vec3d vec3d) {}
                                });
                    }
                }

                if (packetEvent.getPacket() instanceof ExplosionS2CPacket explosions2cpacket) {
                    this.applyExplosionDamage(explosions2cpacket);
                }
            }
        }
    }

    @Override
    public void onDisable() {
        this.setSpawned(false);
        super.onDisable();
    }

    public FakePlayerModule() {
        this.lastAttackSoundMillis = 0L;
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null && fakePlayer != null) {
            fakePlayer.setYaw(0.0F);
            fakePlayer.setPitch(0.0F);
            fakePlayer.setHeadYaw(0.0F);
            fakePlayer.setBodyYaw(0.0F);
            fakePlayer.setMainArm(client.player.getMainArm());
            if (this.regenerationTicks > 0) {
                this.regenerationTicks--;
                if (this.regenerationTicks % 20 == 0) {
                    fakePlayer.setHealth(Math.min(fakePlayer.getHealth() + 1.0F, 20.0F));
                }
            }
        }
    }

    @Override
    public void onEnable() {
        this.setSpawned(true);
        super.onEnable();
    }

    private boolean isArthropod(Entity entity) {
        return entity instanceof SpiderEntity
                || entity instanceof CaveSpiderEntity
                || entity instanceof SilverfishEntity
                || entity instanceof EndermiteEntity
                || entity instanceof BeeEntity;
    }

    private float calculateAttackDamage(PlayerEntity playerentity, LivingEntity livingentity) {
        ItemStack itemstack = playerentity.getMainHandStack();
        double attributeValue = playerentity.getAttributeValue(EntityAttributes.ATTACK_DAMAGE);
        float attackCooldownProgress = playerentity.getAttackCooldownProgress(0.5F);
        float f1 =
                (float)
                        (attributeValue
                                * (double)
                                        (0.2F
                                                + attackCooldownProgress
                                                        * attackCooldownProgress
                                                        * 0.8F));
        boolean flag;
        flag =
                (playerentity.getVelocity().y < -0.08
                        && !playerentity.isOnGround()
                        && !playerentity.isSprinting());

        if (flag) {
            f1 *= 1.5F;
        }

        DynamicRegistryManager dynamicregistrymanager =
                playerentity.getEntityWorld().getRegistryManager();
        Registry<Enchantment> registry =
                dynamicregistrymanager.getOrThrow(RegistryKeys.ENCHANTMENT);
        int i =
                (int)
                        registry.getEntry(Enchantments.SHARPNESS.getValue())
                                .map(reference -> EnchantmentHelper.getLevel(reference, itemstack))
                                .orElse(0);
        if (i > 0) {
            float f2 = 0.5F + 0.5F * (float) i;
            f1 += f2;
        }

        int j =
                (int)
                        registry.getEntry(Enchantments.SMITE.getValue())
                                .map(reference -> EnchantmentHelper.getLevel(reference, itemstack))
                                .orElse(0);
        if (j > 0 && this.isUndead(livingentity)) {
            float f3 = 2.5F * (float) j;
            f1 += f3;
        }

        int k =
                (int)
                        registry.getEntry(Enchantments.BANE_OF_ARTHROPODS.getValue())
                                .map(reference -> EnchantmentHelper.getLevel(reference, itemstack))
                                .orElse(0);
        if (k > 0 && this.isArthropod(livingentity)) {
            float f4 = 2.5F * (float) k;
            f1 += f4;
        }

        return f1;
    }

    private boolean isUndead(Entity entity) {
        return entity instanceof ZombieEntity
                || entity instanceof SkeletonEntity
                || entity instanceof WitherSkeletonEntity
                || entity instanceof WitherEntity
                || entity instanceof ZoglinEntity
                || entity instanceof ZombieHorseEntity
                || entity instanceof ZombieVillagerEntity
                || entity instanceof HuskEntity
                || entity instanceof StrayEntity
                || entity instanceof DrownedEntity
                || entity instanceof PhantomEntity;
    }

    private void handleAttack() {
        if (!(client.player.squaredDistanceTo(fakePlayer) > 36.0)) {
            float f = this.calculateAttackDamage(client.player, fakePlayer);
            long nowMillis = System.currentTimeMillis();
            if (nowMillis - this.lastAttackSoundMillis >= 100L) {
                boolean flag;
                flag =
                        (client.player.getVelocity().y < -0.08
                                && !client.player.isOnGround()
                                && !client.player.isSprinting());

                client.player.playSound(
                        flag
                                ? SoundEvents.ENTITY_PLAYER_ATTACK_CRIT
                                : SoundEvents.ENTITY_PLAYER_ATTACK_STRONG,
                        1.0F,
                        1.0F);
                this.lastAttackSoundMillis = nowMillis;
            }

            this.applyDamage(fakePlayer, f);
        }
    }

    private void popTotem(OtherClientPlayerEntity otherclientplayerentity) {
        client.player.playSound(SoundEvents.ITEM_TOTEM_USE, 1.0F, 1.0F);
        TotemGhostModule totemGhostModule =
                Gooba.getInstance().getModuleRegistry().findModule(TotemGhostModule.class);
        if (totemGhostModule != null) {
            totemGhostModule.spawnGhost(otherclientplayerentity);
        }

        ParticlesModule particlesModule =
                Gooba.getInstance().getModuleRegistry().findModule(ParticlesModule.class);
        if (particlesModule.onTotemPopSetting.isOn()) {
            for (int i = 0; (float) i < particlesModule.totemParticleCountSetting.getFloat(); i++) {
                double d0 = MathUtils.randomDouble(0.0, Math.PI * 2);
                double d1 = MathUtils.randomDouble(2.5, 4.0);
                double d2 = Math.cos(d0) * d1;
                double d3 = Math.sin(d0) * d1;
                double d4 =
                        MathUtils.randomDouble(
                                0.0, (double) (otherclientplayerentity.getHeight() / 2.0F));
                particlesModule.spawnTotemParticle(
                        particlesModule.totemParticles,
                        new Vec3d(
                                otherclientplayerentity.getX() + MathUtils.randomDouble(-0.2, 0.2),
                                otherclientplayerentity.getY()
                                        + (double)
                                                MathUtils.randomFloat(
                                                        0.1F, otherclientplayerentity.getHeight()),
                                otherclientplayerentity.getZ() + MathUtils.randomDouble(-0.2, 0.2)),
                        new Vec3d(d2, d4, d3));
            }
        } else {
            client.particleManager.addEmitter(
                    otherclientplayerentity, ParticleTypes.TOTEM_OF_UNDYING, 30);
        }

        otherclientplayerentity.clearStatusEffects();
        otherclientplayerentity.setHealth(4.0F);
        otherclientplayerentity.setAbsorptionAmount(12.0F);
        this.regenerationTicks = 1400;
    }
}
