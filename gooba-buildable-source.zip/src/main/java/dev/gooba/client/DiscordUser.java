package dev.gooba.client;

import com.sun.jna.Structure;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Arrays;
import java.util.List;

@Environment(EnvType.CLIENT)
public class DiscordUser extends Structure {
    @Deprecated public String discriminator;
    public String username;
    public String avatar;
    public String userId;

    protected List<String> getFieldOrder() {
        return Arrays.asList("userId", "username", "discriminator", "avatar");
    }
}
