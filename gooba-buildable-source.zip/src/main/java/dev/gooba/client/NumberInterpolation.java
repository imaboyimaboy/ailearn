package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class NumberInterpolation {
    public static Number getNumber(Number number, Number value, double d0) {
        double d1 = number.doubleValue();
        double d2 = value.doubleValue();
        double numberValue = d1 + d0 * (d2 - d1);
        if (number instanceof Integer) {
            return (int) Math.round(numberValue);
        } else if (number instanceof Double) {
            return numberValue;
        } else if (number instanceof Float) {
            return (float) numberValue;
        } else if (number instanceof Long) {
            return Math.round(numberValue);
        } else if (number instanceof Short) {
            return (short) ((int) Math.round(numberValue));
        } else if (number instanceof Byte) {
            return (byte) ((int) Math.round(numberValue));
        } else {
            String simpleName = number.getClass().getSimpleName();
            throw new IllegalArgumentException("Unsupported type: " + simpleName);
        }
    }
}
