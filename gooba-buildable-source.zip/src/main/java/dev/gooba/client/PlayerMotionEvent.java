package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class PlayerMotionEvent extends CancellableEvent {
    private double pitch;
    private double x;
    private double z;
    private boolean ground;
    private double yaw;
    private double y;

    public boolean isGround() {
        return this.ground;
    }

    public double getX() {
        return this.x;
    }

    public PlayerMotionEvent x(double d0) {
        this.x = d0;
        return this;
    }

    public PlayerMotionEvent pitch(double pitchValue) {
        this.pitch = pitchValue;
        return this;
    }

    public PlayerMotionEvent z(double d0) {
        this.z = d0;
        return this;
    }

    public PlayerMotionEvent y(double d0) {
        this.y = d0;
        return this;
    }

    public PlayerMotionEvent yaw(double yawValue) {
        this.yaw = yawValue;
        return this;
    }

    public PlayerMotionEvent(
            double d0,
            double d1,
            double d2,
            double yawValue,
            double pitchValue,
            boolean groundValue) {
        this.x = d0;
        this.y = d1;
        this.z = d2;
        this.yaw = yawValue;
        this.pitch = pitchValue;
        this.ground = groundValue;
    }

    public PlayerMotionEvent ground(boolean groundValue) {
        this.ground = groundValue;
        return this;
    }

    public double getY() {
        return this.y;
    }

    public double getPitch() {
        return this.pitch;
    }

    public double getYaw() {
        return this.yaw;
    }

    public double getZ() {
        return this.z;
    }
}
