package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public interface ConditionalSetting {
    Setting visibleWhen(Supplier supplier);
}
