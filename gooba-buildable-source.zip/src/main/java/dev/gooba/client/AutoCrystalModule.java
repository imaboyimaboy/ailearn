package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

import org.lwjgl.glfw.GLFW;

@ModuleInfo(
        name = "Auto Crystal",
        desc = "Places and breaks crystals while the activation key is held",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class AutoCrystalModule extends Module {
    private final ModeSetting modeSetting =
            new ModeSetting(this, "Mode", new String[] {"Bind", "Auto"});

    private long lastPlaceMillis;
    private final SliderSetting placeDelaySetting;
    private long lastBreakMillis;
    private final KeybindSetting activationKeySetting =
            new KeybindSetting(this, "Activation Key", 1)
                    .visibleWhen(() -> this.modeSetting.isSelected("Bind"));
    private final SliderSetting breakDelaySetting;
    private final BooleanSetting removeBounceSetting;

    @Override
    protected void onDisable() {
        this.reset();
        super.onDisable();
    }

    private Hand crystalHand() {
        if (client.player.getOffHandStack().isOf(Items.END_CRYSTAL)) {
            return Hand.OFF_HAND;
        } else {
            return client.player.getMainHandStack().isOf(Items.END_CRYSTAL) ? Hand.MAIN_HAND : null;
        }
    }

    private void breakCrystal(
            EntityHitResult entityhitresult,
            EndCrystalEntity endcrystalentity,
            long lastBreakMillisValue) {
        if (endcrystalentity.isAlive() && !endcrystalentity.isRemoved()) {
            if (lastBreakMillisValue - this.lastBreakMillis
                    >= (long) Math.round(this.breakDelaySetting.getFloat())) {
                if (this.canHitCrystal(entityhitresult, endcrystalentity)) {
                    MouseSimulator.click(0);
                    client.interactionManager.attackEntity(client.player, endcrystalentity);
                    client.player.swingHand(Hand.MAIN_HAND);
                    this.lastBreakMillis = lastBreakMillisValue;
                }
            }
        }
    }

    private void reset() {
        this.lastPlaceMillis = 0L;
        this.lastBreakMillis = 0L;
    }

    @EventHandler
    public void onPreClientTick(PreClientTickEvent preClientTickEvent) {
        if (client.player != null && client.world != null && client.interactionManager != null) {
            boolean flag =
                    client.currentScreen == null
                            && (this.modeSetting.isSelected("Auto") || this.isActivationHeld());
            if (flag) {
                long nowMillis = System.currentTimeMillis();
                if (client.crosshairTarget instanceof EntityHitResult entityhitresult
                        && entityhitresult.getType() == Type.ENTITY
                        && entityhitresult.getEntity()
                                instanceof EndCrystalEntity endcrystalentity) {
                    MouseSimulator.suppressUse(75L);
                    client.options.useKey.setPressed(false);
                    this.breakCrystal(entityhitresult, endcrystalentity, nowMillis);
                    return;
                }

                if (client.crosshairTarget instanceof BlockHitResult blockhitresult
                        && blockhitresult.getType() == Type.BLOCK
                        && this.canPlaceCrystal(blockhitresult.getBlockPos())) {
                    Hand hand = this.crystalHand();
                    if (hand == null) {
                        return;
                    }

                    MouseSimulator.suppressUse(75L);
                    client.options.useKey.setPressed(false);
                    if (nowMillis - this.lastPlaceMillis
                            < (long) Math.round(this.placeDelaySetting.getFloat())) {
                        return;
                    }

                    MouseSimulator.click(1);
                    ActionResult actionresult =
                            client.interactionManager.interactBlock(
                                    client.player, hand, blockhitresult);
                    if (actionresult.isAccepted()) {
                        client.player.swingHand(hand);
                    }

                    this.lastPlaceMillis = nowMillis;
                    return;
                }
            }
        } else {
            this.reset();
        }
    }

    private boolean isActivationHeld() {
        int cachedKeyCode = this.activationKeySetting.getCachedKeyCode();
        if (cachedKeyCode < 0) {
            return false;
        } else {
            long handle = client.getWindow().getHandle();
            return cachedKeyCode <= 7
                    ? GLFW.glfwGetMouseButton(handle, cachedKeyCode) == 1
                    : InputUtil.isKeyPressed(client.getWindow(), cachedKeyCode);
        }
    }

    public AutoCrystalModule() {
        this.placeDelaySetting = new SliderSetting(this, "Place Delay", 0.0F, 0.0F, 500.0F, 5.0F);
        this.breakDelaySetting = new SliderSetting(this, "Break Delay", 0.0F, 0.0F, 500.0F, 5.0F);
        this.removeBounceSetting = new BooleanSetting(this, "Remove Bounce", true);
    }

    private boolean canHitCrystal(
            EntityHitResult entityhitresult, EndCrystalEntity endcrystalentity) {
        Box box = endcrystalentity.getBoundingBox().expand(0.05);
        if (!box.contains(entityhitresult.getPos())) {
            return false;
        } else {
            Vec3d vec3d = client.player.getEyePos();
            Vec3d vec3d1 =
                    EntityRaycast.rotationVector(client.player.getPitch(), client.player.getYaw());
            Vec3d vec3d2 = vec3d.add(vec3d1.multiply(6.0));
            Vec3d vec3d3 = box.raycast(vec3d, vec3d2).orElse(null);
            if (vec3d3 != null && !(vec3d.squaredDistanceTo(vec3d3) > 36.0)) {
                BlockHitResult blockhitresult =
                        client.world.raycast(
                                new RaycastContext(
                                        vec3d,
                                        vec3d3,
                                        ShapeType.COLLIDER,
                                        FluidHandling.NONE,
                                        client.player));
                return blockhitresult.getType() == Type.MISS
                        || vec3d.squaredDistanceTo(blockhitresult.getPos()) + 0.01
                                >= vec3d.squaredDistanceTo(vec3d3);
            } else {
                return false;
            }
        }
    }

    public boolean shouldRemoveBounce() {
        return this.isEnabled() && this.removeBounceSetting.isOn();
    }

    private boolean canPlaceCrystal(BlockPos blockpos) {
        BlockState blockstate = client.world.getBlockState(blockpos);
        if (!blockstate.isOf(Blocks.OBSIDIAN) && !blockstate.isOf(Blocks.BEDROCK)) {
            return false;
        } else {
            BlockPos blockPos = blockpos.up();
            if (!client.world.getBlockState(blockPos).isAir()) {
                return false;
            } else {
                Box box =
                        new Box(
                                (double) blockPos.getX(),
                                (double) blockPos.getY(),
                                (double) blockPos.getZ(),
                                (double) blockPos.getX() + 1.0,
                                (double) blockPos.getY() + 2.0,
                                (double) blockPos.getZ() + 1.0);
                return client.world.getOtherEntities(null, box).isEmpty();
            }
        }
    }
}
