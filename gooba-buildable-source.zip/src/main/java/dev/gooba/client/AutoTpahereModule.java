package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;

@ModuleInfo(
        name = "Auto Tpahere",
        category = ModuleCategory.DONUT,
        desc = "Automatically sends /tpahere or /tpa to a specified player")
@Environment(EnvType.CLIENT)
public class AutoTpahereModule extends Module {
    public final TextSetting playerNameSetting = new TextSetting(this, "Player Name", "");
    private int ticksSinceRequest;
    public final ModeSetting modeSetting =
            new ModeSetting(this, "Mode", new String[] {"Tpahere", "Tpa"});
    public final SliderSetting intervalSSetting =
            new SliderSetting(this, "Interval (s)", 15.5F, 1.0F, 60.0F, 0.5F);

    @Override
    protected void onDisable() {
        this.ticksSinceRequest = 0;
        this.sendStatusMessage("§cDisabled.");
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null) {
            this.ticksSinceRequest++;
            int i = (int) (this.intervalSSetting.getFloat() * 20.0F);
            if (this.ticksSinceRequest >= i) {
                this.ticksSinceRequest = 0;
                this.sendTeleportRequest();
            }
        }
    }

    private void sendStatusMessage(String text) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal("§7[§6Auto Tpahere§7] §f" + text), false);
        }
    }

    private void sendTeleportRequest() {
        if (client.player != null && client.player.networkHandler != null) {
            String text = this.playerNameSetting.getText().trim();
            if (!text.isEmpty()) {
                String textValue;
                if (this.modeSetting.isSelected("Tpahere")) {
                    textValue = "tpahere";
                } else {
                    textValue = "tpa";
                }

                client.player.networkHandler.sendChatCommand(textValue + " " + text);
            }
        }
    }

    @Override
    protected void onEnable() {
        this.ticksSinceRequest = 0;
        String text = this.playerNameSetting.getText().trim();
        if (text.isEmpty()) {
            this.sendStatusMessage("§cNo player name set — disabling.");
            this.setEnabled(false);
        } else {
            if (this.modeSetting.isSelected("Tpahere")) {
                String textValue = "/tpahere";
                String text2 = String.valueOf(this.intervalSSetting.getFloat());
                this.sendStatusMessage(
                        "§aEnabled §7— sending §e"
                                + textValue
                                + " "
                                + text
                                + " §7every §e"
                                + text2
                                + "s§7.");
            } else {
                String text3 = "/tpa";
                String text4 = String.valueOf(this.intervalSSetting.getFloat());
                this.sendStatusMessage(
                        "§aEnabled §7— sending §e"
                                + text3
                                + " "
                                + text
                                + " §7every §e"
                                + text4
                                + "s§7.");
            }

            this.sendTeleportRequest();
        }
    }

    public AutoTpahereModule() {
        this.ticksSinceRequest = 0;
    }
}
