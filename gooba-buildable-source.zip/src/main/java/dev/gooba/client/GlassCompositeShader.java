package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public class GlassCompositeShader {
    private static final Identifier VERTEX_SHADER = Identifier.of("client", "core/glass_composite");
    private GpuBuffer uniformBuffer;
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
    private boolean initialized = false;

    private static final Identifier FRAGMENT_SHADER =
            Identifier.of("client", "core/glass_composite");
    private ByteBuffer uniformData;
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
    private static final Identifier PIPELINE_ID =
            Identifier.of("client", "pipeline/glass_composite");
    private static final BlendFunction REPLACE_BLEND =
            new BlendFunction(SourceFactor.ONE, DestFactor.ZERO, SourceFactor.ONE, DestFactor.ZERO);
    private GpuBuffer vertexBuffer;

    private static final Vector3f MODEL_OFFSET = new Vector3f(0.0F, 0.0F, 0.0F);
    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(PIPELINE_ID)
                            .withVertexShader(VERTEX_SHADER)
                            .withFragmentShader(FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("GlassData", UniformType.UNIFORM_BUFFER)
                            .withSampler("SceneSampler")
                            .withSampler("BlurSampler")
                            .withSampler("MaskSampler")
                            .withBlend(REPLACE_BLEND)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());

    public void render(
            GpuTextureView gputextureview,
            GpuTextureView gpuTextureView,
            GpuTextureView gpuTextureViewValue,
            GpuTextureView gpuTextureView2,
            int i,
            int j,
            float f,
            boolean flag,
            int k,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float f8,
            float f9,
            float f10) {
        this.initialize();
        this.writeUniforms(i, j, f, flag, k, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10);
        int l = this.uniformData.remaining();
        if (this.uniformBuffer == null || this.uniformBuffer.size() < (long) l) {
            if (this.uniformBuffer != null) {
                this.uniformBuffer.close();
            }

            this.uniformBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:glass_composite_uniform", 136, (long) l);
        }

        CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
        commandencoder.writeToBuffer(this.uniformBuffer.slice(), this.uniformData);
        GpuBufferSlice gpubufferslice =
                RenderSystem.getDynamicUniforms()
                        .write(
                                RenderSystem.getModelViewMatrix(),
                                COLOR_MODULATOR,
                                MODEL_OFFSET,
                                TEXTURE_MATRIX);
        GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);

        try (RenderPass renderpass =
                commandencoder.createRenderPass(
                        () -> "minecraft:glass_composite_pass",
                        gputextureview,
                        OptionalInt.empty())) {
            renderpass.setPipeline(PIPELINE);
            renderpass.setVertexBuffer(0, this.vertexBuffer);
            renderpass.bindTexture("SceneSampler", gpuTextureView, gpusampler);
            renderpass.bindTexture("BlurSampler", gpuTextureViewValue, gpusampler);
            renderpass.bindTexture("MaskSampler", gpuTextureView2, gpusampler);
            RenderSystem.bindDefaultUniforms(renderpass);
            renderpass.setUniform("DynamicTransforms", gpubufferslice);
            renderpass.setUniform("GlassData", this.uniformBuffer);
            renderpass.draw(0, 6);
        }
    }

    private void initialize() {
        if (!this.initialized) {
            this.uniformData = MemoryUtil.memAlloc(80);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.vertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "minecraft:glass_composite_dummy_vertex", 32, bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.initialized = true;
        }
    }

    public void close() {
        if (this.uniformBuffer != null) {
            this.uniformBuffer.close();
            this.uniformBuffer = null;
        }

        if (this.vertexBuffer != null) {
            this.vertexBuffer.close();
            this.vertexBuffer = null;
        }

        if (this.uniformData != null) {
            MemoryUtil.memFree(this.uniformData);
            this.uniformData = null;
        }

        this.initialized = false;
    }

    private void writeUniforms(
            int i,
            int j,
            float f,
            boolean flag,
            int k,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float f8,
            float f9,
            float f10) {
        this.uniformData.clear();
        this.uniformData.putFloat((float) i);
        this.uniformData.putFloat((float) j);
        this.uniformData.putFloat(f);
        this.uniformData.putFloat(flag ? 1.0F : 0.0F);
        float f11 = (float) (k >> 24 & 0xFF) / 255.0F;
        float f12 = (float) (k >> 16 & 0xFF) / 255.0F;
        float f13 = (float) (k >> 8 & 0xFF) / 255.0F;
        float f14 = (float) (k & 0xFF) / 255.0F;
        this.uniformData.putFloat(f12);
        this.uniformData.putFloat(f13);
        this.uniformData.putFloat(f14);
        this.uniformData.putFloat(f11);
        this.uniformData.putFloat(f1);
        this.uniformData.putFloat(f2);
        this.uniformData.putFloat(f3);
        this.uniformData.putFloat(0.0F);
        float f15 = (float) (System.currentTimeMillis() % 100000L) / 1000.0F;
        this.uniformData.putFloat(f15);
        this.uniformData.putFloat(f4);
        this.uniformData.putFloat(f5);
        this.uniformData.putFloat(f6);
        this.uniformData.putFloat(f7);
        this.uniformData.putFloat(f8);
        this.uniformData.putFloat(f9);
        this.uniformData.putFloat(f10);
        this.uniformData.flip();
    }
}
