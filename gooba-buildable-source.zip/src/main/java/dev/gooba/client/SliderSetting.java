package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class SliderSetting extends Setting<Float> {
    public float minValue;

    public float maxValue;
    public TimedAnimation timedAnimation;
    public TimedAnimation timedAnimation2 = new DecelerateAnimation(300, 1.0);
    public float step;
    private Float cachedValue;
    public TimedAnimation timedAnimation3 = new DecelerateAnimation(300, 1.0);

    public SliderSetting setValue(Float object) {
        this.cachedValue = object;
        return (SliderSetting) super.setValue(object);
    }

    public SliderSetting(
            Module moduleValue,
            String nameValue,
            float object,
            float minValueValue,
            float maxValueValue,
            float stepValue) {
        super(moduleValue, nameValue, object);
        this.timedAnimation = new DecelerateAnimation(300, 1.0);
        this.minValue = minValueValue;
        this.maxValue = maxValueValue;
        this.step = stepValue;
        this.cachedValue = object;
    }

    public SliderSetting visibleWhen(Supplier supplier) {
        return (SliderSetting) super.visibleWhen(supplier);
    }

    public SliderSetting onChange(Runnable runnable) {
        return (SliderSetting)
                super.onChange(
                        () -> {
                            runnable.run();
                            this.cachedValue = (Float) super.getValue();
                        });
    }

    public Float getFloat() {
        if (this.cachedValue == null) {
            this.cachedValue = (Float) super.getValue();
        }

        return this.cachedValue;
    }
}
