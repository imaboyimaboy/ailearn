package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class PlayerActionEvent extends CancellableEvent {
    byte type;

    public byte getType() {
        return this.type;
    }

    public PlayerActionEvent(byte typeValue) {
        this.type = typeValue;
    }

    public void setType(byte typeValue) {
        this.type = typeValue;
    }
}
