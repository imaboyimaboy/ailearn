package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.joml.Vector2f;

@ModuleInfo(
        name = "SpotifyHUD",
        desc = "Displays the current media session and provides playback controls",
        category = ModuleCategory.CLIENT)
@Environment(EnvType.CLIENT)
public class SpotifyHUDModule extends Module {
    public final KeybindSetting nextKeySetting;
    public final KeybindSetting previousKeySetting = new KeybindSetting(this, "Previous Key");
    private final MediaPlayerHud mediaPlayerHud;
    public final KeybindSetting playPauseKeySetting = new KeybindSetting(this, "Play/Pause Key");
    public final PositionSetting spotifyHUDSetting;

    @EventHandler
    public void onKeyPress(KeyPressEvent keyPressEvent) {
        int key = keyPressEvent.getKey();
        if (key > 0 && key == this.previousKeySetting.getCachedKeyCode()) {
            this.mediaPlayerHud.previousTrack();
        }

        if (key > 0 && key == this.playPauseKeySetting.getCachedKeyCode()) {
            this.mediaPlayerHud.togglePlayback();
        }

        if (key > 0 && key == this.nextKeySetting.getCachedKeyCode()) {
            this.mediaPlayerHud.nextTrack();
        }
    }

    @Override
    protected void onDisable() {
        this.mediaPlayerHud.close();
    }

    @EventHandler
    public void onRender2D(Render2DEvent render2DEvent) {
        if (client.player != null && client.world != null) {
            this.mediaPlayerHud.render(this.spotifyHUDSetting, HUDModule.getInstance());
        }
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        this.mediaPlayerHud.refreshMedia();
    }

    public SpotifyHUDModule() {
        this.nextKeySetting = new KeybindSetting(this, "Next Key");
        this.spotifyHUDSetting =
                new PositionSetting(this, "Spotify HUD", new Vector2f(10.0F, 400.0F));
        this.mediaPlayerHud = new MediaPlayerHud();
    }
}
