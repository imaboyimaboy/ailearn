package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;

import org.joml.Vector2f;

import java.util.LinkedHashMap;
import java.util.Map;

@ModuleInfo(
        name = "HUD",
        desc = "Configures the legacy HUD elements and notifications",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class LegacyHudModule extends Module {
    public EasingAnimation easingAnimation;
    public SliderSetting notificationVolumeSetting;
    public PositionSetting clickBindsDragingsSetting;
    private final Map<String, LegacyHudModule.EffectData> effects;
    public BooleanSetting arrayListSetting;
    public PositionSetting cordsDragingsSetting;
    public PositionSetting tpsDragingsSetting;
    public EasingAnimation easingAnimation12;
    public BooleanSetting activeEffectsSetting;
    public EasingAnimation easingAnimation13;
    public MultiBooleanSetting elementsSetting;
    public PositionSetting watermarkDraggingsSetting;
    public MinecraftClient minecraftClient;
    public BooleanSetting armorSetting;
    public BooleanSetting bPSAndTPSSetting;
    public BooleanSetting activeKeybindsSetting;
    public ModeSetting notificationTypeSetting;
    TimedAnimation timedAnimation;
    public PositionSetting potionsDragingsSetting;
    public BooleanSetting inventorySetting;
    public BooleanSetting coordinatesSetting;

    public BooleanSetting clientLogoSetting = new BooleanSetting("Client logo", true);
    public PositionSetting inventoryDragingsSetting;
    public EasingAnimation easingAnimation14;
    public PositionSetting arrayListDragingsSetting;
    public PositionSetting keybindsDragingsSetting;
    public PositionSetting bpsDragingsSetting;
    public PositionSetting armorDragingsSetting;

    public static float backgroundOpacity() {
        return ThemeColors.getOpacity() < 0.98F ? ThemeColors.getOpacity() : 0.98F;
    }

    public LegacyHudModule() {
        this.coordinatesSetting = new BooleanSetting("Coordinates", true);
        this.bPSAndTPSSetting = new BooleanSetting("BPS and TPS", true);
        this.activeEffectsSetting = new BooleanSetting("Active Effects", true);
        this.activeKeybindsSetting = new BooleanSetting("Active Keybinds", true);
        this.arrayListSetting = new BooleanSetting("Array List", false);
        this.armorSetting = new BooleanSetting("Armor", true);
        this.inventorySetting = new BooleanSetting("Inventory", true);
        this.elementsSetting =
                new MultiBooleanSetting(
                        this,
                        "Elements",
                        new BooleanSetting[] {
                            this.clientLogoSetting,
                            this.activeKeybindsSetting,
                            this.activeEffectsSetting,
                            this.bPSAndTPSSetting,
                            this.coordinatesSetting,
                            this.arrayListSetting,
                            this.armorSetting,
                            this.inventorySetting
                        });
        this.notificationVolumeSetting =
                new SliderSetting(this, "Notification volume", 0.5F, 0.1F, 1.0F, 0.1F);
        this.notificationTypeSetting =
                new ModeSetting(
                        this, "Notification type", new String[] {"First", "Second", "Third"});
        this.easingAnimation13 = new EasingAnimation();
        this.watermarkDraggingsSetting = new PositionSetting(this, "watermark_draggings");
        this.keybindsDragingsSetting = new PositionSetting(this, "Keybinds_dragings");
        this.potionsDragingsSetting = new PositionSetting(this, "Potions_dragings");
        this.clickBindsDragingsSetting =
                new PositionSetting(this, "ClickBinds_dragings", new Vector2f(8.0F, 100.0F));
        this.arrayListDragingsSetting =
                new PositionSetting(this, "ArrayList_dragings", new Vector2f(10000.0F, 4.0F));
        this.armorDragingsSetting =
                new PositionSetting(this, "Armor_dragings", new Vector2f(160.0F, 90.0F));
        this.inventoryDragingsSetting =
                new PositionSetting(this, "Inventory_dragings", new Vector2f(160.0F, 170.0F));
        this.cordsDragingsSetting =
                new PositionSetting(this, "Cords_dragings", new Vector2f(-999.0F, -999.0F));
        this.bpsDragingsSetting =
                new PositionSetting(this, "Bps_dragings", new Vector2f(-999.0F, -999.0F));
        this.tpsDragingsSetting =
                new PositionSetting(this, "Tps_dragings", new Vector2f(-999.0F, -999.0F));

        this.easingAnimation14 = new EasingAnimation();
        this.easingAnimation = new EasingAnimation();
        this.easingAnimation12 = new EasingAnimation();
        this.effects = new LinkedHashMap<>();
        this.timedAnimation = new DecelerateAnimation(200, 1.0);
        this.minecraftClient = MinecraftClient.getInstance();
    }

    public static int accentColor() {
        return ThemeColors.getAccentColor();
    }

    @Environment(EnvType.CLIENT)
    private static class EffectData {
        String string;
        boolean flag;
        int intVal;
        boolean flag2;
        StatusEffectInstance statusEffectInstance;
        int intVal2;
        EasingAnimation easingAnimation;
        String string2;

        public EffectData(
                String text,
                String stringValue,
                int i,
                boolean flag,
                int j,
                StatusEffectInstance statuseffectinstance) {
            this.string2 = text;
            this.string = stringValue;
            this.intVal2 = i;
            this.flag = flag;
            this.intVal = j;
            this.easingAnimation = new EasingAnimation();
            this.flag2 = true;
            this.statusEffectInstance = statuseffectinstance;
        }
    }
}
