package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Item Scroller",
        desc = "Rapidly shift-moves hovered stacks and bulk-drops matching items",
        category = ModuleCategory.OTHER)
@Environment(EnvType.CLIENT)
public class ItemScrollerModule extends Module {
    public SliderSetting transferDelaySetting =
            new SliderSetting(this, "Transfer Delay", 50.0F, 0.0F, 100.0F, 1.0F);

    public static ItemScrollerModule getInstance() {
        return (ItemScrollerModule) ModuleLookup.getModule(ItemScrollerModule.class);
    }
}
