package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.PlayerInput;

@Environment(EnvType.CLIENT)
public class PlayerInputEvent extends CancellableEvent {
    private PlayerInput input;

    public PlayerInputEvent(PlayerInput playerinput) {
        this.input = playerinput;
    }

    public void setJumping(boolean flag) {
        this.input =
                new PlayerInput(
                        this.input.forward(),
                        this.input.backward(),
                        this.input.left(),
                        this.input.right(),
                        flag,
                        this.input.sneak(),
                        this.input.sprint());
    }

    public PlayerInput getInput() {
        return this.input;
    }

    public float sideways() {
        return this.input.left() ? 1.0F : (this.input.right() ? -1.0F : 0.0F);
    }

    public void setInput(PlayerInput playerinput) {
        this.input = playerinput;
    }

    public void setDirectional(boolean flag, boolean flag1, boolean flag2, boolean flag3) {
        this.input =
                new PlayerInput(
                        flag,
                        flag1,
                        flag2,
                        flag3,
                        this.input.jump(),
                        this.input.sneak(),
                        this.input.sprint());
    }

    public int forward() {
        return this.input.forward() ? 1 : (this.input.backward() ? -1 : 0);
    }

    public void inputNone() {
        this.input = new PlayerInput(false, false, false, false, false, false, false);
    }
}
