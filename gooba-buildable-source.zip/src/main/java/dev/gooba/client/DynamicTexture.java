package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImage.Format;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.imageio.ImageIO;

@Environment(EnvType.CLIENT)
public class DynamicTexture {
    private DynamicTexture(String source) {
        this.loaded = false;

        this.width = 0;
        this.height = 0;
        this.source = source;
        this.textureId =
                Identifier.of("avdeeeeeva", "url_images/" + Integer.toHexString(source.hashCode()));
    }

    private final Identifier textureId;
    private final String source;
    private volatile boolean loaded;

    private static final Map<String, DynamicTexture> cache = new ConcurrentHashMap<>();
    private int width;
    private int height;

    private void download() {
        try {
            if (!isSupportedImage(source)) {

                return;
            }
            HttpURLConnection connection =
                    (HttpURLConnection) URI.create(source).toURL().openConnection();
            try {
                // The candidate decoding the query delimiter to '?' yields these timeouts.
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(8000);
                connection.setRequestProperty("User-Agent", "WhiteClient/1.0");
                try (InputStream input = connection.getInputStream()) {
                    BufferedImage image = ImageIO.read(input);
                    if (image == null) {

                        return;
                    }
                    int imageWidth = image.getWidth();
                    int imageHeight = image.getHeight();
                    int[] pixels = image.getRGB(0, 0, imageWidth, imageHeight, null, 0, imageWidth);
                    MinecraftClient.getInstance()
                            .execute(() -> uploadDownloadedImage(imageWidth, imageHeight, pixels));
                }
            } finally {
                connection.disconnect();
            }
        } catch (Exception ignored) {

        } finally {

        }
    }

    private static boolean isSupportedImage(String source) {
        String path = source.toLowerCase(Locale.ROOT);
        int query = path.indexOf('?');
        if (query >= 0) path = path.substring(0, query);
        return path.endsWith(".png") || path.endsWith(".jpg") || path.endsWith(".jpeg");
    }

    private void uploadDownloadedImage(int widthValue, int heightValue, int[] aint) {
        this.upload(widthValue, heightValue, aint);
    }

    private void upload(int widthValue, int heightValue, int[] aint) {
        if (!this.loaded) {
            NativeImage nativeimage = new NativeImage(Format.RGBA, widthValue, heightValue, false);

            for (int k = 0; k < heightValue; k++) {
                for (int l = 0; l < widthValue; l++) {
                    nativeimage.setColorArgb(l, k, aint[k * widthValue + l]);
                }
            }

            NativeImageBackedTexture nativeimagebackedtexture =
                    new NativeImageBackedTexture(() -> this.textureId.toString(), nativeimage);
            nativeimagebackedtexture.upload();
            MinecraftClient.getInstance()
                    .getTextureManager()
                    .registerTexture(this.textureId, nativeimagebackedtexture);
            this.width = widthValue;
            this.height = heightValue;
            this.loaded = true;
        }
    }

    private void destroyTexture(int i) {
        MinecraftClient.getInstance().getTextureManager().destroyTexture(this.textureId);
    }
}
