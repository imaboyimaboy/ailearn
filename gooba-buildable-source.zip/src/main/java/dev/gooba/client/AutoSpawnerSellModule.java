package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;

@ModuleInfo(
        name = "Auto Spawner Sell",
        category = ModuleCategory.DONUT,
        desc = "Automatically sells items from your spawners.")
@Environment(EnvType.CLIENT)
public class AutoSpawnerSellModule extends Module {
    private String firstMenuTitle;
    private int stateTicks;
    public final BooleanSetting notificationsSetting;
    private int menuWaitTicks;
    public final SliderSetting clickDelayTicksSetting;

    private AutoSpawnerSellModule.State state;
    private int clickDelayTicks;
    private int completedCycles;
    public final SliderSetting intervalMinSetting =
            new SliderSetting(this, "Interval (min)", 5.0F, 1.0F, 60.0F, 1.0F);

    private void sendMessage(String text) {
        if (this.notificationsSetting.isOn() && client.player != null) {
            client.player.sendMessage(Text.literal("§7[§6Auto Spawner Sell§7] §f" + text), false);
        }
    }

    private void waitForSecondMenu() {
        if (client.currentScreen instanceof GenericContainerScreen) {
            String stringValue = client.currentScreen.getTitle().getString();
            if (!stringValue.equals(this.firstMenuTitle) || this.menuWaitTicks > 5) {
                this.state = AutoSpawnerSellModule.State.CLICK_LIME_1;
                this.stateTicks = 0;
                this.clickDelayTicks = this.getClickDelay();
                return;
            }
        }

        if (++this.menuWaitTicks > 60) {
            this.sendMessage("§cSecond GUI did not open — retrying next cycle.");
            this.cancelCycle();
        }
    }

    private int getClickDelay() {
        return Math.max(1, (int) this.clickDelayTicksSetting.getFloat().floatValue());
    }

    private void interactWithSpawner() {
        if (client.currentScreen != null) {
            client.player.closeHandledScreen();
            this.stateTicks = 0;
            this.clickDelayTicks = 5;
        } else if (this.clickDelayTicks > 0) {
            this.clickDelayTicks--;
        } else {
            if (client.crosshairTarget != null && client.crosshairTarget.getType() == Type.BLOCK) {
                BlockHitResult blockhitresult = (BlockHitResult) client.crosshairTarget;
                client.interactionManager.interactBlock(
                        client.player, Hand.MAIN_HAND, blockhitresult);
                this.state = AutoSpawnerSellModule.State.WAIT_FIRST_GUI;
                this.stateTicks = 0;
                this.menuWaitTicks = 0;
            } else {
                this.sendMessage("§cNo block in crosshair — retrying next cycle.");
                this.resetCycle();
            }
        }
    }

    public AutoSpawnerSellModule() {
        this.clickDelayTicksSetting =
                new SliderSetting(this, "Click Delay (ticks)", 5.0F, 1.0F, 40.0F, 1.0F);
        this.notificationsSetting = new BooleanSetting(this, "Notifications", true);
        this.state = AutoSpawnerSellModule.State.WAITING;
        this.stateTicks = 0;
        this.clickDelayTicks = 0;
        this.menuWaitTicks = 0;
        this.firstMenuTitle = "";
        this.completedCycles = 0;
    }

    private void waitForNextCycle() {
        int i = (int) (this.intervalMinSetting.getFloat() * 60.0F * 20.0F);
        if (this.stateTicks >= i) {
            this.state = AutoSpawnerSellModule.State.RIGHT_CLICK;
            this.stateTicks = 0;
            this.sendMessage("§7Starting sell cycle...");
        }
    }

    private int findConfirmSlot(GenericContainerScreen genericcontainerscreen) {
        GenericContainerScreenHandler genericcontainerscreenhandler =
                genericcontainerscreen.getScreenHandler();
        int i = genericcontainerscreenhandler.getRows() * 9;

        for (int j = 0; j < i; j++) {
            Slot slot = genericcontainerscreenhandler.getSlot(j);
            if (slot != null
                    && slot.hasStack()
                    && slot.getStack().isOf(Items.LIME_STAINED_GLASS_PANE)) {
                return j;
            }
        }

        return -1;
    }

    private void clickGoldIngot() {
        if (this.clickDelayTicks > 0) {
            this.clickDelayTicks--;
        } else if (!(client.currentScreen
                instanceof GenericContainerScreen genericcontainerscreen)) {
            this.sendMessage("§cGUI closed unexpectedly — retrying next cycle.");
            this.resetCycle();
        } else {
            GenericContainerScreenHandler genericcontainerscreenhandler =
                    genericcontainerscreen.getScreenHandler();
            int i = genericcontainerscreenhandler.getRows() * 9;
            int j = -1;

            for (int k = 0; k < i; k++) {
                Slot slot = genericcontainerscreenhandler.getSlot(k);
                if (slot != null && slot.hasStack() && slot.getStack().isOf(Items.GOLD_INGOT)) {
                    j = k;
                    break;
                }
            }

            if (j == -1) {
                this.sendMessage("§cGold Ingot not found in GUI — retrying next cycle.");
                this.cancelCycle();
            } else {
                client.interactionManager.clickSlot(
                        genericcontainerscreenhandler.syncId,
                        j,
                        0,
                        SlotActionType.PICKUP,
                        client.player);
                this.sendMessage("§7Clicked Gold Ingot.");
                this.state = AutoSpawnerSellModule.State.WAIT_SECOND_GUI;
                this.stateTicks = 0;
                this.menuWaitTicks = 0;
            }
        }
    }

    private void clickFirstConfirmation() {
        if (this.clickDelayTicks > 0) {
            this.clickDelayTicks--;
        } else if (client.currentScreen instanceof GenericContainerScreen genericcontainerscreen) {
            int i = this.findConfirmSlot(genericcontainerscreen);
            if (i == -1) {
                this.sendMessage("§cLime Stained Glass Pane not found — retrying next cycle.");
                this.cancelCycle();
            } else {
                GenericContainerScreenHandler genericcontainerscreenhandler =
                        genericcontainerscreen.getScreenHandler();
                client.interactionManager.clickSlot(
                        genericcontainerscreenhandler.syncId,
                        i,
                        0,
                        SlotActionType.PICKUP,
                        client.player);
                this.sendMessage("§7Clicked Lime Glass Pane (1/2).");
                this.state = AutoSpawnerSellModule.State.CLICK_LIME_2;
                this.stateTicks = 0;
                this.clickDelayTicks = this.getClickDelay();
            }
        } else {
            this.sendMessage("§cGUI closed unexpectedly — retrying next cycle.");
            this.resetCycle();
        }
    }

    private void finishCycle() {
        if (this.clickDelayTicks > 0) {
            this.clickDelayTicks--;
        } else {
            if (client.currentScreen != null && client.player != null) {
                client.player.closeHandledScreen();
            }

            this.completedCycles++;
            int completedCyclesValue = this.completedCycles;
            int j = (int) this.intervalMinSetting.getFloat().floatValue();
            int completedCyclesValueValue = completedCyclesValue;
            this.sendMessage(
                    "§aCycle §e#"
                            + completedCyclesValueValue
                            + " §acomplete! §7Next in §e"
                            + j
                            + " §7min.");
            this.resetCycle();
        }
    }

    private void clickSecondConfirmation() {
        if (this.clickDelayTicks > 0) {
            this.clickDelayTicks--;
        } else if (client.currentScreen instanceof GenericContainerScreen genericcontainerscreen) {
            int i = this.findConfirmSlot(genericcontainerscreen);
            if (i == -1) {
                this.sendMessage(
                        "§cLime Stained Glass Pane not found for 2nd click — retrying next cycle.");
                this.cancelCycle();
            } else {
                GenericContainerScreenHandler genericcontainerscreenhandler =
                        genericcontainerscreen.getScreenHandler();
                client.interactionManager.clickSlot(
                        genericcontainerscreenhandler.syncId,
                        i,
                        0,
                        SlotActionType.PICKUP,
                        client.player);
                this.sendMessage("§7Clicked Lime Glass Pane (2/2).");
                this.state = AutoSpawnerSellModule.State.CLOSE_GUI;
                this.stateTicks = 0;
                this.clickDelayTicks = this.getClickDelay();
            }
        } else {
            this.sendMessage("§cGUI closed unexpectedly — retrying next cycle.");
            this.resetCycle();
        }
    }

    private void cancelCycle() {
        if (client.currentScreen != null && client.player != null) {
            client.player.closeHandledScreen();
        }

        this.resetCycle();
    }

    private void waitForFirstMenu() {
        if (client.currentScreen instanceof GenericContainerScreen) {
            this.firstMenuTitle = client.currentScreen.getTitle().getString();
            this.state = AutoSpawnerSellModule.State.CLICK_GOLD_INGOT;
            this.stateTicks = 0;
            this.clickDelayTicks = this.getClickDelay();
        } else {
            if (++this.menuWaitTicks > 60) {
                this.sendMessage("§cFirst GUI did not open — retrying next cycle.");
                this.resetCycle();
            }
        }
    }

    @Override
    protected void onEnable() {
        this.state = AutoSpawnerSellModule.State.WAITING;
        this.stateTicks = 0;
        this.clickDelayTicks = 0;
        this.menuWaitTicks = 0;
        this.completedCycles = 0;
        int i = (int) this.intervalMinSetting.getFloat().floatValue();
        this.sendMessage("§aEnabled §7— first cycle in §e" + i + " §7min.");
    }

    private void resetCycle() {
        this.state = AutoSpawnerSellModule.State.WAITING;
        this.stateTicks = 0;
        this.clickDelayTicks = 0;
        this.menuWaitTicks = 0;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null && client.interactionManager != null) {
            this.stateTicks++;
            switch (this.state) {
                case WAITING:
                    this.waitForNextCycle();
                    break;
                case RIGHT_CLICK:
                    this.interactWithSpawner();
                    break;
                case WAIT_FIRST_GUI:
                    this.waitForFirstMenu();
                    break;
                case CLICK_GOLD_INGOT:
                    this.clickGoldIngot();
                    break;
                case WAIT_SECOND_GUI:
                    this.waitForSecondMenu();
                    break;
                case CLICK_LIME_1:
                    this.clickFirstConfirmation();
                    break;
                case CLICK_LIME_2:
                    this.clickSecondConfirmation();
                    break;
                case CLOSE_GUI:
                    this.finishCycle();
            }
        }
    }

    @Override
    protected void onDisable() {
        this.state = AutoSpawnerSellModule.State.WAITING;
        this.stateTicks = 0;
        this.clickDelayTicks = 0;
        this.menuWaitTicks = 0;
        if (client.currentScreen != null && client.player != null) {
            client.player.closeHandledScreen();
        }

        int completedCyclesValue = this.completedCycles;
        this.sendMessage("§cDisabled §7— ran §e" + completedCyclesValue + " §7cycles.");
    }

    @Environment(EnvType.CLIENT)
    private static enum State {
        WAITING,
        RIGHT_CLICK,
        WAIT_FIRST_GUI,
        CLICK_GOLD_INGOT,
        WAIT_SECOND_GUI,
        CLICK_LIME_1,
        CLICK_LIME_2,
        CLOSE_GUI;
    }
}
