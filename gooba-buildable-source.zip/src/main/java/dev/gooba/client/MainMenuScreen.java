package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class MainMenuScreen extends Screen implements MinecraftAccess {
    private boolean fadeStarted;

    private static final Identifier LOGO_TEXTURE = Identifier.of("client", "textures/gooba.png");
    private static final Identifier BACKGROUND_TEXTURE =
            Identifier.of("client", "textures/frame/menu.png");

    private double mouseY;
    private float guiScale;
    private final EasingAnimation fadeAnimation = new EasingAnimation();
    private final MainMenuScreen.MenuButton exitButton;
    private final List<MainMenuScreen.MenuButton> buttons = new ArrayList<>();
    private double mouseX;

    @Override
    public void render(DrawContext drawcontext, int i, int j, float f) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getHudManager() != null) {
            i = (int) ((float) i / this.guiScale);
            j = (int) ((float) j / this.guiScale);
            this.mouseX = (double) i;
            this.mouseY = (double) j;
            if (!this.fadeStarted && MinecraftAccess.client.getOverlay() == null) {
                this.fadeAnimation.snapTo(0.0);
                this.fadeAnimation.animateTo(1.0, 0.5, Easings.OUT_QUAD);
                this.fadeStarted = true;
            }

            this.fadeAnimation.update();
            this.drawMenu(drawcontext);
        }
    }

    private void drawContent(int i, int j, float opacity) {
        float f1 = (float) i * 0.5F;
        float f2 = 54.0F;
        float f3 = (float) j * 0.5F - 92.0F;
        RenderUtils.Images.drawImage(
                LOGO_TEXTURE,
                f1 - f2 * 0.5F,
                f3,
                f2,
                f2,
                ColorUtils.grayscaleOpacity(255, opacity));
        String string = "GOOBAA CLIENT";
        float size = 15.0F;
        float f5 = f3 + f2 + 8.0F;
        Fonts.MENU.drawCenteredText(
                string, f1, f5, size, ColorUtils.grayscaleOpacity(255, opacity));
        float widthValue = Math.min(150.0F, (float) i - 28.0F);
        float heightValue = 18.0F;
        float f8 = 5.0F;
        float f9 = f5 + Fonts.MENU.getLineHeight(size) + 13.0F;

        for (MainMenuScreen.MenuButton menuButtonValue : this.buttons) {
            menuButtonValue.render(f1 - widthValue * 0.5F, f9, widthValue, heightValue, opacity);
            f9 += heightValue + f8;
        }

        float widthValueValue = 25.0F;
        float heightValueValue = 17.0F;
        this.exitButton.render(
                f1 - widthValueValue * 0.5F,
                (float) j - heightValueValue - 6.0F,
                widthValueValue,
                heightValueValue,
                opacity);
        Font font = Fonts.INTER_SEMIBOLD;
        float f12 = (float) j - 14.0F;
        ColorUtils.cachedRgba(155, 155, 160, Math.round(210.0F * opacity));
        font.drawText("Goobaa Client (a043/version)", 10.0F, f12, 7.5F);
    }

    @Override
    public boolean mouseClicked(Click click, boolean flag) {
        if (click.button() == 0) {
            for (MainMenuScreen.MenuButton menuButtonValue : this.buttons) {
                if (menuButtonValue.isHovered()) {
                    menuButtonValue.click();
                    return true;
                }
            }

            if (this.exitButton.isHovered()) {
                this.exitButton.click();
                return true;
            }
        }

        return super.mouseClicked(click, flag);
    }

    @Override
    protected void init() {
        this.fadeAnimation.snapTo(0.0);
        this.fadeStarted = false;
        this.initializeButtons();
    }

    private void initializeButtons() {
        this.buttons.clear();
        this.buttons.add(
                new MainMenuScreen.MenuButton(
                        "Singleplayer",
                        () -> MinecraftAccess.client.setScreen(new SelectWorldScreen(this))));
        this.buttons.add(
                new MainMenuScreen.MenuButton(
                        "Multiplayer",
                        () -> MinecraftAccess.client.setScreen(new MultiplayerScreen(this))));
        if (FabricLoader.getInstance().isModLoaded("modmenu")) {
            this.buttons.add(
                    new MainMenuScreen.MenuButton(
                            "Mods",
                            () -> {
                                try {
                                    Class oclass =
                                            Class.forName(
                                                    "com.terraformersmc.modmenu.gui.ModsScreen");
                                    Screen screen =
                                            (Screen)
                                                    oclass.getConstructor(Screen.class)
                                                            .newInstance(this);
                                    MinecraftAccess.client.setScreen(screen);
                                } catch (Exception exception) {
                                }
                            }));
        }
    }

    @Override
    public void renderBackground(DrawContext drawcontext, int i, int j, float f) {}

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    private void drawMenu(DrawContext drawcontext) {
        float scaleFactor = (float) MinecraftAccess.client.getWindow().getScaleFactor();
        this.guiScale = 2.0F / scaleFactor;
        int i = (int) ((float) MinecraftAccess.client.getWindow().getScaledWidth() / this.guiScale);
        int j =
                (int)
                        ((float) MinecraftAccess.client.getWindow().getScaledHeight()
                                / this.guiScale);
        drawcontext.getMatrices().pushMatrix();
        HudManager.beginHudRender();
        float floatValue = this.fadeAnimation.getFloatValue();
        float f2 = 1.08F;
        float f3 = (float) i * f2;
        float f4 = (float) j * f2;
        RenderUtils.Images.drawOpaqueImage(
                BACKGROUND_TEXTURE,
                ((float) i - f3) * 0.5F,
                ((float) j - f4) * 0.5F,
                f3,
                f4,
                ColorUtils.opaqueGrayscale(255));
        BackgroundBlur.blurDefault();
        RenderUtils.Blur.drawRoundedBlur(
                0.0F, 0.0F, (float) i, (float) j, 1.0F, 0.0F, ColorUtils.cachedRgba(0, 0, 0, 32));

        for (MainMenuScreen.MenuButton menuButtonValue : this.buttons) {
            menuButtonValue.updateHover(this.mouseX, this.mouseY);
        }

        this.exitButton.updateHover(this.mouseX, this.mouseY);
        this.drawContent(i, j, floatValue);
        Gooba.getInstance().getHudManager().flush();
        HudManager.endHudRender();
        drawcontext.getMatrices().popMatrix();
    }

    private static void drawButtonBackground(
            float f, float f1, float widthValue, float heightValue, float f4, float f5) {
        float strength = Math.min(1.0F, f4 * (0.22F + f5 * 0.18F));
        RenderUtils.Blur.drawRoundedBlur(
                f - 0.5F,
                f1 - 0.5F,
                widthValue + 1.0F,
                heightValue + 1.0F,
                strength,
                4.0F,
                ColorUtils.cachedRgba(205, 208, 214, Math.round(38.0F * f4)));
        RenderUtils.Render2D.drawRoundedOutline(
                f,
                f1,
                widthValue,
                heightValue,
                0.35F,
                ColorUtils.cachedRgba(205, 208, 214, Math.round((62.0F + f5 * 42.0F) * f4)),
                4.0F);
    }

    public MainMenuScreen() {
        super(Text.literal("MainMenuScreen"));
        this.exitButton =
                new MainMenuScreen.MenuButton(
                        "K", () -> MinecraftAccess.client.scheduleStop(), true);
        this.guiScale = 1.0F;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Environment(EnvType.CLIENT)
    private static class MenuButton {
        private final String label;
        private float x;
        private final Runnable action;
        private final boolean iconButton;
        private float width;
        private float height;
        private float y;
        private boolean hovered;
        private final EasingAnimation hoverAnimation = new EasingAnimation();

        private boolean isHovered() {
            return this.hovered;
        }

        private MenuButton(String stringValue, Runnable runnable, boolean iconButtonValue) {
            this.label = stringValue;
            this.action = runnable;
            this.iconButton = iconButtonValue;
            this.hoverAnimation.snapTo(0.0);
        }

        private void click() {
            this.action.run();
        }

        private MenuButton(String stringValue, Runnable runnable) {
            this(stringValue, runnable, false);
        }

        private void updateHover(double d0, double d1) {
            this.hovered =
                    MathUtils.containsPoint(
                            (float) d0, (float) d1, this.x, this.y, this.width, this.height);
            this.hoverAnimation.update();
            this.hoverAnimation.animateTo(this.hovered ? 1.0 : 0.0, 0.18F, Easings.OUT_QUAD);
        }

        private void render(
                float f, float f1, float widthValue, float heightValue, float strength) {
            this.x = f;
            this.y = f1;
            this.width = widthValue;
            this.height = heightValue;
            float floatValue = this.hoverAnimation.getFloatValue();
            MainMenuScreen.drawButtonBackground(
                    f, f1, widthValue, heightValue, strength, floatValue);
            RenderUtils.Blur.drawRoundedBlur(
                    f,
                    f1,
                    widthValue,
                    heightValue,
                    strength,
                    4.0F,
                    ColorUtils.grayscaleOpacity(
                            20, Math.min(1.0F, strength * (0.34F + floatValue * 0.14F))));
            float size = this.iconButton ? 8.5F : 8.0F;
            if (this.iconButton) {
                Font font = Fonts.GOOBA_ICONS;
                String stringValue = this.label;
                float f7 = Fonts.GOOBA_ICONS.centerTextX(this.label, f, widthValue, size);
                float f8 = Fonts.GOOBA_ICONS.centerTextY(this.label, f1, heightValue, size);
                ColorUtils.cachedRgba(
                        238,
                        70 + Math.round(25.0F * floatValue),
                        70 + Math.round(25.0F * floatValue),
                        Math.round(255.0F * strength));
                font.drawText(stringValue, f7, f8, size);
            } else {
                Fonts.INTER_SEMIBOLD.drawCenteredText(
                        this.label,
                        f + widthValue * 0.5F,
                        Fonts.INTER_SEMIBOLD.centerTextY(this.label, f1, heightValue, size),
                        size,
                        ColorUtils.cachedRgba(235, 235, 238, Math.round(255.0F * strength)));
            }
        }
    }
}
