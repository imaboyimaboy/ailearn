package dev.gooba.client;

import com.mojang.authlib.GameProfile;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

@Environment(EnvType.CLIENT)
public class RotationTrainer implements MinecraftAccess {
    private float smoothedYawSpeed;
    private float targetY;
    private final List<double[]> trainingOutputs;
    private float smoothedPitchSpeed;
    private float previousFrameYaw;
    private Vec3d dummyOrigin;
    private float previousStraightness;
    private float targetZ;
    private int frameSamples;
    private static RotationTrainer instance;
    private float previousPeakRatio;
    private long trainingStartedMillis;
    private float previousFramePitch;
    private float previousYawDelta;
    private float smoothedPitchDelta;
    private float peakMovement;
    private RotationModelStore currentModel;
    private boolean trajectoryInterrupted;
    private final List<float[]> trajectories;
    private final List<float[]> strokes;
    private OtherClientPlayerEntity dummy;
    private boolean hasPreviousFrame;
    private float accumulatedMovement;
    private float previousPitch;
    private final Map<String, RotationModelStore> models = new LinkedHashMap<>();
    private float previousYaw;
    private boolean ownsDummy;

    private float targetX;
    private boolean training;
    private int ticksSinceAttack;
    private float previousPitchDelta;
    private final List<double[]> trainingInputs = new ArrayList<>();
    private float smoothedYawDelta;

    public boolean createModel(String text) {
        if (this.models.containsKey(text.toLowerCase())) {
            return false;
        } else {
            RotationModelStore rotationModelStore2 = new RotationModelStore(text);
            this.models.put(text.toLowerCase(), rotationModelStore2);
            this.currentModel = rotationModelStore2;
            rotationModelStore2.save();
            RotationModelStore.setCurrentModel(text);
            return true;
        }
    }

    @EventHandler
    public void onAttack(AttackEvent attackEvent) {
        if (this.training) {
            this.ticksSinceAttack = 0;
        }
    }

    private void spawnDummy() {
        double d0 = Math.toRadians((double) Rotation.getCameraYaw());
        double d1 = -Math.sin(d0) * 3.5;
        double d2 = Math.cos(d0) * 3.5;
        this.dummyOrigin =
                new Vec3d(
                        client.player.getX() + d1, client.player.getY(), client.player.getZ() + d2);
        this.ownsDummy = true;
        GameProfile gameprofile =
                new GameProfile(
                        UUID.fromString("32d0a964-137a-2c03-7cc9-df6700000001"), "NEURO_DUMMY");
        this.dummy = new OtherClientPlayerEntity(client.world, gameprofile);
        this.dummy.refreshPositionAndAngles(
                this.dummyOrigin.x, this.dummyOrigin.y, this.dummyOrigin.z, 0.0F, 0.0F);
        this.dummy.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        this.dummy.equipStack(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
        this.dummy.equipStack(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        this.dummy.equipStack(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
        this.dummy.setStackInHand(Hand.MAIN_HAND, new ItemStack(Items.NETHERITE_SWORD));
        this.dummy.setStackInHand(Hand.OFF_HAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        this.dummy.setHealth(20.0F);
        this.dummy.setGlowing(true);
        client.world.addEntity(this.dummy);
    }

    private void loadModels() {
        try {
            if (Files.isDirectory(RotationModelStore.MODEL_DIRECTORY)) {
                Stream<Path> stream = Files.list(RotationModelStore.MODEL_DIRECTORY);

                try {
                    stream.filter(path -> path.getFileName().toString().endsWith(".neuro"))
                            .forEach(
                                    path -> {
                                        String text = path.getFileName().toString();
                                        String textValue =
                                                text.substring(
                                                        0, text.length() - ".neuro".length());
                                        RotationModelStore rotationModelStore3 =
                                                RotationModelStore.load(textValue);
                                        if (rotationModelStore3 != null) {
                                            this.models.put(
                                                    textValue.toLowerCase(), rotationModelStore3);
                                        }
                                    });
                } catch (Throwable throwableValue) {
                    if (stream != null) {
                        try {
                            stream.close();
                        } catch (Throwable throwable) {
                            throwableValue.addSuppressed(throwable);
                            throw throwableValue;
                        }

                        throw throwableValue;
                    }

                    throw throwableValue;
                }

                if (stream != null) {
                    stream.close();
                }

                String currentModelValue = RotationModelStore.getCurrentModel();
                if (currentModelValue != null) {
                    this.currentModel = this.models.get(currentModelValue.toLowerCase());
                }

                if (this.currentModel == null) {
                    this.currentModel =
                            this.models.values().stream()
                                    .max(
                                            Comparator.comparingInt(
                                                    rotationModelStore3 ->
                                                            rotationModelStore3
                                                                    .trainingSampleCount))
                                    .orElse(null);
                }
            }
        } catch (Exception exception) {
        }
    }

    public RotationModelStore getCurrentModel() {
        return this.currentModel;
    }

    public void finishTraining() throws CloneNotSupportedException {
        if (!this.training) {
            ChatMessages.send("§7Training not started");
        } else {
            this.training = false;
            this.removeDummy();
            int count = this.trainingInputs.size();
            if (this.currentModel != null && count >= 10) {
                this.currentModel.ensureNetworkDimensions();
                double[][] adouble = this.trainingInputs.toArray(new double[0][]);
                double[][] valuesArray = this.trainingOutputs.toArray(new double[0][]);
                double trainingLoss =
                        this.currentModel.feedForwardNetwork.train(adouble, valuesArray, 650, 0.18);
                this.currentModel.addTrainingSamples(adouble, valuesArray);
                this.currentModel.addStrokes(this.strokes);
                this.currentModel.addTrajectories(this.trajectories);
                this.currentModel.trainingSampleCount += count;
                this.currentModel.trainingLoss = trainingLoss;
                this.currentModel.save();
                ChatMessages.send(
                        String.format(
                                "§a[Neuro] §7Model §f%s§7 trained: §f%d§7 samples, §f%d§7 strokes,"
                                    + " §f%d§7 trajectory ticks, error §f%.4f",
                                this.currentModel.name,
                                count,
                                this.currentModel.getStrokeCount(),
                                this.currentModel.getTrajectoryCount(),
                                trainingLoss));
            } else {
                ChatMessages.send(
                        "§cNot enough data ("
                                + count
                                + "), the model is not trained. Move your aim longer");
            }
        }
    }

    public void startTraining() {
        if (this.currentModel == null) {
            ChatMessages.send("§cFirst create/select a model: §f.neuro create <name>");
        } else if (client.player != null && client.world != null) {
            if (this.training) {
                ChatMessages.send("§7Training is already underway. §f.neuro stop §7to finish");
            } else {
                if (FakePlayerModule.fakePlayer != null && FakePlayerModule.fakePlayer.isAlive()) {
                    this.dummy = FakePlayerModule.fakePlayer;
                    this.dummyOrigin = this.dummy.getEntityPos();
                    this.ownsDummy = false;
                } else {
                    this.spawnDummy();
                }

                this.trainingInputs.clear();
                this.trainingOutputs.clear();
                this.previousYaw = Rotation.getCameraYaw();
                this.previousPitch = Rotation.getCameraPitch();
                this.previousYawDelta = 0.0F;
                this.previousPitchDelta = 0.0F;
                this.targetX = 0.5F;
                this.targetY = 0.5F;
                this.targetZ = 0.5F;
                this.hasPreviousFrame = false;
                this.accumulatedMovement = 0.0F;
                this.peakMovement = 0.0F;
                this.frameSamples = 0;
                this.previousStraightness = 1.0F;
                this.previousPeakRatio = 0.0F;
                this.smoothedYawSpeed = 0.0F;
                this.smoothedPitchSpeed = 0.0F;
                this.strokes.clear();
                this.smoothedYawDelta = 0.0F;
                this.smoothedPitchDelta = 0.0F;
                this.trajectories.clear();
                this.ticksSinceAttack = 999;
                this.trajectoryInterrupted = false;
                this.trainingStartedMillis = System.currentTimeMillis();
                this.training = true;
                String string = this.currentModel.name;
                ChatMessages.send(
                        "§a[Neuro] §7Training model §f"
                                + string
                                + "§7 has begun: aim at the hitbox. §f.neuro stop§7 to complete");
            }
        }
    }

    @EventHandler
    public void onRender2D(Render2DEvent render2DEvent) {
        if (this.training && client.player != null) {
            float cameraYaw = Rotation.getCameraYaw();
            float cameraPitch = Rotation.getCameraPitch();
            if (!this.hasPreviousFrame) {
                this.previousFrameYaw = cameraYaw;
                this.previousFramePitch = cameraPitch;
                this.hasPreviousFrame = true;
            } else {
                float f2 = MathHelper.wrapDegrees(cameraYaw - this.previousFrameYaw);
                float f3 = cameraPitch - this.previousFramePitch;
                float f4 = (float) Math.hypot((double) f2, (double) f3);
                this.accumulatedMovement += f4;
                this.peakMovement = Math.max(this.peakMovement, f4);
                this.frameSamples++;
                this.previousFrameYaw = cameraYaw;
                this.previousFramePitch = cameraPitch;
            }
        }
    }

    public boolean selectModel(String text) {
        RotationModelStore rotationModelStore2 = this.models.get(text.toLowerCase());
        if (rotationModelStore2 == null) {
            rotationModelStore2 = RotationModelStore.load(text);
        }

        if (rotationModelStore2 == null) {
            return false;
        } else {
            this.models.put(text.toLowerCase(), rotationModelStore2);
            this.currentModel = rotationModelStore2;
            RotationModelStore.setCurrentModel(rotationModelStore2.name);
            return true;
        }
    }

    private RotationTrainer() {
        this.trainingOutputs = new ArrayList<>();
        this.targetX = 0.5F;
        this.targetY = 0.5F;
        this.targetZ = 0.5F;
        this.previousStraightness = 1.0F;
        this.previousPeakRatio = 0.0F;
        this.strokes = new ArrayList<>();
        this.trajectories = new ArrayList<>();
        this.ticksSinceAttack = 999;
        this.loadModels();
    }

    private static float yawTo(Vec3d vec3d) {
        return (float) Math.toDegrees(Math.atan2(-vec3d.x, vec3d.z));
    }

    public static RotationTrainer getInstance() {
        if (instance == null) {
            instance = new RotationTrainer();
            Gooba.getEventBus().subscribe(instance);
        }

        return instance;
    }

    public Collection<RotationModelStore> getModels() {
        return this.models.values();
    }

    private static float[] relativeHitPosition(Box box, Vec3d vec3d) {
        return new float[] {
            clampUnit((float) ((vec3d.x - box.minX) / Math.max(0.001, box.maxX - box.minX))),
            clampUnit((float) ((vec3d.y - box.minY) / Math.max(0.001, box.maxY - box.minY))),
            clampUnit((float) ((vec3d.z - box.minZ) / Math.max(0.001, box.maxZ - box.minZ)))
        };
    }

    public float[] sampleTrajectory(float f, float f1, float f2) {
        return this.currentModel == null ? null : this.currentModel.sampleTrajectory(f, f1, f2);
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (this.training
                && client.player != null
                && client.world != null
                && this.dummy != null
                && this.dummyOrigin != null) {
            if (client.currentScreen == null && client.isWindowFocused()) {
                long i = System.currentTimeMillis() - this.trainingStartedMillis;
                double d0 = (double) i / 650.0;
                double d1 = Math.cos(d0) * 1.8;
                double d2 = Math.sin(d0 * 0.8) * 1.4;
                double d3 = Math.sin((double) i / 500.0) * 0.7;
                if (this.ownsDummy) {
                    this.dummy.refreshPositionAndAngles(
                            this.dummyOrigin.x + d1,
                            this.dummyOrigin.y + d3,
                            this.dummyOrigin.z + d2,
                            0.0F,
                            0.0F);
                }

                this.dummy.setHealth(20.0F);
                float cameraYaw = Rotation.getCameraYaw();
                float cameraPitch = Rotation.getCameraPitch();
                Vec3d vec3dx =
                        this.dummy.getBoundingBox().getCenter().subtract(client.player.getEyePos());
                float f2 = yawTo(vec3dx);
                float f3 = pitchTo(vec3dx);
                Vec3d vec3d1 = this.getAimPoint(this.dummy, cameraYaw, cameraPitch);
                float[] afloat = relativeHitPosition(this.dummy.getBoundingBox(), vec3d1);
                this.targetX = afloat[0];
                this.targetY = afloat[1];
                this.targetZ = afloat[2];
                Vec3d vec3d2 = vec3d1.subtract(client.player.getEyePos());
                float f4 = yawTo(vec3d2);
                float f5 = pitchTo(vec3d2);
                float f6 = MathHelper.wrapDegrees(f2 - this.previousYaw);
                float f7 = f3 - this.previousPitch;
                MathHelper.wrapDegrees(f4 - this.previousYaw);
                float previousYawDeltaValue = MathHelper.wrapDegrees(cameraYaw - this.previousYaw);
                float previousPitchDeltaValue = cameraPitch - this.previousPitch;
                float f10 = MathHelper.wrapDegrees(cameraYaw - f4);
                float f11 = cameraPitch - f5;
                float f12 = (float) client.player.getEyePos().distanceTo(vec3d1);
                this.smoothedYawSpeed =
                        this.smoothedYawSpeed
                                + (Math.abs(previousYawDeltaValue) - this.smoothedYawSpeed) * 0.45F;
                this.smoothedPitchSpeed =
                        this.smoothedPitchSpeed
                                + (Math.abs(previousPitchDeltaValue) - this.smoothedPitchSpeed)
                                        * 0.45F;
                float f13 = previousYawDeltaValue - this.smoothedYawDelta;
                float f14 = previousPitchDeltaValue - this.smoothedPitchDelta;
                this.smoothedYawDelta =
                        this.smoothedYawDelta
                                + (previousYawDeltaValue - this.smoothedYawDelta) * 0.35F;
                this.smoothedPitchDelta =
                        this.smoothedPitchDelta
                                + (previousPitchDeltaValue - this.smoothedPitchDelta) * 0.35F;
                this.strokes.add(
                        new float[] {
                            f13,
                            f14,
                            (float)
                                    Math.hypot(
                                            (double) this.smoothedYawDelta,
                                            (double) this.smoothedPitchDelta)
                        });
                this.ticksSinceAttack = Math.min(this.ticksSinceAttack + 1, 999);
                if (this.trajectoryInterrupted) {
                    this.trajectories.add(new float[] {0.0F, 0.0F, 0.0F, 0.0F, -1.0F});
                    this.trajectoryInterrupted = false;
                }

                this.trajectories.add(
                        new float[] {
                            f6,
                            f7,
                            previousYawDeltaValue,
                            previousPitchDeltaValue,
                            (float) Math.min(this.ticksSinceAttack, 60)
                        });
                float f15 =
                        (float)
                                Math.hypot(
                                        (double) previousYawDeltaValue,
                                        (double) previousPitchDeltaValue);
                float previousStraightnessValue =
                        this.accumulatedMovement < 0.02F
                                ? 1.0F
                                : MathHelper.clamp(f15 / this.accumulatedMovement, 0.0F, 1.0F);
                float previousPeakRatioValue =
                        this.frameSamples <= 0
                                ? 0.0F
                                : MathHelper.clamp(
                                        this.peakMovement * (float) this.frameSamples / 90.0F,
                                        0.0F,
                                        1.0F);
                this.accumulatedMovement = 0.0F;
                this.peakMovement = 0.0F;
                this.frameSamples = 0;
                this.trainingInputs.add(
                        RotationModelStore.encodeFeatures(
                                f6,
                                f7,
                                previousYawDeltaValue,
                                previousPitchDeltaValue,
                                this.previousYawDelta,
                                this.previousPitchDelta,
                                this.targetX,
                                this.targetY,
                                this.targetZ,
                                f12,
                                this.previousStraightness,
                                this.previousPeakRatio));
                this.trainingOutputs.add(
                        new double[] {
                            (double)
                                    (MathHelper.clamp(this.smoothedYawSpeed, 0.0F, 180.0F)
                                            / 180.0F),
                            (double)
                                    (MathHelper.clamp(this.smoothedPitchSpeed, 0.0F, 120.0F)
                                            / 120.0F),
                            (double) this.targetX,
                            (double) this.targetY,
                            (double) this.targetZ,
                            RotationModelStore.normalizeSigned(f10, 8.0F),
                            RotationModelStore.normalizeSigned(f11, 5.0F),
                            RotationModelStore.normalizeSigned(previousYawDeltaValue, 35.0F),
                            RotationModelStore.normalizeSigned(previousPitchDeltaValue, 22.0F),
                            RotationModelStore.normalizeSigned(
                                    previousYawDeltaValue - this.previousYawDelta, 35.0F),
                            RotationModelStore.normalizeSigned(
                                    previousPitchDeltaValue - this.previousPitchDelta, 22.0F),
                            (double) previousStraightnessValue,
                            (double) previousPeakRatioValue
                        });
                this.previousStraightness = previousStraightnessValue;
                this.previousPeakRatio = previousPeakRatioValue;
                this.previousYawDelta = previousYawDeltaValue;
                this.previousPitchDelta = previousPitchDeltaValue;
                this.previousYaw = cameraYaw;
                this.previousPitch = cameraPitch;
            } else {
                this.previousYaw = Rotation.getCameraYaw();
                this.previousPitch = Rotation.getCameraPitch();
                this.previousYawDelta = 0.0F;
                this.previousPitchDelta = 0.0F;
                this.accumulatedMovement = 0.0F;
                this.peakMovement = 0.0F;
                this.frameSamples = 0;
                this.hasPreviousFrame = false;
                this.smoothedYawDelta = 0.0F;
                this.smoothedPitchDelta = 0.0F;
                this.trajectoryInterrupted = true;
            }
        }
    }

    private static Vec3d rotationVector(float f, float f1) {
        double d0 = Math.toRadians((double) f);
        double d1 = Math.toRadians((double) f1);
        double d2 = Math.cos(d1);
        return new Vec3d(-Math.sin(d0) * d2, -Math.sin(d1), Math.cos(d0) * d2);
    }

    private Vec3d getAimPoint(OtherClientPlayerEntity otherclientplayerentity, float f, float f1) {
        Vec3d vec3dx = client.player.getEyePos();
        Vec3d vec3d1 = vec3dx.add(rotationVector(f, f1).multiply(8.0));
        Optional optional = otherclientplayerentity.getBoundingBox().raycast(vec3dx, vec3d1);
        if (optional.isPresent()) {
            return (Vec3d) optional.get();
        } else {
            Box box = otherclientplayerentity.getBoundingBox();
            return new Vec3d(
                    MathHelper.lerp((double) this.targetX, box.minX, box.maxX),
                    MathHelper.lerp((double) this.targetY, box.minY, box.maxY),
                    MathHelper.lerp((double) this.targetZ, box.minZ, box.maxZ));
        }
    }

    public float[] sampleStroke(float f) {
        return this.currentModel == null
                ? new float[] {0.0F, 0.0F}
                : this.currentModel.sampleStroke(f);
    }

    private static float pitchTo(Vec3d vec3d) {
        return (float)
                MathHelper.clamp(
                        -Math.toDegrees(Math.atan2(vec3d.y, Math.hypot(vec3d.x, vec3d.z))),
                        -90.0,
                        90.0);
    }

    public RotationModelStore.Prediction predict(double[] adouble) {
        return this.currentModel != null && this.currentModel.trainingSampleCount > 0
                ? this.currentModel.predict(adouble)
                : new RotationModelStore.Prediction(
                        90.0F, 90.0F, 0.5F, 0.5F, 0.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F,
                        0.0F, false);
    }

    public boolean deleteModel(String text) {
        RotationModelStore rotationModelStore2 = this.models.remove(text.toLowerCase());

        try {
            Files.deleteIfExists(RotationModelStore.MODEL_DIRECTORY.resolve(text + ".neuro"));
        } catch (Exception exception) {
        }

        if (rotationModelStore2 != null && this.currentModel == rotationModelStore2) {
            this.currentModel =
                    this.models.values().stream()
                            .max(Comparator.comparingInt(ctrx -> ctrx.trainingSampleCount))
                            .orElse(null);
            if (this.currentModel == null) {
                RotationModelStore.setCurrentModel(null);
            } else {
                RotationModelStore.setCurrentModel(this.currentModel.name);
            }
        }

        return rotationModelStore2 != null;
    }

    private static float clampUnit(float f) {
        return MathHelper.clamp(f, 0.0F, 1.0F);
    }

    private void removeDummy() {
        if (this.dummy != null && this.ownsDummy) {
            this.dummy.discard();
        }

        this.dummy = null;
        this.ownsDummy = false;
    }
}
