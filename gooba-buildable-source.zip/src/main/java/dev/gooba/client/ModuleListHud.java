package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;

@Environment(EnvType.CLIENT)
public class ModuleListHud implements HudElement {
    private final EasingAnimation heightAnimation;
    private final IdentityHashMap<Module, EasingAnimation> moduleVisibilityAnimations =
            new IdentityHashMap<>();
    private final IdentityHashMap<Module, EasingAnimation> modulePositionAnimations =
            new IdentityHashMap<>();
    private boolean heightInitialized;
    private boolean initialized;

    @Override
    public void render(PositionSetting positionSetting2, HUDModule hUDModule) {
        if (client.player != null && client.world != null) {
            float f = hUDModule.hudSizeSetting.getFloat();
            float size = 7.5F * f;
            float f2 = 3.0F * f;
            float heightValue = 11.0F * f;
            float height = 12.0F * f;
            List list =
                    Gooba.getInstance().getModuleRegistry().values().stream()
                            .filter(
                                    module6 ->
                                            module6.getCategory() != ModuleCategory.RENDER
                                                    && module6.getCategory()
                                                            != ModuleCategory.CLIENT)
                            .toList();
            if (!this.initialized) {
                for (Module moduleValue : (Iterable<Module>) (Iterable) list) {
                    this.moduleVisibilityAnimations.put(
                            moduleValue,
                            new EasingAnimation()
                                    .resetValue(moduleValue.isEnabled() ? 1.0F : 0.0F));
                }

                this.initialized = true;
            }

            IdentityHashMap identityhashmap = new IdentityHashMap();
            ArrayList<Module> arraylist = new ArrayList<>();

            for (Module module10 : (Iterable<Module>) (Iterable) list) {
                EasingAnimation easingAnimation2 =
                        this.moduleVisibilityAnimations.computeIfAbsent(
                                module10, module6 -> new EasingAnimation().resetValue(0.0F));
                float f5 = easingAnimation2.approach(module10.isEnabled() ? 1.0F : 0.0F, 8.0F);
                identityhashmap.put(module10, f5);
                if (module10.isEnabled() || f5 > 0.001F) {
                    arraylist.add(module10);
                }
            }

            arraylist.sort(
                    (module6, module) ->
                            Float.compare(
                                    Fonts.INTER_SEMIBOLD.measureWidth(getDisplayName(module), size),
                                    Fonts.INTER_SEMIBOLD.measureWidth(
                                            getDisplayName(module6), size)));
            float f21 = 0.0F;

            for (Module module3 : (Iterable<Module>) (Iterable) list) {
                f21 =
                        Math.max(
                                f21,
                                Fonts.INTER_SEMIBOLD.measureWidth(getDisplayName(module3), size));
            }

            float width3 = f21 + f2 * 2.0F;
            boolean visible = client.currentScreen instanceof ChatScreen;
            if (arraylist.isEmpty()) {
                positionSetting2.visible = visible;
                if (visible) {
                    hUDModule.drawBackground(
                            positionSetting2.position.x,
                            positionSetting2.position.y,
                            width3,
                            heightValue,
                            3.0F * f,
                            1.0F);
                }

                positionSetting2.size.set(width3, heightValue);
            } else {
                positionSetting2.visible = true;
                if (!this.heightInitialized) {
                    this.heightAnimation.resetValue(heightValue);
                    this.heightInitialized = true;
                }

                float f23 = positionSetting2.position.x;
                float f6 = positionSetting2.position.y;
                float f7 = f23 + width3;
                float[] afloat = new float[arraylist.size()];

                for (int i = 0; i < arraylist.size(); i++) {
                    afloat[i] =
                            Fonts.INTER_SEMIBOLD.measureWidth(
                                            getDisplayName((Module) arraylist.get(i)), size)
                                    + f2 * 2.0F;
                }

                int i1 = 0;

                while (i1 < afloat.length) {
                    float f8 = afloat[i1];

                    int j;
                    for (j = i1 + 1;
                            j < afloat.length && Math.abs(afloat[j] - f8) <= 3.0F * f;
                            j++) {
                        f8 = Math.max(f8, afloat[j]);
                    }

                    for (int k = i1; k < j; k++) {
                        afloat[k] = f8;
                    }

                    i1 = j;
                }

                float f24 = 3.0F * f;
                float target = f6;
                float f26 = 0.0F;

                for (int l = 0; l < arraylist.size(); l++) {
                    Module module7 = (Module) arraylist.get(l);
                    float orDefault =
                            (float) identityhashmap.getOrDefault(module7, Float.valueOf(0.0F));
                    String string = getDisplayName(module7);
                    float width = afloat[l];
                    EasingAnimation easingAnimation3 = this.modulePositionAnimations.get(module7);
                    if (easingAnimation3 == null) {
                        easingAnimation3 = new EasingAnimation().resetValue(target);
                        this.modulePositionAnimations.put(module7, easingAnimation3);
                    }

                    float innerY = easingAnimation3.approach(target, 8.5F);
                    float innerX = f7 - width + (1.0F - orDefault) * 20.0F * f;
                    boolean flagx;
                    flagx = (l == 0);

                    boolean flag1;
                    flag1 = (l == arraylist.size() - 1);

                    boolean flag2x;
                    flag2x = (!flagx && width > afloat[l - 1] + 0.5F * f);

                    boolean flag3;
                    flag3 = (!flag1 && width > afloat[l + 1] + 0.5F * f);

                    float f13 = !flagx && !flag2x ? 0.0F : f24;
                    float f14 = 0.0F;
                    float f15 = 0.0F;
                    float f16 = !flag1 && !flag3 ? 0.0F : f24;
                    hUDModule.drawCornerBlur(
                            innerX,
                            innerY,
                            width,
                            height,
                            f13,
                            f14,
                            f15,
                            f16,
                            orDefault,
                            hUDModule.getTintedBackgroundColor());
                    float widthValue = Math.max(1.0F, f);
                    RenderUtils.Render2D.drawRoundedRect(
                            innerX + width - widthValue,
                            innerY,
                            widthValue,
                            height,
                            hUDModule.getAccentColor(orDefault),
                            0.0F);
                    float f18 = Fonts.INTER_SEMIBOLD.centerTextY(string, innerY, height, size);
                    float f19 =
                            innerX
                                    + (width - Fonts.INTER_SEMIBOLD.measureWidth(string, size))
                                            / 2.0F;
                    Math.round(255.0F * orDefault);
                    Fonts.INTER_SEMIBOLD.drawText(string, f19, f18, size);
                    float f20 = heightValue * orDefault;
                    target += f20;
                    f26 += f20;
                }

                float f27 = this.heightAnimation.approach(Math.max(f26, heightValue), 8.5F);
                positionSetting2.size.set(width3, f27);
            }
        }
    }

    public ModuleListHud() {
        this.heightAnimation = new EasingAnimation();
    }

    private static String getDisplayName(Module module) {
        return module.getBigName();
    }
}
