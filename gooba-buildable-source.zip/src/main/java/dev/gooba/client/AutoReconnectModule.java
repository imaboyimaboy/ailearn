package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

@ModuleInfo(
        name = "Auto Reconnect",
        category = ModuleCategory.OTHER,
        desc = "Automatically reconnects when disconnected from a server.")
@Environment(EnvType.CLIENT)
public class AutoReconnectModule extends Module {
    public final SliderSetting delaySetting =
            new SliderSetting(this, "Delay", 3.5F, 0.0F, 60.0F, 0.1F);
    public ServerInfo serverInfo;
    private Screen previousScreen;
    private long disconnectedAtMillis = -1L;
    private boolean reconnectStarted;
    public ServerAddress serverAddress;

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.currentScreen != this.previousScreen) {
            this.previousScreen = client.currentScreen;
            if (client.currentScreen instanceof DisconnectedScreen) {
                this.disconnectedAtMillis = -1L;
                this.reconnectStarted = false;
            }
        }

        ServerInfo serverinfo = client.getCurrentServerEntry();
        if (serverinfo != null && client.getNetworkHandler() != null) {
            this.rememberServer(ServerAddress.parse(serverinfo.address), serverinfo);
            this.disconnectedAtMillis = -1L;
            this.reconnectStarted = false;
        }

        if (client.currentScreen instanceof DisconnectedScreen
                && this.hasSavedServer()
                && !this.reconnectStarted) {
            if (this.disconnectedAtMillis < 0L) {
                this.disconnectedAtMillis = System.currentTimeMillis();
            }

            long i = (long) (this.delaySetting.getFloat() * 1000.0F);
            if (System.currentTimeMillis() - this.disconnectedAtMillis >= i) {
                this.reconnectStarted = true;
                ConnectScreen.connect(
                        client.currentScreen,
                        client,
                        this.serverAddress,
                        this.serverInfo,
                        false,
                        null);
            }
        }
    }

    @Override
    protected void onDisable() {

        this.disconnectedAtMillis = (-1L);
        this.reconnectStarted = false;
        this.previousScreen = null;
    }

    public boolean hasSavedServer() {
        return this.serverAddress != null && this.serverInfo != null;
    }

    public void rememberServer(ServerAddress serveraddress, ServerInfo serverinfo) {
        if (serveraddress != null && serverinfo != null) {
            this.serverAddress = serveraddress;
            this.serverInfo = serverinfo;
        }
    }
}
