package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class EaseInOutQuadAnimation extends TimedAnimation {
    public EaseInOutQuadAnimation(
            int durationMillisValue, double endValueValue, AnimationDirection animationDirection2) {
        super(durationMillisValue, endValueValue, animationDirection2);
    }

    @Override
    protected double evaluate(double d0) {
        double d1 = d0 / (double) this.durationMillis;
        return 1.0 + 2.70158 * Math.pow(d1 - 1.0, 3.0) + 1.70158 * Math.pow(d1 - 1.0, 2.0);
    }

    public EaseInOutQuadAnimation(int durationMillisValue, double endValueValue) {
        super(durationMillisValue, endValueValue);
    }
}
