package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EntityPose;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;

@Environment(EnvType.CLIENT)
public final class RaycastUtils implements MinecraftAccess {

    public static List<Vec3d> sampleHitbox(Box box) {
        ArrayList arraylist = new ArrayList();
        double d0 = 0.01F;
        byte b0 = 17;
        byte b1 = 5;
        byte b2 = 24;
        byte b3 = 6;
        box = box.offset(-d0, -d0, -d0);
        double[] adouble =
                new double[] {
                    box.maxX - box.minX, box.maxY - box.minY, (box.maxY - box.minY) / 1.05
                };
        double[] values =
                new double[] {box.minX + adouble[0] / 2.0, box.minY, box.minZ + adouble[0] / 2.0};
        double[] valuesValue = new double[] {box.minX, box.minY, box.minZ};
        double[] values2 = new double[] {box.maxX, box.maxY, box.maxZ};
        float f =
                (float)
                                Math.sqrt(
                                        adouble[0] * adouble[0]
                                                + adouble[0] * adouble[0]
                                                + adouble[0] * adouble[0])
                        / 2.0F;
        ClientPlayerEntity clientplayerentity = client.player;
        if (clientplayerentity == null) {
            return null;
        } else {
            float f1 =
                    (float)
                            ((1.0
                                            - Math.min(
                                                    clientplayerentity
                                                                    .getEntityPos()
                                                                    .distanceTo(
                                                                            new Vec3d(
                                                                                    values[0],
                                                                                    values[1],
                                                                                    values[2]))
                                                            / 5.0,
                                                    1.0))
                                    * Math.min(
                                            clientplayerentity
                                                            .getEntityPos()
                                                            .distanceTo(
                                                                    new Vec3d(
                                                                            values[0],
                                                                            clientplayerentity
                                                                                    .getY(),
                                                                            values[2]))
                                                    / 0.6F,
                                            1.0));
            int i = lerpInt(b1, b0, f1);
            int j = lerpInt(b3, b2, f1);
            float f2 = 0.0F;
            int[] aint = IntStream.range(0, i).toArray();
            int length = aint.length;

            for (int l = 0; l < length; l++) {
                Integer integer = aint[l];
                boolean flag;
                double d1;
                int[] values3;
                int i1;
                int j1;
                if (integer != 0 && integer != i - 1) {
                    flag = false;
                    d1 =
                            lerp(
                                    valuesValue[0],
                                    values2[0],
                                    (double) ((float) integer.intValue() / (float) (i - 1)));
                    values3 = IntStream.range(0, i).toArray();
                    i1 = values3.length;
                    j1 = 0;
                } else {
                    flag = true;
                    d1 =
                            lerp(
                                    valuesValue[0],
                                    values2[0],
                                    (double) ((float) integer.intValue() / (float) (i - 1)));
                    values3 = IntStream.range(0, i).toArray();
                    i1 = values3.length;
                    j1 = 0;
                }

                for (; j1 < i1; j1++) {
                    Integer value = values3[j1];
                    boolean flag1;
                    flag1 = !(value != 0 && value != i - 1);

                    double d2 =
                            lerp(
                                    valuesValue[2],
                                    values2[2],
                                    (double) ((float) value.intValue() / (float) (i - 1)));
                    int[] values4 = IntStream.range(0, j).toArray();
                    int lengthValue = values4.length;

                    for (int l1 = 0; l1 < lengthValue; l1++) {
                        Integer valueValue = values4[l1];
                        boolean flag2;
                        Vec3d vec3d;
                        if (valueValue != 0 && valueValue != j - 1) {
                            flag2 = false;
                            double d4 =
                                    lerp(
                                            valuesValue[1],
                                            values2[1],
                                            (double)
                                                    ((float) valueValue.intValue()
                                                            / (float) (j - 1)));
                            vec3d = new Vec3d(d1, d4, d2);
                        } else {
                            flag2 = true;
                            double d3 =
                                    lerp(
                                            valuesValue[1],
                                            values2[1],
                                            (double)
                                                    ((float) valueValue.intValue()
                                                            / (float) (j - 1)));
                            vec3d = new Vec3d(d1, d3, d2);
                        }

                        if ((flag || flag1 || flag2)
                                && !(clientplayerentity
                                                .getEntityPos()
                                                .distanceTo(
                                                        vec3d.add(
                                                                0.0,
                                                                (double)
                                                                        (-clientplayerentity
                                                                                .getEyeHeight(
                                                                                        EntityPose
                                                                                                .STANDING)),
                                                                0.0))
                                        < (double) f)
                                && isRegionVisible(clientplayerentity, vec3d, f2)
                                && !arraylist.add(vec3d)) {
                            break;
                        }
                    }
                }
            }

            return arraylist;
        }
    }

    public static HitResult raycast(
            Vec3d vec3d, Vec3d vec3d1, ShapeType shapetype, FluidHandling fluidhandling) {
        return client.world.raycast(
                new RaycastContext(vec3d, vec3d1, shapetype, fluidhandling, client.player));
    }

    public static Vec3d findAimPoint(Box box) {
        return findAimPoint(box, false);
    }

    private static boolean isPointVisible(
            ClientPlayerEntity clientplayerentity, double d0, double d1, double d2) {
        Vec3d vec3d = new Vec3d(d0, d1, d2);
        return client.world != null
                && raycast(
                                        clientplayerentity.getEyePos(),
                                        vec3d,
                                        ShapeType.COLLIDER,
                                        FluidHandling.NONE)
                                .getType()
                        != Type.BLOCK;
    }

    private static boolean isRegionVisible(
            ClientPlayerEntity clientplayerentity, Vec3d vec3d, float f) {
        return f == 0.0F
                ? isPointVisible(clientplayerentity, vec3d.x, vec3d.y, vec3d.z)
                : isPointVisible(clientplayerentity, vec3d.x, vec3d.y, vec3d.z)
                        && isPointVisible(
                                clientplayerentity, vec3d.x, vec3d.y + (double) f, vec3d.z)
                        && isPointVisible(
                                clientplayerentity, vec3d.x, vec3d.y - (double) f, vec3d.z)
                        && isPointVisible(
                                clientplayerentity, vec3d.x + (double) f, vec3d.y, vec3d.z)
                        && isPointVisible(
                                clientplayerentity, vec3d.x - (double) f, vec3d.y, vec3d.z)
                        && isPointVisible(
                                clientplayerentity, vec3d.x, vec3d.y, vec3d.z + (double) f)
                        && isPointVisible(
                                clientplayerentity, vec3d.x, vec3d.y, vec3d.z - (double) f);
    }

    private static double horizontalDistance(
            ClientPlayerEntity clientplayerentity, double d0, double d1) {
        double d2 = clientplayerentity.getX() - d0;
        double d3 = clientplayerentity.getZ() - d1;
        return (double) MathHelper.sqrt((float) (d2 * d2 + d3 * d3));
    }

    private RaycastUtils() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static double clamp(double d0, double d1, double d2) {
        return Math.min(d2, Math.max(d0, d1));
    }

    private static boolean isPointVisible(ClientPlayerEntity clientplayerentity, Vec3d vec3d) {
        Vec3d vec3d1 =
                new Vec3d(
                        clientplayerentity.getX(),
                        clientplayerentity.getEyeY(),
                        clientplayerentity.getZ());
        return client.world != null
                && raycast(vec3d1, vec3d, ShapeType.COLLIDER, FluidHandling.NONE).getType()
                        != Type.BLOCK;
    }

    private static double distance(Vec3d vec3d, Vec3d vec3d1) {
        double d0;
        double d1;
        double d2;
        return Math.sqrt(
                (d0 = vec3d.x - vec3d1.x) * d0
                        + (d1 = vec3d.y - vec3d1.y) * d1
                        + (d2 = vec3d.z - vec3d1.z) * d2);
    }

    public static Vec3d findAimPoint(Box box, boolean flag) {
        if (box == null) {
            return client.player.getEyePos();
        } else {
            double[] adouble =
                    new double[] {
                        box.maxX - box.minX, box.maxY - box.minY, (box.maxY - box.minY) / 1.1F
                    };
            double[] values =
                    new double[] {
                        box.minX + adouble[0] / 2.0, box.minY, box.minZ + adouble[0] / 2.0
                    };
            double[] valuesValue =
                    new double[] {
                        client.player.getY() - values[1],
                        horizontalDistance(client.player, values[0], values[2])
                    };
            double d0 =
                    clamp(
                            Easings.OUT_BACK_ALT.ease(
                                    (valuesValue[1] - adouble[0] / 2.0) / (5.0 + adouble[0] / 2.0)),
                            0.1,
                            0.95);
            double d1 = clamp(d0 * d0, 0.0, 1.0);
            double d2 =
                    clamp(
                            adouble[2] / 2.0 * d1
                                    + adouble[2] / 2.0 * clamp(valuesValue[0] + d1, 0.0, 1.0),
                            0.0,
                            adouble[2]);
            Vec3d vec3d = new Vec3d(values[0], values[1] + d2, values[2]);
            if (!flag && !isPointVisible(client.player, vec3d)) {
                vec3d = vec3d.add(0.0, -d2 / 2.0, 0.0);
            }

            if (!(adouble[1] <= 1.0) && (flag || !isPointVisible(client.player, vec3d))) {
                List<Vec3d> list = sampleHitbox(box);
                float f = 1.0F - (float) Math.max(Math.min((valuesValue[1] - 2.0) / 3.0, 1.0), 0.0);
                Vec3d vec3d1 =
                        new Vec3d(
                                client.player.getX(),
                                client.player.getY() + 0.6F + lerp(d2, d2 / 2.5, (double) f),
                                client.player.getZ());
                if (list != null && list.size() > 1) {
                    list.sort(Comparator.comparing(vec3d1x -> distance(vec3d1, vec3d1x)));
                }

                return list != null && !list.isEmpty() ? (Vec3d) list.getFirst() : vec3d;
            } else {
                return vec3d;
            }
        }
    }

    public static int lerpInt(int i, int j, float f) {
        return i + (int) (f * (float) (j - i));
    }

    private static Double squaredEyeDistance(Vec3d vec3d) {
        return vec3d.squaredDistanceTo(client.player.getEyePos());
    }

    public static double lerp(double d0, double d1, double d2) {
        return d0 + d2 * (d1 - d0);
    }
}
