package dev.gooba.client;

import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FieldOrder({"match", "join", "spectate"})
@Environment(EnvType.CLIENT)
public class DiscordSecrets extends Structure {
    public byte[] join;

    public byte[] match = new byte[128];
    public byte[] spectate;

    public DiscordSecrets() {
        this.join = new byte[128];
        this.spectate = new byte[128];
    }
}
