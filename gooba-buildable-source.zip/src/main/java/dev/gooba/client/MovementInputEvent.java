package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.PlayerInput;

@Environment(EnvType.CLIENT)
public class MovementInputEvent extends CancellableEvent {
    private PlayerInput input;
    private float strafe;
    private float forward;

    public MovementInputEvent(PlayerInput playerinput, float forwardValue, float strafeValue) {
        this.input = playerinput;
        this.forward = forwardValue;
        this.strafe = strafeValue;
    }

    public void setStrafe(float strafeValue) {
        this.strafe = strafeValue;
    }

    public float getStrafe() {
        return this.strafe;
    }

    public void setDirectionalLow(boolean flag, boolean flag1, boolean flag2, boolean flag3) {
        this.input =
                new PlayerInput(
                        flag,
                        flag1,
                        flag2,
                        flag3,
                        this.input.jump(),
                        this.input.sneak(),
                        this.input.sprint());
    }

    public void setForward(float forwardValue) {
        this.forward = forwardValue;
    }

    public PlayerInput getInput() {
        return this.input;
    }

    public float getForward() {
        return this.forward;
    }

    public void setInput(PlayerInput playerinput) {
        this.input = playerinput;
    }
}
