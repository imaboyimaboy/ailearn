package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Fog Blur",
        category = ModuleCategory.RENDER,
        desc = "Blurs and desaturates distant parts of the world")
@Environment(EnvType.CLIENT)
public final class FogBlurModule extends Module {
    private final SliderSetting saturationSetting;
    private final BooleanSetting useThemeColorSetting;
    private final SliderSetting distanceSetting =
            new SliderSetting(this, "Distance", 0.05F, 0.001F, 0.5F, 0.001F);

    public FogBlurModule() {
        this.saturationSetting = new SliderSetting(this, "Saturation", 0.5F, 0.05F, 0.95F, 0.05F);
        this.useThemeColorSetting = new BooleanSetting(this, "Use Theme Color", false);
    }

    @EventHandler(priority = 500)
    public void onRender3D(Render3DEvent render3DEvent) {
        if (this.isEnabled()) {
            if (client.player != null && client.world != null) {
                int i = ColorUtils.hudAccent();
                int j = ColorUtils.hudAccent();
                int k = ColorUtils.hudAccent();
                int l = ColorUtils.hudAccent();
                FogBlurRenderer.render(
                        this.distanceSetting.getFloat(),
                        Math.max(0.0F, Math.min(1.0F, 1.0F - this.saturationSetting.getFloat())),
                        this.useThemeColorSetting.isOn(),
                        i,
                        j,
                        k,
                        l);
            }
        }
    }
}
