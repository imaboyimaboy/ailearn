package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.PlayerLikeEntity;

@ModuleInfo(
        name = "Custom Models",
        category = ModuleCategory.RENDER,
        desc = "Replaces player models with custom animated models")
@Environment(EnvType.CLIENT)
public class CustomModelsModule extends Module {
    public final BooleanSetting friendsSetting;
    public final ModeSetting modelSetting =
            new ModeSetting(
                    this,
                    "Model",
                    new String[] {"Crazy Rabbit", "Freddy Bear", "Tung Tung Sahur"}) {
                @Override
                public ModeSetting setValue(String text) {
                    return super.setValue(this.modes.contains(text) ? text : "Crazy Rabbit");
                }
            };

    public CustomModelsModule() {
        this.friendsSetting = new BooleanSetting(this, "Friends", true);
    }

    public boolean shouldUseCustomModel(PlayerLikeEntity playerlikeentity) {
        if (!this.isEnabled() || playerlikeentity == null || playerlikeentity.isSpectator()) {
            return false;
        } else if (FakeLagModule.isGhost(playerlikeentity)) {
            return true;
        } else {
            return client.player != null && playerlikeentity == client.player
                    ? true
                    : this.friendsSetting.isOn()
                            && Gooba.getInstance()
                                    .getFriendManager()
                                    .isFriend(playerlikeentity.getName().getString());
        }
    }

    public String selectedModel() {
        return this.modelSetting.getSelectedMode();
    }
}
