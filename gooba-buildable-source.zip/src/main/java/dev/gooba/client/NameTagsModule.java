package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.ReadableScoreboardScore;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.text.MutableText;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@ModuleInfo(
        name = "Name Tags",
        category = ModuleCategory.RENDER,
        desc = "Displays fixed-size entity names, health, armor, and held items")
@Environment(EnvType.CLIENT)
public class NameTagsModule extends Module {
    public final SliderSetting sizeSetting;
    public final BooleanSetting heldItemsSetting;
    public final SliderSetting armorSizeSetting;
    private final List<NameTagsModule.SpawnerTag> spawnerTags;
    public final BooleanSetting ignoreUnarmoredPlayersSetting;
    public final BooleanSetting spawnerSetting;
    public final SliderSetting offHandSizeSetting;
    public final BooleanSetting mobsSetting;
    private int scanTicks;
    public final BooleanSetting playersSetting = new BooleanSetting(this, "Players", true);
    public final SliderSetting mainHandSizeSetting;
    public final BooleanSetting droppedItemsSetting;
    private static final EquipmentSlot[] EQUIPMENT_ORDER =
            new EquipmentSlot[] {
                EquipmentSlot.HEAD,
                EquipmentSlot.CHEST,
                EquipmentSlot.LEGS,
                EquipmentSlot.FEET,
                EquipmentSlot.OFFHAND,
                EquipmentSlot.MAINHAND
            };

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.world != null && client.player != null) {
            if (this.spawnerSetting.isOn()) {
                if (++this.scanTicks >= 10) {
                    this.scanTicks = 0;
                    this.scanSpawners();
                }
            } else {
                this.spawnerTags.clear();
                this.scanTicks = 0;
            }
        }
    }

    private String displayName(Entity entity) {
        if (entity instanceof PlayerEntity playerentity) {
            String string = playerentity.getName().getString();
            NameProtectModule nameProtectModule =
                    Gooba.getInstance().getModuleRegistry().findModule(NameProtectModule.class);
            if (nameProtectModule != null && nameProtectModule.isEnabled()) {
                boolean isFriend = Gooba.getInstance().getFriendManager().isFriend(string);
                return nameProtectModule.hideFriendNamesSetting.isOn() && isFriend
                        ? "Friend"
                        : string.replace(
                                client.player.getName().getString(),
                                nameProtectModule.protectedName());
            } else {
                return string;
            }
        } else if (entity instanceof ItemEntity itementity) {
            String stringValue = itementity.getStack().getName().getString();
            String text;
            if (itementity.getStack().getCount() > 1) {
                int count = itementity.getStack().getCount();
                text = stringValue + " x" + count;
            } else {
                text = stringValue;
            }

            return text;
        } else {
            return entity.getType().getName().getString();
        }
    }

    private NameTagsModule.TagData createTag(Entity entity, float f, float f1) {
        String string = this.displayName(entity);
        TextRenderEvent textRenderEvent = new TextRenderEvent(string);
        textRenderEvent.hook();
        string = textRenderEvent.getText();
        if (string != null && !string.isBlank()) {
            float f2 = this.sizeSetting.getFloat();
            float size = 8.2F * f2;
            float f4 = 4.0F * f2;
            float f5 = 2.0F * f2;
            float f6 = Fonts.INTER_SEMIBOLD.getLineHeight(size) + f5 * 2.0F;
            float f7 = 3.0F * f2;
            String stringValue =
                    entity instanceof LivingEntity livingentity
                            ? String.format(Locale.ROOT, "%.1f", this.displayedHealth(livingentity))
                            : null;
            float f15 = Fonts.INTER_SEMIBOLD.measureWidth(string, size);
            float f8 =
                    stringValue == null
                            ? 0.0F
                            : Fonts.INTER_SEMIBOLD.measureWidth(stringValue, size);
            float f9 = f15 + (stringValue == null ? 0.0F : f7 + f8);
            float f10 = f9 + f4 * 2.0F;
            float f11 = f - f10 * 0.5F;
            float f12 = f1 - f6;
            List listx = this.collectEquipment(entity);
            float f13 = 8.0F * f2;
            float f14 = 2.0F * f2;
            return new NameTagsModule.TagData(
                    string, stringValue, listx, f, f11, f12, f10, f6, f7, size, f5, f13, f14);
        } else {
            return null;
        }
    }

    @EventHandler(priority = 500)
    public void onRender2D(Render2DEvent render2DEvent) {
        if (client.world != null && client.player != null && client.gameRenderer != null) {
            Vec3d vec3d = client.gameRenderer.getCamera().getCameraPos();
            double d0 = 36864.0;
            ArrayList arraylist = new ArrayList();

            for (Entity entity : client.world.getEntities()) {
                if (this.shouldRender(entity, d0)) {
                    arraylist.add(entity);
                }
            }

            arraylist.sort(
                    Comparator.<Entity>comparingDouble(
                                    entity3 ->
                                            vec3d.squaredDistanceTo(
                                                    entity3.getBoundingBox().getCenter()))
                            .reversed());

            for (Entity entityValue : (Iterable<Entity>) (Iterable) arraylist) {
                Vec3d vec3d1 =
                        entityValue
                                .getLerpedPos(render2DEvent.getPartialTicks())
                                .add(0.0, (double) entityValue.getHeight() + 0.25, 0.0);
                Vec3d vec3d2 = ProjectionUtils.worldToScreen(vec3d1);
                if (!(vec3d2.z <= 0.0) && !(vec3d2.z >= 1.0)) {
                    NameTagsModule.TagData tagData =
                            this.createTag(entityValue, (float) vec3d2.x, (float) vec3d2.y);
                    if (tagData != null) {
                        this.drawTag(render2DEvent.getDrawContext(), tagData);
                        Gooba.getInstance().getHudManager().flush();
                    }
                }
            }

            if (this.spawnerSetting.isOn()) {
                for (NameTagsModule.SpawnerTag spawnerTag : this.spawnerTags) {
                    this.drawSpawnerTag(spawnerTag);
                }
            }
        }
    }

    private List<NameTagsModule.EquipmentItem> collectEquipment(Entity entity) {
        if (!(entity instanceof LivingEntity livingentity)) {
            return List.of();
        } else {
            ArrayList arraylist = new ArrayList();

            for (EquipmentSlot equipmentslot : EQUIPMENT_ORDER) {
                if (this.heldItemsSetting.isOn()
                        || equipmentslot != EquipmentSlot.MAINHAND
                                && equipmentslot != EquipmentSlot.OFFHAND) {
                    ItemStack itemstack = livingentity.getEquippedStack(equipmentslot);
                    if (!itemstack.isEmpty()) {
                        arraylist.add(new NameTagsModule.EquipmentItem(itemstack, equipmentslot));
                    }
                }
            }

            return arraylist;
        }
    }

    private boolean shouldRender(Entity entity, double d0) {
        if (FakeLagModule.isGhost(entity)
                || entity.isRemoved()
                || !entity.isAlive()
                || entity.isSpectator()
                || client.player.squaredDistanceTo(entity) > d0) {
            return false;
        } else if (entity == client.player && client.options.getPerspective().isFirstPerson()) {
            return false;
        } else if (entity instanceof PlayerEntity playerentity) {
            return this.playersSetting.isOn()
                    && (playerentity.getCustomName() == null
                            || !playerentity.getCustomName().getString().startsWith("Ghost_"))
                    && (!this.ignoreUnarmoredPlayersSetting.isOn() || isArmored(playerentity));
        } else {
            return entity instanceof LivingEntity
                    ? this.mobsSetting.isOn()
                    : entity instanceof ItemEntity && this.droppedItemsSetting.isOn();
        }
    }

    private void scanSpawners() {
        this.spawnerTags.clear();
        if (client.world != null && client.player != null) {
            ChunkPos chunkpos = client.player.getChunkPos();
            int i = Math.min(client.options.getClampedViewDistance(), 6);

            for (int j = chunkpos.x - i; j <= chunkpos.x + i; j++) {
                for (int k = chunkpos.z - i; k <= chunkpos.z + i; k++) {
                    WorldChunk worldchunk =
                            client.world.getChunkManager().getChunk(j, k, ChunkStatus.FULL, false);
                    if (worldchunk != null) {
                        for (BlockEntity blockentity : worldchunk.getBlockEntities().values()) {
                            if (blockentity instanceof MobSpawnerBlockEntity) {
                                MobSpawnerBlockEntity mobspawnerblockentity =
                                        (MobSpawnerBlockEntity) blockentity;
                                BlockPos blockpos = blockentity.getPos().toImmutable();
                                Entity entity =
                                        mobspawnerblockentity
                                                .getLogic()
                                                .getRenderedEntity(client.world, blockpos);
                                String text;
                                if (entity == null) {
                                    text = "Spawner";
                                } else {
                                    String string = entity.getType().getName().getString();
                                    text = string + " Spawner";
                                }

                                String textValue = text;
                                this.spawnerTags.add(
                                        new NameTagsModule.SpawnerTag(blockpos, textValue));
                            }
                        }
                    }
                }
            }
        }
    }

    public static NameTagsModule getInstance() {
        return (NameTagsModule) ModuleLookup.getModule(NameTagsModule.class);
    }

    public static boolean isArmored(PlayerEntity playerentity) {
        for (EquipmentSlot equipmentslot : EQUIPMENT_ORDER) {
            if (equipmentslot != EquipmentSlot.MAINHAND
                    && equipmentslot != EquipmentSlot.OFFHAND
                    && !playerentity.getEquippedStack(equipmentslot).isEmpty()) {
                return true;
            }
        }

        return false;
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.spawnerTags.clear();
        this.scanTicks = 0;
    }

    private float equipmentSize(float f, EquipmentSlot equipmentslot) {
        if (equipmentslot == EquipmentSlot.MAINHAND) {
            return f * this.mainHandSizeSetting.getFloat();
        } else {
            return equipmentslot == EquipmentSlot.OFFHAND
                    ? f * this.offHandSizeSetting.getFloat()
                    : f * this.armorSizeSetting.getFloat();
        }
    }

    private void drawTag(DrawContext drawcontext, NameTagsModule.TagData tagData) {
        if (!tagData.equipment().isEmpty()) {
            float f = -tagData.itemGap();
            float f1 = 0.0F;

            for (NameTagsModule.EquipmentItem equipmentItem : tagData.equipment()) {
                float f2 = this.equipmentSize(tagData.itemSize(), equipmentItem.slot());
                f += f2 + tagData.itemGap();
                f1 = Math.max(f1, f2);
            }

            float f6 = tagData.centerX() - f * 0.5F;
            float f8 = tagData.y() - f1 * 0.5F - 2.0F * this.sizeSetting.getFloat();

            for (NameTagsModule.EquipmentItem equipmentItemValue : tagData.equipment()) {
                float f3 = this.equipmentSize(tagData.itemSize(), equipmentItemValue.slot());
                ItemIconRenderer.drawCentered(
                        drawcontext,
                        equipmentItemValue.stack(),
                        f6 + f3 * 0.5F,
                        f8,
                        f3 / 16.0F,
                        1.0F);
                f6 += f3 + tagData.itemGap();
            }
        }

        HUDModule.getInstance()
                .drawBackground(
                        tagData.x(),
                        tagData.y(),
                        tagData.width(),
                        tagData.height(),
                        tagData.height() * 0.5F,
                        1.0F);
        float f4 = Fonts.INTER_SEMIBOLD.measureWidth(tagData.name(), tagData.fontSize());
        float f5 =
                tagData.health() == null
                        ? 0.0F
                        : Fonts.INTER_SEMIBOLD.measureWidth(tagData.health(), tagData.fontSize());
        float f7 = f4 + (tagData.health() == null ? 0.0F : tagData.gap() + f5);
        float f9 = tagData.centerX() - f7 * 0.5F;
        float f10 = tagData.y() + tagData.verticalPadding();
        Font font = Fonts.INTER_SEMIBOLD;
        String string = tagData.name();
        float size = tagData.fontSize();
        ColorUtils.opaqueGrayscale(255);
        font.drawText(string, f9, f10, size);
        if (tagData.health() != null) {
            font = Fonts.INTER_SEMIBOLD;
            string = tagData.health();
            float f11 = f9 + f4 + tagData.gap();
            size = tagData.fontSize();
            ColorUtils.rgb(80, 255, 110);
            font.drawText(string, f11, f10, size);
        }
    }

    public NameTagsModule() {
        this.ignoreUnarmoredPlayersSetting =
                new BooleanSetting(this, "Ignore Unarmored Players", false)
                        .visibleWhen(this.playersSetting::isOn);
        this.heldItemsSetting = new BooleanSetting(this, "Held Items", true);
        this.mobsSetting = new BooleanSetting(this, "Mobs", true);
        this.droppedItemsSetting = new BooleanSetting(this, "Dropped Items", true);
        this.spawnerSetting = new BooleanSetting(this, "Spawner", false);
        this.sizeSetting = new SliderSetting(this, "Size", 1.0F, 0.5F, 1.5F, 0.05F);
        this.armorSizeSetting = new SliderSetting(this, "Armor Size", 1.0F, 0.5F, 2.0F, 0.05F);
        this.mainHandSizeSetting =
                new SliderSetting(this, "Main Hand Size", 1.0F, 0.5F, 2.0F, 0.05F)
                        .visibleWhen(this.heldItemsSetting::isOn);
        this.offHandSizeSetting =
                new SliderSetting(this, "Off Hand Size", 1.0F, 0.5F, 2.0F, 0.05F)
                        .visibleWhen(this.heldItemsSetting::isOn);
        this.spawnerTags = new ArrayList<>();
    }

    private float displayedHealth(LivingEntity livingentity) {
        float f = livingentity.getHealth() + livingentity.getAbsorptionAmount();
        if (livingentity instanceof PlayerEntity playerentity && client.world != null) {
            ScoreboardObjective scoreboardobjective =
                    client.world
                            .getScoreboard()
                            .getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME);
            if (scoreboardobjective != null) {
                MutableText mutabletext =
                        ReadableScoreboardScore.getFormattedScore(
                                client.world
                                        .getScoreboard()
                                        .getScore(playerentity, scoreboardobjective),
                                scoreboardobjective.getNumberFormatOr(StyledNumberFormat.EMPTY));

                try {
                    f = Float.parseFloat(ColorUtils.stripFormatting(mutabletext.getString()));
                } catch (NumberFormatException numberformatexception) {
                }
            }
        }

        return f;
    }

    private void drawSpawnerTag(NameTagsModule.SpawnerTag spawnerTag) {
        Vec3d vec3d =
                ProjectionUtils.worldToScreen(spawnerTag.pos().toCenterPos().add(0.0, 0.75, 0.0));
        if (!(vec3d.z <= 0.0) && !(vec3d.z >= 1.0)) {
            float f = this.sizeSetting.getFloat();
            float size = 7.0F * f;
            float height = 15.0F * f;
            float f3 = 5.0F * f;
            float width = Fonts.INTER_SEMIBOLD.measureWidth(spawnerTag.name(), size) + f3 * 2.0F;
            float innerX = (float) vec3d.x - width * 0.5F;
            float innerY = (float) vec3d.y - height;
            HUDModule.getInstance()
                    .drawBackground(innerX, innerY, width, height, height * 0.5F, 1.0F);
            Font font = Fonts.INTER_SEMIBOLD;
            String string = spawnerTag.name();
            float f7 = innerX + f3;
            float f8 = Fonts.INTER_SEMIBOLD.centerTextY(spawnerTag.name(), innerY, height, size);
            ColorUtils.opaqueGrayscale(255);
            font.drawText(string, f7, f8, size);
        }
    }

    @Environment(EnvType.CLIENT)
    private static record EquipmentItem(ItemStack stack, EquipmentSlot slot) {}

    @Environment(EnvType.CLIENT)
    private static record SpawnerTag(BlockPos pos, String name) {}

    @Environment(EnvType.CLIENT)
    private static record TagData(
            String name,
            String health,
            List<NameTagsModule.EquipmentItem> equipment,
            float centerX,
            float x,
            float y,
            float width,
            float height,
            float gap,
            float fontSize,
            float verticalPadding,
            float itemSize,
            float itemGap) {}
}
