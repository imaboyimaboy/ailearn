package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.WorldChunk;

import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

@ModuleInfo(
        name = "Light Debug",
        category = ModuleCategory.DONUT,
        desc = "Visualizes block light levels underground.")
@Environment(EnvType.CLIENT)
public final class LightDebugModule extends Module {
    public final SliderSetting maxYSetting =
            new SliderSetting(this, "Max Y", -50.0F, -64.0F, 16.0F, 1.0F);
    private final AtomicBoolean scanning;
    public final SliderSetting alphaSetting;
    private int scanTicks;
    private ExecutorService scanExecutor;
    public final SliderSetting chunkRadiusSetting =
            new SliderSetting(this, "Chunk Radius", 8.0F, 1.0F, 12.0F, 1.0F);
    private ChunkPos lastPlayerChunk;
    private final ConcurrentHashMap<Long, Integer> lightLevels;

    private void scanLightLevels() {
        if (client.world != null && client.player != null) {
            ChunkPos chunkpos = client.player.getChunkPos();
            int i = MathHelper.clamp(this.chunkRadiusSetting.getFloat().intValue(), 1, 12);
            int j = MathHelper.clamp(this.maxYSetting.getFloat().intValue(), -64, 16);
            ConcurrentHashMap concurrenthashmap = new ConcurrentHashMap();
            Mutable mutable = new Mutable();

            for (int k = chunkpos.x - i; k <= chunkpos.x + i; k++) {
                for (int l = chunkpos.z - i; l <= chunkpos.z + i; l++) {
                    if (client.world != null && client.world.isChunkLoaded(k, l)) {
                        WorldChunk worldchunk =
                                client.world.getChunkManager().getWorldChunk(k, l, false);
                        if (worldchunk != null) {
                            int i1 = k << 4;
                            int j1 = l << 4;

                            for (int k1 = i1; k1 < i1 + 16; k1++) {
                                for (int l1 = j1; l1 < j1 + 16; l1++) {
                                    for (int i2 = -64; i2 <= j; i2++) {
                                        mutable.set(k1, i2, l1);
                                        int lightLevel =
                                                client.world.getLightLevel(
                                                        LightType.BLOCK, mutable);
                                        if (lightLevel > 0) {
                                            int lightLevelValue =
                                                    client.world.getLightLevel(
                                                            LightType.SKY, mutable);
                                            if (lightLevel > lightLevelValue) {
                                                concurrenthashmap.put(
                                                        BlockPos.asLong(k1, i2, l1), lightLevel);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            this.lightLevels.clear();
            this.lightLevels.putAll(concurrenthashmap);
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.world != null && client.player != null && !this.lightLevels.isEmpty()) {
            int i = MathHelper.clamp(this.alphaSetting.getFloat().intValue(), 0, 255);
            if (i > 0) {
                WorldEspRenderer.clear();

                for (Entry entry : this.lightLevels.entrySet()) {
                    long key = (Long) entry.getKey();
                    int value = (Integer) entry.getValue();
                    int l = BlockPos.unpackLongX(key);
                    int i1 = BlockPos.unpackLongY(key);
                    int j1 = BlockPos.unpackLongZ(key);
                    int k1 = lightColor(value, i);
                    WorldEspRenderer.enqueueBox(
                            new Box(
                                    (double) l,
                                    (double) i1,
                                    (double) j1,
                                    (double) l + 1.0,
                                    (double) i1 + 1.0,
                                    (double) j1 + 1.0),
                            k1,
                            false);
                }

                WorldEspRenderer.flush(render3DEvent.getMatrixStack());
            }
        }
    }

    public LightDebugModule() {
        this.alphaSetting = new SliderSetting(this, "Alpha", 160.0F, 0.0F, 255.0F, 1.0F);
        this.lightLevels = new ConcurrentHashMap<>();
        this.scanning = new AtomicBoolean(false);
        this.lastPlayerChunk = null;
        this.scanTicks = 0;
    }

    @Override
    protected void onDisable() {
        if (this.scanExecutor != null) {
            this.scanExecutor.shutdownNow();

            try {
                this.scanExecutor.awaitTermination(1L, TimeUnit.SECONDS);
            } catch (InterruptedException interruptedexception) {
            }

            this.scanExecutor = null;
        }

        this.lightLevels.clear();
        this.lastPlayerChunk = null;
    }

    private static int lightColor(int i, int j) {
        float f = MathHelper.clamp((float) i / 15.0F, 0.0F, 1.0F);
        int k = Math.round(MathHelper.lerp(f, 50.0F, 200.0F));
        int l = Math.round(MathHelper.lerp(f, 0.0F, 130.0F));
        int i11 = Math.round(MathHelper.lerp(f, 70.0F, 255.0F));
        return j << 24 | k << 16 | l << 8 | i11;
    }

    @Override
    protected void onEnable() {
        this.scanExecutor =
                Executors.newSingleThreadExecutor(
                        runnable -> {
                            Thread thread = new Thread(runnable, "Goobaa-LightDebug-Scanner");
                            thread.setDaemon(true);
                            return thread;
                        });
        this.lightLevels.clear();
        this.lastPlayerChunk = null;
        this.scanTicks = 0;
        this.queueScan();
    }

    private void queueScan() {
        if (this.scanExecutor != null
                && !this.scanExecutor.isShutdown()
                && client.world != null
                && client.player != null) {
            if (this.scanning.compareAndSet(false, true)) {
                this.scanExecutor.submit(
                        () -> {
                            try {
                                this.scanLightLevels();
                            } catch (Exception exception) {
                            } finally {
                                this.scanning.set(false);
                            }
                        });
            }
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.world != null && client.player != null) {
            this.scanTicks++;
            ChunkPos chunkpos = client.player.getChunkPos();
            boolean flag = !chunkpos.equals(this.lastPlayerChunk);
            if (flag || this.scanTicks % 16 == 0) {
                this.lastPlayerChunk = chunkpos;
                this.queueScan();
            }
        }
    }
}
