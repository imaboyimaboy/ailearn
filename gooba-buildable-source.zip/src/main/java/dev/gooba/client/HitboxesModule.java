package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@ModuleInfo(
        name = "Hitboxes",
        desc = "Expands player hitboxes to make targets easier to hit",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class HitboxesModule extends Module {

    public static int rotationTicks;
    public ModeSetting rotationModeSetting;
    public SliderSetting hitboxSizeSetting =
            new SliderSetting(this, "Hitbox Size", 0.3F, 0.1F, 1.0F, 0.1F);
    public ModeSetting modeSetting =
            new ModeSetting(this, "Mode", new String[] {"Normal", "Rotation"});
    public static LivingEntity target;

    public static HitboxesModule getInstance() {
        return (HitboxesModule) ModuleLookup.getModule(HitboxesModule.class);
    }

    @EventHandler
    public void onAttack(AttackEvent attackEvent) {
        if (this.rotationModeSetting.isSelected("On Hit")) {
            target = (LivingEntity) attackEvent.getTarget();
            rotationTicks = 0;
        }
    }

    public void updateRotation(LivingEntity livingentity) {
        if (this.rotationModeSetting.isSelected("Constant")) {
            Vec3d vec3d =
                    RaycastUtils.findAimPoint(livingentity.getBoundingBox(), false)
                            .subtract(client.player.getEyePos());
            float f = (float) Math.toDegrees(Math.atan2(-vec3d.x, vec3d.z));
            float f1 =
                    (float)
                            MathHelper.clamp(
                                    -Math.toDegrees(
                                            Math.atan2(vec3d.y, Math.hypot(vec3d.x, vec3d.z))),
                                    -90.0,
                                    90.0);
            float f2 = (float) Math.cos((double) System.currentTimeMillis() / 40.0);
            float f3 = (float) Math.sin((double) System.currentTimeMillis() / 70.0);
            float f4 = f2 * MathUtils.secureRandomFloat(1.0F, 2.0F);
            float f5 = f3 * MathUtils.secureRandomFloat(1.0F, 2.0F);
            Rotation rotation = new Rotation(f + f4, RotationStateManager.pitch + f5);
            TargetRingRenderer.aim(
                    rotation,
                    MathUtils.secureRandomFloat(12.0F, 25.0F),
                    MathUtils.secureRandomFloat(22.0F, 25.0F),
                    MathUtils.secureRandomFloat(24.0F, 26.0F),
                    MathUtils.secureRandomFloat(24.0F, 26.0F),
                    0,
                    15,
                    false);
        }

        if (this.rotationModeSetting.isSelected("On Hit")) {
            Vec3d vec3d1 =
                    livingentity
                            .getEntityPos()
                            .add(0.0, (double) (livingentity.getHeight() / 2.0F), 0.0)
                            .subtract(client.player.getEyePos())
                            .normalize();
            float f6 = (float) Math.toDegrees(Math.atan2(-vec3d1.x, vec3d1.z));
            float f7 =
                    (float)
                            MathHelper.clamp(
                                    -Math.toDegrees(
                                            Math.atan2(vec3d1.y, Math.hypot(vec3d1.x, vec3d1.z))),
                                    -90.0,
                                    90.0);
            float f8 = (float) Math.cos((double) System.currentTimeMillis() / 180.0);
            float f9 = (float) Math.sin((double) System.currentTimeMillis() / 180.0);
            float f10 = f8 * MathUtils.secureRandomFloat(2.0F, 4.0F);
            float f11 = f9 * MathUtils.secureRandomFloat(2.0F, 4.0F);
            Rotation rotationValue = new Rotation(f6 + f10, f7 + f11);
            TargetRingRenderer.aim(
                    rotationValue,
                    MathUtils.secureRandomFloat(152.0F, 255.0F),
                    MathUtils.secureRandomFloat(125.0F, 255.0F),
                    MathUtils.secureRandomFloat(152.0F, 255.0F),
                    MathUtils.secureRandomFloat(152.0F, 255.0F),
                    0,
                    15,
                    false);
        }
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (client.player != null
                && client.world != null
                && this.modeSetting.isSelected("Rotation")) {
            if (this.rotationModeSetting.isSelected("Constant")) {
                if (!(client.crosshairTarget instanceof EntityHitResult entityhitresult)) {
                    target = null;
                    return;
                }

                if (!(entityhitresult.getEntity() instanceof LivingEntity livingentity)
                        || client.player.distanceTo(livingentity) > 4.0F) {
                    target = null;
                    return;
                }

                if (livingentity instanceof PlayerEntity playerentity) {
                    target = playerentity;
                    this.updateRotation(playerentity);
                } else {
                    target = null;
                }
            }

            if (this.rotationModeSetting.isSelected("On Hit") && target != null) {
                if (!target.isAlive() || client.player.distanceTo(target) > 4.0F) {
                    target = null;
                    return;
                }

                this.updateRotation(target);
                rotationTicks++;
                if (rotationTicks >= 3) {
                    target = null;
                    rotationTicks = 0;
                }
            }
        }
    }

    public HitboxesModule() {
        this.rotationModeSetting =
                new ModeSetting(this, "Rotation Mode", new String[] {"Constant", "On Hit"})
                        .visibleWhen(() -> this.modeSetting.isSelected("Rotation"));
    }
}
