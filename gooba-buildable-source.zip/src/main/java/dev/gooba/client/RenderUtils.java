package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public final class RenderUtils implements MinecraftAccess {
    private RenderUtils() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    @Environment(EnvType.CLIENT)
    public static final class Blur {
        public static void drawRoundedBlur(
                float f,
                float f1,
                float width,
                float height,
                float strength,
                float radius,
                int color) {
            GlowRenderer.drawRoundedBlur(f, f1, width, height, strength, radius, color);
        }

        private Blur() {
            throw new UnsupportedOperationException(
                    "This is a utility class and cannot be instantiated");
        }

        public static void drawCornerBlur(
                float f,
                float f1,
                float f2,
                float f3,
                float f4,
                float f5,
                float f6,
                float f7,
                float f8,
                float f9) {
            GlowRenderer.drawBlurMask(f, f1, f2, f3, f4, f5, f6, f7, f8, f9);
        }
    }

    @Environment(EnvType.CLIENT)
    public static final class Images {
        public static void drawRoundedImage(
                Identifier identifier,
                float f,
                float f1,
                float f2,
                float f3,
                float f4,
                float f5,
                int i) {
            GlowRenderer.drawImageRegion(
                    identifier, f, f1, f2, f3, 0.0F, 0.0F, 1.0F, 1.0F, i, f4, f5);
        }

        public static void drawImage(
                Identifier identifier, float f, float f1, float f2, float f3, int i) {
            GlowRenderer.drawImage(identifier, f, f1, f2, f3, i);
        }

        public static void drawRoundedRegion(
                Identifier identifier,
                float f,
                float f1,
                float f2,
                float f3,
                float f4,
                float f5,
                float f6,
                float f7,
                int i,
                float f8) {
            GlowRenderer.drawRoundedRegion(identifier, f, f1, f2, f3, f4, f5, f6, f7, i, f8);
        }

        public static void drawOpaqueImage(
                Identifier identifier, float f, float f1, float f2, float f3, int i) {
            GlowRenderer.drawImageRegion(
                    identifier, f, f1, f2, f3, 0.0F, 0.0F, 1.0F, 1.0F, i, 1.0F, 0.0F);
        }

        public static void drawImageRegion(
                Identifier identifier,
                float f,
                float f1,
                float f2,
                float f3,
                float f4,
                float f5,
                float f6,
                float f7,
                int i,
                float f8,
                float f9) {
            GlowRenderer.drawImageRegion(identifier, f, f1, f2, f3, f4, f5, f6, f7, i, f8, f9);
        }

        private Images() {
            throw new UnsupportedOperationException(
                    "This is a utility class and cannot be instantiated");
        }
    }

    @Environment(EnvType.CLIENT)
    public static final class Render2D {
        public static void drawShadow(
                float innerX,
                float innerY,
                float width,
                float height,
                int color,
                float radius,
                float spread,
                float softness) {
            GlowRenderer.drawShadow(innerX, innerY, width, height, color, radius, spread, softness);
        }

        public static void drawRect(
                float innerX, float innerY, float width, float height, int color) {
            GlowRenderer.drawRect(innerX, innerY, width, height, color);
        }

        private Render2D() {
            throw new UnsupportedOperationException(
                    "This is a utility class and cannot be instantiated");
        }

        public static void drawShadowWithOpacity(
                float innerX,
                float innerY,
                float width,
                float height,
                int color,
                float radius,
                float spread,
                float softness,
                float opacity) {
            GlowRenderer.drawShadowWithOpacity(
                    innerX, innerY, width, height, color, radius, spread, softness, opacity);
        }

        public static void drawRoundedOutline(
                float f,
                float f1,
                float width,
                float height,
                float thickness,
                int color,
                float radius) {
            GlowRenderer.drawRoundedOutline(f, f1, width, height, thickness, color, radius);
        }

        public static void drawProgressCircle(
                DrawContext drawcontext,
                float centerX,
                float centerY,
                float radius,
                float thickness,
                float progress,
                int color,
                int startColor,
                int endColor) {
            progress = Math.max(0.0F, Math.min(1.0F, progress));
            if (!(radius <= 0.0F) && !(thickness <= 0.0F)) {
                HudManager hudManager2 = Gooba.getInstance().getHudManager();
                hudManager2.flush();
                hudManager2
                        .getCircleData()
                        .drawProgressArc(centerX, centerY, radius, thickness, 1.0F, color);
                if (progress > 0.0F) {
                    hudManager2
                            .getCircleData()
                            .drawProgressArc(
                                    centerX,
                                    centerY,
                                    radius,
                                    thickness,
                                    progress,
                                    ColorUtils.interpolate(startColor, endColor, 0.65F));
                }

                hudManager2.getCircleData().flush();
            }
        }

        public static void drawCornerGradient(
                float innerX,
                float innerY,
                float width,
                float height,
                int[] aint,
                float topLeft,
                float topRight,
                float bottomRight,
                float bottomLeft) {
            GlowRenderer.drawCornerGradient(
                    innerX,
                    innerY,
                    width,
                    height,
                    aint,
                    topLeft,
                    topRight,
                    bottomRight,
                    bottomLeft);
        }

        public static void drawRoundedRect(
                float innerX, float innerY, float width, float height, int color, float radius) {
            GlowRenderer.drawRoundedRect(innerX, innerY, width, height, color, radius);
        }

        public static void drawRoundedGradient(
                float innerX, float innerY, float width, float height, int[] aint, float radius) {
            GlowRenderer.drawRoundedGradient(innerX, innerY, width, height, aint, radius);
        }
    }

    @Environment(EnvType.CLIENT)
    public static final class Render3D {
        public static final Matrix4f positionMatrix = new Matrix4f();
        public static final Matrix4f modelViewMatrix = new Matrix4f();
        public static final Matrix4f projectionMatrix = new Matrix4f();

        private Render3D() {
            throw new UnsupportedOperationException(
                    "This is a utility class and cannot be instantiated");
        }
    }

    @Environment(EnvType.CLIENT)
    public static final class RenderPlayer3DMatrix {
        private RenderPlayer3DMatrix() {
            throw new UnsupportedOperationException(
                    "This is a utility class and cannot be instantiated");
        }
    }
}
