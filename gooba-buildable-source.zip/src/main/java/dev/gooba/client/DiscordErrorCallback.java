package dev.gooba.client;

import com.sun.jna.Callback;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface DiscordErrorCallback extends Callback {
    void apply(int i, String text);
}
