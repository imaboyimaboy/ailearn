package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.InputUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PiercingWeaponComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;

import org.lwjgl.glfw.GLFW;

@ModuleInfo(
        name = "SpearSwap",
        desc = "Swaps to a Lunge spear, jabs and returns to the previous hotbar slot",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class SpearSwapModule extends Module {
    private long switchAtMillis;
    public final KeybindSetting activationKeySetting;

    private static SpearSwapModule instance;
    private int previousSlot;
    public final SliderSetting switchDelaySetting;
    private int spearSlot;
    public final ModeSetting modeSetting =
            new ModeSetting(this, "Mode", new String[] {"Auto", "Bind"});

    public static boolean isActive() {
        return instance != null && instance.isEnabled() && instance.previousSlot != -1;
    }

    @EventHandler
    public void onPreClientTick(PreClientTickEvent preClientTickEvent) {
        if (client.player != null && client.world != null && client.interactionManager != null) {
            boolean flag;
            long i;
            label195:
            {
                if (client.currentScreen != null
                        || !client.player.isAlive()
                        || client.player.isSpectator()
                        || !this.modeSetting.isSelected("Auto") && !this.isActivationHeld()) {
                    flag = false;
                    i = System.currentTimeMillis();
                    if (this.previousSlot == -1) {
                        break label195;
                    }

                    if (flag && i < this.switchAtMillis && !AutoTotemModule.isSwapPending()) {
                        return;
                    }
                } else {
                    flag = true;
                    i = System.currentTimeMillis();
                    if (this.previousSlot == -1) {
                        break label195;
                    }

                    if (flag && i < this.switchAtMillis && !AutoTotemModule.isSwapPending()) {
                        return;
                    }
                }

                this.restoreSlot();
                return;
            }

            if (flag
                    && i >= this.switchAtMillis
                    && !AutoTotemModule.isSwapPending()
                    && !MaceSwapModule.isActive()
                    && !ShieldBreakerModule.isActive()
                    && !DoubleAnchorModule.isActive()
                    && !client.player.isUsingItem()
                    && !client.player.isTouchingWater()
                    && !client.player.isGliding()) {
                if (client.player.isCreative()
                        || client.player.getHungerManager().getFoodLevel() >= 6) {
                    int spearSlotValue =
                            EnchantmentInventoryUtils.findBestEnchantedSlot(
                                    itemStack -> itemStack.isIn(ItemTags.SPEARS),
                                    Enchantments.LUNGE);
                    if (spearSlotValue != -1) {
                        ItemStack itemstack = client.player.getInventory().getStack(spearSlotValue);
                        PiercingWeaponComponent piercingweaponcomponent =
                                itemstack.get(DataComponentTypes.PIERCING_WEAPON);
                        if (piercingweaponcomponent != null
                                && !client.player.isBelowMinimumAttackCharge(itemstack, 0)) {
                            this.previousSlot = client.player.getInventory().getSelectedSlot();
                            this.spearSlot = spearSlotValue;
                            EnchantmentInventoryUtils.selectHotbarSlot(spearSlotValue);
                            boolean flag1 = false;

                            try {
                                client.interactionManager.attackWithPiercingWeapon(
                                        piercingweaponcomponent);
                                client.player.swingHand(Hand.MAIN_HAND);
                                flag1 = true;
                            } finally {
                                this.switchAtMillis =
                                        i + (long) Math.round(this.switchDelaySetting.getFloat());
                                if (!flag1 || this.switchDelaySetting.getFloat() <= 0.0F) {
                                    this.restoreSlot();
                                }
                            }
                        }
                    }
                }
            }
        } else {
            this.reset();
        }
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.reset();
    }

    private void reset() {
        this.previousSlot = -1;
        this.spearSlot = -1;
        this.switchAtMillis = 0L;
    }

    private boolean isActivationHeld() {
        int cachedKeyCode = this.activationKeySetting.getCachedKeyCode();
        if (cachedKeyCode < 0) {
            return false;
        } else {
            return cachedKeyCode <= 7
                    ? GLFW.glfwGetMouseButton(client.getWindow().getHandle(), cachedKeyCode) == 1
                    : InputUtil.isKeyPressed(client.getWindow(), cachedKeyCode);
        }
    }

    @Override
    protected void onDisable() {
        this.restoreSlot();
        this.reset();
    }

    public SpearSwapModule() {
        this.activationKeySetting =
                new KeybindSetting(this, "Activation Key", 82)
                        .visibleWhen(() -> this.modeSetting.isSelected("Bind"));
        this.switchDelaySetting = new SliderSetting(this, "Switch Delay", 0.0F, 0.0F, 500.0F, 1.0F);
        this.previousSlot = -1;
        this.spearSlot = -1;
        instance = this;
    }

    private void restoreSlot() {
        if (client.player != null
                && client.player.isAlive()
                && client.player.getInventory().getSelectedSlot() == this.spearSlot) {
            EnchantmentInventoryUtils.selectHotbarSlot(this.previousSlot);
        }

        this.previousSlot = -1;
        this.spearSlot = -1;
        this.switchAtMillis =
                System.currentTimeMillis() + (long) Math.round(this.switchDelaySetting.getFloat());
    }
}
