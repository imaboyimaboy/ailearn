package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class EasingAnimation {
    private double targetValue;
    private float previousProgress;
    private float interpolatedProgress;
    private long lastSmoothUpdateNanos;
    private double startValue;
    private double currentValue;
    private double durationMillis;
    private EasingFunction easing = Easings.LINEAR;
    private float progress;
    private Runnable completionCallback;
    private long lastApproachNanos;
    private double previousValue;
    private long lastProgressUpdateMillis = System.currentTimeMillis();
    private long startedAtMillis;

    public EasingAnimation setTargetValue(double targetValueValue) {
        this.targetValue = targetValueValue;
        return this;
    }

    public float updateSmoothProgress(boolean forward, float speed) {
        long nowNanos = System.nanoTime();
        float f1 = Math.min(0.05F, (float) (nowNanos - this.lastSmoothUpdateNanos) / 1.0E9F);
        this.lastSmoothUpdateNanos = nowNanos;
        this.previousProgress = this.progress;
        float f2 = forward ? 1.0F : -1.0F;
        this.progress = Math.max(0.0F, Math.min(1.0F, this.progress + f2 * speed * 20.0F * f1));
        this.interpolatedProgress = this.progress * this.progress * (3.0F - 2.0F * this.progress);
        return this.interpolatedProgress;
    }

    public EasingAnimation animateTo(double targetValueValue, double d1) {
        return this.animateTo(targetValueValue, d1, Easings.LINEAR, false);
    }

    public double getTargetValue() {
        return this.targetValue;
    }

    public boolean isRunning() {
        return !this.isFinished();
    }

    public long getStartTime() {
        return this.startedAtMillis;
    }

    public double getValue() {
        return this.currentValue;
    }

    public float getFloatValue() {
        return (float) this.getValue();
    }

    public EasingAnimation resetProgress(float progressValue) {
        this.progress = progressValue;
        this.previousProgress = progressValue;
        this.interpolatedProgress = progressValue;
        this.lastProgressUpdateMillis = System.currentTimeMillis();
        this.lastSmoothUpdateNanos = System.nanoTime();
        return this;
    }

    public double getStartValue() {
        return this.startValue;
    }

    public float sampleThenAdvanceProgress(boolean forward, float speed, float tickDelta) {
        this.interpolatedProgress =
                this.previousProgress + (this.progress - this.previousProgress) * tickDelta;
        long nowMillis = System.currentTimeMillis();
        float f2 = (float) (nowMillis - this.lastProgressUpdateMillis) / 1000.0F;
        this.lastProgressUpdateMillis = nowMillis;
        this.previousProgress = this.progress;
        float f3 = forward ? 1.0F : -1.0F;
        this.progress = Math.max(0.0F, Math.min(1.0F, this.progress + f3 * speed * 20.0F * f2));
        return this.interpolatedProgress;
    }

    public boolean isFinished() {
        return this.getElapsedFraction() >= 1.0;
    }

    public EasingAnimation animateTo(
            double targetValueValue, double d1, EasingFunction easingFunction33, boolean preserve) {
        if (!this.shouldKeepAnimation(preserve, targetValueValue)) {
            this.setEasingFunction(easingFunction33)
                    .setDurationMillis(d1 * 1000.0)
                    .setStartTime(System.currentTimeMillis())
                    .setStartValue(this.getValue())
                    .setTargetValue(targetValueValue);
        }

        return this;
    }

    public EasingAnimation animateTo(double targetValueValue, double d1, boolean preserve) {
        return this.animateTo(targetValueValue, d1, Easings.LINEAR, preserve);
    }

    public double getElapsedFraction() {
        return (double) (System.currentTimeMillis() - this.getStartTime())
                / this.getDurationMillis();
    }

    public double interpolate(double start, double end, double progressValue) {
        return start + (end - start) * progressValue;
    }

    public EasingAnimation setEasingFunction(EasingFunction easingFunction33) {
        this.easing = easingFunction33;
        return this;
    }

    public EasingAnimation() {
        this.lastSmoothUpdateNanos = System.nanoTime();
        this.lastApproachNanos = System.nanoTime();
    }

    public EasingAnimation setDurationMillis(double durationMillisValue) {
        this.durationMillis = durationMillisValue;
        return this;
    }

    public boolean update() {
        this.setPreviousValue(this.getValue());
        boolean isRunning = this.isRunning();
        if (isRunning) {
            this.setCurrentValue(
                    this.interpolate(
                            this.getStartValue(),
                            this.getTargetValue(),
                            this.getEasingFunction().ease(this.getElapsedFraction())));
        } else {
            this.setStartTime(0L);
            this.setCurrentValue(this.getTargetValue());
            if (this.completionCallback != null) {
                this.completionCallback.run();
                this.completionCallback = null;
            }
        }

        return isRunning;
    }

    public void snapTo(double targetValueValue) {
        this.animateTo(targetValueValue, 0.0);
        this.update();
        this.setCurrentValue(targetValueValue);
    }

    public float advanceThenSampleProgress(boolean forward, float speed, float tickDelta) {
        long nowMillis = System.currentTimeMillis();
        float f2 = (float) (nowMillis - this.lastProgressUpdateMillis) / 1000.0F;
        this.lastProgressUpdateMillis = nowMillis;
        this.previousProgress = this.progress;
        float f3 = forward ? 1.0F : -1.0F;
        this.progress = Math.max(0.0F, Math.min(1.0F, this.progress + f3 * speed * 20.0F * f2));
        this.interpolatedProgress =
                this.previousProgress + (this.progress - this.previousProgress) * tickDelta;
        return this.interpolatedProgress;
    }

    public EasingAnimation resetValue(float f) {
        this.snapTo((double) f);
        this.lastApproachNanos = System.nanoTime();
        return this;
    }

    public EasingAnimation setStartTime(long startedAtMillisValue) {
        this.startedAtMillis = startedAtMillisValue;
        return this;
    }

    public EasingAnimation setCurrentValue(double currentValueValue) {
        this.currentValue = currentValueValue;
        return this;
    }

    public float approach(float target, float speed) {
        long nowNanos = System.nanoTime();
        float f2 = Math.min(0.033F, (float) (nowNanos - this.lastApproachNanos) / 1.0E9F);
        this.lastApproachNanos = nowNanos;
        float f3 = Math.max(0.0F, Math.min(1.0F, f2 * 2.0F * speed));
        float f4 = 1.0F - (float) Math.pow((double) (f3 - 1.0F), 4.0);
        this.currentValue = this.currentValue + ((double) target - this.currentValue) * (double) f4;
        if (Math.abs((double) target - this.currentValue) < 0.01F) {
            this.currentValue = (double) target;
        }

        return (float) this.currentValue;
    }

    public EasingFunction getEasingFunction() {
        return this.easing;
    }

    public float getInterpolatedProgress() {
        return this.interpolatedProgress;
    }

    public EasingAnimation animateTo(
            double targetValueValue, double d1, EasingFunction easingFunction33) {
        return this.animateTo(targetValueValue, d1, easingFunction33, false);
    }

    public boolean shouldKeepAnimation(boolean preserve, double target) {
        return preserve
                && this.isRunning()
                && (target == this.getStartValue()
                        || target == this.getTargetValue()
                        || target == this.getValue());
    }

    public EasingAnimation setStartValue(double startValueValue) {
        this.startValue = startValueValue;
        return this;
    }

    public EasingAnimation setPreviousValue(double previousValueValue) {
        this.previousValue = previousValueValue;
        return this;
    }

    public double getDurationMillis() {
        return this.durationMillis;
    }
}
