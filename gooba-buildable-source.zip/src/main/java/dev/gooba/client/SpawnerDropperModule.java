package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

@ModuleInfo(
        name = "Spawner Dropper",
        category = ModuleCategory.DONUT,
        desc = "Drops items from nearby spawners and closes when arrows appear")
@Environment(EnvType.CLIENT)
public class SpawnerDropperModule extends Module {
    private int stage;
    public final SliderSetting delaySetting;
    private int reopenTicks;
    public final BooleanSetting notificationsSetting =
            new BooleanSetting(this, "Notifications", true);
    private int clickTicks;
    private int waitTicks;
    private boolean waitingForReopen;
    private BlockPos spawnerPosition;

    public final SliderSetting autoReopenIntervalSetting;
    public final BooleanSetting boneOnlySetting;

    @Override
    protected void onDisable() {
        this.stage = 0;
        this.waitTicks = 0;
        this.reopenTicks = 0;
        this.spawnerPosition = null;
        this.waitingForReopen = false;
        if (client.currentScreen != null) {
            client.setScreen(null);
        }
    }

    private void notifyPlayer(String text) {
        if (this.notificationsSetting.isOn() && client.player != null) {
            client.player.sendMessage(Text.literal("§7[§6Spawner Dropper§7] §f" + text), false);
        }
    }

    private void clickDropControls(HandledScreen<?> handledscreen) {
        if (client.interactionManager != null && client.player != null) {
            int syncId = handledscreen.getScreenHandler().syncId;
            int count = handledscreen.getScreenHandler().slots.size();
            if (count > 50) {
                client.interactionManager.clickSlot(
                        syncId, 50, 0, SlotActionType.PICKUP, client.player);
            }

            if (count > 53) {
                client.interactionManager.clickSlot(
                        syncId, 53, 0, SlotActionType.PICKUP, client.player);
            }
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.interactionManager != null && client.world != null) {
            if (this.spawnerPosition == null) {
                this.spawnerPosition = this.findSpawner();
                if (this.spawnerPosition != null) {
                    this.notifyPlayer("Spawner detected nearby!");
                }
            }

            this.reopenTicks++;
            int i = (int) (this.autoReopenIntervalSetting.getFloat() * 60.0F * 20.0F);
            if (this.waitingForReopen) {
                if (this.reopenTicks >= i) {
                    this.notifyPlayer("Interval reached - opening spawner.");
                    this.openSpawner();
                    this.reopenTicks = 0;
                }
            } else if (client.currentScreen instanceof HandledScreen handledscreen) {
                if (this.boneOnlySetting.isOn() && this.containsArrows(handledscreen)) {
                    this.notifyPlayer(
                            "Arrows detected - closing spawner and waiting for interval.");
                    this.closeScreen();
                    this.waitingForReopen = true;
                    this.reopenTicks = 0;
                } else {
                    int k = (int) this.delaySetting.getFloat().floatValue();
                    if (this.stage == 2 || this.stage == 5) {
                        this.waitTicks++;
                        if (this.waitTicks >= 3) {
                            if (handledscreen.getScreenHandler().slots.isEmpty()
                                    || handledscreen
                                            .getScreenHandler()
                                            .getSlot(0)
                                            .getStack()
                                            .isEmpty()) {
                                this.notifyPlayer(
                                        "All bones dropped - closing and waiting for interval.");
                                this.closeScreen();
                                this.waitingForReopen = true;
                                this.reopenTicks = 0;
                                return;
                            }

                            this.stage = this.stage == 2 ? 3 : 0;
                            this.waitTicks = 0;
                        }
                    } else if (k > 0) {
                        this.clickTicks++;
                        if (this.clickTicks >= k) {
                            this.clickTicks = 0;
                            int syncId = handledscreen.getScreenHandler().syncId;
                            int count = handledscreen.getScreenHandler().slots.size();
                            switch (this.stage) {
                                case 0:
                                    if (count > 50) {
                                        client.interactionManager.clickSlot(
                                                syncId,
                                                50,
                                                0,
                                                SlotActionType.PICKUP,
                                                client.player);
                                    }

                                    this.stage = 1;
                                    break;
                                case 1:
                                    if (count > 53) {
                                        client.interactionManager.clickSlot(
                                                syncId,
                                                53,
                                                0,
                                                SlotActionType.PICKUP,
                                                client.player);
                                    }

                                    this.stage = 2;
                                    this.waitTicks = 0;
                                case 2:
                                default:
                                    break;
                                case 3:
                                    if (count > 50) {
                                        client.interactionManager.clickSlot(
                                                syncId,
                                                50,
                                                0,
                                                SlotActionType.PICKUP,
                                                client.player);
                                    }

                                    this.stage = 4;
                                    break;
                                case 4:
                                    if (count > 53) {
                                        client.interactionManager.clickSlot(
                                                syncId,
                                                53,
                                                0,
                                                SlotActionType.PICKUP,
                                                client.player);
                                    }

                                    this.stage = 5;
                                    this.waitTicks = 0;
                            }
                        }
                    } else {
                        boolean flagx = this.stage == 3 || this.stage == 4;
                        this.clickDropControls(handledscreen);
                        this.stage = flagx ? 5 : 2;
                        this.waitTicks = 0;
                        this.clickTicks = 0;
                    }
                }
            } else {
                if ((this.reopenTicks >= i || this.reopenTicks == 20)
                        && this.spawnerPosition != null) {
                    this.openSpawner();
                    this.reopenTicks = 0;
                }
            }
        }
    }

    private void openSpawner() {
        if (this.spawnerPosition == null) {
            this.spawnerPosition = this.findSpawner();
        }

        if (this.spawnerPosition != null
                && client.interactionManager != null
                && client.player != null) {
            BlockHitResult blockhitresult =
                    new BlockHitResult(
                            Vec3d.ofCenter(this.spawnerPosition),
                            Direction.UP,
                            this.spawnerPosition,
                            false);
            client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, blockhitresult);
            this.stage = 0;
            this.waitTicks = 0;
            this.clickTicks = 0;
            this.waitingForReopen = false;
        }
    }

    private void closeScreen() {
        if (client.currentScreen != null) {
            client.currentScreen.close();
        }
    }

    private boolean containsArrows(HandledScreen<?> handledscreen) {
        ScreenHandler screenhandler = handledscreen.getScreenHandler();
        int i = Math.min(45, screenhandler.slots.size());

        for (int j = 0; j < i; j++) {
            if (screenhandler.getSlot(j).getStack().isOf(Items.ARROW)) {
                return true;
            }
        }

        return false;
    }

    @Override
    protected void onEnable() {
        this.clickTicks = 0;
        this.stage = 0;
        this.waitTicks = 0;
        this.reopenTicks = 0;
        this.spawnerPosition = null;
        this.waitingForReopen = false;
        this.notifyPlayer("Spawner Dropper activated - will auto-open spawner.");
    }

    public SpawnerDropperModule() {
        this.delaySetting = new SliderSetting(this, "Delay", 0.0F, 0.0F, 20.0F, 1.0F);
        this.boneOnlySetting = new BooleanSetting(this, "Bone Only", true);
        this.autoReopenIntervalSetting =
                new SliderSetting(this, "Auto Reopen Interval", 10.0F, 1.0F, 600.0F, 1.0F);
        this.clickTicks = 0;
        this.stage = 0;
        this.waitTicks = 0;
        this.reopenTicks = 0;
        this.spawnerPosition = null;
        this.waitingForReopen = false;
    }

    private BlockPos findSpawner() {
        if (client.player != null && client.world != null) {
            BlockPos blockpos = client.player.getBlockPos();

            for (int i = -6; i <= 6; i++) {
                for (int j = -6; j <= 6; j++) {
                    for (int k = -6; k <= 6; k++) {
                        BlockPos blockPosValue = blockpos.add(i, j, k);
                        if (client.world.getBlockState(blockPosValue).isOf(Blocks.SPAWNER)) {
                            return blockPosValue;
                        }
                    }
                }
            }

            return null;
        } else {
            return null;
        }
    }
}
