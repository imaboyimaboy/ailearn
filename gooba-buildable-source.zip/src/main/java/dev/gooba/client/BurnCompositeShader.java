package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public class BurnCompositeShader {
    private static final BlendFunction ADDITIVE_BLEND =
            new BlendFunction(SourceFactor.ONE, DestFactor.ONE, SourceFactor.ZERO, DestFactor.ONE);
    private static final RenderPipeline COMPOSITE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/burn_composite"))
                            .withVertexShader(Identifier.of("client", "core/burn_composite"))
                            .withFragmentShader(Identifier.of("client", "core/burn_composite"))
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("BurnData", UniformType.UNIFORM_BUFFER)
                            .withSampler("MaskSampler")
                            .withSampler("GlowSampler")
                            .withSampler("TrailSampler")
                            .withBlend(BurnCompositeShader.ADDITIVE_BLEND)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
    private static final Vector3f MODEL_OFFSET = new Vector3f(0.0F, 0.0F, 0.0F);
    private GpuBuffer vertexBuffer;
    private GpuBuffer uniformBuffer;
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
    private ByteBuffer uniformData;
    private static final BlendFunction REPLACE_BLEND =
            new BlendFunction(SourceFactor.ONE, DestFactor.ZERO, SourceFactor.ONE, DestFactor.ZERO);
    private static final RenderPipeline TRAIL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/burn_trail"))
                            .withVertexShader(Identifier.of("client", "core/burn_trail"))
                            .withFragmentShader(Identifier.of("client", "core/burn_trail"))
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("BurnData", UniformType.UNIFORM_BUFFER)
                            .withSampler("TrailSampler")
                            .withSampler("GlowSampler")
                            .withSampler("HandSampler")
                            .withSampler("MaskSampler")
                            .withBlend(BurnCompositeShader.REPLACE_BLEND)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private static final RenderPipeline GLOW_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/burn_glow"))
                            .withVertexShader(Identifier.of("client", "core/burn_glow"))
                            .withFragmentShader(Identifier.of("client", "core/burn_glow"))
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("BurnData", UniformType.UNIFORM_BUFFER)
                            .withSampler("HandSampler")
                            .withSampler("MaskSampler")
                            .withBlend(REPLACE_BLEND)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private boolean initialized = false;

    public void renderTrail(
            GpuTextureView gputextureview,
            GpuTextureView gpuTextureView,
            GpuTextureView gpuTextureViewValue,
            GpuTextureView gpuTextureView2,
            GpuTextureView gpuTextureView3) {
        GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
        CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
        GpuBufferSlice gpubufferslice =
                RenderSystem.getDynamicUniforms()
                        .write(
                                RenderSystem.getModelViewMatrix(),
                                COLOR_MODULATOR,
                                MODEL_OFFSET,
                                TEXTURE_MATRIX);

        try (RenderPass renderpass =
                commandencoder.createRenderPass(
                        () -> "minecraft:burn_trail_pass", gputextureview, OptionalInt.of(0))) {
            renderpass.setPipeline(TRAIL_PIPELINE);
            renderpass.setVertexBuffer(0, this.vertexBuffer);
            renderpass.bindTexture("TrailSampler", gpuTextureView, gpusampler);
            renderpass.bindTexture("GlowSampler", gpuTextureViewValue, gpusampler);
            renderpass.bindTexture("HandSampler", gpuTextureView2, gpusampler);
            renderpass.bindTexture("MaskSampler", gpuTextureView3, gpusampler);
            RenderSystem.bindDefaultUniforms(renderpass);
            renderpass.setUniform("DynamicTransforms", gpubufferslice);
            renderpass.setUniform("BurnData", this.uniformBuffer);
            renderpass.draw(0, 6);
        }
    }

    public void renderGlow(
            GpuTextureView gputextureview,
            GpuTextureView gpuTextureView,
            GpuTextureView gpuTextureViewValue) {
        GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
        CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
        GpuBufferSlice gpubufferslice =
                RenderSystem.getDynamicUniforms()
                        .write(
                                RenderSystem.getModelViewMatrix(),
                                COLOR_MODULATOR,
                                MODEL_OFFSET,
                                TEXTURE_MATRIX);

        try (RenderPass renderpass =
                commandencoder.createRenderPass(
                        () -> "minecraft:burn_glow_pass", gputextureview, OptionalInt.of(0))) {
            renderpass.setPipeline(GLOW_PIPELINE);
            renderpass.setVertexBuffer(0, this.vertexBuffer);
            renderpass.bindTexture("HandSampler", gpuTextureView, gpusampler);
            renderpass.bindTexture("MaskSampler", gpuTextureViewValue, gpusampler);
            RenderSystem.bindDefaultUniforms(renderpass);
            renderpass.setUniform("DynamicTransforms", gpubufferslice);
            renderpass.setUniform("BurnData", this.uniformBuffer);
            renderpass.draw(0, 6);
        }
    }

    public void close() {
        if (this.uniformBuffer != null) {
            this.uniformBuffer.close();
            this.uniformBuffer = null;
        }

        if (this.vertexBuffer != null) {
            this.vertexBuffer.close();
            this.vertexBuffer = null;
        }

        if (this.uniformData != null) {
            MemoryUtil.memFree(this.uniformData);
            this.uniformData = null;
        }

        this.initialized = false;
    }

    public void composite(
            GpuTextureView gputextureview,
            GpuTextureView gpuTextureView,
            GpuTextureView gpuTextureViewValue,
            GpuTextureView gpuTextureView2) {
        GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
        CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
        GpuBufferSlice gpubufferslice =
                RenderSystem.getDynamicUniforms()
                        .write(
                                RenderSystem.getModelViewMatrix(),
                                COLOR_MODULATOR,
                                MODEL_OFFSET,
                                TEXTURE_MATRIX);

        try (RenderPass renderpass =
                commandencoder.createRenderPass(
                        () -> "minecraft:burn_composite_pass",
                        gputextureview,
                        OptionalInt.empty())) {
            renderpass.setPipeline(COMPOSITE_PIPELINE);
            renderpass.setVertexBuffer(0, this.vertexBuffer);
            renderpass.bindTexture("MaskSampler", gpuTextureView, gpusampler);
            renderpass.bindTexture("GlowSampler", gpuTextureViewValue, gpusampler);
            renderpass.bindTexture("TrailSampler", gpuTextureView2, gpusampler);
            RenderSystem.bindDefaultUniforms(renderpass);
            renderpass.setUniform("DynamicTransforms", gpubufferslice);
            renderpass.setUniform("BurnData", this.uniformBuffer);
            renderpass.draw(0, 6);
        }
    }

    private void initialize() {
        if (!this.initialized) {
            this.uniformData = MemoryUtil.memAlloc(64);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.vertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:burn_dummy_vertex", 32, bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.initialized = true;
        }
    }

    public void uploadUniforms(
            int i,
            int j,
            boolean flag,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            int k,
            float f8) {
        this.initialize();
        this.uniformData.clear();
        float f9 = (float) (System.currentTimeMillis() % 100000L) / 1000.0F;
        this.uniformData.putFloat((float) i);
        this.uniformData.putFloat((float) j);
        this.uniformData.putFloat(f9);
        this.uniformData.putFloat(flag ? 1.0F : 0.0F);
        this.uniformData.putFloat(f);
        this.uniformData.putFloat(f1);
        this.uniformData.putFloat(f2);
        this.uniformData.putFloat(f3);
        this.uniformData.putFloat(f4);
        this.uniformData.putFloat(f5);
        this.uniformData.putFloat(f6);
        this.uniformData.putFloat(f7);
        this.uniformData.putFloat((float) (k >> 16 & 0xFF) / 255.0F);
        this.uniformData.putFloat((float) (k >> 8 & 0xFF) / 255.0F);
        this.uniformData.putFloat((float) (k & 0xFF) / 255.0F);
        this.uniformData.putFloat(f8);
        this.uniformData.flip();
        int l = this.uniformData.remaining();
        if (this.uniformBuffer == null || this.uniformBuffer.size() < (long) l) {
            if (this.uniformBuffer != null) {
                this.uniformBuffer.close();
            }

            this.uniformBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:burn_uniform", 136, (long) l);
        }

        CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
        commandencoder.writeToBuffer(this.uniformBuffer.slice(), this.uniformData);
    }
}
