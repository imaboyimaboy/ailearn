package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

@Environment(EnvType.CLIENT)
public class MainMenuGridShader {
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

    private static final Identifier FRAGMENT_SHADER =
            Identifier.of("client", "core/main_menu_grid");

    private static final Vector3f MODEL_OFFSET = new Vector3f(0.0F, 0.0F, 0.0F);
    private static final Identifier VERTEX_SHADER = Identifier.of("client", "core/main_menu_grid");
    private static final Identifier PIPELINE_ID =
            Identifier.of("client", "pipeline/main_menu_grid");
    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(MainMenuGridShader.PIPELINE_ID)
                            .withVertexShader(VERTEX_SHADER)
                            .withFragmentShader(FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("MainMenuGridData", UniformType.UNIFORM_BUFFER)
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
}
