package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Environment(EnvType.CLIENT)
public class CommandManager {
    private final Map<String, Command> commands;

    private char prefix = '.';

    public boolean executeChatMessage(String text) throws CloneNotSupportedException {
        if (!text.isEmpty() && text.charAt(0) == this.prefix) {
            String[] astring = text.substring(1).trim().split("\\s+");
            if (astring.length != 0 && !astring[0].isEmpty()) {
                String textValue = astring[0].toLowerCase();
                Command command = this.commands.get(textValue);
                if (command == null) {
                    ChatMessages.send("§cUnknown command: §r" + textValue);
                    this.printCommandList();
                    return true;
                } else {
                    command.execute(Arrays.copyOfRange(astring, 1, astring.length));
                    return true;
                }
            } else {
                this.printCommandList();
                return true;
            }
        } else {
            return false;
        }
    }

    public void initialize() {
        this.register(new Configs());
        this.register(new FriendsList());
        this.register(new ChangeCommandPrefix());
        this.register(new Gps());
        this.register(new WaypointsMarkersOnCoordinates());
    }

    private void printCommandList() {
        int count = this.commands.size();
        ChatMessages.send("§7Commands §8[" + count + "§8]§7:");
        this.commands
                .keySet()
                .forEach(
                        text -> {
                            char prefixValue = this.prefix;
                            ChatMessages.send("§a" + prefixValue + text);
                        });
    }

    public void register(Command command) {
        this.commands.put(command.getName().toLowerCase(), command);
    }

    public CommandManager() {
        this.commands = new LinkedHashMap<>();
    }

    public char getPrefix() {
        return this.prefix;
    }

    public List<String> suggest(String text) {
        if (!text.isEmpty() && text.charAt(0) == this.prefix) {
            String textValue = text.substring(1);
            if (!textValue.contains(" ")) {
                return this.commands.entrySet().stream()
                        .filter(entry -> entry.getKey().startsWith(textValue.toLowerCase()))
                        .map(
                                entry -> {
                                    char prefixValue = this.prefix;
                                    String key = entry.getKey();
                                    char c0 = prefixValue;
                                    return c0 + key;
                                })
                        .collect(Collectors.toList());
            } else {
                String[] astring = textValue.split(" ", 2);
                String text3 = astring[0].toLowerCase();
                String text2;
                if (astring.length > 1) {
                    text2 = astring[1];
                } else {
                    text2 = "";
                }

                Command command = this.commands.get(text3);
                return command == null
                        ? Collections.emptyList()
                        : command.suggest(text2).stream()
                                .map(
                                        s1x -> {
                                            char c0 = this.prefix;
                                            return c0 + text3 + " " + s1x;
                                        })
                                .collect(Collectors.toList());
            }
        } else {
            return Collections.emptyList();
        }
    }

    public void setPrefix(char prefixValue) {
        this.prefix = prefixValue;
    }
}
