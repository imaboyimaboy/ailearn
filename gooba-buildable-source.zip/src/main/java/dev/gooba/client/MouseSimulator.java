package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Environment(EnvType.CLIENT)
public final class MouseSimulator {
    private static final Map<Integer, Boolean> pressedButtons = new ConcurrentHashMap<>();
    private static volatile long useSuppressedUntilMillis;
    private static final ScheduledExecutorService releaseExecutor =
            Executors.newSingleThreadScheduledExecutor(
                    runnable -> {
                        Thread thread = new Thread(runnable, "goobaa-mouse-simulation");
                        thread.setDaemon(true);
                        return thread;
                    });

    public static void suppressUse(long i) {
        useSuppressedUntilMillis =
                Math.max(useSuppressedUntilMillis, System.currentTimeMillis() + Math.max(1L, i));
    }

    public static boolean isPressed(int i) {
        return pressedButtons.getOrDefault(i, false);
    }

    private MouseSimulator() {}

    private static double scaledMouseX(MinecraftClient minecraftclient) {
        return minecraftclient.mouse.getX()
                * (double) minecraftclient.getWindow().getScaledWidth()
                / (double) minecraftclient.getWindow().getWidth();
    }

    public static void release(int i) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        pressedButtons.put(i, false);
        if (minecraftclient != null) {
            new MouseReleaseEvent(
                            scaledMouseX(minecraftclient),
                            scaledMouseY(minecraftclient),
                            i,
                            minecraftclient.currentScreen)
                    .hook();
        }
    }

    public static boolean isUseSuppressed() {
        return System.currentTimeMillis() <= useSuppressedUntilMillis;
    }

    public static void click(int i, long j) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient != null) {
            press(i);
            releaseExecutor.schedule(
                    () -> minecraftclient.execute(() -> release(i)),
                    Math.max(1L, j),
                    TimeUnit.MILLISECONDS);
        }
    }

    public static void click(int i) {
        click(i, 35L);
    }

    public static boolean consumePress(int i) {
        return pressedButtons.replace(i, true, false);
    }

    private static double scaledMouseY(MinecraftClient minecraftclient) {
        return minecraftclient.mouse.getY()
                * (double) minecraftclient.getWindow().getScaledHeight()
                / (double) minecraftclient.getWindow().getHeight();
    }

    public static void press(int i) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        pressedButtons.put(i, true);
        if (minecraftclient != null) {
            new KeyPressEvent(i).hook();
            new MouseButtonEvent(
                            i,
                            1,
                            0,
                            minecraftclient.currentScreen,
                            scaledMouseX(minecraftclient),
                            scaledMouseY(minecraftclient))
                    .hook();
        }
    }
}
