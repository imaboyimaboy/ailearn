package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "China Hat",
        desc = "Renders a decorative conical hat above the player",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class ChinaHatModule extends Module {
    public static ChinaHatModule getInstance() {
        return (ChinaHatModule) ModuleLookup.getModule(ChinaHatModule.class);
    }
}
