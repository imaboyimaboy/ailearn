package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public class KawaseBlur {
    private GpuTextureView outputView;
    private ByteBuffer uniformData;
    private static final Identifier UPSAMPLE_PIPELINE_ID =
            Identifier.of("client", "pipeline/kawase_up");
    private static final Identifier UPSAMPLE_VERTEX_SHADER =
            Identifier.of("client", "core/kawase_up");
    private GpuBuffer[] uniformBuffers;
    private static final Identifier UPSAMPLE_FRAGMENT_SHADER =
            Identifier.of("client", "core/kawase_up");
    private static final RenderPipeline UPSAMPLE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(KawaseBlur.UPSAMPLE_PIPELINE_ID)
                            .withVertexShader(KawaseBlur.UPSAMPLE_VERTEX_SHADER)
                            .withFragmentShader(KawaseBlur.UPSAMPLE_FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("KawaseData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private int height;
    private boolean initialized;
    private static final Vector3f MODEL_OFFSET = new Vector3f(0.0F, 0.0F, 0.0F);

    private int[] downsampleHeights;
    private static final Identifier DOWNSAMPLE_VERTEX_SHADER =
            Identifier.of("client", "core/kawase_down");
    private GpuBuffer vertexBuffer;
    private static final Identifier DOWNSAMPLE_PIPELINE_ID =
            Identifier.of("client", "pipeline/kawase_down");
    private int[] upsampleWidths;
    private static final Identifier DOWNSAMPLE_FRAGMENT_SHADER =
            Identifier.of("client", "core/kawase_down");
    private GpuTexture[] downsampleTextures;
    private GpuTexture outputTexture;

    private int width = 0;
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
    private int[] downsampleWidths;
    private int[] upsampleHeights;
    private GpuTexture[] upsampleTextures;
    private GpuTextureView[] downsampleViews;
    private static final RenderPipeline DOWNSAMPLE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(DOWNSAMPLE_PIPELINE_ID)
                            .withVertexShader(DOWNSAMPLE_VERTEX_SHADER)
                            .withFragmentShader(DOWNSAMPLE_FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("KawaseData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
    private GpuTextureView[] upsampleViews;

    private void uploadUniforms(
            CommandEncoder commandencoder, GpuBuffer gpubuffer, int i, int j, float f) {
        this.uniformData.clear();
        this.uniformData.putFloat((float) i);
        this.uniformData.putFloat((float) j);
        this.uniformData.putFloat(f);
        this.uniformData.putFloat(0.0F);
        this.uniformData.flip();
        commandencoder.writeToBuffer(gpubuffer.slice(), this.uniformData);
    }

    private void resize(int widthValue, int heightValue) {
        if (widthValue != this.width || heightValue != this.height) {
            this.closeTextures();
            this.outputTexture =
                    RenderSystem.getDevice()
                            .createTexture(
                                    () -> "minecraft:kawase_final",
                                    13,
                                    TextureFormat.RGBA8,
                                    widthValue,
                                    heightValue,
                                    1,
                                    1);
            this.outputView = RenderSystem.getDevice().createTextureView(this.outputTexture);
            int downsampleWidth = widthValue;
            int downsampleHeight = heightValue;

            for (int i11 = 0; i11 < 8; i11++) {
                downsampleWidth = Math.max(1, downsampleWidth / 2);
                downsampleHeight = Math.max(1, downsampleHeight / 2);
                int j1 = i11;
                this.downsampleWidths[i11] = downsampleWidth;
                this.downsampleHeights[i11] = downsampleHeight;
                this.upsampleWidths[i11] = downsampleWidth;
                this.upsampleHeights[i11] = downsampleHeight;
                this.downsampleTextures[i11] =
                        RenderSystem.getDevice()
                                .createTexture(
                                        () -> "minecraft:kawase_down_" + j1,
                                        13,
                                        TextureFormat.RGBA8,
                                        downsampleWidth,
                                        downsampleHeight,
                                        1,
                                        1);
                this.downsampleViews[i11] =
                        RenderSystem.getDevice().createTextureView(this.downsampleTextures[i11]);
                this.upsampleTextures[i11] =
                        RenderSystem.getDevice()
                                .createTexture(
                                        () -> "minecraft:kawase_up_" + j1,
                                        13,
                                        TextureFormat.RGBA8,
                                        downsampleWidth,
                                        downsampleHeight,
                                        1,
                                        1);
                this.upsampleViews[i11] =
                        RenderSystem.getDevice().createTextureView(this.upsampleTextures[i11]);
            }

            this.width = widthValue;
            this.height = heightValue;
        }
    }

    public void close() {
        this.closeTextures();
        if (this.uniformBuffers != null) {
            for (GpuBuffer gpubuffer : this.uniformBuffers) {
                if (gpubuffer != null) {
                    gpubuffer.close();
                }
            }

            this.uniformBuffers = null;
        }

        if (this.vertexBuffer != null) {
            this.vertexBuffer.close();
            this.vertexBuffer = null;
        }

        if (this.uniformData != null) {
            MemoryUtil.memFree(this.uniformData);
            this.uniformData = null;
        }

        this.initialized = false;
    }

    public GpuTextureView blur(
            GpuTexture gputexture,
            GpuTextureView gputextureview,
            int widthValue,
            int heightValue,
            int k,
            float f,
            boolean flag) {
        if (gputexture == null || gputextureview == null) {
            return null;
        } else if (!gputexture.isClosed() && !gputextureview.isClosed()) {
            this.initialize();
            this.resize(widthValue, heightValue);
            k = Math.min(Math.max(k, 1), 8);
            CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
            GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
            GpuBufferSlice gpubufferslice =
                    RenderSystem.getDynamicUniforms()
                            .write(
                                    RenderSystem.getModelViewMatrix(),
                                    COLOR_MODULATOR,
                                    MODEL_OFFSET,
                                    TEXTURE_MATRIX);
            GpuTextureView gputextureviewValue = gputextureview;
            int widthValueValue = widthValue;
            int heightValueValue = heightValue;
            int j1 = 0;
            int k1 = 0;

            while (true) {
                RenderPass renderpass;
                Throwable throwableValue;
                label92:
                if (k1 < k) {
                    GpuBuffer gpubuffer = this.uniformBuffers[j1++];
                    float f1 =
                            flag
                                    ? f
                                            * (float) k1
                                            / Math.max(1.0F, (float) k - 1.0F)
                                            * (float) widthValueValue
                                            / (float) widthValue
                                    : f;
                    this.uploadUniforms(
                            commandencoder, gpubuffer, widthValueValue, heightValueValue, f1);
                    int k2 = k1;
                    renderpass =
                            commandencoder.createRenderPass(
                                    () -> "minecraft:kawase_down_" + k2,
                                    this.downsampleViews[k1],
                                    OptionalInt.empty());

                    try {
                        renderpass.setPipeline(DOWNSAMPLE_PIPELINE);
                        renderpass.setVertexBuffer(0, this.vertexBuffer);
                        renderpass.bindTexture("Sampler0", gputextureviewValue, gpusampler);
                        RenderSystem.bindDefaultUniforms(renderpass);
                        renderpass.setUniform("DynamicTransforms", gpubufferslice);
                        renderpass.setUniform("KawaseData", gpubuffer);
                        renderpass.draw(0, 6);
                    } catch (Throwable throwableValueValue) {
                        throwableValue = throwableValueValue;
                        boolean flag1 = false;
                        break label92;
                    }

                    if (renderpass != null) {
                        renderpass.close();
                    }

                    gputextureviewValue = this.downsampleViews[k1];
                    widthValueValue = this.downsampleWidths[k1];
                    heightValueValue = this.downsampleHeights[k1];
                    k1++;
                    continue;
                } else {
                    k1 = k - 1;

                    while (true) {
                        if (k1 < 0) {
                            GpuBuffer gpubufferValue = this.uniformBuffers[j1];
                            this.uploadUniforms(
                                    commandencoder,
                                    gpubufferValue,
                                    widthValueValue,
                                    heightValueValue,
                                    flag ? 0.0F : f);

                            try (RenderPass renderPass =
                                    commandencoder.createRenderPass(
                                            () -> "minecraft:kawase_final",
                                            this.outputView,
                                            OptionalInt.empty())) {
                                renderPass.setPipeline(UPSAMPLE_PIPELINE);
                                renderPass.setVertexBuffer(0, this.vertexBuffer);
                                renderPass.bindTexture("Sampler0", gputextureviewValue, gpusampler);
                                RenderSystem.bindDefaultUniforms(renderPass);
                                renderPass.setUniform("DynamicTransforms", gpubufferslice);
                                renderPass.setUniform("KawaseData", gpubufferValue);
                                renderPass.draw(0, 6);
                            }

                            return this.outputView;
                        }

                        GpuBuffer uniformBuffer = this.uniformBuffers[j1++];
                        float f2 =
                                flag
                                        ? f
                                                * (float) k1
                                                / Math.max(1.0F, (float) k - 1.0F)
                                                * (float) widthValueValue
                                                / (float) widthValue
                                        : f;
                        this.uploadUniforms(
                                commandencoder,
                                uniformBuffer,
                                widthValueValue,
                                heightValueValue,
                                f2);
                        int l1 = k1;
                        renderpass =
                                commandencoder.createRenderPass(
                                        () -> "minecraft:kawase_up_" + l1,
                                        this.upsampleViews[l1],
                                        OptionalInt.empty());

                        try {
                            renderpass.setPipeline(UPSAMPLE_PIPELINE);
                            renderpass.setVertexBuffer(0, this.vertexBuffer);
                            renderpass.bindTexture("Sampler0", gputextureviewValue, gpusampler);
                            RenderSystem.bindDefaultUniforms(renderpass);
                            renderpass.setUniform("DynamicTransforms", gpubufferslice);
                            renderpass.setUniform("KawaseData", uniformBuffer);
                            renderpass.draw(0, 6);
                        } catch (Throwable throwableValue2) {
                            throwableValue = throwableValue2;
                            boolean flag2 = false;
                            break;
                        }

                        if (renderpass != null) {
                            renderpass.close();
                        }

                        gputextureviewValue = this.upsampleViews[k1];
                        widthValueValue = this.upsampleWidths[k1];
                        heightValueValue = this.upsampleHeights[k1];
                        k1--;
                    }
                }

                Throwable throwable = throwableValue;
                if (renderpass != null) {
                    try {
                        renderpass.close();
                    } catch (Throwable throwable2) {
                        throwable.addSuppressed(throwable2);
                    }
                }

                throw dev.gooba.client.Sneaky.rethrow(throwable);
            }
        } else {
            return null;
        }
    }

    private void closeTextures() {
        if (this.outputView != null) {
            this.outputView.close();
            this.outputView = null;
        }

        if (this.outputTexture != null) {
            this.outputTexture.close();
            this.outputTexture = null;
        }

        if (this.downsampleViews != null) {
            for (int i = 0; i < 8; i++) {
                if (this.downsampleViews[i] != null) {
                    this.downsampleViews[i].close();
                    this.downsampleViews[i] = null;
                }

                if (this.downsampleTextures[i] != null) {
                    this.downsampleTextures[i].close();
                    this.downsampleTextures[i] = null;
                }

                if (this.upsampleViews[i] != null) {
                    this.upsampleViews[i].close();
                    this.upsampleViews[i] = null;
                }

                if (this.upsampleTextures[i] != null) {
                    this.upsampleTextures[i].close();
                    this.upsampleTextures[i] = null;
                }
            }
        }
    }

    private void initialize() {
        if (!this.initialized) {
            this.uniformData = MemoryUtil.memAlloc(16);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.vertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:kawase_dummy_vertex", 32, bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.uniformBuffers = new GpuBuffer[17];

            for (int i = 0; i < 17; i++) {
                int j = i;
                this.uniformBuffers[i] =
                        RenderSystem.getDevice()
                                .createBuffer(() -> "minecraft:kawase_uniform_" + j, 136, 16L);
            }

            this.downsampleTextures = new GpuTexture[8];
            this.downsampleViews = new GpuTextureView[8];
            this.upsampleTextures = new GpuTexture[8];
            this.upsampleViews = new GpuTextureView[8];
            this.downsampleWidths = new int[8];
            this.downsampleHeights = new int[8];
            this.upsampleWidths = new int[8];
            this.upsampleHeights = new int[8];
            this.initialized = true;
        }
    }

    public GpuTextureView blur(
            GpuTexture gputexture,
            GpuTextureView gputextureview,
            int widthValue,
            int heightValue,
            int k,
            float f) {
        return this.blur(gputexture, gputextureview, widthValue, heightValue, k, f, false);
    }

    public KawaseBlur() {
        this.height = 0;
        this.initialized = false;
    }
}
