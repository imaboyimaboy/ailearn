package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Discord Presence",
        desc = "Shows your game activity on Discord",
        category = ModuleCategory.CLIENT,
        autoEnabled = true)
@Environment(EnvType.CLIENT)
public class DiscordPresenceModule extends Module {
    public final BooleanSetting showButtonsSetting = new BooleanSetting(this, "Show Buttons", true);
    public final TextSetting button2URLSetting;
    public final TextSetting button1LabelSetting =
            new TextSetting(this, "Button 1 Label", "Web")
                    .visibleWhen(this.showButtonsSetting::isOn);
    public final TextSetting button2LabelSetting;
    public final TextSetting button1URLSetting =
            new TextSetting(this, "Button 1 URL", "https://goobaaclient.org")
                    .visibleWhen(this.showButtonsSetting::isOn);

    @Override
    public void setEnabled(boolean enabled, boolean playSound) {

        boolean wasEnabled = this.isEnabled();
        super.setEnabled(enabled, playSound);
        if (wasEnabled != this.isEnabled()) {
            if (this.isEnabled()) {
                Gooba.getInstance().getDiscordPresenceManager().start();
            } else {
                Gooba.getInstance().getDiscordPresenceManager().stop();
            }
        }
    }

    public DiscordPresenceModule() {
        this.button2LabelSetting =
                new TextSetting(this, "Button 2 Label", "Discord")
                        .visibleWhen(this.showButtonsSetting::isOn);
        this.button2URLSetting =
                new TextSetting(this, "Button 2 URL", "https://discord.gg/goobaa")
                        .visibleWhen(this.showButtonsSetting::isOn);
    }
}
