package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

@ModuleInfo(
        name = "MaceSwap",
        desc = "Follows sword attacks with an enchanted mace or targets enemies while falling",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class MaceSwapModule extends Module {
    private boolean rotating;

    private int previousSlot;
    private LivingEntity target;
    public final BooleanSetting switchBackSetting;
    private long swapStartedMillis;
    private boolean fallConsumed;
    public final SliderSetting switchDelaySetting;
    private int remainingTicks;
    private long switchAtMillis;
    private boolean attacking;
    private int maceSlot;
    private static MaceSwapModule instance;
    private float pitchSpeed;
    public final BooleanSetting targetSetting;
    public final ModeSetting modeSetting =
            new ModeSetting(this, "Mode", new String[] {"Breach", "Wind Burst"});
    private float yawSpeed;

    @EventHandler
    public void onPreClientTick(PreClientTickEvent preClientTickEvent) {
        if (client.player != null && client.world != null && client.interactionManager != null) {
            if (client.player.isOnGround() || client.player.getVelocity().y >= 0.0) {
                this.fallConsumed = false;
            }

            if (client.currentScreen == null
                    && client.player.isAlive()
                    && !client.player.isSpectator()
                    && !client.player.isUsingItem()
                    && !AutoTotemModule.isSwapPending()
                    && !SpearSwapModule.isActive()
                    && !ShieldBreakerModule.isActive()
                    && !DoubleAnchorModule.isActive()) {
                if (this.previousSlot == -1) {
                    if (!this.targetSetting.isOn() || !this.canSmash() || this.fallConsumed) {
                        return;
                    }

                    LivingEntity livingentity = null;
                    double MAX_VALUE = Double.MAX_VALUE;

                    for (Entity entity : client.world.getEntities()) {
                        if (!FakeLagModule.isGhost(entity) && entity instanceof LivingEntity) {
                            LivingEntity entityValue = (LivingEntity) entity;
                            if (this.isValidTarget(entityValue)) {
                                double MAX_VALUEValue =
                                        client.player.squaredDistanceTo(entityValue);
                                if (MAX_VALUEValue < MAX_VALUE) {
                                    livingentity = entityValue;
                                    MAX_VALUE = MAX_VALUEValue;
                                }
                            }
                        }
                    }

                    if (livingentity == null || !this.startSwap(livingentity)) {
                        return;
                    }
                }

                long nowMillis = System.currentTimeMillis();
                if (nowMillis - this.swapStartedMillis
                        > Math.max(
                                2000L,
                                (long) Math.round(this.switchDelaySetting.getFloat()) * 5L
                                        + 1000L)) {
                    this.finishSwap();
                } else if (this.remainingTicks == 0) {
                    if (nowMillis >= this.switchAtMillis) {
                        this.finishSwap();
                    }
                } else if (this.isValidTarget(this.target)
                        && (!this.targetSetting.isOn() || this.canSmash())) {
                    if (this.maceSlot == -1) {
                        if (client.player.getInventory().getSelectedSlot() != this.previousSlot) {
                            this.reset();
                            return;
                        }

                        if (nowMillis < this.switchAtMillis) {
                            return;
                        }

                        int maceSlotValue = this.findMaceSlot();
                        if (maceSlotValue == -1) {
                            this.reset();
                            return;
                        }

                        this.maceSlot = maceSlotValue;
                        EnchantmentInventoryUtils.selectHotbarSlot(maceSlotValue);
                        this.switchAtMillis =
                                nowMillis + (long) Math.round(this.switchDelaySetting.getFloat());
                    }

                    if (client.player.getInventory().getSelectedSlot() != this.maceSlot
                            || !client.player.getMainHandStack().isOf(Items.MACE)
                            || EnchantmentInventoryUtils.enchantmentLevel(
                                            client.player.getMainHandStack(),
                                            this.preferredEnchantment())
                                    == 0) {
                        this.reset();
                    } else if (!this.targetSetting.isOn() || this.aimAtTarget()) {
                        if (nowMillis >= this.switchAtMillis) {
                            if (this.isAimedAtTarget(
                                            client.player.getYaw(), client.player.getPitch())
                                    && this.isAimedAtTarget(
                                            client.player.lastYawClient,
                                            client.player.lastPitchClient)) {
                                this.attacking = true;

                                try {
                                    client.interactionManager.attackEntity(
                                            client.player, this.target);
                                    client.player.swingHand(Hand.MAIN_HAND);
                                    this.remainingTicks--;
                                    this.switchAtMillis =
                                            nowMillis
                                                    + (long)
                                                            Math.round(
                                                                    this.switchDelaySetting
                                                                            .getFloat());
                                } finally {
                                    this.attacking = false;
                                }

                                if (this.remainingTicks == 0
                                        && this.switchDelaySetting.getFloat() <= 0.0F) {
                                    this.finishSwap();
                                }
                            } else {
                                if (!this.targetSetting.isOn()) {
                                    this.finishSwap();
                                }
                            }
                        }
                    }
                } else {
                    this.finishSwap();
                }
            } else {
                this.finishSwap();
            }
        } else {
            this.reset();
            this.fallConsumed = false;
        }
    }

    private boolean canSmash() {
        return !client.player.isOnGround()
                && client.player.fallDistance >= 3.0
                && client.player.getVelocity().y < 0.0
                && !client.player.isGliding()
                && !client.player.isTouchingWater()
                && !client.player.hasVehicle();
    }

    @EventHandler
    public void onMovementInput(MovementInputEvent movementInputEvent) {
        if (this.rotating
                && client.player != null
                && TargetRingRenderer.rotationPriority == 30
                && TargetRingRenderer.rotationTask == TargetRingRenderer.RotationTask.AIM) {
            MovementUtils.correctMovementInput(
                    movementInputEvent,
                    client.player.getYaw(),
                    client.gameRenderer.getCamera().getYaw());
        }
    }

    public MaceSwapModule() {
        this.switchBackSetting = new BooleanSetting(this, "Switch Back", true);
        this.switchDelaySetting = new SliderSetting(this, "Switch Delay", 0.0F, 0.0F, 500.0F, 1.0F);
        this.targetSetting = new BooleanSetting(this, "Target", false);
        this.previousSlot = -1;
        this.maceSlot = -1;
        this.yawSpeed = 24.0F;
        this.pitchSpeed = 6.0F;
        instance = this;
    }

    private int findMaceSlot() {
        return EnchantmentInventoryUtils.findBestEnchantedSlot(
                itemstack -> itemstack.isOf(Items.MACE), this.preferredEnchantment());
    }

    private void reset() {
        if (this.rotating && TargetRingRenderer.rotationPriority == 30) {
            TargetRingRenderer.rotationTask = TargetRingRenderer.RotationTask.RESET;
        }

        this.target = null;
        this.previousSlot = -1;
        this.maceSlot = -1;
        this.remainingTicks = 0;
        this.attacking = false;
        this.rotating = false;
        this.yawSpeed = 24.0F;
        this.pitchSpeed = 6.0F;
    }

    private boolean isValidTarget(LivingEntity livingentity) {
        if (livingentity != null
                && livingentity != client.player
                && livingentity.isAlive()
                && !livingentity.isRemoved()
                && !livingentity.isInvulnerable()
                && !livingentity.isSpectator()
                && !(livingentity instanceof ArmorStandEntity)) {
            if (client.world.getEntityById(livingentity.getId()) == livingentity
                    && client.player.canSee(livingentity)) {
                if (livingentity instanceof PlayerEntity playerentity
                        && (playerentity.isCreative()
                                || Gooba.getInstance()
                                        .getFriendManager()
                                        .isFriend(playerentity.getName().getString()))) {
                    return false;
                }

                double d0 = client.player.getEntityInteractionRange() + 2.0;
                return client.player.squaredDistanceTo(livingentity) <= d0 * d0;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private void finishSwap() {
        if (this.switchBackSetting.isOn()
                && client.player != null
                && client.player.isAlive()
                && client.player.getInventory().getSelectedSlot() == this.maceSlot) {
            EnchantmentInventoryUtils.selectHotbarSlot(this.previousSlot);
        }

        this.reset();
    }

    @Override
    protected void onDisable() {
        this.finishSwap();
        this.fallConsumed = false;
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled() && instance.previousSlot != -1;
    }

    private boolean isAimedAtTarget(float f, float f1) {
        Vec3d vec3d = client.player.getEyePos();
        double entityInteractionRange = client.player.getEntityInteractionRange();
        Vec3d vec3d1 =
                vec3d.add(EntityRaycast.rotationVector(f1, f).multiply(entityInteractionRange));
        Vec3d vec3d2 = this.target.getBoundingBox().raycast(vec3d, vec3d1).orElse(null);
        if (vec3d2 == null) {
            return false;
        } else {
            BlockHitResult blockhitresult =
                    client.world.raycast(
                            new RaycastContext(
                                    vec3d,
                                    vec3d2,
                                    ShapeType.COLLIDER,
                                    FluidHandling.NONE,
                                    client.player));
            return blockhitresult.getType() == Type.MISS;
        }
    }

    private RegistryKey<Enchantment> preferredEnchantment() {
        return this.modeSetting.isSelected("Wind Burst")
                ? Enchantments.WIND_BURST
                : Enchantments.BREACH;
    }

    private boolean startSwap(LivingEntity livingentity) {
        if (this.findMaceSlot() == -1) {
            return false;
        } else {
            this.target = livingentity;
            this.previousSlot = client.player.getInventory().getSelectedSlot();
            this.maceSlot = -1;
            this.remainingTicks = 2;
            this.swapStartedMillis = System.currentTimeMillis();
            this.switchAtMillis =
                    this.swapStartedMillis + (long) Math.round(this.switchDelaySetting.getFloat());
            if (this.targetSetting.isOn()) {
                this.fallConsumed = true;
            }

            return true;
        }
    }

    private boolean aimAtTarget() {
        if (TargetRingRenderer.rotationPriority > 30) {
            return false;
        } else if (this.rotating
                && this.isAimedAtTarget(client.player.getYaw(), client.player.getPitch())
                && this.isAimedAtTarget(
                        client.player.lastYawClient, client.player.lastPitchClient)) {
            TargetRingRenderer.ticksSinceAim = 0;
            return true;
        } else {
            Vec3d vec3d =
                    this.target.getBoundingBox().getCenter().subtract(client.player.getEyePos());
            float f = (float) Math.toDegrees(Math.atan2(-vec3d.x, vec3d.z));
            float f1 = (float) (-Math.toDegrees(Math.atan2(vec3d.y, Math.hypot(vec3d.x, vec3d.z))));
            float f2 = Math.abs(MathHelper.wrapDegrees(f - client.player.getYaw()));
            float f3 = Math.abs(f1 - client.player.getPitch());
            this.yawSpeed =
                    this.yawSpeed + (Math.min(37.0F, f2 * 0.45F + 0.2F) - this.yawSpeed) * 0.3F;
            this.pitchSpeed =
                    this.pitchSpeed + (Math.min(8.0F, f3 * 0.45F + 0.2F) - this.pitchSpeed) * 0.3F;
            TargetRingRenderer.aim(
                    new Rotation(f, f1),
                    this.yawSpeed,
                    this.pitchSpeed,
                    24.0F,
                    12.0F,
                    2,
                    30,
                    false);
            this.rotating = true;
            return false;
        }
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.reset();
        this.fallConsumed = false;
    }

    @EventHandler(priority = -500)
    public void onAttack(AttackEvent attackEvent) {
        if (!this.attacking
                && !attackEvent.isCancelled()
                && this.previousSlot == -1
                && client.player != null
                && client.world != null
                && client.currentScreen == null
                && !AutoTotemModule.isSwapPending()
                && !SpearSwapModule.isActive()
                && !ShieldBreakerModule.isActive()
                && !DoubleAnchorModule.isActive()) {
            if (client.player.getMainHandStack().isIn(ItemTags.SWORDS)) {
                if (!this.targetSetting.isOn() || this.canSmash()) {
                    if (attackEvent.getTarget() instanceof LivingEntity livingentity
                            && this.isValidTarget(livingentity)) {
                        this.startSwap(livingentity);
                    }
                }
            }
        }
    }
}
