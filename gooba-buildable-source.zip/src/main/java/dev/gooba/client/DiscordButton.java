package dev.gooba.client;

import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

@FieldOrder({"url", "label"})
@Environment(EnvType.CLIENT)
public class DiscordButton extends Structure {

    public byte[] label;
    public byte[] url = new byte[256];

    public DiscordButton() {
        this.label = new byte[64];
    }

    public void setLabel(String text) {
        copyUtf8(this.label, text);
    }

    public static void copyUtf8(byte[] bArray, String text) {
        if (text == null) {
            text = "";
        }

        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        int var3 = Math.min(bytes.length, bArray.length - 1);
        Arrays.fill(bArray, (byte) 0);
        System.arraycopy(bytes, 0, bArray, 0, var3);
    }

    public void setUrl(String text) {
        copyUtf8(this.url, text);
    }
}
