package dev.gooba.client;

import it.unimi.dsi.fastutil.objects.Object2DoubleArrayMap;
import it.unimi.dsi.fastutil.objects.Object2DoubleMap;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.PowderSnowBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

@Environment(EnvType.CLIENT)
public class SimulatedPlayer implements MinecraftAccess {
    public Vec3d position;
    public boolean jumping;

    public boolean gliding;
    private final Object2DoubleMap<TagKey<Fluid>> fluidHeights;
    private final HashSet<TagKey<Fluid>> submergedFluids;
    public boolean horizontalCollision;
    public boolean sprinting;
    public Box boundingBox;
    public final PlayerEntity player;
    public Vec3d velocity;
    public boolean touchingWater;

    public float pitch;
    public float fallDistance;
    public final SimulatedPlayer.SimulatedPlayerInput input;
    public float yaw;
    public int jumpingCooldown;
    public boolean submergedInWater;
    public boolean verticalCollision;
    private int simulatedTicks = 0;
    public boolean swimming;
    public boolean onGround;

    private void resetFallDistance() {
        this.fallDistance = 0.0F;
    }

    private float getBaseMovementSpeed() {
        return 0.1F;
    }

    private boolean isSpaceEmpty(Box box) {
        return this.player.getEntityWorld().isSpaceEmpty(this.player, box)
                && !this.player.getEntityWorld().containsFluid(box);
    }

    public BlockState getBlockStateAt(BlockPos blockpos) {
        return this.player.getEntityWorld().getBlockState(blockpos);
    }

    private boolean isRegionUnloaded() {
        Box boxx = this.boundingBox.expand(1.0);
        int i = MathHelper.floor(boxx.minX);
        int j = MathHelper.ceil(boxx.maxX);
        int k = MathHelper.floor(boxx.minZ);
        int l = MathHelper.ceil(boxx.maxZ);
        return !this.player.getEntityWorld().isRegionLoaded(i, k, j, l);
    }

    private float getAirSpeed() {
        float f = 0.02F;
        return this.input.playerInput.sprint() ? f + 0.006F : f;
    }

    private boolean isClimbableTrapdoor(BlockPos blockpos, BlockState blockstate) {
        if (!blockstate.get(TrapdoorBlock.OPEN)) {
            return false;
        } else {
            BlockState blockState = this.player.getEntityWorld().getBlockState(blockpos.down());
            return blockState.isOf(Blocks.LADDER)
                    && blockState
                            .get(LadderBlock.FACING)
                            .equals(blockstate.get(TrapdoorBlock.FACING));
        }
    }

    public BlockPos floorPosition(Vec3d vec3d) {
        return new BlockPos(
                MathHelper.floor(vec3d.x), MathHelper.floor(vec3d.y), MathHelper.floor(vec3d.z));
    }

    private boolean updateFluidMovement(TagKey<Fluid> tagkey, double d0) {
        if (this.isRegionUnloaded()) {
            return false;
        } else {
            Box boxx = this.boundingBox.contract(0.001);
            int i = MathHelper.floor(boxx.minX);
            int j = MathHelper.ceil(boxx.maxX);
            int k = MathHelper.floor(boxx.minY);
            int l = MathHelper.ceil(boxx.maxY);
            int i1 = MathHelper.floor(boxx.minZ);
            int j1 = MathHelper.ceil(boxx.maxZ);
            double d1 = 0.0;
            boolean flagx = true;
            boolean flag1 = false;
            Vec3d vec3dx = Vec3d.ZERO;
            int k1 = 0;
            Mutable mutable = new Mutable();

            for (int l1 = i; l1 < j; l1++) {
                for (int i2 = k; i2 < l; i2++) {
                    for (int j2 = i1; j2 < j1; j2++) {
                        mutable.set(l1, i2, j2);
                        FluidState fluidstate = this.player.getEntityWorld().getFluidState(mutable);
                        if (fluidstate.isIn(tagkey)) {
                            double d2 =
                                    (double)
                                            ((float) i2
                                                    + fluidstate.getHeight(
                                                            this.player.getEntityWorld(), mutable));
                            if (d2 >= boxx.minY) {
                                flag1 = true;
                                d1 = Math.max(d2 - boxx.minY, d1);
                                if (flagx) {
                                    Vec3d vec3d1 =
                                            fluidstate.getVelocity(
                                                    this.player.getEntityWorld(), mutable);
                                    if (d1 < 0.4) {
                                        vec3d1 = vec3d1.multiply(d1);
                                    }

                                    vec3dx = vec3dx.add(vec3d1);
                                    k1++;
                                }
                            }
                        }
                    }
                }
            }

            if (vec3dx.length() > 0.0) {
                if (k1 > 0) {
                    vec3dx = vec3dx.multiply(1.0 / (double) k1);
                }

                vec3dx = vec3dx.multiply(d0);
                if (Math.abs(this.velocity.x) < 0.003
                        && Math.abs(this.velocity.z) < 0.003
                        && vec3dx.length() < 0.0045) {
                    vec3dx = vec3dx.normalize().multiply(0.0045);
                }

                this.velocity = this.velocity.add(vec3dx);
            }

            this.fluidHeights.put(tagkey, d1);
            return flag1;
        }
    }

    private double getEyeY() {
        return this.position.y + (double) this.player.getStandingEyeHeight();
    }

    private void updateSubmergedFluid() {
        this.submergedInWater = this.submergedFluids.contains(FluidTags.WATER);
        this.submergedFluids.clear();
        double d0 = this.getEyeY() - 0.11111111F;
        if (this.player.getVehicle() instanceof BoatEntity boatentity
                && !boatentity.isSubmergedInWater()
                && boatentity.getBoundingBox().maxY >= d0
                && boatentity.getBoundingBox().minY <= d0) {
            return;
        }

        BlockPos blockpos = BlockPos.ofFloored(this.position.x, d0, this.position.z);
        FluidState fluidstate = this.player.getEntityWorld().getFluidState(blockpos);
        double d1 =
                (double)
                        ((float) blockpos.getY()
                                + fluidstate.getHeight(this.player.getEntityWorld(), blockpos));
        if (d1 > d0) {
            this.submergedFluids.addAll(fluidstate.streamTags().toList());
        }
    }

    private void move(Vec3d vec3d) {
        Vec3d vec3d1 = this.clipAtLedge(vec3d);
        Vec3d vec3d2x = this.adjustMovementForCollisions(vec3d1);
        if (vec3d2x.lengthSquared() > 1.0E-7) {
            this.position = this.position.add(vec3d2x);
            this.boundingBox = this.player.dimensions.getBoxAt(this.position);
        }

        boolean flagx;
        flagx = (!MathHelper.approximatelyEquals(vec3d.x, vec3d2x.x));

        boolean flag1;
        flag1 = (!MathHelper.approximatelyEquals(vec3d.z, vec3d2x.z));

        if (!flagx && !flag1) {
            this.horizontalCollision = false;
        } else {
            this.horizontalCollision = true;
        }

        if (vec3d.y != vec3d2x.y) {
            this.verticalCollision = true;
        } else {
            this.verticalCollision = false;
        }

        if (this.verticalCollision && vec3d.y < 0.0) {
            this.onGround = true;
        } else {
            this.onGround = false;
        }

        if (!this.isTouchingWater()) {
            this.updateWaterState();
        }

        if (this.onGround) {
            this.resetFallDistance();
        } else if (vec3d.y < 0.0) {
            this.fallDistance = this.fallDistance - (float) vec3d.y;
        }

        Vec3d vec3d3 = this.velocity;
        if (this.horizontalCollision || this.verticalCollision) {
            this.velocity =
                    new Vec3d(
                            flagx ? 0.0 : vec3d3.x,
                            this.onGround ? 0.0 : vec3d3.y,
                            flag1 ? 0.0 : vec3d3.z);
        }
    }

    private boolean isOffsetSpaceEmpty(double d0, double d1, double d2) {
        return this.isSpaceEmpty(this.boundingBox.offset(d0, d1, d2));
    }

    private float getJumpVelocity() {
        return 0.42F * this.getJumpVelocityMultiplier() + this.getJumpBoostVelocity();
    }

    private void swimUpward(TagKey<Fluid> tagkey) {
        this.velocity = this.velocity.add(0.0, 0.04F, 0.0);
    }

    protected boolean isSneaking() {
        return this.input.playerInput.sneak() || this.input.forcedSneaking;
    }

    private float getJumpVelocityMultiplier() {
        float f = 0.0F;
        Block block = this.getBlockStateAt(this.floorPosition(this.position)).getBlock();
        if (block != null) {
            f = block.getJumpVelocityMultiplier();
        }

        float f1 = 0.0F;
        Block blockValue = this.getBlockStateAt(this.getSupportingBlockPos()).getBlock();
        if (blockValue != null) {
            f1 = blockValue.getJumpVelocityMultiplier();
        }

        return f == 1.0F ? f1 : f;
    }

    private Vec3d rotationVector(float f, float f1) {
        float f2 = (float) ((double) f * Math.PI / 180.0);
        float f3 = (float) ((double) (-f1) * Math.PI / 180.0);
        float f4 = MathHelper.cos((double) f3);
        float f5 = MathHelper.sin((double) f3);
        float f6 = MathHelper.cos((double) f2);
        float f7 = MathHelper.sin((double) f2);
        return new Vec3d((double) (f5 * f6), (double) (-f7), (double) (f4 * f6));
    }

    private float getJumpBoostVelocity() {
        if (this.hasStatusEffect(StatusEffects.JUMP_BOOST)) {
            StatusEffectInstance statuseffectinstance =
                    this.getStatusEffect(StatusEffects.JUMP_BOOST);
            return 0.1F * (float) (statuseffectinstance.getAmplifier() + 1);
        } else {
            return 0.0F;
        }
    }

    public boolean isClimbing() {
        BlockPos blockpos = this.floorPosition(this.position);
        BlockState blockstate = this.getBlockStateAt(blockpos);
        return blockstate.isIn(BlockTags.CLIMBABLE)
                ? true
                : blockstate.getBlock() instanceof TrapdoorBlock
                        && this.isClimbableTrapdoor(blockpos, blockstate);
    }

    private boolean isSprinting() {
        return this.sprinting;
    }

    private void updateWaterState() {
        if (this.player.getVehicle() instanceof BoatEntity) {
            BoatEntity boatentity = (BoatEntity) this.player.getVehicle();
            if (!boatentity.isSubmergedInWater()) {
                this.touchingWater = false;
                return;
            }
        }

        if (this.updateFluidMovement(FluidTags.WATER, 0.014)) {
            this.resetFallDistance();
            this.touchingWater = true;
        } else {
            this.touchingWater = false;
        }
    }

    public static SimulatedPlayer predict(int i) {
        SimulatedPlayer simulatedPlayer =
                fromClient(
                        SimulatedPlayer.SimulatedPlayerInput.fromInput(
                                client.player.input.playerInput));

        for (int j = 0; j < i; j++) {
            simulatedPlayer.tick();
        }

        return simulatedPlayer;
    }

    private float getMovementSpeed(float f) {
        return this.onGround
                ? this.getBaseMovementSpeed() * (0.21600002F / (f * f * f))
                : this.getAirSpeed();
    }

    public boolean hasStatusEffect(RegistryEntry<StatusEffect> registryentry) {
        StatusEffectInstance statuseffectinstance = this.player.getStatusEffect(registryentry);
        return statuseffectinstance != null
                && statuseffectinstance.getDuration() >= this.simulatedTicks;
    }

    public double getAttributeValue(RegistryEntry<EntityAttribute> registryentry) {
        return this.player.getAttributes().getValue(registryentry);
    }

    private double getFluidHeight(TagKey<Fluid> tagkey) {
        return this.fluidHeights.getDouble(tagkey);
    }

    public boolean isInLava() {
        return this.fluidHeights.getDouble(FluidTags.LAVA) > 0.0;
    }

    private Vec3d getRotationVector() {
        return this.rotationVector(this.pitch, this.yaw);
    }

    private boolean isTouchingWater() {
        return this.touchingWater;
    }

    public static SimulatedPlayer fromClient(
            SimulatedPlayer.SimulatedPlayerInput simulatedPlayerInputValue) {
        ClientPlayerEntity clientplayerentity = client.player;
        return new SimulatedPlayer(
                clientplayerentity,
                simulatedPlayerInputValue,
                clientplayerentity.getEntityPos(),
                clientplayerentity.getVelocity(),
                clientplayerentity.getBoundingBox(),
                clientplayerentity.getYaw(),
                clientplayerentity.getPitch(),
                clientplayerentity.isSprinting(),
                (float) clientplayerentity.fallDistance,
                clientplayerentity.jumpingCooldown,
                clientplayerentity.jumping,
                clientplayerentity.isGliding(),
                clientplayerentity.isOnGround(),
                clientplayerentity.horizontalCollision,
                clientplayerentity.verticalCollision,
                clientplayerentity.isTouchingWater(),
                clientplayerentity.isSwimming(),
                clientplayerentity.isSubmergedInWater(),
                new Object2DoubleArrayMap<>(clientplayerentity.fluidHeight),
                new HashSet<>(clientplayerentity.submergedFluidTag));
    }

    private Vec3d applyClimbingSpeed(Vec3d vec3d) {
        if (!this.isClimbing()) {
            return vec3d;
        } else {
            this.resetFallDistance();
            double d0 = MathHelper.clamp(vec3d.x, -0.15F, 0.15F);
            double d1 = MathHelper.clamp(vec3d.z, -0.15F, 0.15F);
            double d2 = Math.max(vec3d.y, -0.15F);
            if (d2 < 0.0
                    && !this.getBlockStateAt(this.floorPosition(this.position))
                            .isOf(Blocks.SCAFFOLDING)
                    && this.player.isHoldingOntoLadder()) {
                d2 = 0.0;
            }

            return new Vec3d(d0, d2, d1);
        }
    }

    public SimulatedPlayer(
            PlayerEntity playerentity,
            SimulatedPlayer.SimulatedPlayerInput simulatedPlayerInputValue,
            Vec3d vec3d,
            Vec3d vec3d1,
            Box box,
            float yawValue,
            float pitchValue,
            boolean sprintingValue,
            float fallDistanceValue,
            int jumpingCooldownValue,
            boolean jumpingValue,
            boolean glidingValue,
            boolean onGroundValue,
            boolean horizontalCollisionValue,
            boolean verticalCollisionValue,
            boolean touchingWaterValue,
            boolean swimmingValue,
            boolean submergedInWaterValue,
            Object2DoubleMap<TagKey<Fluid>> object2doublemap,
            HashSet<TagKey<Fluid>> hashset) {

        this.player = playerentity;
        this.input = simulatedPlayerInputValue;
        this.position = vec3d;
        this.velocity = vec3d1;
        this.boundingBox = box;
        this.yaw = yawValue;
        this.pitch = pitchValue;
        this.sprinting = sprintingValue;
        this.fallDistance = fallDistanceValue;
        this.jumpingCooldown = jumpingCooldownValue;
        this.jumping = jumpingValue;
        this.gliding = glidingValue;
        this.onGround = onGroundValue;
        this.horizontalCollision = horizontalCollisionValue;
        this.verticalCollision = verticalCollisionValue;
        this.touchingWater = touchingWaterValue;
        this.swimming = swimmingValue;
        this.submergedInWater = submergedInWaterValue;
        this.fluidHeights = object2doublemap;
        this.submergedFluids = hashset;
    }

    public boolean isSubmergedInWater() {
        return this.submergedInWater && this.isTouchingWater();
    }

    private void updateSwimming() {
        if (this.swimming) {
            if (this.isSprinting() && this.isTouchingWater() && !this.player.hasVehicle()) {
                this.swimming = true;
            } else {
                this.swimming = false;
            }
        } else if (this.isSprinting()
                && this.isSubmergedInWater()
                && !this.player.hasVehicle()
                && this.player
                        .getEntityWorld()
                        .getFluidState(this.floorPosition(this.position))
                        .isIn(FluidTags.WATER)) {
            this.swimming = true;
        } else {
            this.swimming = false;
        }
    }

    private boolean canClipAtLedge() {
        return this.onGround
                || (double) this.fallDistance < 0.5
                        && !this.player
                                .getEntityWorld()
                                .isSpaceEmpty(
                                        this.player,
                                        this.boundingBox.offset(
                                                0.0, (double) this.fallDistance - 0.5, 0.0));
    }

    private StatusEffectInstance getStatusEffect(RegistryEntry<StatusEffect> registryentry) {
        StatusEffectInstance statuseffectinstance = this.player.getStatusEffect(registryentry);
        return statuseffectinstance != null
                        && statuseffectinstance.getDuration() >= this.simulatedTicks
                ? statuseffectinstance
                : null;
    }

    private double getSwimHeight() {
        return (double) this.player.getStandingEyeHeight() < 0.4 ? 0.0 : 0.4;
    }

    public void jump() {
        this.velocity =
                this.velocity.add(0.0, (double) this.getJumpVelocity() - this.velocity.y, 0.0);
        if (this.isSprinting()) {
            float f = (float) Math.toRadians((double) this.yaw);
            this.velocity =
                    this.velocity.add(
                            (double) (-MathHelper.sin((double) f)) * 0.2,
                            0.0,
                            (double) MathHelper.cos((double) f) * 0.2);
        }
    }

    private BlockPos getSupportingBlockPos() {
        return BlockPos.ofFloored(
                this.position.x, this.boundingBox.minY - 0.5000001, this.position.z);
    }

    public void tick() {
        this.simulatedTicks++;

        if (!(this.position.y <= -70.0)) {
            this.input.updateMovement();
            this.updateWaterState();
            this.updateSubmergedFluid();
            this.updateSwimming();
            if (this.jumpingCooldown > 0) {
                this.jumpingCooldown--;
            }

            this.jumping = this.input.playerInput.jump();
            double d0 = this.velocity.x;
            double d1 = this.velocity.y;
            double d2 = this.velocity.z;
            if (Math.abs(this.velocity.x) < 0.003) {
                d0 = 0.0;
            }

            if (Math.abs(this.velocity.y) < 0.003) {
                d1 = 0.0;
            }

            if (Math.abs(this.velocity.z) < 0.003) {
                d2 = 0.0;
            }

            if (this.onGround) {
                this.gliding = false;
            }

            this.velocity = new Vec3d(d0, d1, d2);
            if (this.jumping) {
                double d3;
                if (this.isInLava()) {
                    d3 = this.getFluidHeight(FluidTags.LAVA);
                } else {
                    d3 = this.getFluidHeight(FluidTags.WATER);
                }

                boolean flagx;
                double d4;
                if (this.isTouchingWater() && d3 > 0.0) {
                    flagx = true;
                    d4 = this.getSwimHeight();
                } else {
                    flagx = false;
                    d4 = this.getSwimHeight();
                }

                if (!flagx || this.onGround && !(d3 > d4)) {
                    if (!this.isInLava() || this.onGround && !(d3 > d4)) {
                        if ((this.onGround || flagx && d3 <= d4) && this.jumpingCooldown == 0) {
                            this.jump();
                            this.jumpingCooldown = 10;
                        }
                    } else {
                        this.swimUpward(FluidTags.LAVA);
                    }
                } else {
                    this.swimUpward(FluidTags.WATER);
                }
            }

            float f1 = this.input.sidewaysMovement * 0.98F;
            float f = this.input.forwardMovement * 0.98F;
            float f2 = 0.0F;
            if (this.hasStatusEffect(StatusEffects.SLOW_FALLING)
                    || this.hasStatusEffect(StatusEffects.LEVITATION)) {
                this.resetFallDistance();
            }

            this.travel(new Vec3d((double) f1, (double) f2, (double) f));
        }
    }

    private Vec3d adjustMovementForCollisions(Vec3d vec3d) {
        Box boxx = new Box(-0.3, 0.0, -0.3, 0.3, 1.8, 0.3).offset(this.position);
        List list = Collections.emptyList();
        Vec3d vec3d1;
        if (vec3d.lengthSquared() == 0.0) {
            vec3d1 = vec3d;
        } else {
            vec3d1 =
                    Entity.adjustMovementForCollisions(
                            this.player, vec3d, boxx, this.player.getEntityWorld(), list);
        }

        boolean flagx;
        flagx = (vec3d.x != vec3d1.x);

        boolean flag1;
        flag1 = (vec3d.y != vec3d1.y);

        boolean flag2x;
        flag2x = (vec3d.z != vec3d1.z);

        boolean flag3x;
        flag3x = (this.onGround || flag1 && vec3d.y < 0.0);

        if (this.player.getStepHeight() > 0.0F && flag3x && (flagx || flag2x)) {
            Vec3d vec3d2x =
                    Entity.adjustMovementForCollisions(
                            this.player,
                            new Vec3d(vec3d.x, (double) this.player.getStepHeight(), vec3d.z),
                            boxx,
                            this.player.getEntityWorld(),
                            list);
            Vec3d vec3d3 =
                    Entity.adjustMovementForCollisions(
                            this.player,
                            new Vec3d(0.0, (double) this.player.getStepHeight(), 0.0),
                            boxx.stretch(vec3d.x, 0.0, vec3d.z),
                            this.player.getEntityWorld(),
                            list);
            Vec3d vec3d4 =
                    Entity.adjustMovementForCollisions(
                                    this.player,
                                    new Vec3d(vec3d.x, 0.0, vec3d.z),
                                    boxx.offset(vec3d3),
                                    this.player.getEntityWorld(),
                                    list)
                            .add(vec3d3);
            if (vec3d3.y < (double) this.player.getStepHeight()
                    && vec3d4.horizontalLengthSquared() > vec3d2x.horizontalLengthSquared()) {
                vec3d2x = vec3d4;
            }

            if (vec3d2x.horizontalLengthSquared() > vec3d1.horizontalLengthSquared()) {
                return vec3d2x.add(
                        Entity.adjustMovementForCollisions(
                                this.player,
                                new Vec3d(0.0, -vec3d2x.y + vec3d.y, 0.0),
                                boxx.offset(vec3d2x),
                                this.player.getEntityWorld(),
                                list));
            }
        }

        return vec3d1;
    }

    private Vec3d clipAtLedge(Vec3d vec3d) {
        if (vec3d.y <= 0.0 && this.canClipAtLedge()) {
            double d0 = vec3d.x;
            double d1 = vec3d.z;

            double d2;
            for (d2 = 0.05;
                    d0 != 0.0
                            && this.player
                                    .getEntityWorld()
                                    .isSpaceEmpty(
                                            this.player, this.boundingBox.offset(d0, -0.5, 0.0));
                    d0 += d0 > 0.0 ? -d2 : d2) {
                if (d0 < d2 && d0 >= -d2) {
                    d0 = 0.0;
                    break;
                }
            }

            while (d1 != 0.0
                    && this.player
                            .getEntityWorld()
                            .isSpaceEmpty(this.player, this.boundingBox.offset(0.0, -0.5, d1))) {
                if (d1 < d2 && d1 >= -d2) {
                    d1 = 0.0;
                    break;
                }

                d1 += d1 > 0.0 ? -d2 : d2;
            }

            while (d0 != 0.0
                    && d1 != 0.0
                    && this.player
                            .getEntityWorld()
                            .isSpaceEmpty(this.player, this.boundingBox.offset(d0, -0.5, d1))) {
                if (d0 < d2 && d0 >= -d2) {
                    d0 = 0.0;
                } else if (d0 > 0.0) {
                    d0 -= d2;
                } else {
                    d0 += d2;
                }

                if (d1 < d2 && d1 >= -d2) {
                    d1 = 0.0;
                    break;
                }

                d1 += d1 > 0.0 ? -d2 : d2;
            }

            if (vec3d.x != d0 || vec3d.z != d1) {}

            if (this.isSneaking()) {
                vec3d = new Vec3d(d0, vec3d.y, d1);
            }
        }

        return vec3d;
    }

    private void travel(Vec3d vec3d) {
        if (this.swimming && !this.player.hasVehicle()) {
            double d0 = this.getRotationVector().y;
            double d1;
            if (d0 < -0.2) {
                d1 = 0.085;
            } else {
                d1 = 0.06;
            }

            BlockPos blockpos =
                    new BlockPos(
                            MathHelper.floor(this.position.x),
                            MathHelper.floor(this.position.y + 1.0 - 0.1),
                            MathHelper.floor(this.position.z));
            if (d0 <= 0.0
                    || this.input.playerInput.jump()
                    || !this.player
                            .getEntityWorld()
                            .getBlockState(blockpos)
                            .getFluidState()
                            .isEmpty()) {
                this.velocity = this.velocity.add(0.0, (d0 - this.velocity.y) * d1, 0.0);
            }
        }

        double d6 = this.velocity.y;
        double d7 = 0.08;
        boolean flagx;
        flagx = (this.velocity.y <= 0.0);

        if (this.velocity.y <= 0.0 && this.hasStatusEffect(StatusEffects.SLOW_FALLING)) {
            d7 = 0.01;
            this.resetFallDistance();
        }

        if (this.isTouchingWater() && this.player.shouldSwimInFluids()) {
            double d10 = this.position.y;
            float f4;
            float f5;
            float f6;
            if (this.isSprinting()) {
                f4 = 0.9F;
                f5 = 0.02F;
                f6 = (float) this.getAttributeValue(EntityAttributes.WATER_MOVEMENT_EFFICIENCY);
            } else {
                f4 = 0.8F;
                f5 = 0.02F;
                f6 = (float) this.getAttributeValue(EntityAttributes.WATER_MOVEMENT_EFFICIENCY);
            }

            if (!this.onGround) {
                f6 *= 0.5F;
            }

            if (f6 > 0.0F) {
                f4 += (0.54600006F - f4) * f6 / 3.0F;
                f5 += (this.getBaseMovementSpeed() - f5) * f6 / 3.0F;
            }

            if (this.hasStatusEffect(StatusEffects.DOLPHINS_GRACE)) {
                f4 = 0.96F;
            }

            this.accelerate(f5, vec3d);
            this.move(this.velocity);
            Vec3d vec3d4 = this.velocity;
            if (this.horizontalCollision && this.isClimbing()) {
                vec3d4 = new Vec3d(vec3d4.x, 0.2, vec3d4.z);
            }

            this.velocity = vec3d4.multiply((double) f4, 0.8, (double) f4);
            Vec3d vec3d5 = this.player.applyFluidMovingSpeed(d7, flagx, this.velocity);
            this.velocity = vec3d5;
            if (this.horizontalCollision
                    && this.isOffsetSpaceEmpty(
                            vec3d5.x, vec3d5.y + 0.6 - this.position.y + d10, vec3d5.z)) {
                this.velocity = new Vec3d(vec3d5.x, 0.3, vec3d5.z);
            }
        } else if (this.isInLava() && this.player.shouldSwimInFluids()) {
            double d9 = this.position.y;
            this.accelerate(0.02F, vec3d);
            this.move(this.velocity);
            if (this.getFluidHeight(FluidTags.LAVA) <= this.getSwimHeight()) {
                this.velocity = this.velocity.multiply(0.5, 0.8, 0.5);
                this.velocity = this.player.applyFluidMovingSpeed(d7, flagx, this.velocity);
            } else {
                this.velocity = this.velocity.multiply(0.5);
            }

            if (!this.player.hasNoGravity()) {
                this.velocity = this.velocity.add(0.0, -d7 / 4.0, 0.0);
            }

            if (this.horizontalCollision
                    && this.isOffsetSpaceEmpty(
                            this.velocity.x,
                            this.velocity.y + 0.6 - this.position.y + d9,
                            this.velocity.z)) {
                this.velocity = new Vec3d(this.velocity.x, 0.3, this.velocity.z);
            }
        } else if (this.gliding) {
            Vec3d vec3d1 = this.velocity;
            if (vec3d1.y > -0.5) {
                this.fallDistance = 1.0F;
            }

            Vec3d vec3d2x = this.getRotationVector();
            float f1 = this.pitch * (float) (Math.PI / 180.0);
            double d3 = Math.sqrt(vec3d2x.x * vec3d2x.x + vec3d2x.z * vec3d2x.z);
            double d4 = this.velocity.horizontalLength();
            double count = vec3d2x.length();
            float f2 = MathHelper.cos((double) f1);
            f2 = (float) ((double) f2 * (double) f2 * Math.min(1.0, count / 0.4));
            vec3d1 = this.velocity.add(0.0, d7 * (-1.0 + (double) f2 * 0.75), 0.0);
            if (vec3d1.y < 0.0 && d3 > 0.0) {
                double d2 = vec3d1.y * -0.1 * (double) f2;
                vec3d1 = vec3d1.add(vec3d2x.x * d2 / d3, d2, vec3d2x.z * d2 / d3);
            }

            if (f1 < 0.0F && d3 > 0.0) {
                double d8 = d4 * (double) (-MathHelper.sin((double) f1)) * 0.04;
                vec3d1 = vec3d1.add(-vec3d2x.x * d8 / d3, d8 * 3.2, -vec3d2x.z * d8 / d3);
            }

            if (d3 > 0.0) {
                vec3d1 =
                        vec3d1.add(
                                (vec3d2x.x / d3 * d4 - vec3d1.x) * 0.1,
                                0.0,
                                (vec3d2x.z / d3 * d4 - vec3d1.z) * 0.1);
            }

            this.velocity = vec3d1.multiply(0.99, 0.98, 0.99);
            this.move(this.velocity);
        } else {
            BlockPos blockPos = this.getSupportingBlockPos();
            float slipperiness =
                    this.player
                            .getEntityWorld()
                            .getBlockState(blockPos)
                            .getBlock()
                            .getSlipperiness();
            float f3;
            Vec3d vec3d3;
            double d11;
            if (this.onGround) {
                f3 = slipperiness * 0.91F;
                vec3d3 = this.applyMovementInput(vec3d, slipperiness);
                d11 = vec3d3.y;
            } else {
                f3 = 0.91F;
                vec3d3 = this.applyMovementInput(vec3d, slipperiness);
                d11 = vec3d3.y;
            }

            if (this.hasStatusEffect(StatusEffects.LEVITATION)) {
                StatusEffectInstance statuseffectinstance =
                        this.getStatusEffect(StatusEffects.LEVITATION);
                if (statuseffectinstance != null) {
                    d11 +=
                            (0.05 * (double) (statuseffectinstance.getAmplifier() + 1) - vec3d3.y)
                                    * 0.2;
                }
            } else if (this.player.getEntityWorld().isClient()
                    && !this.player.getEntityWorld().isChunkLoaded(blockPos)) {
                if (this.position.y > (double) this.player.getEntityWorld().getBottomY()) {
                    d11 = -0.1;
                } else {
                    d11 = 0.0;
                }
            } else if (!this.player.hasNoGravity()) {
                d11 -= d7;
            }

            if (this.player.hasNoDrag()) {
                this.velocity = new Vec3d(vec3d3.x, d11, vec3d3.z);
            } else {
                this.velocity =
                        new Vec3d(vec3d3.x * (double) f3, d11 * 0.98F, vec3d3.z * (double) f3);
            }
        }

        if (this.player.getAbilities().flying && !this.player.hasVehicle()) {
            this.velocity = new Vec3d(this.velocity.x, d6 * 0.6, this.velocity.z);
            this.resetFallDistance();
        }
    }

    private void accelerate(float f, Vec3d vec3d) {
        Vec3d vec3d1 = Entity.movementInputToVelocity(vec3d, f, this.yaw);
        this.velocity = this.velocity.add(vec3d1);
    }

    private Vec3d applyMovementInput(Vec3d vec3d, float f) {
        this.accelerate(this.getMovementSpeed(f), vec3d);
        this.velocity = this.applyClimbingSpeed(this.velocity);
        this.move(this.velocity);
        Vec3d vec3d1 = this.velocity;
        BlockPos blockpos = this.floorPosition(this.position);
        BlockState blockstate = this.getBlockStateAt(blockpos);
        if ((this.horizontalCollision || this.jumping)
                && (this.isClimbing()
                        || blockstate != null
                                && blockstate.isOf(Blocks.POWDER_SNOW)
                                && PowderSnowBlock.canWalkOnPowderSnow(this.player))) {
            vec3d1 = new Vec3d(vec3d1.x, 0.2, vec3d1.z);
        }

        return vec3d1;
    }

    @Environment(EnvType.CLIENT)
    public static class SimulatedPlayerInput extends Input {
        public boolean forcedSneaking = false;
        public PlayerInput playerInput;
        public float forwardMovement;
        public float sidewaysMovement;

        public static SimulatedPlayer.SimulatedPlayerInput fromInput(PlayerInput playerinput) {
            return new SimulatedPlayer.SimulatedPlayerInput(playerinput);
        }

        @Override
        public String toString() {
            boolean flag7 = this.playerInput.forward();
            boolean flag8 = this.playerInput.backward();
            boolean flag9 = this.playerInput.left();
            boolean flag10 = this.playerInput.right();
            boolean flag11 = this.playerInput.jump();
            boolean flag6 = this.playerInput.sneak();
            boolean flag5 = this.playerInput.sprint();
            boolean flag4 = flag11;
            boolean flag3 = flag10;
            boolean flag2 = flag9;
            boolean flag1 = flag8;
            boolean flagx = flag7;
            return "SimulatedPlayerInput(forwards={"
                    + flagx
                    + "}, backwards={"
                    + flag1
                    + "}, left={"
                    + flag2
                    + "}, right={"
                    + flag3
                    + "}, jumping={"
                    + flag4
                    + "}, sprinting="
                    + flag5
                    + ", slowDown="
                    + flag6
                    + ")";
        }

        public SimulatedPlayerInput(PlayerInput playerinput) {
            this.playerInput = playerinput;
        }

        public void updateMovement() {
            if (this.playerInput.forward() != this.playerInput.backward()) {
                this.forwardMovement = this.playerInput.forward() ? 1.0F : -1.0F;
            } else {
                this.forwardMovement = 0.0F;
            }

            if (this.playerInput.left() == this.playerInput.right()) {
                this.sidewaysMovement = 0.0F;
            } else {
                this.sidewaysMovement = this.playerInput.left() ? 1.0F : -1.0F;
            }

            if (this.playerInput.sneak()) {
                this.sidewaysMovement *= 0.3F;
                this.forwardMovement *= 0.3F;
            }
        }
    }
}
