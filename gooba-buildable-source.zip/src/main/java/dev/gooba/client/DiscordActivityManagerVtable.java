package dev.gooba.client;

import com.sun.jna.Callback;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FieldOrder({
    "update_activity",
    "clear_activity",
    "send_request_reply",
    "accept_request",
    "deny_request",
    "send_invite",
    "accept_invite",
    "reject_invite"
})
@Environment(EnvType.CLIENT)
public class DiscordActivityManagerVtable extends Structure {
    public DiscordActivityManagerVtable.DenyRequestFunc deny_request;
    public DiscordActivityManagerVtable.RejectInviteFunc reject_invite;
    public DiscordActivityManagerVtable.SendRequestReplyFunc send_request_reply;
    public DiscordActivityManagerVtable.AcceptRequestFunc accept_request;
    public DiscordActivityManagerVtable.ClearActivityFunc clear_activity;
    public DiscordActivityManagerVtable.SendInviteFunc send_invite;
    public DiscordActivityManagerVtable.AcceptInviteFunc accept_invite;
    public DiscordActivityManagerVtable.UpdateActivityFunc update_activity;

    @Environment(EnvType.CLIENT)
    public interface AcceptInviteFunc extends Callback {
        int invoke(long i, long j, Pointer pointer, Callback callback);
    }

    @Environment(EnvType.CLIENT)
    public interface AcceptRequestFunc extends Callback {
        int invoke(long i, long j, Pointer pointer, Callback callback);
    }

    @Environment(EnvType.CLIENT)
    public interface ClearActivityFunc extends Callback {
        int invoke(
                long i,
                Pointer pointer,
                DiscordActivityManager.UpdateActivityCallback updateactivitycallback);
    }

    @Environment(EnvType.CLIENT)
    public interface DenyRequestFunc extends Callback {
        int invoke(long i, long j, Pointer pointer, Callback callback);
    }

    @Environment(EnvType.CLIENT)
    public interface RejectInviteFunc extends Callback {
        int invoke(long i, long j, Pointer pointer, Callback callback);
    }

    @Environment(EnvType.CLIENT)
    public interface SendInviteFunc extends Callback {
        int invoke(long i, long j, int k, String text, Pointer pointer, Callback callback);
    }

    @Environment(EnvType.CLIENT)
    public interface SendRequestReplyFunc extends Callback {
        int invoke(long i, long j, int k, Pointer pointer, Callback callback);
    }

    @Environment(EnvType.CLIENT)
    public interface UpdateActivityFunc extends Callback {
        int invoke(
                long i,
                DiscordActivity discordActivity,
                Pointer pointer,
                DiscordActivityManager.UpdateActivityCallback updateactivitycallback);
    }
}
