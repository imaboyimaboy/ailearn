package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public final class CollisionUtils implements MinecraftAccess {
    public static boolean containsBlock(Box box, Block block) {
        return anyBlockMatches(
                box, blockpos -> client.world.getBlockState(blockpos).getBlock().equals(block));
    }

    public static boolean isTouchingBlock(Block block) {
        return containsBlock(client.player.getBoundingBox().expand(-0.001), block);
    }

    public static boolean canFitPose(EntityPose entitypose) {
        return client.player
                .getEntityWorld()
                .isSpaceEmpty(
                        client.player,
                        client.player
                                .getDimensions(entitypose)
                                .getBoxAt(client.player.getEntityPos())
                                .contract(1.0E-7));
    }

    public static boolean isCriticalPrevented() {
        return client.player.hasStatusEffect(StatusEffects.BLINDNESS)
                || client.player.hasStatusEffect(StatusEffects.LEVITATION)
                || isTouchingBlock(Blocks.COBWEB)
                || client.player.isSubmergedInWater()
                || client.player.isInLava()
                || client.player.isClimbing()
                || !canFitPose(EntityPose.STANDING) && client.player.isInSneakingPose()
                || client.player.getAbilities().flying;
    }

    public static boolean anyBlockMatches(Box box, Predicate<BlockPos> predicate) {
        return BlockPos.stream(box).anyMatch(predicate);
    }

    public static boolean canCriticalThisFall() {
        boolean flag;
        flag =
                (client.player.fallDistance > 0.0
                        && (client.player.fallDistance < 0.08
                                || !SimulatedPlayer.predict(1).onGround));

        return !client.player.isOnGround() && flag;
    }

    private CollisionUtils() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }
}
