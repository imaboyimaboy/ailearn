package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Auto Mine",
        category = ModuleCategory.OTHER,
        desc = "Mines the block under the crosshair.")
@Environment(EnvType.CLIENT)
public class AutoMineModule extends Module {
    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        client.options.attackKey.setPressed(
                client.player != null && client.world != null && client.currentScreen == null);
    }

    @Override
    protected void onDisable() {
        if (client.options != null) {
            client.options.attackKey.setPressed(false);
        }
    }
}
