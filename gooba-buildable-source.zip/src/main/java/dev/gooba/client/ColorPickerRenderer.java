package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public final class ColorPickerRenderer {
    public static final RenderPipeline HUE_PIPELINE = createPipeline("color_picker_hue");

    public static final RenderPipeline ICON_OUTLINE_PIPELINE =
            createPipeline("color_picker_icon_outline");

    public static final RenderPipeline ALPHA_PIPELINE = createPipeline("color_picker_alpha");
    public static final RenderPipeline MSDF_ICON_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder()
                            .withLocation(
                                    Identifier.of("client", "pipeline/color_picker_msdf_icon"))
                            .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
                            .withUniform("Projection", UniformType.UNIFORM_BUFFER)
                            .withVertexShader(Identifier.of("client", "core/toggle_msdf"))
                            .withFragmentShader(Identifier.of("client", "core/toggle_msdf"))
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .build());
    public static final RenderPipeline BACKGROUND_PIPELINE =
            createPipeline("color_picker_background_fill");
    public static final RenderPipeline ICON_FILL_PIPELINE =
            createPipeline("color_picker_icon_fill");
    public static final RenderPipeline AREA_PIPELINE = createPipeline("color_picker_area");
    public static final RenderPipeline CURSOR_PIPELINE = createPipeline("color_picker_cursor");

    private static RenderPipeline createPipeline(String text) {
        return RenderPipelines.register(
                RenderPipeline.builder()
                        .withLocation(Identifier.of("client", "pipeline/" + text))
                        .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
                        .withUniform("Projection", UniformType.UNIFORM_BUFFER)
                        .withVertexShader(Identifier.of("client", "core/toggle_rounded_fill"))
                        .withFragmentShader(Identifier.of("client", "core/" + text))
                        .withBlend(BlendFunction.TRANSLUCENT)
                        .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                        .build());
    }

    private ColorPickerRenderer() {}
}
