package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class ScrollAnimation {
    private boolean enabled;
    private double scrollOffset;
    private final MinecraftClient minecraftClient = MinecraftClient.getInstance();

    public void setEnabled(boolean enabledValue) {
        this.enabled = enabledValue;
    }

    public ScrollAnimation() {
        this.setEnabled(true);
        GLFW.glfwSetScrollCallback(
                this.minecraftClient.getWindow().getHandle(),
                (i, d0, d1) -> this.scrollOffset += d1);
    }
}
