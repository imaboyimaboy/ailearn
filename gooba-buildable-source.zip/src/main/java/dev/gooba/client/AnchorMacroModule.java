package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;

import org.lwjgl.glfw.GLFW;

@ModuleInfo(
        name = "Anchor Macro",
        desc = "Charges and detonates respawn anchors",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class AnchorMacroModule extends Module {
    private int lastSelectedSlot;
    private final BooleanSetting autoExplodeSetting;
    private boolean sequenceActive;
    private final BooleanSetting spamSetting;

    private boolean activationConsumed;
    private final SliderSetting chargeDelaySetting;
    private final SliderSetting totemSlotSetting;
    private final SliderSetting delaySetting =
            new SliderSetting(this, "Delay", 0.0F, 0.0F, 500.0F, 5.0F);
    private long lastSwitchMillis;
    private long lastChargeMillis;

    private void interactBlock(BlockHitResult blockhitresult) {
        MouseSimulator.click(1);
        ActionResult actionresult =
                client.interactionManager.interactBlock(
                        client.player, Hand.MAIN_HAND, blockhitresult);
        if (actionresult.isAccepted()) {
            client.player.swingHand(Hand.MAIN_HAND);
        }
    }

    @Override
    protected void onDisable() {
        this.reset();
        super.onDisable();
    }

    private boolean selectSlotAndWait(int lastSelectedSlotValue, long lastSwitchMillisValue) {
        if (lastSelectedSlotValue >= 0 && lastSelectedSlotValue <= 8) {
            if (client.player.getInventory().getSelectedSlot() == lastSelectedSlotValue) {
                return this.hasSwitchDelayElapsed(lastSwitchMillisValue);
            } else {
                this.selectSlot(lastSelectedSlotValue, lastSwitchMillisValue);
                return this.delaySetting.getFloat() <= 0.0F;
            }
        } else {
            return false;
        }
    }

    public AnchorMacroModule() {
        this.chargeDelaySetting = new SliderSetting(this, "Charge Delay", 0.0F, 0.0F, 500.0F, 5.0F);
        this.totemSlotSetting = new SliderSetting(this, "Totem Slot", 1.0F, 1.0F, 9.0F, 1.0F);
        this.autoExplodeSetting = new BooleanSetting(this, "Auto Explode", false);
        this.spamSetting = new BooleanSetting(this, "Spam", true);
        this.lastSelectedSlot = -1;
    }

    @Override
    protected void onEnable() {
        this.reset();
        super.onEnable();
    }

    private void suppressUse() {
        MouseSimulator.suppressUse(75L);
        client.options.useKey.setPressed(false);
    }

    private boolean isUseHeld() {
        return GLFW.glfwGetMouseButton(client.getWindow().getHandle(), 1) == 1;
    }

    private void reset() {
        this.lastChargeMillis = 0L;
        this.lastSwitchMillis = 0L;
        this.lastSelectedSlot = -1;
        this.activationConsumed = false;
        this.sequenceActive = false;
    }

    private int findHotbarItem(Item item) {
        for (int i = 0; i < 9; i++) {
            ItemStack itemstack = client.player.getInventory().getStack(i);
            if (itemstack.isOf(item)) {
                return i;
            }
        }

        return -1;
    }

    private void selectSlot(int lastSelectedSlotValue, long lastSwitchMillisValue) {
        if (lastSelectedSlotValue >= 0
                && lastSelectedSlotValue <= 8
                && client.player.getInventory().getSelectedSlot() != lastSelectedSlotValue) {
            client.player.getInventory().setSelectedSlot(lastSelectedSlotValue);
            client.interactionManager.syncSelectedSlot();
            this.lastSelectedSlot = lastSelectedSlotValue;
            this.lastSwitchMillis = lastSwitchMillisValue;
        }
    }

    private boolean hasSwitchDelayElapsed(long i) {
        int selectedSlot = client.player.getInventory().getSelectedSlot();
        return selectedSlot != this.lastSelectedSlot
                || i - this.lastSwitchMillis >= (long) Math.round(this.delaySetting.getFloat());
    }

    private boolean selectItemAndWait(Item item, long lastSwitchMillisValue) {
        if (client.player.getMainHandStack().isOf(item)) {
            return this.hasSwitchDelayElapsed(lastSwitchMillisValue);
        } else {
            int lastSelectedSlotValue = this.findHotbarItem(item);
            if (lastSelectedSlotValue == -1) {
                return false;
            } else {
                this.selectSlot(lastSelectedSlotValue, lastSwitchMillisValue);
                return this.delaySetting.getFloat() <= 0.0F;
            }
        }
    }

    @EventHandler
    public void onPreClientTick(PreClientTickEvent preClientTickEvent) {
        if (client.player == null
                || client.world == null
                || client.interactionManager == null
                || client.currentScreen != null) {
            this.reset();
        } else if (!DoubleAnchorModule.shouldSuppressUse()
                && !SafeAnchorModule.shouldSuppressUse()) {
            boolean isUseHeld = this.isUseHeld();
            if (!isUseHeld) {
                this.activationConsumed = false;
                this.sequenceActive = false;
                this.lastSelectedSlot = -1;
                this.lastSwitchMillis = 0L;
            } else if (!this.activationConsumed || this.spamSetting.isOn() || this.sequenceActive) {
                if (client.crosshairTarget instanceof BlockHitResult blockhitresult
                        && blockhitresult.getType() == Type.BLOCK) {
                    BlockState blockstate =
                            client.world.getBlockState(blockhitresult.getBlockPos());
                    if (!blockstate.isOf(Blocks.RESPAWN_ANCHOR)) {
                        return;
                    }

                    this.activationConsumed = true;
                    this.sequenceActive = true;
                    this.suppressUse();
                    long nowMillis = System.currentTimeMillis();
                    if (blockstate.get(RespawnAnchorBlock.CHARGES) == 0) {
                        if (nowMillis - this.lastChargeMillis
                                < (long) Math.round(this.chargeDelaySetting.getFloat())) {
                            return;
                        }

                        if (!this.selectItemAndWait(Items.GLOWSTONE, nowMillis)) {
                            return;
                        }

                        this.interactBlock(blockhitresult);
                        this.lastChargeMillis = nowMillis;
                        return;
                    }

                    if (!this.selectSlotAndWait(
                            Math.round(this.totemSlotSetting.getFloat()) - 1, nowMillis)) {
                        return;
                    }

                    if (!this.autoExplodeSetting.isOn()) {
                        this.sequenceActive = false;
                        return;
                    }

                    if (!client.player.getMainHandStack().isOf(Items.GLOWSTONE)
                            && !client.player.getOffHandStack().isOf(Items.GLOWSTONE)) {
                        this.interactBlock(blockhitresult);
                        this.sequenceActive = false;
                        return;
                    }

                    return;
                }
            }
        }
    }
}
