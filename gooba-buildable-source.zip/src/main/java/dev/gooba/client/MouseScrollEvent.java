package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class MouseScrollEvent extends CancellableEvent {
    private final double vertical;
    private final double horizontal;

    public double getHorizontal() {
        return this.horizontal;
    }

    public MouseScrollEvent(double horizontalValue, double verticalValue) {
        this.horizontal = horizontalValue;
        this.vertical = verticalValue;
    }

    public double getVertical() {
        return this.vertical;
    }
}
