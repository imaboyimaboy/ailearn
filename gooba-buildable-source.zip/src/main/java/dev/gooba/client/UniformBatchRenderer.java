package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.ArrayList;

@Environment(EnvType.CLIENT)
public abstract class UniformBatchRenderer implements RenderBatchDispatcher.Batched {
    private int instanceCount;
    private GpuBuffer[] uniformBuffers;
    private boolean initialized;
    private final int bufferSizeBytes;
    private final String debugName;
    private ByteBuffer instanceData;
    private final int maxInstances;
    private int uniformBufferIndex = 0;
    private final String uniformName;
    private final ArrayList<UniformBatchRenderer.Chunk> pendingChunks;
    private final RenderPipeline pipeline;
    private final int bufferCount;
    private GpuBuffer dummyVertexBuffer;

    @Override
    public final void clear() {
        this.pendingChunks.clear();
    }

    private void initialize() {
        if (!this.initialized) {
            this.instanceData = MemoryUtil.memAlloc(this.bufferSizeBytes);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.dummyVertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> {
                                        String stringValue = this.debugName;
                                        return "client:" + stringValue + "_dummy_vertex";
                                    },
                                    32,
                                    bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.uniformBuffers = new GpuBuffer[this.bufferCount];
            this.initialized = true;
        }
    }

    public final void flush() {
        if (this.instanceCount != 0 || !this.pendingChunks.isEmpty()) {
            RenderBatchDispatcher.renderImmediately(this);
        }
    }

    protected final void finishInstance() {
        this.instanceCount++;
        if (RenderBatchDispatcher.isBatching()) {
            RenderBatchDispatcher.enqueue(this);
            if (this.instanceCount >= this.maxInstances) {
                if (this.pendingChunks.size() >= this.bufferCount - 1) {
                    RenderBatchDispatcher.renderImmediately(this);
                } else {
                    this.submitBatch();
                }
            }
        } else {
            RenderBatchDispatcher.renderImmediately(this);
        }
    }

    private GpuBuffer nextUniformBuffer() {
        GpuBuffer gpubuffer = this.uniformBuffers[this.uniformBufferIndex];
        if (gpubuffer == null) {
            int uniformBufferIndexValue = this.uniformBufferIndex;
            gpubuffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> {
                                        String stringValue = this.debugName;
                                        return "client:"
                                                + stringValue
                                                + "_uniform_"
                                                + uniformBufferIndexValue;
                                    },
                                    136,
                                    (long) this.bufferSizeBytes);
            this.uniformBuffers[this.uniformBufferIndex] = gpubuffer;
        }

        this.uniformBufferIndex = (this.uniformBufferIndex + 1) % this.bufferCount;
        return gpubuffer;
    }

    public void close() {
        this.instanceCount = 0;
        this.clear();
        if (this.uniformBuffers != null) {
            for (GpuBuffer gpubuffer : this.uniformBuffers) {
                if (gpubuffer != null) {
                    gpubuffer.close();
                }
            }

            this.uniformBuffers = null;
        }

        this.uniformBufferIndex = 0;
        if (this.dummyVertexBuffer != null) {
            this.dummyVertexBuffer.close();
            this.dummyVertexBuffer = null;
        }

        if (this.instanceData != null) {
            MemoryUtil.memFree(this.instanceData);
            this.instanceData = null;
        }

        this.initialized = false;
    }

    private void submitBatch() {
        if (this.instanceCount != 0) {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            float f = (float) minecraftclient.getWindow().getFramebufferWidth() / 2.0F;
            float f1 = (float) minecraftclient.getWindow().getFramebufferHeight() / 2.0F;
            int i = this.instanceData.position();
            this.instanceData.position(0);
            this.instanceData.putFloat(f);
            this.instanceData.putFloat(f1);
            this.instanceData.putFloat(2.0F);
            this.instanceData.putFloat(0.0F);
            this.instanceData.position(0);
            this.instanceData.limit(i);
            GpuBuffer gpubuffer = this.nextUniformBuffer();
            RenderSystem.getDevice()
                    .createCommandEncoder()
                    .writeToBuffer(
                            gpubuffer.slice(0L, (long) this.instanceData.remaining()),
                            this.instanceData);
            this.instanceData.limit(this.instanceData.capacity());
            this.pendingChunks.add(new UniformBatchRenderer.Chunk(gpubuffer, this.instanceCount));
            this.instanceCount = 0;
        }
    }

    @Override
    public final void render(RenderPass renderpass) {
        if (!this.pendingChunks.isEmpty()) {
            renderpass.setPipeline(this.pipeline);
            renderpass.setVertexBuffer(0, this.dummyVertexBuffer);

            for (UniformBatchRenderer.Chunk chunk : this.pendingChunks) {
                renderpass.setUniform(this.uniformName, chunk.buffer());
                renderpass.draw(0, chunk.count() * 6);
            }

            this.pendingChunks.clear();
        }
    }

    @Override
    public final void prepare(CommandEncoder commandencoder) {
        this.submitBatch();
    }

    protected final ByteBuffer beginInstance() {
        this.initialize();
        if (this.instanceCount == 0) {
            this.instanceData.clear();
            this.instanceData.position(16);
        }

        return this.instanceData;
    }

    protected UniformBatchRenderer(
            String stringValue,
            RenderPipeline renderpipeline,
            String text,
            int maxInstancesValue,
            int j,
            int bufferCountValue) {
        this.initialized = false;
        this.instanceCount = 0;
        this.pendingChunks = new ArrayList<>();
        this.debugName = stringValue;
        this.pipeline = renderpipeline;
        this.uniformName = text;
        this.maxInstances = maxInstancesValue;
        this.bufferSizeBytes = 16 + maxInstancesValue * j;
        this.bufferCount = bufferCountValue;
    }

    @Environment(EnvType.CLIENT)
    private static record Chunk(GpuBuffer buffer, int count) {}
}
