package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;

import java.util.Arrays;
import java.util.List;

@ModuleInfo(
        name = "Chat Macro",
        category = ModuleCategory.OTHER,
        desc = "Sends chat messages/commands when activated. Separate lines with | symbol.")
@Environment(EnvType.CLIENT)
public class ChatMacroModule extends Module {
    public final TextSetting messagesSetting = new TextSetting(this, "Messages", "");
    private List<String> messages;
    private int delayTicks;
    private int messageIndex;

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player == null
                || this.messages == null
                || this.messageIndex >= this.messages.size()) {
            this.toggle();
        } else if (++this.delayTicks >= 20) {
            this.delayTicks = 0;
            String text = this.messages.get(this.messageIndex++);
            if (text.startsWith("/")) {
                client.player.networkHandler.sendChatCommand(text.substring(1));
            } else {
                client.player.networkHandler.sendChatMessage(text);
            }
        }
    }

    @Override
    protected void onEnable() {
        if (client.player != null) {
            String text = this.messagesSetting.getText().trim();
            if (text.isEmpty()) {
                client.player.sendMessage(
                        Text.literal("§8[§6CM§8] §cNo messages configured!"), false);
                this.toggle();
            } else {
                this.messages =
                        Arrays.stream(text.split("\\|"))
                                .map(String::trim)
                                .filter(sx -> !sx.isEmpty())
                                .toList();
                this.messageIndex = 0;
                this.delayTicks = 0;
            }
        }
    }

    @Override
    protected void onDisable() {
        this.messages = null;
        this.messageIndex = 0;
        this.delayTicks = 0;
    }
}
