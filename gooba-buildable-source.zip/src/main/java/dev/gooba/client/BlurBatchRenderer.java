package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.ArrayList;

@Environment(EnvType.CLIENT)
public class BlurBatchRenderer implements RenderBatchDispatcher.Batched {
    private GpuBuffer[] uniformBuffers;
    private static final Identifier PIPELINE_ID = Identifier.of("client", "pipeline/blur");
    private boolean initialized;
    private static final Identifier VERTEX_SHADER = Identifier.of("client", "core/blur");
    private GpuBuffer vertexBuffer;
    private int uniformIndex = 0;

    private ByteBuffer uniformData;
    private static final Identifier FRAGMENT_SHADER = Identifier.of("client", "core/blur");

    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(BlurBatchRenderer.PIPELINE_ID)
                            .withVertexShader(BlurBatchRenderer.VERTEX_SHADER)
                            .withFragmentShader(BlurBatchRenderer.FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("BlurData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private GpuBuffer sweepUniformBuffer;
    private final ArrayList<GpuBuffer> blurQueue;
    private final RenderBatchDispatcher.Batched sweepBatch;
    private final ArrayList<GpuBuffer> sweepQueue;

    private int getGuiWidth() {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        return minecraftclient != null && minecraftclient.getWindow() != null
                ? (int) Math.ceil((double) minecraftclient.getWindow().getFramebufferWidth() / 2.0)
                : 960;
    }

    @Override
    public void render(RenderPass renderpass) {
        this.renderQueue(renderpass, this.blurQueue);
    }

    public void flush() {
        if (!this.blurQueue.isEmpty()) {
            RenderBatchDispatcher.renderImmediately(this);
        }

        if (!this.sweepQueue.isEmpty()) {
            RenderBatchDispatcher.renderImmediately(this.sweepBatch);
        }
    }

    private void writeUniforms(
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            int i,
            int j,
            float f6,
            float f7,
            float[] afloat,
            int k,
            float f8,
            float f9,
            float f10,
            float f11,
            float f12,
            float f13,
            float f14) {
        this.uniformData.clear();
        this.uniformData.putFloat(f);
        this.uniformData.putFloat(f1);
        this.uniformData.putFloat(f2);
        this.uniformData.putFloat(f3);
        this.uniformData.putFloat(f4);
        this.uniformData.putFloat(f5);
        this.uniformData.putFloat(f6);
        this.uniformData.putFloat(f7);
        this.uniformData.putFloat((float) i);
        this.uniformData.putFloat((float) j);
        this.uniformData.putFloat(0.0F);
        this.uniformData.putFloat(0.0F);
        this.uniformData.putFloat(afloat[0]);
        this.uniformData.putFloat(afloat[1]);
        this.uniformData.putFloat(afloat[2]);
        this.uniformData.putFloat(afloat[3]);
        float f15 = (float) (k >> 24 & 0xFF) / 255.0F;
        float f16 = (float) (k >> 16 & 0xFF) / 255.0F;
        float f17 = (float) (k >> 8 & 0xFF) / 255.0F;
        float f18 = (float) (k & 0xFF) / 255.0F;
        this.uniformData.putFloat(f16);
        this.uniformData.putFloat(f17);
        this.uniformData.putFloat(f18);
        this.uniformData.putFloat(f15);
        this.uniformData.putFloat(Math.max(0.0F, f8));
        this.uniformData.putFloat(Math.max(0.0F, f9));
        this.uniformData.putFloat(Math.max(0.0F, f10));
        this.uniformData.putFloat(Math.max(0.0F, f11));
        this.uniformData.putFloat(f12);
        this.uniformData.putFloat(0.5F);
        this.uniformData.putFloat(f13);
        this.uniformData.putFloat(f14);
        this.uniformData.flip();
    }

    public BlurBatchRenderer() {
        this.initialized = false;
        this.blurQueue = new ArrayList<>();
        this.sweepQueue = new ArrayList<>();
        this.sweepBatch =
                new RenderBatchDispatcher.Batched() {
                    @Override
                    public void render(RenderPass renderpass) {
                        BlurBatchRenderer.this.renderQueue(
                                renderpass, BlurBatchRenderer.this.sweepQueue);
                    }

                    @Override
                    public void prepare(CommandEncoder commandencoder) {}

                    @Override
                    public int getSortOrder() {
                        return 1;
                    }

                    @Override
                    public void clear() {
                        BlurBatchRenderer.this.sweepQueue.clear();
                    }
                };
    }

    public void drawTintedRect(
            float innerX,
            float innerY,
            float width,
            float height,
            float factor,
            float[] afloat,
            int color,
            float f5) {
        if (!(width <= 0.0F) && !(height <= 0.0F) && !(factor <= 0.0F) && color >>> 24 != 0) {
            if (!BackgroundBlur.isAvailable()) {
                Gooba.getInstance()
                        .getHudManager()
                        .getRectData()
                        .drawRect(
                                innerX,
                                innerY,
                                width,
                                height,
                                ColorUtils.repeatNine(ColorUtils.multiplyAlpha(color, factor)),
                                afloat);
            } else {
                this.enqueue(
                        innerX,
                        innerY,
                        width,
                        height,
                        factor,
                        afloat,
                        color,
                        0.0F,
                        0.0F,
                        0.0F,
                        0.0F,
                        -1.0F,
                        0.0F,
                        Math.max(0.0F, Math.min(1.0F, f5)));
            }
        }
    }

    public void drawLightSweep(
            float f, float f1, float f2, float f3, float f4, float[] afloat, float f5) {
        this.enqueueGlass(f, f1, f2, f3, f4, afloat, 0, 0.0F, 0.0F, 0.0F, 0.0F, f5, 1.0F);
    }

    public void drawGlassRect(
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float[] afloat,
            int i,
            float f5,
            float f6,
            float f7,
            float f8,
            float f9) {
        this.enqueueGlass(f, f1, f2, f3, f4, afloat, i, f5, f6, f7, f8, f9, 0.0F);
    }

    private void initialize() {
        if (!this.initialized) {
            this.uniformData = MemoryUtil.memAlloc(128);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.vertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "client:blur_vertex", 32, bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.uniformBuffers = new GpuBuffer[64];
            this.initialized = true;
        }
    }

    @Override
    public int getSortOrder() {
        return -1;
    }

    private void enqueue(
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float[] afloat,
            int i,
            float f5,
            float f6,
            float f7,
            float f8,
            float f9,
            float f10,
            float f11) {

        BackgroundBlur.requestBlur();
        if (BackgroundBlur.isAvailable()) {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (minecraftclient.getFramebuffer() != null) {
                this.initialize();
                int width = BackgroundBlur.getWidth();
                int height = BackgroundBlur.getHeight();
                int guiWidth = this.getGuiWidth();
                int guiHeight = this.getGuiHeight();
                this.writeUniforms(
                        f,
                        f1,
                        f2,
                        f3,
                        (float) guiWidth,
                        (float) guiHeight,
                        width,
                        height,
                        2.0F,
                        f4,
                        afloat,
                        i,
                        f5,
                        f6,
                        f7,
                        f8,
                        f9,
                        f10,
                        f11);
                GpuBuffer gpubuffer;
                if (f10 > 0.5F) {
                    if (this.sweepUniformBuffer == null) {
                        this.sweepUniformBuffer =
                                RenderSystem.getDevice()
                                        .createBuffer(() -> "client:blur_sweep_uniform", 136, 128L);
                    }

                    gpubuffer = this.sweepUniformBuffer;
                } else {
                    gpubuffer = this.nextUniformBuffer();
                }

                RenderSystem.getDevice()
                        .createCommandEncoder()
                        .writeToBuffer(
                                gpubuffer.slice(0L, (long) this.uniformData.remaining()),
                                this.uniformData);
                if (f10 > 0.5F) {
                    this.sweepQueue.add(gpubuffer);
                    if (RenderBatchDispatcher.isBatching()) {
                        RenderBatchDispatcher.enqueue(this.sweepBatch);
                    } else {
                        RenderBatchDispatcher.flush();
                        RenderBatchDispatcher.renderImmediately(this.sweepBatch);
                    }
                } else {
                    this.blurQueue.add(gpubuffer);
                    if (RenderBatchDispatcher.isBatching()) {
                        RenderBatchDispatcher.enqueue(this);
                        if (this.blurQueue.size() >= 64) {
                            RenderBatchDispatcher.renderImmediately(this);
                        }
                    } else {
                        RenderBatchDispatcher.flush();
                        RenderBatchDispatcher.renderImmediately(this);
                    }
                }
            }
        }
    }

    @Override
    public void prepare(CommandEncoder commandencoder) {}

    private void enqueueGlass(
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float[] afloat,
            int i,
            float f5,
            float f6,
            float f7,
            float f8,
            float f9,
            float f10) {
        this.enqueue(f, f1, f2, f3, f4, afloat, i, f5, f6, f7, f8, f9, f10, -1.0F);
    }

    public void close() {
        this.blurQueue.clear();
        this.sweepQueue.clear();
        if (this.uniformBuffers != null) {
            for (GpuBuffer gpubuffer : this.uniformBuffers) {
                if (gpubuffer != null) {
                    gpubuffer.close();
                }
            }

            this.uniformBuffers = null;
        }

        if (this.sweepUniformBuffer != null) {
            this.sweepUniformBuffer.close();
            this.sweepUniformBuffer = null;
        }

        this.uniformIndex = 0;
        if (this.vertexBuffer != null) {
            this.vertexBuffer.close();
            this.vertexBuffer = null;
        }

        if (this.uniformData != null) {
            MemoryUtil.memFree(this.uniformData);
            this.uniformData = null;
        }

        this.initialized = false;
    }

    private int getGuiHeight() {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        return minecraftclient != null && minecraftclient.getWindow() != null
                ? (int) Math.ceil((double) minecraftclient.getWindow().getFramebufferHeight() / 2.0)
                : 540;
    }

    private GpuBuffer nextUniformBuffer() {
        GpuBuffer gpubuffer = this.uniformBuffers[this.uniformIndex];
        if (gpubuffer == null) {
            int uniformIndexValue = this.uniformIndex;
            gpubuffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "client:blur_uniform_" + uniformIndexValue, 136, 128L);
            this.uniformBuffers[this.uniformIndex] = gpubuffer;
        }

        this.uniformIndex = (this.uniformIndex + 1) % 64;
        return gpubuffer;
    }

    public void drawSweepTintedRect(
            float f, float f1, float f2, float f3, float f4, float[] afloat, int i, float f5) {
        this.enqueueGlass(f, f1, f2, f3, f4, afloat, i, 0.0F, 0.0F, 0.0F, 0.0F, f5, 0.0F);
    }

    private void renderQueue(RenderPass renderpass, ArrayList<GpuBuffer> arraylist) {
        if (!arraylist.isEmpty()) {
            if (!BackgroundBlur.isAvailable()) {
                arraylist.clear();
            } else {
                GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
                renderpass.setPipeline(PIPELINE);
                renderpass.setVertexBuffer(0, this.vertexBuffer);
                renderpass.bindTexture("Sampler0", BackgroundBlur.getTextureView(), gpusampler);

                for (GpuBuffer gpubuffer : arraylist) {
                    renderpass.setUniform("BlurData", gpubuffer);
                    renderpass.draw(0, 6);
                }

                arraylist.clear();
            }
        }
    }

    @Override
    public void clear() {
        this.blurQueue.clear();
    }
}
