package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class RotationStateManager extends ClientComponent {
    public static boolean freeLookLocked;
    public static float pitch;
    public static boolean cameraOverride;
    public static float yaw;

    private void applyMouseDelta(double d0, double d1) {
        pitch = MathHelper.clamp((float) ((double) pitch + d1 * 0.15), -90.0F, 90.0F);
        yaw = (float) ((double) yaw + d0 * 0.15);
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        ServerInfo.update();
    }

    @EventHandler
    public void onPacket(PacketEvent packetEvent) {
        ServerInfo.updateTickRate(packetEvent);
    }

    public static void setCameraOverride(boolean cameraOverrideValue) {
        if (cameraOverrideValue || !RotationStateManager.freeLookLocked) {
            cameraOverride = cameraOverrideValue;
        }
    }

    @EventHandler
    public void onCameraRotation(CameraRotationEvent cameraRotationEvent) {
        if (cameraOverride) {
            cameraRotationEvent.setYaw(yaw);
            cameraRotationEvent.setPitch(pitch);
        } else {
            yaw = cameraRotationEvent.getYaw();
            pitch = cameraRotationEvent.getPitch();
        }
    }

    @EventHandler
    public void onMouseRotation(MouseRotationEvent mouseRotationEvent) {
        if (cameraOverride) {
            this.applyMouseDelta(mouseRotationEvent.getYaw(), mouseRotationEvent.getPitch());
            mouseRotationEvent.cancel();
        }
    }
}
