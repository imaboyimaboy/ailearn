package dev.gooba.client;

import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FieldOrder({"start", "end"})
@Environment(EnvType.CLIENT)
public class DiscordTimestamps extends Structure {
    public long start;
    public long end;
}
