package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

@ModuleInfo(
        name = "Auto Log",
        category = ModuleCategory.OTHER,
        desc = "Disconnects when any non-friend player is detected nearby.")
@Environment(EnvType.CLIENT)
public class AutoLogModule extends Module {
    private boolean disconnectRequested;

    @Override
    protected void onDisable() {
        this.disconnectRequested = false;
    }

    @Override
    protected void onEnable() {
        this.disconnectRequested = false;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (!this.disconnectRequested
                && client.player != null
                && client.world != null
                && client.getNetworkHandler() != null) {
            PlayerEntity playerentity = null;
            double MAX_VALUE = Double.MAX_VALUE;

            for (PlayerEntity entity : client.world.getPlayers()) {
                if (entity != client.player && !FakeLagModule.isGhost(entity) && entity.isAlive()) {
                    String string = entity.getName().getString();
                    if (!Gooba.getInstance().getFriendManager().isFriend(string)) {
                        double MAX_VALUEValue = client.player.squaredDistanceTo(entity);
                        if (MAX_VALUEValue < MAX_VALUE) {
                            MAX_VALUE = MAX_VALUEValue;
                            playerentity = entity;
                        }
                    }
                }
            }

            if (playerentity != null) {
                this.disconnectRequested = true;
                client.getNetworkHandler()
                        .getConnection()
                        .disconnect(
                                Text.literal(
                                        "Auto Log | Player detected: "
                                                + playerentity.getName().getString()));
                this.setEnabled(false);
            }
        }
    }
}
