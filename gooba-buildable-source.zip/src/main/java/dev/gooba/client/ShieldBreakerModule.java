package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

import org.lwjgl.glfw.GLFW;

@ModuleInfo(
        name = "Shield Breaker",
        desc = "Swaps to an axe to disable a blocking player's shield under the crosshair",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class ShieldBreakerModule extends Module {
    private boolean attacked;
    private int previousSlot;
    private int axeSlot;
    public final KeybindSetting activationKeySetting;
    private long cooldownUntilMillis;
    public final BooleanSetting shieldStunSetting;
    public final SliderSetting switchDelaySetting;
    private static ShieldBreakerModule instance;
    private PlayerEntity target;

    public final ModeSetting modeSetting =
            new ModeSetting(this, "Mode", new String[] {"Auto", "Bind"});
    private long switchAtMillis;

    private boolean isBlockingTarget(PlayerEntity playerentity) {
        return this.isValidTarget(playerentity)
                && playerentity.isBlocking()
                && playerentity.getActiveItem().isOf(Items.SHIELD);
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled() && instance.previousSlot != -1;
    }

    private int findAxeSlot() {
        int selectedSlot = client.player.getInventory().getSelectedSlot();
        if (client.player.getInventory().getStack(selectedSlot).isIn(ItemTags.AXES)) {
            return selectedSlot;
        } else {
            for (int j = 0; j < 9; j++) {
                if (client.player.getInventory().getStack(j).isIn(ItemTags.AXES)) {
                    return j;
                }
            }

            return -1;
        }
    }

    @EventHandler
    public void onPreClientTick(PreClientTickEvent preClientTickEvent) {
        if (client.player != null && client.world != null && client.interactionManager != null) {
            label283:
            {
                long i;
                label262:
                {
                    label276:
                    {
                        i = System.currentTimeMillis();
                        boolean flagx;
                        if (client.currentScreen == null
                                && client.player.isAlive()
                                && !client.player.isSpectator()
                                && !client.player.isUsingItem()
                                && !AutoTotemModule.isSwapPending()
                                && (this.modeSetting.isSelected("Auto")
                                        || this.isActivationHeld())) {
                            flagx = true;
                            if (this.previousSlot != -1) {
                                if (!flagx
                                        || client.player.getInventory().getSelectedSlot()
                                                != this.axeSlot
                                        || !client.player.getMainHandStack().isIn(ItemTags.AXES)) {
                                    break label283;
                                }
                                break label276;
                            }
                        } else {
                            flagx = false;
                            if (this.previousSlot != -1) {
                                if (!flagx
                                        || client.player.getInventory().getSelectedSlot()
                                                != this.axeSlot
                                        || !client.player.getMainHandStack().isIn(ItemTags.AXES)) {
                                    break label283;
                                }
                                break label276;
                            }
                        }

                        if (!flagx
                                || i < this.cooldownUntilMillis
                                || MaceSwapModule.isActive()
                                || SpearSwapModule.isActive()
                                || DoubleAnchorModule.isActive()) {
                            return;
                        }

                        if (!(client.crosshairTarget instanceof EntityHitResult entityhitresult)
                                || !(entityhitresult.getEntity()
                                        instanceof PlayerEntity playerentity)
                                || !this.isBlockingTarget(playerentity)) {
                            return;
                        }

                        int axeSlotValue = this.findAxeSlot();
                        if (axeSlotValue == -1) {
                            return;
                        }

                        this.target = playerentity;
                        this.previousSlot = client.player.getInventory().getSelectedSlot();
                        this.axeSlot = axeSlotValue;
                        EnchantmentInventoryUtils.selectHotbarSlot(axeSlotValue);
                        this.switchAtMillis =
                                i + (long) Math.round(this.switchDelaySetting.getFloat());
                        break label262;
                    }

                    if (this.attacked) {
                        if (i >= this.switchAtMillis) {
                            this.restoreSlot();
                        }

                        return;
                    }

                    if (!this.isBlockingTarget(this.target)) {
                        this.restoreSlot();
                        return;
                    }
                }

                if (i < this.switchAtMillis) {
                    return;
                }

                try {
                    if (this.isBlockingTarget(this.target)) {
                        client.interactionManager.attackEntity(client.player, this.target);
                        client.player.swingHand(Hand.MAIN_HAND);
                        if (this.shieldStunSetting.isOn() && this.isValidTarget(this.target)) {
                            client.interactionManager.attackEntity(client.player, this.target);
                            client.player.swingHand(Hand.MAIN_HAND);
                        }

                        this.attacked = true;
                        this.switchAtMillis =
                                i + (long) Math.round(this.switchDelaySetting.getFloat());
                        this.cooldownUntilMillis =
                                i
                                        + Math.max(
                                                250L,
                                                (long)
                                                        Math.round(
                                                                this.switchDelaySetting
                                                                        .getFloat()));
                        return;
                    }
                } finally {
                    if (!this.attacked || this.switchDelaySetting.getFloat() <= 0.0F) {
                        this.restoreSlot();
                    }
                }

                return;
            }

            this.restoreSlot();
        } else {
            this.reset();
        }
    }

    private void reset() {
        this.target = null;
        this.previousSlot = -1;
        this.axeSlot = -1;
        this.attacked = false;
        this.switchAtMillis = 0L;
        this.cooldownUntilMillis = 0L;
    }

    private boolean isActivationHeld() {
        int cachedKeyCode = this.activationKeySetting.getCachedKeyCode();
        if (cachedKeyCode < 0) {
            return false;
        } else {
            return cachedKeyCode <= 7
                    ? GLFW.glfwGetMouseButton(client.getWindow().getHandle(), cachedKeyCode) == 1
                    : InputUtil.isKeyPressed(client.getWindow(), cachedKeyCode);
        }
    }

    private void restoreSlot() {
        if (client.player != null
                && client.player.isAlive()
                && client.player.getInventory().getSelectedSlot() == this.axeSlot
                && client.player.getMainHandStack().isIn(ItemTags.AXES)) {
            EnchantmentInventoryUtils.selectHotbarSlot(this.previousSlot);
        }

        this.target = null;
        this.previousSlot = -1;
        this.axeSlot = -1;
        this.attacked = false;
    }

    private boolean isAimedAt(PlayerEntity playerentity, float f, float f1) {
        Vec3d vec3d = client.player.getEyePos();
        Vec3d vec3d1 =
                vec3d.add(
                        EntityRaycast.rotationVector(f1, f)
                                .multiply(client.player.getEntityInteractionRange()));
        Vec3d vec3d2 = playerentity.getBoundingBox().raycast(vec3d, vec3d1).orElse(null);
        return vec3d2 == null
                ? false
                : client.world
                                .raycast(
                                        new RaycastContext(
                                                vec3d,
                                                vec3d2,
                                                ShapeType.COLLIDER,
                                                FluidHandling.NONE,
                                                client.player))
                                .getType()
                        == Type.MISS;
    }

    public ShieldBreakerModule() {
        this.activationKeySetting =
                new KeybindSetting(this, "Activation Key", 71)
                        .visibleWhen(() -> this.modeSetting.isSelected("Bind"));
        this.switchDelaySetting = new SliderSetting(this, "Switch Delay", 0.0F, 0.0F, 500.0F, 1.0F);
        this.shieldStunSetting = new BooleanSetting(this, "Shield Stun", false);
        this.previousSlot = -1;
        this.axeSlot = -1;
        instance = this;
    }

    @Override
    protected void onDisable() {
        this.restoreSlot();
        this.reset();
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.reset();
    }

    private boolean isValidTarget(PlayerEntity playerentity) {
        if (playerentity != null
                && playerentity != client.player
                && playerentity.isAlive()
                && !playerentity.isRemoved()
                && !playerentity.isSpectator()
                && !playerentity.isCreative()
                && !playerentity.isInvulnerable()) {
            if (client.world.getEntityById(playerentity.getId()) == playerentity
                    && !Gooba.getInstance()
                            .getFriendManager()
                            .isFriend(playerentity.getName().getString())) {
                if (client.crosshairTarget instanceof EntityHitResult entityhitresult
                        && entityhitresult.getEntity() == playerentity
                        && this.isAimedAt(
                                playerentity, client.player.getYaw(), client.player.getPitch())
                        && this.isAimedAt(
                                playerentity,
                                client.player.lastYawClient,
                                client.player.lastPitchClient)) {
                    return true;
                }

                return false;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
