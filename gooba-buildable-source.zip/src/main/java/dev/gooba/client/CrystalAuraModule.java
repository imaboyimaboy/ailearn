package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

import java.util.concurrent.ThreadLocalRandom;

@ModuleInfo(
        name = "Crystal Aura",
        desc = "Continuously places and breaks crystals near players",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class CrystalAuraModule extends Module {
    private final SliderSetting breakDelaySetting =
            new SliderSetting(this, "Break Delay", 80.0F, 0.0F, 500.0F, 10.0F);
    private CrystalAuraModule.SequenceState sequenceState;
    private long stateStartedAtMillis;
    private PlayerEntity target;
    private static final Direction[] SUPPORT_DIRECTIONS =
            new Direction[] {
                Direction.DOWN,
                Direction.NORTH,
                Direction.SOUTH,
                Direction.EAST,
                Direction.WEST,
                Direction.UP
            };
    private boolean placedObsidian;
    private Vec3d aimPoint;
    private long lastPlaceMillis;
    private EndCrystalEntity targetCrystal;
    private final SliderSetting aimRandomizationSetting;
    private final SliderSetting rotationSpeedSetting =
            new SliderSetting(this, "Rotation Speed", 30.0F, 12.0F, 45.0F, 1.0F);
    private BlockHitResult placementHit;
    private int previousSlot;
    private final BooleanSetting raycastSetting;

    private BlockPos basePosition;

    private void placeCrystalImmediately(long lastPlaceMillisValue) {
        Hand hand = this.selectCrystalHand();
        if (hand == null) {
            this.stopSequence();
        } else {
            Vec3d vec3dx =
                    new Vec3d(
                            (double) this.basePosition.getX() + 0.5,
                            (double) this.basePosition.getY() + 1.0,
                            (double) this.basePosition.getZ() + 0.5);
            BlockHitResult blockhitresult =
                    new BlockHitResult(vec3dx, Direction.UP, this.basePosition, false);
            this.interactAndWait(blockhitresult, hand, lastPlaceMillisValue);
        }
    }

    private Vec3d randomFacePoint(BlockPos blockpos, Direction direction) {
        double d0 = 0.28 * (double) this.aimRandomizationSetting.getFloat().floatValue();
        double d1 = (double) blockpos.getX() + 0.5 + (double) direction.getOffsetX() * 0.5;
        double d2 = (double) blockpos.getY() + 0.5 + (double) direction.getOffsetY() * 0.5;
        double d3 = (double) blockpos.getZ() + 0.5 + (double) direction.getOffsetZ() * 0.5;
        if (direction.getOffsetX() == 0) {
            d1 += this.randomDouble(-d0, d0);
        }

        if (direction.getOffsetY() == 0) {
            d2 += this.randomDouble(-d0, d0);
        }

        if (direction.getOffsetZ() == 0) {
            d3 += this.randomDouble(-d0, d0);
        }

        return new Vec3d(d1, d2, d3);
    }

    private boolean placeObsidian(BlockHitResult blockhitresult, Hand hand) {
        if (blockhitresult != null
                && hand != null
                && this.basePosition != null
                && this.canPlaceObsidian(this.basePosition)) {
            client.interactionManager.interactBlock(client.player, hand, blockhitresult);
            client.player.swingHand(hand);
            return true;
        } else {
            return false;
        }
    }

    private EndCrystalEntity findNearbyCrystal() {
        for (Entity entity : client.world.getEntities()) {
            if (entity instanceof EndCrystalEntity) {
                EndCrystalEntity endcrystalentity = (EndCrystalEntity) entity;
                if (endcrystalentity.isAlive() && !endcrystalentity.isRemoved()) {
                    BlockPos blockpos =
                            BlockPos.ofFloored(
                                    endcrystalentity.getX(),
                                    endcrystalentity.getY() - 1.0,
                                    endcrystalentity.getZ());
                    if (this.isNearTarget(blockpos) && this.isWithinPlaceRange(blockpos)) {
                        return endcrystalentity;
                    }
                }
            }
        }

        return null;
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (client.player != null && client.world != null && client.interactionManager != null) {
            long nowMillis = System.currentTimeMillis();
            if (!this.isValidTarget(this.target)) {
                PlayerEntity playerentity = this.findTarget();
                if (playerentity == null) {
                    this.stopSequence();
                    return;
                }

                this.setTarget(playerentity);
            }

            if (this.sequenceState == CrystalAuraModule.SequenceState.IDLE) {
                this.setState(CrystalAuraModule.SequenceState.PREPARE);
            }

            switch (this.sequenceState) {
                case IDLE:
                default:
                    break;
                case PREPARE:
                    this.prepareTick(nowMillis);
                    break;
                case PLACE_OBSIDIAN:
                    this.placeObsidianTick(nowMillis);
                    break;
                case PLACE_CRYSTAL:
                    this.placeCrystalTick(nowMillis);
                    break;
                case WAIT_CRYSTAL:
                    this.waitForCrystalTick(nowMillis);
                    break;
                case BREAK_CRYSTAL:
                    this.breakCrystalTick(nowMillis);
            }
        } else {
            this.resetState();
        }
    }

    private boolean isWithinPlaceRange(BlockPos blockpos) {
        if (blockpos != null && client.player != null) {
            BlockPos blockPosValue = client.player.getBlockPos();
            double d0 = (double) (blockpos.getX() - blockPosValue.getX());
            double d1 = (double) (blockpos.getZ() - blockPosValue.getZ());
            double d2 = d0 * d0 + d1 * d1;
            double d3 = Math.abs((double) blockpos.getY() - client.player.getY());
            return d2 <= 20.25 && d3 <= 4.5;
        } else {
            return false;
        }
    }

    @Override
    protected void onDisable() {
        this.stopSequence();
    }

    private BlockHitResult findCrystalPlaceHit(BlockPos blockpos) {
        if (this.isBlockAbovePlayer(blockpos)) {
            Vec3d vec3dx = this.raisedAimPoint(blockpos);
            if (!this.raycastSetting.isOn() || this.canRaycastBlock(blockpos, vec3dx)) {
                return new BlockHitResult(vec3dx, Direction.UP, blockpos, false);
            }
        }

        if (!this.raycastSetting.isOn()) {
            Vec3d vec3d2 = this.randomFacePoint(blockpos, Direction.UP);
            return new BlockHitResult(vec3d2, Direction.UP, blockpos, false);
        } else {
            for (Direction direction : Direction.values()) {
                for (int i = 0; i < 4; i++) {
                    Vec3d vec3d1 = this.randomFacePoint(blockpos, direction);
                    if (this.raycast(vec3d1) instanceof BlockHitResult blockhitresult
                            && blockhitresult.getBlockPos().equals(blockpos)) {
                        return new BlockHitResult(
                                blockhitresult.getPos(), blockhitresult.getSide(), blockpos, false);
                    }
                }
            }

            return null;
        }
    }

    private boolean canRaycastBlock(BlockPos blockpos, Vec3d vec3d) {
        if (this.raycast(vec3d) instanceof BlockHitResult blockhitresult
                && blockhitresult.getBlockPos().equals(blockpos)) {
            return true;
        }

        return false;
    }

    private void interactAndWait(
            BlockHitResult blockhitresult, Hand hand, long lastPlaceMillisValue) {
        client.interactionManager.interactBlock(client.player, hand, blockhitresult);
        client.player.swingHand(hand);
        this.lastPlaceMillis = lastPlaceMillisValue;
        if (this.sequenceState != CrystalAuraModule.SequenceState.WAIT_CRYSTAL) {
            this.setState(CrystalAuraModule.SequenceState.WAIT_CRYSTAL);
        }
    }

    private boolean isValidTarget(PlayerEntity playerentity) {
        return playerentity != null
                && playerentity != client.player
                && playerentity.isAlive()
                && !playerentity.isRemoved()
                && !Gooba.getInstance()
                        .getFriendManager()
                        .isFriend(playerentity.getName().getString());
    }

    private boolean isBlockAbovePlayer(BlockPos blockpos) {
        if (blockpos != null && client.player != null) {
            int i =
                    BlockPos.ofFloored(
                                    client.player.getX(),
                                    client.player.getBoundingBox().minY + 0.05,
                                    client.player.getZ())
                            .getY();
            return i < blockpos.getY();
        } else {
            return false;
        }
    }

    private boolean isCrystalBase(BlockPos blockpos) {
        if (blockpos == null) {
            return false;
        } else {
            BlockState blockstate = client.world.getBlockState(blockpos);
            return blockstate.isOf(Blocks.OBSIDIAN) || blockstate.isOf(Blocks.BEDROCK);
        }
    }

    private EndCrystalEntity findCrystalAt(BlockPos blockpos) {
        if (blockpos == null) {
            return null;
        } else {
            Vec3d vec3dx =
                    new Vec3d(
                            (double) blockpos.getX() + 0.5,
                            (double) blockpos.getY() + 1.0,
                            (double) blockpos.getZ() + 0.5);
            EndCrystalEntity endcrystalentity = null;
            double MAX_VALUE = Double.MAX_VALUE;

            for (Entity entity : client.world.getEntities()) {
                if (entity instanceof EndCrystalEntity) {
                    EndCrystalEntity entityValue = (EndCrystalEntity) entity;
                    if (entityValue.isAlive() && !entityValue.isRemoved()) {
                        Vec3d vec3d1 = entityValue.getEntityPos();
                        if (!(Math.abs(vec3d1.x - vec3dx.x) > 0.35)
                                && !(Math.abs(vec3d1.y - vec3dx.y) > 0.75)
                                && !(Math.abs(vec3d1.z - vec3dx.z) > 0.35)) {
                            double MAX_VALUEValue = vec3d1.squaredDistanceTo(vec3dx);
                            if (MAX_VALUEValue < MAX_VALUE) {
                                MAX_VALUE = MAX_VALUEValue;
                                endcrystalentity = entityValue;
                            }
                        }
                    }
                }
            }

            return endcrystalentity;
        }
    }

    private Vec3d raisedAimPoint(BlockPos blockpos) {
        double d0 = (double) blockpos.getX() + 0.5;
        double d1 = (double) blockpos.getZ() + 0.5;
        double d2 = d0 - client.player.getX();
        double d3 = d1 - client.player.getZ();
        double d4 = Math.hypot(d2, d3);
        double d5 = this.randomDouble(-0.06, 0.06);
        double d6;
        if (d4 <= 0.001) {
            d6 = 0.0;
        } else {
            d6 = -d3 / d4 * d5;
        }

        if (d4 <= 0.001) {
            double d8 = 0.0;
            return new Vec3d(d0 + d6, (double) blockpos.getY() + 1.04, d1 + d8);
        } else {
            double d7 = d2 / d4 * d5;
            return new Vec3d(d0 + d6, (double) blockpos.getY() + 1.04, d1 + d7);
        }
    }

    private void setTarget(PlayerEntity playerentity) {
        this.stopSequence();
        this.target = playerentity;
        this.setState(CrystalAuraModule.SequenceState.PREPARE);
    }

    private void placeObsidianTick(long lastPlaceMillisValue) {
        if (!this.isNearTarget(this.basePosition) || !this.isWithinPlaceRange(this.basePosition)) {
            this.basePosition = null;
            this.placedObsidian = false;
            this.setState(CrystalAuraModule.SequenceState.PREPARE);
        } else if (this.isCrystalBase(this.basePosition)) {
            this.setState(CrystalAuraModule.SequenceState.PLACE_CRYSTAL);
        } else if (!this.canPlaceObsidian(this.basePosition)) {
            this.basePosition = null;
            this.setState(CrystalAuraModule.SequenceState.PREPARE);
        } else {
            if (this.placementHit == null) {
                this.placementHit = this.findObsidianPlaceHit(this.basePosition);
                if (this.placementHit == null) {
                    return;
                }

                this.aimPoint = this.placementHit.getPos();
            }

            if (this.rotateToward(this.aimPoint, 3.0F)) {
                if (this.raycastSetting.isOn()
                        && !this.canRaycastBlock(this.placementHit.getBlockPos(), this.aimPoint)) {
                    this.placementHit = null;
                    this.aimPoint = null;
                } else {
                    int j = this.findHotbarItem(Items.OBSIDIAN);
                    if (j == -1) {
                        this.stopSequence();
                    } else {
                        this.selectSlot(j);
                        if (!this.placeObsidian(this.placementHit, Hand.MAIN_HAND)) {
                            this.stopSequence();
                        } else {
                            this.placedObsidian = true;
                            this.placeCrystalImmediately(lastPlaceMillisValue);
                        }
                    }
                }
            }
        }
    }

    private boolean canPlaceObsidian(BlockPos blockpos) {
        if (blockpos != null && client.world.getBlockState(blockpos).isReplaceable()) {
            if (!client.world.getBlockState(blockpos.up()).isAir()) {
                return false;
            } else {
                return !client.world
                                .getOtherEntities(null, new Box(blockpos), Entity::isAlive)
                                .isEmpty()
                        ? false
                        : this.findHotbarItem(Items.OBSIDIAN) != -1;
            }
        } else {
            return false;
        }
    }

    private boolean isAimingAtCrystal(EndCrystalEntity endcrystalentity) {
        Vec3d vec3dx = client.player.getEyePos();
        Vec3d vec3d1 =
                EntityRaycast.rotationVector(client.player.getPitch(), client.player.getYaw());
        double d0 = vec3dx.distanceTo(endcrystalentity.getBoundingBox().getCenter()) + 1.0;
        Vec3d vec3d2 = vec3dx.add(vec3d1.multiply(d0));
        return endcrystalentity.getBoundingBox().expand(0.04).raycast(vec3dx, vec3d2).isPresent();
    }

    private void breakCrystalTick(long lastPlaceMillisValue) {
        if (this.targetCrystal == null
                || !this.targetCrystal.isAlive()
                || this.targetCrystal.isRemoved()) {
            this.targetCrystal = null;
            if (this.isValidTarget(this.target)
                    && this.isNearTarget(this.basePosition)
                    && this.isWithinPlaceRange(this.basePosition)
                    && this.isCrystalBase(this.basePosition)) {
                this.setState(CrystalAuraModule.SequenceState.PLACE_CRYSTAL);
            } else {
                this.basePosition = null;
                this.placedObsidian = false;
                this.setState(CrystalAuraModule.SequenceState.PREPARE);
            }
        } else if (this.isWithinPlaceRange(this.basePosition)
                && this.isNearTarget(this.basePosition)) {
            if (lastPlaceMillisValue - this.stateStartedAtMillis
                            >= this.breakDelaySetting.getFloat().longValue()
                    && lastPlaceMillisValue - this.lastPlaceMillis
                            >= this.breakDelaySetting.getFloat().longValue()) {
                if (this.aimPoint == null
                        || !this.targetCrystal
                                .getBoundingBox()
                                .expand(0.02)
                                .contains(this.aimPoint)) {
                    this.aimPoint = this.getCrystalAimPoint(this.targetCrystal);
                }

                if (this.rotateToward(this.aimPoint, 2.25F)) {
                    if (this.isAimingAtCrystal(this.targetCrystal)) {
                        if (this.raycastSetting.isOn() && !this.isPointVisible(this.aimPoint)) {
                            this.aimPoint = this.getCrystalAimPoint(this.targetCrystal);
                        } else {
                            client.interactionManager.attackEntity(
                                    client.player, this.targetCrystal);
                            client.player.swingHand(Hand.MAIN_HAND);
                            this.lastPlaceMillis = lastPlaceMillisValue;
                            this.aimPoint = this.getCrystalAimPoint(this.targetCrystal);
                        }
                    }
                }
            }
        } else {
            this.targetCrystal = null;
            this.basePosition = null;
            this.placedObsidian = false;
            this.setState(CrystalAuraModule.SequenceState.PREPARE);
        }
    }

    private Vec3d randomCrystalPoint(EndCrystalEntity endcrystalentity) {
        Box box = endcrystalentity.getBoundingBox();
        double d0 = (double) this.aimRandomizationSetting.getFloat().floatValue();
        double d1 = Math.max(0.04, (box.maxX - box.minX) * 0.5 * d0);
        double d2 = Math.max(0.04, (box.maxY - box.minY) * 0.5 * d0);
        double d3 = Math.max(0.04, (box.maxZ - box.minZ) * 0.5 * d0);
        Vec3d vec3dx = box.getCenter();
        return new Vec3d(
                this.randomDouble(vec3dx.x - d1, vec3dx.x + d1),
                this.randomDouble(vec3dx.y - d2, vec3dx.y + d2),
                this.randomDouble(vec3dx.z - d3, vec3dx.z + d3));
    }

    private boolean rotateToward(Vec3d vec3d, float f) {
        if (vec3d == null) {
            return false;
        } else {
            Rotation rotation = this.rotationTo(vec3d);
            Rotation rotationValue = new Rotation(client.player);
            float f1 = MathHelper.wrapDegrees(rotation.getYaw() - rotationValue.getYaw());
            float f2 = rotation.getPitch() - rotationValue.getPitch();
            float aimYawSpeedValue = Math.min(this.rotationSpeedSetting.getFloat(), 30.0F);
            float aimPitchSpeedValue = Math.min(this.rotationSpeedSetting.getFloat() * 1.5F, 45.0F);
            float f5 = this.rotationStep(f1, aimYawSpeedValue, 0.65F);
            float f6 = this.rotationStep(f2, aimPitchSpeedValue, 0.94F);
            Rotation rotation3 =
                    new Rotation(rotationValue.getYaw() + f5, rotationValue.getPitch() + f6);
            TargetRingRenderer.aim(
                    rotation3, aimYawSpeedValue, aimPitchSpeedValue, 24.0F, 36.0F, 4, 30, false);
            return new Rotation(client.player).angularDistanceTo(rotation) <= f;
        }
    }

    private void waitForCrystalTick(long lastPlaceMillisValue) {
        this.targetCrystal = this.findCrystalAt(this.basePosition);
        if (this.targetCrystal != null) {
            this.setState(CrystalAuraModule.SequenceState.BREAK_CRYSTAL);
        } else if (this.isNearTarget(this.basePosition)
                && this.isWithinPlaceRange(this.basePosition)) {
            if (!this.isCrystalBase(this.basePosition)
                    && this.placedObsidian
                    && lastPlaceMillisValue - this.stateStartedAtMillis > (1000L)) {
                this.basePosition = null;
                this.placedObsidian = false;
                this.setState(CrystalAuraModule.SequenceState.PREPARE);
            } else {
                this.retryCrystalPlacement(lastPlaceMillisValue);
            }
        } else {
            this.basePosition = null;
            this.placedObsidian = false;
            this.setState(CrystalAuraModule.SequenceState.PREPARE);
        }
    }

    private boolean isInPreferredRange(BlockPos blockpos) {
        if (blockpos != null && client.player != null) {
            BlockPos blockPosValue = client.player.getBlockPos();
            double d0 = (double) (blockpos.getX() - blockPosValue.getX());
            double d1 = (double) (blockpos.getZ() - blockPosValue.getZ());
            double d2 = d0 * d0 + d1 * d1;
            return d2 >= 9.0 && d2 <= 16.0;
        } else {
            return false;
        }
    }

    private BlockHitResult findObsidianPlaceHit(BlockPos blockpos) {
        for (Direction direction : SUPPORT_DIRECTIONS) {
            BlockPos blockposValue = blockpos.offset(direction);
            BlockState blockstate = client.world.getBlockState(blockposValue);
            if (!blockstate.isAir() && blockstate.isSolidBlock(client.world, blockposValue)) {
                Direction opposite = direction.getOpposite();

                for (int i = 0; i < 4; i++) {
                    Vec3d vec3dx = this.randomFacePoint(blockposValue, opposite);
                    if (!this.raycastSetting.isOn()
                            || this.canRaycastBlock(blockposValue, vec3dx)) {
                        return new BlockHitResult(vec3dx, opposite, blockposValue, false);
                    }
                }
            }
        }

        return null;
    }

    private void selectSlot(int i) {
        int selectedSlot = client.player.getInventory().getSelectedSlot();
        if (selectedSlot != i) {
            if (this.previousSlot == -1) {
                this.previousSlot = selectedSlot;
            }

            client.player.getInventory().setSelectedSlot(i);
            client.interactionManager.syncSelectedSlot();
        }
    }

    private Hand selectCrystalHand() {
        if (client.player.getOffHandStack().getItem() == Items.END_CRYSTAL) {
            return Hand.OFF_HAND;
        } else {
            int i = this.findHotbarItem(Items.END_CRYSTAL);
            if (i == -1) {
                return null;
            } else {
                this.selectSlot(i);
                return Hand.MAIN_HAND;
            }
        }
    }

    private void setState(CrystalAuraModule.SequenceState sequenceStateValue) {
        this.sequenceState = sequenceStateValue;
        this.stateStartedAtMillis = System.currentTimeMillis();
        this.placementHit = null;
        this.aimPoint = null;
    }

    private void resetState() {
        this.sequenceState = CrystalAuraModule.SequenceState.IDLE;
        this.target = null;
        this.basePosition = null;
        this.targetCrystal = null;
        this.placementHit = null;
        this.aimPoint = null;
        this.stateStartedAtMillis = 0L;
        this.lastPlaceMillis = 0L;
        this.previousSlot = -1;
        this.placedObsidian = false;
    }

    private HitResult raycast(Vec3d vec3d) {
        Vec3d vec3d1 = client.player.getEyePos();
        Vec3d vec3d2 = vec3d.subtract(vec3d1);
        if (vec3d2.lengthSquared() == 0.0) {
            return client.world.raycast(
                    new RaycastContext(
                            vec3d1, vec3d, ShapeType.COLLIDER, FluidHandling.NONE, client.player));
        } else {
            Vec3d vec3d3 = vec3d.add(vec3d2.normalize().multiply(0.01));
            return client.world.raycast(
                    new RaycastContext(
                            vec3d1, vec3d3, ShapeType.COLLIDER, FluidHandling.NONE, client.player));
        }
    }

    private void prepareTick(long i) {
        EndCrystalEntity endcrystalentity = this.findNearbyCrystal();
        if (endcrystalentity != null) {
            this.targetCrystal = endcrystalentity;
            this.basePosition =
                    BlockPos.ofFloored(
                                    endcrystalentity.getX(),
                                    endcrystalentity.getY() - 1.0,
                                    endcrystalentity.getZ())
                            .toImmutable();
            this.setState(CrystalAuraModule.SequenceState.BREAK_CRYSTAL);
        } else if (client.player.getOffHandStack().getItem() != Items.END_CRYSTAL
                && this.findHotbarItem(Items.END_CRYSTAL) == -1) {
            this.stopSequence();
        } else {
            this.basePosition = this.findBasePosition();
            if (this.basePosition == null) {
                if (i - this.stateStartedAtMillis > 900L) {
                    this.stopSequence();
                }
            } else {
                this.setState(
                        this.isCrystalBase(this.basePosition)
                                ? CrystalAuraModule.SequenceState.PLACE_CRYSTAL
                                : CrystalAuraModule.SequenceState.PLACE_OBSIDIAN);
            }
        }
    }

    private boolean isWithinTargetRange(PlayerEntity playerentity) {
        if (!this.isValidTarget(playerentity)) {
            return false;
        } else {
            BlockPos blockpos = client.player.getBlockPos();
            BlockPos blockPosValue = playerentity.getBlockPos();
            double d0 = (double) (blockPosValue.getX() - blockpos.getX());
            double d1 = (double) (blockPosValue.getZ() - blockpos.getZ());
            double d2 = d0 * d0 + d1 * d1;
            double d3 = 2.0;
            double d4 = 5.0;
            return d2 >= d3 * d3 && d2 <= d4 * d4;
        }
    }

    private boolean isPointVisible(Vec3d vec3d) {
        HitResult hitresult = this.raycast(vec3d);
        return hitresult.getType() == Type.MISS
                || hitresult.getPos().squaredDistanceTo(client.player.getEyePos()) + 0.002
                        >= vec3d.squaredDistanceTo(client.player.getEyePos());
    }

    private BlockPos findBasePosition() {
        BlockPos blockpos =
                BlockPos.ofFloored(
                        this.target.getX(),
                        this.target.getBoundingBox().minY + 0.05,
                        this.target.getZ());
        Vec3d vec3dx = this.target.getVelocity();
        double d0 = this.target.getX() + vec3dx.x * 3.0;
        double d1 = this.target.getZ() + vec3dx.z * 3.0;
        BlockPos blockPos2 = null;
        double MAX_VALUE = Double.MAX_VALUE;

        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (Math.abs(i) + Math.abs(j) <= 1) {
                    BlockPos blockposValue = blockpos.add(i, -1, j);
                    boolean isCrystalBase = this.isCrystalBase(blockposValue);
                    if ((isCrystalBase || this.canPlaceObsidian(blockposValue))
                            && (!isCrystalBase
                                    || client.world.getBlockState(blockposValue.up()).isAir())
                            && this.isInPreferredRange(blockposValue)
                            && this.isWithinPlaceRange(blockposValue)
                            && (isCrystalBase || this.findObsidianPlaceHit(blockposValue) != null)
                            && (!isCrystalBase
                                    || !this.raycastSetting.isOn()
                                    || this.findCrystalPlaceHit(blockposValue) != null)) {
                        double d3 = (double) blockposValue.getX() + 0.5 - d0;
                        double d4 = (double) blockposValue.getZ() + 0.5 - d1;
                        BlockPos blockPosValue = client.player.getBlockPos();
                        double d5 = (double) (blockposValue.getX() - blockPosValue.getX());
                        double d6 = (double) (blockposValue.getZ() - blockPosValue.getZ());
                        double d7 = Math.hypot(d5, d6);
                        double MAX_VALUEValue = d3 * d3 + d4 * d4 + (4.0 - d7) * 12.0;
                        if (!isCrystalBase) {
                            MAX_VALUEValue += 0.1;
                        }

                        if (MAX_VALUEValue < MAX_VALUE) {
                            MAX_VALUE = MAX_VALUEValue;
                            blockPos2 = blockposValue.toImmutable();
                        }
                    }
                }
            }
        }

        return blockPos2;
    }

    public CrystalAuraModule() {
        this.aimRandomizationSetting =
                new SliderSetting(this, "Aim Randomization", 0.72F, 0.1F, 1.0F, 0.01F);
        this.raycastSetting = new BooleanSetting(this, "Raycast", true);
        this.sequenceState = CrystalAuraModule.SequenceState.IDLE;
        this.previousSlot = -1;
    }

    private void placeCrystalTick(long lastPlaceMillisValue) {
        if (!this.isNearTarget(this.basePosition) || !this.isWithinPlaceRange(this.basePosition)) {
            this.basePosition = null;
            this.placedObsidian = false;
            this.setState(CrystalAuraModule.SequenceState.PREPARE);
        } else if (this.isCrystalBase(this.basePosition)) {
            EndCrystalEntity endcrystalentity = this.findCrystalAt(this.basePosition);
            if (endcrystalentity != null) {
                this.targetCrystal = endcrystalentity;
                this.setState(CrystalAuraModule.SequenceState.BREAK_CRYSTAL);
            } else if (client.world.getBlockState(this.basePosition.up()).isAir()) {
                if (this.placementHit == null) {
                    this.placementHit = this.findCrystalPlaceHit(this.basePosition);
                    if (this.placementHit == null) {
                        return;
                    }

                    this.aimPoint = this.placementHit.getPos();
                }

                if (this.rotateToward(this.aimPoint, 3.0F)) {
                    if (this.raycastSetting.isOn()
                            && !this.canRaycastBlock(this.basePosition, this.aimPoint)) {
                        this.placementHit = null;
                        this.aimPoint = null;
                    } else {
                        Hand hand = this.selectCrystalHand();
                        if (hand == null) {
                            this.stopSequence();
                        } else {
                            this.interactAndWait(this.placementHit, hand, lastPlaceMillisValue);
                        }
                    }
                }
            }
        } else if (this.placedObsidian) {
            if (lastPlaceMillisValue - this.lastPlaceMillis > 1000L) {
                this.stopSequence();
            }
        } else {
            this.basePosition = null;
            this.setState(CrystalAuraModule.SequenceState.PREPARE);
        }
    }

    private int findHotbarItem(Item item) {
        for (int i = 0; i < 9; i++) {
            ItemStack itemstack = client.player.getInventory().getStack(i);
            if (itemstack.getItem() == item) {
                return i;
            }
        }

        return -1;
    }

    private void stopSequence() {
        this.restoreSlot();
        this.resetState();
    }

    private boolean isNearTarget(BlockPos blockpos) {
        if (blockpos != null && this.target != null) {
            double d0 = this.target.getX() - ((double) blockpos.getX() + 0.5);
            double d1 = this.target.getZ() - ((double) blockpos.getZ() + 0.5);
            double d2 =
                    Math.abs(this.target.getBoundingBox().minY - ((double) blockpos.getY() + 1.0));
            return d0 * d0 + d1 * d1 <= 16.0 && d2 <= 4.5;
        } else {
            return false;
        }
    }

    private PlayerEntity findTarget() {
        PlayerEntity playerentity = null;
        double MAX_VALUE = Double.MAX_VALUE;

        for (PlayerEntity entity : client.world.getPlayers()) {
            if (!FakeLagModule.isGhost(entity) && this.isWithinTargetRange(entity)) {
                double MAX_VALUEValue = client.player.squaredDistanceTo(entity);
                if (MAX_VALUEValue < MAX_VALUE) {
                    MAX_VALUE = MAX_VALUEValue;
                    playerentity = entity;
                }
            }
        }

        return playerentity;
    }

    private void retryCrystalPlacement(long lastPlaceMillisValue) {
        Hand hand = this.selectCrystalHand();
        if (hand == null) {
            this.stopSequence();
        } else {
            BlockHitResult blockhitresult = this.placementHit;
            if (blockhitresult == null && this.isCrystalBase(this.basePosition)) {
                blockhitresult = this.findCrystalPlaceHit(this.basePosition);
            }

            if (blockhitresult == null) {
                Vec3d vec3dx =
                        new Vec3d(
                                (double) this.basePosition.getX() + 0.5,
                                (double) this.basePosition.getY() + 1.0,
                                (double) this.basePosition.getZ() + 0.5);
                blockhitresult = new BlockHitResult(vec3dx, Direction.UP, this.basePosition, false);
            }

            this.placementHit = blockhitresult;
            if (!this.isCrystalBase(this.basePosition)
                    || this.rotateToward(blockhitresult.getPos(), 3.0F)) {
                if (this.raycastSetting.isOn()
                        && this.isCrystalBase(this.basePosition)
                        && !this.canRaycastBlock(this.basePosition, blockhitresult.getPos())) {
                    this.placementHit = null;
                } else {
                    this.interactAndWait(blockhitresult, hand, lastPlaceMillisValue);
                }
            }
        }
    }

    private double randomDouble(double d0, double d1) {
        return d1 <= d0 ? d0 : ThreadLocalRandom.current().nextDouble(d0, d1);
    }

    private Rotation rotationTo(Vec3d vec3d) {
        Vec3d vec3d1 = vec3d.subtract(client.player.getEyePos());
        double d0 = Math.hypot(vec3d1.x, vec3d1.z);
        float f = (float) (Math.toDegrees(Math.atan2(vec3d1.z, vec3d1.x)) - 90.0);
        float f1 = (float) (-Math.toDegrees(Math.atan2(vec3d1.y, d0)));
        return new Rotation(f, f1);
    }

    private void restoreSlot() {
        if (this.previousSlot != -1 && client.player != null && client.interactionManager != null) {
            client.player.getInventory().setSelectedSlot(this.previousSlot);
            client.interactionManager.syncSelectedSlot();
            this.previousSlot = -1;
        }
    }

    private float rotationStep(float f, float f1, float f2) {
        float f3 = Math.abs(f);
        if (f3 <= 0.08F) {
            return f;
        } else {
            float f4 = Math.max(0.85F, f3 * f2);
            return Math.copySign(Math.min(f3, Math.min(f1, f4)), f);
        }
    }

    private Vec3d getCrystalAimPoint(EndCrystalEntity endcrystalentity) {
        if (this.isBlockAbovePlayer(this.basePosition)) {
            Box box = endcrystalentity.getBoundingBox();
            Vec3d vec3dx = this.raisedAimPoint(this.basePosition);
            return new Vec3d(
                    MathHelper.clamp(vec3dx.x, box.minX + 0.04, box.maxX - 0.04),
                    MathHelper.clamp(vec3dx.y, box.minY + 0.04, box.maxY - 0.04),
                    MathHelper.clamp(vec3dx.z, box.minZ + 0.04, box.maxZ - 0.04));
        } else {
            return this.randomCrystalPoint(endcrystalentity);
        }
    }

    @Environment(EnvType.CLIENT)
    private static enum SequenceState {
        IDLE,
        PREPARE,
        PLACE_OBSIDIAN,
        PLACE_CRYSTAL,
        WAIT_CRYSTAL,
        BREAK_CRYSTAL;
    }
}
