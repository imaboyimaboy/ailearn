package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Stopwatch {
    public long startedAtMillis = System.currentTimeMillis();

    public void reset() {
        this.startedAtMillis = System.currentTimeMillis();
    }

    public boolean hasElapsed(long i) {
        return System.currentTimeMillis() - this.startedAtMillis > i;
    }

    public long elapsedMillis() {
        return System.currentTimeMillis() - this.startedAtMillis;
    }

    @Environment(EnvType.CLIENT)
    public static class legacyTime {
        private long startedAtMillis;

        public void reset() {
            this.startedAtMillis = System.currentTimeMillis();
        }

        private legacyTime() {
            this.reset();
        }
    }
}
