package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public record Rectangle(float x, float y, float width, float height) {
    public static final Rectangle EMPTY = new Rectangle(0.0F, 0.0F, 0.0F, 0.0F);

    public boolean contains(float mouseX, float mouseY) {
        return MathUtils.containsPoint(mouseX, mouseY, this.x, this.y, this.width, this.height);
    }

    public float centerY() {
        return this.y + this.height / 2.0F;
    }

    public float squaredDistanceToCenter(float pointX, float pointY) {
        float f2 = pointX - this.centerX();
        float f3 = pointY - this.centerY();
        return f2 * f2 + f3 * f3;
    }

    public float centerX() {
        return this.x + this.width / 2.0F;
    }
}
