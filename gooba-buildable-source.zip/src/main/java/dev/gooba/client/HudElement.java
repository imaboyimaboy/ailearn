package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface HudElement extends MinecraftAccess {
    void render(PositionSetting positionSetting2, HUDModule hUDModule);
}
