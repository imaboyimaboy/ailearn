package dev.gooba.client;

import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FieldOrder({"currentSize", "maxSize"})
@Environment(EnvType.CLIENT)
public class DiscordPartySize extends Structure {
    public int maxSize;
    public int currentSize;
}
