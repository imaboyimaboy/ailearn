package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class MillisecondTimer {
    private long startedAtMillis = System.currentTimeMillis();

    public boolean hasElapsed(long i) {
        return System.currentTimeMillis() - this.startedAtMillis >= i;
    }

    public void reset() {
        this.startedAtMillis = System.currentTimeMillis();
    }
}
