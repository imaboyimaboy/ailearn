package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class EventSubscriber {
    public EventSubscriber() {
        Gooba.getEventBus().subscribe(this);
    }
}
