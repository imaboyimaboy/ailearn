package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

@Environment(EnvType.CLIENT)
public class FontRenderer {
    private final FontBatchRenderer fontBatchRenderer;

    private static final Logger logger = LoggerFactory.getLogger("client/FontRenderer");

    private boolean initialized = false;
    private final Map<String, FontAtlas> atlases;

    public float getLineHeight(String text, float size) {
        FontAtlas fontAtlas2 = this.atlases.get(text);
        return fontAtlas2 == null
                ? size
                : fontAtlas2.getLineHeight() / fontAtlas2.getFontSize() * size;
    }

    public FontRenderer() {
        this.fontBatchRenderer = new FontBatchRenderer();
        this.atlases = new HashMap<>();
    }

    public void drawText(String text, String string, float f, float f1, float size, int color) {
        FontAtlas fontAtlas2 = this.atlases.get(text);
        if (fontAtlas2 != null) {
            this.fontBatchRenderer.drawText(fontAtlas2, string, f, f1, size, color, 0.0F, 0, 0.0F);
        }
    }

    public boolean isInitialized() {
        return this.initialized;
    }

    public void initialize(int i) {
        if (!this.initialized) {
            for (Entry entry : this.atlases.entrySet()) {
                ((FontAtlas) entry.getValue()).preload();
            }

            this.initialized = true;
        }
    }

    public void drawFadedText(
            String text, String string, float f, float f1, float size, float maxWidth, int color) {
        FontAtlas fontAtlas2 = this.atlases.get(text);
        if (fontAtlas2 != null) {
            this.fontBatchRenderer.drawFadedText(fontAtlas2, string, f, f1, size, maxWidth, color);
        }
    }

    public float measureWidth(String text, String string, float size) {
        FontAtlas fontAtlas2 = this.atlases.get(text);
        return fontAtlas2 == null
                ? 0.0F
                : this.fontBatchRenderer.measureWidth(fontAtlas2, string, size);
    }

    public void drawCenteredText(
            String text, String string, float f, float f1, float size, int color) {
        FontAtlas fontAtlas2 = this.atlases.get(text);
        if (fontAtlas2 != null) {
            float f3 = this.fontBatchRenderer.measureWidth(fontAtlas2, string, size);
            this.fontBatchRenderer.drawText(
                    fontAtlas2, string, f - f3 / 2.0F, f1, size, color, 0.0F, 0, 0.0F);
        }
    }

    public FontAtlas getFontAtlas(String text) {
        return this.atlases.get(text);
    }

    public void registerFont(String text, String textValue) {
        Identifier identifier = Identifier.of("client", "fonts/" + textValue + ".json");
        Identifier identifierValue = Identifier.of("client", "fonts/" + textValue + ".png");
        FontAtlas fontAtlas2 = new FontAtlas(identifier, identifierValue);
        this.atlases.put(text, fontAtlas2);
    }

    public void clear() {
        this.fontBatchRenderer.close();
        this.atlases.clear();
        this.initialized = false;
    }

    public void registerFonts(Map<String, String> map) {
        for (Entry entry : map.entrySet()) {
            this.registerFont((String) entry.getKey(), (String) entry.getValue());
        }
    }

    public void flush() {
        this.fontBatchRenderer.flush();
    }
}
