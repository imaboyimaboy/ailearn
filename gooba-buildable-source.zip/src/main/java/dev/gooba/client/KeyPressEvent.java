package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class KeyPressEvent extends Event {
    private int key;

    public int getKey() {
        return this.key;
    }

    public KeyPressEvent(int keyValue) {
        this.key = keyValue;
    }

    public void setKey(int keyValue) {
        this.key = keyValue;
    }
}
