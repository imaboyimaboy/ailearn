package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class HandSwingEvent extends CancellableEvent {
    private float speedMultiplier;

    public void setAnimation(float animationValue) {
        this.speedMultiplier = animationValue;
    }

    public float getAnimation() {
        return this.speedMultiplier;
    }
}
