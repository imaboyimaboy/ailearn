package dev.gooba.client;

import com.sun.jna.Callback;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FieldOrder({"vtable"})
@Environment(EnvType.CLIENT)
public class DiscordActivityManager extends Structure {
    public DiscordActivityManagerVtable vtable;

    public DiscordActivityManager() {}

    public DiscordActivityManager(Pointer pointer) {
        super(pointer);
        this.read();
    }

    @Environment(EnvType.CLIENT)
    public static class UpdateActivityCallback implements Callback {
        private final Runnable runnable;

        public UpdateActivityCallback(Runnable runnable) {
            this.runnable = runnable;
        }

        public void callback(Pointer pointer) {
            if (this.runnable != null) {
                try {
                    this.runnable.run();
                } catch (Throwable throwable) {
                }
            }
        }
    }

    public void clearActivity(
            DiscordActivityManager.UpdateActivityCallback updateActivityCallback) {
        this.vtable.clear_activity.invoke(
                Pointer.nativeValue(this.getPointer()), null, updateActivityCallback);
    }

    public void updateActivity(
            DiscordActivity discordActivity,
            DiscordActivityManager.UpdateActivityCallback updateActivityCallback) {
        this.vtable.update_activity.invoke(
                Pointer.nativeValue(this.getPointer()),
                discordActivity,
                null,
                updateActivityCallback);
    }
}
