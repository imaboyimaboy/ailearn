package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum HandTransformMode {
    LINEAR(Easings.LINEAR),
    QUAD_OUT(Easings.OUT_QUAD),
    CUBIC_OUT(Easings.OUT_CUBIC),
    QUART_OUT(Easings.OUT_QUART),
    QUINT_OUT(Easings.OUT_QUINT),
    SINE_OUT(Easings.OUT_SINE),
    CIRC_OUT(Easings.OUT_CIRC),
    ELASTIC_OUT(Easings.OUT_ELASTIC),
    EXPO_OUT(Easings.OUT_EXPO),
    BACK_OUT(Easings.OUT_BACK_ALT),
    BOUNCE_OUT(Easings.OUT_BOUNCE);

    private final EasingFunction easing;

    @Override
    public String toString() {
        String text = this.name().toLowerCase();
        String[] astring = text.split("_");
        StringBuilder stringbuilder = new StringBuilder();

        for (String textValue : astring) {
            stringbuilder
                    .append(Character.toUpperCase(textValue.charAt(0)))
                    .append(textValue.substring(1))
                    .append(" ");
        }

        return stringbuilder.toString().trim();
    }

    private HandTransformMode(EasingFunction easingFunction33) {
        this.easing = easingFunction33;
    }
}
