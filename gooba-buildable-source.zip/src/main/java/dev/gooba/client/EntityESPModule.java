package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4f;
import org.joml.Vector4d;

import java.util.ArrayList;
import java.util.List;

@ModuleInfo(
        name = "Entity ESP",
        category = ModuleCategory.RENDER,
        desc = "Draws 2D or 3D boxes around selected entities through walls")
@Environment(EnvType.CLIENT)
public class EntityESPModule extends Module {
    private static final RenderPipeline LINE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("minecraft", "rendertype_lines"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.DEBUG_LINES)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    private static final RenderLayer LINE_LAYER =
            RenderLayer.of(
                    "goobaa_esp_box_line",
                    RenderSetup.builder(EntityESPModule.LINE_PIPELINE)
                            .expectedBufferSize(4096)
                            .build());
    private static final RenderPipeline FILL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(
                                    Identifier.of("minecraft", "rendertype_lequal_depth_test"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    private final BufferAllocator bufferAllocator;
    private final List<Entity> entities;
    public BooleanSetting playersSetting = new BooleanSetting(this, "Players", true);
    public BooleanSetting ignoreUnarmoredPlayersSetting =
            new BooleanSetting(this, "Ignore Unarmored Players", false)
                    .visibleWhen(() -> this.playersSetting.isOn());
    private static final RenderLayer FILL_LAYER =
            RenderLayer.of(
                    "goobaa_esp_box_fill",
                    RenderSetup.builder(EntityESPModule.FILL_PIPELINE)
                            .expectedBufferSize(4096)
                            .build());
    public ModeSetting boxStyleSetting;
    public BooleanSetting droppedItemsSetting;
    public BooleanSetting mobsSetting = new BooleanSetting(this, "Mobs", true);

    public static void drawDashedLine(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            double d0,
            double d1,
            double d2,
            double d3,
            double d4,
            double d5,
            int i,
            int j,
            double d6,
            double d7) {
        double d8 = d3 - d0;
        double d9 = d4 - d1;
        double d10 = d5 - d2;
        double d11 = Math.sqrt(d8 * d8 + d9 * d9 + d10 * d10);
        if (!(d11 < 0.001)) {
            double d12 = d8 / d11;
            double d13 = d9 / d11;
            double d14 = d10 / d11;
            int k = i >> 16 & 0xFF;
            int l = i >> 8 & 0xFF;
            int i11 = i & 0xFF;
            int j1 = i >> 24 & 0xFF;
            int k1 = j >> 16 & 0xFF;
            int l1 = j >> 8 & 0xFF;
            int i2 = j & 0xFF;
            int j2 = j >> 24 & 0xFF;
            double d15 = d6 + d7;

            for (double d16 = 0.0; d16 < d11; d16 += d15) {
                double d17 = Math.min(d16 + d6, d11);
                if (d17 > d16) {
                    double d18 = d0 + d12 * d16;
                    double d19 = d1 + d13 * d16;
                    double d20 = d2 + d14 * d16;
                    double d21 = d0 + d12 * d17;
                    double d22 = d1 + d13 * d17;
                    double d23 = d2 + d14 * d17;
                    double d24 = d16 / d11;
                    int k2 = (int) ((double) k + (double) (k1 - k) * d24);
                    int l2 = (int) ((double) l + (double) (l1 - l) * d24);
                    int i3 = (int) ((double) i11 + (double) (i2 - i11) * d24);
                    int j3 = (int) ((double) j1 + (double) (j2 - j1) * d24);
                    vertexconsumer
                            .vertex(matrix4f, (float) d18, (float) d19, (float) d20)
                            .color(k2, l2, i3, j3);
                    d24 = d17 / d11;
                    k2 = (int) ((double) k + (double) (k1 - k) * d24);
                    l2 = (int) ((double) l + (double) (l1 - l) * d24);
                    i3 = (int) ((double) i11 + (double) (i2 - i11) * d24);
                    j3 = (int) ((double) j1 + (double) (j2 - j1) * d24);
                    vertexconsumer
                            .vertex(matrix4f, (float) d21, (float) d22, (float) d23)
                            .color(k2, l2, i3, j3);
                }
            }
        }
    }

    public static void drawFilledBox(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            double d0,
            double d1,
            double d2,
            double d3,
            double d4,
            double d5,
            int[] aint,
            int alpha) {
        int j = ColorUtils.withAlpha(aint[0], alpha);
        int k = ColorUtils.withAlpha(aint[1], alpha);
        int l = ColorUtils.withAlpha(aint[2], alpha);
        int i1 = ColorUtils.withAlpha(aint[3], alpha);
        float f = (float) d0;
        float f1 = (float) d3;
        float f2 = (float) d1;
        float f3 = (float) d4;
        float f4 = (float) d2;
        float f5 = (float) d5;
        vertexconsumer.vertex(matrix4f, f, f2, f4).color(j);
        vertexconsumer.vertex(matrix4f, f1, f2, f4).color(k);
        vertexconsumer.vertex(matrix4f, f1, f2, f5).color(l);
        vertexconsumer.vertex(matrix4f, f, f2, f5).color(i1);
        vertexconsumer.vertex(matrix4f, f, f3, f4).color(j);
        vertexconsumer.vertex(matrix4f, f, f3, f5).color(i1);
        vertexconsumer.vertex(matrix4f, f1, f3, f5).color(l);
        vertexconsumer.vertex(matrix4f, f1, f3, f4).color(k);
        vertexconsumer.vertex(matrix4f, f, f2, f5).color(i1);
        vertexconsumer.vertex(matrix4f, f1, f2, f5).color(l);
        vertexconsumer.vertex(matrix4f, f1, f3, f5).color(l);
        vertexconsumer.vertex(matrix4f, f, f3, f5).color(i1);
        vertexconsumer.vertex(matrix4f, f1, f2, f4).color(k);
        vertexconsumer.vertex(matrix4f, f, f2, f4).color(j);
        vertexconsumer.vertex(matrix4f, f, f3, f4).color(j);
        vertexconsumer.vertex(matrix4f, f1, f3, f4).color(k);
        vertexconsumer.vertex(matrix4f, f, f2, f4).color(j);
        vertexconsumer.vertex(matrix4f, f, f2, f5).color(i1);
        vertexconsumer.vertex(matrix4f, f, f3, f5).color(i1);
        vertexconsumer.vertex(matrix4f, f, f3, f4).color(j);
        vertexconsumer.vertex(matrix4f, f1, f2, f5).color(l);
        vertexconsumer.vertex(matrix4f, f1, f2, f4).color(k);
        vertexconsumer.vertex(matrix4f, f1, f3, f4).color(k);
        vertexconsumer.vertex(matrix4f, f1, f3, f5).color(l);
    }

    @EventHandler
    public void onRender2D(Render2DEvent render2DEvent) {
        float partialTicks = render2DEvent.getPartialTicks();
        if (client.world != null && client.player != null) {
            if (this.boxStyleSetting.isSelected("2D")) {
                for (Entity entity : this.entities) {
                    Vector4d vector4d = ProjectionUtils.projectEntityBounds(entity, partialTicks);
                    if (!ProjectionUtils.isOutsideScreen(vector4d)) {
                        float f1 =
                                (float)
                                        client.gameRenderer
                                                .getCamera()
                                                .getCameraPos()
                                                .distanceTo(entity.getBoundingBox().getCenter());
                        if (!(f1 < 1.0F)) {
                            boolean flag1;
                            label28:
                            {
                                if (entity instanceof PlayerEntity playerentity
                                        && Gooba.getInstance()
                                                .getFriendManager()
                                                .isFriend(playerentity.getName().getString())) {
                                    flag1 = true;
                                    break label28;
                                }

                                flag1 = false;
                            }

                            boolean flag = flag1;
                            this.drawCornerBox(flag, vector4d, entity);
                        }
                    }
                }
            }
        }
    }

    private void drawCornerBox(boolean flag, Vector4d vector4d, Entity entity) {
        int color = flag ? ColorUtils.rgb(100, 200, 100) : ColorUtils.animatedAccent(1);
        float innerX = (float) vector4d.x;
        float innerY = (float) vector4d.y;
        float f2 = (float) vector4d.z;
        float f3 = (float) vector4d.w;
        float width = (f2 - innerX) / 3.0F;
        float height = 1.15F;
        RenderUtils.Render2D.drawRect(innerX, innerY, width, height, color);
        RenderUtils.Render2D.drawRect(innerX, innerY, height, width, color);
        RenderUtils.Render2D.drawRect(innerX, f3 - width, height, width, color);
        RenderUtils.Render2D.drawRect(innerX, f3 - height, width, height, color);
        RenderUtils.Render2D.drawRect(f2 - width, innerY, width, height, color);
        RenderUtils.Render2D.drawRect(f2 - height, innerY, height, width, color);
        RenderUtils.Render2D.drawRect(f2 - height, f3 - width, height, width, color);
        RenderUtils.Render2D.drawRect(f2 - width, f3 - height, width, height, color);
    }

    private void drawEntityBox(
            MatrixStack matrixstack, Immediate immediate, Entity entity, float f) {
        if (entity != null) {
            Vec3d vec3d = client.gameRenderer.getCamera().getCameraPos();
            double d0 = entity.lastRenderX + (entity.getX() - entity.lastRenderX) * (double) f;
            double d1 = entity.lastRenderY + (entity.getY() - entity.lastRenderY) * (double) f;
            double d2 = entity.lastRenderZ + (entity.getZ() - entity.lastRenderZ) * (double) f;
            Box box = entity.getBoundingBox();
            double d3 = 0.0;
            if (HitboxesModule.getInstance().isEnabled() && entity instanceof PlayerEntity) {
                d3 =
                        (double)
                                HitboxesModule.getInstance()
                                        .hitboxSizeSetting
                                        .getFloat()
                                        .floatValue();
            }

            double d4;
            double d5;
            double d6;
            double d7;
            double d8;
            double d9;
            int j;
            label19:
            {
                d4 = box.minX - entity.getX() + d0 - d3 - vec3d.x;
                d5 = box.minY - entity.getY() + d1 - d3 - vec3d.y;
                d6 = box.minZ - entity.getZ() + d2 - d3 - vec3d.z;
                d7 = box.maxX - entity.getX() + d0 + d3 - vec3d.x;
                d8 = box.maxY - entity.getY() + d1 + d3 - vec3d.y;
                d9 = box.maxZ - entity.getZ() + d2 + d3 - vec3d.z;
                if (entity instanceof AbstractClientPlayerEntity abstractclientplayerentity
                        && Gooba.getInstance()
                                .getFriendManager()
                                .isFriend(abstractclientplayerentity.getNameForScoreboard())) {
                    j = ColorUtils.GREEN;
                    break label19;
                }

                j = ColorUtils.hudAccent();
            }

            int startColor = j;
            int[] aint =
                    new int[] {
                        ColorUtils.saturatedGradient(startColor, startColor, 0, 7),
                        ColorUtils.saturatedGradient(startColor, startColor, 90, 7),
                        ColorUtils.saturatedGradient(startColor, startColor, 180, 7),
                        ColorUtils.saturatedGradient(startColor, startColor, 270, 7)
                    };
            Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
            VertexConsumer vertexconsumer = immediate.getBuffer(FILL_LAYER);
            drawFilledBox(vertexconsumer, matrix4f, d4, d5, d6, d7, d8, d9, aint, 10);
            VertexConsumer buffer = immediate.getBuffer(LINE_LAYER);
            drawDashedBox(buffer, matrix4f, d4, d5, d6, d7, d8, d9, aint, 255, 0.12, 0.08);
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        this.entities.clear();
        if (client.world != null) {
            for (Entity entity : client.world.getEntities()) {
                if (entity instanceof PlayerEntity) {
                    PlayerEntity playerentity = (PlayerEntity) entity;
                    if (this.playersSetting.isOn()
                            && (playerentity.getCustomName() == null
                                    || !playerentity
                                            .getCustomName()
                                            .getString()
                                            .startsWith("Ghost_"))
                            && (!this.ignoreUnarmoredPlayersSetting.isOn()
                                    || isArmored(playerentity))) {
                        this.entities.add(entity);
                    }
                } else if (entity instanceof LivingEntity) {
                    if (this.mobsSetting.isOn()) {
                        this.entities.add(entity);
                    }
                } else if (entity instanceof ItemEntity && this.droppedItemsSetting.isOn()) {
                    this.entities.add(entity);
                }
            }
        }
    }

    public static boolean isArmored(PlayerEntity playerentity) {
        return !playerentity.getEquippedStack(EquipmentSlot.HEAD).isEmpty()
                || !playerentity.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
                || !playerentity.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
                || !playerentity.getEquippedStack(EquipmentSlot.FEET).isEmpty();
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.entities.clear();
        this.bufferAllocator.clear();
    }

    public EntityESPModule() {
        this.droppedItemsSetting = new BooleanSetting(this, "Dropped Items", true);
        this.boxStyleSetting = new ModeSetting(this, "Box Style", new String[] {"2D", "3D"});
        this.entities = new ArrayList<>();
        this.bufferAllocator = new BufferAllocator(262144);
    }

    public static void drawDashedBox(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            double d0,
            double d1,
            double d2,
            double d3,
            double d4,
            double d5,
            int[] aint,
            int alpha,
            double d6,
            double d7) {
        int[] values = new int[4];

        for (int j = 0; j < 4; j++) {
            values[j] = ColorUtils.withAlpha(aint[j], alpha);
        }

        drawDashedLine(
                vertexconsumer, matrix4f, d0, d1, d2, d3, d1, d2, values[0], values[1], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d3, d1, d2, d3, d1, d5, values[1], values[2], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d3, d1, d5, d0, d1, d5, values[2], values[3], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d0, d1, d5, d0, d1, d2, values[3], values[0], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d0, d4, d2, d3, d4, d2, values[0], values[1], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d3, d4, d2, d3, d4, d5, values[1], values[2], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d3, d4, d5, d0, d4, d5, values[2], values[3], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d0, d4, d5, d0, d4, d2, values[3], values[0], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d0, d1, d2, d0, d4, d2, values[0], values[0], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d3, d1, d2, d3, d4, d2, values[1], values[1], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d3, d1, d5, d3, d4, d5, values[2], values[2], d6, d7);
        drawDashedLine(
                vertexconsumer, matrix4f, d0, d1, d5, d0, d4, d5, values[3], values[3], d6, d7);
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        float tickDelta = render3DEvent.getTickDelta();
        if (client.world != null && client.player != null && !this.entities.isEmpty()) {
            if (this.boxStyleSetting.isSelected("3D")) {
                Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);

                for (Entity entity : this.entities) {
                    if ((entity != client.player
                                    || !client.options.getPerspective().isFirstPerson())
                            && ProjectionUtils.isInFrontOfCamera(
                                    entity.getBoundingBox().getCenter())) {
                        this.drawEntityBox(
                                render3DEvent.getMatrixStack(), immediate, entity, tickDelta);
                    }
                }

                immediate.draw();
            }
        }
    }
}
