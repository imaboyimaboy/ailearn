package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.Identifier;

import org.joml.Vector2f;

import java.util.List;

@Environment(EnvType.CLIENT)
public class Gps extends Command implements MinecraftAccess {

    private static final Identifier ARROW_TEXTURE = Identifier.of("client", "textures/arrow.png");
    private Vector2f destination = null;

    public Gps() {
        super("gps", ".gps <set|off> <x> <z>", "Arrow on the screen leading to the coordinates");
        Gooba.getEventBus().subscribe(this);
    }

    @Override
    public List suggest(String text) {
        return List.of("set", "off").stream()
                .filter(textValue -> textValue.startsWith(text.toLowerCase()))
                .toList();
    }

    @EventHandler(priority = -500)
    public void onRender2D(Render2DEvent render2DEvent) {
        if (client.player != null && client.world != null) {
            if (this.destination != null) {
                if (!client.options.hudHidden) {
                    if (client.options.getPerspective().equals(Perspective.FIRST_PERSON)) {
                        double d0 = (double) this.destination.x + 0.5 - client.player.getX();
                        double d1 = (double) this.destination.y + 0.5 - client.player.getZ();
                        int i = (int) Math.sqrt(d0 * d0 + d1 * d1);
                        float f = 2.0F;
                        float scaleFactor = (float) client.getWindow().getScaleFactor();
                        float f2 = f / scaleFactor;
                        int j = (int) ((float) client.getWindow().getScaledWidth() / f2);
                        int k = (int) ((float) client.getWindow().getScaledHeight() / f2);
                        float f3 = (float) j / 2.0F;
                        float f4 = (float) k / 2.0F - 90.0F;
                        float f5 = (float) (-(Math.atan2(d0, d1) * (180.0 / Math.PI)));
                        float f6 = f5 - client.gameRenderer.getCamera().getYaw();
                        float f7 = (float) Math.toRadians((double) f6);
                        float f8 = f4 - 30.0F;
                        float f9 = f8 + 10.0F - f4;
                        float f10 = f3 - f9 * (float) Math.sin((double) f7);
                        float f11 = f4 + f9 * (float) Math.cos((double) f7);
                        int l = ColorUtils.animatedAccent(1);
                        Gooba.getInstance()
                                .getHudManager()
                                .getTextureBatchRenderer()
                                .drawGlow(
                                        ARROW_TEXTURE,
                                        f10 - 10.0F,
                                        f11 - 10.0F,
                                        20.0F,
                                        20.0F,
                                        0.0F,
                                        0.0F,
                                        1.0F,
                                        1.0F,
                                        new int[] {l, l, l, l},
                                        new float[] {0.0F, 0.0F, 0.0F, 0.0F},
                                        1.0F,
                                        f6);
                        Fonts.SF_REGULAR.drawCenteredText(
                                i + "m",
                                f10,
                                f11 + 10.0F + 4.0F,
                                6.0F,
                                ColorUtils.grayscaleOpacity(255, 0.85F));
                    }
                }
            }
        }
    }

    @Override
    public void execute(String[] astring) {
        if (astring.length == 0) {
            this.showUsage();
        } else {
            String text = astring[0].toLowerCase();
            switch (text.hashCode()) {
                case 109935:
                    if (text.equals("off")) {
                        this.destination = null;
                        ChatMessages.send("§7GPS reset");
                        return;
                    }
                    break;
                case 113762:
                    if (text.equals("set")) {
                        if (astring.length < 3) {
                            ChatMessages.send("§7Usage: §f.gps set <x> <z>");
                            return;
                        }

                        try {
                            float f = Float.parseFloat(astring[1]);
                            float f1 = Float.parseFloat(astring[2]);
                            this.destination = new Vector2f(f, f1);
                            int k = (int) f;
                            int j = (int) f1;
                            int i = k;
                            ChatMessages.send("§aGPS §7→ §f" + i + "§7, §f" + j);
                        } catch (NumberFormatException numberformatexception) {
                            ChatMessages.send("§cError: incorrect coordinates");
                        }

                        return;
                    }
            }

            this.showUsage();
        }
    }

    private void showUsage() {
        ChatMessages.send("§7.gps §fset §7<x> <z> §8| §7.gps §foff");
    }
}
