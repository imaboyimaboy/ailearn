package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "World Tweaks",
        desc = "Overrides world time, fog distance, and fog color",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class WorldTweaksModule extends Module {
    public ModeSetting colorModeSetting;
    public BooleanSetting overrideTimeSetting = new BooleanSetting(this, "Override Time", true);
    public BooleanSetting overrideFogSetting = new BooleanSetting(this, "Override Fog", true);
    public SliderSetting fogDistanceSetting;
    public ColorSetting colorSetting;
    public SliderSetting timeSetting =
            new SliderSetting(this, "Time", 12.0F, 0.0F, 24.0F, 1.0F)
                    .visibleWhen(() -> this.overrideTimeSetting.isOn());

    @EventHandler
    public void onFog(FogEvent fogEvent) {
        if (this.overrideFogSetting.isOn()) {
            fogEvent.setDistance(this.fogDistanceSetting.getFloat());
            fogEvent.setColor(this.getFogColor());
            fogEvent.cancel();
        }
    }

    public int getFogColor() {
        return this.colorModeSetting.isSelected("Theme")
                ? ColorUtils.hudAccent()
                : this.colorSetting.getColor();
    }

    public static WorldTweaksModule getInstance() {
        return (WorldTweaksModule) ModuleLookup.getModule(WorldTweaksModule.class);
    }

    public WorldTweaksModule() {
        this.fogDistanceSetting =
                new SliderSetting(this, "Fog distance", 100.0F, 2.0F, 200.0F, 1.0F)
                        .visibleWhen(() -> this.overrideFogSetting.isOn());
        this.colorModeSetting =
                new ModeSetting(this, "Color Mode", new String[] {"Theme", "Custom"});
        this.colorSetting =
                new ColorSetting(this, "Color", -16711681)
                        .visibleWhen(() -> this.colorModeSetting.isSelected("Custom"));
    }
}
