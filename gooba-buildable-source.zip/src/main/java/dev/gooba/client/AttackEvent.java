package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;

@Environment(EnvType.CLIENT)
public class AttackEvent extends CancellableEvent {
    private Entity target;

    public void setTarget(Entity entity) {
        this.target = entity;
    }

    public AttackEvent(Entity entity) {
        this.target = entity;
    }

    public Entity getTarget() {
        return this.target;
    }
}
