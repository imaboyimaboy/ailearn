package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.scoreboard.ScoreAccess;
import net.minecraft.scoreboard.ScoreHolder;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardCriterion.RenderType;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.number.BlankNumberFormat;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

import java.util.ArrayList;
import java.util.List;

@ModuleInfo(
        name = "Fake Scoreboard",
        category = ModuleCategory.DONUT,
        desc = "Replaces the sidebar with your own stats.")
@Environment(EnvType.CLIENT)
public class FakeScoreboardModule extends Module {
    public final TextSetting deathsAmountSetting;
    public final TextSetting moneyAmountSetting;
    public final TextSetting shardsAmountSetting;

    private ScoreboardObjective originalObjective;
    public final BooleanSetting deathsSetting;
    private long lastUpdateMillis;
    public final BooleanSetting playtimeSetting;
    public final BooleanSetting killsSetting;
    public final TextSetting playtimeAmountSetting;
    private ScoreboardObjective fakeObjective;
    public final BooleanSetting shardsSetting;
    private final List<String> teamNames;
    public final BooleanSetting moneySetting;
    public final TextSetting killsAmountSetting;
    public final TextSetting titleSetting = new TextSetting(this, "Title", "Goobaa");

    @Override
    protected void onDisable() {
        this.restoreScoreboard();
    }

    private MutableText plainText(String text) {

        String textValue;
        if (text == null) {

            textValue = "";
        } else {

            textValue = text;
        }

        return this.coloredText(textValue, 16777215);
    }

    private List<Text> scoreboardLines() {
        ArrayList arraylist = new ArrayList();
        if (this.moneySetting.isOn()) {
            arraylist.add(this.coloredText("$ ", 65280).append(this.plainText(this.moneyLabel())));
        }

        if (this.shardsSetting.isOn()) {
            arraylist.add(
                    this.coloredText("★ ", 10814460)
                            .append(this.plainText(this.shardsAmountSetting.getText())));
        }

        if (this.killsSetting.isOn()) {
            arraylist.add(
                    this.coloredText("\ud83d\udde1 ", 16711680)
                            .append(this.plainText(this.killsAmountSetting.getText())));
        }

        if (this.deathsSetting.isOn()) {
            arraylist.add(
                    this.coloredText("☠ ", 16545539)
                            .append(this.plainText(this.deathsAmountSetting.getText())));
        }

        if (this.playtimeSetting.isOn()) {
            arraylist.add(
                    this.coloredText("⌚ ", 16770560)
                            .append(this.plainText(this.playtimeAmountSetting.getText())));
        }

        if (arraylist.isEmpty()) {
            arraylist.add(Text.literal(" "));
        }

        return arraylist;
    }

    private void restoreScoreboard() {
        if (client.world == null) {
            this.fakeObjective = null;
            this.teamNames.clear();
        } else {
            Scoreboard scoreboard = client.world.getScoreboard();
            this.removeTeams(scoreboard);
            if (this.fakeObjective != null) {
                try {
                    scoreboard.removeObjective(this.fakeObjective);
                } catch (Exception exceptionValue) {
                }

                this.fakeObjective = null;
            }

            ScoreboardObjective scoreboardobjective;
            scoreboardobjective = null;
            label38:
            if (this.originalObjective != null) {
                try {
                    if (scoreboard.getNullableObjective(this.originalObjective.getName()) == null) {
                        break label38;
                    }
                } catch (Exception exception4) {
                    break label38;
                }

                try {
                    scoreboardobjective = this.originalObjective;
                } catch (Exception exception5) {
                }
            }

            try {
                scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, scoreboardobjective);
            } catch (Exception exception) {
            }

            this.originalObjective = null;
        }
    }

    private void removeTeams(Scoreboard scoreboard) {
        for (String text : this.teamNames) {
            try {
                Team team = scoreboard.getTeam(text);
                if (team != null) {
                    scoreboard.removeTeam(team);
                }
            } catch (Exception exception) {
            }
        }

        this.teamNames.clear();
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.world != null && client.player != null) {
            long nowMillis = System.currentTimeMillis();
            if (nowMillis - this.lastUpdateMillis >= 1000L) {
                this.lastUpdateMillis = nowMillis;
                this.updateScoreboard();
            }
        } else {
            this.fakeObjective = null;
            this.originalObjective = null;
            this.teamNames.clear();
            this.lastUpdateMillis = 0L;
        }
    }

    @Override
    protected void onEnable() {
        this.lastUpdateMillis = 0L;
        this.updateScoreboard();
    }

    public FakeScoreboardModule() {
        this.moneySetting = new BooleanSetting(this, "Money", true);
        this.moneyAmountSetting =
                new TextSetting(this, "Money Amount", "Goobaa")
                        .visibleWhen(this.moneySetting::isOn);
        this.shardsSetting = new BooleanSetting(this, "Shards", true);
        this.shardsAmountSetting =
                new TextSetting(this, "Shards Amount", "Goobaa")
                        .visibleWhen(this.shardsSetting::isOn);
        this.killsSetting = new BooleanSetting(this, "Kills", true);
        this.killsAmountSetting =
                new TextSetting(this, "Kills Amount", "Goobaa")
                        .visibleWhen(this.killsSetting::isOn);
        this.deathsSetting = new BooleanSetting(this, "Deaths", true);
        this.deathsAmountSetting =
                new TextSetting(this, "Deaths Amount", "Goobaa")
                        .visibleWhen(this.deathsSetting::isOn);
        this.playtimeSetting = new BooleanSetting(this, "Playtime", true);
        this.playtimeAmountSetting =
                new TextSetting(this, "Playtime Amount", "Goobaa")
                        .visibleWhen(this.playtimeSetting::isOn);
        this.teamNames = new ArrayList<>();
    }

    private void updateScoreboard() {
        if (client.world != null && client.player != null) {
            Scoreboard scoreboard = client.world.getScoreboard();
            ScoreboardObjective scoreboardobjective =
                    scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
            if (scoreboardobjective != null
                    && !"goobaa_fakesb".equals(scoreboardobjective.getName())) {
                this.originalObjective = scoreboardobjective;
            }

            this.removeTeams(scoreboard);
            ScoreboardObjective nullableObjective =
                    scoreboard.getNullableObjective("goobaa_fakesb");
            if (nullableObjective != null) {
                try {
                    scoreboard.removeObjective(nullableObjective);
                } catch (Exception exception) {
                }
            }

            this.fakeObjective =
                    scoreboard.addObjective(
                            "goobaa_fakesb",
                            ScoreboardCriterion.DUMMY,
                            this.plainText(this.titleSetting.getText()),
                            RenderType.INTEGER,
                            false,
                            BlankNumberFormat.INSTANCE);
            scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, this.fakeObjective);
            List listx = this.scoreboardLines();

            for (int i = 0; i < listx.size(); i++) {
                String text = "goobaa_sb_" + i;
                this.teamNames.add(text);
                Team team = scoreboard.getTeam(text);
                if (team != null) {
                    scoreboard.removeTeam(team);
                }

                team = scoreboard.addTeam(text);
                team.setPrefix((Text) listx.get(i));
                String textValue = Integer.toHexString(i);
                String text2 = "§" + textValue;
                ScoreHolder scoreholder = ScoreHolder.fromName(text2);
                ScoreAccess scoreaccess =
                        scoreboard.getOrCreateScore(scoreholder, this.fakeObjective);
                scoreaccess.setScore(listx.size() - i);
                scoreaccess.setNumberFormat(BlankNumberFormat.INSTANCE);
                scoreboard.addScoreHolderToTeam(text2, team);
            }
        }
    }

    private MutableText coloredText(String text, int i) {
        return Text.literal(text).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(i)));
    }

    private String moneyLabel() {
        Double value = NumberFormatter.parseCompact(this.moneyAmountSetting.getText());
        return value == null
                ? this.moneyAmountSetting.getText()
                : NumberFormatter.formatCompact(Math.max(0.0, value));
    }
}
