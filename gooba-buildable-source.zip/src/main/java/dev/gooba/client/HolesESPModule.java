package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.chunk.WorldChunk;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@ModuleInfo(
        name = "Holes ESP",
        category = ModuleCategory.OTHER,
        desc = "Highlights 1x1 (purple) and 3x1 (dark purple) holes.")
@Environment(EnvType.CLIENT)
public final class HolesESPModule extends Module {
    private final ConcurrentHashMap<BlockPos, Integer> holes;
    private ExecutorService scanExecutor;
    public final ColorSetting tripleHoleColor;
    public final ColorSetting singleHoleColor;
    private int cleanupTicks;
    public final SliderSetting opacitySetting =
            new SliderSetting(this, "Opacity", 60.0F, 0.0F, 255.0F, 1.0F);

    private void scanHole(BlockPos blockpos) {
        if (client.world != null) {
            if (this.isPassable(blockpos)) {
                if (this.isSingleHole(blockpos)) {
                    Mutable mutable =
                            new Mutable(blockpos.getX(), blockpos.getY(), blockpos.getZ());

                    while (this.isSingleHole(mutable)) {
                        mutable.move(Direction.UP);
                    }

                    if (mutable.getY() - blockpos.getY() >= 4) {
                        this.holes.putIfAbsent(blockpos, 0);
                    }
                }
            }
        }
    }

    private boolean isEastWestHole(WorldChunk worldchunk, BlockPos blockpos) {
        return this.isPassable(worldchunk, blockpos)
                && this.isPassable(worldchunk, blockpos.east(1))
                && this.isPassable(worldchunk, blockpos.east(2))
                && !this.isPassable(worldchunk, blockpos.north())
                && !this.isPassable(worldchunk, blockpos.south())
                && !this.isPassable(worldchunk, blockpos.east(3))
                && !this.isPassable(worldchunk, blockpos.west())
                && !this.isPassable(worldchunk, blockpos.east(1).north())
                && !this.isPassable(worldchunk, blockpos.east(1).south())
                && !this.isPassable(worldchunk, blockpos.east(2).north())
                && !this.isPassable(worldchunk, blockpos.east(2).south());
    }

    private BlockState getBlockState(WorldChunk worldchunk, BlockPos blockpos) {
        int i = blockpos.getX() >> 4;
        int j = blockpos.getZ() >> 4;
        if (i == worldchunk.getPos().x && j == worldchunk.getPos().z) {
            return worldchunk.getBlockState(blockpos);
        } else {
            return client.world != null
                    ? client.world.getBlockState(blockpos)
                    : Blocks.AIR.getDefaultState();
        }
    }

    private void queueChunkScan(WorldChunk worldchunk) {
        if (this.scanExecutor != null && !this.scanExecutor.isShutdown()) {
            this.scanExecutor.submit(() -> this.scanChunk(worldchunk));
        }
    }

    private boolean isSingleHole(BlockPos blockpos) {
        return this.isPassable(blockpos)
                && !this.isPassable(blockpos.north())
                && !this.isPassable(blockpos.south())
                && !this.isPassable(blockpos.east())
                && !this.isPassable(blockpos.west());
    }

    public HolesESPModule() {
        this.singleHoleColor = new ColorSetting(this, "1x1 Color", -6283024);
        this.tripleHoleColor = new ColorSetting(this, "3x1 Color", -12058494);
        this.holes = new ConcurrentHashMap<>();
        this.cleanupTicks = 0;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null) {
            if (++this.cleanupTicks >= 20) {
                this.cleanupTicks = 0;
                int value = client.options.getViewDistance().getValue();
                ChunkPos chunkpos = client.player.getChunkPos();
                this.holes
                        .keySet()
                        .removeIf(blockpos -> isOutsideViewDistance(blockpos, chunkpos, value));
            }
        }
    }

    private boolean isSingleHole(WorldChunk worldchunk, BlockPos blockpos) {
        return this.isPassable(worldchunk, blockpos)
                && !this.isPassable(worldchunk, blockpos.north())
                && !this.isPassable(worldchunk, blockpos.south())
                && !this.isPassable(worldchunk, blockpos.east())
                && !this.isPassable(worldchunk, blockpos.west());
    }

    @EventHandler
    public void onBlockUpdate(BlockUpdateEvent blockUpdateEvent) {
        if (client.world != null) {
            BlockPos blockpos = blockUpdateEvent.getPos();

            for (int i = -3; i <= 3; i++) {
                for (int j = -3; j <= 3; j++) {
                    for (int k = -1; k <= 4; k++) {
                        BlockPos blockposValue = blockpos.add(i, k, j).toImmutable();
                        this.holes.remove(blockposValue);
                        this.scanHole(blockposValue);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null && !this.holes.isEmpty()) {
            int i = Math.max(0, Math.min(255, Math.round(this.opacitySetting.getFloat())));
            if (i != 0) {
                int value = client.options.getViewDistance().getValue();
                ChunkPos chunkpos = client.player.getChunkPos();
                int k = i << 24 | this.singleHoleColor.getColor() & 16777215;
                int l = i << 24 | this.tripleHoleColor.getColor() & 16777215;
                WorldEspRenderer.clear();
                this.holes.forEach(
                        (blockpos, integer) -> {
                            if (!isOutsideViewDistance(blockpos, chunkpos, value)) {
                                double d0 = (double) blockpos.getX();
                                double d1 = (double) blockpos.getY();
                                double d2 = (double) blockpos.getZ();

                                Box box =
                                        switch (integer) {
                                            case 0 ->
                                                    new Box(
                                                            d0, d1, d2, d0 + 1.0, d1 + 4.0,
                                                            d2 + 1.0);
                                            case 1 ->
                                                    new Box(
                                                            d0, d1, d2, d0 + 3.0, d1 + 4.0,
                                                            d2 + 1.0);
                                            case 2 ->
                                                    new Box(
                                                            d0, d1, d2, d0 + 1.0, d1 + 4.0,
                                                            d2 + 3.0);
                                            default ->
                                                    new Box(
                                                            d0, d1, d2, d0 + 1.0, d1 + 4.0,
                                                            d2 + 1.0);
                                        };
                                int lx = integer == 0 ? k : l;
                                WorldEspRenderer.enqueueBox(box, lx, false);
                            }
                        });
                WorldEspRenderer.flush(render3DEvent.getMatrixStack());
            }
        }
    }

    private boolean isNorthSouthHole(WorldChunk worldchunk, BlockPos blockpos) {
        return this.isPassable(worldchunk, blockpos)
                && this.isPassable(worldchunk, blockpos.south(1))
                && this.isPassable(worldchunk, blockpos.south(2))
                && !this.isPassable(worldchunk, blockpos.east())
                && !this.isPassable(worldchunk, blockpos.west())
                && !this.isPassable(worldchunk, blockpos.south(3))
                && !this.isPassable(worldchunk, blockpos.north())
                && !this.isPassable(worldchunk, blockpos.south(1).east())
                && !this.isPassable(worldchunk, blockpos.south(1).west())
                && !this.isPassable(worldchunk, blockpos.south(2).east())
                && !this.isPassable(worldchunk, blockpos.south(2).west());
    }

    private void scanChunk(WorldChunk worldchunk) {
        if (worldchunk != null && !worldchunk.isEmpty()) {
            int startX = worldchunk.getPos().getStartX();
            int startZ = worldchunk.getPos().getStartZ();
            int bottomY = worldchunk.getBottomY();
            int l = bottomY + worldchunk.getHeight();
            Mutable mutable = new Mutable();

            for (int startXValue = startX; startXValue < startX + 16; startXValue++) {
                for (int startZValue = startZ; startZValue < startZ + 16; startZValue++) {
                    for (int bottomYValue = bottomY; bottomYValue < l; bottomYValue++) {
                        mutable.set(startXValue, bottomYValue, startZValue);
                        if (this.isPassable(worldchunk, mutable)) {
                            if (this.isSingleHole(worldchunk, mutable)) {
                                Mutable mutableValue =
                                        new Mutable(startXValue, bottomYValue, startZValue);

                                while (this.isSingleHole(worldchunk, mutableValue)) {
                                    mutableValue.move(Direction.UP);
                                }

                                if (mutableValue.getY() - bottomYValue >= 4) {
                                    this.holes.putIfAbsent(
                                            new BlockPos(startXValue, bottomYValue, startZValue),
                                            0);
                                }
                            }

                            if (this.isEastWestHole(worldchunk, mutable)) {
                                Mutable mutable4 =
                                        new Mutable(startXValue, bottomYValue, startZValue);

                                while (this.isEastWestHole(worldchunk, mutable4)) {
                                    mutable4.move(Direction.UP);
                                }

                                if (mutable4.getY() - bottomYValue >= 4) {
                                    this.holes.putIfAbsent(
                                            new BlockPos(startXValue, bottomYValue, startZValue),
                                            1);
                                }
                            }

                            if (this.isNorthSouthHole(worldchunk, mutable)) {
                                Mutable mutable5 =
                                        new Mutable(startXValue, bottomYValue, startZValue);

                                while (this.isNorthSouthHole(worldchunk, mutable5)) {
                                    mutable5.move(Direction.UP);
                                }

                                if (mutable5.getY() - bottomYValue >= 4) {
                                    this.holes.putIfAbsent(
                                            new BlockPos(startXValue, bottomYValue, startZValue),
                                            2);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    protected void onDisable() {
        if (this.scanExecutor != null) {
            this.scanExecutor.shutdownNow();

            try {
                this.scanExecutor.awaitTermination(1L, TimeUnit.SECONDS);
            } catch (InterruptedException interruptedexception) {
            }

            this.scanExecutor = null;
        }

        this.holes.clear();
    }

    private boolean isPassable(BlockPos blockpos) {
        if (client.world == null) {
            return false;
        } else {
            BlockState blockstate = client.world.getBlockState(blockpos);
            VoxelShape voxelshape = blockstate.getCollisionShape(client.world, blockpos);
            return voxelshape.isEmpty() || !VoxelShapes.fullCube().equals(voxelshape);
        }
    }

    @Override
    protected void onEnable() {
        this.holes.clear();
        this.cleanupTicks = 0;
        this.scanExecutor =
                Executors.newSingleThreadExecutor(
                        runnable -> {
                            Thread thread = new Thread(runnable, "Goobaa-HolesESP-Scanner");
                            thread.setDaemon(true);
                            return thread;
                        });
        if (client.world != null && client.player != null) {
            int value = client.options.getViewDistance().getValue();
            ChunkPos chunkpos = client.player.getChunkPos();

            for (int j = chunkpos.x - value; j <= chunkpos.x + value; j++) {
                for (int k = chunkpos.z - value; k <= chunkpos.z + value; k++) {
                    if (client.world.isChunkLoaded(j, k)) {
                        WorldChunk worldchunk = client.world.getChunk(j, k);
                        if (worldchunk != null) {
                            this.queueChunkScan(worldchunk);
                        }
                    }
                }
            }
        }
    }

    private boolean isPassable(WorldChunk worldchunk, BlockPos blockpos) {
        BlockState blockstate = this.getBlockState(worldchunk, blockpos);
        VoxelShape voxelshape =
                blockstate.getCollisionShape(
                        (BlockView) (client.world != null ? client.world : worldchunk.getWorld()),
                        blockpos);
        return voxelshape.isEmpty() || !VoxelShapes.fullCube().equals(voxelshape);
    }

    private static boolean isOutsideViewDistance(BlockPos blockpos, ChunkPos chunkpos, int i) {
        return Math.abs((blockpos.getX() >> 4) - chunkpos.x) > i
                || Math.abs((blockpos.getZ() >> 4) - chunkpos.z) > i;
    }
}
