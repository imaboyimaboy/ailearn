package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name = "Freecam", desc = "test", category = ModuleCategory.PLAYER)
@Environment(EnvType.CLIENT)
public class ExperimentalFreecamModule extends Module {}
