package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.stream.Collectors;

@Environment(EnvType.CLIENT)
public final class ModuleManager extends LinkedHashMap<Class<? extends Module>, Module> {

    @EventHandler
    public void onKeyPress(KeyPressEvent keyPressEvent) {
        this.values().stream()
                .filter(module -> module.getKey() == keyPressEvent.getKey())
                .forEach(Module::toggle);
    }

    private static boolean matchesName(String text, Module module) {
        return module.getName().equalsIgnoreCase(text);
    }

    private static boolean matchesName2(String text, Module module) {
        return module.getName().equalsIgnoreCase(text);
    }

    private static Module identity(Module module) {
        return module;
    }

    private void unregister(Module module) {
        this.remove(module.getClass());
    }

    public <T extends Module> T findModule(Class<T> oclass) {
        return this.values().stream()
                .filter(module -> oclass.isAssignableFrom(module.getClass()))
                .map(oclass::cast)
                .findFirst()
                .orElse(null);
    }

    public void register(Module[] modules) {
        Arrays.stream(modules)
                .forEach(module -> this.put((Class<? extends Module>) module.getClass(), module));
    }

    public void initialize() {
        this.register(
                new Module[] {
                    new AttackAuraModule(),
                    new AnchorMacroModule(),
                    new SafeAnchorModule(),
                    new DoubleAnchorModule(),
                    new AutoCrystalModule(),
                    new OptimizedCrystalsModule(),
                    new FakeLagModule(),
                    new AutoTotemModule(),
                    new AutoInvTotemModule(),
                    new NoFriendDamageModule(),
                    new HitboxesModule(),
                    new FakeTiersModule(),
                    new MaceExploitModule(),
                    new MaceSwapModule(),
                    new SpearSwapModule(),
                    new ShieldBreakerModule(),
                    new AutoSellModule(),
                    new AutoSellAxeModule(),
                    new AutoSpawnerSellModule(),
                    new AutoTpahereModule(),
                    new BetterTridentModule(),
                    new BlockEntityDebugModule(),
                    new ChunkFinderModule(),
                    new ChunkFinderV2Module(),
                    new FakeScoreboardModule(),
                    new HomeMacroModule(),
                    new SpawnerBreakerModule(),
                    new SpawnerDropperModule(),
                    new SpawnerProtectModule(),
                    new SusChunkFinderModule(),
                    new TriggerBotModule(),
                    new SprintModule(),
                    new AirStuckModule(),
                    new ClickGUIModule(),
                    new FriendsModule(),
                    new DiscordPresenceModule(),
                    new PlayerIndicatorModule(),
                    new PlayerESPModule(),
                    new NameTagsModule(),
                    new NoRenderModule(),
                    new SwingAnimationModule(),
                    new ShaderHandModule(),
                    new ShaderESPModule(),
                    new ShaderSkyModule(),
                    new WorldTweaksModule(),
                    new GammaModule(),
                    new ParticlesModule(),
                    new HealthAlertModule(),
                    new BlockESPModule(),
                    new StorageESPModule(),
                    new BlockOutlinesModule(),
                    new HolesESPModule(),
                    new LightDebugModule(),
                    new SpawnerNotifierModule(),
                    new SuspiciousESPModule(),
                    new SwingSpeedModule(),
                    new XRayModule(),
                    new SkinProtectModule(),
                    new CustomModelsModule(),
                    new RadarModule(),
                    new ChinaHatModule(),
                    new JumpCircleModule(),
                    new CrosshairModule(),
                    new TargetESPModule(),
                    new TrailsModule(),
                    new WorldCubesModule(),
                    new TrajectoriesModule(),
                    new GradientModule(),
                    new FirefliesModule(),
                    new FloatingCubesModule(),
                    new FogBlurModule(),
                    new TotemGhostModule(),
                    new HandsModule(),
                    new HUDModule(),
                    new SpotifyHUDModule(),
                    new NoDelayModule(),
                    new AutoToolModule(),
                    new AutoEatModule(),
                    new AutoFireworkModule(),
                    new AutoLogModule(),
                    new AutoMineModule(),
                    new AutoReconnectModule(),
                    new AutoTridentModule(),
                    new AutoWalkModule(),
                    new ChatMacroModule(),
                    new CoordSnapperModule(),
                    new CustomFOVModule(),
                    new FastPlaceModule(),
                    new FloatingHandsModule(),
                    new NoInvLeakModule(),
                    new ElytraFlyModule(),
                    new FreecamModule(),
                    new WeatherNotifierModule(),
                    new FreeLookModule(),
                    new NameProtectModule(),
                    new FakePlayerModule(),
                    new ItemScrollerModule()
                });
        this.values().stream()
                .filter(Module::isAutoEnabled)
                .forEach(module -> module.setEnabled(true, false));
        Gooba.getEventBus().subscribe(this);
    }

    @Override
    public Collection<Module> values() {
        return super.values().stream()
                .sorted(Comparator.comparing(Module::getName, String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toList());
    }

    private static boolean isInCategory(ModuleCategory moduleCategory2, Module module) {
        return module.getCategory() == moduleCategory2;
    }
}
