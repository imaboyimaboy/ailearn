package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

@ModuleInfo(
        name = "Elytra Fly",
        category = ModuleCategory.OTHER,
        desc = "Gives you more control over your elytra.")
@Environment(EnvType.CLIENT)
public class ElytraFlyModule extends Module {
    public final BooleanSetting noUnloadedChunksSetting;
    public final SliderSetting pitch40RotateDownSetting;
    private boolean disconnectScheduled;
    public final SliderSetting pitch40UpperSetting;
    private boolean descending;
    public final SliderSetting pitch40RotateUpSetting;
    public final BooleanSetting elytraBreakNotiSetting;
    private float flightPitch;
    public final BooleanSetting stopInWaterSetting =
            new BooleanSetting(this, "Stop In Water", false);
    public final SliderSetting pitch40LowerSetting;

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null && client.player.isGliding()) {
            if (this.elytraBreakNotiSetting.isOn()) {
                ItemStack itemstack = client.player.getEquippedStack(EquipmentSlot.CHEST);
                if (itemstack.isOf(Items.ELYTRA)) {
                    int i = itemstack.getMaxDamage() - itemstack.getDamage();
                    if (i <= 5) {
                        this.disconnectForDurability("Elytra durability critical!");
                        return;
                    }
                }
            }

            if (this.stopInWaterSetting.isOn() && client.player.isTouchingWater()) {
                this.setEnabled(false);
            } else {
                this.updateFlightPitch();
                if (this.noUnloadedChunksSetting.isOn()) {
                    this.stopBeforeUnloadedChunk();
                }
            }
        }
    }

    private void stopBeforeUnloadedChunk() {
        Vec3d vec3d = client.player.getVelocity();
        int i = (int) Math.floor((client.player.getX() + vec3d.x * 2.0) / 16.0);
        int j = (int) Math.floor((client.player.getZ() + vec3d.z * 2.0) / 16.0);
        if (!client.world.isChunkLoaded(i, j)) {
            client.player.setVelocity(0.0, vec3d.y, 0.0);
        }
    }

    @Override
    protected void onDisable() {
        this.disconnectScheduled = false;
        if (client.options != null) {
            client.options.jumpKey.setPressed(false);
        }
    }

    public ElytraFlyModule() {
        this.noUnloadedChunksSetting = new BooleanSetting(this, "No Unloaded Chunks", true);
        this.elytraBreakNotiSetting = new BooleanSetting(this, "Elytra Break Noti", true);
        this.pitch40LowerSetting =
                new SliderSetting(this, "Pitch40 Lower", 330.0F, -64.0F, 1000.0F, 0.001F);
        this.pitch40UpperSetting =
                new SliderSetting(this, "Pitch40 Upper", 370.0F, -64.0F, 1000.0F, 0.001F);
        this.pitch40RotateUpSetting =
                new SliderSetting(this, "Pitch40 Rotate Up", 5.45F, 0.001F, 20.0F, 0.001F);
        this.pitch40RotateDownSetting =
                new SliderSetting(this, "Pitch40 Rotate Down", 0.9F, 0.001F, 20.0F, 0.001F);
        this.descending = true;
        this.flightPitch = 37.72F;
    }

    @Override
    protected void onEnable() {
        if (client.player != null && client.player.getY() <= 370.0) {
            client.player.sendMessage(
                    Text.literal("You need to activate Elytra Fly above Y=370."), false);
            this.setEnabled(false);
        } else {
            this.flightPitch = 37.72F;
            this.descending = true;
            this.disconnectScheduled = false;
        }
    }

    private void updateFlightPitch() {
        double d0 = client.player.getY();
        if (this.descending && d0 <= (double) this.pitch40LowerSetting.getFloat().floatValue()) {
            this.descending = false;
        } else if (!this.descending
                && d0 >= (double) this.pitch40UpperSetting.getFloat().floatValue()) {
            this.descending = true;
        }

        if (!this.descending) {
            float f =
                    (float)
                            ((double) this.pitch40RotateUpSetting.getFloat().floatValue()
                                    + 1.0 * (Math.random() - 0.5));
            this.flightPitch -= f;
            if (this.flightPitch < -54.77F) {
                this.flightPitch = -54.77F;
                this.descending = true;
            }
        } else if (this.flightPitch < 37.72F) {
            float f1 =
                    (float)
                            ((double) this.pitch40RotateDownSetting.getFloat().floatValue()
                                    + 0.5 * (Math.random() - 0.5));
            this.flightPitch += f1;
            if (this.flightPitch > 37.72F) {
                this.flightPitch = 37.72F;
            }
        }

        client.player.setPitch(this.flightPitch);
    }

    private void disconnectForDurability(String text) {
        if (!this.disconnectScheduled) {
            this.disconnectScheduled = true;
            client.execute(
                    () -> {
                        if (client.getNetworkHandler() != null) {
                            client.getNetworkHandler()
                                    .getConnection()
                                    .disconnect(Text.literal(text));
                        }

                        this.setEnabled(false);
                    });
        }
    }
}
