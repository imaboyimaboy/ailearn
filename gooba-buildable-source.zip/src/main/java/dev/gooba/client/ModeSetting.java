package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.List;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class ModeSetting extends Setting<String> {

    public TimedAnimation timedAnimation = new DecelerateAnimation(300, 1.0);
    private String selectedMode;
    public TimedAnimation timedAnimation2 = new DecelerateAnimation(300, 1.0);
    public TimedAnimation timedAnimation3 = new DecelerateAnimation(300, 1.0);
    public List<String> modes;

    public boolean isSelected(String text) {
        return this.getSelectedMode().equalsIgnoreCase(text) && this.getVisibility().get();
    }

    public ModeSetting visibleWhen(Supplier supplier) {
        return (ModeSetting) super.visibleWhen(supplier);
    }

    public ModeSetting setValue(String stringValue) {
        this.selectedMode = stringValue;
        return (ModeSetting) super.setValue(stringValue);
    }

    public ModeSetting onChange(Runnable runnable) {
        return (ModeSetting)
                super.onChange(
                        () -> {
                            runnable.run();
                            this.selectedMode = (String) super.getValue();
                        });
    }

    public String getSelectedMode() {
        if (this.selectedMode == null) {
            this.selectedMode = (String) super.getValue();
        }

        return this.selectedMode;
    }

    public ModeSetting(Module moduleValue, String nameValue, String[] astring) {
        super(moduleValue, nameValue, astring[0]);
        this.modes = List.of(astring);
        this.setValue(astring[0]);
        this.selectedMode = astring[0];
    }
}
