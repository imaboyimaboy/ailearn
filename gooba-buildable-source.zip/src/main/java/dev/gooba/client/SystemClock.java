package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class SystemClock {
    public long startedAtMillis = System.currentTimeMillis();

    public SystemClock() {
        this.reset();
    }

    public void reset() {
        this.startedAtMillis = System.currentTimeMillis();
    }
}
