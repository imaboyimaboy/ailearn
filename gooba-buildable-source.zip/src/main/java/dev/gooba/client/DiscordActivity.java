package dev.gooba.client;

import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

@FieldOrder({
    "applicationId",
    "name",
    "secondLine",
    "type",
    "state",
    "details",
    "timestamps",
    "assets",
    "party",
    "secrets",
    "instance",
    "buttons"
})
@Environment(EnvType.CLIENT)
public class DiscordActivity extends Structure {
    public DiscordButtons buttons;
    public byte[] secondLine;
    public long applicationId;
    public int type;
    public boolean instance;

    public DiscordAssets assets;
    public byte[] details;
    public DiscordParty party;
    public byte[] state;
    public byte[] name = new byte[128];
    public DiscordSecrets secrets;
    public DiscordTimestamps timestamps;

    public DiscordActivity() {
        this.secondLine = new byte[128];
        this.state = new byte[128];
        this.details = new byte[128];
        this.timestamps = new DiscordTimestamps();
        this.assets = new DiscordAssets();
        this.party = new DiscordParty();
        this.secrets = new DiscordSecrets();
        this.buttons = new DiscordButtons();
    }

    public void setDetails(String text) {
        copyUtf8(this.details, text);
    }

    public static void copyUtf8(byte[] bArray, String text) {
        if (text == null) {
            text = "";
        }

        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        int var3 = Math.min(bytes.length, bArray.length - 1);
        Arrays.fill(bArray, (byte) 0);
        System.arraycopy(bytes, 0, bArray, 0, var3);
    }

    public void setName(String text) {
        copyUtf8(this.name, text);
    }

    public void setSecondLine(String text) {
        copyUtf8(this.secondLine, text);
    }

    public void setState(String text) {
        copyUtf8(this.state, text);
    }
}
