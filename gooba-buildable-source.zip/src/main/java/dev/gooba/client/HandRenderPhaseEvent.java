package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;

@Environment(EnvType.CLIENT)
public class HandRenderPhaseEvent extends CancellableEvent {
    private final HandRenderPhaseEvent.Phase phase;
    private final MatrixStack matrices;
    private final float tickDelta;

    public HandRenderPhaseEvent(
            HandRenderPhaseEvent.Phase phaseValue, MatrixStack matrixstack, float tickDeltaValue) {
        this.phase = phaseValue;
        this.matrices = matrixstack;
        this.tickDelta = tickDeltaValue;
    }

    public HandRenderPhaseEvent.Phase getPhase() {
        return this.phase;
    }

    public float getTickDelta() {
        return this.tickDelta;
    }

    public MatrixStack getMatrices() {
        return this.matrices;
    }

    @Environment(EnvType.CLIENT)
    public static enum Phase {
        PRE,
        POST;
    }
}
