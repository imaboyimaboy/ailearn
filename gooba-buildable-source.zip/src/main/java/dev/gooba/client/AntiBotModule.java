package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

@ModuleInfo(
        name = "Anti Bot",
        desc = "Prevents combat modules from targeting detected bots",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class AntiBotModule extends Module {

    private final List<PlayerEntity> bots = new ArrayList<>();

    @Override
    public void onDisable() {
        super.onDisable();
        this.bots.clear();
    }

    private void updateBots() {
        if (client.player != null && client.world != null) {
            for (PlayerEntity playerentity : client.world.getPlayers()) {
                if (playerentity != null && playerentity != client.player) {
                    boolean flag = false;
                    boolean flag1 = false;
                    boolean flag2 = false;
                    boolean flag3;
                    flag3 = (playerentity.getOffHandStack().getItem() == Items.AIR);

                    boolean flag4;
                    flag4 =
                            !(playerentity.getEquippedStack(EquipmentSlot.FEET).getItem()
                                            != Items.LEATHER_BOOTS
                                    && playerentity.getEquippedStack(EquipmentSlot.FEET).getItem()
                                            != Items.IRON_BOOTS
                                    && playerentity.getEquippedStack(EquipmentSlot.LEGS).getItem()
                                            != Items.LEATHER_LEGGINGS
                                    && playerentity.getEquippedStack(EquipmentSlot.LEGS).getItem()
                                            != Items.IRON_LEGGINGS
                                    && playerentity.getEquippedStack(EquipmentSlot.CHEST).getItem()
                                            != Items.LEATHER_CHESTPLATE
                                    && playerentity.getEquippedStack(EquipmentSlot.CHEST).getItem()
                                            != Items.IRON_CHESTPLATE
                                    && playerentity.getEquippedStack(EquipmentSlot.HEAD).getItem()
                                            != Items.LEATHER_HELMET
                                    && playerentity.getEquippedStack(EquipmentSlot.HEAD).getItem()
                                            != Items.IRON_HELMET);

                    boolean flag5;
                    flag5 = (playerentity.getMainHandStack().getItem() != Items.AIR);

                    boolean flag6;
                    if (playerentity.getHungerManager().getFoodLevel() == 20) {
                        flag6 = true;
                        EquipmentSlot[] aequipmentslot =
                                new EquipmentSlot[] {
                                    EquipmentSlot.FEET,
                                    EquipmentSlot.LEGS,
                                    EquipmentSlot.CHEST,
                                    EquipmentSlot.HEAD
                                };
                        int length = aequipmentslot.length;

                    } else {
                        flag6 = false;
                    }

                    for (EquipmentSlot equipmentslot :
                            new EquipmentSlot[] {
                                EquipmentSlot.FEET,
                                EquipmentSlot.LEGS,
                                EquipmentSlot.CHEST,
                                EquipmentSlot.HEAD
                            }) {
                        ItemStack itemstack = playerentity.getEquippedStack(equipmentslot);
                        if (!flag && itemstack.getItem() != Items.AIR) {
                            flag = true;
                        }

                        if (!flag1 && itemstack.isEnchantable()) {
                            flag1 = true;
                        }

                        if (!flag2 && !itemstack.isDamaged()) {
                            flag2 = true;
                        }
                    }

                    if (!flag || !flag1 || !flag2 || !flag3 || !flag4 || !flag5 || !flag6) {
                        this.bots.remove(playerentity);
                    } else if (!this.bots.contains(playerentity)) {
                        this.bots.add(playerentity);
                    }
                }
            }
        }
    }

    public static AntiBotModule getInstance() {
        return (AntiBotModule) ModuleLookup.getModule(AntiBotModule.class);
    }

    public boolean isBot(LivingEntity livingentity) {
        if (livingentity instanceof PlayerEntity playerentity && this.bots.contains(playerentity)) {
            return true;
        }

        return false;
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        this.updateBots();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.bots.clear();
    }
}
