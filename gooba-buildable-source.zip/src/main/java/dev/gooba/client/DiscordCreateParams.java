package dev.gooba.client;

import com.sun.jna.Callback;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FieldOrder({
    "version",
    "clientId",
    "events",
    "event_data",
    "event_size",
    "log_hook",
    "log_hook_data",
    "log_level"
})
@Environment(EnvType.CLIENT)
public class DiscordCreateParams extends Structure {
    public int event_size;
    public long clientId;
    public Pointer event_data;
    public Pointer log_hook_data;
    public long version;
    public Callback log_hook;
    public int log_level;
    public Pointer events;
}
