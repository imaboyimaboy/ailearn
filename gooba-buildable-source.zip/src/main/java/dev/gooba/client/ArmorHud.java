package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import org.joml.Matrix3x2fStack;

import java.awt.Color;

@Environment(EnvType.CLIENT)
public class ArmorHud implements MinecraftAccess {
    private static final EquipmentSlot[] ARMOR_ORDER =
            new EquipmentSlot[] {
                EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD
            };
    private final EasingAnimation visibilityAnimation = createAnimation(0.0F);

    private static EasingAnimation createAnimation(float f) {
        return new EasingAnimation()
                .setCurrentValue((double) f)
                .setStartValue((double) f)
                .setTargetValue((double) f)
                .setDurationMillis(1.0);
    }

    public void render(
            PositionSetting positionSetting2, HUDModule hUDModule, Render2DEvent render2DEvent) {
        if (client.player != null) {
            boolean flag = false;

            for (EquipmentSlot equipmentslot : ARMOR_ORDER) {
                if (!client.player.getEquippedStack(equipmentslot).isEmpty()) {
                    flag = true;
                    break;
                }
            }

            boolean flag1;
            flag1 =
                    !(!flag
                            && !hUDModule.alwaysShowSetting.isOn()
                            && !(client.currentScreen instanceof ChatScreen));

            this.visibilityAnimation.animateTo(flag1 ? 1.0 : 0.0, 0.2F, Easings.OUT_EXPO, true);
            this.visibilityAnimation.update();
            float floatValue = this.visibilityAnimation.getFloatValue();
            float f6 = hUDModule.hudSizeSetting.getFloat();
            float width = 20.0F * (float) ARMOR_ORDER.length * f6;
            float f = 20.0F * f6;
            float innerX = positionSetting2.position.x;
            float f2 = positionSetting2.position.y;
            if (!flag1 && !(floatValue > 0.01F)) {
                positionSetting2.visible = false;
            } else {
                positionSetting2.visible = true;
            }

            positionSetting2.size.set(width, f);
            if (!(floatValue <= 0.01F)) {
                hUDModule.drawBackground(
                        innerX, f2 - 3.0F * f6, width, f + 3.0F * f6, 4.0F * f6, floatValue);

                for (int i = 0; i < ARMOR_ORDER.length; i++) {
                    ItemStack itemstack = client.player.getEquippedStack(ARMOR_ORDER[i]);
                    if (!itemstack.isEmpty()) {
                        float f3 = innerX + ((float) i * 20.0F + 2.0F) * f6;
                        float f4 = f2 + 2.0F * f6;
                        Matrix3x2fStack matrix3x2fstack =
                                render2DEvent.getDrawContext().getMatrices();
                        matrix3x2fstack.pushMatrix();
                        matrix3x2fstack.translate(f3, f4);
                        matrix3x2fstack.scale(f6, f6);
                        render2DEvent.getDrawContext().drawItem(itemstack, 0, 0);
                        matrix3x2fstack.popMatrix();
                        drawDurability(itemstack, f3, f4, f6, floatValue);
                    }
                }
            }
        }
    }

    private static void drawDurability(
            ItemStack itemstack, float f, float f1, float f2, float opacity) {
        if (itemstack.isDamageable() && itemstack.getMaxDamage() > 0) {
            float f4 =
                    Math.max(
                            0.0F,
                            Math.min(
                                    1.0F,
                                    (float) (itemstack.getMaxDamage() - itemstack.getDamage())
                                            / (float) itemstack.getMaxDamage()));
            int j = Math.round(f4 * 100.0F);
            String string = j + "%";
            float size = 5.0F * f2;
            float f6 = f + 8.0F * f2;
            float f7 = Fonts.INTER_SEMIBOLD.centerTextY(string, f1 - 3.5F * f2, 5.0F * f2, size);
            int color = Color.HSBtoRGB(f4 / 3.0F, 0.9F, 1.0F);
            Fonts.INTER_SEMIBOLD.drawCenteredText(
                    string, f6, f7, size, ColorUtils.withOpacity(color, opacity));
        }
    }
}
