package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public class TargetRingRenderer extends ClientComponent {
    private float effectTime;
    private long lastFrameMillis;
    private static final RenderPipeline OUTLINE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "ring_esp_line"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.DEBUG_LINES)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    private static final RenderLayer OUTLINE_LAYER =
            RenderLayer.of(
                    "ring_esp_line",
                    RenderSetup.builder(TargetRingRenderer.OUTLINE_PIPELINE)
                            .expectedBufferSize(16384)
                            .build());
    public static int ticksSinceAim;
    public static TargetRingRenderer.RotationTask rotationTask =
            TargetRingRenderer.RotationTask.IDLE;
    private final BufferAllocator bufferAllocator = new BufferAllocator(262144);
    private final TargetRingRenderer.JitterPreset[] jitterPresets;
    public static float resetYawSpeed;
    public static final Function<Identifier, RenderLayer> texturedLayer =
            Util.memoize(
                    identifier -> {
                        RenderSetup rendersetup =
                                RenderSetup.builder(TargetRingRenderer.TEXTURED_PIPELINE)
                                        .texture("Sampler0", identifier)
                                        .translucent()
                                        .expectedBufferSize(1536)
                                        .build();
                        return RenderLayer.of("wtex", rendersetup);
                    });
    public EasingAnimation visibilityAnimation;
    public static int holdTicks;
    public static Rotation rotation;
    public static int rotationPriority;
    public static final RenderPipeline TEXTURED_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation("pipeline/wtex")
                            .withVertexShader("core/position_tex_color")
                            .withFragmentShader("core/position_tex_color")
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withCull(false)
                            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
                            .build());
    public static float resetPitchSpeed;
    private static final RenderPipeline FILL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "ring_esp_fill"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    public static float aimPitchSpeed;

    private static final RenderLayer FILL_LAYER =
            RenderLayer.of(
                    "ring_esp_fill",
                    RenderSetup.builder(FILL_PIPELINE).expectedBufferSize(65536).build());
    public EasingAnimation hitAnimation;
    private long jitterIntervalMillis;

    public static float aimYawSpeed;
    private long speedIntervalMillis;
    private long nextJitterUpdateMillis;
    float reservedRotationOffset;
    private long nextSpeedUpdateMillis;

    public LivingEntity effectTarget;
    private final TargetRingRenderer.SpeedPreset[] speedPresets;

    public static void aim(
            Rotation rotationValue,
            float aimYawSpeedValue,
            float resetYawSpeedValue,
            int holdTicksValue) {
        aim(
                rotationValue,
                aimYawSpeedValue,
                aimYawSpeedValue,
                resetYawSpeedValue,
                resetYawSpeedValue,
                holdTicksValue,
                90,
                false);
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.bufferAllocator.clear();
    }

    public void resetRotation() {
        rotationTask = TargetRingRenderer.RotationTask.IDLE;
        rotationPriority = 0;
        RotationStateManager.setCameraOverride(false);
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (rotationTask.equals(TargetRingRenderer.RotationTask.AIM) && ticksSinceAim > holdTicks) {
            rotationTask = TargetRingRenderer.RotationTask.RESET;
        }

        if (rotationTask.equals(TargetRingRenderer.RotationTask.RESET)) {
            this.returnToCamera();
        }

        ticksSinceAim++;
    }

    private static void drawCubeOutline(
            VertexConsumer vertexconsumer, Matrix4f matrix4f, float f, int i) {
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
    }

    private static void drawCubeFaces(
            VertexConsumer vertexconsumer, Matrix4f matrix4f, float f, int i) {
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
    }

    @EventHandler(priority = -250)
    public void onRender3D(Render3DEvent render3DEvent) {
        int i2 = 15728880;
        AttackAuraModule attackAuraModule = AttackAuraModule.getInstance();
        this.visibilityAnimation.update();
        LivingEntity livingentity = AttackAuraModule.target;
        if (livingentity != null) {
            this.effectTarget = livingentity;
        }

        if (client.world != null && client.player != null) {
            this.visibilityAnimation.animateTo(
                    livingentity != null ? 1.0 : 0.0, 0.2F, Easings.OUT_SINE);
            float floatValue = this.visibilityAnimation.getFloatValue();
            Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);
            if (floatValue > 0.001F
                    && this.effectTarget != null
                    && attackAuraModule.targetEffectSetting.isSelected("Image")) {
                int hurtTime = this.effectTarget.hurtTime;
                float f1 = (float) Math.sin((double) hurtTime * (Math.PI / 20));
                this.hitAnimation.update();
                this.hitAnimation.animateTo((double) f1, 0.12F, Easings.OUT_SINE);
                int endColor = ColorUtils.cachedRgba(185, 80, 80, (int) (255.0F * floatValue));
                int color7 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(0), floatValue),
                                endColor,
                                this.hitAnimation.getFloatValue());
                int colorValueValue =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(90), floatValue),
                                endColor,
                                this.hitAnimation.getFloatValue());
                int i1 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(180), floatValue),
                                endColor,
                                this.hitAnimation.getFloatValue());
                int j1 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(360), floatValue),
                                endColor,
                                this.hitAnimation.getFloatValue());
                MatrixStack matrixstack = render3DEvent.getMatrixStack();
                VertexConsumer vertexconsumer =
                        immediate.getBuffer(
                                texturedLayer.apply(
                                        Identifier.of("client", "textures/visuals/union.png")));
                Vec3d vec3d = this.effectTarget.getLerpedPos(render3DEvent.getTickDelta());
                double d0 = vec3d.x;
                double d2 = vec3d.y;
                double d4 = vec3d.z;
                Vec3d vec3d1 = client.gameRenderer.getCamera().getCameraPos();
                matrixstack.push();
                matrixstack.translate(
                        d0 - vec3d1.x,
                        d2 - vec3d1.y + (double) (this.effectTarget.getHeight() / 1.75F),
                        d4 - vec3d1.z);
                matrixstack.multiply(
                        RotationAxis.POSITIVE_Y.rotationDegrees(
                                -client.gameRenderer.getCamera().getYaw()));
                matrixstack.multiply(
                        RotationAxis.POSITIVE_X.rotationDegrees(
                                client.gameRenderer.getCamera().getPitch()));
                long nowMillis = System.currentTimeMillis();
                float f2 =
                        (float)
                                MathUtils.clampBetween(
                                        0.0,
                                        720.0,
                                        (Math.sin((double) nowMillis / 1000.0) + 1.0)
                                                / 2.0
                                                * 360.0
                                                * 2.0);
                matrixstack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(f2));
                Matrix4f matrix4f1 = matrixstack.peek().getPositionMatrix();
                float f3 = 0.7F;
                float f4 = 0.3F * f3;
                float floatValueValue = this.hitAnimation.getFloatValue();
                long nowMillisValue = System.currentTimeMillis();

                float f8 = 0.1F;
                float f9 = 0.2F - 0.2F * floatValue;
                this.drawRotatedSprite(
                        matrixstack,
                        vertexconsumer,
                        f4 + f8 * floatValueValue + f9,
                        f4 + f8 * floatValueValue + f9,
                        135.0F,
                        f3,
                        color7,
                        colorValueValue,
                        i1,
                        j1,
                        floatValue);
                this.drawRotatedSprite(
                        matrixstack,
                        vertexconsumer,
                        -f4 - f8 * floatValueValue - f9,
                        f4 + f8 * floatValueValue + f9,
                        -135.0F,
                        f3,
                        color7,
                        colorValueValue,
                        i1,
                        j1,
                        floatValue);
                this.drawRotatedSprite(
                        matrixstack,
                        vertexconsumer,
                        -f4 - f8 * floatValueValue - f9,
                        -f4 - f8 * floatValueValue - f9,
                        -45.0F,
                        f3,
                        color7,
                        colorValueValue,
                        i1,
                        j1,
                        floatValue);
                this.drawRotatedSprite(
                        matrixstack,
                        vertexconsumer,
                        f4 + f8 * floatValueValue + f9,
                        -f4 - f8 * floatValueValue - f9,
                        45.0F,
                        f3,
                        color7,
                        colorValueValue,
                        i1,
                        j1,
                        floatValue);
                matrixstack.pop();
            }

            if (floatValue > 0.001F
                    && this.effectTarget != null
                    && attackAuraModule.targetEffectSetting.isSelected("Ring")) {
                int hurtTimeValue = this.effectTarget.hurtTime;
                float progress = (float) Math.sin((double) hurtTimeValue * (Math.PI / 10));
                int endColorValue =
                        ColorUtils.cachedRgba(255, 100, 100, (int) (255.0F * floatValue));
                double d6 = 1200.0;
                double d7 = (double) System.currentTimeMillis() % d6;
                boolean flag = d7 > d6 / 2.0;
                double d9 = d7 / (d6 / 2.0);
                d9 = flag ? d9 - 1.0 : 1.0 - d9;
                double d11 = d9 < 0.5 ? 2.0 * d9 * d9 : 1.0 - Math.pow(-2.0 * d9 + 2.0, 2.0) / 2.0;
                float height = this.effectTarget.getHeight();
                double d3 =
                        (double) height
                                / 1.7
                                * (d11 > 0.5 ? 1.0 - d11 : d11)
                                * (double) (flag ? -1 : 1)
                                / 0.7;
                MatrixStack matrixStack = render3DEvent.getMatrixStack();
                Vec3d vec3d6 = this.effectTarget.getLerpedPos(render3DEvent.getTickDelta());
                Vec3d vec3d7 = client.gameRenderer.getCamera().getCameraPos();
                matrixStack.push();
                matrixStack.translate(
                        vec3d6.x - vec3d7.x, vec3d6.y - vec3d7.y, vec3d6.z - vec3d7.z);
                Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
                float f22 = this.effectTarget.getWidth() - 0.1F + 0.35F - 0.35F * floatValue;
                float f26 = (float) ((double) height * d11);
                float f30 = (float) ((double) height * d11 + d3);
                VertexConsumer buffer = immediate.getBuffer(FILL_LAYER);

                for (int phase = 0; phase < 360; phase++) {
                    float f34 = (float) Math.toRadians((double) phase);
                    float f6 = (float) Math.toRadians((double) (phase + 1));
                    int color =
                            ColorUtils.interpolate(
                                    ColorUtils.scaleAlpha(
                                            ColorUtils.animatedAccent(phase), floatValue),
                                    endColorValue,
                                    progress);
                    int colorValue =
                            ColorUtils.interpolate(
                                    ColorUtils.scaleAlpha(
                                            ColorUtils.animatedAccent(phase), floatValue),
                                    endColorValue,
                                    progress);
                    float f40 = (float) (Math.cos((double) f34) * (double) f22);
                    float f10 = (float) (Math.sin((double) f34) * (double) f22);
                    float f11 = (float) (Math.cos((double) f6) * (double) f22);
                    float f12 = (float) (Math.sin((double) f6) * (double) f22);
                    buffer.vertex(matrix4f, f40, f26, f10)
                            .color(ColorUtils.withAlpha(color, (int) (120.0F * floatValue)));
                    buffer.vertex(matrix4f, f11, f26, f12)
                            .color(ColorUtils.withAlpha(colorValue, (int) (120.0F * floatValue)));
                    buffer.vertex(matrix4f, f11, f30, f12)
                            .color(ColorUtils.withAlpha(colorValue, 0));
                    buffer.vertex(matrix4f, f40, f30, f10).color(ColorUtils.withAlpha(color, 0));
                }

                VertexConsumer bufferValue = immediate.getBuffer(OUTLINE_LAYER);

                for (int j6 = 0; j6 < 360; j6++) {
                    float f35 = (float) Math.toRadians((double) j6);
                    float f37 = (float) Math.toRadians((double) (j6 + 1));
                    int color8 =
                            ColorUtils.scaleAlpha(
                                    ColorUtils.interpolate(
                                            ColorUtils.brighten(ColorUtils.animatedAccent(1), 0.7F),
                                            endColorValue,
                                            progress),
                                    floatValue);
                    bufferValue
                            .vertex(
                                    matrix4f,
                                    (float) (Math.cos((double) f35) * (double) f22),
                                    f26,
                                    (float) (Math.sin((double) f35) * (double) f22))
                            .color(ColorUtils.withAlpha(color8, (int) (150.0F * floatValue)));
                    bufferValue
                            .vertex(
                                    matrix4f,
                                    (float) (Math.cos((double) f37) * (double) f22),
                                    f26,
                                    (float) (Math.sin((double) f37) * (double) f22))
                            .color(ColorUtils.withAlpha(color8, (int) (150.0F * floatValue)));
                }

                matrixStack.pop();
            }

            if (floatValue > 0.001F
                    && this.effectTarget != null
                    && attackAuraModule.targetEffectSetting.isSelected("Spirits")) {
                long nowMillis2 = System.currentTimeMillis();
                if (this.lastFrameMillis == 0L) {
                    this.lastFrameMillis = nowMillis2;
                }

                long j3 = nowMillis2 - this.lastFrameMillis;
                if (j3 > 0L) {
                    this.effectTime += (float) (5L * j3) / 700.0F;
                }

                this.lastFrameMillis = nowMillis2;
                MatrixStack matrixStackValue = render3DEvent.getMatrixStack();
                Vec3d vec3d2 = this.effectTarget.getLerpedPos(render3DEvent.getTickDelta());
                Vec3d vec3d4 = client.gameRenderer.getCamera().getCameraPos();
                double d8 = vec3d2.x - vec3d4.x;
                double d10 = vec3d2.y - vec3d4.y;
                double d1 = vec3d2.z - vec3d4.z;
                floatValue = (float) this.visibilityAnimation.getValue();
                this.hitAnimation.update();
                int hurtTime2 = this.effectTarget.hurtTime;
                float f18 = (float) Math.sin((double) hurtTime2 * (Math.PI / 20));
                this.hitAnimation.animateTo((double) f18, 0.1F, Easings.OUT_SINE);
                float floatValue2 = this.hitAnimation.getFloatValue();
                int color9 = ColorUtils.animatedAccent(1);
                int endColor2 = ColorUtils.cachedRgba(200, 70, 70, (int) (255.0F * floatValue));
                int color10 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(color9, floatValue), endColor2, floatValue2);
                byte b6 = 3;
                byte b7 = 12;
                int l5 = 3 * b6;
                matrixStackValue.push();
                Camera cameraValue = client.gameRenderer.getCamera();

                for (byte b8 = 0; b8 < l5; b8 += b6) {
                    for (int k6 = 0; k6 < b7; k6++) {
                        float f36 = this.effectTime + (float) k6 * 0.1F;
                        float f38 = 0.6F;
                        float f39 = 0.4F;
                        int k7 = (int) Math.pow((double) b8, 2.0);
                        matrixStackValue.push();
                        double d21 = d8 + (double) f38 * Math.sin((double) (f36 + (float) k7));
                        double d22 =
                                d10
                                        + (double) f39
                                        + 0.3F
                                                * Math.sin(
                                                        (double)
                                                                (this.effectTime
                                                                        + (float) k6 * 0.2F))
                                        + (double) (0.2F * (float) b8);
                        double d5 = d1 + (double) f38 * Math.cos((double) (f36 - (float) k7));
                        matrixStackValue.translate(d21, d22, d5);
                        float f13 = (0.005F + (float) k6 / 2000.0F) * floatValue;
                        matrixStackValue.scale(f13, f13, f13);
                        matrixStackValue.multiply(
                                RotationAxis.POSITIVE_Y.rotationDegrees(-cameraValue.getYaw()));
                        matrixStackValue.multiply(
                                RotationAxis.POSITIVE_X.rotationDegrees(cameraValue.getPitch()));
                        Matrix4f matrix4f2 = matrixStackValue.peek().getPositionMatrix();
                        VertexConsumer buffer2 =
                                immediate.getBuffer(
                                        texturedLayer.apply(
                                                Identifier.of(
                                                        "client",
                                                        "textures/visuals/particles_3.png")));
                        byte b0 = -20;
                        byte b1 = 35;
                        buffer2.vertex(matrix4f2, (float) b0, (float) (b0 + b1), 0.0F)
                                .color(color10)
                                .texture(0.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(i2)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer2.vertex(matrix4f2, (float) (b0 + b1), (float) (b0 + b1), 0.0F)
                                .color(color10)
                                .texture(1.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(i2)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer2.vertex(matrix4f2, (float) (b0 + b1), (float) b0, 0.0F)
                                .color(color10)
                                .texture(1.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(i2)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer2.vertex(matrix4f2, (float) b0, (float) b0, 0.0F)
                                .color(color10)
                                .texture(0.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(i2)
                                .normal(0.0F, 0.0F, 1.0F);
                        b0 = -50;
                        b1 = 95;
                        buffer2.vertex(matrix4f2, (float) b0, (float) (b0 + b1), 0.0F)
                                .color(ColorUtils.withOpacity(color10, floatValue * 0.1F))
                                .texture(0.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(i2)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer2.vertex(matrix4f2, (float) (b0 + b1), (float) (b0 + b1), 0.0F)
                                .color(ColorUtils.withOpacity(color10, floatValue * 0.1F))
                                .texture(1.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(i2)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer2.vertex(matrix4f2, (float) (b0 + b1), (float) b0, 0.0F)
                                .color(ColorUtils.withOpacity(color10, floatValue * 0.1F))
                                .texture(1.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(i2)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer2.vertex(matrix4f2, (float) b0, (float) b0, 0.0F)
                                .color(ColorUtils.withOpacity(color10, floatValue * 0.1F))
                                .texture(0.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(i2)
                                .normal(0.0F, 0.0F, 1.0F);
                        matrixStackValue.pop();
                    }
                }

                matrixStackValue.pop();
            }

            if (floatValue > 0.001F
                    && this.effectTarget != null
                    && attackAuraModule.targetEffectSetting.isSelected("Cubes")) {
                int hurtTime3 = this.effectTarget.hurtTime;
                float f15 = (float) Math.sin((double) hurtTime3 * (Math.PI / 10));
                this.hitAnimation.update();
                this.hitAnimation.animateTo((double) f15, 0.1F, Easings.OUT_SINE);
                int endColor3 = ColorUtils.cachedRgba(255, 100, 100, (int) (255.0F * floatValue));
                int color11 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(1), floatValue),
                                endColor3,
                                this.hitAnimation.getFloatValue());
                MatrixStack matrixStack2 = render3DEvent.getMatrixStack();
                Vec3d vec3d3 = client.gameRenderer.getCamera().getCameraPos();
                Vec3d vec3d5 = this.effectTarget.getLerpedPos(render3DEvent.getTickDelta());
                long i4 = 40L;
                long nowMillis3 = System.currentTimeMillis();
                if (this.lastFrameMillis == 0L) {
                    this.lastFrameMillis = nowMillis3;
                }

                long k4 = nowMillis3 - this.lastFrameMillis;
                if (k4 > 0L) {
                    this.effectTime += (float) (5L * k4) / (float) i4;
                }

                this.lastFrameMillis = nowMillis3;
                float f17 = this.effectTime - 12.0F * this.hitAnimation.getFloatValue();
                byte b2 = 12;
                float f20 = this.effectTarget.getWidth() * 1.5F;
                float f21 = (1.0F - 0.3F * this.hitAnimation.getFloatValue()) * floatValue;
                Camera camera = client.gameRenderer.getCamera();

                for (byte b3 = 0; b3 < 360; b3 += b2) {
                    float f23 = 0.70000005F;
                    float f27 =
                            (float)
                                    (Math.sin(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b3
                                                                                            + f17))))
                                            * (double) f20
                                            * (double) f23);
                    float f31 =
                            (float)
                                    (Math.cos(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b3
                                                                                            + f17))))
                                            * (double) f20
                                            * (double) f23);
                    double d12 = vec3d5.x + (double) f27;
                    double d15 = vec3d5.z + (double) f31;
                    double d18 =
                            vec3d5.y
                                    + (double) this.effectTarget.getHeight()
                                            * Math.abs(MathUtils.fastSin((double) b3));
                    matrixStack2.push();
                    matrixStack2.translate(d12 - vec3d3.x, d18 - vec3d3.y, d15 - vec3d3.z);
                    matrixStack2.multiply(camera.getRotation());
                    float f41 = 0.6F * f21;
                    matrixStack2.scale(f41, f41, f41);
                    drawGradientQuad(
                            immediate.getBuffer(
                                    texturedLayer.apply(
                                            Identifier.of(
                                                    "client", "textures/visuals/particles_1.png"))),
                            matrixStack2.peek().getPositionMatrix(),
                            ColorUtils.scaleAlpha(color11, 0.3F),
                            ColorUtils.scaleAlpha(color11, 0.3F),
                            ColorUtils.scaleAlpha(color11, 0.3F),
                            ColorUtils.scaleAlpha(color11, 0.3F),
                            (int) (floatValue * 0.35F * 255.0F));
                    matrixStack2.pop();
                }

                for (byte b4 = 0; b4 < 360; b4 += b2) {
                    float f24 = 0.70000005F;
                    float f28 =
                            (float)
                                    (Math.sin(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b4
                                                                                            + f17))))
                                            * (double) f20
                                            * (double) f24);
                    float f32 =
                            (float)
                                    (Math.cos(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b4
                                                                                            + f17))))
                                            * (double) f20
                                            * (double) f24);
                    double d13 = vec3d5.x + (double) f28;
                    double d16 = vec3d5.z + (double) f32;
                    double d19 =
                            vec3d5.y
                                    + (double) this.effectTarget.getHeight()
                                            * Math.abs(MathUtils.fastSin((double) b4));
                    Vec3d vec3d8 = new Vec3d(d13, d19, d16);
                    Vector3f vector3f =
                            new Vector3f(
                                            (float) (vec3d5.x - vec3d8.x),
                                            (float) (vec3d5.y - vec3d8.y),
                                            (float) (vec3d5.z - vec3d8.z))
                                    .normalize();
                    matrixStack2.push();
                    matrixStack2.translate(d13 - vec3d3.x, d19 - vec3d3.y, d16 - vec3d3.z);
                    matrixStack2.multiply(
                            new Quaternionf().rotationTo(new Vector3f(0.0F, 1.0F, 0.0F), vector3f));
                    Matrix4f matrix4f3 = matrixStack2.peek().getPositionMatrix();
                    float f42 = 0.06F * f21;
                    drawCubeFaces(
                            immediate.getBuffer(FILL_LAYER),
                            matrix4f3,
                            f42,
                            ColorUtils.withAlpha(color11, (int) (floatValue * 0.2F * 255.0F)));
                    matrixStack2.pop();
                }

                for (byte b5 = 0; b5 < 360; b5 += b2) {
                    float f25 = 0.70000005F;
                    float f29 =
                            (float)
                                    (Math.sin(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b5
                                                                                            + f17))))
                                            * (double) f20
                                            * (double) f25);
                    float f33 =
                            (float)
                                    (Math.cos(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b5
                                                                                            + f17))))
                                            * (double) f20
                                            * (double) f25);
                    double d14 = vec3d5.x + (double) f29;
                    double d17 = vec3d5.z + (double) f33;
                    double d20 =
                            vec3d5.y
                                    + (double) this.effectTarget.getHeight()
                                            * Math.abs(MathUtils.fastSin((double) b5));
                    Vec3d vec3d9 = new Vec3d(d14, d20, d17);
                    Vector3f vector3f1 =
                            new Vector3f(
                                            (float) (vec3d5.x - vec3d9.x),
                                            (float) (vec3d5.y - vec3d9.y),
                                            (float) (vec3d5.z - vec3d9.z))
                                    .normalize();
                    matrixStack2.push();
                    matrixStack2.translate(d14 - vec3d3.x, d20 - vec3d3.y, d17 - vec3d3.z);
                    matrixStack2.multiply(
                            new Quaternionf()
                                    .rotationTo(new Vector3f(0.0F, 1.0F, 0.0F), vector3f1));
                    Matrix4f matrix4f4 = matrixStack2.peek().getPositionMatrix();
                    float f43 = 0.06F * f21;
                    drawCubeOutline(
                            immediate.getBuffer(OUTLINE_LAYER),
                            matrix4f4,
                            f43,
                            ColorUtils.withAlpha(color11, (int) (floatValue * 255.0F)));
                    matrixStack2.pop();
                }
            }

            if (attackAuraModule.targetEffectSetting.isSelected("Cube")) {
                attackAuraModule.drawFragments(render3DEvent, immediate);
                if (floatValue > 0.001F && this.effectTarget != null) {
                    attackAuraModule.drawTargetCube(
                            render3DEvent, this.effectTarget, floatValue, immediate);
                }
            }

            immediate.draw();
        }
    }

    static boolean stepRotation(Rotation rotation3, float f, float f1) {
        if (client.player == null) {
            return false;
        } else {
            Rotation rotationValue = new Rotation(client.player);
            float f2 = rotation3.pitch - rotationValue.pitch;
            float f3 = MathHelper.wrapDegrees(rotation3.yaw - rotationValue.yaw);
            float f4 = Math.min(Math.abs(f3), f);
            float f5 = Math.min(Math.abs(f2), f1);
            client.player.setYaw(
                    client.player.headYaw =
                            client.player.headYaw
                                    + MouseSensitivity.quantizeRotation(
                                            MathHelper.clamp(f3, -f4, f4)));
            client.player.setPitch(
                    MathHelper.clamp(
                            client.player.getPitch()
                                    + MouseSensitivity.quantizeRotation(
                                            MathHelper.clamp(f2, -f5, f5)),
                            -90.0F,
                            90.0F));
            ticksSinceAim = 0;
            return new Rotation(client.player).angularDistanceTo(rotation3) < 1.0F;
        }
    }

    private void drawRotatedSprite(
            MatrixStack matrixstack,
            VertexConsumer vertexconsumer,
            float f,
            float f1,
            float f2,
            float f3,
            int color,
            int colorValue,
            int k,
            int l,
            float f4) {
        matrixstack.push();
        matrixstack.translate(f, f1, 0.0F);
        matrixstack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(f2));
        matrixstack.scale(f3 * 0.6F, f3 * 0.6F, 1.0F);
        Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
        drawGradientQuad(vertexconsumer, matrix4f, color, colorValue, k, l, (int) (255.0F * f4));
        matrixstack.pop();
    }

    private void returnToCamera() {
        Rotation rotationValue = new Rotation(RotationStateManager.yaw, RotationStateManager.pitch);
        if (stepRotation(rotationValue, resetYawSpeed, resetPitchSpeed)) {
            this.resetRotation();
        }
    }

    public TargetRingRenderer() {
        this.effectTime = 0.0F;
        this.lastFrameMillis = 0L;
        this.effectTarget = null;
        this.visibilityAnimation = new EasingAnimation();
        this.hitAnimation = new EasingAnimation();
        this.jitterPresets =
                new TargetRingRenderer.JitterPreset[] {
                    new TargetRingRenderer.JitterPreset() {

                        static {
                        }

                        @Override
                        public float yawOffset(long i) {
                            return (float)
                                    ((Math.cos((double) i / 95.0)
                                                    + Math.sin((double) i / 42.0) * 0.4)
                                            * 11.0);
                        }

                        @Override
                        public float pitchOffset(long i) {
                            return (float)
                                    ((Math.sin((double) i / 80.0)
                                                    + Math.cos((double) i / 35.0) * 0.35)
                                            * 13.0);
                        }
                    },
                    new TargetRingRenderer.JitterPreset() {
                        @Override
                        public float yawOffset(long i) {
                            return (float)
                                    (Math.cos((double) i / 65.0 + Math.cos((double) i / 280.0))
                                            * 14.0);
                        }

                        @Override
                        public float pitchOffset(long i) {
                            return (float)
                                    (Math.sin((double) i / 55.0 + Math.sin((double) i / 350.0))
                                            * 15.0);
                        }
                    },
                    new TargetRingRenderer.JitterPreset() {
                        @Override
                        public float yawOffset(long i) {
                            return (float)
                                    ((Math.sin((double) i / 58.0) * 0.5
                                                    + Math.cos((double) i / 140.0))
                                            * 12.0);
                        }

                        @Override
                        public float pitchOffset(long i) {
                            return (float)
                                    ((Math.cos((double) i / 42.0) * 0.7
                                                    + Math.sin((double) i / 120.0))
                                            * 17.0);
                        }
                    },
                    new TargetRingRenderer.JitterPreset() {
                        @Override
                        public float pitchOffset(long i) {
                            return (float)
                                    (Math.sin((double) i / 25.0)
                                            * (9.0 + Math.sin((double) i / 300.0) * 4.0));
                        }

                        @Override
                        public float yawOffset(long i) {
                            return (float)
                                    (Math.cos((double) i / 48.0)
                                            * (13.0 + Math.cos((double) i / 250.0) * 3.0));
                        }
                    },
                    new TargetRingRenderer.JitterPreset() {
                        @Override
                        public float yawOffset(long i) {
                            return (float)
                                    ((Math.cos((double) i / 90.0)
                                                    + Math.cos((double) i / 23.0) * 0.2)
                                            * 13.0);
                        }

                        @Override
                        public float pitchOffset(long i) {
                            return (float)
                                    ((Math.sin((double) i / 70.0)
                                                    + Math.sin((double) i / 17.0) * 0.25)
                                            * 16.0);
                        }
                    },
                    new TargetRingRenderer.JitterPreset() {
                        @Override
                        public float pitchOffset(long i) {
                            return (float)
                                    ((Math.cos((double) i / 110.0) * 0.8
                                                    + Math.sin((double) i / 38.0) * 0.6)
                                            * 12.0);
                        }

                        @Override
                        public float yawOffset(long i) {
                            return (float)
                                    ((Math.sin((double) i / 100.0) * 0.7
                                                    + Math.cos((double) i / 29.0) * 0.4)
                                            * 15.0);
                        }
                    },
                    new TargetRingRenderer.JitterPreset() {
                        @Override
                        public float yawOffset(long i) {
                            return (float)
                                    ((Math.cos((double) i / 52.0) + Math.sin((double) i / 240.0))
                                            * 10.0);
                        }

                        @Override
                        public float pitchOffset(long i) {
                            return (float) (Math.sin((double) i / 170.0 + 1.2) * 21.0);
                        }
                    },
                    new TargetRingRenderer.JitterPreset() {
                        @Override
                        public float pitchOffset(long i) {
                            return (float)
                                    ((Math.cos((double) i / 36.0) * 0.45
                                                    + Math.sin((double) i / 145.0))
                                            * 18.0);
                        }

                        @Override
                        public float yawOffset(long i) {
                            return (float)
                                    ((Math.sin((double) i / 44.0) * 0.35
                                                    + Math.cos((double) i / 180.0))
                                            * 14.0);
                        }
                    },
                    new TargetRingRenderer.JitterPreset() {
                        @Override
                        public float pitchOffset(long i) {
                            return (float)
                                    (Math.sin((double) i / 60.0 + Math.cos((double) i / 180.0))
                                            * 14.0);
                        }

                        @Override
                        public float yawOffset(long i) {
                            return (float)
                                    (Math.cos((double) i / 73.0 + Math.sin((double) i / 210.0))
                                            * 17.0);
                        }
                    },
                    new TargetRingRenderer.JitterPreset() {
                        @Override
                        public float yawOffset(long i) {
                            return (float)
                                    ((Math.cos((double) i / 84.0) * 0.8
                                                    + Math.sin((double) i / 32.0) * 0.3)
                                            * 12.0);
                        }

                        @Override
                        public float pitchOffset(long i) {
                            return (float)
                                    ((Math.sin((double) i / 48.0) * 0.9
                                                    + Math.cos((double) i / 140.0) * 0.5)
                                            * 15.0);
                        }
                    }
                };
        this.speedPresets =
                new TargetRingRenderer.SpeedPreset[] {
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 40.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 12.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float pitchSpeed() {
                            return 15.0F;
                        }

                        @Override
                        public float yawSpeed() {
                            return 55.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 30.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 10.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 48.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 18.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float pitchSpeed() {
                            return 14.0F;
                        }

                        @Override
                        public float yawSpeed() {
                            return 60.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float pitchSpeed() {
                            return 16.0F;
                        }

                        @Override
                        public float yawSpeed() {
                            return 35.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float pitchSpeed() {
                            return 13.0F;
                        }

                        @Override
                        public float yawSpeed() {
                            return 50.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 44.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 17.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 58.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 11.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 32.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 19.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 46.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 12.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 53.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 15.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float pitchSpeed() {
                            return 18.0F;
                        }

                        @Override
                        public float yawSpeed() {
                            return 37.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float pitchSpeed() {
                            return 13.0F;
                        }

                        @Override
                        public float yawSpeed() {
                            return 42.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float pitchSpeed() {
                            return 16.0F;
                        }

                        @Override
                        public float yawSpeed() {
                            return 57.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 34.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 11.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float pitchSpeed() {
                            return 20.0F;
                        }

                        @Override
                        public float yawSpeed() {
                            return 49.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float pitchSpeed() {
                            return 14.0F;
                        }

                        @Override
                        public float yawSpeed() {
                            return 62.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 39.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 17.0F;
                        }
                    },
                    new TargetRingRenderer.SpeedPreset() {
                        @Override
                        public float yawSpeed() {
                            return 52.0F;
                        }

                        @Override
                        public float pitchSpeed() {
                            return 12.0F;
                        }
                    }
                };

        this.reservedRotationOffset = 0.0F;
        this.jitterIntervalMillis = ThreadLocalRandom.current().nextLong(1000L, 2001L);
        this.nextJitterUpdateMillis = System.currentTimeMillis() + this.jitterIntervalMillis;

        this.speedIntervalMillis = ThreadLocalRandom.current().nextLong(2000L, 4001L);
        this.nextSpeedUpdateMillis = System.currentTimeMillis() + this.speedIntervalMillis;
    }

    @EventHandler
    public void onMovementInput(MovementInputEvent movementInputEvent) {
        if (rotationTask.equals(TargetRingRenderer.RotationTask.RESET)) {
            MovementUtils.correctMovementInput(
                    movementInputEvent,
                    client.player.getYaw(),
                    client.gameRenderer.getCamera().getYaw());
        }
    }

    public static void aim(
            Rotation rotationValue,
            float aimYawSpeedValue,
            float aimPitchSpeedValue,
            float resetYawSpeedValue,
            float resetPitchSpeedValue,
            int holdTicksValue,
            int rotationPriorityValue,
            boolean flag) {
        if (rotationPriority <= rotationPriorityValue) {
            if (rotationTask.equals(TargetRingRenderer.RotationTask.IDLE) && !flag) {
                RotationStateManager.cameraOverride = true;
            }

            aimYawSpeed = aimYawSpeedValue;
            aimPitchSpeed = aimPitchSpeedValue;
            resetYawSpeed = resetYawSpeedValue;
            resetPitchSpeed = resetPitchSpeedValue;
            holdTicks = holdTicksValue;
            rotationPriority = rotationPriorityValue;
            rotationTask = TargetRingRenderer.RotationTask.AIM;
            TargetRingRenderer.rotation = rotationValue;
            stepRotation(rotationValue, aimYawSpeedValue, aimPitchSpeedValue);
        }
    }

    private static void drawGradientQuad(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            int color,
            int colorValue,
            int color4,
            int color5,
            int alpha) {
        vertexconsumer
                .vertex(matrix4f, -0.5F, -0.5F, 0.0F)
                .color(ColorUtils.withAlpha(color, alpha))
                .texture(0.0F, 1.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(0.0F, 0.0F, 1.0F);
        vertexconsumer
                .vertex(matrix4f, 0.5F, -0.5F, 0.0F)
                .color(ColorUtils.withAlpha(colorValue, alpha))
                .texture(1.0F, 1.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(0.0F, 0.0F, 1.0F);
        vertexconsumer
                .vertex(matrix4f, 0.5F, 0.5F, 0.0F)
                .color(ColorUtils.withAlpha(color4, alpha))
                .texture(1.0F, 0.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(0.0F, 0.0F, 1.0F);
        vertexconsumer
                .vertex(matrix4f, -0.5F, 0.5F, 0.0F)
                .color(ColorUtils.withAlpha(color5, alpha))
                .texture(0.0F, 0.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(0.0F, 0.0F, 1.0F);
    }

    @Environment(EnvType.CLIENT)
    private interface JitterPreset {
        float pitchOffset(long i);

        float yawOffset(long i);
    }

    @Environment(EnvType.CLIENT)
    public static enum RotationTask {
        AIM,
        RESET,
        IDLE;
    }

    @Environment(EnvType.CLIENT)
    private interface SpeedPreset {
        float yawSpeed();

        float pitchSpeed();
    }
}
