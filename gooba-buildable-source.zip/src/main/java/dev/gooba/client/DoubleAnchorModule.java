package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

import org.lwjgl.glfw.GLFW;

@ModuleInfo(
        name = "Double Anchor",
        desc = "Places, charges and explodes two anchors at the selected block",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class DoubleAnchorModule extends Module {
    private int activationTicks;
    private int stage;

    public final KeybindSetting activationKeySetting =
            new KeybindSetting(this, "Activation Key", 1);
    private int stageStartedTick;
    private int previousSlot = -1;
    private BlockPos anchorPosition;
    private static DoubleAnchorModule instance;
    private boolean activationConsumed;

    private BlockHitResult getPlacementHit() {
        BlockHitResult blockhitresult = this.findPlacementHit();
        return blockhitresult != null
                        && blockhitresult
                                .getBlockPos()
                                .offset(blockhitresult.getSide())
                                .equals(this.anchorPosition)
                ? blockhitresult
                : null;
    }

    private void advanceStage(int stageValue) {
        this.stage = stageValue;
        this.stageStartedTick = client.player.age;
    }

    private int findHotbarItem(Item item) {
        for (int i = 0; i < 9; i++) {
            if (client.player.getInventory().getStack(i).isOf(item)) {
                return i;
            }
        }

        return -1;
    }

    private boolean interactBlock(BlockHitResult blockhitresult) {
        ActionResult actionresult =
                client.interactionManager.interactBlock(
                        client.player, Hand.MAIN_HAND, blockhitresult);
        if (!actionresult.isAccepted()) {
            return false;
        } else {
            client.player.swingHand(Hand.MAIN_HAND);
            return true;
        }
    }

    @EventHandler
    public void onKeyPress(KeyPressEvent keyPressEvent) {
        int cachedKeyCode = this.activationKeySetting.getCachedKeyCode();
        if (client.currentScreen == null
                && cachedKeyCode > 7
                && keyPressEvent.getKey() == cachedKeyCode) {
            this.activationTicks = 4;
        }
    }

    public DoubleAnchorModule() {
        instance = this;
    }

    private BlockHitResult getAnchorHit() {
        BlockHitResult blockhitresult = this.raycastBlock();
        return blockhitresult != null && blockhitresult.getBlockPos().equals(this.anchorPosition)
                ? blockhitresult
                : null;
    }

    private boolean isActivationHeld() {
        int cachedKeyCode = this.activationKeySetting.getCachedKeyCode();
        if (cachedKeyCode < 0) {
            return false;
        } else {
            return cachedKeyCode <= 7
                    ? GLFW.glfwGetMouseButton(client.getWindow().getHandle(), cachedKeyCode) == 1
                    : InputUtil.isKeyPressed(client.getWindow(), cachedKeyCode);
        }
    }

    public static boolean shouldSuppressUse() {
        if (instance == null
                || !instance.isEnabled()
                || client.player == null
                || client.world == null
                || client.currentScreen != null
                || !instance.isActivationRequested()) {
            return false;
        } else {
            return instance.stage != 0 ? true : instance.findPlacementHit() != null;
        }
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled() && instance.stage != 0;
    }

    @EventHandler
    public void onMouseButton(MouseButtonEvent mouseButtonEvent) {
        int cachedKeyCode = this.activationKeySetting.getCachedKeyCode();
        if (mouseButtonEvent.getScreen() == null
                && cachedKeyCode >= 0
                && cachedKeyCode <= 7
                && mouseButtonEvent.getButton() == cachedKeyCode
                && mouseButtonEvent.getAction() == 1) {
            this.activationTicks = 4;
        }
    }

    @Override
    protected void onDisable() {
        this.reset(true);
        this.activationConsumed = false;
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.reset(false);
        this.activationConsumed = false;
    }

    private boolean isActivationRequested() {
        return this.activationTicks > 0 || this.isActivationHeld();
    }

    private void suppressUse() {
        MouseSimulator.suppressUse(75L);
        client.options.useKey.setPressed(false);
    }

    @EventHandler
    public void onPreClientTick(PreClientTickEvent preClientTickEvent) {
        if (client.player != null
                && client.world != null
                && client.interactionManager != null
                && client.currentScreen == null) {
            if (this.activationTicks > 0) {
                this.activationTicks--;
            }

            if (this.stage != 0 || !SafeAnchorModule.shouldSuppressUse()) {
                boolean isActivationRequested = this.isActivationRequested();
                if (!isActivationRequested) {
                    this.activationConsumed = false;
                }

                if (this.stage != 0 && AutoTotemModule.isSwapPending()) {
                    this.reset(true);
                } else {
                    if (this.stage == 0) {
                        if (!isActivationRequested
                                || this.activationConsumed
                                || AutoTotemModule.isSwapPending()
                                || MaceSwapModule.isActive()
                                || SpearSwapModule.isActive()
                                || ShieldBreakerModule.isActive()) {
                            return;
                        }

                        BlockHitResult blockhitresult = this.findPlacementHit();
                        if (blockhitresult == null) {
                            return;
                        }

                        if (this.findHotbarItem(Items.RESPAWN_ANCHOR) == -1
                                || this.findHotbarItem(Items.GLOWSTONE) == -1) {
                            return;
                        }

                        this.anchorPosition =
                                blockhitresult
                                        .getBlockPos()
                                        .offset(blockhitresult.getSide())
                                        .toImmutable();
                        this.previousSlot = client.player.getInventory().getSelectedSlot();
                        this.stage = 1;
                        this.stageStartedTick = client.player.age;
                        this.activationConsumed = true;
                        this.activationTicks = 0;
                    }

                    this.suppressUse();
                    if (client.player.age - this.stageStartedTick > 40) {
                        this.reset(true);
                    } else {
                        this.tickSequence();
                    }
                }
            }
        } else {
            this.reset(true);
        }
    }

    private BlockHitResult raycastBlock() {
        Vec3d vec3d = client.player.getEyePos();
        double blockInteractionRange = client.player.getBlockInteractionRange();
        float pitch = client.gameRenderer.getCamera().getPitch();
        float yaw = client.gameRenderer.getCamera().getYaw();
        Vec3d vec3d1 = EntityRaycast.rotationVector(pitch, yaw);
        BlockHitResult blockhitresult =
                client.world.raycast(
                        new RaycastContext(
                                vec3d,
                                vec3d.add(vec3d1.multiply(blockInteractionRange)),
                                ShapeType.OUTLINE,
                                FluidHandling.NONE,
                                client.player));
        return blockhitresult.getType() == Type.BLOCK && !blockhitresult.isInsideBlock()
                ? blockhitresult
                : null;
    }

    private void reset(boolean flag) {
        if (flag && client.player != null && this.previousSlot >= 0) {
            EnchantmentInventoryUtils.selectHotbarSlot(this.previousSlot);
        }

        this.anchorPosition = null;
        this.stage = 0;
        this.previousSlot = -1;
        this.stageStartedTick = 0;
        this.activationTicks = 0;
    }

    private boolean selectItem(Item item) {
        if (client.player.getMainHandStack().isOf(item)) {
            return true;
        } else {
            int i = this.findHotbarItem(item);
            if (i == -1) {
                return false;
            } else {
                EnchantmentInventoryUtils.selectHotbarSlot(i);
                return false;
            }
        }
    }

    private BlockHitResult findPlacementHit() {
        BlockHitResult blockhitresult = this.raycastBlock();
        if (blockhitresult == null) {
            return null;
        } else {
            BlockPos blockpos = blockhitresult.getBlockPos().offset(blockhitresult.getSide());
            return client.world.isInBuildLimit(blockpos)
                            && client.world.getWorldBorder().contains(blockpos)
                            && client.world.getBlockState(blockpos).isReplaceable()
                    ? blockhitresult
                    : null;
        }
    }

    private void tickSequence() {
        BlockHitResult blockhitresult;
        if (this.stage == 1) {
            blockhitresult = this.getPlacementHit();
        } else {
            blockhitresult = this.getAnchorHit();
        }

        if (blockhitresult == null) {
            boolean isActivationHeld = this.isActivationHeld();
            this.reset(true);
            this.activationConsumed = isActivationHeld;
        } else {
            BlockState blockstate = client.world.getBlockState(this.anchorPosition);
            if (this.stage == 1) {
                if (blockstate.isReplaceable() && this.selectItem(Items.RESPAWN_ANCHOR)) {
                    if (this.interactBlock(blockhitresult)) {
                        this.advanceStage(2);
                    }
                }
            } else if (this.stage == 2) {
                if (blockstate.isOf(Blocks.RESPAWN_ANCHOR)) {
                    if (blockstate.get(RespawnAnchorBlock.CHARGES) > 0) {
                        this.advanceStage(3);
                    } else if (this.selectItem(Items.GLOWSTONE)) {
                        if (this.interactBlock(blockhitresult)) {
                            this.advanceStage(3);
                        }
                    }
                }
            } else if (this.stage == 3) {
                if (this.isChargedAnchor(this.anchorPosition)
                        && this.selectItem(Items.RESPAWN_ANCHOR)) {
                    BlockHitResult blockHitResult =
                            new BlockHitResult(
                                    blockhitresult.getPos(),
                                    blockhitresult.getSide(),
                                    this.anchorPosition,
                                    false);
                    if (this.interactBlock(blockhitresult)) {
                        client.interactionManager.sendSequencedPacket(
                                client.world,
                                i ->
                                        new PlayerInteractBlockC2SPacket(
                                                Hand.MAIN_HAND, blockHitResult, i));
                        client.player.swingHand(Hand.MAIN_HAND);
                        this.advanceStage(4);
                    }
                }
            } else if (this.stage == 4) {
                if (blockstate.isOf(Blocks.RESPAWN_ANCHOR)) {
                    if (blockstate.get(RespawnAnchorBlock.CHARGES) > 0) {
                        this.advanceStage(5);
                    } else if (this.selectItem(Items.GLOWSTONE)) {
                        if (this.interactBlock(blockhitresult)) {
                            this.advanceStage(5);
                        }
                    }
                }
            } else {
                if (this.stage == 5) {
                    if (!this.isChargedAnchor(this.anchorPosition)
                            || !this.selectItem(Items.RESPAWN_ANCHOR)) {
                        return;
                    }

                    if (this.interactBlock(blockhitresult)) {
                        this.reset(true);
                    }
                }
            }
        }
    }

    private boolean isChargedAnchor(BlockPos blockpos) {
        BlockState blockstate = client.world.getBlockState(blockpos);
        return blockstate.isOf(Blocks.RESPAWN_ANCHOR)
                && blockstate.get(RespawnAnchorBlock.CHARGES) > 0;
    }
}
