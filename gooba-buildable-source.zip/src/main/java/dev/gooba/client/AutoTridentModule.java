package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;

import java.util.Optional;

@ModuleInfo(
        name = "Auto Trident",
        category = ModuleCategory.OTHER,
        desc = "Automatically charges and releases Riptide tridents.")
@Environment(EnvType.CLIENT)
public class AutoTridentModule extends Module {

    private boolean waitingToRecharge;
    private int previousSlot;
    public final SliderSetting minDurabilitySetting;
    private int releaseTicks;
    private boolean charging;
    public final BooleanSetting autoSwitchSetting;
    public final SliderSetting chargeTicksSetting =
            new SliderSetting(this, "Charge Ticks", 10.0F, 5.0F, 20.0F, 1.0F);

    public AutoTridentModule() {
        this.minDurabilitySetting =
                new SliderSetting(this, "Min Durability %", 20.0F, 0.0F, 50.0F, 1.0F);
        this.autoSwitchSetting = new BooleanSetting(this, "Auto Switch", true);
        this.previousSlot = -1;
    }

    private boolean selectRiptideTrident() {
        if (client.player == null) {
            return false;
        } else if (this.getRiptideLevel(client.player.getMainHandStack()) > 0) {
            return true;
        } else {
            if (this.previousSlot == -1) {
                this.previousSlot = client.player.getInventory().getSelectedSlot();
            }

            for (int i = 0; i < 9; i++) {
                ItemStack itemstack = client.player.getInventory().getStack(i);
                if (itemstack.isOf(Items.TRIDENT) && this.getRiptideLevel(itemstack) > 0) {
                    client.player.getInventory().setSelectedSlot(i);
                    return true;
                }
            }

            return false;
        }
    }

    @Override
    protected void onEnable() {
        this.charging = false;
        this.waitingToRecharge = false;
        this.previousSlot = -1;
        this.releaseTicks = 0;
        if (client.player != null && !this.selectRiptideTrident()) {
            client.player.sendMessage(
                    Text.literal("§c[AutoTrident] No riptide trident found!"), false);
            this.setEnabled(false);
        }
    }

    private int getRiptideLevel(ItemStack itemstack) {
        if (client.world != null
                && itemstack != null
                && !itemstack.isEmpty()
                && itemstack.isOf(Items.TRIDENT)) {
            try {
                Optional optional =
                        client.world.getRegistryManager().getOptional(RegistryKeys.ENCHANTMENT);
                if (optional.isPresent()) {
                    Optional entry =
                            ((Registry) optional.get()).getEntry(Enchantments.RIPTIDE.getValue());
                    if (entry.isPresent()) {
                        return EnchantmentHelper.getLevel(
                                (RegistryEntry<Enchantment>) entry.get(), itemstack);
                    }
                }

                return 0;
            } catch (Exception exception) {
                return 0;
            }
        } else {
            return 0;
        }
    }

    @Override
    protected void onDisable() {
        if (client.options != null) {
            client.options.useKey.setPressed(false);
        }

        if (this.previousSlot != -1 && client.player != null) {
            client.player.getInventory().setSelectedSlot(this.previousSlot);
            this.previousSlot = -1;
        }

        this.charging = false;
        this.waitingToRecharge = false;
        this.releaseTicks = 0;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null) {
            ItemStack itemstack = client.player.getMainHandStack();
            if (this.getRiptideLevel(itemstack) == 0) {
                if (!this.autoSwitchSetting.isOn() || !this.selectRiptideTrident()) {
                    client.player.sendMessage(
                            Text.literal("§c[AutoTrident] No riptide trident!"), false);
                    this.setEnabled(false);
                    return;
                }

                itemstack = client.player.getMainHandStack();
            }

            if (itemstack.isDamageable()) {
                double d0 =
                        (double) (itemstack.getMaxDamage() - itemstack.getDamage())
                                / (double) itemstack.getMaxDamage()
                                * 100.0;
                if (d0 <= (double) this.minDurabilitySetting.getFloat().floatValue()) {
                    client.player.sendMessage(
                            Text.literal("§c[AutoTrident] Durability too low!"), false);
                    this.setEnabled(false);
                    return;
                }
            }

            int maxUseTime = itemstack.getMaxUseTime(client.player);
            int itemUseTimeLeft = client.player.getItemUseTimeLeft();
            int j = maxUseTime - itemUseTimeLeft;
            int k = this.chargeTicksSetting.getFloat().intValue();
            if (this.waitingToRecharge) {
                if (++this.releaseTicks >= 1) {
                    this.waitingToRecharge = false;
                    this.charging = true;
                    client.options.useKey.setPressed(true);
                }
            } else if (this.charging) {
                if (client.player.isUsingItem() && j >= k) {
                    client.options.useKey.setPressed(false);
                    this.charging = false;
                    this.waitingToRecharge = true;
                    this.releaseTicks = 0;
                } else if (!client.player.isUsingItem()) {
                    client.options.useKey.setPressed(true);
                }
            } else {
                this.charging = true;
                client.options.useKey.setPressed(true);
            }
        }
    }
}
