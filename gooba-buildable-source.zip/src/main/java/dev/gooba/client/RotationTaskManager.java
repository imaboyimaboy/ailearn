package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.MathHelper;

import java.util.Random;

@Environment(EnvType.CLIENT)
public class RotationTaskManager extends ClientComponent {
    public static float resetPitchSpeed;
    public static int holdTicks;
    public static int ticksSinceAim;
    public static float resetYawSpeed;
    public static int rotationPriority;
    private static final Random random = new Random();
    public static RotationTaskManager.RotationTask rotationTask =
            RotationTaskManager.RotationTask.IDLE;
    public static float resetYawJitter;
    public static int jitterDurationTicks;
    private static int resetTicks;
    public static float resetPitchJitter;

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (rotationTask.equals(RotationTaskManager.RotationTask.AIM)
                && ticksSinceAim > holdTicks) {
            rotationTask = RotationTaskManager.RotationTask.RESET;
            resetTicks = 0;
        }

        if (rotationTask.equals(RotationTaskManager.RotationTask.RESET)) {
            resetTicks++;
            this.updateReset();
        }

        ticksSinceAim++;
    }

    private void updateReset() {
        Rotation rotation = new Rotation(RotationStateManager.yaw, RotationStateManager.pitch);
        float f = 0.0F;
        float f1 = 0.0F;
        if (jitterDurationTicks > 0 && resetTicks <= jitterDurationTicks) {
            float f2 = 1.0F - (float) resetTicks / (float) jitterDurationTicks;
            f = (random.nextFloat() * 2.0F - 1.0F) * resetYawJitter * f2;
            f1 = (random.nextFloat() * 2.0F - 1.0F) * resetPitchJitter * f2;
        }

        boolean flag = stepTowardTarget(rotation, resetYawSpeed, resetPitchSpeed, f, f1);
        if (flag && (jitterDurationTicks <= 0 || resetTicks > jitterDurationTicks)) {
            this.finishReset();
        }
    }

    public void finishReset() {
        rotationTask = RotationTaskManager.RotationTask.IDLE;
        rotationPriority = 0;
        RotationStateManager.setCameraOverride(false);
    }

    static boolean stepTowardTarget(Rotation rotationValue, float f, float f1, float f2, float f3) {
        if (client.player == null) {
            return false;
        } else {
            Rotation rotation = new Rotation(client.player);
            float f4 = MathHelper.wrapDegrees(rotationValue.yaw - rotation.yaw);
            float f5 = rotationValue.pitch - rotation.pitch;
            float f6 = Math.min(Math.abs(f4), f);
            float f7 = Math.min(Math.abs(f5), f1);
            float f8 = MouseSensitivity.quantizeRotation(MathHelper.clamp(f4, -f6, f6)) + f2;
            float f9 = MouseSensitivity.quantizeRotation(MathHelper.clamp(f5, -f7, f7)) + f3;
            client.player.setYaw(client.player.headYaw += f8);
            client.player.setPitch(MathHelper.clamp(client.player.getPitch() + f9, -90.0F, 90.0F));
            ticksSinceAim = 0;
            return new Rotation(client.player).angularDistanceTo(rotationValue) < 1.0F;
        }
    }

    @Environment(EnvType.CLIENT)
    public static class AdvancedRotationConfig {
        public AdvancedRotationConfig(Rotation rotation) {
            this.fVal4 = 180.0F;
            this.fVal2 = 180.0F;
            this.fVal6 = 0.0F;
            this.fVal7 = 0.0F;
            this.fVal3 = 0.0F;
            this.fVal = 0.0F;
            this.intVal3 = 0;
            this.intVal2 = 1;
            this.intVal = 0;
            this.flag = false;
            this.rotation = rotation;
        }

        public int intVal;
        public float fVal;
        public float fVal2;
        public float fVal3;
        public float fVal4;
        public float fVal5;
        public int intVal2;
        public int intVal3;
        public boolean flag;
        public float fVal6;
        public Rotation rotation;
        public float fVal7;
        public float fVal8;
    }

    @Environment(EnvType.CLIENT)
    public static enum RotationTask {
        AIM,
        RESET,
        IDLE;

        private static RotationTaskManager.RotationTask[] getRotationTaskArray() {
            return new RotationTaskManager.RotationTask[] {AIM, RESET, IDLE};
        }
    }
}
