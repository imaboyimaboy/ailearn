package dev.gooba.client;

import com.sun.jna.Library;
import com.sun.jna.Native;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

@Environment(EnvType.CLIENT)
public interface DiscordRpcLibrary extends Library {
    void Discord_Initialize(
            String applicationId,
            DiscordEventHandlers handlers,
            boolean autoRegister,
            String steamId);

    void Discord_UpdatePresence(DiscordRichPresence presence);

    void Discord_RunCallbacks();

    void Discord_ClearPresence();

    void Discord_Shutdown();

    void Discord_UpdateHandlers(DiscordEventHandlers handlers);

    void Discord_Register(String applicationId, String command);

    void Discord_RegisterSteamGame(String applicationId, String steamId);

    void Discord_Respond(String userId, int reply);

    final class Loader {
        private static final Logger LOGGER = LoggerFactory.getLogger("Goobaa/Discord");
        private static DiscordRpcLibrary library;

        private Loader() {}

        public static synchronized DiscordRpcLibrary getDiscordRpcLibrary() {
            if (library == null) {
                try {
                    var bundledLibrary =
                            Native.extractFromResourcePath(
                                    "/assets/gooba/natives/windows-x86_64/discord-rpc.dll",
                                    DiscordRpcLibrary.class.getClassLoader());
                    library =
                            Native.load(
                                    bundledLibrary.getAbsolutePath(),
                                    DiscordRpcLibrary.class,
                                    Map.of(Library.OPTION_STRING_ENCODING, "UTF-8"));
                } catch (UnsatisfiedLinkError | IOException failure) {
                    LOGGER.error("Unable to load the bundled Discord RPC library.", failure);
                }
            }
            return library;
        }
    }
}
