package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

@ModuleInfo(
        name = "Jump Circle",
        desc = "Displays an expanding animated circle whenever you jump",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class JumpCircleModule extends Module {
    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_TEX_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/world/textured_quads"))
                            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    public static final Function<Identifier, RenderLayer> textureLayer =
            Util.memoize(
                    identifier -> {
                        RenderSetup rendersetup =
                                RenderSetup.builder(PIPELINE)
                                        .texture("Sampler0", identifier)
                                        .translucent()
                                        .expectedBufferSize(1536)
                                        .build();
                        return RenderLayer.of("wtex", rendersetup);
                    });
    BufferAllocator bufferAllocator;
    private final List<JumpCircleModule.Circle> circles = new ArrayList<>();
    public SliderSetting sizeSetting = new SliderSetting(this, "Size", 1.0F, 0.2F, 3.0F, 0.1F);

    private void drawTexturedQuad(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            Matrix3f matrix3f,
            float f,
            float f1,
            float f2,
            float f3,
            int[] aint,
            int alpha) {
        Vector3f vector3f = new Vector3f(0.0F, 0.0F, 1.0F);
        matrix3f.transform(vector3f);
        vector3f.normalize();
        float f4 = f + f2;
        float f5 = f1 + f3;
        vertexconsumer
                .vertex(matrix4f, f, f1, 0.0F)
                .color(ColorUtils.withAlpha(aint[0], alpha))
                .texture(0.0F, 1.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(vector3f.x, vector3f.y, vector3f.z);
        vertexconsumer
                .vertex(matrix4f, f4, f1, 0.0F)
                .color(ColorUtils.withAlpha(aint[1], alpha))
                .texture(1.0F, 1.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(vector3f.x, vector3f.y, vector3f.z);
        vertexconsumer
                .vertex(matrix4f, f4, f5, 0.0F)
                .color(ColorUtils.withAlpha(aint[2], alpha))
                .texture(1.0F, 0.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(vector3f.x, vector3f.y, vector3f.z);
        vertexconsumer
                .vertex(matrix4f, f, f5, 0.0F)
                .color(ColorUtils.withAlpha(aint[3], alpha))
                .texture(0.0F, 0.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(vector3f.x, vector3f.y, vector3f.z);
    }

    private void drawGlow(Immediate immediate, MatrixStack matrixstack, float f, float f1) {
        VertexConsumer vertexconsumer =
                immediate.getBuffer(
                        textureLayer.apply(
                                Identifier.of("client", "textures/visuals/jump_new.png")));
        byte b0 = 20;
        float f2 = f * 0.15F;
        float f3 = f * 0.25F;
        Vector3f vector3f = new Vector3f(0.0F, 1.0F, 0.0F);
        matrixstack.peek().getNormalMatrix().transform(vector3f);
        vector3f.normalize();

        for (int i = 0; i < b0; i++) {
            float f4 = (float) i / (float) b0;
            float f5 = f2 * f4;
            float f6 = f1 * (1.0F - f4) * 0.15F;
            if (!(f6 <= 0.004F)) {
                float f7 = f + f3 * f4;
                float f8 = f7 / 2.0F;
                int j = (int) (f6 * 255.0F);
                Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
                int k = ColorUtils.animatedAccent(0);
                int l = ColorUtils.animatedAccent(90);
                int i1 = ColorUtils.animatedAccent(180);
                int j1 = ColorUtils.animatedAccent(270);
                vertexconsumer
                        .vertex(matrix4f, -f8, f5, -f8)
                        .color(k >> 16 & 0xFF, k >> 8 & 0xFF, k & 0xFF, j)
                        .texture(0.0F, 0.0F)
                        .overlay(OverlayTexture.DEFAULT_UV)
                        .light(15728880)
                        .normal(vector3f.x, vector3f.y, vector3f.z);
                vertexconsumer
                        .vertex(matrix4f, -f8, f5, f8)
                        .color(l >> 16 & 0xFF, l >> 8 & 0xFF, l & 0xFF, j)
                        .texture(0.0F, 1.0F)
                        .overlay(OverlayTexture.DEFAULT_UV)
                        .light(15728880)
                        .normal(vector3f.x, vector3f.y, vector3f.z);
                vertexconsumer
                        .vertex(matrix4f, f8, f5, f8)
                        .color(i1 >> 16 & 0xFF, i1 >> 8 & 0xFF, i1 & 0xFF, j)
                        .texture(1.0F, 1.0F)
                        .overlay(OverlayTexture.DEFAULT_UV)
                        .light(15728880)
                        .normal(vector3f.x, vector3f.y, vector3f.z);
                vertexconsumer
                        .vertex(matrix4f, f8, f5, -f8)
                        .color(j1 >> 16 & 0xFF, j1 >> 8 & 0xFF, j1 & 0xFF, j)
                        .texture(1.0F, 0.0F)
                        .overlay(OverlayTexture.DEFAULT_UV)
                        .light(15728880)
                        .normal(vector3f.x, vector3f.y, vector3f.z);
            }
        }
    }

    public JumpCircleModule() {
        this.bufferAllocator = new BufferAllocator(262144);
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (!this.circles.isEmpty()) {
            this.circles.removeIf(
                    circle -> System.currentTimeMillis() - circle.createdAtMillis > 1000L);
            if (!this.circles.isEmpty()) {
                Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);
                MatrixStack matrixstack = render3DEvent.getMatrixStack();
                ColorUtils.animatedAccent(1);
                short short1 = 255;

                for (JumpCircleModule.Circle circleValue : this.circles) {
                    float f =
                            MathHelper.clamp(
                                    (float)
                                                    (System.currentTimeMillis()
                                                            - circleValue.createdAtMillis)
                                            / 1000.0F,
                                    0.0F,
                                    1.0F);
                    float f1 = (float) Math.pow(Math.sin(Math.PI * (double) f), 2.0);
                    float f2 = f * f * (3.0F - 2.0F * f);
                    float f3 = 0.35F + f2 * 1.65F;
                    double d0 =
                            circleValue.position.x
                                    - client.gameRenderer.getCamera().getCameraPos().x;
                    double d1 =
                            circleValue.position.y
                                    - client.gameRenderer.getCamera().getCameraPos().y;
                    double d2 =
                            circleValue.position.z
                                    - client.gameRenderer.getCamera().getCameraPos().z;
                    float f4 = this.sizeSetting.getFloat() * f3;
                    matrixstack.push();
                    matrixstack.translate(d0, d1, d2);
                    matrixstack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0F));
                    Entry entry = matrixstack.peek();
                    Matrix4f matrix4f = entry.getPositionMatrix();
                    Matrix3f matrix3f = entry.getNormalMatrix();
                    VertexConsumer vertexconsumer =
                            immediate.getBuffer(
                                    textureLayer.apply(
                                            Identifier.of(
                                                    "client", "textures/visuals/jump_new.png")));
                    this.drawTexturedQuad(
                            vertexconsumer,
                            matrix4f,
                            matrix3f,
                            -f4 / 2.0F,
                            -f4 / 2.0F,
                            f4,
                            f4,
                            new int[] {
                                ColorUtils.animatedAccent(0),
                                ColorUtils.animatedAccent(90),
                                ColorUtils.animatedAccent(180),
                                ColorUtils.animatedAccent(360)
                            },
                            (int) ((float) short1 * f1));
                    matrixstack.pop();
                    matrixstack.push();
                    matrixstack.translate(d0, d1, d2);
                    this.drawGlow(immediate, matrixstack, f4, f1);
                    matrixstack.pop();
                }

                immediate.draw();
            }
        }
    }

    @EventHandler
    public void onPlayerJump(PlayerJumpEvent playerJumpEvent) {
        this.circles.add(
                new JumpCircleModule.Circle(client.player.getEntityPos().add(0.0, 0.05, 0.0)));
    }

    @Environment(EnvType.CLIENT)
    private class Circle {
        private final Vec3d position;
        private final long createdAtMillis;

        public Circle(Vec3d vec3d) {
            this.position = vec3d;
            this.createdAtMillis = System.currentTimeMillis();
        }
    }
}
