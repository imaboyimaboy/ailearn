package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class CooldownTimer {
    private long startedAtMillis;

    public void reset() {
        this.startedAtMillis = System.currentTimeMillis();
    }

    public boolean hasElapsed(double d0) {
        return (double) System.currentTimeMillis() - d0 >= (double) this.startedAtMillis;
    }

    public CooldownTimer() {
        this.reset();
    }
}
