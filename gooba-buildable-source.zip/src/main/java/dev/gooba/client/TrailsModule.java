package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Function;

@ModuleInfo(
        name = "Trails",
        desc = "Draws a customizable glowing trail behind the player while moving",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class TrailsModule extends Module {
    public final BooleanSetting segmentsSetting;
    private static final RenderLayer GLOW_LAYER;
    private double previousY;
    private static final RenderPipeline GLOW_PIPELINE;
    public final ModeSetting rotationSetting;
    private float visibility;
    public final ModeSetting colorSetting =
            new ModeSetting(this, "Color", new String[] {"Client", "Random"});
    private double previousZ;
    public final BooleanSetting glowSetting;
    private final Random random;
    private static final List<Identifier> staticTextures = new ArrayList<>();
    public final BooleanSetting smoothingSetting;
    private static final Function<Identifier, RenderLayer> textureLayer;
    private boolean hasPreviousPosition;
    private final BufferAllocator bufferAllocator;
    private static final Identifier GLOW_TEXTURE =
            Identifier.of("client", "textures/particles/glow.png");
    private static final int[] ANIMATION_FRAME_COUNTS = new int[] {11, 23, 32, 16, 32};
    private final Vector3f cameraUp;
    private float glowOpacity;
    public final SliderSetting trailLengthSetting;
    private final Quaternionf cameraRotation;
    private static final List<List<Identifier>> animatedTextures = new ArrayList<>();
    private static final RenderPipeline TRAIL_PIPELINE;
    private final List<TrailsModule.DashCubic> trails;
    public final BooleanSetting dotsSetting;
    private final Vector3f cameraRight;
    public final SliderSetting positionSmoothingSetting;
    private final List<TrailsModule.DashCubic> renderTrails;
    private double previousX;

    private static void drawTexturedQuad(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            float f,
            float f1,
            float f2,
            float f3,
            int i) {
        int j = i >> 16 & 0xFF;
        int k = i >> 8 & 0xFF;
        int l = i & 0xFF;
        int i1 = i >> 24 & 0xFF;
        vertexconsumer.vertex(matrix4f, f, f1, 0.0F).color(j, k, l, i1).texture(0.0F, 1.0F);
        vertexconsumer.vertex(matrix4f, f2, f1, 0.0F).color(j, k, l, i1).texture(1.0F, 1.0F);
        vertexconsumer.vertex(matrix4f, f2, f3, 0.0F).color(j, k, l, i1).texture(1.0F, 0.0F);
        vertexconsumer.vertex(matrix4f, f, f3, 0.0F).color(j, k, l, i1).texture(0.0F, 0.0F);
    }

    private int trailColor() {
        return this.colorSetting.isSelected("Random")
                ? Color.getHSBColor((float) this.random.nextInt(255) / 255.0F, 1.0F, 1.0F).getRGB()
                        | 0xFF000000
                : ColorUtils.animatedAccent(0);
    }

    static {
        for (int i = 1; i <= 21; i++) {
            staticTextures.add(
                    Identifier.of("client", "textures/dash_cubes/dashcubic" + i + ".png"));
        }

        for (int k = 1; k <= ANIMATION_FRAME_COUNTS.length; k++) {
            ArrayList arraylist = new ArrayList();

            for (int j = 1; j <= ANIMATION_FRAME_COUNTS[k - 1]; j++) {
                arraylist.add(
                        Identifier.of(
                                "client",
                                "textures/dash_cubes/group_dashs/group"
                                        + k
                                        + "/dashcubic"
                                        + j
                                        + ".png"));
            }

            animatedTextures.add(arraylist);
        }

        TRAIL_PIPELINE =
                RenderPipelines.register(
                        RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                                .withLocation(Identifier.of("client", "pipeline/trails/spark"))
                                .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                                .withCull(false)
                                .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                                .withDepthWrite(false)
                                .withBlend(BlendFunction.LIGHTNING)
                                .build());
        GLOW_LAYER =
                RenderLayer.of(
                        "trails_spark",
                        RenderSetup.builder(TRAIL_PIPELINE).expectedBufferSize(16384).build());
        GLOW_PIPELINE =
                RenderPipelines.register(
                        RenderPipeline.builder(RenderPipelines.POSITION_TEX_COLOR_SNIPPET)
                                .withLocation(Identifier.of("client", "pipeline/trails/cubic"))
                                .withVertexFormat(
                                        VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
                                .withCull(false)
                                .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                                .withDepthWrite(false)
                                .withBlend(BlendFunction.LIGHTNING)
                                .build());
        textureLayer =
                Util.memoize(
                        identifierx ->
                                RenderLayer.of(
                                        "trails_cubic",
                                        RenderSetup.builder(GLOW_PIPELINE)
                                                .texture("Sampler0", identifierx)
                                                .translucent()
                                                .expectedBufferSize(1536)
                                                .build()));
    }

    public TrailsModule() {
        this.rotationSetting =
                new ModeSetting(this, "Rotation", new String[] {"Movement", "Camera"});
        this.trailLengthSetting = new SliderSetting(this, "Trail Length", 0.75F, 0.5F, 1.5F, 0.01F);
        this.positionSmoothingSetting =
                new SliderSetting(this, "Position Smoothing", 0.2F, 0.1F, 0.5F, 0.01F);
        this.smoothingSetting = new BooleanSetting(this, "Smoothing", false);
        this.segmentsSetting = new BooleanSetting(this, "Segments", false);
        this.dotsSetting = new BooleanSetting(this, "Dots", true);
        this.glowSetting = new BooleanSetting(this, "Glow", true);
        this.trails = new ArrayList<>();
        this.renderTrails = new ArrayList<>();
        this.random = new Random(1234567891L);
        this.bufferAllocator = new BufferAllocator(262144);
        this.cameraRight = new Vector3f();
        this.cameraUp = new Vector3f();
        this.cameraRotation = new Quaternionf();
        this.visibility = 0.0F;
        this.glowOpacity = 0.0F;
        this.hasPreviousPosition = false;
    }

    private static float movementYaw(double d0, double d1) {
        int i = (int) (Math.toDegrees(Math.atan2(d1, d0)) - 90.0);
        return i < 0 ? (float) (i + 360) : (float) i;
    }

    private void rotateTrail(MatrixStack matrixstack, float[] afloat, float f, float f1) {
        if (this.rotationSetting.isSelected("Movement")) {
            matrixstack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-afloat[0]));
            matrixstack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(afloat[1]));
        } else {
            matrixstack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-f));
            matrixstack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(f1));
        }
    }

    private void spawnTrail(LivingEntity livingentity, double d0, double d1, double d2) {
        if (livingentity != null) {
            double d3 = livingentity.getX() - d0;
            double d4 = livingentity.getY() - d1;
            double d5 = livingentity.getZ() - d2;
            if (!(d3 * d3 + d5 * d5 < 0.0064)) {
                double d6 = Math.sqrt(d3 * d3 + d4 * d4 + d5 * d5);
                int i = (int) MathHelper.clamp((float) (d6 / 0.4F), 1.0F, 16.0F);

                for (int j = 0; j < i; j++) {
                    int k =
                            (int)
                                    ((float) (550 + this.random.nextInt(300))
                                            * this.trailLengthSetting.getFloat());
                    this.trails.add(
                            new TrailsModule.DashCubic(
                                    new TrailsModule.DashBase(
                                            livingentity, 0.04F, (float) j / (float) i, k)));
                }
            }
        }
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.trails.clear();
        this.renderTrails.clear();
        this.hasPreviousPosition = false;
    }

    @Override
    protected void onEnable() {
        this.trails.clear();
        this.renderTrails.clear();
        this.visibility = 0.0F;
        this.hasPreviousPosition = false;
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null) {
            this.visibility = this.visibility + (1.0F - this.visibility) * 0.08F;
            this.glowOpacity =
                    this.glowOpacity
                            + ((this.glowSetting.isOn() ? 1.0F : 0.0F) - this.glowOpacity) * 0.08F;
            if (!this.hasPreviousPosition) {
                this.previousX = client.player.getX();
                this.previousY = client.player.getY();
                this.previousZ = client.player.getZ();
                this.hasPreviousPosition = true;
            } else {
                long nowMillis = System.currentTimeMillis();
                int count = this.trails.size();

                for (int k = 0; k < count; k++) {
                    TrailsModule.DashCubic dashCubic = this.trails.get(k);
                    dashCubic.ageFraction =
                            Math.min(
                                    1.0F,
                                    (float) (nowMillis - dashCubic.createdAtMillis)
                                            / (float) dashCubic.motion.lifetimeMillis);
                    if (dashCubic.ageFraction >= 1.0F && dashCubic.targetOpacity != 0.0F) {
                        dashCubic.targetOpacity = 0.0F;
                    }

                    dashCubic.opacity =
                            dashCubic.opacity
                                    + (dashCubic.targetOpacity - dashCubic.opacity) * 0.08F;
                }

                for (int i1 = this.trails.size() - 1; i1 >= 0; i1--) {
                    TrailsModule.DashCubic dashCubicValue = this.trails.get(i1);
                    if (dashCubicValue.ageFraction >= 1.0F
                            && dashCubicValue.targetOpacity == 0.0F
                            && dashCubicValue.opacity < 0.02F) {
                        this.trails.remove(i1);
                    }
                }

                this.renderTrails.clear();
                int j1 = 0;

                for (int countValue = this.trails.size(); j1 < countValue; j1++) {
                    TrailsModule.DashCubic dashCubic2 = this.trails.get(j1);
                    if (dashCubic2.opacity > 0.05F) {
                        this.renderTrails.add(dashCubic2);
                    }
                }

                float pitch = client.gameRenderer.getCamera().getPitch();
                boolean isOn = this.smoothingSetting.isOn();
                int count2 = this.renderTrails.size();

                for (int l = 0; l < count2; l++) {
                    TrailsModule.DashCubic dashCubic3 = this.renderTrails.get(l);
                    TrailsModule.DashCubic dashCubic4 =
                            isOn && l + 1 < count2 ? this.renderTrails.get(l + 1) : null;
                    if (dashCubic4 != null
                            && dashCubic4.motion.entityId != dashCubic3.motion.entityId) {
                        dashCubic4 = null;
                    }

                    dashCubic3.update(dashCubic4, nowMillis, pitch);
                }

                double previousXValue = this.previousX;
                double previousYValue = this.previousY;
                double previousZValue = this.previousZ;
                double d1 = this.positionSmoothingSetting.getFloat().doubleValue();
                this.previousX = MathHelper.lerp(d1, this.previousX, client.player.getX());
                this.previousY = MathHelper.lerp(d1, this.previousY, client.player.getY());
                this.previousZ = MathHelper.lerp(d1, this.previousZ, client.player.getZ());
                this.spawnTrail(client.player, previousXValue, previousYValue, previousZValue);
            }
        }
    }

    @Override
    protected void onDisable() {
        this.trails.clear();
        this.renderTrails.clear();
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && !(this.visibility < 0.05F) && !this.renderTrails.isEmpty()) {
            float tickDelta = render3DEvent.getTickDelta();
            float visibilityValue = this.visibility;
            float glowOpacityValue = this.glowOpacity;
            int count = this.renderTrails.size();
            long nowMillis = System.currentTimeMillis();
            MatrixStack matrixstack = render3DEvent.getMatrixStack();
            Vec3d vec3d = client.getEntityRenderDispatcher().camera.getCameraPos();
            double d0 = vec3d.x;
            double d1 = vec3d.y;
            double d2 = vec3d.z;
            Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);
            float yaw = client.gameRenderer.getCamera().getYaw();
            float pitch = client.gameRenderer.getCamera().getPitch();
            Quaternionf quaternionfx = client.gameRenderer.getCamera().getRotation();
            quaternionfx.transform(this.cameraRight.set(1.0F, 0.0F, 0.0F));
            quaternionfx.transform(this.cameraUp.set(0.0F, 1.0F, 0.0F));
            this.cameraRotation
                    .identity()
                    .rotateY((float) Math.toRadians((double) (-yaw)))
                    .rotateX((float) Math.toRadians((double) pitch));

            for (int k = 0; k < count; k++) {
                TrailsModule.DashCubic dashCubic = this.renderTrails.get(k);
                Identifier identifierx = dashCubic.texture.frameAt(nowMillis);
                if (identifierx != null) {
                    float factor = dashCubic.opacity * visibilityValue;
                    float f6 = 4.224F * factor * 0.3F;
                    int startColor = dashCubic.color;
                    matrixstack.push();
                    matrixstack.translate(
                            dashCubic.interpolatedX(tickDelta) - d0,
                            dashCubic.interpolatedY(tickDelta) - d1,
                            dashCubic.interpolatedZ(tickDelta) - d2);
                    this.rotateTrail(matrixstack, dashCubic.rotation, yaw, pitch);
                    matrixstack.scale(-0.1F, -0.1F, 0.1F);
                    drawTexturedQuad(
                            immediate.getBuffer(textureLayer.apply(identifierx)),
                            matrixstack.peek().getPositionMatrix(),
                            -f6,
                            -f6,
                            f6,
                            f6,
                            ColorUtils.darken(
                                    ColorUtils.interpolate(startColor, -1, 0.4F), factor));
                    matrixstack.pop();
                }
            }

            VertexConsumer vertexconsumer = immediate.getBuffer(textureLayer.apply(GLOW_TEXTURE));

            for (int k1 = 0; k1 < count; k1++) {
                TrailsModule.DashCubic dashCubicValue = this.renderTrails.get(k1);
                float f9 = dashCubicValue.opacity * visibilityValue;
                float f10 = 4.224F * f9 * 0.3F;
                float f11 = 1.0F - dashCubicValue.ageFraction;
                int startColorValue = dashCubicValue.color;
                int color = ColorUtils.interpolate(startColorValue, -1, 0.18F);
                matrixstack.push();
                matrixstack.translate(
                        dashCubicValue.interpolatedX(tickDelta) - d0,
                        dashCubicValue.interpolatedY(tickDelta) - d1,
                        dashCubicValue.interpolatedZ(tickDelta) - d2);
                matrixstack.multiply(this.cameraRotation);
                matrixstack.scale(-0.1F, -0.1F, 0.1F);
                Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
                drawTexturedQuad(
                        vertexconsumer,
                        matrix4f,
                        -f10 * 6.0F,
                        -f10 * 6.0F,
                        f10 * 6.0F,
                        f10 * 6.0F,
                        ColorUtils.withRawAlpha(color, 15.0F * f9));
                drawTexturedQuad(
                        vertexconsumer,
                        matrix4f,
                        -f10 * 2.2F,
                        -f10 * 2.2F,
                        f10 * 2.2F,
                        f10 * 2.2F,
                        ColorUtils.withRawAlpha(color, 70.0F * f9));
                drawTexturedQuad(
                        vertexconsumer,
                        matrix4f,
                        -f10 * 1.1F,
                        -f10 * 1.1F,
                        f10 * 1.1F,
                        f10 * 1.1F,
                        ColorUtils.withRawAlpha(color, 140.0F * f9));
                if (glowOpacityValue > 0.0F) {
                    float f7 = f9 * glowOpacityValue;
                    float f8 = f10 * (1.0F + 8.0F * f11 * f7);
                    drawTexturedQuad(
                            vertexconsumer,
                            matrix4f,
                            -f8,
                            -f8,
                            f8,
                            f8,
                            ColorUtils.withRawAlpha(
                                    ColorUtils.darken(color, f7 / 4.0F), 95.0F * f7));
                }

                matrixstack.pop();
            }

            immediate.draw();
        }
    }

    @Environment(EnvType.CLIENT)
    private static class DashBase {
        double previousZ;
        final int lifetimeMillis;
        double velocityY;
        final int entityId;
        final float previousYaw;
        final float yaw;
        double velocityZ;
        double z;
        double y;
        double x;
        double velocityX;
        double previousY;
        double previousX;

        DashBase(LivingEntity livingentity, float f, float f1, int lifetimeMillisValue) {
            this.entityId = livingentity.getId();
            this.lifetimeMillis = lifetimeMillisValue;
            this.yaw = livingentity.getYaw();
            this.previousYaw = livingentity.lastYaw;
            double velocityXValue = -(livingentity.lastRenderX - livingentity.getX());
            double velocityYValue = -(livingentity.lastRenderY - livingentity.getY());
            double velocityZValue = -(livingentity.lastRenderZ - livingentity.getZ());
            this.velocityX = velocityXValue;
            this.velocityY = velocityYValue;
            this.velocityZ = velocityZValue;
            float height = livingentity.getHeight();
            float f3 = livingentity.isSubmergedInWater() ? 2.4F : 1.0F;
            this.x =
                    livingentity.lastRenderX
                            - velocityXValue * (double) f1
                            + -0.0875
                            + 0.175 * Math.random();
            this.y =
                    livingentity.lastRenderY
                            - velocityYValue * (double) f1
                            + (double) (height / f3) / 3.0
                            + (double) (height / f3) / 4.0 * Math.random() * 2.7;
            this.z =
                    livingentity.lastRenderZ
                            - velocityZValue * (double) f1
                            + -0.0875
                            + 0.175 * Math.random();
            this.previousX = this.x;
            this.previousY = this.y;
            this.previousZ = this.z;
            this.velocityX *= (double) f;
            this.velocityY *= (double) f;
            this.velocityZ *= (double) f;
        }
    }

    @Environment(EnvType.CLIENT)
    private class DashCubic {
        final List<TrailsModule.DashSpark> sparks;
        final TrailsModule.DashTexture texture;
        float opacity = 0.0F;
        final long createdAtMillis;
        float ageFraction;
        final int color;
        final float[] rotation;
        float targetOpacity = 1.0F;
        final TrailsModule.DashBase motion;

        double interpolatedZ(float f) {
            return this.motion.previousZ + (this.motion.z - this.motion.previousZ) * (double) f;
        }

        void update(TrailsModule.DashCubic dashCubic, long i, float f) {
            this.motion.previousX = this.motion.x;
            this.motion.previousY = this.motion.y;
            this.motion.previousZ = this.motion.z;
            this.motion.velocityX =
                    (dashCubic != null ? dashCubic.motion.velocityX : this.motion.velocityX) / 1.05;
            this.motion.x = this.motion.x + 5.0 * this.motion.velocityX;
            this.motion.velocityY =
                    (dashCubic != null ? dashCubic.motion.velocityY : this.motion.velocityY) / 1.05;
            this.motion.y =
                    this.motion.y
                            + 5.0
                                    * this.motion.velocityY
                                    / (this.motion.velocityY < 0.0 ? 1.0 : 3.5);
            this.motion.velocityZ =
                    (dashCubic != null ? dashCubic.motion.velocityZ : this.motion.velocityZ) / 1.05;
            this.motion.z = this.motion.z + 5.0 * this.motion.velocityZ;
            this.updateRotation(f);
            int count = this.sparks.size();

            for (int k = 0; k < count; k++) {
                this.sparks.get(k).update(i);
            }

            for (int l1 = this.sparks.size() - 1; l1 >= 0; l1--) {
                if (this.sparks.get(l1).expired) {
                    this.sparks.remove(l1);
                }
            }
        }

        double interpolatedX(float f) {
            return this.motion.previousX + (this.motion.x - this.motion.previousX) * (double) f;
        }

        DashCubic(TrailsModule.DashBase dashBaseValue) {
            this.ageFraction = 0.0F;
            this.createdAtMillis = System.currentTimeMillis();
            this.rotation = new float[2];
            this.sparks = new ArrayList<>(4);
            this.motion = dashBaseValue;
            this.color = TrailsModule.this.trailColor();
            this.texture = TrailsModule.this.new DashTexture();
            this.updateRotation(MinecraftAccess.client.gameRenderer.getCamera().getPitch());
        }

        double interpolatedY(float f) {
            return this.motion.previousY + (this.motion.y - this.motion.previousY) * (double) f;
        }

        void updateRotation(float f) {
            double d0 =
                    Math.sqrt(
                            this.motion.velocityX * this.motion.velocityX
                                    + this.motion.velocityZ * this.motion.velocityZ);
            if (d0 < 5.0E-4) {
                this.rotation[0] = (float) (360.0 * Math.random());
                this.rotation[1] = f;
            } else {
                float f1 = TrailsModule.movementYaw(this.motion.velocityX, this.motion.velocityZ);
                this.rotation[0] = f1 - 60.0F - (this.motion.previousYaw - this.motion.yaw) * 3.0F;
                float f2 = Math.abs(f1 + 26.3F - this.motion.yaw) % 360.0F;
                if (f2 > 180.0F) {
                    f2 = 360.0F - f2;
                }

                this.rotation[1] = !(f2 < 10.0F) && !(f2 > 160.0F) ? f : -90.0F;
            }
        }
    }

    @Environment(EnvType.CLIENT)
    private static class DashSpark {
        double previousZ;
        final double speed;
        final double directionZ;
        final double directionY;
        boolean expired = false;
        final long createdAtMillis;
        float opacity = 1.0F;
        double previousY;
        final double directionX;
        double y;
        double previousX;
        double z;
        double x;

        DashSpark() {
            this.speed = Math.random() / 50.0;
            this.createdAtMillis = System.currentTimeMillis();
            double d0 = Math.random() * Math.PI * 2.0;
            double d1 = Math.toRadians(-90.0 + Math.random() * 180.0 - 90.0);
            this.directionX = Math.sin(d0);
            this.directionZ = Math.cos(d0);
            this.directionY = Math.cos(d1);
        }

        void update(long i) {
            float f = MathHelper.clamp((float) (i - this.createdAtMillis) / 1000.0F, 0.0F, 1.0F);
            if (f >= 1.0F) {
                this.expired = true;
            } else {
                this.expired = false;
            }

            this.opacity = 1.0F - f;
            this.previousX = this.x;
            this.previousY = this.y;
            this.previousZ = this.z;
            this.x = this.x + this.directionX * this.speed;
            this.y = this.y + this.directionY * this.speed;
            this.z = this.z + this.directionZ * this.speed;
        }
    }

    @Environment(EnvType.CLIENT)
    private class DashTexture {
        private final boolean animated;
        private final List<Identifier> frames;
        private final long durationMillis;
        private final long createdAtMillis = System.currentTimeMillis();

        Identifier frameAt(long i) {
            if (this.frames.isEmpty()) {
                return null;
            } else if (this.animated && this.frames.size() > 1 && this.durationMillis > 0L) {
                int j = (int) ((i - this.createdAtMillis) / 80L % (long) this.frames.size());
                return this.frames.get(j);
            } else {
                return this.frames.get(0);
            }
        }

        DashTexture() {
            boolean animatedValue;
            animatedValue =
                    (TrailsModule.this.random.nextInt(100) > 40
                            && !TrailsModule.animatedTextures.isEmpty());

            this.animated = animatedValue;
            if (animatedValue) {
                this.frames =
                        TrailsModule.animatedTextures.get(
                                TrailsModule.this.random.nextInt(
                                        TrailsModule.animatedTextures.size()));
                this.durationMillis =
                        (long)
                                ((float) (550 + TrailsModule.this.random.nextInt(300))
                                        * TrailsModule.this.trailLengthSetting.getFloat());
            } else {
                this.frames =
                        TrailsModule.staticTextures.isEmpty()
                                ? List.of()
                                : List.of(
                                        TrailsModule.staticTextures.get(
                                                TrailsModule.this.random.nextInt(
                                                        TrailsModule.staticTextures.size())));
                this.durationMillis = 0L;
            }
        }
    }
}
