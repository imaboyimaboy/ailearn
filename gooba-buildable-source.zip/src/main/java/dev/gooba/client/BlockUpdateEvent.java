package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;

@Environment(EnvType.CLIENT)
public class BlockUpdateEvent extends Event {
    private final BlockState state;
    private final BlockPos pos;
    private final BlockState oldState;

    public BlockPos getPos() {
        return this.pos;
    }

    public BlockState getState() {
        return this.state;
    }

    public BlockUpdateEvent(BlockPos blockpos, BlockState blockstate, BlockState oldStateValue) {
        this.pos = blockpos;
        this.state = blockstate;
        this.oldState = oldStateValue;
    }

    public BlockState getOldState() {
        return this.oldState;
    }
}
