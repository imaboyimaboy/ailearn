package dev.gooba.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class RotationNeuralNetwork {
    private static final Path MODEL_PATH = GoobaPaths.CONFIG_DIRECTORY.resolve("neuro_rotation.json");
    private final float[][] outputWeights;
    private final float[] outputBiases;

    private final float[][] hiddenWeights;
    private static final Gson gson = new GsonBuilder().create();
    private final float[] hiddenBiases;
    private final List<float[]> samples;

    private final float[] inputBiases;
    private static final Path SAMPLES_PATH = GoobaPaths.CONFIG_DIRECTORY.resolve("neuro_samples.bin");

    private final float[][] inputWeights = new float[24][8];

    private void initializeWeights() {
        Random random = new Random();
        initializeLayer(this.inputWeights, this.inputBiases, random);
        initializeLayer(this.hiddenWeights, this.hiddenBiases, random);
        initializeLayer(this.outputWeights, this.outputBiases, random);
    }

    private static void readJsonArray(JsonArray jsonarray, float[] afloat) {
        for (int i = 0; i < afloat.length; i++) {
            afloat[i] = jsonarray.get(i).getAsFloat();
        }
    }

    private static boolean containsInvalidValues(float[] afloat) {
        for (float f : afloat) {
            if (Float.isNaN(f) || Float.isInfinite(f)) {
                return true;
            }
        }

        return false;
    }

    private void loadSamples() {
        if (Files.exists(SAMPLES_PATH)) {
            try (DataInputStream datainputstream =
                    new DataInputStream(
                            new BufferedInputStream(Files.newInputStream(SAMPLES_PATH)))) {
                int i = datainputstream.readInt();
                if (i != 10) {
                    return;
                }

                int j = Math.min(datainputstream.readInt(), 40000);
                synchronized (this.samples) {
                    this.samples.clear();

                    for (int k = 0; k < j; k++) {
                        float[] afloat = new float[10];

                        for (int l = 0; l < afloat.length; l++) {
                            afloat[l] = datainputstream.readFloat();
                        }

                        this.samples.add(afloat);
                    }
                }
            } catch (Exception exception) {
            }
        }
    }

    private static void initializeLayer(float[][] afloat, float[] values, Random random) {
        float f = (float) Math.sqrt(2.0 / (double) afloat[0].length);

        for (float[] valuesValue : afloat) {
            for (int i = 0; i < valuesValue.length; i++) {
                valuesValue[i] = (float) (random.nextGaussian() * (double) f);
            }
        }

        Arrays.fill(values, 0.0F);
    }

    public RotationNeuralNetwork() {
        this.inputBiases = new float[24];
        this.hiddenWeights = new float[16][24];
        this.hiddenBiases = new float[16];
        this.outputWeights = new float[2][16];
        this.outputBiases = new float[2];
        this.samples = new ArrayList<>();

        this.initializeWeights();
        this.loadModel();
        this.loadSamples();
    }

    private boolean hasInvalidWeights() {
        return containsInvalidValues(this.inputWeights)
                || containsInvalidValues(this.inputBiases)
                || containsInvalidValues(this.hiddenWeights)
                || containsInvalidValues(this.hiddenBiases)
                || containsInvalidValues(this.outputWeights)
                || containsInvalidValues(this.outputBiases);
    }

    public void loadModel() {
        if (Files.exists(MODEL_PATH)) {
            try (BufferedReader bufferedreader =
                    Files.newBufferedReader(MODEL_PATH, StandardCharsets.UTF_8)) {
                JsonObject jsonobject = JsonParser.parseReader(bufferedreader).getAsJsonObject();
                readJsonMatrix(jsonobject.getAsJsonArray("w1"), this.inputWeights);
                readJsonArray(jsonobject.getAsJsonArray("b1"), this.inputBiases);
                readJsonMatrix(jsonobject.getAsJsonArray("w2"), this.hiddenWeights);
                readJsonArray(jsonobject.getAsJsonArray("b2"), this.hiddenBiases);
                readJsonMatrix(jsonobject.getAsJsonArray("w3"), this.outputWeights);
                readJsonArray(jsonobject.getAsJsonArray("b3"), this.outputBiases);
                if (this.hasInvalidWeights()) {
                    this.initializeWeights();
                } else {

                }
                return;
            } catch (Exception exception) {
            }

            this.initializeWeights();
        }
    }

    private static boolean containsInvalidValues(float[][] afloat) {
        for (float[] afloatValue : afloat) {
            if (containsInvalidValues(afloatValue)) {
                return true;
            }
        }

        return false;
    }

    private static void readJsonMatrix(JsonArray jsonarray, float[][] afloat) {
        for (int i = 0; i < afloat.length; i++) {
            readJsonArray(jsonarray.get(i).getAsJsonArray(), afloat[i]);
        }
    }

    private static float clamp(float f, float f1, float f2) {
        return f < f1 ? f1 : Math.min(f, f2);
    }

    private static JsonArray toJsonArray(float[][] fArray) {
        JsonArray jsonArray = new JsonArray();

        for (float[] fArrayValue : fArray) {
            jsonArray.add(toJsonArray(fArrayValue));
        }

        return jsonArray;
    }

    private static JsonArray toJsonArray(float[] fArray) {
        JsonArray jsonArray = new JsonArray();

        for (float var5 : fArray) {
            jsonArray.add(var5);
        }

        return jsonArray;
    }

    private void trainWeights(List<float[]> trainingSamples) {

        int epochs = 60;
        float learningRate = 0.004F;
        float momentum = 0.85F;
        float gradientLimit = 3.0F;
        float[][] inputWeightVelocity = new float[24][8];
        float[] inputBiasVelocity = new float[24];
        float[][] hiddenWeightVelocity = new float[16][24];
        float[] hiddenBiasVelocity = new float[16];
        float[][] outputWeightVelocity = new float[2][16];
        float[] outputBiasVelocity = new float[2];
        float[] inputActivations = new float[24];
        float[] hiddenActivations = new float[16];
        float[] outputActivations = new float[2];
        float[] outputGradient = new float[2];
        float[] hiddenGradient = new float[16];
        float[] inputGradient = new float[24];
        Random random = new Random();
        ArrayList<float[]> shuffledSamples = new ArrayList<>(trainingSamples);

        for (int epoch = 0; epoch < epochs; epoch++) {
            Collections.shuffle(shuffledSamples, random);
            float stepSize = learningRate * (1.0F - (float) epoch / (float) epochs * 0.9F);

            for (float[] sample : shuffledSamples) {
                this.forward(sample, inputActivations, hiddenActivations, outputActivations);

                for (int predictionIndex = 0; predictionIndex < 2; predictionIndex++) {
                    outputGradient[predictionIndex] =
                            clamp(
                                    outputActivations[predictionIndex]
                                            - sample[8 + predictionIndex],
                                    -gradientLimit,
                                    gradientLimit);
                }

                for (int outputNeuron = 0; outputNeuron < 2; outputNeuron++) {
                    for (int hiddenNeuron = 0; hiddenNeuron < 16; hiddenNeuron++) {
                        outputWeightVelocity[outputNeuron][hiddenNeuron] =
                                momentum * outputWeightVelocity[outputNeuron][hiddenNeuron]
                                        - stepSize
                                                * outputGradient[outputNeuron]
                                                * hiddenActivations[hiddenNeuron];
                        this.outputWeights[outputNeuron][hiddenNeuron] =
                                this.outputWeights[outputNeuron][hiddenNeuron]
                                        + outputWeightVelocity[outputNeuron][hiddenNeuron];
                    }

                    outputBiasVelocity[outputNeuron] =
                            momentum * outputBiasVelocity[outputNeuron]
                                    - stepSize * outputGradient[outputNeuron];
                    this.outputBiases[outputNeuron] =
                            this.outputBiases[outputNeuron] + outputBiasVelocity[outputNeuron];
                }

                for (int hiddenIndex = 0; hiddenIndex < 16; hiddenIndex++) {
                    float hiddenError = 0.0F;

                    for (int outputIndex = 0; outputIndex < 2; outputIndex++) {
                        hiddenError +=
                                outputGradient[outputIndex]
                                        * this.outputWeights[outputIndex][hiddenIndex];
                    }

                    hiddenGradient[hiddenIndex] =
                            clamp(
                                    hiddenError
                                            * (1.0F
                                                    - hiddenActivations[hiddenIndex]
                                                            * hiddenActivations[hiddenIndex]),
                                    -gradientLimit,
                                    gradientLimit);
                }

                for (int hiddenWeightRow = 0; hiddenWeightRow < 16; hiddenWeightRow++) {
                    for (int inputWeightColumn = 0; inputWeightColumn < 24; inputWeightColumn++) {
                        hiddenWeightVelocity[hiddenWeightRow][inputWeightColumn] =
                                momentum * hiddenWeightVelocity[hiddenWeightRow][inputWeightColumn]
                                        - stepSize
                                                * hiddenGradient[hiddenWeightRow]
                                                * inputActivations[inputWeightColumn];
                        this.hiddenWeights[hiddenWeightRow][inputWeightColumn] =
                                this.hiddenWeights[hiddenWeightRow][inputWeightColumn]
                                        + hiddenWeightVelocity[hiddenWeightRow][inputWeightColumn];
                    }

                    hiddenBiasVelocity[hiddenWeightRow] =
                            momentum * hiddenBiasVelocity[hiddenWeightRow]
                                    - stepSize * hiddenGradient[hiddenWeightRow];
                    this.hiddenBiases[hiddenWeightRow] =
                            this.hiddenBiases[hiddenWeightRow]
                                    + hiddenBiasVelocity[hiddenWeightRow];
                }

                for (int inputIndex = 0; inputIndex < 24; inputIndex++) {
                    float inputError = 0.0F;

                    for (int hiddenWeightColumn = 0;
                            hiddenWeightColumn < 16;
                            hiddenWeightColumn++) {
                        inputError +=
                                hiddenGradient[hiddenWeightColumn]
                                        * this.hiddenWeights[hiddenWeightColumn][inputIndex];
                    }

                    inputGradient[inputIndex] =
                            clamp(
                                    inputError
                                            * (1.0F
                                                    - inputActivations[inputIndex]
                                                            * inputActivations[inputIndex]),
                                    -gradientLimit,
                                    gradientLimit);
                }

                for (int inputWeightRow = 0; inputWeightRow < 24; inputWeightRow++) {
                    for (int featureIndex = 0; featureIndex < 8; featureIndex++) {
                        inputWeightVelocity[inputWeightRow][featureIndex] =
                                momentum * inputWeightVelocity[inputWeightRow][featureIndex]
                                        - stepSize
                                                * inputGradient[inputWeightRow]
                                                * sample[featureIndex];
                        this.inputWeights[inputWeightRow][featureIndex] =
                                this.inputWeights[inputWeightRow][featureIndex]
                                        + inputWeightVelocity[inputWeightRow][featureIndex];
                    }

                    inputBiasVelocity[inputWeightRow] =
                            momentum * inputBiasVelocity[inputWeightRow]
                                    - stepSize * inputGradient[inputWeightRow];
                    this.inputBiases[inputWeightRow] =
                            this.inputBiases[inputWeightRow] + inputBiasVelocity[inputWeightRow];
                }
            }
        }
    }

    private void forward(
            float[] features, float[] firstLayer, float[] secondLayer, float[] outputs) {
        for (int firstNeuron = 0; firstNeuron < 24; firstNeuron++) {
            float firstSum = this.inputBiases[firstNeuron];

            for (int featureIndex = 0; featureIndex < 8; featureIndex++) {
                firstSum += this.inputWeights[firstNeuron][featureIndex] * features[featureIndex];
            }

            firstLayer[firstNeuron] = (float) Math.tanh((double) firstSum);
        }

        for (int secondNeuron = 0; secondNeuron < 16; secondNeuron++) {
            float secondSum = this.hiddenBiases[secondNeuron];

            for (int firstIndex = 0; firstIndex < 24; firstIndex++) {
                secondSum += this.hiddenWeights[secondNeuron][firstIndex] * firstLayer[firstIndex];
            }

            secondLayer[secondNeuron] = (float) Math.tanh((double) secondSum);
        }

        for (int outputNeuron = 0; outputNeuron < 2; outputNeuron++) {
            float outputSum = this.outputBiases[outputNeuron];

            for (int secondIndex = 0; secondIndex < 16; secondIndex++) {
                outputSum +=
                        this.outputWeights[outputNeuron][secondIndex] * secondLayer[secondIndex];
            }

            outputs[outputNeuron] = outputSum;
        }
    }

    public void saveModel() {
        if (hasInvalidWeights()) return;
        try {
            Files.createDirectories(MODEL_PATH.getParent());
            JsonObject model = new JsonObject();
            model.add("w1", toJsonArray(inputWeights));
            model.add("b1", toJsonArray(inputBiases));
            model.add("w2", toJsonArray(hiddenWeights));
            model.add("b2", toJsonArray(hiddenBiases));
            model.add("w3", toJsonArray(outputWeights));
            model.add("b3", toJsonArray(outputBiases));
            try (var writer = Files.newBufferedWriter(MODEL_PATH, StandardCharsets.UTF_8)) {
                gson.toJson(model, writer);
            }
        } catch (Exception ignored) {
        }
    }

    private void saveSamples(List<float[]> samples) {
        try {
            Files.createDirectories(SAMPLES_PATH.getParent());
            try (var output =
                    new java.io.DataOutputStream(
                            new java.io.BufferedOutputStream(
                                    Files.newOutputStream(SAMPLES_PATH)))) {
                output.writeInt(10);
                output.writeInt(samples.size());
                for (float[] sample : samples) {
                    for (int index = 0; index < 10; index++) {
                        output.writeFloat(sample[index]);
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void train(
            List<float[]> samples, java.util.function.BiConsumer<Boolean, Integer> callback) {
        boolean success = false;
        try {
            saveSamples(samples);
            if (samples.size() >= 300) {
                if (hasInvalidWeights()) initializeWeights();
                trainWeights(samples);
                if (hasInvalidWeights()) {
                    initializeWeights();

                } else {

                    saveModel();
                    success = true;
                }
            }
        } catch (Throwable ignored) {
            initializeWeights();

        } finally {

        }
        if (callback != null) callback.accept(success, samples.size());
    }
}
