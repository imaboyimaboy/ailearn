package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.Screen;

@Environment(EnvType.CLIENT)
public class MouseButtonEvent extends Event {
    private final int action;
    private final int button;
    private double mouseX;
    private double mouseY;
    private final Screen screen;
    private final int modifiers;

    public Screen getScreen() {
        return this.screen;
    }

    public int getAction() {
        return this.action;
    }

    public MouseButtonEvent(
            int buttonValue,
            int actionValue,
            int modifiersValue,
            Screen screen,
            double mouseXValue,
            double mouseYValue) {
        this.button = buttonValue;
        this.action = actionValue;
        this.modifiers = modifiersValue;
        this.screen = screen;
        this.mouseX = mouseXValue;
        this.mouseY = mouseYValue;
    }

    public double getMouseX() {
        return this.mouseX;
    }

    public int getModifiers() {
        return this.modifiers;
    }

    public int getButton() {
        return this.button;
    }

    public int getMouseButton() {
        return this.button;
    }

    public double getMouseY() {
        return this.mouseY;
    }
}
