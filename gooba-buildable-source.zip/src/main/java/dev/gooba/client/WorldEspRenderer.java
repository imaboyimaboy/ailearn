package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public final class WorldEspRenderer implements MinecraftAccess {
    private static final List<WorldEspRenderer.Entry> drawQueue = new ArrayList<>();
    private static final BufferAllocator lineAllocator = new BufferAllocator(524288);
    private static final RenderPipeline FILL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "esp_fill"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .build());
    private static final RenderPipeline LINE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "esp_lines"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.DEBUG_LINES)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .build());
    private static final BufferAllocator fillAllocator = new BufferAllocator(524288);
    private static final RenderLayer FILL_LAYER =
            RenderLayer.of(
                    "goobaa_esp_fill",
                    RenderSetup.builder(FILL_PIPELINE).expectedBufferSize(65536).build());
    private static final RenderLayer LINE_LAYER =
            RenderLayer.of(
                    "goobaa_esp_lines",
                    RenderSetup.builder(LINE_PIPELINE).expectedBufferSize(65536).build());

    public static void enqueueBox(Box box, int i, boolean flag) {
        drawQueue.add(new WorldEspRenderer.Entry(box, i, -1, flag));
    }

    private WorldEspRenderer() {}

    public static void enqueueBox(Box box, int i, int j, boolean flag) {
        drawQueue.add(new WorldEspRenderer.Entry(box, i, j, flag));
    }

    private static void putQuad(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float f8,
            float f9,
            float f10,
            float f11,
            int i) {
        vertexconsumer.vertex(matrix4f, f, f1, f2).color(i);
        vertexconsumer.vertex(matrix4f, f3, f4, f5).color(i);
        vertexconsumer.vertex(matrix4f, f6, f7, f8).color(i);
        vertexconsumer.vertex(matrix4f, f9, f10, f11).color(i);
    }

    private static void putBox(VertexConsumer vertexconsumer, Matrix4f matrix4f, Box box, int i) {
        float minX = (float) box.minX;
        float minY = (float) box.minY;
        float minZ = (float) box.minZ;
        float maxX = (float) box.maxX;
        float maxY = (float) box.maxY;
        float maxZ = (float) box.maxZ;
        putQuad(
                vertexconsumer,
                matrix4f,
                minX,
                minY,
                minZ,
                maxX,
                minY,
                minZ,
                maxX,
                minY,
                maxZ,
                minX,
                minY,
                maxZ,
                i);
        putQuad(
                vertexconsumer,
                matrix4f,
                minX,
                maxY,
                minZ,
                minX,
                maxY,
                maxZ,
                maxX,
                maxY,
                maxZ,
                maxX,
                maxY,
                minZ,
                i);
        putQuad(
                vertexconsumer,
                matrix4f,
                minX,
                minY,
                maxZ,
                maxX,
                minY,
                maxZ,
                maxX,
                maxY,
                maxZ,
                minX,
                maxY,
                maxZ,
                i);
        putQuad(
                vertexconsumer,
                matrix4f,
                maxX,
                minY,
                minZ,
                minX,
                minY,
                minZ,
                minX,
                maxY,
                minZ,
                maxX,
                maxY,
                minZ,
                i);
        putQuad(
                vertexconsumer,
                matrix4f,
                minX,
                minY,
                minZ,
                minX,
                minY,
                maxZ,
                minX,
                maxY,
                maxZ,
                minX,
                maxY,
                minZ,
                i);
        putQuad(
                vertexconsumer,
                matrix4f,
                maxX,
                minY,
                maxZ,
                maxX,
                minY,
                minZ,
                maxX,
                maxY,
                minZ,
                maxX,
                maxY,
                maxZ,
                i);
    }

    public static void flush(MatrixStack matrixstack) {
        if (!drawQueue.isEmpty() && client.gameRenderer != null) {
            Vec3d vec3d = client.gameRenderer.getCamera().getCameraPos();
            Vec3d vec3d1 =
                    Vec3d.fromPolar(
                                    client.gameRenderer.getCamera().getPitch(),
                                    client.gameRenderer.getCamera().getYaw())
                            .multiply(0.1);
            Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
            Immediate immediate = VertexConsumerProvider.immediate(fillAllocator);
            VertexConsumer vertexconsumer = immediate.getBuffer(FILL_LAYER);

            for (WorldEspRenderer.Entry entry : drawQueue) {
                Box box = entry.box.offset(-vec3d.x, -vec3d.y, -vec3d.z);
                putBox(vertexconsumer, matrix4f, box, entry.color);
            }

            immediate.draw(FILL_LAYER);
            boolean flag = false;

            for (WorldEspRenderer.Entry entryValue : drawQueue) {
                if (entryValue.tracer) {
                    flag = true;
                    break;
                }
            }

            if (flag) {
                Immediate immediateValue = VertexConsumerProvider.immediate(lineAllocator);
                VertexConsumer buffer = immediateValue.getBuffer(LINE_LAYER);

                for (WorldEspRenderer.Entry entry2 : drawQueue) {
                    if (entry2.tracer) {
                        Box boxValue = entry2.box.offset(-vec3d.x, -vec3d.y, -vec3d.z);
                        int i =
                                entry2.tracerAlpha >= 0
                                        ? ColorUtils.withAlpha(entry2.color, entry2.tracerAlpha)
                                        : entry2.color;
                        putLine(
                                buffer,
                                matrix4f,
                                (float) vec3d1.x,
                                (float) vec3d1.y,
                                (float) vec3d1.z,
                                (float) boxValue.getCenter().x,
                                (float) boxValue.getCenter().y,
                                (float) boxValue.getCenter().z,
                                i);
                    }
                }

                immediateValue.draw(LINE_LAYER);
            }

            drawQueue.clear();
        }
    }

    private static void putLine(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            int i) {
        vertexconsumer.vertex(matrix4f, f, f1, f2).color(i);
        vertexconsumer.vertex(matrix4f, f3, f4, f5).color(i);
    }

    public static void clear() {
        drawQueue.clear();
    }

    @Environment(EnvType.CLIENT)
    private static record Entry(Box box, int color, int tracerAlpha, boolean tracer) {}
}
