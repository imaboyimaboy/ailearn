package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.joml.Matrix4f;

import java.security.SecureRandom;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

@Environment(EnvType.CLIENT)
public final class MathUtils implements MinecraftAccess {
    public static final Matrix4f matrix4f = new Matrix4f();

    private static final Random random = new Random();
    public static final Matrix4f matrix4f2 = new Matrix4f();
    public static final Matrix4f matrix4f3 = new Matrix4f();
    private static final double[] sineTable = new double[65536];

    private static void validateRange(double minimum, double maximum) {
        if (maximum < minimum) {
            throw new IllegalArgumentException("max cannot be less than min.");
        }
    }

    public static double clampBetween(double minimum, double maximum, double value) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    public static float lerp(double start, double end, double progress) {
        return (float) (start + (end - start) * progress);
    }

    public static boolean containsPoint(
            float mouseX, float mouseY, float f2, float f3, float width, float height) {
        return mouseX > f2 && mouseX < f2 + width && mouseY > f3 && mouseY < f3 + height;
    }

    public static float roundToStep(float value, float step) {
        return (float) Math.round(value / step) * step;
    }

    private MathUtils() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static float randomInterpolated(double minimum, double maximum) {
        return (float) (minimum + (maximum - minimum) * Math.random());
    }

    public static int randomIntInclusive(int minimum, int maximum) {
        return minimum + (int) (Math.random() * (double) (maximum - minimum + 1));
    }

    public static float randomFloat(float minimum, float maximum) {
        validateRange((double) minimum, (double) maximum);
        return minimum + ThreadLocalRandom.current().nextFloat() * (maximum - minimum);
    }

    public static float secureRandomFloat(float minimum, float number) {
        return (Float)
                NumberInterpolation.getNumber(
                        number, minimum, (double) new SecureRandom().nextFloat());
    }

    public static float clamp(float value, float minimum, float maximum) {
        if (value < minimum) {
            return minimum;
        } else {
            return value > maximum ? maximum : value;
        }
    }

    public static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    public static double randomDouble(double minimum, double maximum) {
        validateRange(minimum, maximum);
        return minimum + ThreadLocalRandom.current().nextDouble() * (maximum - minimum);
    }

    static {
        for (int i = 0; i < 65536; i++) {
            sineTable[i] = Math.sin((double) i * (Math.PI * 2) / 65536.0);
        }
    }

    public static float quantize(float value, float step) {
        return (float) Math.round(value / step) * step;
    }

    public static float randomFloatUnchecked(float minimum, float maximum) {
        return (float) (Math.random() * (double) (maximum - minimum) + (double) minimum);
    }

    public static double fastSin(double angle) {
        int i = (int) (angle * 10430.378350470453) & 65535;
        return sineTable[i];
    }
}
