package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Environment(EnvType.CLIENT)
public @interface ModuleInfo {
    String name();

    boolean autoEnabled() default false;

    ModuleCategory category();

    String desc() default "The module has no description";

    int key() default -1;

    boolean allowDisable() default true;

    boolean hidden() default false;
}
