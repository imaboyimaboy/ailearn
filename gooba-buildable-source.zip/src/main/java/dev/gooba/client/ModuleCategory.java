package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum ModuleCategory {
    COMBAT("Combat", "Q"),
    PLAYER("Player", "S"),
    OTHER("Misc", "V"),
    RENDER("Render", "U"),
    DONUT("Donut", "\ue001"),
    CLIENT("Client", "R");

    public TimedAnimation timedAnimation;

    private final String icon;
    public TimedAnimation timedAnimation2 = new DecelerateAnimation(300, 1.0);
    public EasingAnimation selectionAnimation;
    private final String displayName;

    public String getIcon() {
        return this.icon;
    }

    private ModuleCategory(String displayNameValue, String iconValue) {
        this.timedAnimation = new DecelerateAnimation(300, 1.0);
        this.selectionAnimation = new EasingAnimation();
        this.displayName = displayNameValue;
        this.icon = iconValue;
    }

    public String getDisplayName() {
        return this.displayName;
    }
}
