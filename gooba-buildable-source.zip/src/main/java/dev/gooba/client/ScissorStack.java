package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

import org.lwjgl.opengl.GL11;

import java.util.ArrayDeque;
import java.util.Deque;

@Environment(EnvType.CLIENT)
public class ScissorStack {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Deque<int[]> rectangles = new ArrayDeque<>();

    public static void push(float f, float f1, float f2, float f3, float f4) {
        RenderBatchDispatcher.flush();
        int height = mc.getWindow().getHeight();
        int j = (int) (f * f4);
        int k = (int) ((float) height - (f1 + f3) * f4);
        int l = (int) (f2 * f4);
        int i1 = (int) (f3 * f4);
        if (!rectangles.isEmpty()) {
            int[] aint = rectangles.peek();
            int j1 = aint[0];
            int k1 = aint[1];
            int l1 = j1 + aint[2];
            int i2 = k1 + aint[3];
            int j2 = j + l;
            int k2 = k + i1;
            j = Math.max(j, j1);
            k = Math.max(k, k1);
            j2 = Math.min(j2, l1);
            k2 = Math.min(k2, i2);
            l = Math.max(0, j2 - j);
            i1 = Math.max(0, k2 - k);
        }

        rectangles.push(new int[] {j, k, l, i1});
        GL11.glEnable(3089);
        GL11.glScissor(j, k, l, i1);
    }

    public static void pop() {
        RenderBatchDispatcher.flush();
        if (!rectangles.isEmpty()) {
            rectangles.pop();
        }

        if (rectangles.isEmpty()) {
            GL11.glDisable(3089);
        } else {
            int[] aint = rectangles.peek();
            GL11.glScissor(aint[0], aint[1], aint[2], aint[3]);
        }
    }

    public static void push(float f, float f1, float f2, float f3) {
        int i =
                mc.getWindow()
                        .calculateScaleFactor(
                                mc.options.getGuiScale().getValue(), mc.forcesUnicodeFont());
        push(f, f1, f2, f3, (float) i);
    }
}
