package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class ColorSetting extends Setting<Integer> {

    private Integer cachedColor;
    public boolean expanded = false;
    public TimedAnimation timedAnimation = new DecelerateAnimation(220, 1.0);

    public ColorSetting setValue(Integer integer) {
        this.cachedColor = integer;
        return (ColorSetting) super.setValue(integer);
    }

    public Integer getColor() {
        if (this.cachedColor == null) {
            this.cachedColor = (Integer) super.getValue();
        }

        return this.cachedColor;
    }

    public ColorSetting onChange(Runnable runnable) {
        return (ColorSetting)
                super.onChange(
                        () -> {
                            runnable.run();
                            this.cachedColor = (Integer) super.getValue();
                        });
    }

    public ColorSetting visibleWhen(Supplier supplier) {
        return (ColorSetting) super.visibleWhen(supplier);
    }

    public ColorSetting(String nameValue, Integer integer) {
        super(nameValue, integer);
        this.cachedColor = integer;
    }

    public ColorSetting(Module moduleValue, String nameValue, Integer integer) {
        super(moduleValue, nameValue, integer);
        this.cachedColor = integer;
    }
}
