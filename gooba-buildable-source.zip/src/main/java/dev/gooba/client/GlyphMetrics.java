package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class GlyphMetrics {
    public final float v1;
    public final float u0;
    public final float offsetX;
    public final int codePoint;
    public final float advance;
    public final float atlasY;
    public final float width;
    public final float offsetY;
    public final float v0;
    public final float atlasX;
    public final float u1;
    public final float height;

    public GlyphMetrics(
            int codePointValue,
            float atlasXValue,
            float atlasYValue,
            float widthValue,
            float heightValue,
            float offsetXValue,
            float offsetYValue,
            float advanceValue,
            float f7,
            float f8) {
        this.codePoint = codePointValue;
        this.atlasX = atlasXValue;
        this.atlasY = atlasYValue;
        this.width = widthValue;
        this.height = heightValue;
        this.offsetX = offsetXValue;
        this.offsetY = offsetYValue;
        this.advance = advanceValue;
        this.u0 = atlasXValue / f7;
        this.v0 = atlasYValue / f8;
        this.u1 = (atlasXValue + widthValue) / f7;
        this.v1 = (atlasYValue + heightValue) / f8;
    }
}
