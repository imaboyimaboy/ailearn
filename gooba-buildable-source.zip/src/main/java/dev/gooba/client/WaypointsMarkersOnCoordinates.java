package dev.gooba.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.Vec3d;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

@Environment(EnvType.CLIENT)
public class WaypointsMarkersOnCoordinates extends Command implements MinecraftAccess {

    private static final Path WAYPOINTS_FILE = GoobaPaths.CONFIG_DIRECTORY.resolve("waypoints.json");
    private final Map<String, WaypointsMarkersOnCoordinates.Waypoint> waypoints =
            new ConcurrentHashMap<>();
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private void saveWaypoints() {
        JsonArray waypoints = new JsonArray();
        for (WaypointsMarkersOnCoordinates.Waypoint waypoint : this.waypoints.values()) {
            JsonObject entry = new JsonObject();
            entry.addProperty("name", waypoint.name());
            entry.addProperty("x", waypoint.pos().x);
            entry.addProperty("y", waypoint.pos().y);
            entry.addProperty("z", waypoint.pos().z);
            waypoints.add(entry);
        }

        try {
            Files.createDirectories(WAYPOINTS_FILE.getParent());
            try (java.io.Writer writer =
                    new java.io.OutputStreamWriter(
                            new java.io.FileOutputStream(WAYPOINTS_FILE.toFile()),
                            StandardCharsets.UTF_8)) {
                gson.toJson(waypoints, writer);
            }
        } catch (java.io.IOException exception) {
        }
    }

    private void showUsage() {
        ChatMessages.send(
                "§7.way §fadd §7<name> [x y z] §8| §7.way §fdelete §7<name> §8| §7.way §fclear §8|"
                    + " §7.way §flist");
    }

    @Override
    public List suggest(String text) {
        String textValue = text.toLowerCase();
        if (!textValue.startsWith("delete ")
                && !textValue.startsWith("del ")
                && !textValue.startsWith("remove ")) {
            return Stream.of("add", "delete", "clear", "list")
                    .filter(s5 -> s5.startsWith(textValue))
                    .toList();
        } else {
            String text3 = textValue.substring(0, textValue.indexOf(32));
            String text4 = textValue.substring(text3.length() + 1);
            return this.waypoints.values().stream()
                    .filter(
                            waypointsmarkersoncoordinates$waypoint ->
                                    waypointsmarkersoncoordinates$waypoint
                                            .name()
                                            .toLowerCase()
                                            .startsWith(text4))
                    .map(
                            waypointsmarkersoncoordinates$waypoint -> {
                                String s5 = waypointsmarkersoncoordinates$waypoint.name();
                                return text3 + " " + s5;
                            })
                    .toList();
        }
    }

    @Override
    public void execute(String[] astring) {
        if (astring.length == 0) {
            this.showUsage();
        } else {
            String text = astring[0].toLowerCase();
            switch (text.hashCode()) {
                case -1335458389:
                    if (text.equals("delete")) {
                        if (astring.length < 2) {
                            ChatMessages.send("§7Usage: §f.way delete <name>");
                            return;
                        }

                        if (this.waypoints.remove(astring[1].toLowerCase()) != null) {
                            this.saveWaypoints();
                            String textValue = astring[1];
                            ChatMessages.send("§aWaypoint deleted: §f" + textValue);
                        } else {
                            String text2 = astring[1];
                            ChatMessages.send("§cWaypoint not found: §f" + text2);
                        }

                        return;
                    }
                    break;
                case -934610812:
                    if (text.equals("remove")) {
                        if (astring.length < 2) {
                            ChatMessages.send("§7Usage: §f.way delete <name>");
                            return;
                        }

                        if (this.waypoints.remove(astring[1].toLowerCase()) != null) {
                            this.saveWaypoints();
                            String text3 = astring[1];
                            ChatMessages.send("§aWaypoint deleted: §f" + text3);
                        } else {
                            String text4 = astring[1];
                            ChatMessages.send("§cWaypoint not found: §f" + text4);
                        }

                        return;
                    }
                    break;
                case 96417:
                    if (text.equals("add")) {
                        if (astring.length < 2) {
                            ChatMessages.send("§7Usage: §f.way add <name> [x y z]");
                            return;
                        }

                        String text5 = astring[1];
                        Vec3d vec3d;
                        if (astring.length >= 5) {
                            try {
                                vec3d =
                                        new Vec3d(
                                                Double.parseDouble(astring[2]),
                                                Double.parseDouble(astring[3]),
                                                Double.parseDouble(astring[4]));
                            } catch (NumberFormatException numberformatexception) {
                                ChatMessages.send("§cError: incorrect coordinates");
                                return;
                            }
                        } else {
                            if (client.player == null) {
                                ChatMessages.send(
                                        "§cYou are not in the world, enter the coordinates: §f.way"
                                            + " add <name> <x> <y> <z>");
                                return;
                            }

                            vec3d = client.player.getEntityPos();
                        }

                        boolean flag;
                        flag =
                                (this.waypoints.put(
                                                text5.toLowerCase(),
                                                new WaypointsMarkersOnCoordinates.Waypoint(
                                                        text5, vec3d))
                                        != null);

                        this.saveWaypoints();
                        if (flag) {
                            int l2 = (int) vec3d.x;
                            int i4 = (int) vec3d.y;
                            int j2 = (int) vec3d.z;
                            int j = i4;
                            int k1 = l2;
                            String text6 = "§aWaypoint updated: §f";
                            ChatMessages.send(
                                    text6 + text5 + " §7(" + k1 + ", " + j + ", " + j2 + ")");
                        } else {
                            int i3 = (int) vec3d.x;
                            int j3 = (int) vec3d.y;
                            int k2 = (int) vec3d.z;
                            int i2 = j3;
                            int l1 = i3;
                            String text7 = "§aWaypoint added: §f";
                            ChatMessages.send(
                                    text7 + text5 + " §7(" + l1 + ", " + i2 + ", " + k2 + ")");
                        }

                        return;
                    }
                    break;
                case 99339:
                    if (text.equals("del")) {
                        if (astring.length < 2) {
                            ChatMessages.send("§7Usage: §f.way delete <name>");
                            return;
                        }

                        if (this.waypoints.remove(astring[1].toLowerCase()) != null) {
                            this.saveWaypoints();
                            String text8 = astring[1];
                            ChatMessages.send("§aWaypoint deleted: §f" + text8);
                        } else {
                            String text9 = astring[1];
                            ChatMessages.send("§cWaypoint not found: §f" + text9);
                        }

                        return;
                    }
                    break;
                case 3322014:
                    if (text.equals("list")) {
                        if (this.waypoints.isEmpty()) {
                            ChatMessages.send("§7No waypoints");
                            return;
                        }

                        int count = this.waypoints.size();
                        ChatMessages.send("§7Waypoints (§f" + count + "§7):");

                        for (WaypointsMarkersOnCoordinates.Waypoint waypoint :
                                this.waypoints.values()) {
                            String text10 = waypoint.name();
                            int k3 = (int) waypoint.pos().x;
                            int l3 = (int) waypoint.pos().y;
                            int j1 = (int) waypoint.pos().z;
                            int i1 = l3;
                            int l = k3;
                            String text11 = text10;
                            ChatMessages.send(
                                    "§8• §f" + text11 + " §7— §f" + l + ", " + i1 + ", " + j1);
                        }

                        return;
                    }
                    break;
                case 94746189:
                    if (text.equals("clear")) {
                        int countValue = this.waypoints.size();
                        this.waypoints.clear();
                        this.saveWaypoints();
                        ChatMessages.send("§a Waypoints removed: §f" + countValue);
                        return;
                    }
            }

            this.showUsage();
        }
    }

    public WaypointsMarkersOnCoordinates() {
        super("way", ".way <add|delete|clear|list>", "Waypoints - markers on coordinates");
        this.loadWaypoints();
        Gooba.getEventBus().subscribe(this);
    }

    @EventHandler
    public void onRender2D(Render2DEvent render2DEvent) {
        if (client.player != null && client.world != null && !this.waypoints.isEmpty()) {
            if (!client.options.hudHidden) {
                Font font = Fonts.SF_MEDIUM;
                float size = 8.0F;
                Vec3d vec3d = client.gameRenderer.getCamera().getCameraPos();
                float f1 =
                        (float) Math.max(64, client.options.getViewDistance().getValue() * 16 - 16);

                for (WaypointsMarkersOnCoordinates.Waypoint waypoint : this.waypoints.values()) {
                    float f2 = (float) vec3d.distanceTo(waypoint.pos());
                    Vec3d vec3d1 = waypoint.pos();
                    boolean flag = f2 > f1;
                    if (flag) {
                        vec3d1 =
                                vec3d.add(
                                        waypoint.pos()
                                                .subtract(vec3d)
                                                .normalize()
                                                .multiply((double) f1));
                    }

                    Vec3d vec3d2 = ProjectionUtils.worldToScreen(vec3d1);
                    if (!(vec3d2.z <= 0.0) && !(vec3d2.z >= 1.0)) {
                        String string =
                                waypoint.name()
                                        + " "
                                        + TextFormatting.colorTag(
                                                ThemeColors.secondaryTextWithOpacity(1.0F))
                                        + (int) f2
                                        + "m";
                        float width = font.measureWidth(string, size) + 10.0F;
                        float height = 13.0F;
                        float f5 = (float) vec3d2.x - width / 2.0F;
                        float f6 = (float) vec3d2.y - height - 6.0F;
                        RenderUtils.Blur.drawRoundedBlur(
                                f5, f6, width, height, 1.0F, 4.0F, ColorUtils.hudBackground(1.0F));
                        RenderUtils.Render2D.drawRoundedOutline(
                                f5,
                                f6,
                                width,
                                height,
                                0.5F,
                                ThemeColors.outlineWithOpacity(1.0F),
                                4.0F);
                        font.drawCenteredText(
                                string,
                                f5 + width / 2.0F,
                                f6 + 1.8F,
                                size,
                                ThemeColors.textWithOpacity(1.0F));
                        if (!flag) {
                            RenderUtils.Render2D.drawRoundedRect(
                                    (float) vec3d2.x - 1.5F,
                                    (float) vec3d2.y - 1.5F,
                                    3.0F,
                                    3.0F,
                                    ColorUtils.hudAccent(),
                                    1.5F);
                        }
                    }
                }
            }
        }
    }

    private void loadWaypoints() {
        if (Files.exists(WAYPOINTS_FILE)) {
            try {
                InputStreamReader inputstreamreader =
                        new InputStreamReader(
                                new FileInputStream(WAYPOINTS_FILE.toFile()),
                                StandardCharsets.UTF_8);

                label60:
                {
                    JsonArray jsonarray;
                    try {
                        jsonarray = JsonParser.parseReader(inputstreamreader).getAsJsonArray();
                    } catch (Throwable throwableValue) {
                        try {
                            inputstreamreader.close();
                        } catch (Throwable throwable7) {
                            throwableValue.addSuppressed(throwable7);
                        }

                        throw throwableValue;
                    }

                    Throwable throwable8;
                    label45:
                    {
                        Iterator iterator;
                        try {
                            this.waypoints.clear();
                            iterator = jsonarray.iterator();
                        } catch (Throwable throwable9) {
                            throwable8 = throwable9;
                            boolean flag1 = false;
                            break label45;
                        }

                        while (true) {
                            try {
                                if (!iterator.hasNext()) {
                                    break label60;
                                }

                                JsonElement jsonelement = (JsonElement) iterator.next();
                                JsonObject jsonobject = jsonelement.getAsJsonObject();
                                String name = jsonobject.get("name").getAsString();
                                Vec3d vec3d =
                                        new Vec3d(
                                                jsonobject.get("x").getAsDouble(),
                                                jsonobject.get("y").getAsDouble(),
                                                jsonobject.get("z").getAsDouble());
                                this.waypoints.put(
                                        name.toLowerCase(),
                                        new WaypointsMarkersOnCoordinates.Waypoint(name, vec3d));
                            } catch (Throwable throwable10) {
                                throwable8 = throwable10;
                                boolean flag = false;
                                break;
                            }
                        }
                    }

                    Throwable throwable = throwable8;

                    try {
                        inputstreamreader.close();
                    } catch (Throwable throwable11) {
                        throwable.addSuppressed(throwable11);
                    }

                    throw dev.gooba.client.Sneaky.rethrow(throwable);
                }

                inputstreamreader.close();
            } catch (Exception exception) {
            }
        }
    }

    @Environment(EnvType.CLIENT)
    private static record Waypoint(String name, Vec3d pos) {}
}
