package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.LinkedHashMap;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class Fonts {
    private static final Map<String, String> FONT_RESOURCES = new LinkedHashMap<>();
    public static final Font GOOBA_ICONS = register("goobaa_2", "goobaa_2");
    public static final Font LOGO = register("gooba_logo", "gooba_logo");
    public static final Font GOOBA = register("goobaa", "goobaa");
    public static final Font DONUT_ICON = register("donut_icon", "donut_icon");
    public static final Font INTER_SEMIBOLD = register("inter_semibold", "inter_semibold");
    public static final Font SF_REGULAR = register("sf_regular", "sf_regular");
    public static final Font CATEGORY_ICONS = register("category", "category");
    public static final Font ICONS = register("icons", "icons");
    public static final Font GUI_ICONS = register("icongui", "icongui");
    public static final Font SF_MEDIUM = register("sf_medium", "sf_medium");
    public static final Font MENU = register("menu_gui", "menu_gui");
    public static final Font SF_BOLD = register("sf_bold", "sf_bold");
    public static final Font ALPHA = register("alpha", "alpha");
    public static final Font DEFAULT = SF_MEDIUM;

    public static Map<String, String> fontResources() {
        return FONT_RESOURCES;
    }

    private Fonts() {}

    private static Font register(String text, String textValue) {
        FONT_RESOURCES.put(text, textValue);
        return new Font(text);
    }
}
