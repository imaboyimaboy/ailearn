package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Item;

@Environment(EnvType.CLIENT)
public final class ItemUseScheduler implements MinecraftAccess {

    private ItemUseScheduler() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    private static void runIfPresent(Runnable runnable) {
        if (runnable != null) {
            runnable.run();
        }
    }

    private static boolean isItemInSlot(Item item, int i) {
        return client.player.getInventory().getStack(i).getItem().equals(item);
    }

    private static void restoreMovementKeys(boolean flag) {
        KeyBinding[] akeybinding =
                new KeyBinding[] {
                    client.options.forwardKey,
                    client.options.backKey,
                    client.options.leftKey,
                    client.options.rightKey,
                    client.options.jumpKey,
                    client.options.sprintKey
                };
        client.getWindow().getHandle();

        for (KeyBinding keybinding : akeybinding) {
            boolean flag1;
            flag1 =
                    (flag
                            && InputUtil.isKeyPressed(
                                    client.getWindow(), keybinding.getDefaultKey().getCode()));

            keybinding.setPressed(flag1);
        }
    }

    private static void resumeMovement() {
        restoreMovementKeys(true);
    }

    private static void restorePhysicalKeyState() {
        restoreMovementKeys(true);
    }

    private static void runWithMovementPaused(Runnable runnable, long l) {
        try {
            Thread.sleep((30L));
            client.execute(
                    () -> {
                        if (runnable != null) {
                            runnable.run();
                        }
                    });
            Thread.sleep(l);
            client.execute(() -> restoreMovementKeys(true));
        } catch (InterruptedException interruptedException) {
            client.execute(() -> restoreMovementKeys(true));
        }
    }
}
