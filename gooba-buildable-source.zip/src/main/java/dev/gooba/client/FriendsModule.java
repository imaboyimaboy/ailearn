package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

@ModuleInfo(
        name = "Friends",
        category = ModuleCategory.CLIENT,
        desc =
                "Manage your friends list. Friends are highlighted in Player ESP, Name Tags, Auto"
                    + " Log and other modules.",
        autoEnabled = true,
        allowDisable = false)
@Environment(EnvType.CLIENT)
public class FriendsModule extends Module {
    public final TextSetting nameSetting = new TextSetting(this, "Name", "");
    public final BooleanSetting removeSetting;
    private final List<BooleanSetting> friendSettings;
    public final BooleanSetting addSetting = new BooleanSetting(this, "Add", false);

    private void refreshFriendSettings() {
        Iterator iterator;
        try {
            Field field = Module.class.getDeclaredField("settings");
            field.setAccessible(true);
            List listx = (List) field.get(this);
            listx.removeAll(this.friendSettings);
            this.friendSettings.clear();
            Set set = Gooba.getInstance().getFriendManager().getFriends();
            iterator = set.iterator();
        } catch (Exception exceptionValue) {
            boolean flag1 = false;
            return;
        }

        while (true) {
            try {
                if (!iterator.hasNext()) {
                    return;
                }
            } catch (Exception exception) {
                return;
            }

            try {
                String text = (String) iterator.next();
                BooleanSetting booleanSetting =
                        new BooleanSetting(this, text, true) {
                            @Override
                            public BooleanSetting setValue(Boolean obool) {
                                if (!obool) {
                                    Gooba.getInstance()
                                            .getFriendManager()
                                            .removeFriend(this.getName());
                                    FriendsModule.this.refreshFriendSettings();
                                }

                                return this;
                            }
                        };
                this.friendSettings.add(booleanSetting);
            } catch (Exception exception3) {
                boolean flag = false;
                return;
            }
        }
    }

    @Override
    protected void onEnable() {
        this.refreshFriendSettings();
    }

    private void removeEnteredFriend() {
        if (this.removeSetting.isOn()) {
            String text = this.nameSetting.getText().trim();
            if (!text.isEmpty()) {
                Gooba.getInstance().getFriendManager().removeFriend(text);
                this.nameSetting.setValue("");
                this.refreshFriendSettings();
            }

            this.removeSetting.setValue(false);
        }
    }

    public FriendsModule() {
        this.removeSetting = new BooleanSetting(this, "Remove", false);
        this.friendSettings = new ArrayList<>();
        this.addSetting.onChange(this::addEnteredFriend);
        this.removeSetting.onChange(this::removeEnteredFriend);
    }

    private void addEnteredFriend() {
        if (this.addSetting.isOn()) {
            String text = this.nameSetting.getText().trim();
            if (!text.isEmpty()) {
                Gooba.getInstance().getFriendManager().addFriend(text);
                this.nameSetting.setValue("");
                this.refreshFriendSettings();
            }

            this.addSetting.setValue(false);
        }
    }
}
