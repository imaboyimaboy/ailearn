package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@ModuleInfo(
        name = "Totem Ghost",
        desc = "Displays a fading player ghost when a totem is activated",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class TotemGhostModule extends Module {
    private static final RenderPipeline FILL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "totem_ghost_fill"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    private static final Identifier LARGE_GLOW_TEXTURE =
            Identifier.of("client", "textures/visuals/particles_1.png");
    private static final RenderPipeline GLOW_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_TEX_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "totem_ghost_glow"))
                            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    private static final Identifier SMALL_GLOW_TEXTURE =
            Identifier.of("client", "textures/visuals/particles_2.png");
    public ColorSetting colorSetting;
    private static final RenderLayer SMALL_GLOW_LAYER =
            RenderLayer.of(
                    "totem_ghost_glow_small",
                    RenderSetup.builder(TotemGhostModule.GLOW_PIPELINE)
                            .texture("Sampler0", TotemGhostModule.SMALL_GLOW_TEXTURE)
                            .translucent()
                            .expectedBufferSize(1024)
                            .build());
    private static final RenderLayer FILL_LAYER =
            RenderLayer.of(
                    "totem_ghost_fill",
                    RenderSetup.builder(FILL_PIPELINE)
                            .translucent()
                            .expectedBufferSize(4096)
                            .build());
    private static final int[][] FACE_INDICES =
            new int[][] {
                {0, 1, 3, 2}, {4, 5, 7, 6}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 2, 6, 4}, {1, 3, 7, 5}
            };
    private static final RenderPipeline LINE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "totem_ghost_lines"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.DEBUG_LINES)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    private static final RenderLayer LARGE_GLOW_LAYER =
            RenderLayer.of(
                    "totem_ghost_glow_big",
                    RenderSetup.builder(GLOW_PIPELINE)
                            .texture("Sampler0", LARGE_GLOW_TEXTURE)
                            .translucent()
                            .expectedBufferSize(1024)
                            .build());
    private static final int[][] EDGE_INDICES =
            new int[][] {
                {0, 1}, {1, 3}, {3, 2}, {2, 0}, {4, 5}, {5, 7}, {7, 6}, {6, 4}, {0, 4}, {1, 5},
                {2, 6}, {3, 7}
            };
    private static final float[][] PART_BOUNDS =
            new float[][] {
                {-0.25F, 1.5F, -0.25F, 0.25F, 2.0F, 0.25F},
                {-0.25F, 0.75F, -0.125F, 0.25F, 1.5F, 0.125F},
                {0.25F, 0.75F, -0.125F, 0.5F, 1.5F, 0.125F},
                {-0.5F, 0.75F, -0.125F, -0.25F, 1.5F, 0.125F},
                {0.0F, 0.0F, -0.125F, 0.25F, 0.75F, 0.125F},
                {-0.25F, 0.0F, -0.125F, 0.0F, 0.75F, 0.125F}
            };
    private final List<TotemGhostModule.Ghost> ghosts;
    public ModeSetting colorModeSetting =
            new ModeSetting(this, "Color Mode", new String[] {"Theme", "Custom"});

    public SliderSetting durationSetting;
    private static final RenderLayer LINE_LAYER =
            RenderLayer.of(
                    "totem_ghost_lines",
                    RenderSetup.builder(LINE_PIPELINE).expectedBufferSize(4096).build());

    public SliderSetting riseHeightSetting;
    private static final float[][] PART_PIVOTS =
            new float[][] {
                {0.0F, 1.5F, 0.0F},
                {0.0F, 0.75F, 0.0F},
                {0.375F, 1.4F, 0.0F},
                {-0.375F, 1.4F, 0.0F},
                {0.125F, 0.75F, 0.0F},
                {-0.125F, 0.75F, 0.0F}
            };
    private final BufferAllocator bufferAllocator;

    public int ghostColor() {
        return this.colorModeSetting.isSelected("Theme")
                ? ColorUtils.hudAccent()
                : this.colorSetting.getColor();
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.ghosts.clear();
    }

    private static void drawGlowQuad(
            VertexConsumer vertexconsumer, Matrix4f matrix4f, int i, int j, int k, int l, float f) {
        if (l > 0) {
            vertexconsumer
                    .vertex(matrix4f, -f, -f, 0.0F)
                    .color(i, j, k, l)
                    .texture(0.0F, 1.0F)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(15728880)
                    .normal(0.0F, 0.0F, 1.0F);
            vertexconsumer
                    .vertex(matrix4f, f, -f, 0.0F)
                    .color(i, j, k, l)
                    .texture(1.0F, 1.0F)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(15728880)
                    .normal(0.0F, 0.0F, 1.0F);
            vertexconsumer
                    .vertex(matrix4f, f, f, 0.0F)
                    .color(i, j, k, l)
                    .texture(1.0F, 0.0F)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(15728880)
                    .normal(0.0F, 0.0F, 1.0F);
            vertexconsumer
                    .vertex(matrix4f, -f, f, 0.0F)
                    .color(i, j, k, l)
                    .texture(0.0F, 0.0F)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(15728880)
                    .normal(0.0F, 0.0F, 1.0F);
        }
    }

    private static void drawPartFaces(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            float[] afloat,
            int i,
            int j,
            int k,
            int l) {
        for (int[] aint : FACE_INDICES) {
            for (int i11 : aint) {
                vertexconsumer
                        .vertex(
                                matrix4f,
                                cornerCoordinate(afloat, i11, 0),
                                cornerCoordinate(afloat, i11, 1),
                                cornerCoordinate(afloat, i11, 2))
                        .color(i, j, k, l);
            }
        }
    }

    private static void drawPartEdges(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            float[] afloat,
            int i,
            int j,
            int k,
            int l) {
        for (int[] aint : EDGE_INDICES) {
            vertexconsumer
                    .vertex(
                            matrix4f,
                            cornerCoordinate(afloat, aint[0], 0),
                            cornerCoordinate(afloat, aint[0], 1),
                            cornerCoordinate(afloat, aint[0], 2))
                    .color(i, j, k, l);
            vertexconsumer
                    .vertex(
                            matrix4f,
                            cornerCoordinate(afloat, aint[1], 0),
                            cornerCoordinate(afloat, aint[1], 1),
                            cornerCoordinate(afloat, aint[1], 2))
                    .color(i, j, k, l);
        }
    }

    @Override
    public void toggle() {
        super.toggle();
        this.ghosts.clear();
    }

    public TotemGhostModule() {
        this.colorSetting =
                new ColorSetting(this, "Color", -16711681)
                        .visibleWhen(() -> this.colorModeSetting.isSelected("Custom"));
        this.riseHeightSetting = new SliderSetting(this, "Rise Height", 2.0F, 0.5F, 4.0F, 0.1F);
        this.durationSetting = new SliderSetting(this, "Duration", 2.0F, 1.0F, 4.0F, 0.1F);
        this.ghosts = new ArrayList<>();
        this.bufferAllocator = new BufferAllocator(16384);
    }

    private static float cornerCoordinate(float[] afloat, int i, int j) {
        return (i >> j & 1) == 0 ? afloat[j] : afloat[j + 3];
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (!this.ghosts.isEmpty() && client.player != null && client.world != null) {
            long nowMillis = System.currentTimeMillis();
            long j = (long) (this.durationSetting.getFloat() * 1000.0F);
            float f = this.riseHeightSetting.getFloat();
            int k = this.ghostColor();
            int l = k >> 16 & 0xFF;
            int i1 = k >> 8 & 0xFF;
            int j1 = k & 0xFF;
            MatrixStack matrixstack = render3DEvent.getMatrixStack();
            Vec3d vec3d = client.gameRenderer.getCamera().getCameraPos();
            Iterator iterator = this.ghosts.iterator();

            while (iterator.hasNext()) {
                TotemGhostModule.Ghost ghost = (TotemGhostModule.Ghost) iterator.next();
                float f1 = (float) (nowMillis - ghost.createdAtMillis) / (float) j;
                if (f1 >= 1.0F) {
                    iterator.remove();
                } else {
                    float f2 = 1.0F - (1.0F - f1) * (1.0F - f1) * (1.0F - f1);
                    float f3 = Math.min(f1 * 8.0F, 1.0F);
                    float f4 = f1 > 0.55F ? 1.0F - (f1 - 0.55F) / 0.45F : 1.0F;
                    ghost.opacity = f3 * f4;
                    double d0 = ghost.x - vec3d.x;
                    double d1 = ghost.y - vec3d.y + (double) (f2 * f);
                    double d2 = ghost.z - vec3d.z;
                    matrixstack.push();
                    matrixstack.translate(d0, d1, d2);
                    matrixstack.multiply(
                            RotationAxis.POSITIVE_Y.rotationDegrees(-ghost.bodyYaw + f1 * 40.0F));

                    for (int k1 = 0; k1 < 6; k1++) {
                        float partAngle = ghost.partAngles[k1];
                        float f6 = k1 == 0 ? ghost.headYaw : 0.0F;
                        if (partAngle == 0.0F && f6 == 0.0F) {
                            ghost.partTransforms[k1].set(matrixstack.peek().getPositionMatrix());
                        } else {
                            float[] afloat = PART_PIVOTS[k1];
                            matrixstack.push();
                            matrixstack.translate(afloat[0], afloat[1], afloat[2]);
                            if (f6 != 0.0F) {
                                matrixstack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-f6));
                            }

                            if (partAngle != 0.0F) {
                                matrixstack.multiply(
                                        RotationAxis.POSITIVE_X.rotationDegrees(partAngle));
                            }

                            matrixstack.translate(-afloat[0], -afloat[1], -afloat[2]);
                            ghost.partTransforms[k1].set(matrixstack.peek().getPositionMatrix());
                            matrixstack.pop();
                        }
                    }

                    matrixstack.pop();
                    matrixstack.push();
                    matrixstack.translate(d0, d1 + 1.1, d2);
                    matrixstack.multiply(client.gameRenderer.getCamera().getRotation());
                    ghost.transform.set(matrixstack.peek().getPositionMatrix());
                    matrixstack.pop();
                }
            }

            if (!this.ghosts.isEmpty()) {
                Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);
                VertexConsumer vertexconsumer = immediate.getBuffer(FILL_LAYER);

                for (TotemGhostModule.Ghost ghostValue : this.ghosts) {
                    int l1 = (int) (ghostValue.opacity * 0.25F * 255.0F);
                    if (l1 > 0) {
                        for (int j2 = 0; j2 < 6; j2++) {
                            drawPartFaces(
                                    vertexconsumer,
                                    ghostValue.partTransforms[j2],
                                    PART_BOUNDS[j2],
                                    l,
                                    i1,
                                    j1,
                                    l1);
                        }
                    }
                }

                vertexconsumer = immediate.getBuffer(LINE_LAYER);

                for (TotemGhostModule.Ghost ghost2 : this.ghosts) {
                    int i2 = (int) (ghost2.opacity * 0.45F * 255.0F);
                    if (i2 > 0) {
                        for (int k2 = 0; k2 < 6; k2++) {
                            drawPartEdges(
                                    vertexconsumer,
                                    ghost2.partTransforms[k2],
                                    PART_BOUNDS[k2],
                                    l,
                                    i1,
                                    j1,
                                    i2);
                        }
                    }
                }

                vertexconsumer = immediate.getBuffer(LARGE_GLOW_LAYER);

                for (TotemGhostModule.Ghost ghost3 : this.ghosts) {
                    drawGlowQuad(
                            vertexconsumer,
                            ghost3.transform,
                            l,
                            i1,
                            j1,
                            (int) (110.0F * ghost3.opacity),
                            1.5F);
                }

                vertexconsumer = immediate.getBuffer(SMALL_GLOW_LAYER);

                for (TotemGhostModule.Ghost ghost4 : this.ghosts) {
                    drawGlowQuad(
                            vertexconsumer,
                            ghost4.transform,
                            l,
                            i1,
                            j1,
                            (int) (160.0F * ghost4.opacity),
                            0.7F);
                }

                immediate.draw();
            }
        }
    }

    public void spawnGhost(Entity entity) {
        if (this.isEnabled() && entity != null) {
            TotemGhostModule.Ghost ghost =
                    new TotemGhostModule.Ghost(entity.getEntityPos(), entity.getYaw());
            if (entity instanceof LivingEntity livingentity) {
                ghost.bodyYaw = livingentity.getBodyYaw();
                ghost.headYaw =
                        MathHelper.clamp(
                                MathHelper.wrapDegrees(
                                        livingentity.getHeadYaw() - livingentity.getBodyYaw()),
                                -75.0F,
                                75.0F);
                float animationProgress = livingentity.limbAnimator.getAnimationProgress();
                float f1 = Math.min(livingentity.limbAnimator.getSpeed(), 1.0F);
                ghost.partAngles[0] = livingentity.getPitch();
                ghost.partAngles[2] =
                        (float)
                                Math.toDegrees(
                                        (double)
                                                (MathHelper.cos(
                                                                (double)
                                                                        (animationProgress * 0.6662F
                                                                                + (float) Math.PI))
                                                        * 2.0F
                                                        * f1
                                                        * 0.5F));
                ghost.partAngles[3] =
                        (float)
                                Math.toDegrees(
                                        (double)
                                                (MathHelper.cos(
                                                                (double)
                                                                        (animationProgress
                                                                                * 0.6662F))
                                                        * 2.0F
                                                        * f1
                                                        * 0.5F));
                ghost.partAngles[4] =
                        (float)
                                Math.toDegrees(
                                        (double)
                                                (MathHelper.cos(
                                                                (double)
                                                                        (animationProgress
                                                                                * 0.6662F))
                                                        * 1.4F
                                                        * f1));
                ghost.partAngles[5] =
                        (float)
                                Math.toDegrees(
                                        (double)
                                                (MathHelper.cos(
                                                                (double)
                                                                        (animationProgress * 0.6662F
                                                                                + (float) Math.PI))
                                                        * 1.4F
                                                        * f1));
            } else {
                ghost.bodyYaw = entity.getYaw();
            }

            this.ghosts.add(ghost);
        }
    }

    @EventHandler
    public void onPacket(PacketEvent packetEvent) {
        if (packetEvent.getPacket() instanceof EntityStatusS2CPacket entitystatuss2cpacket) {
            if (entitystatuss2cpacket.getStatus() == 35) {
                if (client.world != null) {
                    Entity entity = entitystatuss2cpacket.getEntity(client.world);
                    if (entity != null) {
                        this.spawnGhost(entity);
                    }
                }
            }
        }
    }

    @Environment(EnvType.CLIENT)
    private static class Ghost {
        final Matrix4f[] partTransforms;
        float headYaw;
        final double y;
        final long createdAtMillis;
        float opacity;
        final float[] partAngles = new float[6];
        final double x;
        final Matrix4f transform;
        final double z;
        float bodyYaw;

        Ghost(Vec3d vec3d, float bodyYawValue) {
            this.partTransforms = new Matrix4f[6];
            this.transform = new Matrix4f();
            this.x = vec3d.x;
            this.y = vec3d.y;
            this.z = vec3d.z;
            this.bodyYaw = bodyYawValue;
            this.createdAtMillis = System.currentTimeMillis();

            for (int i = 0; i < 6; i++) {
                this.partTransforms[i] = new Matrix4f();
            }
        }
    }
}
