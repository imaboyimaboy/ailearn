package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "No Render",
        desc = "Hides selected overlays, fog, effects, camera motion, and HUD elements",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class NoRenderModule extends Module {
    public BooleanSetting removeNegativeEffectsSetting;
    public BooleanSetting removeTotemAnimationSetting;
    public BooleanSetting cameraClipSetting;
    public BooleanSetting removeScoreboardSetting;
    public BooleanSetting removeBossBarSetting;
    public BooleanSetting removeFireOverlaySetting =
            new BooleanSetting(this, "Remove Fire Overlay", true);
    public BooleanSetting removeLavaFogSetting = new BooleanSetting(this, "Remove lava fog", true);
    public BooleanSetting removeCameraShakeSetting;

    public static NoRenderModule getInstance() {
        return (NoRenderModule) ModuleLookup.getModule(NoRenderModule.class);
    }

    public NoRenderModule() {
        this.removeNegativeEffectsSetting =
                new BooleanSetting(this, "Remove Negative Effects", true);
        this.removeScoreboardSetting = new BooleanSetting(this, "Remove Scoreboard", false);
        this.removeBossBarSetting = new BooleanSetting(this, "Remove Boss Bar", false);
        this.cameraClipSetting = new BooleanSetting(this, "Camera Clip", false);
        this.removeTotemAnimationSetting = new BooleanSetting(this, "Remove Totem Animation", true);
        this.removeCameraShakeSetting = new BooleanSetting(this, "Remove Camera Shake", true);
    }
}
