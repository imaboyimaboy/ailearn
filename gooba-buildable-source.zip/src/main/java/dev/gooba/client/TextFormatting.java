package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Style;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Environment(EnvType.CLIENT)
public final class TextFormatting {
    private static final HashMap<String, String> aliases = new HashMap<>();

    public static final Pattern COLOR_TAG_PATTERN =
            Pattern.compile(
                    "\\$\\{(rgba|rgb)\\((\\d{1,3}),(\\d{1,3}),(\\d{1,3})(?:,(\\d{1,3}))?\\)}|\\$\\{reset}",
                    2);

    static {
        aliases.put("${black}", Formatting.BLACK.toString());
        aliases.put("${dark_blue}", Formatting.DARK_BLUE.toString());
        aliases.put("${dark_green}", Formatting.DARK_GREEN.toString());
        aliases.put("${dark_aqua}", Formatting.DARK_AQUA.toString());
        aliases.put("${dark_red}", Formatting.DARK_RED.toString());
        aliases.put("${dark_purple}", Formatting.DARK_PURPLE.toString());
        aliases.put("${orange}", Formatting.GOLD.toString());
        aliases.put("${gray}", Formatting.GRAY.toString());
        aliases.put("${dark_gray}", Formatting.DARK_GRAY.toString());
        aliases.put("${blue}", Formatting.BLUE.toString());
        aliases.put("${green}", Formatting.GREEN.toString());
        aliases.put("${aqua}", Formatting.AQUA.toString());
        aliases.put("${red}", Formatting.RED.toString());
        aliases.put("${purple}", Formatting.LIGHT_PURPLE.toString());
        aliases.put("${yellow}", Formatting.YELLOW.toString());
        aliases.put("${avdeeeeeva}", Formatting.WHITE.toString());
        aliases.put("${bold}", Formatting.BOLD.toString());
        aliases.put("${reset}", Formatting.RESET.toString());
    }

    public static String expandAliases(String string) {
        if (string == null || string.isEmpty()) {
            return string;
        } else if (string.indexOf("${") < 0) {
            return string;
        } else {
            String stringValue = string;

            for (Entry entry : aliases.entrySet()) {
                stringValue =
                        stringValue.replace(
                                (CharSequence) entry.getKey(), (CharSequence) entry.getValue());
            }

            return stringValue;
        }
    }

    public static String rgbaTag(int i, int j, int k, int l) {
        return "${rgba(" + i + "," + j + "," + k + "," + l + ")}";
    }

    public static String colorTag(int color) {
        return rgbaTag(
                ColorUtils.red(color),
                ColorUtils.green(color),
                ColorUtils.blue(color),
                ColorUtils.alpha(color));
    }

    public static TextFormatting.ColorTag parseColorTag(String text, int i, int color) {

        if (text == null || i < 0 || i >= text.length() - 1) {
            return null;
        } else if (text.charAt(i) == '$' && text.charAt(i + 1) == '{') {
            Matcher matcher = COLOR_TAG_PATTERN.matcher(text);
            if (matcher.find(i) && matcher.start() == i) {
                if (matcher.group().equalsIgnoreCase(resetTag())) {
                    return new TextFormatting.ColorTag(color, matcher.end() - i);
                } else {
                    String textValue = matcher.group(1).toLowerCase();
                    int red = clampChannel(Integer.parseInt(matcher.group(2)));
                    int green = clampChannel(Integer.parseInt(matcher.group(3)));
                    int blue = clampChannel(Integer.parseInt(matcher.group(4)));
                    int alpha =
                            textValue.equals(rgbaName()) && matcher.group(5) != null
                                    ? clampChannel(Integer.parseInt(matcher.group(5)))
                                    : ColorUtils.alpha(color);
                    return new TextFormatting.ColorTag(
                            ColorUtils.cachedRgba(red, green, blue, alpha), matcher.end() - i);
                }
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    private TextFormatting() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static String stripColorTags(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        } else {
            return text.indexOf("${") < 0 ? text : COLOR_TAG_PATTERN.matcher(text).replaceAll("");
        }
    }

    public static String rgbaName() {
        return "rgba";
    }

    private static int clampChannel(int i) {
        return Math.max(0, Math.min(255, i));
    }

    private static Style withColor(int i, Style style) {
        return style.withColor(i);
    }

    public static String resetTag() {
        return "${reset}";
    }

    public static String plainText(String string) {
        return string != null && !string.isEmpty() ? stripColorTags(expandAliases(string)) : string;
    }

    @Environment(EnvType.CLIENT)
    public static record ColorTag(int color, int length) {
        static {
        }
    }
}
