package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ElapsedTimer {
    private long lastResetMillis;

    public void reset() {
        this.lastResetMillis = System.currentTimeMillis();
    }

    public boolean hasElapsed(double durationMillis) {
        return (double) System.currentTimeMillis() - durationMillis
                >= (double) this.lastResetMillis;
    }

    public ElapsedTimer() {
        this.reset();
    }
}
