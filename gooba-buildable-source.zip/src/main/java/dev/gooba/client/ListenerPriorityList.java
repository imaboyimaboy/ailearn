package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.List;

@Environment(EnvType.CLIENT)
public class ListenerPriorityList {

    private static int binarySearch(List<EventListener> list, EventListener eventListener) {
        int i = 0;
        int j = list.size() - 1;

        while (i <= j) {
            int k = i + (j - i) / 2;
            EventListener eventListener2 = (EventListener) list.get(k);
            int l = Integer.compare(eventListener.getPriority(), eventListener2.getPriority());
            if (l == 0) {
                return k;
            }

            if (l < 0) {
                i = k + 1;
            } else {
                j = k - 1;
            }
        }

        return i;
    }

    private static int linearSearch(List<EventListener> list, EventListener eventListener) {
        int count = list.size();

        for (int j = 0; j < count; j++) {
            if (eventListener.getPriority() > ((EventListener) list.get(j)).getPriority()) {
                return j;
            }
        }

        return count;
    }

    public static void insert(List<EventListener> list, EventListener eventListener) {
        int i =
                list.size() < 8
                        ? linearSearch(list, eventListener)
                        : binarySearch(list, eventListener);
        list.add(i, eventListener);
    }

    public static EventListener remove(List<EventListener> list, EventListener eventListener) {
        int priority = eventListener.getPriority();

        for (int j = 0; j < list.size(); j++) {
            EventListener eventListener2 = (EventListener) list.get(j);
            if (eventListener2 == eventListener) {
                return (EventListener) list.remove(j);
            }

            if (eventListener2.getPriority() < priority) {
                break;
            }
        }

        return null;
    }

    public static boolean contains(List<EventListener> list, EventListener eventListener) {
        int priority = eventListener.getPriority();

        for (EventListener eventListener2 : list) {
            if (eventListener2 == eventListener) {
                return true;
            }

            if (eventListener2.getPriority() < priority) {
                break;
            }
        }

        return false;
    }
}
