package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface EventBusAccess {
    void subscribe(Object object);

    void unsubscribe(EventListener eventListener);

    void subscribe(Class<?> oclass);

    boolean isListening(Class<?> oclass);

    <T extends Cancellable> T post(T t);

    void unsubscribe(Class<?> oclass);

    <T> T post(T t);

    void unsubscribe(Object object);

    void subscribe(EventListener eventListener);

    void registerLambdaFactory(String text, LambdaListener.Factory factory);
}
