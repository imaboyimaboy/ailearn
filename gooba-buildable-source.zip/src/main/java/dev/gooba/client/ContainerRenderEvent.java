package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

@Environment(EnvType.CLIENT)
public class ContainerRenderEvent extends Event {
    private int mouseX;
    private int mouseY;
    private HandledScreen<?> screen;
    private DrawContext drawContext;

    public int getMouseY() {
        return this.mouseY;
    }

    public DrawContext getDrawContext() {
        return this.drawContext;
    }

    public HandledScreen<?> getScreen() {
        return this.screen;
    }

    public int getMouseX() {
        return this.mouseX;
    }

    public ContainerRenderEvent(
            DrawContext drawcontext,
            HandledScreen<?> handledscreen,
            int mouseXValue,
            int mouseYValue) {
        this.drawContext = drawcontext;
        this.screen = handledscreen;
        this.mouseX = mouseXValue;
        this.mouseY = mouseYValue;
    }
}
