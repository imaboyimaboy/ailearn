package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.List;

@ModuleInfo(
        name = "Player Indicator",
        category = ModuleCategory.RENDER,
        desc = "Displays directional arrows pointing toward other players")
@Environment(EnvType.CLIENT)
public class PlayerIndicatorModule extends Module {
    private final EasingAnimation inventoryAnimation;
    public SliderSetting sizeSetting;

    public SliderSetting crosshairRadiusSetting;
    public BooleanSetting ignoreUnarmoredPlayersSetting =
            new BooleanSetting(this, "Ignore Unarmored Players", false);
    private static final Identifier ARROW_TEXTURE = Identifier.of("client", "textures/arrow.png");

    private static boolean isArmored(AbstractClientPlayerEntity abstractclientplayerentity) {
        return !abstractclientplayerentity.getEquippedStack(EquipmentSlot.HEAD).isEmpty()
                || !abstractclientplayerentity.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
                || !abstractclientplayerentity.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
                || !abstractclientplayerentity.getEquippedStack(EquipmentSlot.FEET).isEmpty();
    }

    @EventHandler(priority = -500)
    public void onRender2D(Render2DEvent render2DEvent) {
        if (client.player != null && client.world != null) {
            if (!client.options.hudHidden
                    && client.options.getPerspective().equals(Perspective.FIRST_PERSON)) {
                List list =
                        client.world.getPlayers().stream()
                                .filter(
                                        abstractclientplayerentityx ->
                                                abstractclientplayerentityx != client.player)
                                .filter(
                                        abstractclientplayerentityx ->
                                                !this.ignoreUnarmoredPlayersSetting.isOn()
                                                        || isArmored(abstractclientplayerentityx))
                                .toList();
                if (!list.isEmpty()) {
                    this.inventoryAnimation.update();
                    float f = 2.0F;
                    float scaleFactor = (float) client.getWindow().getScaleFactor();
                    float f2 = f / scaleFactor;
                    int i = (int) ((float) client.getWindow().getScaledWidth() / f2);
                    int j = (int) ((float) client.getWindow().getScaledHeight() / f2);
                    float partialTicks = render2DEvent.getPartialTicks();
                    float f4 = (float) i / 2.0F;
                    float f5 = (float) j / 2.0F;
                    float f6 = this.sizeSetting.getFloat() / 4.0F;
                    float f7 =
                            f5
                                    - this.crosshairRadiusSetting.getFloat()
                                    - this.crosshairRadiusSetting.getFloat()
                                            / 4.0F
                                            * this.inventoryAnimation.getFloatValue();
                    float f8 = f7 + f6 / 2.0F - f5;
                    float f9 =
                            Math.abs(
                                    MathHelper.clamp(
                                            client.gameRenderer.getCamera().getPitch(),
                                            -90.0F,
                                            90.0F));
                    float f10 = MathHelper.lerp(f9 / 90.0F, 0.45F, 1.0F);

                    for (AbstractClientPlayerEntity abstractclientplayerentity :
                            (Iterable<AbstractClientPlayerEntity>) (Iterable) list) {
                        int k =
                                Gooba.getInstance()
                                                .getFriendManager()
                                                .isFriend(
                                                        abstractclientplayerentity
                                                                .getName()
                                                                .getString())
                                        ? ColorUtils.GREEN
                                        : ColorUtils.animatedAccent(1);
                        float f11 =
                                bearingTo(abstractclientplayerentity, partialTicks)
                                        - client.gameRenderer.getCamera().getYaw();
                        float f12 = (float) Math.toRadians((double) f11);
                        float f13 = (float) Math.sin((double) f12);
                        float f14 = (float) Math.cos((double) f12);
                        float f15 = f4 - f8 * f13;
                        float f16 = f5 + f8 * f14 * f10;
                        float f17 =
                                (float)
                                        Math.toDegrees(
                                                Math.atan2((double) f13, (double) (f14 * f10)));
                        float f18 =
                                f6
                                        * (float)
                                                Math.sqrt(
                                                        (double)
                                                                (f14 * f14
                                                                        + f10 * f10 * f13 * f13));
                        float f19 =
                                f6
                                        * (float)
                                                Math.sqrt(
                                                        (double)
                                                                (f13 * f13
                                                                        + f10 * f10 * f14 * f14));
                        Gooba.getInstance()
                                .getHudManager()
                                .getTextureBatchRenderer()
                                .drawGlow(
                                        ARROW_TEXTURE,
                                        f15 - f18 / 2.0F,
                                        f16 - f19 / 2.0F,
                                        f18,
                                        f19,
                                        0.0F,
                                        0.0F,
                                        1.0F,
                                        1.0F,
                                        new int[] {k, k, k, k},
                                        new float[] {0.0F, 0.0F, 0.0F, 0.0F},
                                        1.0F,
                                        f17);
                    }
                }
            }
        }
    }

    public PlayerIndicatorModule() {
        this.sizeSetting = new SliderSetting(this, "Size", 30.0F, 12.0F, 80.0F, 1.0F);
        this.crosshairRadiusSetting =
                new SliderSetting(this, "Crosshair Radius", 50.0F, 20.0F, 80.0F, 1.0F);
        this.inventoryAnimation = new EasingAnimation();
    }

    private static float bearingTo(Entity entity, float f) {
        double d0 =
                (double)
                        (MathUtils.lerp(entity.lastRenderX, entity.getX(), (double) f)
                                - MathUtils.lerp(
                                        client.player.lastRenderX,
                                        client.player.getX(),
                                        (double) f));
        double d1 =
                (double)
                        (MathUtils.lerp(entity.lastRenderZ, entity.getZ(), (double) f)
                                - MathUtils.lerp(
                                        client.player.lastRenderZ,
                                        client.player.getZ(),
                                        (double) f));
        return (float) (-(Math.atan2(d0, d1) * (180.0 / Math.PI)));
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null) {
            this.inventoryAnimation.animateTo(
                    client.currentScreen instanceof InventoryScreen ? 1.0 : 0.0,
                    0.1F,
                    Easings.OUT_SINE);
        }
    }
}
