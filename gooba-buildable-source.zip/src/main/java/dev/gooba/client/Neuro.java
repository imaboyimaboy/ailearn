package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.List;
import java.util.stream.Collectors;

@Environment(EnvType.CLIENT)
public class Neuro extends Command {

    private static final List<String> SUBCOMMANDS =
            List.of("create", "select", "train", "stop", "list", "delete", "info");

    @Override
    public List suggest(String text) {
        return SUBCOMMANDS.stream()
                .filter(textValue -> textValue.startsWith(text.toLowerCase()))
                .collect(Collectors.toList());
    }

    public Neuro() {
        super(
                "neuro",
                ".neuro <create|select|train|stop|list|delete|info> [name]",
                "Neuro-rotation: models and training");
    }

    private void showUsage() {
        ChatMessages.send(
                "§7.neuro §fcreate §7<name> §8| §fselect §7<name> §8| §ftrain §8| §fstop §8| §flist"
                    + " §8| §finfo §8| §fdelete §7<name>");
        ChatMessages.send(
                "§8Training: §7.neuro create my §8→ §7.neuro train §8→ aim for the dummy §8→"
                    + " §7.neuro stop");
    }

    @Override
    public void execute(String[] astring) throws CloneNotSupportedException {
        if (astring.length == 0) {
            this.showUsage();
        } else {
            RotationTrainer rotationTrainer2 = RotationTrainer.getInstance();
            String text = astring[0].toLowerCase();
            switch (text) {
                case "create":
                    if (astring.length < 2) {
                        ChatMessages.send("§7Usage: §f.neuro create <name>");
                        return;
                    }

                    if (rotationTrainer2.createModel(astring[1])) {
                        String textValue = astring[1];
                        ChatMessages.send(
                                "§a[Neuro] §7Model §f" + textValue + "§7 created and selected");
                    } else {
                        String text2 = astring[1];
                        ChatMessages.send("§cModel §f" + text2 + "§c already exists");
                    }
                    break;
                case "select":
                    if (astring.length < 2) {
                        ChatMessages.send("§7Usage: §f.neuro select <name>");
                        return;
                    }

                    if (rotationTrainer2.selectModel(astring[1])) {
                        String text3 = astring[1];
                        ChatMessages.send("§a[Neuro] §7Model selected §f" + text3);
                    } else {
                        String text4 = astring[1];
                        ChatMessages.send("§cModel §f" + text4 + "§c not found");
                    }
                    break;
                case "train":
                    rotationTrainer2.startTraining();
                    break;
                case "stop":
                    rotationTrainer2.finishTraining();
                    break;
                case "delete":
                    if (astring.length < 2) {
                        ChatMessages.send("§7Usage: §f.neuro delete <name>");
                        return;
                    }

                    if (rotationTrainer2.deleteModel(astring[1])) {
                        String text5 = astring[1];
                        ChatMessages.send("§c[Neuro] §7Model §f" + text5 + "§7 deleted");
                    } else {
                        String text6 = astring[1];
                        ChatMessages.send("§cModel §f" + text6 + "§c not found");
                    }
                    break;
                case "list":
                    if (rotationTrainer2.getModels().isEmpty()) {
                        ChatMessages.send("§7No models. §f.neuro create <name>");
                        return;
                    }

                    int count = rotationTrainer2.getModels().size();
                    ChatMessages.send("§7Models §8[" + count + "§8]§7:");
                    rotationTrainer2
                            .getModels()
                            .forEach(
                                    ctrx -> {
                                        if (ctrx == rotationTrainer2.getCurrentModel()) {
                                            int trainingSampleCount = ctrx.trainingSampleCount;
                                            String s3x = ctrx.name;
                                            String s2x = "§a";
                                            ChatMessages.send(
                                                    s2x + s3x + " §7(" + trainingSampleCount + ")");
                                        } else {
                                            int ix = ctrx.trainingSampleCount;
                                            String s1x = ctrx.name;
                                            String sx = "§f";
                                            ChatMessages.send(sx + s1x + " §7(" + ix + ")");
                                        }
                                    });
                    break;
                case "info":
                    RotationModelStore rotationModelStore2 = rotationTrainer2.getCurrentModel();
                    if (rotationModelStore2 == null) {
                        ChatMessages.send("§7Model not selected");
                        return;
                    }

                    ChatMessages.send(
                            String.format(
                                    "§a[Neuro] §f%s§7 - samples: §f%d§7, error: §f%s",
                                    rotationModelStore2.name,
                                    rotationModelStore2.trainingSampleCount,
                                    rotationModelStore2.trainingLoss < 0.0
                                            ? "—"
                                            : String.format(
                                                    "%.4f", rotationModelStore2.trainingLoss)));
                    break;
                default:
                    this.showUsage();
            }
        }
    }
}
