package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public final class FogBlurRenderer {
    private static SimpleFramebuffer depthFramebuffer;
    private static GpuBuffer vertexBuffer;
    private static GpuTextureView colorView;
    private static int width = -1;
    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/fog_blur"))
                            .withVertexShader(Identifier.of("client", "core/fog_blur"))
                            .withFragmentShader(Identifier.of("client", "core/fog_blur"))
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("FogData", UniformType.UNIFORM_BUFFER)
                            .withSampler("DepthTex")
                            .withSampler("MinecraftTex")
                            .withSampler("BlurTex")
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private static KawaseBlur kawaseBlur;
    private static int height = -1;
    private static GpuBuffer uniformBuffer;
    private static GpuTexture colorTexture;
    private static ByteBuffer uniformData;

    private static void resize(int widthValue, int heightValue) {
        if (colorTexture == null || widthValue != width || heightValue != height) {
            if (colorView != null) {
                colorView.close();
                colorView = null;
            }

            if (colorTexture != null) {
                colorTexture.close();
                colorTexture = null;
            }

            depthFramebuffer = null;
            colorTexture =
                    RenderSystem.getDevice()
                            .createTexture(
                                    () -> "client:fog_blur_color",
                                    5,
                                    TextureFormat.RGBA8,
                                    widthValue,
                                    heightValue,
                                    1,
                                    1);
            colorView = RenderSystem.getDevice().createTextureView(colorTexture);
            depthFramebuffer =
                    new SimpleFramebuffer("client_fog_blur_depth", widthValue, heightValue, true);
            width = widthValue;
            height = heightValue;
        }
    }

    private static void writeUniforms(
            float f, float f1, float f2, float f3, boolean flag, int i, int j, int k, int l) {
        uniformData.clear();
        uniformData.putFloat(f).putFloat(f1).putFloat(f2).putFloat(f3);
        uniformData.putFloat(flag ? 1.0F : 0.0F).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
        putColor(uniformData, i);
        putColor(uniformData, j);
        putColor(uniformData, k);
        putColor(uniformData, l);

        while (uniformData.position() < 256) {
            uniformData.put((byte) 0);
        }

        uniformData.flip();
    }

    private static void putColor(ByteBuffer bytebuffer, int i) {
        bytebuffer.putFloat((float) (i >> 16 & 0xFF) / 255.0F);
        bytebuffer.putFloat((float) (i >> 8 & 0xFF) / 255.0F);
        bytebuffer.putFloat((float) (i & 0xFF) / 255.0F);
        bytebuffer.putFloat((float) (i >>> 24 & 0xFF) / 255.0F);
    }

    private static boolean initialize() {
        if (vertexBuffer != null && uniformBuffer != null && uniformData != null) {
            if (kawaseBlur == null) {
                kawaseBlur = new KawaseBlur();
            }

            return true;
        } else {
            try {
                ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
                bytebuffer.putInt(0).flip();
                vertexBuffer =
                        RenderSystem.getDevice()
                                .createBuffer(() -> "client:fog_blur_dummy_vertex", 32, bytebuffer);
                MemoryUtil.memFree(bytebuffer);
                uniformBuffer =
                        RenderSystem.getDevice()
                                .createBuffer(() -> "client:fog_blur_uniform", 136, 256L);
                uniformData = MemoryUtil.memAlloc(256);
                kawaseBlur = new KawaseBlur();
                return true;
            } catch (Exception exception) {
                return false;
            }
        }
    }

    public static boolean render(float f, float f1, boolean flag, int i, int j, int k, int l) {
        if (!initialize()) {
            return false;
        } else {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (minecraftclient != null
                    && minecraftclient.getFramebuffer() != null
                    && minecraftclient.getFramebuffer().getColorAttachment() != null) {
                Framebuffer framebuffer = minecraftclient.getFramebuffer();
                int textureWidth = framebuffer.textureWidth;
                int textureHeight = framebuffer.textureHeight;
                resize(textureWidth, textureHeight);
                if (colorTexture != null
                        && depthFramebuffer != null
                        && framebuffer.getDepthAttachment() != null
                        && depthFramebuffer.getDepthAttachment() != null) {
                    CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
                    commandencoder.copyTextureToTexture(
                            framebuffer.getColorAttachment(),
                            colorTexture,
                            0,
                            0,
                            0,
                            0,
                            0,
                            textureWidth,
                            textureHeight);
                    commandencoder.copyTextureToTexture(
                            framebuffer.getDepthAttachment(),
                            depthFramebuffer.getDepthAttachment(),
                            0,
                            0,
                            0,
                            0,
                            0,
                            textureWidth,
                            textureHeight);
                    GpuTextureView gputextureview = depthFramebuffer.getDepthAttachmentView();
                    if (gputextureview == null) {
                        return false;
                    } else {
                        GpuTextureView gpuTextureViewValue =
                                kawaseBlur.blur(
                                        colorTexture,
                                        colorView,
                                        textureWidth,
                                        textureHeight,
                                        3,
                                        2.5F);
                        if (gpuTextureViewValue == null) {
                            gpuTextureViewValue = colorView;
                        }

                        float f2 =
                                (float)
                                                minecraftclient
                                                        .options
                                                        .getViewDistance()
                                                        .getValue()
                                                        .intValue()
                                        * 16.0F;
                        writeUniforms(0.05F, f2, f, f1, flag, i, j, k, l);
                        GpuBufferSlice gpubufferslice = uniformBuffer.slice(0L, 256L);
                        commandencoder.writeToBuffer(gpubufferslice, uniformData);

                        try {
                            boolean flag1;
                            try (RenderPass renderpass =
                                    commandencoder.createRenderPass(
                                            () -> "client:fog_blur",
                                            framebuffer.getColorAttachmentView(),
                                            OptionalInt.empty())) {
                                renderpass.setPipeline(PIPELINE);
                                renderpass.setVertexBuffer(0, vertexBuffer);
                                renderpass.bindTexture(
                                        "DepthTex",
                                        gputextureview,
                                        RenderSystem.getSamplerCache().get(FilterMode.NEAREST));
                                renderpass.bindTexture(
                                        "MinecraftTex",
                                        colorView,
                                        RenderSystem.getSamplerCache().get(FilterMode.LINEAR));
                                renderpass.bindTexture(
                                        "BlurTex",
                                        gpuTextureViewValue,
                                        RenderSystem.getSamplerCache().get(FilterMode.LINEAR));
                                renderpass.setUniform("FogData", gpubufferslice);
                                renderpass.draw(0, 6);
                                flag1 = true;
                            }

                            return flag1;
                        } catch (Exception exception) {
                            return false;
                        }
                    }
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }

    private FogBlurRenderer() {}
}
