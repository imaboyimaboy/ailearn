package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;

@Environment(EnvType.CLIENT)
public class HandMatrixEvent extends Event {
    private final Arm arm;
    private final Hand hand;
    private final MatrixStack matrix;

    public boolean isRightHand() {
        return this.arm == Arm.RIGHT;
    }

    public Hand getHand() {
        return this.hand;
    }

    public Arm getArm() {
        return this.arm;
    }

    public HandMatrixEvent(MatrixStack matrixstack, Hand hand, Arm arm) {
        this.matrix = matrixstack;
        this.hand = hand;
        this.arm = arm;
    }

    public MatrixStack getMatrix() {
        return this.matrix;
    }
}
