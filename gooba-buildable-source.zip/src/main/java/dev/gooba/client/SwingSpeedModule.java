package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Swing Speed",
        category = ModuleCategory.OTHER,
        desc = "Changes mainhand swing animation speed.")
@Environment(EnvType.CLIENT)
public class SwingSpeedModule extends Module {
    public final SliderSetting speedSetting =
            new SliderSetting(this, "Speed", 6.0F, 0.0F, 20.0F, 1.0F);
    public static SwingSpeedModule instance;

    @EventHandler
    public void onHandSwing(HandSwingEvent handSwingEvent) {
        if (this.swingDuration() <= 0) {
            handSwingEvent.setAnimation(0.0F);
            handSwingEvent.cancel();
        } else {
            handSwingEvent.setAnimation((float) this.swingDuration() / 6.0F);
            handSwingEvent.cancel();
        }
    }

    public int swingDuration() {
        return Math.round(this.speedSetting.getFloat());
    }

    public SwingSpeedModule() {
        instance = this;
    }
}
