package dev.gooba.client;

import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

@FieldOrder({"largeImage", "largeText", "smallImage", "smallText"})
@Environment(EnvType.CLIENT)
public class DiscordAssets extends Structure {
    public byte[] smallImage;
    public byte[] smallText;

    public byte[] largeText;
    public byte[] largeImage = new byte[128];

    public DiscordAssets() {
        this.largeText = new byte[128];
        this.smallImage = new byte[128];
        this.smallText = new byte[128];
    }

    public void setLargeText(String text) {
        copyUtf8(this.largeText, text);
    }

    public void setLargeImage(String text) {
        copyUtf8(this.largeImage, text);
    }

    public void setSmallImage(String text) {
        copyUtf8(this.smallImage, text);
    }

    public void setSmallText(String text) {
        copyUtf8(this.smallText, text);
    }

    private static void copyUtf8(byte[] bArray, String text) {
        if (text == null) {
            text = "";
        }

        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        int var3 = Math.min(bytes.length, bArray.length - 1);
        Arrays.fill(bArray, (byte) 0);
        System.arraycopy(bytes, 0, bArray, 0, var3);
    }
}
