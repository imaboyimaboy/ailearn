package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class DecelerateAnimation extends TimedAnimation {
    public DecelerateAnimation(
            int durationMillisValue, double endValueValue, AnimationDirection animationDirection2) {
        super(durationMillisValue, endValueValue, animationDirection2);
    }

    public DecelerateAnimation(int durationMillisValue, double endValueValue) {
        super(durationMillisValue, endValueValue);
    }

    @Override
    protected double evaluate(double d0) {
        double d1 = d0 / (double) this.durationMillis;
        return d1 < 0.5 ? 2.0 * Math.pow(d1, 2.0) : 1.0 - Math.pow(-2.0 * d1 + 2.0, 2.0) / 2.0;
    }
}
