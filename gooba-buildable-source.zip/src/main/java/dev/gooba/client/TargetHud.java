package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;

@Environment(EnvType.CLIENT)
public class TargetHud implements HudElement {
    private float maxHealth;
    private float absorptionStart;
    private float absorptionTarget;
    private float healthStart;
    private long absorptionStartedMillis;
    private float displayedHealth;
    private long healthStartedMillis;
    private float health;
    private LivingEntity target;
    private final EasingAnimation visibilityAnimation = createAnimation(0.0F);
    private float healthTarget;
    private float displayedAbsorption;
    private float absorption;

    private static EasingAnimation createAnimation(float f) {
        return new EasingAnimation()
                .setCurrentValue((double) f)
                .setStartValue((double) f)
                .setTargetValue((double) f)
                .setDurationMillis(1.0);
    }

    private static float safeHealth(float f) {
        return !Float.isNaN(f) && !(f < 0.0F) ? f : 0.0F;
    }

    private void drawPlayerHead(Identifier identifier, float f, float f1, float f2, int i) {
        float f3 = f2 * 0.3F;
        RenderUtils.Images.drawRoundedRegion(
                identifier, f, f1, f2, f2, 0.125F, 0.125F, 0.25F, 0.25F, i, f3);
        RenderUtils.Images.drawRoundedRegion(
                identifier, f, f1, f2, f2, 0.625F, 0.125F, 0.75F, 0.25F, i, f3);
    }

    @Override
    public void render(PositionSetting positionSetting2, HUDModule hUDModule) {}

    private void drawEquipment(
            Render2DEvent render2DEvent,
            LivingEntity livingentity,
            float f,
            float f1,
            float f2,
            float factor) {
        ItemStack[] aitemstack =
                new ItemStack[] {
                    livingentity.getEquippedStack(EquipmentSlot.HEAD),
                    livingentity.getEquippedStack(EquipmentSlot.CHEST),
                    livingentity.getEquippedStack(EquipmentSlot.LEGS),
                    livingentity.getEquippedStack(EquipmentSlot.FEET),
                    livingentity.getMainHandStack(),
                    livingentity.getOffHandStack()
                };
        float f4 = 8.65F * f2;
        float f5 = f + 4.25F * f2;

        for (ItemStack itemstack : aitemstack) {
            if (!itemstack.isEmpty()) {
                ItemIconRenderer.drawCentered(
                        render2DEvent.getDrawContext(), itemstack, f5, f1, 0.53125F * f2, factor);
            } else {
                float size = 6.0F * f2;
                float width = 8.5F * f2;
                float f8 = f5 - width * 0.5F;
                float f9 = f1 - width * 0.5F;
                Font font = Fonts.GOOBA_ICONS;
                float f10 = Fonts.GOOBA_ICONS.centerTextX("K", f8, width, size);
                float f11 = Fonts.GOOBA_ICONS.centerTextY("K", f9, width, size);
                ColorUtils.multiplyAlpha(-8947072, factor);
                font.drawText("K", f10, f11, size);
            }

            f5 += f4;
        }
    }

    private LivingEntity findTarget() {
        LivingEntity livingentity = AttackAuraModule.target;
        if (Gooba.getInstance().getModuleRegistry().findModule(AttackAuraModule.class).isEnabled()
                && livingentity != null
                && livingentity.isAlive()) {
            return livingentity;
        } else {
            if (client.targetedEntity instanceof LivingEntity livingEntityValue
                    && livingEntityValue.isAlive()) {
                return livingEntityValue;
            }

            return client.currentScreen instanceof ChatScreen ? client.player : null;
        }
    }

    private static float animateVisibility(EasingAnimation easingAnimation2, boolean flag) {
        easingAnimation2.animateTo(flag ? 1.0 : 0.0, 0.3F, Easings.OUT_EXPO, true);
        easingAnimation2.update();
        return easingAnimation2.getFloatValue();
    }

    private float animateAbsorption(float f) {
        long nowMillis = System.currentTimeMillis();
        float absorptionTargetValue = MathHelper.clamp(f, 0.0F, 1.0F);
        if (Float.compare(absorptionTargetValue, this.absorptionTarget) != 0) {
            this.displayedAbsorption = this.sampleAbsorption(nowMillis);
            this.absorptionStart = this.displayedAbsorption;
            this.absorptionTarget = absorptionTargetValue;
            this.absorptionStartedMillis = nowMillis;
        }

        this.displayedAbsorption = this.sampleAbsorption(nowMillis);
        return this.displayedAbsorption;
    }

    public TargetHud() {
        this.maxHealth = 1.0F;
        this.displayedHealth = 1.0F;
        this.healthStart = 1.0F;
        this.healthTarget = 1.0F;
    }

    private float animateHealth(float f) {
        long nowMillis = System.currentTimeMillis();
        float healthTargetValue = MathHelper.clamp(f, 0.0F, 1.0F);
        if (Float.compare(healthTargetValue, this.healthTarget) != 0) {
            this.displayedHealth = this.sampleHealth(nowMillis);
            this.healthStart = this.displayedHealth;
            this.healthTarget = healthTargetValue;
            this.healthStartedMillis = nowMillis;
        }

        this.displayedHealth = this.sampleHealth(nowMillis);
        return this.displayedHealth;
    }

    private float sampleAbsorption(long i) {
        float f = MathHelper.clamp((float) (i - this.absorptionStartedMillis) / 300.0F, 0.0F, 1.0F);
        float f1 = f >= 1.0F ? 1.0F : 1.0F - (float) Math.pow(2.0, -10.0 * (double) f);
        return this.absorptionStart + (this.absorptionTarget - this.absorptionStart) * f1;
    }

    private void resetHealth(float f) {
        float displayedHealthValue = MathHelper.clamp(f, 0.0F, 1.0F);
        this.displayedHealth = displayedHealthValue;
        this.healthStart = displayedHealthValue;
        this.healthTarget = displayedHealthValue;
        this.healthStartedMillis = System.currentTimeMillis();
    }

    private float sampleHealth(long i) {
        float f = MathHelper.clamp((float) (i - this.healthStartedMillis) / 300.0F, 0.0F, 1.0F);
        float f1 = f >= 1.0F ? 1.0F : 1.0F - (float) Math.pow(2.0, -10.0 * (double) f);
        return this.healthStart + (this.healthTarget - this.healthStart) * f1;
    }

    private String protectName(String text) {
        NameProtectModule nameProtectModule =
                Gooba.getInstance().getModuleRegistry().findModule(NameProtectModule.class);
        return !nameProtectModule.isEnabled()
                ? text
                : text.replace(
                        client.player.getName().getString(), nameProtectModule.protectedName());
    }

    private void resetAbsorption(float f) {
        float displayedAbsorptionValue = MathHelper.clamp(f, 0.0F, 1.0F);
        this.displayedAbsorption = displayedAbsorptionValue;
        this.absorptionStart = displayedAbsorptionValue;
        this.absorptionTarget = displayedAbsorptionValue;
        this.absorptionStartedMillis = System.currentTimeMillis();
    }

    public void render(
            PositionSetting positionSetting2, HUDModule hUDModule, Render2DEvent render2DEvent) {
        if (client.player != null && client.world != null) {
            LivingEntity object = this.findTarget();
            if (object == null && hUDModule.alwaysShowSetting.isOn()) {
                object = client.player;
            }

            if (object != null) {
                this.health = safeHealth(object.getHealth());
                this.maxHealth = Math.max(1.0F, object.getMaxHealth());
                this.absorption = Math.max(0.0F, object.getAbsorptionAmount());
                if (object != this.target) {
                    this.resetHealth(MathHelper.clamp(this.health / this.maxHealth, 0.0F, 1.0F));
                    this.resetAbsorption(
                            MathHelper.clamp(this.absorption / this.maxHealth, 0.0F, 1.0F));
                }

                this.target = (LivingEntity) object;
            }

            float factor;
            if (object != null) {
                factor = animateVisibility(this.visibilityAnimation, true);
            } else {
                factor = animateVisibility(this.visibilityAnimation, false);
            }

            if (object == null && !(factor > 0.01F)) {
                positionSetting2.visible = false;
            } else {
                positionSetting2.visible = true;
            }

            float f1 = hUDModule.hudSizeSetting.getFloat();
            positionSetting2.size.set(110.0F * f1, 32.0F * f1);
            if (!(factor <= 0.01F) && this.target != null) {
                float innerX = positionSetting2.position.x;
                float innerY = positionSetting2.position.y;
                float widthValue = 110.0F * f1;
                float height = 32.0F * f1;
                float f6 = 8.0F * f1;
                LivingEntity livingentity = this.target;
                hUDModule.drawBackground(innerX, innerY, widthValue, height, f6, factor);
                float width = 28.0F * f1;
                float innerXValue = innerX + 2.0F * f1;
                float innerYValue = innerY + (height - width) * 0.5F;
                float f10 = MathHelper.clamp((float) livingentity.hurtTime / 10.0F, 0.0F, 1.0F);
                int rGB =
                        new Color(
                                        255,
                                        Math.round(255.0F * (1.0F - f10)),
                                        Math.round(255.0F * (1.0F - f10)),
                                        MathHelper.clamp(Math.round(255.0F * factor), 0, 255))
                                .getRGB();
                if (livingentity instanceof AbstractClientPlayerEntity abstractclientplayerentity) {
                    this.drawPlayerHead(
                            abstractclientplayerentity.getSkin().body().texturePath(),
                            innerXValue,
                            innerYValue,
                            width,
                            rGB);
                } else {
                    RenderUtils.Render2D.drawRoundedRect(
                            innerXValue,
                            innerYValue,
                            width,
                            width,
                            ColorUtils.multiplyAlpha(-13619923, factor),
                            width * 0.3F);
                    String stringValue = "N";
                    float size = 16.5F * f1;
                    Font font = Fonts.ALPHA;
                    float f25 = Fonts.ALPHA.centerTextX(stringValue, innerXValue, width, size);
                    float f26 = Fonts.ALPHA.centerTextY(stringValue, innerYValue, width, size);
                    ColorUtils.multiplyAlpha(-657931, factor);
                    font.drawText(stringValue, f25, f26, size);
                }

                float centerX = innerX + widthValue - 14.5F * f1;
                float centerY = innerY + height * 0.5F;
                float radius = 11.5F * f1;
                float thickness = 1.6F * f1;
                float f13 = MathHelper.clamp(this.health / this.maxHealth, 0.0F, 1.0F);
                float progress = this.animateHealth(f13);
                float progressValue =
                        this.animateAbsorption(
                                MathHelper.clamp(this.absorption / this.maxHealth, 0.0F, 1.0F));
                Gooba.getInstance()
                        .getHudManager()
                        .getCircleData()
                        .drawProgressArc(
                                centerX,
                                centerY,
                                radius,
                                thickness,
                                1.0F,
                                ColorUtils.multiplyAlpha(-13092808, factor));
                Gooba.getInstance()
                        .getHudManager()
                        .getCircleData()
                        .drawProgressArc(
                                centerX,
                                centerY,
                                radius,
                                thickness,
                                progress,
                                hUDModule.getAccentColor(factor));
                if (progressValue > 0.001F) {
                    Gooba.getInstance()
                            .getHudManager()
                            .getCircleData()
                            .drawProgressArc(
                                    centerX,
                                    centerY,
                                    radius,
                                    thickness,
                                    progressValue,
                                    ColorUtils.multiplyAlpha(-10934, factor));
                }

                String string2 =
                        Integer.toString(Math.max(0, Math.round(progress * this.maxHealth)));
                float sizeValue = 7.2F * f1;
                Font fontValue = Fonts.INTER_SEMIBOLD;
                float f23 =
                        Fonts.INTER_SEMIBOLD.centerTextX(
                                string2, centerX - radius, radius * 2.0F, sizeValue);
                float f24 =
                        Fonts.INTER_SEMIBOLD.centerTextY(
                                string2, centerY - radius, radius * 2.0F, sizeValue);
                ColorUtils.multiplyAlpha(-657931, factor);
                fontValue.drawText(string2, f23, f24, sizeValue);
                float f17 = innerX + 32.0F * f1;
                float f18 = centerX - radius - 2.0F * f1;
                String string = this.protectName(livingentity.getName().getString());
                float size3 = 7.2F * f1;
                ScissorStack.push(f17, innerY, Math.max(0.0F, f18 - f17), height);
                fontValue = Fonts.INTER_SEMIBOLD;
                f24 =
                        Fonts.INTER_SEMIBOLD.centerTextY(
                                string, innerY + 3.0F * f1, 13.0F * f1, size3);
                ColorUtils.multiplyAlpha(-657931, factor);
                fontValue.drawText(string, f17, f24, size3);
                ScissorStack.pop();
                this.drawEquipment(
                        render2DEvent,
                        livingentity,
                        f17 - 1.5F * f1,
                        innerY + 21.0F * f1,
                        f1,
                        factor);
            }
        } else {
            positionSetting2.visible = false;
        }
    }
}
