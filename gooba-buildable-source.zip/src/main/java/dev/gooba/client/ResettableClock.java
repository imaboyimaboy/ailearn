package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ResettableClock {
    private long startedAtMillis;

    public void reset() {
        this.startedAtMillis = System.currentTimeMillis();
    }

    public ResettableClock() {
        this.reset();
    }

    @Environment(EnvType.CLIENT)
    public static class TimerNew {
        private long startedAtNanos;

        public void reset() {
            this.startedAtNanos = System.nanoTime();
        }

        public TimerNew() {
            this.reset();
        }
    }
}
