package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class MultiBooleanSetting extends Setting<Map<String, BooleanSetting>> {
    public EasingAnimation expansionAnimation;
    private final Map<String, BooleanSetting> optionsByName = new LinkedHashMap<>();

    public MultiBooleanSetting visibleWhen(Supplier supplier) {
        return (MultiBooleanSetting) super.visibleWhen(supplier);
    }

    public boolean isOn(String text) {
        BooleanSetting booleanSetting = this.findOption(text);
        return booleanSetting != null && booleanSetting.isOn() && this.getVisibility().get();
    }

    public MultiBooleanSetting onChange(Runnable runnable) {
        return (MultiBooleanSetting) super.onChange(runnable);
    }

    @Override
    public EasingAnimation getAnimation() {
        return this.expansionAnimation;
    }

    public MultiBooleanSetting(
            Module moduleValue, String nameValue, BooleanSetting[] booleanSettings) {
        super(moduleValue, nameValue, new LinkedHashMap<>());
        this.expansionAnimation = new EasingAnimation();

        for (BooleanSetting booleanSetting : booleanSettings) {
            ((Map) this.getValue()).put(booleanSetting.getName().toLowerCase(), booleanSetting);
            this.optionsByName.put(booleanSetting.getName().toLowerCase(), booleanSetting);
        }
    }

    public Collection<BooleanSetting> getOptions() {
        return ((Map<String, BooleanSetting>) this.getValue()).values();
    }

    public BooleanSetting findOption(String text) {
        return this.optionsByName.get(text.toLowerCase());
    }
}
