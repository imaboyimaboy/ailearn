package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.HashMap;
import java.util.Map;

@Environment(EnvType.CLIENT)
public final class AnimationRegistry {
    private final Map<String, TimedAnimation> animations = new HashMap<>();
    private final Map<String, float[]> smoothedValues = new HashMap<>();
    private float mouseY;
    private float mouseX;

    public TimedAnimation getOrCreateAnimation(String text) {
        return this.animations.computeIfAbsent(
                text, textValue -> new DecelerateAnimation(300, 1.0));
    }

    public float smoothValue(String text, float target) {
        float[] afloat =
                this.smoothedValues.computeIfAbsent(text, textValue -> new float[] {target});
        afloat[0] += (target - afloat[0]) * 0.2F;
        return afloat[0];
    }

    public void drawMenuButton(MenuButton menuButton2, float opacity) {

        float hoverProgress = menuButton2.getHoverProgress();
        float clickProgress = menuButton2.getClickProgress();
        float f3 = Math.max(hoverProgress, clickProgress);
        RenderUtils.Render2D.drawShadow(
                menuButton2.getX(),
                menuButton2.getY(),
                menuButton2.getWidth(),
                menuButton2.getHeight(),
                ColorUtils.grayscaleOpacity(0, 0.15F * opacity),
                5.0F,
                10.0F,
                1.0F);
        RenderUtils.Blur.drawRoundedBlur(
                menuButton2.getX(),
                menuButton2.getY(),
                menuButton2.getWidth(),
                menuButton2.getHeight(),
                opacity,
                5.0F,
                ColorUtils.scaleAlpha(
                        ColorUtils.darken(ColorUtils.themeBackground(), 0.6F), opacity));
        if (menuButton2.isSelected()) {
            RenderUtils.Render2D.drawRoundedRect(
                    menuButton2.getX(),
                    menuButton2.getY(),
                    menuButton2.getWidth(),
                    menuButton2.getHeight(),
                    ColorUtils.withOpacity(ColorUtils.themeAccent(), opacity * (0.2F + 0.2F * f3)),
                    5.0F);
        }

        RenderUtils.Render2D.drawRoundedOutline(
                menuButton2.getX(),
                menuButton2.getY(),
                menuButton2.getWidth(),
                menuButton2.getHeight(),
                0.5F,
                ColorUtils.withOpacity(
                        ColorUtils.themeAccent(),
                        opacity * (menuButton2.isSelected() ? 0.5F + 0.5F * f3 : f3)),
                5.0F);
        Fonts.SF_REGULAR.drawCenteredText(
                menuButton2.getLabel(),
                menuButton2.getX() + menuButton2.getWidth() / 2.0F,
                menuButton2.getY() + menuButton2.getHeight() / 2.0F - 3.8F,
                6.5F,
                ColorUtils.grayscaleOpacity(255, opacity * (0.6F + 0.4F * f3)));
    }

    public void drawHoverBackground(Rectangle rectangle, float hoverProgress, float opacity) {
        RenderUtils.Render2D.drawShadow(
                rectangle.x(),
                rectangle.y(),
                rectangle.width(),
                rectangle.height(),
                ColorUtils.grayscaleOpacity(0, 0.06F * opacity),
                4.0F,
                6.0F,
                1.0F);
        RenderUtils.Render2D.drawRoundedRect(
                rectangle.x(),
                rectangle.y(),
                rectangle.width(),
                rectangle.height(),
                ColorUtils.grayscaleOpacity(40, 0.15F * opacity),
                4.0F);
        RenderUtils.Render2D.drawRoundedOutline(
                rectangle.x(),
                rectangle.y(),
                rectangle.width(),
                rectangle.height(),
                0.5F,
                ColorUtils.withOpacity(ColorUtils.themeAccent(), opacity * hoverProgress),
                4.0F);
    }

    public float updateHover(String text, Rectangle rectangle) {
        TimedAnimation timedAnimation4 = this.getOrCreateAnimation(text + ":hover");
        timedAnimation4.setDirection(
                rectangle.contains(this.mouseX, this.mouseY)
                        ? AnimationDirection.FORWARDS
                        : AnimationDirection.BACKWARDS);
        return timedAnimation4.getValue();
    }

    public void drawToggle(
            Rectangle rectangle, String string, boolean enabled, String text, float opacity) {
        if (!(rectangle.width() <= 0.0F) && !(opacity <= 0.01F)) {
            float hoverProgress = this.updateHover(text, rectangle);
            this.drawHoverBackground(rectangle, hoverProgress, opacity);
            Font font = Fonts.SF_REGULAR;
            float f3 = rectangle.x() + 6.0F;
            float f4 = rectangle.y() + 3.2F;
            ColorUtils.grayscaleOpacity(255, opacity * (0.5F + 0.5F * hoverProgress));
            font.drawText(string, f3, f4, 6.0F);
            TimedAnimation timedAnimation4 = this.getOrCreateAnimation(text + ":on");
            timedAnimation4.setDirection(
                    enabled ? AnimationDirection.FORWARDS : AnimationDirection.BACKWARDS);
            float value = timedAnimation4.getValue();
            RenderUtils.Render2D.drawRoundedRect(
                    rectangle.x() + rectangle.width() - 6.0F - 11.0F,
                    rectangle.y() + 3.5F,
                    11.0F,
                    6.0F,
                    ColorUtils.interpolate(
                            ColorUtils.grayscaleOpacity(0, 0.2F * opacity),
                            ColorUtils.withOpacity(
                                    ColorUtils.themeAccent(),
                                    opacity * (0.5F + 0.5F * hoverProgress)),
                            value),
                    3.0F);
            RenderUtils.Render2D.drawRoundedRect(
                    rectangle.x() + rectangle.width() - 6.0F - 11.0F + 1.0F + 4.5F * value,
                    rectangle.y() + 4.5F,
                    4.0F,
                    4.0F,
                    ColorUtils.grayscaleOpacity(
                            255, opacity * (0.2F + 0.4F * value + 0.4F * hoverProgress)),
                    2.0F);
        }
    }

    public void setMousePosition(float mouseXValue, float mouseYValue) {
        this.mouseX = mouseXValue;
        this.mouseY = mouseYValue;
    }
}
