package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.math.Box;

@ModuleInfo(
        name = "Player ESP",
        category = ModuleCategory.PLAYER,
        desc = "Highlights players with filled 3D boxes and optional tracers")
@Environment(EnvType.CLIENT)
public class PlayerESPModule extends Module {
    public final SliderSetting eSPAlphaSetting;
    public final ColorSetting colorSetting;
    public final BooleanSetting tracersSetting;
    public final ColorSetting friendColorSetting;
    public final SliderSetting tracersAlphaSetting;
    public final BooleanSetting eSPSetting = new BooleanSetting(this, "ESP", true);

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.world != null && client.player != null) {
            if (this.eSPSetting.isOn() || this.tracersSetting.isOn()) {
                float tickDelta = render3DEvent.getTickDelta();
                int alpha = Math.max(0, Math.min(255, Math.round(this.eSPAlphaSetting.getFloat())));
                int j = Math.max(0, Math.min(255, Math.round(this.tracersAlphaSetting.getFloat())));
                WorldEspRenderer.clear();

                for (AbstractClientPlayerEntity abstractclientplayerentity :
                        client.world.getPlayers()) {
                    if (abstractclientplayerentity != client.player
                            && !FakeLagModule.isGhost(abstractclientplayerentity)
                            && abstractclientplayerentity.isAlive()
                            && !abstractclientplayerentity.isSpectator()) {
                        double d0 =
                                abstractclientplayerentity.lastRenderX
                                        + (abstractclientplayerentity.getX()
                                                        - abstractclientplayerentity.lastRenderX)
                                                * (double) tickDelta;
                        double d1 =
                                abstractclientplayerentity.lastRenderY
                                        + (abstractclientplayerentity.getY()
                                                        - abstractclientplayerentity.lastRenderY)
                                                * (double) tickDelta;
                        double d2 =
                                abstractclientplayerentity.lastRenderZ
                                        + (abstractclientplayerentity.getZ()
                                                        - abstractclientplayerentity.lastRenderZ)
                                                * (double) tickDelta;
                        Box box = abstractclientplayerentity.getBoundingBox();
                        double d3 = box.getLengthX() / 2.0;
                        double d4 = box.getLengthZ() / 2.0;
                        double lengthY = box.getLengthY();
                        Box boxValue =
                                new Box(d0 - d3, d1, d2 - d4, d0 + d3, d1 + lengthY, d2 + d4);
                        boolean isFriend =
                                Gooba.getInstance()
                                        .getFriendManager()
                                        .isFriend(
                                                abstractclientplayerentity.getNameForScoreboard());
                        int color =
                                isFriend
                                        ? this.friendColorSetting.getColor()
                                        : this.colorSetting.getColor();
                        int l = ColorUtils.withAlpha(color, alpha);
                        if (this.eSPSetting.isOn()) {
                            WorldEspRenderer.enqueueBox(boxValue, l, j, this.tracersSetting.isOn());
                        } else {
                            WorldEspRenderer.enqueueBox(boxValue, 0, j, true);
                        }
                    }
                }

                WorldEspRenderer.flush(render3DEvent.getMatrixStack());
            }
        }
    }

    public PlayerESPModule() {
        this.tracersSetting = new BooleanSetting(this, "Tracers", true);
        this.tracersAlphaSetting =
                new SliderSetting(this, "Tracers Alpha", 255.0F, 0.0F, 255.0F, 1.0F);
        this.eSPAlphaSetting = new SliderSetting(this, "ESP Alpha", 128.0F, 0.0F, 255.0F, 1.0F);
        this.colorSetting = new ColorSetting(this, "Color", -2141847553);
        this.friendColorSetting = new ColorSetting(this, "Friend Color", ColorUtils.GREEN);
    }
}
