package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class TextSetting extends Setting<String> {
    private String cachedText;
    private final boolean numericOnly;

    public boolean isNumericOnly() {
        return this.numericOnly;
    }

    public String getText() {
        if (this.cachedText == null) {
            this.cachedText = (String) super.getValue();
        }

        return this.cachedText;
    }

    public TextSetting(Module moduleValue, String nameValue, String object) {
        super(moduleValue, nameValue, object);
        this.numericOnly = false;
        this.cachedText = object;
    }

    public TextSetting setValue(String stringValue) {
        this.cachedText = stringValue;
        return (TextSetting) super.setValue(stringValue);
    }

    public TextSetting visibleWhen(Supplier supplier) {
        return (TextSetting) super.visibleWhen(supplier);
    }

    public TextSetting onChange(Runnable runnable) {
        return (TextSetting)
                super.onChange(
                        () -> {
                            runnable.run();
                            this.cachedText = (String) super.getValue();
                        });
    }

    public TextSetting(
            Module moduleValue, String nameValue, String object, boolean numericOnlyValue) {
        super(moduleValue, nameValue, object);
        this.numericOnly = numericOnlyValue;
        this.cachedText = object;
    }
}
