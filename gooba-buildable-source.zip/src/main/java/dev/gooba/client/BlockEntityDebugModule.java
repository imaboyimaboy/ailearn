package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SignText;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;

@ModuleInfo(
        name = "BlockEntityDebug",
        category = ModuleCategory.DONUT,
        desc = "Reports selected loaded block entities in chat")
@Environment(EnvType.CLIENT)
public class BlockEntityDebugModule extends Module {
    private int scanTicks;
    private final Map<BlockPos, String> lastDescriptions;

    public final StringListSetting selectBlocksSetting =
            new StringListSetting(this, "Select Blocks");

    @Override
    protected void onEnable() {
        this.reset();
    }

    public BlockEntityDebugModule() {
        this.lastDescriptions = new HashMap<>();
    }

    private String signText(SignText signtext) {
        StringJoiner stringjoiner = new StringJoiner(" | ");

        for (Text text : signtext.getMessages(false)) {
            String textValue =
                    text.getString()
                            .replace('\n', ' ')
                            .replace('\r', ' ')
                            .replace("\"", "\\\"")
                            .trim();
            if (!textValue.isEmpty()) {
                stringjoiner.add(textValue);
            }
        }

        return stringjoiner.toString();
    }

    @Override
    protected void onDisable() {
        this.reset();
    }

    private void scanBlocks(Set<Block> set) {
        HashSet hashset = new HashSet();
        ChunkPos chunkpos = client.player.getChunkPos();
        int clampedViewDistance = client.options.getClampedViewDistance();

        for (int j = chunkpos.x - clampedViewDistance; j <= chunkpos.x + clampedViewDistance; j++) {
            for (int k = chunkpos.z - clampedViewDistance;
                    k <= chunkpos.z + clampedViewDistance;
                    k++) {
                WorldChunk worldchunk =
                        client.world.getChunkManager().getChunk(j, k, ChunkStatus.FULL, false);
                if (worldchunk != null) {
                    for (BlockEntity blockentity : worldchunk.getBlockEntities().values()) {
                        BlockPos blockpos = blockentity.getPos().toImmutable();
                        BlockState blockstate = client.world.getBlockState(blockpos);
                        if (set.contains(blockstate.getBlock())) {
                            hashset.add(blockpos);
                            String text = this.describeBlock(blockentity, blockstate, blockpos);
                            String textValue = this.lastDescriptions.put(blockpos, text);
                            if (!text.equals(textValue)) {
                                client.player.sendMessage(
                                        Text.literal(text).formatted(Formatting.WHITE), false);
                            }
                        }
                    }
                }
            }
        }

        this.lastDescriptions.keySet().retainAll(hashset);
    }

    private void reset() {
        this.lastDescriptions.clear();
        this.scanTicks = 0;
    }

    private String describeBlock(
            BlockEntity blockentity, BlockState blockstate, BlockPos blockpos) {
        String text = Registries.BLOCK.getId(blockstate.getBlock()).toString();
        StringBuilder stringbuilder =
                new StringBuilder("[BlockEntityDebug] found ")
                        .append(text)
                        .append(" at ")
                        .append(blockpos.getX())
                        .append(' ')
                        .append(blockpos.getY())
                        .append(' ')
                        .append(blockpos.getZ())
                        .append(" state: ")
                        .append(blockstate);
        if (blockentity instanceof SignBlockEntity signblockentity) {
            this.appendSignDetails(stringbuilder, signblockentity);
        }

        return stringbuilder.toString();
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.world != null && client.player != null) {
            Set set = this.selectBlocksSetting.getSelectedBlocks();
            if (set.isEmpty()) {
                this.lastDescriptions.clear();
                this.scanTicks = 0;
            } else if (++this.scanTicks >= 20) {
                this.scanTicks = 0;
                this.scanBlocks(set);
            }
        } else {
            this.reset();
        }
    }

    private void appendSignDetails(StringBuilder stringbuilder, SignBlockEntity signblockentity) {
        SignText signtext = signblockentity.getFrontText();
        SignText backText = signblockentity.getBackText();
        stringbuilder
                .append(" sign: frontGlowing=")
                .append(signtext.isGlowing())
                .append(", backGlowing=")
                .append(backText.isGlowing())
                .append(", frontColor=")
                .append(signtext.getColor().getId())
                .append(", backColor=")
                .append(backText.getColor().getId())
                .append(", waxed=")
                .append(signblockentity.isWaxed())
                .append(", frontText=\"")
                .append(this.signText(signtext))
                .append('"')
                .append(", backText=\"")
                .append(this.signText(backText))
                .append('"');
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.reset();
    }
}
