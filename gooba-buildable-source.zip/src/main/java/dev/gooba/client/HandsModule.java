package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;

@ModuleInfo(
        name = "Hands",
        desc = "Adjusts first-person hand position, rotation, and scale",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class HandsModule extends Module {
    public SliderSetting leftZSetting;
    public SliderSetting rightScaleSetting;
    public SliderSetting rightYSetting;
    public SliderSetting leftScaleSetting;
    public SliderSetting rightZSetting;
    public SliderSetting leftYSetting;
    public SliderSetting rightXSetting;
    public ButtonSetting rightHandSetting = new ButtonSetting(this, "Right hand");
    public SliderSetting leftXSetting;
    private boolean restoreShaderHand;
    public ButtonSetting leftHandSetting;
    private boolean previewing;
    private boolean restoreSwingAnimation;

    @Override
    protected void onDisable() {
        SwingAnimationModule swingAnimationModule = SwingAnimationModule.getInstance();
        if (swingAnimationModule != null && swingAnimationModule.isEnabled()) {
            this.restoreSwingAnimation = true;
        } else {
            this.restoreSwingAnimation = false;
        }

        if (swingAnimationModule != null && swingAnimationModule.isEnabled()) {
            swingAnimationModule.setEnabled(false, false);
        }

        ShaderHandModule shaderHandModule2 = ShaderHandModule.getInstance();
        if (shaderHandModule2 != null && shaderHandModule2.isEnabled()) {
            this.restoreShaderHand = true;
        } else {
            this.restoreShaderHand = false;
        }

        if (shaderHandModule2 != null && shaderHandModule2.isEnabled()) {
            shaderHandModule2.setEnabled(false, false);
        }
    }

    public static HandsModule getInstance() {
        return (HandsModule) ModuleLookup.getModule(HandsModule.class);
    }

    public void applyTranslation(MatrixStack matrixstack, Arm arm) {
        if (this.isActive()) {
            float f =
                    arm == Arm.RIGHT ? this.rightXSetting.getFloat() : this.leftXSetting.getFloat();
            float f1 =
                    arm == Arm.RIGHT ? this.rightYSetting.getFloat() : this.leftYSetting.getFloat();
            float f2 =
                    arm == Arm.RIGHT ? this.rightZSetting.getFloat() : this.leftZSetting.getFloat();
            matrixstack.translate(f, f1, f2);
        }
    }

    @Override
    protected void onEnable() {
        SwingAnimationModule swingAnimationModule = SwingAnimationModule.getInstance();
        if (this.restoreSwingAnimation
                && swingAnimationModule != null
                && !swingAnimationModule.isEnabled()) {
            swingAnimationModule.setEnabled(true, false);
        }

        ShaderHandModule shaderHandModule2 = ShaderHandModule.getInstance();
        if (this.restoreShaderHand && shaderHandModule2 != null && !shaderHandModule2.isEnabled()) {
            shaderHandModule2.setEnabled(true, false);
        }
    }

    public HandsModule() {
        this.rightXSetting = new SliderSetting(this, "Right X", 0.0F, -2.0F, 2.0F, 0.05F);
        this.rightYSetting = new SliderSetting(this, "Right Y", 0.0F, -2.0F, 2.0F, 0.05F);
        this.rightZSetting = new SliderSetting(this, "Right Z", 0.0F, -2.0F, 2.0F, 0.05F);
        this.rightScaleSetting = new SliderSetting(this, "Right Scale", 1.0F, 0.1F, 3.0F, 0.05F);
        this.leftHandSetting = new ButtonSetting(this, "Left hand");
        this.leftXSetting = new SliderSetting(this, "Left X", 0.0F, -2.0F, 2.0F, 0.05F);
        this.leftYSetting = new SliderSetting(this, "Left Y", 0.0F, -2.0F, 2.0F, 0.05F);
        this.leftZSetting = new SliderSetting(this, "Left Z", 0.0F, -2.0F, 2.0F, 0.05F);
        this.leftScaleSetting = new SliderSetting(this, "Left Scale", 1.0F, 0.1F, 3.0F, 0.05F);
    }

    public void setPreviewing(boolean previewingValue) {
        this.previewing = previewingValue;
    }

    public void applyScale(MatrixStack matrixstack, Arm arm) {
        if (this.isActive()) {
            float f =
                    arm == Arm.RIGHT
                            ? this.rightScaleSetting.getFloat()
                            : this.leftScaleSetting.getFloat();
            matrixstack.scale(f, f, f);
        }
    }

    public void resetRightHand() {
        this.rightXSetting.setValue(0.0F);
        this.rightYSetting.setValue(0.0F);
        this.rightZSetting.setValue(0.0F);
        this.rightScaleSetting.setValue(1.0F);
    }

    public void resetHands() {
        this.resetRightHand();
        this.resetLeftHand();
    }

    public boolean isActive() {
        return this.isEnabled() || this.previewing;
    }

    public void resetLeftHand() {
        this.leftXSetting.setValue(0.0F);
        this.leftYSetting.setValue(0.0F);
        this.leftZSetting.setValue(0.0F);
        this.leftScaleSetting.setValue(1.0F);
    }
}
