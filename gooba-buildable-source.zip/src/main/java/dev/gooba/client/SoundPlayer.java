package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioFormat.Encoding;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.FloatControl.Type;
import javax.sound.sampled.LineUnavailableException;

@Environment(EnvType.CLIENT)
public class SoundPlayer {
    private static final CopyOnWriteArrayList<Clip> activeClips = new CopyOnWriteArrayList<>();

    private static float clampVolume(float f) {
        float f1 = Math.max(0.0F, Math.min(2.0F, f));
        return f1 == 0.0F ? 0.0F : Math.max(0.65F, f1);
    }

    public static void play(String text, float f, float f1) {
        if (areSoundsEnabled()) {
            float f2 = clampVolume(f);
            CompletableFuture.runAsync(
                    () -> {
                        try {
                            removeClosedClips();
                            String textValue = "/assets/client/sounds/" + text + ".wav";
                            InputStream inputstream =
                                    SoundPlayer.class.getResourceAsStream(textValue);
                            if (inputstream == null) {
                                playMinecraftSound(text, f2, f1);
                                return;
                            }

                            try (AudioInputStream audioinputstream =
                                    AudioSystem.getAudioInputStream(
                                            new BufferedInputStream(inputstream))) {
                                Clip clip = AudioSystem.getClip();
                                if (Math.abs(f1 - 1.0F) < 0.001F) {
                                    clip.open(audioinputstream);
                                } else {
                                    openPitchShiftedClip(clip, audioinputstream, f1);
                                }

                                if (clip.isControlSupported(Type.MASTER_GAIN)) {
                                    FloatControl floatcontrol =
                                            (FloatControl) clip.getControl(Type.MASTER_GAIN);
                                    if (f2 <= 0.0F) {
                                        floatcontrol.setValue((float) (Math.log10(1.0E-4) * 20.0));
                                    } else {
                                        floatcontrol.setValue(
                                                (float) (Math.log10((double) f2) * 20.0));
                                    }
                                }

                                clip.addLineListener(
                                        lineevent -> {
                                            if (lineevent.getType()
                                                    == javax.sound.sampled.LineEvent.Type.STOP) {
                                                clip.close();
                                                activeClips.remove(clip);
                                            }
                                        });
                                activeClips.add(clip);
                                clip.start();
                            }
                        } catch (Exception exception) {
                        }
                    });
        }
    }

    private static void openPitchShiftedClip(Clip clip, AudioInputStream audioinputstream, float f)
            throws Exception, IOException, LineUnavailableException {
        float f1 = Math.max(0.5F, Math.min(2.0F, f));
        AudioInputStream audioinputstreamValue = audioinputstream;
        AudioFormat audioformat = audioinputstream.getFormat();
        if (audioformat.getEncoding() != Encoding.PCM_SIGNED) {
            audioinputstreamValue =
                    AudioSystem.getAudioInputStream(Encoding.PCM_SIGNED, audioinputstream);
            audioformat = audioinputstreamValue.getFormat();
        }

        byte[] abyte = audioinputstreamValue.readAllBytes();
        if (audioinputstreamValue != audioinputstream) {
            audioinputstreamValue.close();
        }

        int frameSize = audioformat.getFrameSize();
        if (frameSize <= 0) {
            clip.open(audioformat, abyte, 0, abyte.length);
        } else {
            int j = abyte.length / frameSize;
            int k = (int) ((float) j / f1);
            if (k <= 0) {
                clip.open(audioformat, abyte, 0, abyte.length);
            } else {
                byte[] values = new byte[k * frameSize];

                for (int l = 0; l < k; l++) {
                    int i1 = Math.min(j - 1, (int) ((float) l * f1));
                    System.arraycopy(abyte, i1 * frameSize, values, l * frameSize, frameSize);
                }

                clip.open(audioformat, values, 0, values.length);
            }
        }
    }

    public static void playDefaultPitch(String text, float f) {
        play(text, f, 1.0F);
    }

    private static void removeClosedClips() {
        activeClips.removeIf(clip -> !clip.isOpen());
    }

    private static void playMinecraftSound(String text, float f, float f1) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        minecraftclient.execute(
                () ->
                        minecraftclient
                                .getSoundManager()
                                .play(
                                        PositionedSoundInstance.ui(
                                                SoundEvent.of(Identifier.of("client", text)),
                                                f1,
                                                f)));
    }

    public static boolean areSoundsEnabled() {
        try {
            ClickGUIModule clickGUIModule =
                    Gooba.getInstance().getModuleRegistry().findModule(ClickGUIModule.class);
            return clickGUIModule != null && clickGUIModule.soundsSetting.isOn();
        } catch (Exception exception) {
            return false;
        }
    }
}
