package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.function.Function;

@ModuleInfo(
        name = "TargetESP",
        desc = "Displays an animated visual effect around the current combat target",
        category = ModuleCategory.RENDER)
@Environment(EnvType.CLIENT)
public class TargetESPModule extends Module {
    public ModeSetting imageTypeSetting;
    public Entity renderedTarget;
    private static final RenderPipeline LINE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "ring_esp_line"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.DEBUG_LINES)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    public static final RenderPipeline TEXTURE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation("pipeline/wtex")
                            .withVertexShader("core/position_tex_color")
                            .withFragmentShader("core/position_tex_color")
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withCull(false)
                            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
                            .build());
    public ModeSetting targetModeSetting =
            new ModeSetting(this, "Target Mode", new String[] {"Raycast", "Attack"});
    public SliderSetting ghostSpeedSetting;
    public ModeSetting modeSetting;
    private static final RenderPipeline FILL_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "ring_esp_fill"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.LIGHTNING)
                            .build());
    public EasingAnimation visibilityAnimation;
    public SliderSetting timeoutSetting =
            new SliderSetting(this, "Timeout", 3.0F, 0.1F, 10.0F, 0.1F)
                    .visibleWhen(() -> this.targetModeSetting.isSelected("Attack"));
    private long targetExpiresMillis;
    private final BufferAllocator bufferAllocator;
    public SliderSetting ringSpeedSetting;
    public SliderSetting glowStrengthSetting;
    private static final RenderLayer FILL_LAYER =
            RenderLayer.of(
                    "ring_esp_fill",
                    RenderSetup.builder(TargetESPModule.FILL_PIPELINE)
                            .expectedBufferSize(65536)
                            .build());
    public SliderSetting donutSizeSetting;
    private float ghostPhase;
    public EasingAnimation hurtAnimation;
    public static final Function<Identifier, RenderLayer> textureLayer =
            Util.memoize(
                    identifier -> {
                        RenderSetup rendersetup =
                                RenderSetup.builder(TEXTURE_PIPELINE)
                                        .texture("Sampler0", identifier)
                                        .translucent()
                                        .expectedBufferSize(1536)
                                        .build();
                        return RenderLayer.of("wtex", rendersetup);
                    });
    private static final RenderLayer LINE_LAYER =
            RenderLayer.of(
                    "ring_esp_line",
                    RenderSetup.builder(LINE_PIPELINE).expectedBufferSize(16384).build());
    private long lastFrameMillis;
    public SliderSetting glowSizeSetting;
    private Entity attackedTarget;
    public ModeSetting ghostTypeSetting;
    public SliderSetting donutSpeedSetting;
    public SliderSetting imageSizeSetting;
    public SliderSetting imageSpeedSetting;

    @EventHandler
    public void onAttack(AttackEvent attackEvent) {
        if (this.targetModeSetting.isSelected("Attack")
                && this.isTargetType(attackEvent.getTarget())) {
            this.attackedTarget = attackEvent.getTarget();
            this.targetExpiresMillis =
                    System.currentTimeMillis()
                            + (long) Math.round(this.timeoutSetting.getFloat() * 1000.0F);
        }
    }

    public TargetESPModule() {
        this.modeSetting =
                new ModeSetting(
                        this, "Mode", new String[] {"Ghosts", "Image", "Ring", "Donut", "Cubes"});
        this.ghostTypeSetting =
                new ModeSetting(this, "Ghost type", new String[] {"1", "2", "3", "4"})
                        .visibleWhen(() -> this.modeSetting.isSelected("Ghosts"));
        this.imageTypeSetting =
                new ModeSetting(this, "Image Type", new String[] {"1"})
                        .visibleWhen(() -> this.modeSetting.isSelected("Image"));
        this.ghostSpeedSetting =
                new SliderSetting(this, "Ghost speed", 900.0F, 400.0F, 1500.0F, 50.0F)
                        .visibleWhen(() -> this.modeSetting.isSelected("Ghosts"));
        this.glowStrengthSetting =
                new SliderSetting(this, "Glow Strength", 0.35F, 0.1F, 0.75F, 0.05F)
                        .visibleWhen(() -> this.modeSetting.isSelected("Ghosts"));
        this.glowSizeSetting =
                new SliderSetting(this, "Glow size", 0.7F, 0.1F, 2.0F, 0.05F)
                        .visibleWhen(() -> this.modeSetting.isSelected("Ghosts"));
        this.imageSpeedSetting =
                new SliderSetting(this, "Image Speed", 1000.0F, 500.0F, 3000.0F, 100.0F)
                        .visibleWhen(() -> this.modeSetting.isSelected("Image"));
        this.imageSizeSetting =
                new SliderSetting(this, "Image Size", 1.0F, 0.25F, 3.0F, 0.05F)
                        .visibleWhen(() -> this.modeSetting.isSelected("Image"));
        this.ringSpeedSetting =
                new SliderSetting(this, "Ring speed", 1800.0F, 600.0F, 4000.0F, 100.0F)
                        .visibleWhen(() -> this.modeSetting.isSelected("Ring"));
        this.donutSpeedSetting =
                new SliderSetting(this, "Donut Speed", 1400.0F, 600.0F, 4000.0F, 100.0F)
                        .visibleWhen(() -> this.modeSetting.isSelected("Donut"));
        this.donutSizeSetting =
                new SliderSetting(this, "Donut Size", 1.0F, 0.5F, 2.5F, 0.05F)
                        .visibleWhen(() -> this.modeSetting.isSelected("Donut"));
        this.bufferAllocator = new BufferAllocator(262144);
        this.renderedTarget = null;
        this.visibilityAnimation = new EasingAnimation();
        this.hurtAnimation = new EasingAnimation();
        this.ghostPhase = 0.0F;
        this.lastFrameMillis = 0L;
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.bufferAllocator.clear();
        this.renderedTarget = null;
        this.attackedTarget = null;
        this.targetExpiresMillis = 0L;
    }

    private static void drawTexturedQuad(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            int color,
            int colorValue,
            int color4,
            int color5,
            int alpha) {
        vertexconsumer
                .vertex(matrix4f, -0.5F, -0.5F, 0.0F)
                .color(ColorUtils.withAlpha(color, alpha))
                .texture(0.0F, 1.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(0.0F, 0.0F, 1.0F);
        vertexconsumer
                .vertex(matrix4f, 0.5F, -0.5F, 0.0F)
                .color(ColorUtils.withAlpha(colorValue, alpha))
                .texture(1.0F, 1.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(0.0F, 0.0F, 1.0F);
        vertexconsumer
                .vertex(matrix4f, 0.5F, 0.5F, 0.0F)
                .color(ColorUtils.withAlpha(color4, alpha))
                .texture(1.0F, 0.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(0.0F, 0.0F, 1.0F);
        vertexconsumer
                .vertex(matrix4f, -0.5F, 0.5F, 0.0F)
                .color(ColorUtils.withAlpha(color5, alpha))
                .texture(0.0F, 0.0F)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(0.0F, 0.0F, 1.0F);
    }

    private boolean isTargetType(Entity entity) {
        return entity != null
                && entity != client.player
                && (entity instanceof LivingEntity || entity instanceof EndCrystalEntity);
    }

    @Override
    protected void onDisable() {
        this.renderedTarget = null;
        this.attackedTarget = null;
        this.targetExpiresMillis = 0L;
        super.onDisable();
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        int l3 = 15728880;
        this.visibilityAnimation.update();
        if (client.world != null && client.player != null) {
            Entity entityx = this.findTarget();
            if (entityx != null) {
                this.renderedTarget = entityx;
            }

            this.visibilityAnimation.animateTo(
                    entityx != null ? 1.0 : 0.0, 0.15F, Easings.OUT_SINE);
            float floatValue = this.visibilityAnimation.getFloatValue();
            if (entityx == null && floatValue <= 0.001F) {
                this.renderedTarget = null;
            }

            Immediate immediate = VertexConsumerProvider.immediate(this.bufferAllocator);
            if (floatValue > 0.001F
                    && this.renderedTarget != null
                    && this.modeSetting.isSelected("Ghosts")
                    && this.ghostTypeSetting.isSelected("2")) {
                long nowMillis = System.currentTimeMillis();
                if (this.lastFrameMillis == 0L) {
                    this.lastFrameMillis = nowMillis;
                }

                long j = nowMillis - this.lastFrameMillis;
                if (j > 0L) {
                    this.ghostPhase =
                            this.ghostPhase
                                    + (float) (5L * j)
                                            / (float) this.ghostSpeedSetting.getFloat().longValue();
                }

                this.lastFrameMillis = nowMillis;
                MatrixStack matrixstack = render3DEvent.getMatrixStack();
                Vec3d vec3d = this.renderedTarget.getLerpedPos(render3DEvent.getTickDelta());
                Vec3d vec3d1 = client.gameRenderer.getCamera().getCameraPos();
                double d0 = vec3d.x - vec3d1.x;
                double d1 = vec3d.y - vec3d1.y;
                double d2 = vec3d.z - vec3d1.z;
                floatValue = (float) this.visibilityAnimation.getValue();
                this.hurtAnimation.update();
                int k1 = this.hurtTime(this.renderedTarget);
                float f2 = (float) Math.sin((double) k1 * (Math.PI / 20));
                this.hurtAnimation.animateTo((double) f2, 0.1F, Easings.OUT_SINE);
                float floatValueValue = this.hurtAnimation.getFloatValue();
                int color = ColorUtils.animatedAccent(1);
                int endColor = ColorUtils.cachedRgba(200, 70, 70, (int) (255.0F * floatValue));
                int colorValue =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(color, floatValue),
                                endColor,
                                floatValueValue);
                byte b0 = 3;
                byte b1 = 12;
                int k2 = 3 * b0;
                matrixstack.push();
                Camera camera = client.gameRenderer.getCamera();

                for (byte b2 = 0; b2 < k2; b2 += b0) {
                    for (int l2 = 0; l2 < b1; l2++) {
                        float f4 = this.ghostPhase + (float) l2 * 0.1F;
                        float f5 = 0.6F;
                        float f6 = 0.4F;
                        int i3 = (int) Math.pow((double) b2, 2.0);
                        matrixstack.push();
                        double d3 = d0 + (double) f5 * Math.sin((double) (f4 + (float) i3));
                        double d5 =
                                d1
                                        + (double) f6
                                        + 0.3F
                                                * Math.sin(
                                                        (double)
                                                                (this.ghostPhase
                                                                        + (float) l2 * 0.2F))
                                        + (double) (0.2F * (float) b2);
                        double d7 = d2 + (double) f5 * Math.cos((double) (f4 - (float) i3));
                        matrixstack.translate(d3, d5, d7);
                        float f8 = (0.006F + (float) l2 / 2000.0F) * floatValue;
                        matrixstack.scale(f8, f8, f8);
                        matrixstack.multiply(
                                RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
                        matrixstack.multiply(
                                RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
                        Matrix4f matrix4f = matrixstack.peek().getPositionMatrix();
                        VertexConsumer vertexconsumer =
                                immediate.getBuffer(
                                        textureLayer.apply(
                                                Identifier.of(
                                                        "client",
                                                        "textures/visuals/particles_3.png")));
                        int j3 = -20;
                        int k3 = 35;
                        vertexconsumer
                                .vertex(matrix4f, (float) j3, (float) (j3 + k3), 0.0F)
                                .color(colorValue)
                                .texture(0.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        vertexconsumer
                                .vertex(matrix4f, (float) (j3 + k3), (float) (j3 + k3), 0.0F)
                                .color(colorValue)
                                .texture(1.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        vertexconsumer
                                .vertex(matrix4f, (float) (j3 + k3), (float) j3, 0.0F)
                                .color(colorValue)
                                .texture(1.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        vertexconsumer
                                .vertex(matrix4f, (float) j3, (float) j3, 0.0F)
                                .color(colorValue)
                                .texture(0.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        j3 = (int) (-20.0F - 20.0F * this.glowSizeSetting.getFloat());
                        k3 = (int) (35.0F + 40.0F * this.glowSizeSetting.getFloat());
                        vertexconsumer
                                .vertex(matrix4f, (float) j3, (float) (j3 + k3), 0.0F)
                                .color(
                                        ColorUtils.withOpacity(
                                                colorValue,
                                                floatValue * this.glowStrengthSetting.getFloat()))
                                .texture(0.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        vertexconsumer
                                .vertex(matrix4f, (float) (j3 + k3), (float) (j3 + k3), 0.0F)
                                .color(
                                        ColorUtils.withOpacity(
                                                colorValue,
                                                floatValue * this.glowStrengthSetting.getFloat()))
                                .texture(1.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        vertexconsumer
                                .vertex(matrix4f, (float) (j3 + k3), (float) j3, 0.0F)
                                .color(
                                        ColorUtils.withOpacity(
                                                colorValue,
                                                floatValue * this.glowStrengthSetting.getFloat()))
                                .texture(1.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        vertexconsumer
                                .vertex(matrix4f, (float) j3, (float) j3, 0.0F)
                                .color(
                                        ColorUtils.withOpacity(
                                                colorValue,
                                                floatValue * this.glowStrengthSetting.getFloat()))
                                .texture(0.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        matrixstack.pop();
                    }
                }

                matrixstack.pop();
            }

            if (floatValue > 0.001F
                    && this.renderedTarget != null
                    && this.modeSetting.isSelected("Ghosts")
                    && this.ghostTypeSetting.isSelected("4")) {
                long nowMillisValue = System.currentTimeMillis();
                if (this.lastFrameMillis == 0L) {
                    this.lastFrameMillis = nowMillisValue;
                }

                long l5 = nowMillisValue - this.lastFrameMillis;
                if (l5 > 0L) {
                    this.ghostPhase =
                            this.ghostPhase
                                    + (float) (5L * l5)
                                            / (float) this.ghostSpeedSetting.getFloat().longValue();
                }

                this.lastFrameMillis = nowMillisValue;
                MatrixStack matrixStack = render3DEvent.getMatrixStack();
                Vec3d vec3d2 = this.renderedTarget.getLerpedPos(render3DEvent.getTickDelta());
                Vec3d vec3d4 = client.gameRenderer.getCamera().getCameraPos();
                double d10 = vec3d2.x - vec3d4.x;
                double d12 = vec3d2.y - vec3d4.y;
                double d16 = vec3d2.z - vec3d4.z;
                floatValue = (float) this.visibilityAnimation.getValue();
                this.hurtAnimation.update();
                int j12 = this.hurtTime(this.renderedTarget);
                float f22 = (float) Math.sin((double) j12 * (Math.PI / 20));
                this.hurtAnimation.animateTo((double) f22, 0.1F, Easings.OUT_SINE);
                float floatValue2 = this.hurtAnimation.getFloatValue();
                int color12 = ColorUtils.animatedAccent(1);
                int endColorValue = ColorUtils.cachedRgba(200, 70, 70, (int) (255.0F * floatValue));
                int color13 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(color12, floatValue),
                                endColorValue,
                                floatValue2);
                byte b7 = 3;
                byte b8 = 24;
                int i14 = 3 * b7;
                matrixStack.push();
                Camera cameraValue = client.gameRenderer.getCamera();

                for (byte b13 = 0; b13 < i14; b13 += b7) {
                    for (int i15 = 0; i15 < b8; i15++) {
                        float f43 = this.ghostPhase + (float) i15 * 0.05F;
                        float width = this.renderedTarget.getWidth();
                        float f52 = 0.45F;
                        int j17 = (int) Math.pow((double) b13, 2.0);
                        matrixStack.push();
                        double d39 = d10 + (double) width * Math.sin((double) (f43 + (float) j17));
                        double d41 =
                                d12
                                        + (double) f52
                                        + 0.1F
                                                * Math.sin(
                                                        (double)
                                                                (this.ghostPhase
                                                                        + (float) i15 * 0.1F))
                                        + (double) (0.2F * (float) b13);
                        double d44 = d16 + (double) width * Math.cos((double) (f43 - (float) j17));
                        matrixStack.translate(d39, d41, d44);
                        float f62 = (0.009F + (float) i15 / 2000.0F) * floatValue;
                        matrixStack.scale(f62, f62, f62);
                        matrixStack.multiply(
                                RotationAxis.POSITIVE_Y.rotationDegrees(-cameraValue.getYaw()));
                        matrixStack.multiply(
                                RotationAxis.POSITIVE_X.rotationDegrees(cameraValue.getPitch()));
                        Matrix4f matrix4f7 = matrixStack.peek().getPositionMatrix();
                        VertexConsumer buffer =
                                immediate.getBuffer(
                                        textureLayer.apply(
                                                Identifier.of(
                                                        "client",
                                                        "textures/visuals/particles_3.png")));
                        int l17 = -12;
                        int j18 = 16;
                        buffer.vertex(matrix4f7, (float) l17, (float) (l17 + j18), 0.0F)
                                .color(color13)
                                .texture(0.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer.vertex(matrix4f7, (float) (l17 + j18), (float) (l17 + j18), 0.0F)
                                .color(color13)
                                .texture(1.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer.vertex(matrix4f7, (float) (l17 + j18), (float) l17, 0.0F)
                                .color(color13)
                                .texture(1.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer.vertex(matrix4f7, (float) l17, (float) l17, 0.0F)
                                .color(color13)
                                .texture(0.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        l17 = (int) (-12.0F - 20.0F * this.glowSizeSetting.getFloat());
                        j18 = (int) (16.0F + 40.0F * this.glowSizeSetting.getFloat());
                        buffer.vertex(matrix4f7, (float) l17, (float) (l17 + j18), 0.0F)
                                .color(
                                        ColorUtils.withOpacity(
                                                color13,
                                                floatValue * this.glowStrengthSetting.getFloat()))
                                .texture(0.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer.vertex(matrix4f7, (float) (l17 + j18), (float) (l17 + j18), 0.0F)
                                .color(
                                        ColorUtils.withOpacity(
                                                color13,
                                                floatValue * this.glowStrengthSetting.getFloat()))
                                .texture(1.0F, 1.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer.vertex(matrix4f7, (float) (l17 + j18), (float) l17, 0.0F)
                                .color(
                                        ColorUtils.withOpacity(
                                                color13,
                                                floatValue * this.glowStrengthSetting.getFloat()))
                                .texture(1.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        buffer.vertex(matrix4f7, (float) l17, (float) l17, 0.0F)
                                .color(
                                        ColorUtils.withOpacity(
                                                color13,
                                                floatValue * this.glowStrengthSetting.getFloat()))
                                .texture(0.0F, 0.0F)
                                .overlay(OverlayTexture.DEFAULT_UV)
                                .light(l3)
                                .normal(0.0F, 0.0F, 1.0F);
                        matrixStack.pop();
                    }
                }

                matrixStack.pop();
            }

            if (floatValue > 0.001F
                    && this.renderedTarget != null
                    && this.modeSetting.isSelected("Ghosts")
                    && this.ghostTypeSetting.isSelected("1")) {
                long j4 = this.ghostSpeedSetting.getFloat().longValue();
                long nowMillis2 = System.currentTimeMillis();
                if (this.lastFrameMillis == 0L) {
                    this.lastFrameMillis = nowMillis2;
                }

                long i8 = nowMillis2 - this.lastFrameMillis;
                if (i8 > 0L) {
                    this.ghostPhase += (float) (5L * i8) / (float) j4;
                }

                this.lastFrameMillis = nowMillis2;
                int k9 = this.hurtTime(this.renderedTarget);
                float progress = (float) Math.sin((double) k9 * (Math.PI / 20));
                int endColor2 = ColorUtils.cachedRgba(255, 100, 100, (int) (255.0F * floatValue));
                int color14 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(0), floatValue),
                                endColor2,
                                progress);
                int colorValueValue =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(90), floatValue),
                                endColor2,
                                progress);
                int k11 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(180), floatValue),
                                endColor2,
                                progress);
                int j1 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(360), floatValue),
                                endColor2,
                                progress);
                MatrixStack matrixStackValue = render3DEvent.getMatrixStack();
                Vec3d vec3d9 = this.renderedTarget.getLerpedPos(render3DEvent.getTickDelta());
                Vec3d vec3d11 = client.gameRenderer.getCamera().getCameraPos();
                long nowMillis3 = System.currentTimeMillis();
                double d26 = (double) nowMillis3 / (double) j4;
                float f33 = this.renderedTarget.getWidth() + 0.25F - 0.25F * floatValue;
                byte b9 = 3;
                byte b11 = 10;

                for (int j14 = 0; j14 < b9; j14++) {
                    for (int j15 = 0; j15 < b11; j15++) {
                        matrixStackValue.push();
                        float f44 = this.ghostPhase + (float) j15 * 0.1F;
                        double d35 = d26 + (double) j14 * ((Math.PI * 2) / (double) b9);
                        double d37 = Math.cos(d35 + (double) f44) * (double) f33;
                        double d4 = Math.sin(d35 + (double) f44) * (double) f33;
                        double d6 =
                                Math.sin(d26 + (double) j14) * 0.6
                                        + 0.15 * Math.sin(d26 + (double) ((float) j15 * 0.11F));
                        matrixStackValue.translate(
                                vec3d9.x - vec3d11.x + d37,
                                vec3d9.y
                                        - vec3d11.y
                                        + (double) (this.renderedTarget.getHeight() / 2.0F)
                                        + d6,
                                vec3d9.z - vec3d11.z + d4);
                        matrixStackValue.multiply(
                                RotationAxis.POSITIVE_Y.rotationDegrees(
                                        -client.gameRenderer.getCamera().getYaw()));
                        matrixStackValue.multiply(
                                RotationAxis.POSITIVE_X.rotationDegrees(
                                        client.gameRenderer.getCamera().getPitch()));
                        float f7 = (0.12F + (float) j15 / 40.0F) * 1.25F * floatValue;
                        matrixStackValue.scale(f7, f7, f7);
                        Matrix4f matrix4f5 = matrixStackValue.peek().getPositionMatrix();
                        VertexConsumer bufferValue =
                                immediate.getBuffer(
                                        textureLayer.apply(
                                                Identifier.of(
                                                        "client",
                                                        "textures/visuals/particles_3.png")));
                        drawTexturedQuad(
                                bufferValue,
                                matrix4f5,
                                color14,
                                colorValueValue,
                                k11,
                                j1,
                                (int) (255.0F * floatValue));
                        f7 =
                                (0.12F + (float) j15 / 40.0F)
                                        * 100.0F
                                        * this.glowSizeSetting.getFloat()
                                        / 10.0F
                                        * floatValue;
                        matrixStackValue.scale(f7, f7, f7);
                        VertexConsumer buffer2 =
                                immediate.getBuffer(
                                        textureLayer.apply(
                                                Identifier.of(
                                                        "client",
                                                        "textures/visuals/particles_2.png")));
                        drawTexturedQuad(
                                buffer2,
                                matrix4f5,
                                color14,
                                colorValueValue,
                                k11,
                                j1,
                                (int)
                                        (255.0F
                                                * this.glowStrengthSetting.getFloat()
                                                * 1.0F
                                                * floatValue));
                        matrixStackValue.pop();
                    }
                }
            }

            if (floatValue > 0.001F
                    && this.renderedTarget != null
                    && this.modeSetting.isSelected("Ghosts")
                    && this.ghostTypeSetting.isSelected("3")) {
                long k4 = this.ghostSpeedSetting.getFloat().longValue();
                long nowMillis4 = System.currentTimeMillis();
                if (this.lastFrameMillis == 0L) {
                    this.lastFrameMillis = nowMillis4;
                }

                long j8 = nowMillis4 - this.lastFrameMillis;
                if (j8 > 0L) {
                    this.ghostPhase += (float) (5L * j8) / (float) k4;
                }

                this.lastFrameMillis = nowMillis4;
                int l9 = this.hurtTime(this.renderedTarget);
                float progressValue = (float) Math.sin((double) l9 * (Math.PI / 20));
                int endColor3 = ColorUtils.cachedRgba(255, 100, 100, (int) (255.0F * floatValue));
                int color15 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(0), floatValue),
                                endColor3,
                                progressValue);
                int colorValue2 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(90), floatValue),
                                endColor3,
                                progressValue);
                int l11 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(180), floatValue),
                                endColor3,
                                progressValue);
                int i12 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(360), floatValue),
                                endColor3,
                                progressValue);
                MatrixStack matrixStack2 = render3DEvent.getMatrixStack();
                Vec3d vec3d10 = this.renderedTarget.getLerpedPos(render3DEvent.getTickDelta());
                Vec3d vec3d12 = client.gameRenderer.getCamera().getCameraPos();
                long nowMillis5 = System.currentTimeMillis();
                double d27 = (double) nowMillis5 / (double) k4;
                float f34 = this.renderedTarget.getWidth() + 0.25F - 0.25F * floatValue;
                byte b10 = 3;
                byte b12 = 9;

                for (int k14 = 0; k14 < b10; k14++) {
                    for (int k15 = 0; k15 < b12; k15++) {
                        matrixStack2.push();
                        float f45 = this.ghostPhase + (float) k15 * 0.1F;
                        double d36 = d27 + (double) k14 * ((Math.PI * 2) / (double) b10);
                        double d38 = Math.cos(d36 + (double) f45) * (double) f34;
                        double d40 = Math.sin(d36 + (double) f45) * (double) f34;
                        double d42 =
                                Math.sin(d27) * 0.7
                                        + 0.2 * Math.sin(d27 + (double) ((float) k15 * 0.11F));
                        matrixStack2.translate(
                                vec3d10.x - vec3d12.x + d38,
                                vec3d10.y
                                        - vec3d12.y
                                        + (double) (this.renderedTarget.getHeight() / 2.0F)
                                        + d42,
                                vec3d10.z - vec3d12.z + d40);
                        matrixStack2.multiply(
                                RotationAxis.POSITIVE_Y.rotationDegrees(
                                        -client.gameRenderer.getCamera().getYaw()));
                        matrixStack2.multiply(
                                RotationAxis.POSITIVE_X.rotationDegrees(
                                        client.gameRenderer.getCamera().getPitch()));
                        float f61 = (0.12F + (float) k15 / 50.0F) * 1.5F;
                        matrixStack2.scale(f61, f61, f61);
                        Matrix4f matrix4f6 = matrixStack2.peek().getPositionMatrix();
                        VertexConsumer buffer3 =
                                immediate.getBuffer(
                                        textureLayer.apply(
                                                Identifier.of(
                                                        "client",
                                                        "textures/visuals/particles_3.png")));
                        drawTexturedQuad(
                                buffer3,
                                matrix4f6,
                                color15,
                                colorValue2,
                                l11,
                                i12,
                                (int) (255.0F * floatValue));
                        f61 =
                                (0.12F + (float) k15 / 50.0F)
                                        * 100.0F
                                        * this.glowSizeSetting.getFloat()
                                        / 10.0F;
                        matrixStack2.scale(f61, f61, f61);
                        VertexConsumer buffer4 =
                                immediate.getBuffer(
                                        textureLayer.apply(
                                                Identifier.of(
                                                        "client",
                                                        "textures/visuals/particles_2.png")));
                        drawTexturedQuad(
                                buffer4,
                                matrix4f6,
                                color15,
                                colorValue2,
                                l11,
                                i12,
                                (int)
                                        (255.0F
                                                * this.glowStrengthSetting.getFloat()
                                                * 1.0F
                                                * floatValue));
                        matrixStack2.pop();
                    }
                }
            }

            if (floatValue > 0.001F
                    && this.renderedTarget != null
                    && this.modeSetting.isSelected("Image")) {
                int l4 = this.hurtTime(this.renderedTarget);
                float f1 = (float) Math.sin((double) l4 * (Math.PI / 20));
                this.hurtAnimation.update();
                this.hurtAnimation.animateTo((double) f1, 0.15F, Easings.OUT_SINE);
                int endColor4 = ColorUtils.cachedRgba(185, 80, 80, (int) (255.0F * floatValue));
                int color16 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(0), floatValue),
                                endColor4,
                                this.hurtAnimation.getFloatValue());
                int colorValue3 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(90), floatValue),
                                endColor4,
                                this.hurtAnimation.getFloatValue());
                int i9 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(180), floatValue),
                                endColor4,
                                this.hurtAnimation.getFloatValue());
                int i10 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(360), floatValue),
                                endColor4,
                                this.hurtAnimation.getFloatValue());
                MatrixStack matrixStack3 = render3DEvent.getMatrixStack();
                VertexConsumer buffer5 =
                        immediate.getBuffer(
                                textureLayer.apply(
                                        Identifier.of("client", "textures/visuals/marker.png")));
                Vec3d vec3d7 = this.renderedTarget.getLerpedPos(render3DEvent.getTickDelta());
                double d13 = vec3d7.x;
                double d17 = vec3d7.y;
                double d20 = vec3d7.z;
                Vec3d vec3d13 = client.gameRenderer.getCamera().getCameraPos();
                matrixStack3.push();
                matrixStack3.translate(
                        d13 - vec3d13.x,
                        d17 - vec3d13.y + (double) (this.renderedTarget.getHeight() / 1.75F),
                        d20 - vec3d13.z);
                matrixStack3.multiply(
                        RotationAxis.POSITIVE_Y.rotationDegrees(
                                -client.gameRenderer.getCamera().getYaw()));
                matrixStack3.multiply(
                        RotationAxis.POSITIVE_X.rotationDegrees(
                                client.gameRenderer.getCamera().getPitch()));
                long nowMillis6 = System.currentTimeMillis();
                float f30 =
                        (float)
                                MathUtils.clampBetween(
                                        0.0,
                                        720.0,
                                        (Math.sin(
                                                                (double) nowMillis6
                                                                        / this.imageSpeedSetting
                                                                                .getFloat()
                                                                                .doubleValue())
                                                        + 1.0)
                                                / 2.0
                                                * 360.0
                                                * 2.0);
                matrixStack3.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(f30));
                float f35 =
                        this.imageSizeSetting.getFloat()
                                - this.imageSizeSetting.getFloat()
                                        * 0.4F
                                        * this.hurtAnimation.getFloatValue()
                                + 0.8F
                                - 0.8F * floatValue;
                matrixStack3.scale(f35, f35, 1.0F);
                Matrix4f matrix4f2 = matrixStack3.peek().getPositionMatrix();
                drawTexturedQuad(
                        buffer5,
                        matrix4f2,
                        color16,
                        colorValue3,
                        i9,
                        i10,
                        (int) (255.0F * floatValue));
                matrixStack3.pop();
            }

            if (floatValue > 0.001F
                    && this.renderedTarget != null
                    && this.modeSetting.isSelected("Donut")) {
                int i5 = this.hurtTime(this.renderedTarget);
                float f10 = (float) Math.sin((double) i5 * (Math.PI / 20));
                this.hurtAnimation.update();
                this.hurtAnimation.animateTo((double) f10, 0.1F, Easings.OUT_SINE);
                int endColor5 = ColorUtils.cachedRgba(255, 100, 100, (int) (255.0F * floatValue));
                int color17 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(0), floatValue),
                                endColor5,
                                this.hurtAnimation.getFloatValue());
                int colorValue4 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(90), floatValue),
                                endColor5,
                                this.hurtAnimation.getFloatValue());
                int j9 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(180), floatValue),
                                endColor5,
                                this.hurtAnimation.getFloatValue());
                int j10 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(360), floatValue),
                                endColor5,
                                this.hurtAnimation.getFloatValue());
                MatrixStack matrixStack4 = render3DEvent.getMatrixStack();
                Vec3d vec3d6 = this.renderedTarget.getLerpedPos(render3DEvent.getTickDelta());
                Vec3d vec3d8 = client.gameRenderer.getCamera().getCameraPos();
                double d14 = this.donutSpeedSetting.getFloat().doubleValue();
                double d18 = (double) System.currentTimeMillis() % d14;
                boolean flag1 = d18 > d14 / 2.0;
                double d21 = d18 / (d14 / 2.0);
                d21 = flag1 ? d21 - 1.0 : 1.0 - d21;
                double d25 =
                        d21 < 0.5 ? 2.0 * d21 * d21 : 1.0 - Math.pow(-2.0 * d21 + 2.0, 2.0) / 2.0;
                float height = this.renderedTarget.getHeight();
                float f36 = 0.12F + (float) d25 * Math.max(0.2F, height - 0.24F);
                float f38 = flag1 ? -1.0F : 1.0F;
                double d34 =
                        (double) System.currentTimeMillis()
                                / (this.donutSpeedSetting.getFloat().doubleValue() * 0.55);
                float f41 = this.renderedTarget.getWidth() - 0.15F;
                int i16 = (int) (80.0F * floatValue);

                for (int j16 = 2; j16 >= 0; j16--) {
                    float f53 = floatValue * (1.0F - (float) j16 * 0.28F);
                    float f54 = f36 + f38 * (float) j16 * 0.075F;
                    float f56 = f41 + (float) j16 * 0.025F;

                    for (int k17 = 0; k17 < i16; k17++) {
                        float f59 = (float) k17 / (float) i16;
                        double d43 =
                                (double) (f59 * (float) (Math.PI * 2)) + d34 + (double) j16 * 0.18;
                        double d45 = Math.cos(d43) * (double) f56;
                        double d46 = Math.sin(d43) * (double) f56;
                        float f9 = (0.2F + (float) j16 * 0.018F) * this.donutSizeSetting.getFloat();
                        int alpha = (int) ((float) (j16 == 0 ? 255 : 105) * f53);
                        if (j16 == 0) {
                            matrixStack4.push();
                            matrixStack4.translate(
                                    vec3d6.x - vec3d8.x + d45,
                                    vec3d6.y - vec3d8.y + (double) f54,
                                    vec3d6.z - vec3d8.z + d46);
                            matrixStack4.multiply(
                                    RotationAxis.POSITIVE_Y.rotationDegrees(
                                            -client.gameRenderer.getCamera().getYaw()));
                            matrixStack4.multiply(
                                    RotationAxis.POSITIVE_X.rotationDegrees(
                                            client.gameRenderer.getCamera().getPitch()));
                            matrixStack4.multiply(
                                    RotationAxis.POSITIVE_Z.rotationDegrees(
                                            (float) Math.toDegrees(-d43) + (float) (d34 * 80.0)));
                            matrixStack4.scale(f9 * 1.25F, f9 * 1.25F, f9);
                            drawTexturedQuad(
                                    immediate.getBuffer(
                                            textureLayer.apply(
                                                    Identifier.of(
                                                            "client",
                                                            "textures/visuals/particles_3.png"))),
                                    matrixStack4.peek().getPositionMatrix(),
                                    color17,
                                    colorValue4,
                                    j9,
                                    j10,
                                    alpha);
                            matrixStack4.pop();
                        }
                    }
                }
            }

            if (floatValue > 0.001F
                    && this.renderedTarget != null
                    && this.modeSetting.isSelected("Ring")) {
                int j5 = this.hurtTime(this.renderedTarget);
                float progress3 = (float) Math.sin((double) j5 * (Math.PI / 10));
                int endColor6 = ColorUtils.cachedRgba(255, 100, 100, (int) (255.0F * floatValue));
                double d8 = this.ringSpeedSetting.getFloat().doubleValue();
                double d9 = (double) System.currentTimeMillis() % d8;
                boolean flag = d9 > d8 / 2.0;
                double d11 = d9 / (d8 / 2.0);
                d11 = flag ? d11 - 1.0 : 1.0 - d11;
                double d15 =
                        d11 < 0.5 ? 2.0 * d11 * d11 : 1.0 - Math.pow(-2.0 * d11 + 2.0, 2.0) / 2.0;
                float heightValue = this.renderedTarget.getHeight();
                double d19 =
                        (double) heightValue
                                / 1.7
                                * (d15 > 0.5 ? 1.0 - d15 : d15)
                                * (double) (flag ? -1 : 1)
                                / 0.7;
                MatrixStack matrixStack5 = render3DEvent.getMatrixStack();
                Vec3d vec3d14 = this.renderedTarget.getLerpedPos(render3DEvent.getTickDelta());
                Vec3d vec3d15 = client.gameRenderer.getCamera().getCameraPos();
                matrixStack5.push();
                matrixStack5.translate(
                        vec3d14.x - vec3d15.x, vec3d14.y - vec3d15.y, vec3d14.z - vec3d15.z);
                Matrix4f matrix4f1 = matrixStack5.peek().getPositionMatrix();
                float f32 = this.renderedTarget.getWidth() - 0.1F + 0.35F - 0.35F * floatValue;
                float f37 = (float) ((double) heightValue * d15);
                float f39 = (float) ((double) heightValue * d15 + d19);
                VertexConsumer buffer6 = immediate.getBuffer(FILL_LAYER);

                for (int phase = 0; phase < 360; phase++) {
                    float f42 = (float) Math.toRadians((double) phase);
                    float f46 = (float) Math.toRadians((double) (phase + 1));
                    int color18 =
                            ColorUtils.interpolate(
                                    ColorUtils.scaleAlpha(
                                            ColorUtils.animatedAccent(phase), floatValue),
                                    endColor6,
                                    progress3);
                    int color19 =
                            ColorUtils.interpolate(
                                    ColorUtils.scaleAlpha(
                                            ColorUtils.animatedAccent(phase), floatValue),
                                    endColor6,
                                    progress3);
                    float f55 = (float) (Math.cos((double) f42) * (double) f32);
                    float f57 = (float) (Math.sin((double) f42) * (double) f32);
                    float f58 = (float) (Math.cos((double) f46) * (double) f32);
                    float f60 = (float) (Math.sin((double) f46) * (double) f32);
                    buffer6.vertex(matrix4f1, f55, f37, f57)
                            .color(ColorUtils.withAlpha(color18, (int) (120.0F * floatValue)));
                    buffer6.vertex(matrix4f1, f58, f37, f60)
                            .color(ColorUtils.withAlpha(color19, (int) (120.0F * floatValue)));
                    buffer6.vertex(matrix4f1, f58, f39, f60)
                            .color(ColorUtils.withAlpha(color19, 0));
                    buffer6.vertex(matrix4f1, f55, f39, f57)
                            .color(ColorUtils.withAlpha(color18, 0));
                }

                VertexConsumer buffer7 = immediate.getBuffer(LINE_LAYER);

                for (int l15 = 0; l15 < 360; l15++) {
                    float f47 = (float) Math.toRadians((double) l15);
                    float f51 = (float) Math.toRadians((double) (l15 + 1));
                    int color20 =
                            ColorUtils.scaleAlpha(
                                    ColorUtils.interpolate(
                                            ColorUtils.brighten(ColorUtils.animatedAccent(1), 0.7F),
                                            endColor6,
                                            progress3),
                                    floatValue);
                    buffer7.vertex(
                                    matrix4f1,
                                    (float) (Math.cos((double) f47) * (double) f32),
                                    f37,
                                    (float) (Math.sin((double) f47) * (double) f32))
                            .color(ColorUtils.withAlpha(color20, (int) (150.0F * floatValue)));
                    buffer7.vertex(
                                    matrix4f1,
                                    (float) (Math.cos((double) f51) * (double) f32),
                                    f37,
                                    (float) (Math.sin((double) f51) * (double) f32))
                            .color(ColorUtils.withAlpha(color20, (int) (150.0F * floatValue)));
                }

                matrixStack5.pop();
            }

            if (floatValue > 0.001F
                    && this.renderedTarget != null
                    && this.modeSetting.isSelected("Cubes")) {
                int k5 = this.hurtTime(this.renderedTarget);
                float f12 = (float) Math.sin((double) k5 * (Math.PI / 10));
                this.hurtAnimation.update();
                this.hurtAnimation.animateTo((double) f12, 0.1F, Easings.OUT_SINE);
                int endColor7 = ColorUtils.cachedRgba(255, 100, 100, (int) (255.0F * floatValue));
                int color21 =
                        ColorUtils.interpolate(
                                ColorUtils.scaleAlpha(ColorUtils.animatedAccent(1), floatValue),
                                endColor7,
                                this.hurtAnimation.getFloatValue());
                MatrixStack matrixStack6 = render3DEvent.getMatrixStack();
                Vec3d vec3d3 = client.gameRenderer.getCamera().getCameraPos();
                Vec3d vec3d5 = this.renderedTarget.getLerpedPos(render3DEvent.getTickDelta());
                float f15 =
                        (float) Math.cos((double) System.currentTimeMillis() / 2000.0) * 360.0F
                                + this.hurtAnimation.getFloatValue() * 20.0F;
                byte b3 = 12;
                float f16 = this.renderedTarget.getWidth() * 1.5F;
                float f17 = (1.0F - 0.3F * this.hurtAnimation.getFloatValue()) * floatValue;
                Camera camera3 = client.gameRenderer.getCamera();

                for (byte b4 = 0; b4 < 360; b4 += b3) {
                    float f19 = 0.70000005F;
                    float f23 =
                            (float)
                                    (Math.sin(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b4
                                                                                            + f15))))
                                            * (double) f16
                                            * (double) f19);
                    float f27 =
                            (float)
                                    (Math.cos(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b4
                                                                                            + f15))))
                                            * (double) f16
                                            * (double) f19);
                    double d22 = vec3d5.x + (double) f23;
                    double d28 = vec3d5.z + (double) f27;
                    double d31 =
                            vec3d5.y
                                    + (double) this.renderedTarget.getHeight()
                                            * Math.abs(MathUtils.fastSin((double) b4));
                    matrixStack6.push();
                    matrixStack6.translate(d22 - vec3d3.x, d31 - vec3d3.y, d28 - vec3d3.z);
                    matrixStack6.multiply(camera3.getRotation());
                    float f40 = 0.6F * f17;
                    matrixStack6.scale(f40, f40, f40);
                    drawTexturedQuad(
                            immediate.getBuffer(
                                    textureLayer.apply(
                                            Identifier.of(
                                                    "client", "textures/visuals/particles_1.png"))),
                            matrixStack6.peek().getPositionMatrix(),
                            ColorUtils.scaleAlpha(color21, 0.3F),
                            ColorUtils.scaleAlpha(color21, 0.3F),
                            ColorUtils.scaleAlpha(color21, 0.3F),
                            ColorUtils.scaleAlpha(color21, 0.3F),
                            (int) (floatValue * 0.35F * 255.0F));
                    matrixStack6.pop();
                }

                for (byte b5 = 0; b5 < 360; b5 += b3) {
                    float f20 = 0.70000005F;
                    float f24 =
                            (float)
                                    (Math.sin(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b5
                                                                                            + f15))))
                                            * (double) f16
                                            * (double) f20);
                    float f28 =
                            (float)
                                    (Math.cos(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b5
                                                                                            + f15))))
                                            * (double) f16
                                            * (double) f20);
                    double d23 = vec3d5.x + (double) f24;
                    double d29 = vec3d5.z + (double) f28;
                    double d32 =
                            vec3d5.y
                                    + (double) this.renderedTarget.getHeight()
                                            * Math.abs(MathUtils.fastSin((double) b5));
                    Vec3d vec3d16 = new Vec3d(d23, d32, d29);
                    Vector3f vector3f =
                            new Vector3f(
                                            (float) (vec3d5.x - vec3d16.x),
                                            (float) (vec3d5.y - vec3d16.y),
                                            (float) (vec3d5.z - vec3d16.z))
                                    .normalize();
                    matrixStack6.push();
                    matrixStack6.translate(d23 - vec3d3.x, d32 - vec3d3.y, d29 - vec3d3.z);
                    matrixStack6.multiply(
                            new Quaternionf().rotationTo(new Vector3f(0.0F, 1.0F, 0.0F), vector3f));
                    Matrix4f matrix4f3 = matrixStack6.peek().getPositionMatrix();
                    float f48 = 0.06F * f17;
                    drawCubeFaces(
                            immediate.getBuffer(FILL_LAYER),
                            matrix4f3,
                            f48,
                            ColorUtils.withAlpha(color21, (int) (floatValue * 0.2F * 255.0F)));
                    matrixStack6.pop();
                }

                for (byte b6 = 0; b6 < 360; b6 += b3) {
                    float f21 = 0.70000005F;
                    float f25 =
                            (float)
                                    (Math.sin(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b6
                                                                                            + f15))))
                                            * (double) f16
                                            * (double) f21);
                    float f29 =
                            (float)
                                    (Math.cos(
                                                    (double)
                                                            ((float)
                                                                    Math.toRadians(
                                                                            (double)
                                                                                    ((float) b6
                                                                                            + f15))))
                                            * (double) f16
                                            * (double) f21);
                    double d24 = vec3d5.x + (double) f25;
                    double d30 = vec3d5.z + (double) f29;
                    double d33 =
                            vec3d5.y
                                    + (double) this.renderedTarget.getHeight()
                                            * Math.abs(MathUtils.fastSin((double) b6));
                    Vec3d vec3d17 = new Vec3d(d24, d33, d30);
                    Vector3f vector3f1 =
                            new Vector3f(
                                            (float) (vec3d5.x - vec3d17.x),
                                            (float) (vec3d5.y - vec3d17.y),
                                            (float) (vec3d5.z - vec3d17.z))
                                    .normalize();
                    matrixStack6.push();
                    matrixStack6.translate(d24 - vec3d3.x, d33 - vec3d3.y, d30 - vec3d3.z);
                    matrixStack6.multiply(
                            new Quaternionf()
                                    .rotationTo(new Vector3f(0.0F, 1.0F, 0.0F), vector3f1));
                    Matrix4f matrix4f4 = matrixStack6.peek().getPositionMatrix();
                    float f49 = 0.06F * f17;
                    drawCubeOutline(
                            immediate.getBuffer(LINE_LAYER),
                            matrix4f4,
                            f49,
                            ColorUtils.withAlpha(color21, (int) (floatValue * 255.0F)));
                    matrixStack6.pop();
                }
            }

            immediate.draw();
        }
    }

    private Entity findTarget() {
        if (this.targetModeSetting.isSelected("Raycast")) {
            this.attackedTarget = null;
            this.targetExpiresMillis = 0L;
            if (client.crosshairTarget instanceof EntityHitResult entityhitresult
                    && this.isValidTarget(entityhitresult.getEntity())) {
                return entityhitresult.getEntity();
            }

            return null;
        } else if (this.isTargetType(this.attackedTarget)
                && System.currentTimeMillis() < this.targetExpiresMillis) {
            return this.attackedTarget;
        } else {
            this.attackedTarget = null;
            this.targetExpiresMillis = 0L;
            return null;
        }
    }

    private static void drawCubeOutline(
            VertexConsumer vertexconsumer, Matrix4f matrix4f, float f, int i) {
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
    }

    private int hurtTime(Entity entity) {
        return entity instanceof LivingEntity livingentity ? livingentity.hurtTime : 0;
    }

    private static void drawCubeFaces(
            VertexConsumer vertexconsumer, Matrix4f matrix4f, float f, int i) {
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, f).color(i);
        vertexconsumer.vertex(matrix4f, f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, -f, -f).color(i);
        vertexconsumer.vertex(matrix4f, -f, f, -f).color(i);
        vertexconsumer.vertex(matrix4f, f, f, -f).color(i);
    }

    private boolean isValidTarget(Entity entity) {
        return this.isTargetType(entity) && !entity.isRemoved() && entity.isAlive();
    }
}
