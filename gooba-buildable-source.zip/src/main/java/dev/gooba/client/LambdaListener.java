package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.lang.invoke.LambdaConversionException;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.invoke.MethodType;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

@Environment(EnvType.CLIENT)
public class LambdaListener implements EventListener {
    private final int priority;
    private final boolean isStatic;
    private final Consumer<Object> executor;
    private static final LambdaListener.LookupFactory LOOKUP_FACTORY;
    public final Class<?> owner;
    private final Class<?> target;
    private static final Map<Method, MethodHandle> methodHandleCache = new ConcurrentHashMap<>();

    @Override
    public boolean isStatic() {
        return this.isStatic;
    }

    @Override
    public Class<?> getTarget() {
        return this.target;
    }

    public LambdaListener(
            LambdaListener.Factory factory, Class<?> oclass, Object object, Method method) {
        this.target = method.getParameters()[0].getType();
        this.isStatic = Modifier.isStatic(method.getModifiers());
        this.priority = method.getAnnotation(EventHandler.class).priority();
        this.owner = oclass;

        try {
            this.executor =
                    this.isStatic
                            ? (Consumer) staticLambdaFactory(factory, oclass, method).invoke()
                            : (Consumer)
                                    instanceLambdaFactory(factory, oclass, method)
                                            .invoke((Object) object);
        } catch (Throwable throwable) {
            throw new RuntimeException(throwable);
        }
    }

    @Override
    public int getPriority() {
        return this.priority;
    }

    static {
        LambdaListener.LookupFactory LOOKUP_FACTORYValue;
        try {
            try {
                final Method method =
                        MethodHandles.class.getDeclaredMethod(
                                "privateLookupIn", Class.class, Lookup.class);
                LOOKUP_FACTORYValue =
                        new LambdaListener.LookupFactory(true) {
                            @Override
                            public Lookup getLookup(LambdaListener.Factory factory, Class<?> oclass)
                                    throws ReflectiveOperationException {
                                return factory.create(method, oclass);
                            }
                        };
            } catch (NoSuchMethodException nosuchmethodexception) {
                final Constructor constructor = Lookup.class.getDeclaredConstructor(Class.class);
                constructor.setAccessible(true);
                LOOKUP_FACTORYValue =
                        new LambdaListener.LookupFactory(false) {
                            @Override
                            public Lookup getLookup(LambdaListener.Factory factory, Class<?> oclass)
                                    throws ReflectiveOperationException,
                                            IllegalAccessException,
                                            InstantiationException,
                                            InvocationTargetException {
                                return (Lookup) constructor.newInstance(oclass);
                            }
                        };
            }
        } catch (SecurityException | ReflectiveOperationException reflectiveoperationexception) {
            LOOKUP_FACTORYValue =
                    new LambdaListener.LookupFactory(false) {
                        @Override
                        public Lookup getLookup(LambdaListener.Factory factory, Class<?> oclass) {
                            return MethodHandles.publicLookup().in(oclass);
                        }
                    };
        }

        LOOKUP_FACTORY = LOOKUP_FACTORYValue;
    }

    public static boolean requireLambdaFactoryRegistration() {
        return LOOKUP_FACTORY.requireLambdaFactory;
    }

    @Override
    public void call(Object object) {
        this.executor.accept(object);
    }

    private static MethodHandle instanceLambdaFactory(
            LambdaListener.Factory factory, Class<?> oclass, Method method)
            throws Throwable,
                    IllegalAccessException,
                    InstantiationException,
                    NoSuchMethodException,
                    LambdaConversionException,
                    InvocationTargetException {
        MethodHandle methodhandle = methodHandleCache.get(method);
        if (methodhandle != null) {
            return methodhandle;
        } else {
            String name = method.getName();
            Lookup lookup = LOOKUP_FACTORY.getLookup(factory, oclass);
            MethodType methodtype =
                    MethodType.methodType(void.class, method.getParameters()[0].getType());
            MethodHandle methodHandle = lookup.findVirtual(oclass, name, methodtype);
            MethodType methodType = MethodType.methodType(Consumer.class, oclass);
            methodhandle =
                    LambdaMetafactory.metafactory(
                                    lookup,
                                    "accept",
                                    methodType,
                                    MethodType.methodType(void.class, Object.class),
                                    methodHandle,
                                    methodtype)
                            .getTarget();
            methodHandleCache.put(method, methodhandle);
            return methodhandle;
        }
    }

    private static MethodHandle staticLambdaFactory(
            LambdaListener.Factory factory, Class<?> oclass, Method method)
            throws Throwable,
                    IllegalAccessException,
                    InstantiationException,
                    NoSuchMethodException,
                    LambdaConversionException,
                    InvocationTargetException {
        String name = method.getName();
        Lookup lookup = LOOKUP_FACTORY.getLookup(factory, oclass);
        MethodType methodtype =
                MethodType.methodType(void.class, method.getParameters()[0].getType());
        MethodHandle methodhandle = lookup.findStatic(oclass, name, methodtype);
        MethodType methodType = MethodType.methodType(Consumer.class);
        return LambdaMetafactory.metafactory(
                        lookup,
                        "accept",
                        methodType,
                        MethodType.methodType(void.class, Object.class),
                        methodhandle,
                        methodtype)
                .getTarget();
    }

    @Environment(EnvType.CLIENT)
    public interface Factory {
        Lookup create(Method method, Class<?> oclass) throws ReflectiveOperationException;
    }

    @Environment(EnvType.CLIENT)
    private abstract static class LookupFactory {
        public final boolean requireLambdaFactory;

        public abstract Lookup getLookup(LambdaListener.Factory factory, Class<?> oclass)
                throws ReflectiveOperationException,
                        IllegalAccessException,
                        InstantiationException,
                        InvocationTargetException;

        public LookupFactory(boolean requireLambdaFactoryValue) {
            this.requireLambdaFactory = requireLambdaFactoryValue;
        }
    }
}
