package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public final class EnchantmentInventoryUtils implements MinecraftAccess {

    public static void selectHotbarSlot(int i) {
        if (client.player != null && client.interactionManager != null && i >= 0 && i <= 8) {
            if (client.player.getInventory().getSelectedSlot() != i) {
                client.player.getInventory().setSelectedSlot(i);
                client.interactionManager.syncSelectedSlot();
            }
        }
    }

    private EnchantmentInventoryUtils() {}

    public static int findBestEnchantedSlot(
            Predicate<ItemStack> predicate, RegistryKey<Enchantment> registrykey) {
        if (client.player == null) {
            return -1;
        } else {
            int i = -1;
            int j = 0;

            for (int k = 0; k < 9; k++) {
                ItemStack itemstack = client.player.getInventory().getStack(k);
                if (predicate.test(itemstack)) {
                    int l = enchantmentLevel(itemstack, registrykey);
                    if (l > j) {
                        i = k;
                        j = l;
                    }
                }
            }

            return i;
        }
    }

    public static int enchantmentLevel(ItemStack itemstack, RegistryKey<Enchantment> registrykey) {
        return client.world != null && !itemstack.isEmpty()
                ? client.world
                        .getRegistryManager()
                        .getOptional(RegistryKeys.ENCHANTMENT)
                        .flatMap(registry -> registry.getEntry(registrykey.getValue()))
                        .map(reference -> EnchantmentHelper.getLevel(reference, itemstack))
                        .orElse(0)
                : 0;
    }
}
