package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.packet.Packet;

@Environment(EnvType.CLIENT)
public class PacketEvent extends CancellableEvent {
    private Packet<?> packet;
    private PacketEvent.Type type;

    public PacketEvent.Type getType() {
        return this.type;
    }

    public PacketEvent(Packet<?> packet, PacketEvent.Type typeValue) {
        this.packet = packet;
        this.type = typeValue;
    }

    public boolean isSend() {
        return this.type.equals(PacketEvent.Type.SEND);
    }

    public void setPacket(Packet<?> packet) {
        this.packet = packet;
    }

    public void setType(PacketEvent.Type typeValue) {
        this.type = typeValue;
    }

    public Packet<?> getPacket() {
        return this.packet;
    }

    @Environment(EnvType.CLIENT)
    public static enum Type {
        SEND,
        RECEIVE;
    }
}
