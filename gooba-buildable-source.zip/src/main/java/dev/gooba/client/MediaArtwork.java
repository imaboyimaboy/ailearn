package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImage.Format;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.util.Arrays;

import javax.imageio.ImageIO;

@Environment(EnvType.CLIENT)
public final class MediaArtwork {

    private static byte[] previousPng = new byte[0];
    private static volatile boolean available;
    public static final Identifier TEXTURE_ID = Identifier.of("client", "media/artwork");

    private static volatile int artworkColor = -1;

    private MediaArtwork() {}

    public static void setArtwork(byte[] abyte) throws CloneNotSupportedException {
        if (abyte == null) {
            abyte = new byte[0];
        }

        if (!Arrays.equals(abyte, previousPng)) {
            previousPng = (byte[]) abyte.clone();
            if (abyte.length == 0) {
                available = false;
                artworkColor = -1;
            } else {
                byte[] abyteValue = abyte;
                MinecraftClient.getInstance().execute(() -> upload(abyteValue));
            }
        }
    }

    private static int averageColor(BufferedImage bufferedimage) {
        long i = 0L;
        long j = 0L;
        long k = 0L;
        long l = 0L;
        int width = bufferedimage.getWidth();
        int height = bufferedimage.getHeight();

        for (int k1 = 0; k1 < height; k1++) {
            for (int l1 = 0; l1 < width; l1++) {
                int rGB = bufferedimage.getRGB(l1, k1);
                if (rGB >>> 24 != 0) {
                    i += (long) (rGB >> 16 & 0xFF);
                    j += (long) (rGB >> 8 & 0xFF);
                    k += (long) (rGB & 0xFF);
                    l++;
                }
            }
        }

        if (l == 0L) {
            return -1;
        } else {
            int j2 = Math.min(255, (int) (i / l) + 50);
            int k2 = Math.min(255, (int) (j / l) + 50);
            int l2 = Math.min(255, (int) (k / l) + 50);
            return 0xFF000000 | j2 << 16 | k2 << 8 | l2;
        }
    }

    public static void reset() {
        previousPng = new byte[0];
        available = false;
        artworkColor = -1;
    }

    private static void upload(byte[] abyte) {
        label37:
        {
            BufferedImage bufferedimage;
            try {
                bufferedimage = ImageIO.read(new ByteArrayInputStream(abyte));
            } catch (Exception exceptionValue) {
                break label37;
            }

            try {
                if (bufferedimage == null) {
                    available = false;
                    return;
                }

                artworkColor = averageColor(bufferedimage);
                int width = bufferedimage.getWidth();
                int height = bufferedimage.getHeight();
                NativeImage nativeimage = new NativeImage(Format.RGBA, width, height, false);

                for (int k = 0; k < height; k++) {
                    for (int l = 0; l < width; l++) {
                        nativeimage.setColorArgb(l, k, bufferedimage.getRGB(l, k));
                    }
                }

                NativeImageBackedTexture nativeimagebackedtexture =
                        new NativeImageBackedTexture(() -> TEXTURE_ID.toString(), nativeimage);
                nativeimagebackedtexture.upload();
                MinecraftClient.getInstance()
                        .getTextureManager()
                        .registerTexture(TEXTURE_ID, nativeimagebackedtexture);
                available = true;
                return;
            } catch (Exception exception) {
            }
        }

        available = false;
    }

    public static boolean isAvailable() {
        return available;
    }
}
