package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.Screen;

@Environment(EnvType.CLIENT)
public class MouseReleaseEvent extends Event {
    private final int button;
    private final Screen screen;
    private final double mouseY;
    private final double mouseX;

    public MouseReleaseEvent(
            double mouseXValue, double mouseYValue, int buttonValue, Screen screen) {
        this.mouseX = mouseXValue;
        this.mouseY = mouseYValue;
        this.button = buttonValue;
        this.screen = screen;
    }

    public double getMouseY() {
        return this.mouseY;
    }

    public Screen getScreen() {
        return this.screen;
    }

    public double getMouseX() {
        return this.mouseX;
    }

    public int getButton() {
        return this.button;
    }
}
