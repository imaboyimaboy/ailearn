package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum RotationMode {
    UNIVERSAL("Universal", new UniversalRotationMode()),
    GRIM("Grim", new GrimRotationMode()),
    SNAP("Snap", new SnapRotationMode()),
    NEURO("Neuro", new NeuroRotationMode()),
    HVH("HvH", new HvhRotationMode());
    private final RotationModeHandler rotationModeHandler;
    private final String name;

    public RotationModeHandler getRotationModeHandler() {
        return this.rotationModeHandler;
    }

    private RotationMode(String nameValue, RotationModeHandler rotationModeHandler2) {
        this.name = nameValue;
        this.rotationModeHandler = rotationModeHandler2;
    }

    public String getName() {
        return this.name;
    }
}
