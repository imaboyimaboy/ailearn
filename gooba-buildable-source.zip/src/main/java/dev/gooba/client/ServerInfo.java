package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public final class ServerInfo implements MinecraftAccess {
    public static long lastTimePacketNanos;
    private static final ElapsedTimer combatTimer = new ElapsedTimer();
    public static String serverAddress = "Local";
    public static boolean combatEnding;
    public static float ticksPerSecond = 20.0F;

    static {
    }

    private static boolean hasCombatBossBar() {
        return client.inGameHud.getBossBarHud().bossBars.values().stream()
                .map(clientbossbar -> clientbossbar.getName().getString().toLowerCase())
                .anyMatch(text -> text.contains("pvp"));
    }

    private ServerInfo() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static boolean isInCombat() {
        return !combatTimer.hasElapsed(500.0);
    }

    public static boolean isNotInWorld() {
        return client.player == null || client.world == null;
    }

    public static String getDimensionName() {
        return client.world.getRegistryKey().getValue().getPath();
    }

    public static void updateTickRate(PacketEvent packetEvent) {
        if (packetEvent.getPacket() instanceof WorldTimeUpdateS2CPacket) {
            long nowNanos = System.nanoTime();
            float f = 20.0F * (1.0E9F / (float) (nowNanos - lastTimePacketNanos));
            ticksPerSecond = MathHelper.clamp(f, 0.0F, 20.0F);
            lastTimePacketNanos = nowNanos;
        }
    }

    public static void update() {
        serverAddress = getServerAddress();
        combatEnding = isCombatEnding();
        if (hasCombatBossBar()) {
            combatTimer.reset();
        }
    }

    private static String getServerAddress() {
        return !isNotInWorld()
                        && client.getNetworkHandler() != null
                        && client.getNetworkHandler().getServerInfo() != null
                ? client.getNetworkHandler().getServerInfo().address.toLowerCase()
                : "Vanilla";
    }

    private static boolean isCombatEnding() {
        return client.inGameHud.getBossBarHud().bossBars.values().stream()
                .map(clientbossbar -> clientbossbar.getName().getString().toLowerCase())
                .anyMatch(
                        text -> text.contains("pvp") && (text.contains("0") || text.contains("1")));
    }
}
