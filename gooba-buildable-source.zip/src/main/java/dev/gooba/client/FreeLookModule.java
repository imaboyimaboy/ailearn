package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.option.Perspective;

import org.lwjgl.glfw.GLFW;

@ModuleInfo(
        name = "Free Look",
        desc = "Lets you rotate the camera without changing your movement direction",
        category = ModuleCategory.PLAYER)
@Environment(EnvType.CLIENT)
public class FreeLookModule extends Module {
    public ModeSetting modeSetting = new ModeSetting(this, "Mode", new String[] {"Hold", "Toggle"});
    public KeybindSetting freeLookKeySetting = new KeybindSetting(this, "Free Look Key", -1);
    private boolean active;

    private void activateFreeLook() {
        if (client.player != null) {
            this.active = true;
            RotationStateManager.yaw = client.player.getYaw();
            RotationStateManager.pitch = client.player.getPitch();
            RotationStateManager.freeLookLocked = true;
            RotationStateManager.cameraOverride = true;
            client.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        }
    }

    private void deactivateFreeLook() {
        this.active = false;
        RotationStateManager.freeLookLocked = false;
        AttackAuraModule attackAuraModule = AttackAuraModule.getInstance();
        if (attackAuraModule == null || !attackAuraModule.isEnabled()) {
            RotationStateManager.cameraOverride = false;
        }

        if (client.options != null) {
            client.options.setPerspective(Perspective.FIRST_PERSON);
        }
    }

    @EventHandler
    public void onKeyPress(KeyPressEvent keyPressEvent) {
        int cachedKeyCode = this.freeLookKeySetting.getCachedKeyCode();
        if (cachedKeyCode > 0 && keyPressEvent.getKey() == cachedKeyCode) {
            if (this.modeSetting.isSelected("Toggle")) {
                if (this.active) {
                    this.deactivateFreeLook();
                } else {
                    this.activateFreeLook();
                }
            } else if (!this.active) {
                this.activateFreeLook();
            }
        }
    }

    @Override
    public void onDisable() {
        if (this.active) {
            this.deactivateFreeLook();
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        int cachedKeyCode = this.freeLookKeySetting.getCachedKeyCode();
        if (cachedKeyCode <= 0) {
            if (this.active) {
                this.deactivateFreeLook();
            }
        } else {
            if (this.modeSetting.isSelected("Hold")) {
                boolean flagx =
                        client.getWindow() != null
                                && GLFW.glfwGetKey(client.getWindow().getHandle(), cachedKeyCode)
                                        == 1;
                if (flagx && !this.active) {
                    this.activateFreeLook();
                } else if (!flagx && this.active) {
                    this.deactivateFreeLook();
                }
            }

            if (this.active) {
                RotationStateManager.cameraOverride = true;
            }
        }
    }
}
