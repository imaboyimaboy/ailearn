package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Map.Entry;

@Environment(EnvType.CLIENT)
public class KeybindsHud implements HudElement {
    private final Map<Module, String> keyLabels;
    private final EasingAnimation visibilityAnimation = createAnimation(0.0F);
    private final Map<Module, EasingAnimation> positionAnimations;
    private final EasingAnimation widthAnimation = new EasingAnimation().resetValue(0.0F);
    private final EasingAnimation heightAnimation = new EasingAnimation().resetValue(15.0F);
    private final Map<Module, EasingAnimation> moduleAnimations = new IdentityHashMap<>();

    private static boolean shouldDisplay(Module module, boolean flag) {
        return module.getKey() > 0
                && !module.getName().equalsIgnoreCase("ClickGui")
                && (module.isEnabled() || flag);
    }

    private String keyLabel(Module module) {
        return this.keyLabels.getOrDefault(module, KeyCode.displayName(module.getKey()));
    }

    public KeybindsHud() {
        this.positionAnimations = new IdentityHashMap<>();
        this.keyLabels = new IdentityHashMap<>();
    }

    @Override
    public void render(PositionSetting positionSetting2, HUDModule hUDModule) {
        float f = hUDModule.hudSizeSetting.getFloat();
        float innerX = positionSetting2.position.x;
        float innerY = positionSetting2.position.y;
        boolean flag = false;
        ArrayList arraylist = new ArrayList();

        for (Module module : Gooba.getInstance().getModuleRegistry().values()) {
            if (shouldDisplay(module, hUDModule.alwaysShowSetting.isOn())) {
                EasingAnimation easingAnimation2 =
                        this.moduleAnimations.computeIfAbsent(
                                module, module6 -> new EasingAnimation().resetValue(0.0F));
                easingAnimation2.approach(1.0F, 2.5F);
                this.keyLabels.put(module, KeyCode.displayName(module.getKey()));
                flag = true;
                arraylist.add(module);
            }
        }

        for (Entry entry : new ArrayList<>(this.moduleAnimations.entrySet())) {
            if (!shouldDisplay((Module) entry.getKey(), hUDModule.alwaysShowSetting.isOn())) {
                float f39 = ((EasingAnimation) entry.getValue()).approach(0.0F, 2.5F);
                if (f39 > 0.001F) {
                    arraylist.add((Module) entry.getKey());
                }
            }
        }

        arraylist.sort(Comparator.comparing(Module::getBigName, String.CASE_INSENSITIVE_ORDER));
        float f37 = 0.0F;
        float f38 =
                16.0F
                        + Fonts.INTER_SEMIBOLD.measureWidth("  ", 7.5F)
                        + Fonts.INTER_SEMIBOLD.measureVisibleWidth("Keybinds", 7.5F);
        float f40 = 0.0F;

        for (Module moduleValue : (Iterable<Module>) (Iterable) arraylist) {
            float floatValue = this.moduleAnimations.get(moduleValue).getFloatValue();
            f37 += 14.0F * floatValue;
            float f4 = Fonts.INTER_SEMIBOLD.measureVisibleWidth(moduleValue.getBigName(), 7.2F);
            float f5 = Fonts.INTER_SEMIBOLD.measureVisibleWidth(this.keyLabel(moduleValue), 7.2F);
            float f6 = 22.0F + f4 + 0.5F + 8.0F + f5;
            f40 = Math.max(f40, f6);
        }

        float target = Math.max(f38, f40);
        float targetValue = 15.0F + f37;
        boolean flag1;
        flag1 =
                !(!hUDModule.alwaysShowSetting.isOn()
                        && !flag
                        && !(f37 > 0.001F)
                        && !(client.currentScreen instanceof ChatScreen));

        if (flag1 && this.visibilityAnimation.getFloatValue() <= 0.001F) {
            this.widthAnimation.resetValue(target);
            this.heightAnimation.resetValue(targetValue);
        }

        float factor = animate(this.visibilityAnimation, flag1 ? 1.0F : 0.0F);
        if (!flag1 && !(factor > 0.01F)) {
            positionSetting2.visible = false;
        } else {
            positionSetting2.visible = true;
        }

        if (factor <= 0.01F) {
            this.removeHiddenModules(hUDModule.alwaysShowSetting.isOn());
            positionSetting2.size.set(f38 * f, 15.0F * f);
        } else {
            float f44 = this.widthAnimation.approach(target, 2.5F) * f;
            float f45 = this.heightAnimation.approach(targetValue, 2.5F) * f;
            float height = 15.0F * f;
            float f8 = 4.0F * f;
            String stringValue = "C";
            float size = 7.5F * f;
            float f10 = Fonts.INTER_SEMIBOLD.measureWidth("  ", 7.5F * f);
            float width7 =
                    16.0F * f
                            + f10
                            + Fonts.INTER_SEMIBOLD.measureVisibleWidth("Keybinds", 7.5F * f);
            hUDModule.drawBackground(innerX, innerY, width7, height, f8, factor);
            float f12 = innerX + 4.0F * f;
            Font font = Fonts.GOOBA_ICONS;
            float f46 = Fonts.GOOBA_ICONS.centerTextX(stringValue, f12, 8.0F * f, size);
            float f47 = Fonts.GOOBA_ICONS.centerTextY(stringValue, innerY, height, size);
            hUDModule.getAccentColor(factor);
            font.drawText(stringValue, f46, f47, size);
            float f13 = f12 + 8.0F * f + f10;
            float width = Fonts.INTER_SEMIBOLD.measureVisibleWidth("Keybinds", 7.5F * f);
            float f15 = Fonts.INTER_SEMIBOLD.centerTextX("Keybinds", f13, width, 7.5F * f);
            float f16 = centerTextY(innerY, height, 7.5F * f);
            font = Fonts.INTER_SEMIBOLD;
            float sizeValue = 7.5F * f;
            ColorUtils.multiplyAlpha(-657931, factor);
            font.drawText("Keybinds", f15, f16, sizeValue);
            float innerYValue = innerY + height;

            for (Module module3 : (Iterable<Module>) (Iterable) arraylist) {
                float floatValueValue = this.moduleAnimations.get(module3).getFloatValue();
                if (!(floatValueValue <= 0.001F)) {
                    float f19 = 13.5F * floatValueValue * f;
                    float factorValue = factor * floatValueValue;
                    float progress =
                            this.positionAnimations
                                    .computeIfAbsent(
                                            module3,
                                            module6 -> new EasingAnimation().resetValue(0.0F))
                                    .approach(module3.isEnabled() ? 1.0F : 0.0F, 2.5F);
                    int color =
                            ColorUtils.interpolateAwt(
                                    -6645085, hUDModule.getAccentColor(1.0F), progress);
                    int startColor = hUDModule.getTintedBackgroundColor();
                    int colorValue =
                            ColorUtils.interpolateAwt(
                                    startColor, hUDModule.getAccentColor(1.0F), progress * 0.3F);
                    colorValue = startColor & 0xFF000000 | colorValue & 16777215;
                    innerYValue += 0.5F * floatValueValue * f;
                    float f22 = (1.0F - floatValueValue) * 8.0F * f;
                    innerX += f22;
                    String bigName = module3.getBigName();
                    String string = this.keyLabel(module3);
                    float size5 = 7.2F * f;
                    float size6 = 7.2F * f;
                    float widthValue = 13.5F * f;
                    float innerXValue = innerX + widthValue + 0.5F * f;
                    float width10 = Fonts.INTER_SEMIBOLD.measureVisibleWidth(bigName, size5);
                    float width8 = 8.0F * f + width10;
                    float innerX2 = innerXValue + width8 + 0.5F * f;
                    float width11 = Fonts.INTER_SEMIBOLD.measureVisibleWidth(string, size6);
                    float width9 = 8.0F * f + width11;
                    hUDModule.drawBackground(
                            innerX, innerYValue, widthValue, 13.5F * f, f8, factorValue);
                    hUDModule.drawBackground(
                            innerXValue, innerYValue, width8, 13.5F * f, f8, factorValue);
                    hUDModule.drawTintedBlur(
                            innerX2, innerYValue, width9, 13.5F * f, f8, factorValue, colorValue);
                    float f32 = centerTextY(innerYValue, 13.5F * f, size5);
                    float f33 = centerTextY(innerYValue, 13.5F * f, size6);
                    String icon = module3.getCategory().getIcon();
                    Font fontValue =
                            module3.getCategory() == ModuleCategory.DONUT
                                    ? Fonts.DONUT_ICON
                                    : Fonts.CATEGORY_ICONS;
                    float size7 = 7.5F * f;
                    f46 = fontValue.centerTextX(icon, innerX, widthValue, size7);
                    f47 = fontValue.centerTextY(icon, innerYValue, 13.5F * f, size7);
                    hUDModule.getAccentColor(factorValue);
                    fontValue.drawText(icon, f46, f47, size7);
                    float f35 =
                            Fonts.INTER_SEMIBOLD.centerTextX(
                                    bigName, innerXValue + 4.0F * f, width10, size5);
                    font = Fonts.INTER_SEMIBOLD;
                    ColorUtils.multiplyAlpha(-657931, factorValue);
                    font.drawText(bigName, f35, f32, size5);
                    float f36 =
                            Fonts.INTER_SEMIBOLD.centerTextX(
                                    string, innerX2 + 4.0F * f, width11, size6);
                    font = Fonts.INTER_SEMIBOLD;
                    ColorUtils.multiplyAlpha(color, factorValue);
                    font.drawText(string, f36, f33, size6);
                    innerX -= f22;
                    innerYValue += f19;
                }
            }

            this.removeHiddenModules(hUDModule.alwaysShowSetting.isOn());
            positionSetting2.size.set(f44, f45);
        }
    }

    private static float animate(EasingAnimation easingAnimation2, float f) {
        easingAnimation2.animateTo((double) f, 0.3F, Easings.OUT_EXPO, true);
        easingAnimation2.update();
        return easingAnimation2.getFloatValue();
    }

    private void removeHiddenModules(boolean flag) {
        this.moduleAnimations
                .entrySet()
                .removeIf(
                        entry -> {
                            boolean flag1;
                            flag1 =
                                    (!shouldDisplay(entry.getKey(), flag)
                                            && entry.getValue().getFloatValue() <= 0.001F);

                            if (flag1) {
                                this.keyLabels.remove(entry.getKey());
                                this.positionAnimations.remove(entry.getKey());
                            }

                            return flag1;
                        });
    }

    private static float centerTextY(float f, float height, float size) {
        return Fonts.INTER_SEMIBOLD.centerTextY("Ag09:", f, height, size) + 0.45F * size / 7.2F;
    }

    private static EasingAnimation createAnimation(float f) {
        return new EasingAnimation()
                .setCurrentValue((double) f)
                .setStartValue((double) f)
                .setTargetValue((double) f)
                .setDurationMillis(1.0);
    }
}
