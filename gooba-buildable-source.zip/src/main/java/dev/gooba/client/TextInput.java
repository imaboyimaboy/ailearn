package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class TextInput {
    private final EasingAnimation focusAnimation;
    private String text;
    private final float inset;
    private String placeholder = "";

    public TextInput(float insetValue) {
        this.text = "";
        this.focusAnimation = new EasingAnimation();
        this.inset = insetValue;
    }

    public TextInput() {
        this(4.0F);
    }
}
