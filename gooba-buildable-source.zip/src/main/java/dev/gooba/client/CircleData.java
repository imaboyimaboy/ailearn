package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import java.nio.ByteBuffer;

@Environment(EnvType.CLIENT)
public class CircleData extends UniformBatchRenderer {

    private static final Identifier FRAGMENT_SHADER =
            Identifier.of("client", "core/circle_progress");
    private static final Identifier VERTEX_SHADER = Identifier.of("client", "core/circle_progress");
    private static final Identifier PIPELINE_ID =
            Identifier.of("client", "pipeline/circle_progress");

    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(CircleData.PIPELINE_ID)
                            .withVertexShader(VERTEX_SHADER)
                            .withFragmentShader(FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("CircleData", UniformType.UNIFORM_BUFFER)
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());

    public void drawCircle(float centerX, float centerY, float radius, int color) {
        if (!(radius <= 0.0F)) {
            this.drawProgressArc(centerX, centerY, 0.001F, radius * 2.0F, 0.5F, color);
        }
    }

    @Override
    public int getSortOrder() {
        return 0;
    }

    public void drawProgressArc(
            float centerX,
            float centerY,
            float radius,
            float thickness,
            float progress,
            int color) {
        if (!(radius <= 0.0F) && !(thickness <= 0.0F)) {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (minecraftclient.getFramebuffer() != null) {
                ByteBuffer bytebuffer = this.beginInstance();
                float f5 = thickness * 0.75F + 1.0F;
                float f6 = (radius + f5) * 2.0F;
                float f7 = centerX - f6 / 2.0F;
                float f8 = centerY - f6 / 2.0F;
                bytebuffer.putFloat(f7);
                bytebuffer.putFloat(f8);
                bytebuffer.putFloat(f6);
                bytebuffer.putFloat(f6);
                bytebuffer.putFloat(radius + f5);
                bytebuffer.putFloat(radius);
                bytebuffer.putFloat(thickness);
                bytebuffer.putFloat(Math.max(0.0F, Math.min(1.0F, progress)));
                bytebuffer.putFloat((float) (color >> 16 & 0xFF) / 255.0F);
                bytebuffer.putFloat((float) (color >> 8 & 0xFF) / 255.0F);
                bytebuffer.putFloat((float) (color & 0xFF) / 255.0F);
                bytebuffer.putFloat((float) (color >> 24 & 0xFF) / 255.0F);
                bytebuffer.putFloat(0.0F);
                bytebuffer.putFloat(0.0F);
                bytebuffer.putFloat(0.0F);
                bytebuffer.putFloat(0.0F);
                this.finishInstance();
            }
        }
    }

    public CircleData() {
        super("circle_progress", PIPELINE, "CircleData", 64, 64, 32);
    }
}
