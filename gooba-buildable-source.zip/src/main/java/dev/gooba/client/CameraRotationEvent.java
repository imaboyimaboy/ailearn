package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class CameraRotationEvent extends Event {
    public float yaw;
    public float pitch;
    public float partialTicks;

    public float getYaw() {
        return this.yaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setPartialTicks(float partialTicksValue) {
        this.partialTicks = partialTicksValue;
    }

    public void setPitch(float pitchValue) {
        this.pitch = pitchValue;
    }

    public void setYaw(float yawValue) {
        this.yaw = yawValue;
    }

    public float getPartialTicks() {
        return this.partialTicks;
    }

    public CameraRotationEvent(float yawValue, float pitchValue, float partialTicksValue) {
        this.yaw = yawValue;
        this.pitch = pitchValue;
        this.partialTicks = partialTicksValue;
    }
}
