package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Floating Hands",
        category = ModuleCategory.OTHER,
        desc = "Alters the position, scale, and rotation of your hands.")
@Environment(EnvType.CLIENT)
public class FloatingHandsModule extends Module {}
