package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.math.Vec3d;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

@ModuleInfo(name = "Speed", desc = "Increases your movement speed", category = ModuleCategory.OTHER)
@Environment(EnvType.CLIENT)
public class SpeedModule extends Module {
    public float movementMultiplier;
    private int correctionSequence;

    public SliderSetting speedSetting;
    public ModeSetting modeSetting =
            new ModeSetting(this, "Mode", new String[] {"Vanilla", "Meta"});
    public Stopwatch stopwatch;

    @EventHandler
    public void onPacket(PacketEvent packetEvent) {
        if (this.modeSetting.isSelected("RW")
                && packetEvent.getPacket() instanceof PlayerPositionLookS2CPacket
                && this.correctionSequence % 2 == 1) {
            this.correctionSequence++;
        }
    }

    private void resetMovementState(boolean flag) {
        this.correctionSequence = 0;

        if (flag) {
            client.player.speed = 0.0F;
        }
    }

    @EventHandler
    public void onMovementInput(MovementInputEvent movementInputEvent) {}

    public SpeedModule() {
        this.speedSetting =
                new SliderSetting(this, "Speed", 1.0F, 0.3F, 2.0F, 0.1F)
                        .visibleWhen(() -> this.modeSetting.isSelected("Vanilla"));
        this.correctionSequence = 0;

        this.movementMultiplier = 1.0F;
        this.stopwatch = new Stopwatch();
    }

    @Override
    public void onEnable() {
        this.resetMovementState(true);
        super.onEnable();
    }

    private double[] horizontalDirectionTo(Vec3d vec3d, Vec3d vec3d1, double d0) {
        double d1 = vec3d1.x - vec3d.x;
        double d2 = vec3d1.z - vec3d.z;
        double d3 = Math.sqrt(d1 * d1 + d2 * d2);
        return d3 == 0.0 ? new double[] {0.0, 0.0} : new double[] {d1 / d3 * d0, d2 / d3 * d0};
    }

    @Override
    public void onDisable() {
        if (client.getRenderTickCounter() instanceof TickSpeedAccess tickSpeedAccess) {
            tickSpeedAccess.setSpeed(1.0F);
        }

        this.resetMovementState(true);
        TickRateState.multiplier = 20.0F;
        super.onDisable();
    }

    @EventHandler
    public void onPlayerMotion(PlayerMotionEvent playerMotionEvent) {
        if (client.player != null && client.world != null) {
            if (this.modeSetting.isSelected("Grim Box") && !client.player.isSubmergedInWater()) {
                double d0 = 0.02F;
                if (d0 <= 0.0) {
                    return;
                }

                Entity entity = null;
                double MAX_VALUE = Double.MAX_VALUE;
                double d2 = 0.1F;

                for (Entity entityValue : client.world.getEntities()) {
                    if (entityValue != client.player) {
                        if (entityValue == AttackAuraModule.target) {
                            double d3 = entityValue.getX() - client.player.getX();
                            double d4 = entityValue.getZ() - client.player.getZ();
                            double MAX_VALUEValue = d3 * d3 + d4 * d4;
                            if (MAX_VALUEValue <= d2 && MAX_VALUEValue < MAX_VALUE) {
                                MAX_VALUE = MAX_VALUEValue;
                                entity = entityValue;
                            }
                        }

                        if (entity != null) {
                            double[] adouble =
                                    this.horizontalDirectionTo(
                                            client.player.getEntityPos(),
                                            entity.getEntityPos(),
                                            d0);
                            client.player.addVelocity(adouble[0], 0.0, adouble[1]);
                        }
                    }
                }
            }

            if (this.modeSetting.isSelected("Meta")) {
                if (client.player.hasStatusEffect(StatusEffects.SLOWNESS)) {
                    return;
                }

                String string = client.player.getOffHandStack().getName().getString();
                byte[] abyte = string.getBytes(StandardCharsets.UTF_8);
                String text = Arrays.toString(abyte);
                boolean flag2 = text.equals("[-48, -88, -48, -80, -47, -128, 32, 75, 73, 78, 71]");
                boolean flag =
                        text.equals(
                                "[-48, -94, -48, -72, -48, -77, -47, -128, -48, -72, -48, -67, -48,"
                                    + " -67, -48, -80, -47, -113, 32, -48, -77, -48, -66, -48, -69,"
                                    + " -48, -66, -48, -78, -48, -80]");
                StatusEffectInstance statuseffectinstance =
                        client.player.getStatusEffect(StatusEffects.SPEED);
                boolean hasStatusEffect = client.player.hasStatusEffect(StatusEffects.SPEED);
                boolean isOnGround = client.player.isOnGround();
                float fallDistance = (float) client.player.fallDistance;
                if (hasStatusEffect
                        && statuseffectinstance != null
                        && statuseffectinstance.getAmplifier() == 2
                        && fallDistance <= 0.2F
                        && !isOnGround) {
                    MovementUtils.setHorizontalSpeed(flag2 ? 0.72F : (flag ? 0.7F : 0.58F));
                } else if (hasStatusEffect
                        && statuseffectinstance != null
                        && statuseffectinstance.getAmplifier() == 2
                        && isOnGround) {
                    MovementUtils.setHorizontalSpeed(flag2 ? 0.5 : (flag ? 0.49F : 0.42F));
                } else if (hasStatusEffect
                        && statuseffectinstance != null
                        && statuseffectinstance.getAmplifier() == 3
                        && fallDistance <= 0.2F
                        && !isOnGround) {
                    MovementUtils.setHorizontalSpeed(0.7F);
                } else if (hasStatusEffect
                        && statuseffectinstance != null
                        && statuseffectinstance.getAmplifier() == 3
                        && isOnGround) {
                    MovementUtils.setHorizontalSpeed(0.49F);
                } else if (hasStatusEffect
                        && statuseffectinstance != null
                        && statuseffectinstance.getAmplifier() == 1
                        && fallDistance <= 0.2F
                        && !isOnGround) {
                    MovementUtils.setHorizontalSpeed(0.52F);
                } else if (hasStatusEffect
                        && statuseffectinstance != null
                        && statuseffectinstance.getAmplifier() == 1
                        && isOnGround) {
                    MovementUtils.setHorizontalSpeed(0.36F);
                } else if (fallDistance <= 0.2F && !isOnGround
                        || fallDistance <= 0.2F && hasStatusEffect) {
                    MovementUtils.setHorizontalSpeed(0.36F);
                }
            }

            if (this.modeSetting.isSelected("Vanilla") && !client.player.isSubmergedInWater()) {
                if (client.player.isOnGround()) {
                    MovementUtils.setHorizontalSpeed(0.3F);
                } else {
                    MovementUtils.setHorizontalSpeed(
                            (double) this.speedSetting.getFloat().floatValue());
                }
            }

            if (this.modeSetting.isSelected("RW")) {
                this.updateTimerCycle();
            }
        }
    }

    private void updateTimerCycle() {
        if (client.getRenderTickCounter() instanceof TickSpeedAccess tickSpeedAccess) {
            long i = this.stopwatch.elapsedMillis();
            float f;
            if (i < 100L) {
                f = 1.15F;
            } else if (i < 500L) {
                f = 1.4F;
            } else if (i < 520L) {
                f = 1.6F;
            } else if (i < (540L)) {
                f = 0.25F;
            } else {
                this.stopwatch.reset();
                f = 0.5F;
            }

            tickSpeedAccess.setSpeed(f);
        }
    }
}
