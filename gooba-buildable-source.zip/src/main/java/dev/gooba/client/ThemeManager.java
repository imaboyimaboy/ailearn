package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

@Environment(EnvType.CLIENT)
public class ThemeManager {
    private ThemePreset themePreset = ThemePreset.Purple;
    public static final File file =
            GoobaPaths.CONFIG_DIRECTORY.resolve("config/theme/theme.json").toFile();

    private void save() {
        try (FileWriter filewriter = new FileWriter(file)) {
            Properties properties = new Properties();
            properties.setProperty("theme", this.themePreset.name());
            properties.store(filewriter, "GUI Settings");
        } catch (IOException ioexception) {
        }
    }

    public void initialize() {
        label38:
        {
            try {
                File parentFile = file.getParentFile();
                if (parentFile != null && !parentFile.exists()) {
                    parentFile.mkdirs();
                }

                if (!file.exists()) {
                    file.createNewFile();
                    break label38;
                }
            } catch (Exception exceptionValue) {
                return;
            }

            try {
                this.load();
            } catch (Exception exception3) {
            }

            return;
        }

        try {
            this.save();
        } catch (Exception exception) {
        }
    }

    public ThemePreset getThemePreset() {
        return this.themePreset;
    }

    private void load() {
        try (FileReader filereader = new FileReader(file)) {
            Properties properties = new Properties();
            properties.load(filereader);
            this.themePreset =
                    ThemePreset.valueOf(properties.getProperty("theme", ThemePreset.Purple.name()));
        } catch (IllegalArgumentException | IOException ioexception) {
        }
    }
}
