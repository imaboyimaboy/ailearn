package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class EventPhase {
    public static final byte POST = 2;
    public static final byte RECIEVE = 4;
    public static final byte START = -1;
    public static final byte PRE = 0;
    public static final byte CONST_BYTEVAL = 1;
    public static final byte SEND = 3;
}
