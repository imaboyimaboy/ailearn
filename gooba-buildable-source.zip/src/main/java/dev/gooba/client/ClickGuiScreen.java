package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.texture.Sprite;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import org.joml.Matrix3x2fStack;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

@Environment(EnvType.CLIENT)
public class ClickGuiScreen extends Screen implements MinecraftAccess {
    private float tickDelta;
    private String tooltipText;
    private static final Identifier GLOW_TEXTURE =
            Identifier.of("client", "textures/particles/glow.png");
    private final EasingAnimation searchExpansionAnimation;
    private float activeSettingX;
    private TextSetting editingText;
    private DrawContext drawContext;
    private ColorSetting blockColorSetting;
    private boolean configNameSelectedAll;
    private float activeSettingWidth;
    public static float guiScale;
    private float blockDropdownOpacity;
    private String textInput;
    private float configScroll;
    private float blockDropdownHeight;
    private final IdentityHashMap<Setting<?>, EasingAnimation> settingVisibilityAnimations;
    public static ThemePreset themePreset;
    private static final Identifier TOGGLE_ICONS_TEXTURE =
            Identifier.of("client", "fonts/toggle_icons.png");
    private boolean clearSearchWhenClosed;
    private SliderSetting draggedSlider;
    private float colorPickerY;
    private float blockDropdownX;
    private final HandEditor handEditor;
    private float colorPickerButtonX;
    private float blockSearchScrollOffset;
    private int blockSearchScroll;
    private boolean moduleSearchSelectedAll;
    private float colorPickerButtonY;
    private int colorDragChannel;
    private ColorSetting draggedColorSetting;
    private float screenScale;
    private float configScrollTarget;
    private float mouseX;
    private final IdentityHashMap<SliderSetting, Float> sliderFractions;
    private ModuleCategory previousCategory;
    private final EasingAnimation tooltipAnimation;
    public static ThemePreset[] themePresets;
    private boolean editingConfigName;
    public static final TimedAnimation timedAnimation = new DecelerateAnimation(300, 1.0);
    private final EasingAnimation openAnimation;
    private final IdentityHashMap<ColorSetting, EasingAnimation> colorExpansionAnimations;
    private KeybindSetting editingKeybind;
    private final EasingAnimation searchCaretAnimation;
    private boolean blockSearchSelectedAll;
    private float blockDropdownY;
    private static String rememberedSearch = "";
    private long lastFrameNanos;
    private final EasingAnimation blockDropdownAnimation;
    private ColorSetting openColorPicker;
    public static boolean searchFocused;
    private boolean blockSearchFocused;
    private StringListSetting stringListSetting;
    private float mouseY;
    private final IdentityHashMap<Setting<?>, EasingAnimation> booleanAnimations;
    private Module moduleBeingBound;
    private float blockDropdownButtonY;
    private final IdentityHashMap<Module, EasingAnimation> moduleVisibilityAnimations;
    private final List<ClickGuiScreen.SavedConfig> savedConfigs;
    private float configMaxScroll;
    private boolean configSidebarOpen;
    private float colorPickerOpacity;
    private boolean blockDropdownOpen;
    private boolean textSelectedAll;
    private final EasingAnimation categoryTransitionAnimation;
    private int moduleSearchCursor;
    private final List<ClickGuiScreen.Panel> panels = new ArrayList<>();
    public static ThemePreset themePreset2;
    private final EasingAnimation configSidebarAnimation;
    private String blockSearch;
    private final IdentityHashMap<Module, EasingAnimation> moduleBindAnimations;
    private final EasingAnimation searchFilterAnimation;
    private final Map<String, EasingAnimation> blockSelectionAnimations;
    private float frameDelta;
    private ModuleCategory selectedCategory;
    private final IdentityHashMap<Setting<?>, List<EasingAnimation>> optionAnimations;
    private String configName;
    private boolean closing;
    private float blockDropdownButtonX;
    private String moduleSearch;
    private static ModuleCategory rememberedCategory = ModuleCategory.COMBAT;
    private float colorPickerX;
    private boolean searchCaretInitialized;
    private int blockSearchCursor;
    private final EasingAnimation blockScrollAnimation;

    private ClickGuiScreen.Panel findPanel(ModuleCategory moduleCategory2) {
        for (ClickGuiScreen.Panel panel : this.panels) {
            if (panel.category == moduleCategory2) {
                return panel;
            }
        }

        return this.panels.get(0);
    }

    private void drawOpenColorPicker(ClickGuiScreen.View view) {
        if (this.openColorPicker != null && !(this.colorPickerOpacity <= 0.01F)) {
            Color color = new Color(this.openColorPicker.getColor(), true);
            float[] afloat =
                    Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
            float f = this.colorPickerX + 61.0F;
            float f1 = f + 9.0F;
            this.drawColorPicker(
                    view,
                    this.colorPickerX,
                    this.colorPickerY,
                    f,
                    f1,
                    afloat[0],
                    afloat[1],
                    afloat[2],
                    (float) color.getAlpha() / 255.0F,
                    this.colorPickerOpacity);
        }
    }

    private void drawPanelBackground(
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float factor) {
        this.drawBlurredRect(
                view, f, f1, f2, f3, f4, f5, f6, f7, factor, this.getBackgroundColor());
    }

    private int rgbaWithOpacity(int i, int j, int k, int l, float f) {
        return new Color(i, j, k, Math.round((float) l * this.clampUnit(f))).getRGB();
    }

    private boolean handleModuleClick(
            ClickGuiScreen.Panel panel, float mouseX, float mouseY, int i) {
        float f2 = mouseY / guiScale - panel.y / guiScale;
        float f3 = mouseX / guiScale - panel.x / guiScale;
        if (!(f2 < 44.0F) && !(f2 > 310.0F) && !(f3 < 122.0F)) {
            List listx = this.getModules(panel.category);
            float[] afloat = new float[] {48.0F - panel.scroll[0], 48.0F - panel.scroll[1]};

            for (int j = 0; j < listx.size(); j++) {
                Module moduleValue = (Module) listx.get(j);
                int k = j & 1;
                float f4 = 127.0F + (float) k * 208.5F;
                float f5 = afloat[k];
                float activeSettingXValue = f4 + 4.5F;
                float f7 =
                        this.clampUnit(
                                this.moduleVisibilityAnimations
                                        .computeIfAbsent(
                                                moduleValue,
                                                module -> new EasingAnimation().resetValue(1.0F))
                                        .getFloatValue());
                float moduleHeight = this.getModuleHeight(moduleValue);
                if (f7 > 0.05F && this.contains(panel, mouseX, mouseY, f4, f5, 193.5F, 18.0F)) {
                    if (i == 0) {
                        if (!moduleValue.isEnabled()) {
                            moduleValue.setEnabled(true);
                        } else {
                            moduleValue.setEnabled(false);
                        }
                    } else if (i == 1
                            && moduleValue.getSettings().stream()
                                    .anyMatch(this::isDisplayableSetting)) {
                        if (!moduleValue.isExpanded()) {
                            moduleValue.setExpanded(true);
                            GuiSounds.playModuleExpand(moduleValue.isExpanded());
                        } else {
                            moduleValue.setExpanded(false);
                            GuiSounds.playModuleExpand(moduleValue.isExpanded());
                        }
                    } else if (i == 2) {
                        this.moduleBeingBound = moduleValue;
                        GuiSounds.playConfirmation();
                    }

                    return true;
                }

                float f9 =
                        this.clampUnit(
                                moduleValue.getExpandedAnimation().getInterpolatedProgress());
                if (f7 > 0.05F && moduleValue.isExpanded() && f9 > 0.0F) {
                    float f10 = f5 + 18.0F + 4.0F * f9 - 4.0F * (1.0F - f9);
                    float f11 = 0.0F;

                    for (Setting setting : moduleValue.getSettings()) {
                        if (this.isDisplayableSetting(setting)) {
                            float settingVisibility = this.getSettingVisibility(setting);
                            if (!(settingVisibility <= 0.0F)) {
                                float settingHeight = this.getSettingHeight(setting);
                                float f14 = f10 + f11 - 4.0F * (1.0F - settingVisibility);
                                float f15 = f10 + (f14 - f10) * f9;
                                if (this.handleSettingClick(
                                        panel,
                                        setting,
                                        mouseX,
                                        mouseY,
                                        activeSettingXValue,
                                        f15,
                                        184.5F,
                                        settingHeight,
                                        i)) {
                                    return true;
                                }

                                f11 += (settingHeight + 6.0F) * settingVisibility;
                            }
                        }
                    }
                }

                afloat[k] += (moduleHeight + 3.0F) * f7;
            }

            return true;
        } else {
            return true;
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private void insertSettingText(String text) {
        if (this.editingText != null && text != null && !text.isEmpty()) {
            String textValue =
                    text.replace('\r', ' ')
                            .replace('\n', ' ')
                            .replace('\t', ' ')
                            .replaceAll("[\\p{Cntrl}]", "");
            if (!textValue.isEmpty()
                    && (!this.editingText.isNumericOnly() || textValue.matches("[0-9.,-]+"))) {
                String textInput2;
                if (this.textSelectedAll) {
                    textInput2 = textValue;
                } else {
                    String textInputValue = this.textInput;
                    textInput2 = textInputValue + textValue;
                }

                this.textInput = textInput2;
                this.textSelectedAll = false;
                GuiSounds.playTypeCharacter();
            }
        }
    }

    private void drawToggle(ClickGuiScreen.View view, float f, float f1, float f2) {
        float f3 = 19.0F;
        float f4 = 11.428572F;
        float f5 = (f4 - 3.0F) * 0.5F;
        this.drawRoundedRect(
                view,
                f,
                f1,
                f3,
                f4,
                this.rgbaWithOpacity(255, 255, 255, Math.round(10.0F + 8.0F * f2), view.alpha),
                4.0F);
        if (f2 > 0.001F) {
            this.drawRoundedRect(view, f, f1, f3, f4, this.getAccentColor(view.alpha * f2), 4.0F);
        }

        this.drawCircle(
                view,
                f + f4 * 0.5F + (f3 - f4) * f2,
                f1 + f4 * 0.5F,
                f5,
                this.withOpacity(-1, view.alpha));
    }

    public ClickGuiScreen() {
        super(Text.literal("Goobaa Click GUI"));
        this.settingVisibilityAnimations = new IdentityHashMap<>();
        this.optionAnimations = new IdentityHashMap<>();
        this.booleanAnimations = new IdentityHashMap<>();
        this.sliderFractions = new IdentityHashMap<>();
        this.colorExpansionAnimations = new IdentityHashMap<>();
        this.moduleBindAnimations = new IdentityHashMap<>();
        this.moduleVisibilityAnimations = new IdentityHashMap<>();
        this.blockSelectionAnimations = new HashMap<>();
        this.openAnimation = new EasingAnimation();
        this.searchExpansionAnimation = new EasingAnimation();
        this.searchCaretAnimation = new EasingAnimation();
        this.searchFilterAnimation = new EasingAnimation();
        this.categoryTransitionAnimation = new EasingAnimation();
        this.tooltipAnimation = new EasingAnimation();
        this.configSidebarAnimation = new EasingAnimation();
        this.handEditor = HandEditor.getInstance();
        this.screenScale = 1.0F;
        this.blockSearch = "";
        this.blockDropdownAnimation = new EasingAnimation();
        this.blockScrollAnimation = new EasingAnimation();
        this.textInput = "";
        this.moduleSearch = rememberedSearch;
        this.tooltipText = "";
        this.configName = "Config";
        this.savedConfigs = new ArrayList<>();
        this.selectedCategory = rememberedCategory;
        this.activeSettingX = 131.5F;
        this.activeSettingWidth = 184.5F;

        for (ModuleCategory moduleCategory2 : ModuleCategory.values()) {
            this.panels.add(new ClickGuiScreen.Panel(moduleCategory2));
        }

        for (Entry entry : Gooba.getInstance().getConfigManager().getPresets().entrySet()) {
            this.savedConfigs.add(
                    new ClickGuiScreen.SavedConfig(
                            (String) entry.getKey(), (String) entry.getValue()));
        }
    }

    private float getSettingHeight(Setting setting) {
        if (setting instanceof SliderSetting) {
            return 23.0F;
        } else if (setting instanceof ModeSetting modeSetting2) {
            return this.getOptionsHeight(modeSetting2.modes);
        } else if (setting instanceof MultiBooleanSetting multiBooleanSetting) {
            return this.getOptionsHeight(
                    multiBooleanSetting.getOptions().stream().map(Setting::getName).toList());
        } else if (setting instanceof ChoiceSetting choiceSetting) {
            return this.getOptionsHeight(
                    choiceSetting.choices.stream().map(String::valueOf).toList());
        } else if (setting instanceof KeybindSetting || setting instanceof TextSetting) {
            return 13.0F;
        } else if (setting instanceof ColorSetting) {
            return 11.0F;
        } else if (setting instanceof StringListSetting) {
            return 14.0F;
        } else if (setting instanceof ButtonSetting) {
            return 10.0F;
        } else {
            return setting instanceof MatrixSetting ? 66.0F : 11.0F;
        }
    }

    @Override
    public boolean mouseReleased(Click click) {
        OverlayEditor overlayEditor = EditorManager.getActiveEditor();
        if (overlayEditor != null) {
            return overlayEditor.mouseReleased(click.button());
        } else {
            if (this.draggedSlider != null || this.draggedColorSetting != null) {
                GuiSounds.playHighSlider();
            }

            this.draggedSlider = null;
            this.draggedColorSetting = null;
            return true;
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean flag) {
        OverlayEditor overlayEditor = EditorManager.getActiveEditor();
        if (overlayEditor != null) {
            return overlayEditor.mouseClicked(
                    (float) (click.x() / (double) this.screenScale),
                    (float) (click.y() / (double) this.screenScale),
                    click.button());
        } else {
            float mouseX = (float) (click.x() / (double) this.screenScale);
            float mouseY = (float) (click.y() / (double) this.screenScale);
            int integer = click.button();
            if (this.moduleBeingBound != null && integer != 2) {
                boolean flag3x;
                flag3x = (integer < 0);

                Module moduleValue = this.moduleBeingBound;
                if (flag3x) {
                    moduleValue.setKey(-1);
                } else {
                    moduleValue.setKey(integer);
                }

                this.moduleBeingBound = null;
                if (flag3x) {
                    GuiSounds.playBindRemove();
                    String bigName = moduleValue.getBigName();
                    ChatMessages.send(bigName + " bind cleared");
                } else {
                    GuiSounds.playBindSuccess();
                    String bigNameValue = moduleValue.getBigName();
                    ChatMessages.send(bigNameValue + " bound to mouse " + integer);
                }

                return true;
            } else if (this.editingKeybind != null && integer != 0) {
                this.editingKeybind.setValue(integer);
                this.editingKeybind = null;
                GuiSounds.playBindSuccess();
                return true;
            } else if (this.openAnimation.getFloatValue() < 0.9F) {
                return true;
            } else {
                ClickGuiScreen.Panel panel = this.getActivePanel();
                float f2 = this.clampUnit(this.configSidebarAnimation.getFloatValue());
                float f3 = 541.5F + (1.0F - f2) * 5.0F;
                if (f2 > 0.01F && this.contains(panel, mouseX, mouseY, f3, 0.0F, 114.0F, 320.0F)) {
                    float f10 = f3 + 6.0F;
                    float f11 = 102.0F;
                    float f12 = (f11 - 2.0F) * 0.5F;
                    float f14 = 6.0F;
                    float f15 = f10 + f12 + 2.0F;
                    float f16 = f14 + 18.0F + 2.0F;
                    float f5 = f16 + 18.0F + 2.0F;
                    this.editingConfigName = false;
                    if (click.button() == 0
                            && this.contains(panel, mouseX, mouseY, f10, f14, f12, 18.0F)) {
                        String text =
                                MinecraftAccess.client.keyboard == null
                                        ? ""
                                        : MinecraftAccess.client.keyboard.getClipboard();
                        if (Gooba.getInstance().getConfigManager().importConfig(text)) {
                            this.importConfig(text);
                            ChatMessages.send("Successfully loaded");
                            GuiSounds.playBindSuccess();
                        } else {
                            ChatMessages.send("Invalid config");
                            GuiSounds.playBindRemove();
                        }

                        return true;
                    } else if (click.button() == 0
                            && this.contains(panel, mouseX, mouseY, f15, f14, f12, 18.0F)) {
                        this.exportConfig();
                        return true;
                    } else if (click.button() == 0
                            && this.contains(panel, mouseX, mouseY, f10, f16, f11, 18.0F)) {
                        PanicModule.resetAndDisableModules();
                        GuiSounds.playBindRemove();
                        return true;
                    } else if (click.button() == 0
                            && this.contains(panel, mouseX, mouseY, f10, f5, f11, 18.0F)) {
                        this.editingConfigName = true;
                        this.configNameSelectedAll = true;
                        GuiSounds.playSelection();
                        return true;
                    } else {
                        float f6 = f5 + 18.0F + 2.0F;
                        float f7 = 314.0F;
                        if (this.contains(panel, mouseX, mouseY, f10, f6, f11, f7 - f6)) {
                            float f8 = f6 - this.configScroll;

                            for (int k = this.savedConfigs.size() - 1; k >= 0; k--) {
                                ClickGuiScreen.SavedConfig savedConfig = this.savedConfigs.get(k);
                                float opacity = savedConfig.getOpacity();
                                if (!savedConfig.isDeleted()
                                        && this.contains(
                                                panel, mouseX, mouseY, f10, f8, f11, 30.0F)) {
                                    if (click.button() == 0) {
                                        if (Gooba.getInstance()
                                                .getConfigManager()
                                                .importConfig(savedConfig.getEncodedConfig())) {
                                            String stringValue = savedConfig.getName();
                                            ChatMessages.send("Successfully loaded " + stringValue);
                                            GuiSounds.playBindSuccess();
                                        }

                                        return true;
                                    }

                                    if (click.button() == 1) {
                                        savedConfig.markDeleted();
                                        Gooba.getInstance()
                                                .getConfigManager()
                                                .deletePreset(savedConfig.getName());
                                        GuiSounds.playDeleteCharacter();
                                        return true;
                                    }
                                }

                                f8 += 32.0F * opacity;
                            }
                        }

                        return true;
                    }
                } else {
                    if (this.stringListSetting != null
                            && this.blockDropdownAnimation.getFloatValue() > 0.01F
                            && (this.openColorPicker != this.blockColorSetting
                                    || this.blockColorSetting == null
                                    || !this.contains(
                                            panel,
                                            mouseX,
                                            mouseY,
                                            this.colorPickerX - 5.0F,
                                            this.colorPickerY - 5.0F,
                                            84.0F,
                                            66.0F))) {
                        boolean flag1 =
                                this.contains(
                                        panel,
                                        mouseX,
                                        mouseY,
                                        this.blockDropdownX,
                                        this.blockDropdownY,
                                        184.0F,
                                        this.blockDropdownHeight);
                        boolean flag2x =
                                this.contains(
                                        panel,
                                        mouseX,
                                        mouseY,
                                        this.blockDropdownButtonX,
                                        this.blockDropdownButtonY,
                                        14.0F,
                                        14.0F);
                        if (flag1) {
                            if (click.button() == 0
                                    && this.contains(
                                            panel,
                                            mouseX,
                                            mouseY,
                                            this.blockDropdownX,
                                            this.blockDropdownY,
                                            184.0F,
                                            18.0F)) {
                                if (this.editingText != null) {
                                    this.editingText.setValue(this.textInput);
                                }

                                this.editingText = null;
                                this.blockSearchFocused = true;
                                this.blockSearchSelectedAll = false;
                                this.blockSearchCursor = this.blockSearch.length();
                                return true;
                            }

                            if ((click.button() == 0 || click.button() == 1)
                                    && this.contains(
                                            panel,
                                            mouseX,
                                            mouseY,
                                            this.blockDropdownX,
                                            this.blockDropdownY + 18.0F,
                                            184.0F,
                                            this.blockDropdownHeight - 18.0F)) {
                                List listx = this.stringListSetting.searchBlocks(this.blockSearch);
                                float f13 = mouseY / guiScale - panel.y / guiScale;
                                int j =
                                        (int)
                                                Math.floor(
                                                        (double)
                                                                ((f13
                                                                                - this
                                                                                        .blockDropdownY
                                                                                - 18.0F
                                                                                + this
                                                                                        .blockSearchScrollOffset)
                                                                        / 16.0F));
                                if (j >= 0 && j < listx.size()) {
                                    String textValue = (String) listx.get(j);
                                    if (click.button() == 1) {
                                        if (this.blockColorSetting != null) {
                                            this.blockColorSetting.expanded = false;
                                        }

                                        this.blockColorSetting =
                                                this.stringListSetting.getOrCreateColorSetting(
                                                        textValue);
                                        this.blockColorSetting.expanded = true;
                                        this.blockSearchFocused = false;
                                        this.draggedColorSetting = null;
                                        GuiSounds.playExpand(true);
                                        return true;
                                    }

                                    if (this.stringListSetting
                                            .getSelectedIds()
                                            .contains(textValue)) {
                                        this.stringListSetting.removeBlock(textValue);
                                    } else {
                                        this.stringListSetting.addBlock(textValue);
                                    }

                                    GuiSounds.playBooleanToggle(
                                            this.stringListSetting
                                                    .getSelectedIds()
                                                    .contains(textValue));
                                }

                                return true;
                            }

                            return true;
                        }

                        if (!flag2x) {
                            this.blockDropdownOpen = false;
                            this.blockSearchFocused = false;
                        }
                    }

                    if (this.openColorPicker != null) {
                        boolean flag4x =
                                this.contains(
                                        panel,
                                        mouseX,
                                        mouseY,
                                        this.colorPickerX - 5.0F,
                                        this.colorPickerY - 5.0F,
                                        84.0F,
                                        66.0F);
                        boolean flag5x =
                                this.contains(
                                        panel,
                                        mouseX,
                                        mouseY,
                                        this.colorPickerButtonX,
                                        this.colorPickerButtonY,
                                        14.0F,
                                        14.0F);
                        if (!flag4x && !flag5x) {
                            this.openColorPicker.expanded = false;
                            this.openColorPicker = null;
                            this.draggedColorSetting = null;
                        } else {
                            if (flag4x && click.button() != 0) {
                                return true;
                            }

                            if (flag4x
                                    && !this.contains(
                                            panel,
                                            mouseX,
                                            mouseY,
                                            this.colorPickerX,
                                            this.colorPickerY,
                                            56.0F,
                                            56.0F)
                                    && !this.contains(
                                            panel,
                                            mouseX,
                                            mouseY,
                                            this.colorPickerX + 61.0F,
                                            this.colorPickerY,
                                            4.0F,
                                            56.0F)
                                    && !this.contains(
                                            panel,
                                            mouseX,
                                            mouseY,
                                            this.colorPickerX + 70.0F,
                                            this.colorPickerY,
                                            4.0F,
                                            56.0F)) {
                                return true;
                            }
                        }
                    }

                    if (this.contains(panel, mouseX, mouseY, 0.0F, 0.0F, 540.0F, 320.0F)) {
                        if (click.button() == 0 && this.openColorPicker != null) {
                            if (this.contains(
                                    panel,
                                    mouseX,
                                    mouseY,
                                    this.colorPickerX,
                                    this.colorPickerY,
                                    56.0F,
                                    56.0F)) {
                                this.draggedColorSetting = this.openColorPicker;
                                this.colorDragChannel = 0;
                                this.updateColorPicker(
                                        this.draggedColorSetting, mouseX, mouseY, panel);
                                GuiSounds.playSlider();
                                return true;
                            }

                            if (this.contains(
                                    panel,
                                    mouseX,
                                    mouseY,
                                    this.colorPickerX + 61.0F,
                                    this.colorPickerY,
                                    4.0F,
                                    56.0F)) {
                                this.draggedColorSetting = this.openColorPicker;
                                this.colorDragChannel = 1;
                                this.updateColorPicker(
                                        this.draggedColorSetting, mouseX, mouseY, panel);
                                GuiSounds.playSlider();
                                return true;
                            }

                            if (this.contains(
                                    panel,
                                    mouseX,
                                    mouseY,
                                    this.colorPickerX + 70.0F,
                                    this.colorPickerY,
                                    4.0F,
                                    56.0F)) {
                                this.draggedColorSetting = this.openColorPicker;
                                this.colorDragChannel = 2;
                                this.updateColorPicker(
                                        this.draggedColorSetting, mouseX, mouseY, panel);
                                GuiSounds.playSlider();
                                return true;
                            }
                        }

                        ModuleCategory[] moduleCategorys = this.getCategoryOrder();

                        for (int l = 0; l < moduleCategorys.length; l++) {
                            ModuleCategory moduleCategory2 = moduleCategorys[l];
                            float f4 = 74.0F + (float) l * 29.0F;
                            if (this.contains(panel, mouseX, mouseY, 10.0F, f4, 96.0F, 23.0F)
                                    && click.button() == 0) {
                                this.selectCategory(moduleCategory2, panel);
                                return true;
                            }
                        }

                        if (this.contains(panel, mouseX, mouseY, 130.0F, 9.0F, 230.0F, 20.0F)
                                && click.button() == 0) {
                            if (this.editingText != null) {
                                this.editingText.setValue(this.textInput);
                            }

                            this.editingText = null;
                            this.moduleSearchSelectedAll = false;
                            searchFocused = true;
                            this.clearSearchWhenClosed = false;
                            this.moduleSearchCursor = this.moduleSearch.length();
                            this.searchCaretInitialized = false;
                            return true;
                        } else if (this.contains(panel, mouseX, mouseY, 512.0F, 7.0F, 24.0F, 24.0F)
                                && click.button() == 0) {
                            if (!this.configSidebarOpen) {
                                this.configSidebarOpen = true;
                            } else {
                                this.configSidebarOpen = false;
                            }

                            this.editingConfigName = false;
                            GuiSounds.playModuleExpand(this.configSidebarOpen);
                            return true;
                        } else {
                            return this.handleModuleClick(panel, mouseX, mouseY, click.button());
                        }
                    } else if (this.configSidebarOpen) {
                        this.configSidebarOpen = false;
                        this.editingConfigName = false;
                        GuiSounds.playModuleExpand(false);
                        return true;
                    } else {
                        if (searchFocused) {
                            searchFocused = false;
                            this.clearSearchWhenClosed = true;
                        }

                        return super.mouseClicked(click, flag);
                    }
                }
            }
        }
    }

    private void drawBooleanSetting(
            BooleanSetting booleanSetting,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3) {
        float f4 =
                this.booleanAnimations
                        .computeIfAbsent(
                                booleanSetting,
                                setting ->
                                        new EasingAnimation()
                                                .resetProgress(booleanSetting.isOn() ? 1.0F : 0.0F))
                        .advanceThenSampleProgress(booleanSetting.isOn(), 0.5F, this.tickDelta);
        float widthValue = 14.0F;
        float f6 = f + f2 - widthValue;
        float f7 = f1 - 1.5F;
        this.drawFadedText(
                Fonts.DEFAULT,
                booleanSetting.getName(),
                view,
                f,
                this.centerTextY(Fonts.DEFAULT, booleanSetting.getName(), f1, 11.0F, 10.0F),
                f2 - widthValue - 6.0F,
                10.0F,
                this.withOpacity(-922381, f3));
        this.drawRoundedRect(
                view,
                f6,
                f7,
                widthValue,
                widthValue,
                this.rgbaWithOpacity(255, 255, 255, Math.round(7.0F + 8.0F * f4), f3),
                4.0F);
        float sizeValue = 9.714286F;
        float size = 15.085715F;
        if (booleanSetting.isOn()) {
            Font font = Fonts.ICONS;
            float f12 = Fonts.ICONS.centerFirstGlyphX("m", f6, widthValue, size);
            float f13 = this.centerTextY(Fonts.ICONS, "m", f7, widthValue, size);
            this.rgbaWithOpacity(130, 220, 150, 255, f3);
            this.drawText(font, "m", view, f12, f13, size);
        } else {
            Font fontValue = Fonts.ICONS;
            float f10 = Fonts.ICONS.centerFirstGlyphX("u", f6, widthValue, sizeValue);
            float f11 = this.centerTextY(Fonts.ICONS, "u", f7, widthValue, sizeValue);
            this.rgbaWithOpacity(200, 25, 25, 255, f3);
            this.drawText(fontValue, "u", view, f10, f11, sizeValue);
        }
    }

    private void handleSearchKey(KeyInput keyinput, boolean flag) {
        int i;
        boolean flag1;
        String text;
        label127:
        {
            label126:
            {
                i = keyinput.key();
                if ((keyinput.modifiers() & 2) != 0) {
                    flag1 = true;
                    if (flag) {
                        break label126;
                    }
                } else {
                    flag1 = false;
                    if (flag) {
                        break label126;
                    }
                }

                text = this.moduleSearch;
                break label127;
            }

            text = this.blockSearch;
        }

        String textValue = text;
        int blockSearchCursorValue = flag ? this.blockSearchCursor : this.moduleSearchCursor;
        boolean blockSearchSelectedAllValue =
                flag ? this.blockSearchSelectedAll : this.moduleSearchSelectedAll;
        if (flag1 && i == 65) {
            blockSearchSelectedAllValue = (!textValue.isEmpty());

            blockSearchCursorValue = textValue.length();
        } else if (!flag1 || i != 67 && i != 88) {
            if (flag1 && i == 86) {
                if (MinecraftAccess.client.keyboard != null) {
                    this.insertSearchText(MinecraftAccess.client.keyboard.getClipboard(), flag);
                }

                return;
            }

            if (i != 259 && i != 261) {
                if (i != 263 && i != 268) {
                    if (i == 262 || i == 269) {
                        blockSearchCursorValue =
                                !blockSearchSelectedAllValue && i != 269
                                        ? (blockSearchCursorValue < textValue.length()
                                                ? textValue.offsetByCodePoints(
                                                        blockSearchCursorValue, 1)
                                                : textValue.length())
                                        : textValue.length();
                        blockSearchSelectedAllValue = false;
                    }
                } else {
                    if (!blockSearchSelectedAllValue && i != 268 && blockSearchCursorValue > 0) {
                        blockSearchCursorValue =
                                textValue.offsetByCodePoints(blockSearchCursorValue, -1);
                    } else {
                        blockSearchCursorValue = 0;
                    }

                    blockSearchSelectedAllValue = false;
                }
            } else if (blockSearchSelectedAllValue) {
                textValue = "";
                blockSearchCursorValue = 0;
                blockSearchSelectedAllValue = false;
            } else if (i == 259 && blockSearchCursorValue > 0) {
                int blockSearchCursorValueValue =
                        textValue.offsetByCodePoints(blockSearchCursorValue, -1);
                text = textValue.substring(0, blockSearchCursorValueValue);
                String text4 = textValue.substring(blockSearchCursorValue);
                String text2 = text;
                textValue = text2 + text4;
                blockSearchCursorValue = blockSearchCursorValueValue;
            } else if (i == 261 && blockSearchCursorValue < textValue.length()) {
                text = textValue.substring(0, blockSearchCursorValue);
                String text5 =
                        textValue.substring(
                                textValue.offsetByCodePoints(blockSearchCursorValue, 1));
                String text3 = text;
                textValue = text3 + text5;
            }
        } else if (blockSearchSelectedAllValue && MinecraftAccess.client.keyboard != null) {
            MinecraftAccess.client.keyboard.setClipboard(textValue);
            if (i == 88) {
                textValue = "";
                blockSearchCursorValue = 0;
                blockSearchSelectedAllValue = false;
            }
        }

        this.setSearchState(textValue, blockSearchCursorValue, blockSearchSelectedAllValue, flag);
    }

    private void insertSearchText(String text, boolean flag) {
        if (text != null && !text.isEmpty()) {
            String textValue =
                    text.replace('\r', ' ')
                            .replace('\n', ' ')
                            .replace('\t', ' ')
                            .replaceAll("[\\p{Cntrl}]", "");
            boolean flag1 = flag ? this.blockSearchSelectedAll : this.moduleSearchSelectedAll;
            String text2 = flag1 ? "" : (flag ? this.blockSearch : this.moduleSearch);
            int i;
            if (flag1) {
                i = 0;
            } else {
                i = flag ? this.blockSearchCursor : this.moduleSearchCursor;
            }

            int j = Math.min(textValue.length(), 48 - text2.length());
            if (j > 0
                    && j < textValue.length()
                    && Character.isHighSurrogate(textValue.charAt(j - 1))) {
                j--;
            }

            if (j > 0) {
                String text3 = textValue.substring(0, j);
                String text4 = text2.substring(0, i);
                String text5 = text2.substring(i);
                String text6 = text4;
                this.setSearchState(text6 + text3 + text5, i + j, false, flag);
            }
        }
    }

    private List getOptionAnimations(Setting setting, int i) {
        List listx =
                this.optionAnimations.computeIfAbsent(setting, settingValue -> new ArrayList<>());

        while (listx.size() < i) {
            listx.add(new EasingAnimation().resetProgress(0.0F));
        }

        if (listx.size() > i) {
            listx.subList(i, listx.size()).clear();
        }

        return listx;
    }

    private void drawButtonSetting(
            ButtonSetting buttonSetting,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3) {
        Font font = Fonts.DEFAULT;
        String name = buttonSetting.getName();
        this.getAccentColor(f3);
        this.drawText(font, name, view, f, f1, 10.0F);
        this.drawRoundedRect(
                view, f, f1 + 9.0F, f2, 0.5F, this.getAccentColor(f3 * 60.0F / 255.0F), 0.0F);
    }

    private void resetSearchAnimations() {
        if (this.moduleSearch.isBlank()) {
            for (Module moduleValue : Gooba.getInstance().getModuleRegistry().values()) {
                this.moduleVisibilityAnimations
                        .computeIfAbsent(moduleValue, module -> new EasingAnimation())
                        .resetValue(0.0F);
            }
        }
    }

    private void updateSliderValue(SliderSetting sliderSetting2, float mouseX) {
        ClickGuiScreen.Panel panel = this.panelAt(mouseX, this.mouseY);
        if (panel != null) {
            float f1 =
                    MathUtils.clamp(
                            (mouseX / guiScale - panel.x / guiScale - this.activeSettingX)
                                    / this.activeSettingWidth,
                            0.0F,
                            1.0F);
            float value =
                    sliderSetting2.minValue
                            + (sliderSetting2.maxValue - sliderSetting2.minValue) * f1;
            value = (float) Math.round(value / sliderSetting2.step) * sliderSetting2.step;
            sliderSetting2.setValue(
                    MathUtils.clamp(value, sliderSetting2.minValue, sliderSetting2.maxValue));
            GuiSounds.playColorSlider(f1);
        }
    }

    private void drawValueBadge(
            String text,
            String stringValue,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3) {
        float widthValue =
                Math.min(f2 * 0.6F, Fonts.DEFAULT.measureVisibleWidth(stringValue, 10.0F) + 7.0F);
        float f5 = f + f2 - widthValue;
        this.drawFadedText(
                Fonts.DEFAULT,
                text,
                view,
                f,
                this.centerTextY(Fonts.DEFAULT, text, f1, 13.0F, 10.0F),
                f2 - widthValue - 4.0F,
                10.0F,
                this.withOpacity(-922381, f3));
        this.drawRoundedRect(
                view, f5, f1, widthValue, 13.0F, this.getAccentColor(f3 * 13.0F / 255.0F), 3.0F);
        this.drawRoundedOutline(
                view,
                f5,
                f1,
                widthValue,
                13.0F,
                0.5F,
                this.rgbaWithOpacity(255, 255, 255, 18, f3),
                3.0F);
        Font font = Fonts.DEFAULT;
        float f6 = Fonts.DEFAULT.centerTextX(stringValue, f5, widthValue, 10.0F);
        float f7 = this.centerTextY(Fonts.DEFAULT, stringValue, f1, 13.0F, 10.0F);
        this.withOpacity(-922381, f3);
        this.drawText(font, stringValue, view, f6, f7, 10.0F);
    }

    private String drawModules(ClickGuiScreen.Panel panel, ClickGuiScreen.View viewValue) {
        List listx = this.getModules(panel.category);
        IdentityHashMap identityhashmap = new IdentityHashMap();
        float[] afloat = new float[] {0.0F, 0.0F};
        float[] values = new float[] {0.0F, 0.0F};

        for (int i = 0; i < listx.size(); i++) {
            Module moduleValue = (Module) listx.get(i);
            float f =
                    this.clampUnit(
                            this.moduleVisibilityAnimations
                                    .computeIfAbsent(
                                            moduleValue,
                                            module ->
                                                    new EasingAnimation()
                                                            .resetValue(
                                                                    this.matchesSearch(moduleValue)
                                                                            ? 1.0F
                                                                            : 0.0F))
                                    .getFloatValue());
            identityhashmap.put(moduleValue, f);
            int j = i & 1;
            float moduleHeight = this.getModuleHeight(moduleValue);
            if (f > 0.001F) {
                values[j] = Math.max(values[j], afloat[j] + moduleHeight);
            }

            afloat[j] += (moduleHeight + 3.0F) * f;
        }

        float f17 = 48.0F;
        float f18 = 310.0F;
        float f19 = 1.0F - (float) Math.exp((double) (-this.frameDelta * 0.85F));

        for (int i1 = 0; i1 < 2; i1++) {
            panel.maxScroll[i1] = Math.max(0.0F, values[i1] - (f18 - f17));
            panel.scrollTarget[i1] =
                    MathUtils.clamp(panel.scrollTarget[i1], 0.0F, panel.maxScroll[i1]);
            panel.scroll[i1] = panel.scroll[i1] + (panel.scrollTarget[i1] - panel.scroll[i1]) * f19;
            if (Math.abs(panel.scrollTarget[i1] - panel.scroll[i1]) < 0.01F) {
                panel.scroll[i1] = panel.scrollTarget[i1];
            }
        }

        ScissorStack.push(
                viewValue.x + 122.0F * viewValue.scale,
                viewValue.y + 44.0F * viewValue.scale,
                412.0F * viewValue.scale,
                (f18 - 44.0F) * viewValue.scale,
                2.0F);
        float[] valuesValue = new float[] {f17 - panel.scroll[0], f17 - panel.scroll[1]};
        String stringValue = "";

        for (int k = 0; k < listx.size(); k++) {
            Module moduleValueValue = (Module) listx.get(k);
            int l = k & 1;
            float f2 = 127.0F + (float) l * 208.5F;
            float f3 = valuesValue[l];
            float f4 = f2 + 4.5F;
            float orDefault =
                    (float) identityhashmap.getOrDefault(moduleValueValue, Float.valueOf(1.0F));
            boolean flagx;
            flagx =
                    (orDefault > 0.05F
                            && this.contains(panel, this.mouseX, this.mouseY, f2, f3, 193.5F, 18.0F)
                            && this.mouseY >= panel.y + 44.0F * guiScale
                            && this.mouseY <= panel.y + f18 * guiScale);

            float moduleHeightValue = this.getModuleHeight(moduleValueValue);
            if (orDefault > 0.001F && f3 + moduleHeightValue + 3.0F >= 44.0F && f3 <= f18) {
                ClickGuiScreen.View view =
                        new ClickGuiScreen.View(
                                viewValue.x,
                                viewValue.y,
                                viewValue.scale,
                                viewValue.alpha * orDefault);
                float f7 =
                        this.clampUnit(
                                moduleValueValue.getToggleAnimation().getInterpolatedProgress());
                EasingAnimation easingAnimation2 =
                        this.moduleBindAnimations.computeIfAbsent(
                                moduleValueValue,
                                module4 -> new EasingAnimation().resetProgress(0.0F));
                float f8;
                if (this.moduleBeingBound == moduleValueValue) {
                    f8 = easingAnimation2.advanceThenSampleProgress(true, 0.32F, this.tickDelta);
                } else {
                    f8 = easingAnimation2.advanceThenSampleProgress(false, 0.32F, this.tickDelta);
                }

                float f9 = (float) Easings.IN_OUT_CUBIC.ease((double) f8);
                float f10 =
                        this.centerTextY(
                                        Fonts.DEFAULT,
                                        moduleValueValue.getBigName(),
                                        f3,
                                        18.0F,
                                        10.0F)
                                - 0.5F;
                if (f9 < 0.999F) {
                    this.drawFadedText(
                            Fonts.DEFAULT,
                            moduleValueValue.getBigName(),
                            view,
                            f4,
                            f10,
                            145.5F,
                            10.0F,
                            this.withOpacity(-725001, view.alpha * (1.0F - f9)));
                }

                if (f9 > 0.001F) {
                    this.drawFadedText(
                            Fonts.DEFAULT,
                            "...",
                            view,
                            f4,
                            this.centerTextY(Fonts.DEFAULT, "...", f3, 18.0F, 10.0F) - 0.5F,
                            145.5F,
                            10.0F,
                            this.withOpacity(-725001, view.alpha * f9));
                }

                if (flagx && moduleValueValue.getDescription() != null) {
                    stringValue = moduleValueValue.getDescription();
                }

                if (moduleValueValue.getSettings().stream().anyMatch(this::isDisplayableSetting)) {
                    Font font = Fonts.GOOBA;
                    float f20 =
                            Fonts.GOOBA.centerTextX("l", f2 + 193.5F - 40.0F, 14.0F, 11.428572F);
                    float f21 = Fonts.GOOBA.centerTextY("l", f3, 18.0F, 11.428572F);
                    this.withOpacity(-1581335, view.alpha);
                    this.drawText(font, "l", view, f20, f21, 11.428572F);
                }

                this.drawToggle(view, f2 + 193.5F - 23.0F, f3 + 3.2857141F, f7);
                float f11 =
                        this.clampUnit(
                                moduleValueValue.getExpandedAnimation().getInterpolatedProgress());
                if (f11 > 0.001F) {
                    ScissorStack.push(
                            view.x + f2 * view.scale,
                            view.y + f3 * view.scale,
                            193.5F * view.scale,
                            moduleHeightValue * view.scale,
                            2.0F);
                    float f12 = f3 + 18.0F + 4.0F * f11 - 4.0F * (1.0F - f11);
                    float f13 = 0.0F;

                    for (Setting setting : moduleValueValue.getSettings()) {
                        if (this.isDisplayableSetting(setting)) {
                            float settingVisibility = this.getSettingVisibility(setting);
                            if (!(settingVisibility <= 0.001F)) {
                                float f15 = f12 + f13 - 4.0F * (1.0F - settingVisibility);
                                float f16 = f12 + (f15 - f12) * f11;
                                this.drawSetting(
                                        setting, view, f4, f16, 184.5F, f11 * settingVisibility);
                                f13 += (this.getSettingHeight(setting) + 6.0F) * settingVisibility;
                            }
                        }
                    }

                    ScissorStack.pop();
                }
            }

            valuesValue[l] += (moduleHeightValue + 3.0F) * orDefault;
        }

        ScissorStack.pop();
        return stringValue;
    }

    private void drawText(
            Font font, String stringValue, ClickGuiScreen.View view, float f, float f1, float f2) {
        font.drawText(
                stringValue, view.x + f * view.scale, view.y + f1 * view.scale, f2 * view.scale);
    }

    private void drawCenteredText(
            Font font,
            String stringValue,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            int color) {
        font.drawCenteredText(
                stringValue,
                view.x + f * view.scale,
                view.y + f1 * view.scale,
                f2 * view.scale,
                color);
    }

    private void drawMultiBooleanSetting(
            MultiBooleanSetting multiBooleanSetting,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3) {
        long i = multiBooleanSetting.getOptions().stream().filter(BooleanSetting::isOn).count();
        int count = multiBooleanSetting.getOptions().size();
        String stringValue = i + "/" + count;
        float f4 = Fonts.DEFAULT.measureWidth(stringValue, 10.0F);
        this.drawFadedText(
                Fonts.DEFAULT,
                multiBooleanSetting.getName(),
                view,
                f,
                f1,
                f2 - f4 - 4.0F,
                10.0F,
                this.withOpacity(-922381, f3));
        Font font = Fonts.DEFAULT;
        float f9 = f + f2 - f4;
        float f10 = f1 + 0.25F;
        this.withOpacity(-12368303, f3);
        this.drawText(font, stringValue, view, f9, f10, 10.0F);
        List listx =
                this.getOptionAnimations(
                        multiBooleanSetting, multiBooleanSetting.getOptions().size());
        float f5 = 0.0F;
        float f6 = f1 + 10.0F + 6.0F;
        int j = 0;

        for (BooleanSetting booleanSetting :
                (Iterable<BooleanSetting>) (Iterable) multiBooleanSetting.getOptions()) {
            float f7 = Fonts.DEFAULT.measureWidth(booleanSetting.getName(), 10.0F) + 10.0F;
            if (f5 + f7 > f2 && f5 > 0.0F) {
                f5 = 0.0F;
                f6 += 16.0F;
            }

            boolean isOn = booleanSetting.isOn();
            float f8 =
                    ((EasingAnimation) listx.get(j++))
                            .advanceThenSampleProgress(isOn, 0.3F, this.tickDelta);
            this.drawRoundedRect(
                    view,
                    f + f5,
                    f6,
                    f7,
                    13.0F,
                    this.getAccentColor(f3 * (5.0F + 65.0F * f8) / 255.0F),
                    3.0F);
            this.drawRoundedOutline(
                    view,
                    f + f5,
                    f6,
                    f7,
                    13.0F,
                    0.5F,
                    this.rgbaWithOpacity(255, 255, 255, 5, f3),
                    3.0F);
            this.drawCenteredText(
                    Fonts.DEFAULT,
                    booleanSetting.getName(),
                    view,
                    f + f5 + f7 * 0.5F,
                    this.centerTextY(Fonts.DEFAULT, booleanSetting.getName(), f6, 13.0F, 10.0F),
                    10.0F,
                    this.withOpacity(-527622, f3));
            f5 += f7 + 4.0F;
        }
    }

    private void drawBlockDropdown(ClickGuiScreen.View view) {
        float f =
                this.clampUnit(
                        this.blockDropdownAnimation.approach(
                                this.blockDropdownOpen && this.stringListSetting != null
                                        ? 1.0F
                                        : 0.0F,
                                3.0F));
        if (this.stringListSetting != null && !(f <= 0.001F)) {
            List listx = this.stringListSetting.searchBlocks(this.blockSearch);
            int i = Math.min(10, Math.max(1, listx.size()));
            this.blockDropdownHeight = 18.0F + (float) i * 16.0F;
            this.blockDropdownX = this.blockDropdownButtonX + 14.0F + 8.0F;
            if (this.blockDropdownX + 184.0F > 536.0F) {
                this.blockDropdownX = this.blockDropdownButtonX - 184.0F - 8.0F;
            }

            this.blockDropdownY =
                    MathUtils.clamp(
                            this.blockDropdownButtonY + (1.0F - f) * 6.0F,
                            3.0F,
                            320.0F - this.blockDropdownHeight - 3.0F);
            float factor = this.blockDropdownOpacity * f;
            this.drawBlurredRoundedRect(
                    view,
                    this.blockDropdownX,
                    this.blockDropdownY,
                    184.0F,
                    this.blockDropdownHeight,
                    7.0F,
                    factor);
            this.drawRoundedRect(
                    view,
                    this.blockDropdownX,
                    this.blockDropdownY + 18.0F - 0.5F,
                    184.0F,
                    0.5F,
                    this.getAccentColor(factor * 0.75F),
                    0.0F);
            String text = this.blockSearch.isEmpty() ? "Search" : this.blockSearch;
            if (this.blockSearchFocused && this.blockSearchSelectedAll) {
                this.drawRoundedRect(
                        view,
                        this.blockDropdownX + 6.0F,
                        this.blockDropdownY + 4.0F,
                        Math.min(172.0F, Fonts.DEFAULT.measureWidth(this.blockSearch, 11.428572F)),
                        10.0F,
                        this.getAccentColor(factor * 0.45F),
                        1.0F);
            }

            int color =
                    this.blockSearch.isEmpty()
                            ? this.withOpacity(-7239018, factor)
                            : this.withOpacity(-527622, factor);
            this.drawFadedText(
                    Fonts.DEFAULT,
                    text,
                    view,
                    this.blockDropdownX + 6.0F,
                    this.centerTextY(Fonts.DEFAULT, text, this.blockDropdownY, 18.0F, 11.428572F),
                    172.0F,
                    11.428572F,
                    color);
            if (this.blockSearchFocused && this.blockDropdownOpen && !this.blockSearchSelectedAll) {
                float f2 =
                        Math.min(
                                170.0F,
                                Fonts.DEFAULT.measureWidth(
                                        this.blockSearch.substring(0, this.blockSearchCursor),
                                        11.428572F));
                this.drawRoundedRect(
                        view,
                        this.blockDropdownX + 6.0F + f2,
                        this.blockDropdownY + 4.0F,
                        0.7F,
                        10.0F,
                        this.withOpacity(-1, factor),
                        0.3F);
            }

            int j1 = Math.max(0, listx.size() - 10);
            this.blockSearchScroll = Math.max(0, Math.min(this.blockSearchScroll, j1));
            this.blockSearchScrollOffset =
                    this.blockScrollAnimation.approach(
                            (float) this.blockSearchScroll * 16.0F, 4.5F);
            ScissorStack.push(
                    view.x + this.blockDropdownX * view.scale,
                    view.y + (this.blockDropdownY + 18.0F) * view.scale,
                    184.0F * view.scale,
                    (float) i * 16.0F * view.scale,
                    2.0F);
            if (listx.isEmpty()) {
                Font font = Fonts.DEFAULT;
                float f8 = this.blockDropdownX + 6.0F;
                float f9 =
                        this.centerTextY(
                                Fonts.DEFAULT,
                                "No blocks",
                                this.blockDropdownY + 18.0F,
                                16.0F,
                                11.428572F);
                this.withOpacity(-7239018, factor);
                this.drawText(font, "No blocks", view, f8, f9, 11.428572F);
            } else {
                int k =
                        Math.max(
                                0,
                                (int) Math.floor((double) (this.blockSearchScrollOffset / 16.0F)));
                int l = Math.min(listx.size(), k + i + 2);

                for (int i1 = k; i1 < l; i1++) {
                    String textValue = (String) listx.get(i1);
                    float f3 =
                            this.blockDropdownY
                                    + 18.0F
                                    + (float) i1 * 16.0F
                                    - this.blockSearchScrollOffset;
                    if (!(f3 + 16.0F <= this.blockDropdownY + 18.0F)
                            && !(f3 >= this.blockDropdownY + this.blockDropdownHeight)) {
                        boolean flagx = this.stringListSetting.getSelectedIds().contains(textValue);
                        float f4 =
                                this.blockSelectionAnimations
                                        .computeIfAbsent(
                                                textValue,
                                                text2 ->
                                                        new EasingAnimation()
                                                                .resetProgress(flagx ? 1.0F : 0.0F))
                                        .approach(flagx ? 1.0F : 0.0F, 2.5F);
                        float f5 = 13.0F;
                        ItemStack itemstack =
                                new ItemStack(
                                        Registries.BLOCK.get(Identifier.of(textValue)).asItem());
                        if (!itemstack.isEmpty()) {
                            float f6 = 12.0F;
                            float f7 = (f5 - f6) * 0.5F;
                            Sprite sprite = ItemIconRenderer.resolveSprite(itemstack);
                            if (sprite != null) {
                                HudManager.drawSprite(
                                        sprite,
                                        view.x + (this.blockDropdownX + 3.0F + f7) * view.scale,
                                        view.y + (f3 + 1.5F + f7) * view.scale,
                                        f6 * view.scale,
                                        f6 * view.scale,
                                        this.withOpacity(-1, factor),
                                        true);
                            }
                        }

                        this.drawFadedText(
                                Fonts.DEFAULT,
                                StringListSetting.getBlockName(textValue),
                                view,
                                this.blockDropdownX + 20.0F,
                                this.centerTextY(
                                        Fonts.DEFAULT,
                                        StringListSetting.getBlockName(textValue),
                                        f3,
                                        16.0F,
                                        11.428572F),
                                126.0F,
                                11.428572F,
                                this.withOpacity(-922381, factor));
                        this.drawRoundedRect(
                                view,
                                this.blockDropdownX + 184.0F - 33.0F,
                                f3 + 4.0F,
                                7.0F,
                                7.0F,
                                this.withOpacity(
                                        this.stringListSetting.getBlockColor(textValue), factor),
                                2.0F);
                        this.drawToggle(
                                new ClickGuiScreen.View(view.x, view.y, view.scale, factor),
                                this.blockDropdownX + 184.0F - 22.0F,
                                f3 + 2.2857141F,
                                f4);
                    }
                }
            }

            ScissorStack.pop();
        } else {
            if (!this.blockDropdownOpen) {
                this.stringListSetting = null;
                this.blockColorSetting = null;
            }
        }
    }

    private void drawBlockListSetting(
            StringListSetting stringListSetting2,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float blockDropdownOpacityValue) {
        float f4 = 14.0F;
        float blockDropdownButtonXValue = f + f2 - f4;
        float blockDropdownButtonYValue = f1 - 1.5F;
        this.drawFadedText(
                Fonts.DEFAULT,
                stringListSetting2.getName(),
                view,
                f,
                this.centerTextY(Fonts.DEFAULT, stringListSetting2.getName(), f1, 11.0F, 10.0F),
                f2 - f4 - 6.0F,
                10.0F,
                this.withOpacity(-922381, blockDropdownOpacityValue));
        this.drawRoundedRect(
                view,
                blockDropdownButtonXValue,
                blockDropdownButtonYValue,
                f4,
                f4,
                this.rgbaWithOpacity(255, 255, 255, 10, blockDropdownOpacityValue),
                4.0F);
        this.drawBlockSettingsIcon(
                view,
                blockDropdownButtonXValue,
                blockDropdownButtonYValue,
                blockDropdownOpacityValue);
        if (this.stringListSetting == stringListSetting2) {
            this.blockDropdownButtonX = blockDropdownButtonXValue;
            this.blockDropdownButtonY = blockDropdownButtonYValue;
            this.blockDropdownOpacity = blockDropdownOpacityValue;
        }
    }

    private String optionAt(
            ClickGuiScreen.Panel panel,
            List list,
            float mouseX,
            float mouseY,
            float f2,
            float f3,
            float f4) {
        float f5 = 0.0F;
        float f6 = f3 + 10.0F + 6.0F;

        for (String stringValue : (Iterable<String>) (Iterable) list) {
            float f7 = Fonts.DEFAULT.measureWidth(stringValue, 10.0F) + 10.0F;
            if (f5 + f7 > f4 && f5 > 0.0F) {
                f5 = 0.0F;
                f6 += 16.0F;
            }

            if (this.contains(panel, mouseX, mouseY, f2 + f5, f6, f7, 13.0F)) {
                return stringValue;
            }

            f5 += f7 + 4.0F;
        }

        return null;
    }

    @Override
    public boolean keyPressed(KeyInput keyinput) {
        int integer = keyinput.key();
        OverlayEditor overlayEditor = EditorManager.getActiveEditor();
        if (overlayEditor != null) {
            if (integer == 256) {
                overlayEditor.saveAndClose();
            }

            return true;
        } else if (this.editingConfigName) {
            boolean flag4x;
            flag4x = ((keyinput.modifiers() & 2) != 0);

            if (integer != 256 && integer != 257 && integer != 335) {
                if ((integer == 259 || integer == 261) && !this.configName.isEmpty()) {
                    this.configName = this.configName.substring(0, this.configName.length() - 1);
                    this.configNameSelectedAll = false;
                    GuiSounds.playDeleteCharacter();
                } else if (flag4x && integer == 86 && MinecraftAccess.client.keyboard != null) {
                    String text =
                            this.sanitizeConfigName(MinecraftAccess.client.keyboard.getClipboard());
                    if (!text.isBlank()) {
                        this.configName = text;
                    }

                    this.configNameSelectedAll = false;
                    GuiSounds.playTypeCharacter();
                }
            } else {
                this.editingConfigName = false;
                this.configNameSelectedAll = false;
                GuiSounds.playSoftBindSuccess();
            }

            return true;
        } else if (this.stringListSetting != null && this.blockDropdownOpen) {
            if (integer == 256) {
                this.blockDropdownOpen = false;
                this.blockSearchFocused = false;
                this.blockSearchSelectedAll = false;
            } else if (this.blockSearchFocused) {
                this.handleSearchKey(keyinput, true);
            }

            return true;
        } else if (this.moduleBeingBound != null) {
            boolean flag3x;
            flag3x = !(integer != 256 && integer != 261);

            Module moduleValue = this.moduleBeingBound;
            if (flag3x) {
                moduleValue.setKey(-1);
            } else {
                moduleValue.setKey(integer);
            }

            this.moduleBeingBound = null;
            if (flag3x) {
                GuiSounds.playBindRemove();
                String bigName = moduleValue.getBigName();
                ChatMessages.send(bigName + " bind cleared");
            } else {
                GuiSounds.playBindSuccess();
                String bigNameValue = moduleValue.getBigName();
                String textValue = this.formatKeyCode(integer);
                String bigNameValueValue = bigNameValue;
                ChatMessages.send(bigNameValueValue + " bound to " + textValue);
            }

            return true;
        } else if (this.editingKeybind != null) {
            boolean flag2x;
            flag2x = !(integer != 256 && integer != 261);

            label255:
            {
                if (flag2x) {
                    this.editingKeybind.setValue(-1);
                    this.editingKeybind = null;
                    if (flag2x) {
                        break label255;
                    }
                } else {
                    this.editingKeybind.setValue(integer);
                    this.editingKeybind = null;
                    if (flag2x) {
                        break label255;
                    }
                }

                GuiSounds.playBindSuccess();
                return true;
            }

            GuiSounds.playBindRemove();
            return true;
        } else if (this.editingText != null) {
            boolean flag1;
            flag1 = ((keyinput.modifiers() & 2) != 0);

            if (flag1 && integer == 65) {
                if (!this.textInput.isEmpty()) {
                    this.textSelectedAll = true;
                } else {
                    this.textSelectedAll = false;
                }
            } else if (flag1 && integer == 67) {
                if (this.textSelectedAll && MinecraftAccess.client.keyboard != null) {
                    MinecraftAccess.client.keyboard.setClipboard(this.textInput);
                }
            } else if (flag1 && integer == 88) {
                if (this.textSelectedAll && MinecraftAccess.client.keyboard != null) {
                    MinecraftAccess.client.keyboard.setClipboard(this.textInput);
                    this.textInput = "";
                    this.textSelectedAll = false;
                    GuiSounds.playDeleteCharacter();
                }
            } else if (flag1 && integer == 86) {
                if (MinecraftAccess.client.keyboard != null) {
                    this.insertSettingText(MinecraftAccess.client.keyboard.getClipboard());
                }
            } else if (integer == 257 || integer == 335) {
                this.editingText.setValue(this.textInput);
                this.editingText = null;
                this.textSelectedAll = false;
                GuiSounds.playSoftBindSuccess();
            } else if (integer == 256) {
                this.editingText = null;
                this.textSelectedAll = false;
                GuiSounds.playSoftBindRemove();
            } else if (integer != 259 && integer != 261) {
                if (integer == 263 || integer == 262 || integer == 269) {
                    this.textSelectedAll = false;
                }
            } else if (this.textSelectedAll) {
                this.textInput = "";
                this.textSelectedAll = false;
                GuiSounds.playDeleteCharacter();
            } else if (integer == 259 && !this.textInput.isEmpty()) {
                this.textInput =
                        this.textInput.substring(
                                0, this.textInput.offsetByCodePoints(this.textInput.length(), -1));
                GuiSounds.playDeleteCharacter();
            }

            return true;
        } else {
            boolean flagx;
            flagx = ((keyinput.modifiers() & 2) != 0);

            if (flagx && integer == 70) {
                if (!searchFocused) {
                    searchFocused = true;
                } else {
                    searchFocused = false;
                }

                if (searchFocused) {
                    this.clearSearchWhenClosed = false;
                    this.moduleSearchCursor = this.moduleSearch.length();
                    this.searchCaretAnimation.resetValue(
                            Fonts.DEFAULT.measureWidth(this.moduleSearch, 10.0F) + 1.0F);
                    this.searchCaretInitialized = true;
                } else {
                    this.clearSearchWhenClosed = true;
                }

                return true;
            } else if (integer == 256) {
                this.beginClosing();
                return true;
            } else if (searchFocused) {
                this.handleSearchKey(keyinput, false);
                return true;
            } else {
                return super.keyPressed(keyinput);
            }
        }
    }

    private String sanitizeConfigName(String text) {
        if (text == null) {
            return "";
        } else {
            String textValue = text.replaceAll("[\\r\\n\\t]", " ").replaceAll("\\s+", " ").strip();
            return textValue.substring(0, Math.min(textValue.length(), 20));
        }
    }

    private void exportConfig() {
        String text = this.sanitizeConfigName(this.configName);
        if (!text.isBlank()) {
            String textValue = Gooba.getInstance().getConfigManager().exportConfig();
            if (MinecraftAccess.client.keyboard != null) {
                MinecraftAccess.client.keyboard.setClipboard(textValue);
            }

            ChatMessages.send("Successfully exported " + text);
            GuiSounds.playBindSuccess();
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        this.beginClosing();
        return false;
    }

    private void drawLogoGlyph(
            ClickGuiScreen.View view, float f, float f1, float widthValue, float heightValue) {
        this.drawText(
                Fonts.ICONS,
                "G",
                view,
                Fonts.ICONS.centerFirstGlyphX("G", f, widthValue, 11.428572F),
                Fonts.ICONS.centerTextY("G", f1, heightValue, 11.428572F),
                11.428572F);
    }

    private void beginClosing() {
        if (!this.closing) {
            rememberedCategory = this.selectedCategory;
            rememberedSearch = this.moduleSearch;

            for (Module moduleValue : Gooba.getInstance().getModuleRegistry().values()) {
                for (Setting setting : moduleValue.getSettings()) {
                    if (setting instanceof ColorSetting colorSetting4) {
                        colorSetting4.expanded = false;
                    }
                }
            }

            this.openColorPicker = null;
            this.draggedColorSetting = null;
            this.blockDropdownOpen = false;
            this.blockSearchFocused = false;
            this.configSidebarOpen = false;
            this.editingConfigName = false;
            this.configNameSelectedAll = false;
            this.closing = true;
            searchFocused = false;
            this.clearSearchWhenClosed = false;
            GuiSounds.playClose();
            super.close();
            MinecraftAccess.client.mouse.lockCursor();
        }
    }

    private String nullToEmpty(String text) {
        return text == null ? "" : text;
    }

    private float getModuleHeight(Module moduleValue) {
        float f = 0.0F;

        for (Setting setting : moduleValue.getSettings()) {
            if (this.isDisplayableSetting(setting)) {
                f += (this.getSettingHeight(setting) + 6.0F) * this.getSettingVisibility(setting);
            }
        }

        if (f > 0.0F) {
            f += 4.0F;
        }

        return 18.0F
                + f * this.clampUnit(moduleValue.getExpandedAnimation().getInterpolatedProgress());
    }

    private float clampUnit(float f) {
        return Math.max(0.0F, Math.min(1.0F, f));
    }

    private void drawFadedText(
            Font font,
            String stringValue,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3,
            int color) {
        font.drawFadedText(
                stringValue,
                view.x + f * view.scale,
                view.y + f1 * view.scale,
                f2 * view.scale,
                color,
                f3 * view.scale);
    }

    private void drawColorPicker(
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float f8) {
        if (this.drawContext != null) {
            Matrix3x2fStack matrix3x2fstack = this.drawContext.getMatrices();
            matrix3x2fstack.pushMatrix();
            matrix3x2fstack.scale(this.screenScale, this.screenScale);
            matrix3x2fstack.translate(view.x, view.y);
            matrix3x2fstack.scale(view.scale, view.scale);
            ToggleIconRenderer.drawColorPicker(
                    this.drawContext,
                    f,
                    f1,
                    f2,
                    f3,
                    f4,
                    f5,
                    f6,
                    f7,
                    new Color(HUDModule.getInstance().clientColorSetting.getColor(), true),
                    f8);
            matrix3x2fstack.popMatrix();
        }
    }

    @Override
    protected void init() {
        this.closing = false;
        searchFocused = false;
        this.draggedSlider = null;
        this.draggedColorSetting = null;
        this.openColorPicker = null;
        this.stringListSetting = null;
        this.blockColorSetting = null;
        this.blockDropdownOpen = false;
        this.blockSearchFocused = false;
        this.blockSearch = "";
        this.blockSearchCursor = 0;
        this.blockSearchSelectedAll = false;
        this.blockSearchScroll = 0;
        this.blockSearchScrollOffset = 0.0F;
        this.blockDropdownAnimation.resetValue(0.0F);
        this.editingKeybind = null;
        this.moduleBeingBound = null;
        this.editingText = null;
        themePreset = Gooba.getInstance().getThemeManager().getThemePreset();
        themePreset2 = themePreset;
        themePresets = ThemePreset.values();
        this.openAnimation.resetValue(0.0F);
        this.searchExpansionAnimation.snapTo(0.0);
        this.searchCaretAnimation.resetValue(0.0F);
        this.moduleSearch = rememberedSearch;
        this.moduleSearchCursor = this.moduleSearch.length();
        this.moduleSearchSelectedAll = false;
        this.searchFilterAnimation.resetValue(this.moduleSearch.isBlank() ? 0.0F : 1.0F);
        this.categoryTransitionAnimation.resetValue(1.0F);
        this.configSidebarAnimation.resetValue(0.0F);
        this.configSidebarOpen = false;
        this.editingConfigName = false;
        this.configNameSelectedAll = false;
        this.searchCaretInitialized = false;
        this.clearSearchWhenClosed = false;
        this.selectedCategory =
                rememberedCategory == null ? ModuleCategory.COMBAT : rememberedCategory;
        this.previousCategory = null;
        this.tooltipAnimation.snapTo(0.0);
        this.lastFrameNanos = System.nanoTime();

        for (Module moduleValue : Gooba.getInstance().getModuleRegistry().values()) {
            moduleValue.getToggleAnimation().resetProgress(moduleValue.isEnabled() ? 1.0F : 0.0F);
            moduleValue
                    .getExpandedAnimation()
                    .resetProgress(moduleValue.isExpanded() ? 1.0F : 0.0F);
            this.moduleVisibilityAnimations
                    .computeIfAbsent(moduleValue, module -> new EasingAnimation())
                    .resetValue(this.matchesSearch(moduleValue) ? 1.0F : 0.0F);

            for (Setting setting : moduleValue.getSettings()) {
                if (setting instanceof ColorSetting colorSetting4) {
                    colorSetting4.expanded = false;
                    this.colorExpansionAnimations
                            .computeIfAbsent(colorSetting4, colorSetting5 -> new EasingAnimation())
                            .resetValue(0.0F);
                }
            }
        }

        GuiSounds.playOpen();
        MenuBackgroundRenderer.playMusic(0.15F);
    }

    private void drawSliderSetting(
            SliderSetting sliderSetting2,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3) {
        if (this.draggedSlider == sliderSetting2) {
            this.updateSliderValue(sliderSetting2, this.mouseX);
        }

        float f4 =
                MathUtils.clamp(
                        (sliderSetting2.getFloat() - sliderSetting2.minValue)
                                / (sliderSetting2.maxValue - sliderSetting2.minValue),
                        0.0F,
                        1.0F);
        float f5 =
                this.sliderFractions.compute(
                        sliderSetting2,
                        (sliderSetting3, f1x) ->
                                f1x == null
                                        ? f4
                                        : f1x
                                                + (f4 - f1x)
                                                        * (1.0F
                                                                - (float)
                                                                        Math.exp(
                                                                                (double)
                                                                                        (-this
                                                                                                .frameDelta))));
        String stringValue =
                sliderSetting2.step % 1.0F == 0.0F
                        ? Integer.toString(Math.round(sliderSetting2.getFloat()))
                        : Float.toString(
                                (float) Math.round(sliderSetting2.getFloat() * 100.0F) / 100.0F);
        float f6 = Fonts.DEFAULT.measureWidth(stringValue, 10.0F) + 7.0F;
        this.drawFadedText(
                Fonts.DEFAULT,
                sliderSetting2.getName(),
                view,
                f,
                this.centerTextY(Fonts.DEFAULT, sliderSetting2.getName(), f1, 13.0F, 10.0F),
                f2 - f6 - 4.0F,
                10.0F,
                this.withOpacity(-922381, f3));
        this.drawRoundedRect(
                view, f + f2 - f6, f1, f6, 13.0F, this.getAccentColor(f3 * 12.0F / 255.0F), 3.0F);
        this.drawRoundedOutline(
                view,
                f + f2 - f6,
                f1,
                f6,
                13.0F,
                0.5F,
                this.rgbaWithOpacity(255, 255, 255, 18, f3),
                3.0F);
        this.drawCenteredText(
                Fonts.DEFAULT,
                stringValue,
                view,
                f + f2 - f6 * 0.5F,
                this.centerTextY(Fonts.DEFAULT, stringValue, f1, 13.0F, 10.0F),
                10.0F,
                this.withOpacity(-922381, f3));
        float f7 = f1 + 15.75F;
        float f8 = 5.5F;
        float f9 = f2 * f5;
        float f10 = Math.min(2.75F, f9 * 0.5F);
        this.drawRoundedRect(view, f, f7, f2, f8, this.rgbaWithOpacity(50, 52, 60, 130, f3), 2.75F);
        this.drawRoundedRect(view, f, f7, f9, f8, this.getAccentColor(f3), f10);
        this.drawCircle(
                view, f + 4.0F + (f2 - 8.0F) * f5, f1 + 18.5F, 4.0F, this.withOpacity(-1, f3));
    }

    public void renderGui(DrawContext drawcontext, RenderTickCounter rendertickcounter) {
        this.drawContext = drawcontext;
        this.screenScale = 2.0F / (float) MinecraftAccess.client.getWindow().getScaleFactor();
        this.tickDelta = rendertickcounter.getTickProgress(false);
        long nowNanos = System.nanoTime();
        this.frameDelta = (float) (nowNanos - this.lastFrameNanos) / 5.0E7F;
        this.lastFrameNanos = nowNanos;
        float f = (float) MinecraftAccess.client.getWindow().getScaledWidth() / this.screenScale;
        float f1 = (float) MinecraftAccess.client.getWindow().getScaledHeight() / this.screenScale;
        float f2 = this.clampUnit(this.openAnimation.approach(this.closing ? 0.0F : 1.0F, 2.2F));
        float f3 = f2 * f2 * (3.0F - 2.0F * f2);
        if (this.closing) {
            this.mouseX = -10000.0F;
            this.mouseY = -10000.0F;
            if (f3 <= 0.02F) {
                this.closing = false;
                MenuBackgroundRenderer.stopMusic();
                return;
            }
        }

        for (Module moduleValue : Gooba.getInstance().getModuleRegistry().values()) {
            moduleValue
                    .getToggleAnimation()
                    .sampleThenAdvanceProgress(moduleValue.isEnabled(), 0.3F, this.tickDelta);
            moduleValue.getExpandedAnimation().updateSmoothProgress(moduleValue.isExpanded(), 0.5F);

            for (Setting setting : moduleValue.getSettings()) {
                if (this.isDisplayableSetting(setting)) {
                    this.updateSettingVisibility(setting);
                }
            }
        }

        OverlayEditor overlayEditor = EditorManager.getActiveEditor();
        if (overlayEditor != null) {
            overlayEditor.render(
                    (float) ((int) f), (float) ((int) f1), this.mouseX, this.mouseY, f3);
            Gooba.getInstance().getHudManager().flush();
            HudManager.endHudRender();
        } else {
            ClickGUIModule clickGUIModule =
                    Gooba.getInstance().getModuleRegistry().findModule(ClickGUIModule.class);
            BackgroundBlur.blurMenu();
            guiScale =
                    (clickGUIModule == null ? 1.0F : clickGUIModule.sizeSetting.getFloat()) * 0.7F;
            float f4 = (f - 540.0F * guiScale) * 0.5F;
            float f5 = (f1 - 320.0F * guiScale) * 0.5F;
            ClickGuiScreen.Panel panel = this.getActivePanel();
            panel.x = f4;
            panel.y = f5;
            String text = this.drawCategoryPanel(panel, f3);
            this.drawConfigSidebar(panel, f3);
            this.drawTooltip(text, f, f5, f3);
            RenderBatchDispatcher.flush();
            HudManager.endHudRender();
        }
    }

    private void drawRoundedRect(
            ClickGuiScreen.View view, float f, float f1, float f2, float f3, int color, float f4) {
        RenderUtils.Render2D.drawRoundedRect(
                view.x + f * view.scale,
                view.y + f1 * view.scale,
                f2 * view.scale,
                f3 * view.scale,
                color,
                f4 * view.scale);
    }

    private float centerTextY(Font font, String text, float f, float f1, float size) {
        return font.centerFirstGlyphY(text, f + f1 * 0.5F, size);
    }

    private String drawCategoryPanel(ClickGuiScreen.Panel panelValue, float f) {

        float guiScaleValue = guiScale;
        float widthValue = 540.0F * guiScaleValue;
        float heightValue = 320.0F * guiScaleValue;
        float innerX = panelValue.x;
        float innerY = panelValue.y;
        ClickGuiScreen.View view = new ClickGuiScreen.View(innerX, innerY, guiScaleValue, f);
        RenderUtils.Render2D.drawShadowWithOpacity(
                innerX,
                innerY,
                widthValue,
                heightValue,
                HUDModule.getInstance().getBackgroundColor(view.alpha),
                9.0F * guiScaleValue,
                16.0F * guiScaleValue,
                1.0F,
                1.0F);
        this.drawBlurredRoundedRect(view, 0.0F, 0.0F, 540.0F, 320.0F, 9.0F, view.alpha);
        this.drawPanelBackground(
                view, 0.0F, 0.0F, 116.0F, 320.0F, 9.0F, 0.0F, 0.0F, 9.0F, view.alpha);
        this.drawPanelBackground(
                view, 116.0F, 0.0F, 424.0F, 38.0F, 0.0F, 7.0F, 0.0F, 0.0F, view.alpha);
        this.drawPanelBackground(
                view, 116.0F, 38.0F, 424.0F, 282.0F, 0.0F, 0.0F, 7.0F, 0.0F, view.alpha);
        HUDModule.getInstance()
                .drawLightSweep(
                        innerX, innerY, widthValue, heightValue, 9.0F * guiScaleValue, view.alpha);
        this.drawRoundedRect(
                view, 116.0F, 43.5F, 424.0F, 1.0F, this.getAccentColor(view.alpha * 0.16F), 0.0F);
        this.drawRoundedRect(
                view, 115.5F, 0.0F, 1.0F, 320.0F, this.getAccentColor(view.alpha * 0.16F), 0.0F);
        float f6 = 82.0F * guiScaleValue;
        float f7 = innerX + (116.0F * guiScaleValue - f6) * 0.5F;
        float f8 = innerY - 3.0F * guiScaleValue;
        RenderUtils.Images.drawOpaqueImage(
                GLOW_TEXTURE, f7, f8, f6, f6, this.getAccentColor(view.alpha * 105.0F / 255.0F));
        float f9 = 46.0F;
        float f10 = (116.0F - f9) * 0.5F;
        float f11 = 12.0F;
        Font font = Fonts.LOGO;
        this.getAccentColor(view.alpha);
        this.drawText(font, "\ue000", view, f10, f11, f9);
        float textHighlightPosition = this.getTextHighlightPosition();
        ModuleCategory[] moduleCategorys = this.getCategoryOrder();

        for (int i = 0; i < moduleCategorys.length; i++) {
            ModuleCategory moduleCategory2 = moduleCategorys[i];
            float f13 = 74.0F + (float) i * 29.0F;
            float f14;
            if (moduleCategory2 == this.selectedCategory) {
                f14 =
                        this.clampUnit(
                                moduleCategory2.selectionAnimation.sampleThenAdvanceProgress(
                                        true, 0.32F, this.tickDelta));
            } else {
                f14 =
                        this.clampUnit(
                                moduleCategory2.selectionAnimation.sampleThenAdvanceProgress(
                                        false, 0.32F, this.tickDelta));
            }

            this.drawBlurredRoundedRect(view, 10.0F, f13, 96.0F, 23.0F, 5.0F, view.alpha);
            this.drawRoundedRect(
                    view,
                    10.0F,
                    f13,
                    96.0F,
                    23.0F,
                    this.rgbaWithOpacity(255, 255, 255, Math.round(5.0F + 24.0F * f14), view.alpha),
                    5.0F);
            float f15 = 15.0F;
            float f16 = f13 + 3.5F;
            String icon = moduleCategory2.getIcon();
            Font fontValue =
                    moduleCategory2 == ModuleCategory.DONUT
                            ? Fonts.DONUT_ICON
                            : Fonts.CATEGORY_ICONS;
            float f33 = fontValue.centerTextX(icon, f15, 16.0F, 11.428572F);
            float f34 = fontValue.centerTextY(icon, f16, 16.0F, 11.428572F);
            this.withOpacity(-1, view.alpha);
            this.drawText(fontValue, icon, view, f33, f34, 11.428572F);
            float f17 =
                    this.centerTextY(
                                    Fonts.DEFAULT,
                                    moduleCategory2.getDisplayName(),
                                    f13,
                                    23.0F,
                                    11.428572F)
                            - 0.35F;
            if (moduleCategory2 == this.selectedCategory) {
                this.drawHighlightedText(
                        Fonts.DEFAULT,
                        moduleCategory2.getDisplayName(),
                        view,
                        36.0F,
                        f17,
                        11.428572F,
                        textHighlightPosition,
                        view.alpha);
            } else {
                font = Fonts.DEFAULT;
                String displayName = moduleCategory2.getDisplayName();
                this.withOpacity(-3029036, view.alpha);
                this.drawText(font, displayName, view, 36.0F, f17, 11.428572F);
            }
        }

        this.drawModuleSearch(view);
        String username = MinecraftAccess.client.getSession().getUsername();
        NameProtectModule nameProtectModule =
                Gooba.getInstance().getModuleRegistry().findModule(NameProtectModule.class);
        if (nameProtectModule != null && nameProtectModule.isEnabled()) {
            username = nameProtectModule.protectedName();
        }

        float f23 = 514.0F;
        float width3 = 20.0F;
        float f25 = 14.0F;
        float f26 = 4.0F;
        float f27 = 1.5F;
        float f28 = 6.0F;
        float f29 = Math.min(100.0F, Fonts.DEFAULT.measureWidth(username, 10.0F));
        float f18 = f26 + f25 + f27 + f29 + f28;
        float f19 = f23 - 7.0F - f18;
        this.drawBlurredRoundedRect(view, f19, 9.0F, f18, 20.0F, 5.0F, view.alpha);
        this.drawRoundedRect(
                view,
                f19,
                9.0F,
                f18,
                20.0F,
                this.rgbaWithOpacity(255, 255, 255, 6, view.alpha),
                5.0F);
        float f20 = f19 + f26;
        float f21 = 12.0F;
        ClientPlayerEntity clientplayerentity = MinecraftAccess.client.player;
        if (clientplayerentity instanceof AbstractClientPlayerEntity) {
            RenderUtils.Images.drawRoundedRegion(
                    clientplayerentity.getSkin().body().texturePath(),
                    view.x + f20 * view.scale,
                    view.y + f21 * view.scale,
                    f25 * view.scale,
                    f25 * view.scale,
                    0.125F,
                    0.125F,
                    0.25F,
                    0.25F,
                    this.withOpacity(-1, view.alpha),
                    3.0F * view.scale);
            RenderUtils.Images.drawRoundedRegion(
                    clientplayerentity.getSkin().body().texturePath(),
                    view.x + f20 * view.scale,
                    view.y + f21 * view.scale,
                    f25 * view.scale,
                    f25 * view.scale,
                    0.625F,
                    0.125F,
                    0.75F,
                    0.25F,
                    this.withOpacity(-1, view.alpha),
                    3.0F * view.scale);
        } else {
            this.drawBlurredRoundedRect(view, f20, f21, f25, f25, 3.0F, view.alpha);
        }

        this.drawHighlightedText(
                Fonts.DEFAULT,
                username,
                view,
                f20 + f25 + f27,
                this.centerTextY(Fonts.DEFAULT, username, 9.0F, 20.0F, 10.0F) - 0.3F,
                10.0F,
                textHighlightPosition,
                view.alpha);
        this.drawBlurredRoundedRect(view, f23, 9.0F, width3, width3, 5.0F, view.alpha);
        this.drawRoundedRect(
                view,
                f23,
                9.0F,
                width3,
                width3,
                this.rgbaWithOpacity(255, 255, 255, 8, view.alpha),
                5.0F);
        font = Fonts.GOOBA;
        float f31 = Fonts.GOOBA.centerTextX("l", f23, width3, 11.428572F);
        float f32 = Fonts.GOOBA.centerTextY("l", 9.0F, width3, 11.428572F);
        this.withOpacity(-1581335, view.alpha);
        this.drawText(font, "l", view, f31, f32, 11.428572F);
        float f22 =
                this.clampUnit(
                        this.searchFilterAnimation.approach(
                                this.moduleSearch.isBlank() ? 0.0F : 1.0F, 5.5F));
        this.drawModuleColumnBackgrounds(panelValue, view);
        float f30 = this.clampUnit(this.categoryTransitionAnimation.approach(1.0F, 5.5F));
        this.openColorPicker = null;
        if (this.previousCategory != null && f30 < 0.999F && f22 <= 0.001F) {
            ClickGuiScreen.Panel panel = this.findPanel(this.previousCategory);
            panel.x = panelValue.x;
            panel.y = panelValue.y;
            this.drawModules(
                    panel,
                    new ClickGuiScreen.View(view.x, view.y, view.scale, view.alpha * (1.0F - f30)));
        } else if (f30 >= 0.999F) {
            this.previousCategory = null;
        }

        this.openColorPicker = null;
        String stringValue =
                this.drawModules(
                        panelValue,
                        new ClickGuiScreen.View(
                                view.x,
                                view.y,
                                view.scale,
                                view.alpha
                                        * (this.previousCategory != null && !(f22 > 0.001F)
                                                ? f30
                                                : 1.0F)));
        this.drawClippedSettingIcons(panelValue, view);
        this.drawBlockDropdown(view);
        if (this.stringListSetting != null
                && this.blockColorSetting != null
                && this.blockColorSetting.expanded) {
            this.openColorPicker = this.blockColorSetting;
            this.colorPickerX = this.blockDropdownX + 184.0F + 10.0F;
            if (this.colorPickerX + 79.0F > 535.0F) {
                this.colorPickerX = this.blockDropdownX - 89.0F;
            }

            this.colorPickerY = MathUtils.clamp(this.blockDropdownY + 18.0F, 5.0F, 254.0F);
            this.colorPickerButtonX = this.colorPickerX - 20.0F;
            this.colorPickerButtonY = this.colorPickerY;
            this.colorPickerOpacity =
                    this.blockDropdownOpacity
                            * this.clampUnit(this.blockDropdownAnimation.getFloatValue());
        }

        this.drawOpenColorPicker(view);
        return stringValue;
    }

    private void animateTo(
            EasingAnimation easingAnimation2, float f, float f1, EasingFunction easingFunction33) {
        if (Math.abs(easingAnimation2.getTargetValue() - (double) f) > 1.0E-4) {
            easingAnimation2.animateTo((double) f, (double) f1, easingFunction33);
        }
    }

    private boolean configNameExists(String text) {
        return this.savedConfigs.stream()
                .anyMatch(savedConfig -> savedConfig.getName().equalsIgnoreCase(text));
    }

    private void selectCategory(ModuleCategory moduleCategory2, ClickGuiScreen.Panel panel) {
        if (moduleCategory2 != this.selectedCategory) {
            this.previousCategory = this.selectedCategory;
            this.blockDropdownOpen = false;
            this.blockSearchFocused = false;
            this.selectedCategory = moduleCategory2;
            rememberedCategory = moduleCategory2;
            this.categoryTransitionAnimation.resetValue(0.0F);
            ClickGuiScreen.Panel panelValue = this.getActivePanel();
            panelValue.x = panel.x;
            panelValue.y = panel.y;
        }
    }

    private ModuleCategory[] getCategoryOrder() {
        return new ModuleCategory[] {
            ModuleCategory.COMBAT,
            ModuleCategory.PLAYER,
            ModuleCategory.RENDER,
            ModuleCategory.OTHER,
            ModuleCategory.DONUT,
            ModuleCategory.CLIENT
        };
    }

    private List getModules(ModuleCategory moduleCategory2) {
        boolean flagx;
        flagx = (this.searchFilterAnimation.getFloatValue() > 0.001F);

        return Gooba.getInstance().getModuleRegistry().values().stream()
                .filter(moduleValue -> flagx || moduleValue.getCategory() == moduleCategory2)
                .sorted(Comparator.comparing(Module::getBigName, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    private int getHighlightedTextColor(float f, float f1, float f2) {
        float f3 = Math.abs(f - f1);
        float f4 = this.clampUnit(1.0F - f3 / 1.1F);
        f4 = f4 * f4 * (3.0F - 2.0F * f4);
        float f5 = 1.0F - f4 * 0.65F;
        return ColorUtils.withOpacity(
                HUDModule.getInstance().getAccentColor(1.0F), f5 * this.clampUnit(f2));
    }

    private void drawClippedToggleIcon(
            ClickGuiScreen.View view, float f, float f1, int i, float f2) {
        if (this.drawContext != null) {
            int j = (int) Math.floor((double) ((view.x + 122.0F * view.scale) * this.screenScale));
            int k = (int) Math.floor((double) ((view.y + 44.0F * view.scale) * this.screenScale));
            int l = (int) Math.ceil((double) ((view.x + 539.0F * view.scale) * this.screenScale));
            int i1 = (int) Math.ceil((double) ((view.y + 310.0F * view.scale) * this.screenScale));
            this.drawContext.enableScissor(j, k, l, i1);
            Matrix3x2fStack matrix3x2fstack = this.drawContext.getMatrices();
            matrix3x2fstack.pushMatrix();
            matrix3x2fstack.scale(this.screenScale, this.screenScale);
            matrix3x2fstack.translate(view.x, view.y);
            matrix3x2fstack.scale(view.scale, view.scale);
            ToggleIconRenderer.drawToggle(
                    this.drawContext,
                    f,
                    f1,
                    i,
                    new Color(HUDModule.getInstance().clientColorSetting.getColor(), true),
                    f2,
                    1.2727273F);
            matrix3x2fstack.popMatrix();
            this.drawContext.disableScissor();
        }
    }

    private void drawBlockSettingsIcon(ClickGuiScreen.View view, float f, float f1, float f2) {
        int i = this.withOpacity(-1, f2);
        Matrix3x2fStack matrix3x2fstack = this.drawContext.getMatrices();
        float f3 = 12.0F;
        float f4 = f3 * 61.0F / 60.0F;
        matrix3x2fstack.pushMatrix();
        matrix3x2fstack.translate(
                view.x + (f + (14.0F - f3) * 0.5F) * view.scale,
                view.y + (f1 + (14.0F - f4) * 0.5F) * view.scale);
        matrix3x2fstack.scale(f3 * view.scale / 60.0F, f4 * view.scale / 61.0F);
        this.drawContext.drawTexture(
                ColorPickerRenderer.MSDF_ICON_PIPELINE,
                TOGGLE_ICONS_TEXTURE,
                0,
                0,
                412.5F,
                0.5F,
                60,
                61,
                532,
                532,
                i);
        matrix3x2fstack.popMatrix();
    }

    private boolean contains(
            ClickGuiScreen.Panel panel,
            float mouseX,
            float mouseY,
            float f2,
            float f3,
            float f4,
            float f5) {
        return MathUtils.containsPoint(
                mouseX,
                mouseY,
                panel.x + f2 * guiScale,
                panel.y + f3 * guiScale,
                f4 * guiScale,
                f5 * guiScale);
    }

    private void setSearchState(
            String text,
            int blockSearchCursorValue,
            boolean blockSearchSelectedAllValue,
            boolean flag1) {
        if (flag1) {
            if (!this.blockSearch.equals(text)) {
                this.blockSearchScroll = 0;
            }

            this.blockSearch = text;
            this.blockSearchCursor = blockSearchCursorValue;
            this.blockSearchSelectedAll = blockSearchSelectedAllValue;
        } else {
            if (!this.moduleSearch.equals(text)) {
                this.resetSearchAnimations();
            }

            this.moduleSearch = text;
            this.moduleSearchCursor = blockSearchCursorValue;
            this.moduleSearchSelectedAll = blockSearchSelectedAllValue;
        }
    }

    private void drawModuleColumnBackgrounds(ClickGuiScreen.Panel panel, ClickGuiScreen.View view) {
        List listx = this.getModules(panel.category);
        float[] afloat = new float[] {0.0F, 0.0F};
        float[] values = new float[] {0.0F, 0.0F};

        for (int i = 0; i < listx.size(); i++) {
            Module moduleValue = (Module) listx.get(i);
            int j = i & 1;
            float f =
                    this.clampUnit(
                            this.moduleVisibilityAnimations
                                    .computeIfAbsent(
                                            moduleValue,
                                            module ->
                                                    new EasingAnimation()
                                                            .resetValue(
                                                                    this.matchesSearch(moduleValue)
                                                                            ? 1.0F
                                                                            : 0.0F))
                                    .approach(this.matchesSearch(moduleValue) ? 1.0F : 0.0F, 5.5F));
            float moduleHeight = this.getModuleHeight(moduleValue);
            if (f > 0.001F) {
                values[j] = Math.max(values[j], afloat[j] + moduleHeight);
            }

            afloat[j] += (moduleHeight + 3.0F) * f;
        }

        float f6 = 5.0F;
        float f7 = 262.0F;

        for (int k = 0; k < 2; k++) {
            if (!(values[k] <= 0.001F)) {
                float f8 = 127.0F + (float) k * 208.5F;
                float f9 = f8 - f6;
                float f2 = 48.0F - f6;
                float f3 = 193.5F + f6 * 2.0F;
                float f4 = Math.min(f7, values[k]) + f6 * 2.0F;
                float alpha = view.alpha;
                this.drawBlurredRect(
                        view,
                        f9,
                        f2,
                        f3,
                        f4,
                        5.0F,
                        5.0F,
                        5.0F,
                        5.0F,
                        alpha,
                        HUDModule.getInstance().moduleCardsSetting.getColor());
            }
        }
    }

    @Override
    public void close() {
        this.beginClosing();
    }

    private void drawConfigSidebar(ClickGuiScreen.Panel panel, float f) {
        float f1 =
                this.clampUnit(
                        this.configSidebarAnimation.approach(
                                this.configSidebarOpen ? 1.0F : 0.0F, 3.0F));
        if (!(f1 <= 0.001F)) {
            float f2 = 541.5F + (1.0F - f1) * 5.0F;
            ClickGuiScreen.View view = new ClickGuiScreen.View(panel.x, panel.y, guiScale, f * f1);
            RenderUtils.Render2D.drawShadowWithOpacity(
                    view.x + f2 * view.scale,
                    view.y,
                    114.0F * view.scale,
                    320.0F * view.scale,
                    HUDModule.getInstance().getBackgroundColor(view.alpha),
                    9.0F * view.scale,
                    16.0F * view.scale,
                    1.0F,
                    1.0F);
            this.drawBlurredRoundedRect(view, f2, 0.0F, 114.0F, 320.0F, 9.0F, view.alpha);
            this.drawRoundedRect(
                    view,
                    f2,
                    0.0F,
                    114.0F,
                    320.0F,
                    this.rgbaWithOpacity(255, 255, 255, 6, view.alpha),
                    9.0F);
            float f3 = f2 + 6.0F;
            float f4 = 102.0F;
            float f5 = (f4 - 2.0F) * 0.5F;
            float f6 = 6.0F;
            this.drawConfigButton(view, "Import", f3, f6, f5);
            this.drawConfigButton(view, "Export", f3 + f5 + 2.0F, f6, f5);
            float f7 = f6 + 18.0F + 2.0F;
            this.drawConfigButton(view, "Reset All", f3, f7, f4);
            float f8 = f7 + 18.0F + 2.0F;
            this.drawBlurredRoundedRect(view, f3, f8, f4, 18.0F, 4.0F, view.alpha);
            this.drawRoundedRect(
                    view,
                    f3,
                    f8,
                    f4,
                    18.0F,
                    this.rgbaWithOpacity(255, 255, 255, 8, view.alpha),
                    4.0F);
            String text = this.editingConfigName ? "_" : "";
            String textValue = this.configName;
            String stringValue = textValue + text;
            this.drawFadedText(
                    Fonts.DEFAULT,
                    stringValue,
                    view,
                    f3 + 5.0F,
                    this.centerTextY(Fonts.DEFAULT, stringValue, f8, 18.0F, 10.0F) - 0.4F,
                    f4 - 10.0F,
                    10.0F,
                    this.withOpacity(-725001, view.alpha));
            float f9 = f8 + 18.0F + 2.0F;
            float f10 = 314.0F;
            float f11 = Math.max(0.0F, f10 - f9);
            float f12 = 0.0F;

            for (ClickGuiScreen.SavedConfig savedConfig : this.savedConfigs) {
                f12 += 32.0F * savedConfig.getOpacity();
            }

            if (f12 > 0.0F) {
                f12 -= 2.0F;
            }

            this.configMaxScroll = Math.max(0.0F, f12 - f11);
            this.configScrollTarget =
                    MathUtils.clamp(this.configScrollTarget, 0.0F, this.configMaxScroll);
            float f16 = 1.0F - (float) Math.exp((double) (-this.frameDelta * 0.85F));
            this.configScroll =
                    this.configScroll + (this.configScrollTarget - this.configScroll) * f16;
            if (Math.abs(this.configScrollTarget - this.configScroll) < 0.01F) {
                this.configScroll = this.configScrollTarget;
            }

            ScissorStack.push(
                    view.x + f3 * view.scale,
                    view.y + f9 * view.scale,
                    f4 * view.scale,
                    f11 * view.scale,
                    2.0F);
            float f17 = f9 - this.configScroll;

            for (int i = this.savedConfigs.size() - 1; i >= 0; i--) {
                ClickGuiScreen.SavedConfig savedConfigValue = this.savedConfigs.get(i);
                float f13 = savedConfigValue.updateOpacity();
                if (savedConfigValue.isDeleted() && f13 <= 0.01F) {
                    this.savedConfigs.remove(i);
                } else {
                    float f14 = f3 + (1.0F - f13) * 8.0F;
                    float factor = view.alpha * f13;
                    if (f17 + 30.0F >= f9 && f17 <= f10) {
                        this.drawBlurredRoundedRect(view, f14, f17, f4, 30.0F, 4.0F, factor);
                        this.drawRoundedRect(
                                view,
                                f14,
                                f17,
                                f4,
                                30.0F,
                                this.rgbaWithOpacity(255, 255, 255, 7, factor),
                                4.0F);
                        this.drawFadedText(
                                Fonts.DEFAULT,
                                savedConfigValue.getName(),
                                view,
                                f14 + 5.0F,
                                f17 + 5.0F,
                                f4 - 10.0F,
                                10.0F,
                                this.withOpacity(-725001, factor));
                        this.drawFadedText(
                                Fonts.DEFAULT,
                                "Author: Annonymous",
                                view,
                                f14 + 5.0F,
                                f17 + 17.0F,
                                f4 - 10.0F,
                                10.0F,
                                this.withOpacity(-7239018, factor));
                    }

                    f17 += 32.0F * f13;
                }
            }

            ScissorStack.pop();
        }
    }

    private void updateColorPicker(
            ColorSetting colorSetting4, float f, float f1, ClickGuiScreen.Panel panel) {
        float f2 = f / guiScale - panel.x / guiScale;
        float f3 = f1 / guiScale - panel.y / guiScale;
        Color color = new Color(colorSetting4.getColor(), true);
        float[] afloat = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
        int alpha = color.getAlpha();
        float f4;
        if (this.colorDragChannel == 0) {
            afloat[1] = MathUtils.clamp((f2 - this.colorPickerX) / 56.0F, 0.0F, 1.0F);
            afloat[2] = 1.0F - MathUtils.clamp((f3 - this.colorPickerY) / 56.0F, 0.0F, 1.0F);
            f4 = afloat[1];
        } else if (this.colorDragChannel == 1) {
            afloat[0] = MathUtils.clamp((f3 - this.colorPickerY) / 56.0F, 0.0F, 1.0F);
            f4 = afloat[0];
        } else {
            f4 = 1.0F - MathUtils.clamp((f3 - this.colorPickerY) / 56.0F, 0.0F, 1.0F);
            alpha = Math.round(f4 * 255.0F);
        }

        colorSetting4.setValue(
                alpha << 24 | Color.HSBtoRGB(afloat[0], afloat[1], afloat[2]) & 16777215);
        GuiSounds.playSliderDrag(f4);
    }

    @Override
    public boolean charTyped(CharInput charinput) {
        if (!charinput.isValidChar()) {
            return true;
        } else {
            String text = charinput.asString();
            if (this.editingConfigName) {
                String textValue = this.sanitizeConfigName(text);
                if (!textValue.isBlank()) {
                    String configName2;
                    if (this.configNameSelectedAll) {
                        configName2 = textValue;
                    } else {
                        String configNameValue = this.configName;
                        configName2 = this.sanitizeConfigName(configNameValue + textValue);
                    }

                    this.configName = configName2;
                    this.configNameSelectedAll = false;
                    GuiSounds.playTypeCharacter();
                }

                return true;
            } else if (this.stringListSetting != null
                    && this.blockDropdownOpen
                    && this.blockSearchFocused) {
                this.insertSearchText(text, true);
                return true;
            } else if (this.editingText != null) {
                this.insertSettingText(text);
                return true;
            } else if (searchFocused) {
                this.insertSearchText(text, false);
                return true;
            } else {
                return super.charTyped(charinput);
            }
        }
    }

    private ClickGuiScreen.Panel panelAt(float mouseX, float mouseY) {
        ClickGuiScreen.Panel panel = this.getActivePanel();
        return this.contains(panel, mouseX, mouseY, 0.0F, 0.0F, 540.0F, 320.0F) ? panel : null;
    }

    @Override
    public void renderBackground(DrawContext drawcontext, int i, int j, float f) {}

    @Override
    public boolean mouseDragged(Click click, double d0, double d1) {
        OverlayEditor overlayEditor = EditorManager.getActiveEditor();
        if (overlayEditor != null) {
            return overlayEditor.capturesMouse(
                    (float) (d0 / (double) this.screenScale),
                    (float) (d1 / (double) this.screenScale));
        } else {
            float mouseX = (float) (click.x() / (double) this.screenScale);
            float f1 = (float) (click.y() / (double) this.screenScale);
            if (this.draggedSlider != null) {
                this.updateSliderValue(this.draggedSlider, mouseX);
            }

            if (this.draggedColorSetting != null) {
                this.updateColorPicker(this.draggedColorSetting, mouseX, f1, this.getActivePanel());
            }

            return true;
        }
    }

    private float getSettingVisibility(Setting setting) {
        return this.clampUnit(
                this.settingVisibilityAnimations
                        .computeIfAbsent(
                                setting, settingValue -> new EasingAnimation().resetProgress(0.0F))
                        .getInterpolatedProgress());
    }

    private void drawColorSetting(
            ColorSetting colorSetting4,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3) {
        float f4 =
                this.colorExpansionAnimations
                        .computeIfAbsent(colorSetting4, colorSetting5 -> new EasingAnimation())
                        .approach(colorSetting4.expanded ? 1.0F : 0.0F, 3.2F);
        float f5 = 14.0F;
        float colorPickerButtonXValue = f + f2 - f5;
        float value = f1 - 1.5F;
        this.drawFadedText(
                Fonts.DEFAULT,
                colorSetting4.getName(),
                view,
                f,
                this.centerTextY(Fonts.DEFAULT, colorSetting4.getName(), f1, 11.0F, 10.0F),
                f2 - f5 - 6.0F,
                10.0F,
                this.withOpacity(-922381, f3));
        this.drawRoundedRect(
                view,
                colorPickerButtonXValue,
                value,
                f5,
                f5,
                this.rgbaWithOpacity(255, 255, 255, 10, f3),
                4.0F);
        this.drawClippedToggleIcon(
                view, colorPickerButtonXValue, value, colorSetting4.getColor(), f3);
        if (!(f4 <= 0.01F)) {
            this.openColorPicker = colorSetting4;
            this.colorPickerButtonX = colorPickerButtonXValue;
            this.colorPickerButtonY = value;
            this.colorPickerX = f + f2 + 11.0F;
            if (this.colorPickerX + 79.0F > 535.0F) {
                this.colorPickerX = f - 90.0F;
            }

            this.colorPickerY = MathUtils.clamp(value, 49.0F, 249.0F);
            this.colorPickerOpacity = f3 * f4;
        }
    }

    private void drawConfigButton(
            ClickGuiScreen.View view, String stringValue, float f, float f1, float f2) {
        this.drawBlurredRoundedRect(view, f, f1, f2, 18.0F, 4.0F, view.alpha);
        this.drawRoundedRect(
                view, f, f1, f2, 18.0F, this.rgbaWithOpacity(255, 255, 255, 8, view.alpha), 4.0F);
        this.drawCenteredText(
                Fonts.DEFAULT,
                stringValue,
                view,
                f + f2 * 0.5F,
                this.centerTextY(Fonts.DEFAULT, stringValue, f1, 18.0F, 10.0F) - 0.4F,
                10.0F,
                this.withOpacity(-725001, view.alpha));
    }

    private float getOptionsHeight(List<String> list) {
        float f = 184.5F;
        float f1 = 0.0F;
        int i = 1;

        for (String stringValue : list) {
            float f2 = Fonts.DEFAULT.measureWidth(stringValue, 10.0F) + 10.0F;
            if (f1 + f2 > f && f1 > 0.0F) {
                f1 = 0.0F;
                i++;
            }

            f1 += f2 + 4.0F;
        }

        return 16.0F + (float) i * 16.0F - 3.0F;
    }

    private void drawOptions(
            Setting<?> setting,
            String stringValue,
            List<String> list,
            String text,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3) {
        Font font = Fonts.DEFAULT;
        this.withOpacity(-922381, f3);
        this.drawText(font, stringValue, view, f, f1, 10.0F);
        List listValue = this.getOptionAnimations(setting, list.size());
        float f4 = 0.0F;
        float f5 = f1 + 10.0F + 6.0F;

        for (int i = 0; i < list.size(); i++) {
            String string = (String) list.get(i);
            float f6 = Fonts.DEFAULT.measureWidth(string, 10.0F) + 10.0F;
            if (f4 + f6 > f2 && f4 > 0.0F) {
                f4 = 0.0F;
                f5 += 16.0F;
            }

            boolean forward = string.equalsIgnoreCase(text);
            float f7 =
                    ((EasingAnimation) listValue.get(i))
                            .advanceThenSampleProgress(forward, 0.3F, this.tickDelta);
            this.drawRoundedRect(
                    view,
                    f + f4,
                    f5,
                    f6,
                    13.0F,
                    this.getAccentColor(f3 * (5.0F + 65.0F * f7) / 255.0F),
                    3.0F);
            this.drawRoundedOutline(
                    view,
                    f + f4,
                    f5,
                    f6,
                    13.0F,
                    0.5F,
                    this.rgbaWithOpacity(255, 255, 255, 5, f3),
                    3.0F);
            this.drawCenteredText(
                    Fonts.DEFAULT,
                    string,
                    view,
                    f + f4 + f6 * 0.5F,
                    this.centerTextY(Fonts.DEFAULT, string, f5, 13.0F, 10.0F),
                    10.0F,
                    this.withOpacity(-527622, f3));
            f4 += f6 + 4.0F;
        }
    }

    private void drawClippedSettingIcons(ClickGuiScreen.Panel panel, ClickGuiScreen.View view) {

        List listx = this.getModules(panel.category);
        float[] afloat = new float[] {48.0F - panel.scroll[0], 48.0F - panel.scroll[1]};
        boolean[] aboolean = new boolean[] {false, false};
        ScissorStack.push(
                view.x + 122.0F * view.scale,
                view.y + 44.0F * view.scale,
                412.0F * view.scale,
                266.0F * view.scale,
                2.0F);

        for (int i = 0; i < listx.size(); i++) {
            Module moduleValue = (Module) listx.get(i);
            int j = i & 1;
            float f =
                    this.clampUnit(
                            this.moduleVisibilityAnimations
                                    .computeIfAbsent(
                                            moduleValue,
                                            module ->
                                                    new EasingAnimation()
                                                            .resetValue(
                                                                    this.matchesSearch(moduleValue)
                                                                            ? 1.0F
                                                                            : 0.0F))
                                    .getFloatValue());
            float moduleHeight = this.getModuleHeight(moduleValue);
            if (f > 0.001F) {
                float f2 = afloat[j];
                if (aboolean[j] && f2 >= 41.0F && f2 <= 313.0F) {
                    float f3 = 127.0F + (float) j * 208.5F;
                    this.drawSeparator(view, f3, f2 - 1.5F, 193.5F);
                }

                aboolean[j] = true;
            }

            afloat[j] += (moduleHeight + 3.0F) * f;
        }

        ScissorStack.pop();
    }

    private void drawModuleSearch(ClickGuiScreen.View view) {
        float f =
                this.clampUnit(
                        this.searchExpansionAnimation.approach(
                                searchFocused && !this.closing ? 1.0F : 0.0F, 5.5F));
        if (!this.closing && f <= 0.001F && this.clearSearchWhenClosed) {
            this.moduleSearch = "";
            this.moduleSearchCursor = 0;
            this.moduleSearchSelectedAll = false;
            this.clearSearchWhenClosed = false;
        }

        float f1 = 130.0F;
        float f2 = 9.0F;
        float f3 = 184.0F + 16.0F * f;
        float f4 = 20.0F;
        this.drawBlurredRoundedRect(view, f1, f2, f3, f4, 5.0F, view.alpha);
        this.drawRoundedRect(
                view,
                f1,
                f2,
                f3,
                f4,
                this.rgbaWithOpacity(255, 255, 255, Math.round(6.0F + 6.0F * f), view.alpha),
                5.0F);
        String stringValue = this.moduleSearch.isEmpty() ? "Search modules" : this.moduleSearch;
        if (searchFocused && this.moduleSearchSelectedAll) {
            this.drawRoundedRect(
                    view,
                    f1 + 7.0F,
                    f2 + 5.0F,
                    Math.min(f3 - 32.0F, Fonts.DEFAULT.measureWidth(this.moduleSearch, 10.0F)),
                    10.0F,
                    this.getAccentColor(view.alpha * 0.45F),
                    1.0F);
        }

        Font font = Fonts.DEFAULT;
        float f9 = f1 + 7.0F;
        float f10 = this.centerTextY(Fonts.DEFAULT, stringValue, f2, f4, 10.0F) - 0.3F;
        float f11 = f3 - 32.0F;
        if (this.moduleSearch.isEmpty()) {
            this.drawFadedText(
                    font,
                    stringValue,
                    view,
                    f9,
                    f10,
                    f11,
                    10.0F,
                    this.withOpacity(-7239018, view.alpha));
        } else {
            this.drawFadedText(
                    font,
                    stringValue,
                    view,
                    f9,
                    f10,
                    f11,
                    10.0F,
                    this.withOpacity(-527622, view.alpha));
        }

        float f7 = f1 + f3 - 21.0F;
        float f8 = f2 + 3.0F;
        if (f > 0.01F) {
            this.getAccentColor(view.alpha);
        } else {
            this.withOpacity(-7174249, view.alpha);
        }

        this.drawLogoGlyph(view, f7, f8, 14.0F, 14.0F);
        if (searchFocused && !this.moduleSearchSelectedAll) {
            float target =
                    Math.min(
                            Fonts.DEFAULT.measureWidth(
                                            this.moduleSearch.substring(0, this.moduleSearchCursor),
                                            10.0F)
                                    + 1.0F,
                            f3 - 38.0F);
            if (!this.searchCaretInitialized) {
                this.searchCaretAnimation.resetValue(target);
                this.searchCaretInitialized = true;
            }

            float f6 = f1 + 7.0F + this.searchCaretAnimation.approach(target, 7.0F);
            this.drawRoundedRect(
                    view,
                    f6,
                    f2 + 5.0F,
                    0.7F,
                    10.0F,
                    this.rgbaWithOpacity(247, 242, 250, 255, view.alpha),
                    0.3F);
        }
    }

    private void drawSetting(
            Setting<?> setting, ClickGuiScreen.View view, float f, float f1, float f2, float f3) {
        float blockDropdownOpacityValue = view.alpha * f3;
        if (setting instanceof BooleanSetting booleanSetting) {
            this.drawBooleanSetting(booleanSetting, view, f, f1, f2, blockDropdownOpacityValue);
        } else if (setting instanceof SliderSetting sliderSetting2) {
            this.drawSliderSetting(sliderSetting2, view, f, f1, f2, blockDropdownOpacityValue);
        } else if (setting instanceof ModeSetting modeSetting2) {
            this.drawOptions(
                    modeSetting2,
                    modeSetting2.getName(),
                    modeSetting2.modes,
                    modeSetting2.getSelectedMode(),
                    view,
                    f,
                    f1,
                    f2,
                    blockDropdownOpacityValue);
        } else if (setting instanceof MultiBooleanSetting multiBooleanSetting) {
            this.drawMultiBooleanSetting(
                    multiBooleanSetting, view, f, f1, f2, blockDropdownOpacityValue);
        } else if (setting instanceof ChoiceSetting choiceSetting) {
            this.drawOptions(
                    choiceSetting,
                    choiceSetting.getName(),
                    choiceSetting.choices.stream().map(String::valueOf).toList(),
                    String.valueOf(choiceSetting.getValue()),
                    view,
                    f,
                    f1,
                    f2,
                    blockDropdownOpacityValue);
        } else if (setting instanceof KeybindSetting keybindSetting2) {
            this.drawValueBadge(
                    keybindSetting2.getName(),
                    this.editingKeybind == keybindSetting2
                            ? "..."
                            : this.formatKeyCode(keybindSetting2.getCachedKeyCode()),
                    view,
                    f,
                    f1,
                    f2,
                    blockDropdownOpacityValue);
        } else if (setting instanceof TextSetting textSetting2) {
            String name = textSetting2.getName();
            String text;
            if (this.editingText == textSetting2) {
                String textValue = this.textSelectedAll ? "" : "_";
                String textInputValue = this.textInput;
                text = textInputValue + textValue;
            } else {
                text = textSetting2.getText();
            }

            if (this.editingText == textSetting2 && this.textSelectedAll) {
                this.drawKeybindBadge(name, text, view, f, f1, f2, blockDropdownOpacityValue, true);
            } else {
                this.drawKeybindBadge(
                        name, text, view, f, f1, f2, blockDropdownOpacityValue, false);
            }
        } else if (setting instanceof ColorSetting colorSetting4) {
            this.drawColorSetting(colorSetting4, view, f, f1, f2, blockDropdownOpacityValue);
        } else if (setting instanceof StringListSetting stringListSetting2) {
            this.drawBlockListSetting(
                    stringListSetting2, view, f, f1, f2, blockDropdownOpacityValue);
        } else if (setting instanceof ButtonSetting buttonSetting) {
            this.drawButtonSetting(buttonSetting, view, f, f1, f2, blockDropdownOpacityValue);
        } else if (setting instanceof MatrixSetting matrixSetting) {
            this.drawMatrixSetting(matrixSetting, view, f, f1, f2, blockDropdownOpacityValue);
        }
    }

    private void drawHighlightedText(
            Font font,
            String string,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float size,
            float f3,
            float f4) {
        float f5 = font.measureWidth(string, size);
        float f6 = 0.0F;
        int i = 0;

        while (i < string.length()) {
            int codePoint = string.codePointAt(i);
            String stringValue = new String(Character.toChars(codePoint));
            float f7 = font.measureWidth(stringValue, size);
            float f8 = f5 <= 0.0F ? 0.0F : (f6 + f7 * 0.5F) / f5;
            float f9 = f + f6;
            this.getHighlightedTextColor(f8, f3, f4);
            this.drawText(font, stringValue, view, f9, f1, size);
            f6 += f7;
            i += Character.charCount(codePoint);
        }
    }

    private boolean isDisplayableSetting(Setting<?> setting) {
        return !(setting instanceof PositionSetting);
    }

    private float getTextHighlightPosition() {
        float f = (float) (System.currentTimeMillis() % 1500L) / 1500.0F;
        return 2.1F - f * 3.2F;
    }

    private void drawTooltip(String tooltipTextValue, float f, float f1, float f2) {
        if (!tooltipTextValue.isBlank()) {
            this.tooltipText = tooltipTextValue;
        }

        this.animateTo(
                this.tooltipAnimation,
                tooltipTextValue.isBlank() ? 0.0F : 1.0F,
                0.22F,
                Easings.OUT_QUAD);
        this.tooltipAnimation.update();
        float f3 = this.clampUnit(this.tooltipAnimation.getFloatValue());
        if (!(f3 <= 0.01F) && !this.tooltipText.isBlank()) {
            float size = 10.0F * guiScale;
            float f5 = f * 0.5F - Fonts.DEFAULT.measureWidth(this.tooltipText, size) * 0.5F;
            float f6 = f1 - size - 8.0F * guiScale + (1.0F - f3) * 4.0F * guiScale;
            Font font = Fonts.DEFAULT;
            String stringValue = this.tooltipText;
            float f7 = f5 + 0.5F;
            float f8 = f6 + 0.5F;
            this.rgbaWithOpacity(0, 0, 0, 170, f2 * f3);
            font.drawText(stringValue, f7, f8, size);
            font = Fonts.DEFAULT;
            stringValue = this.tooltipText;
            this.rgbaWithOpacity(255, 255, 255, 255, f2 * f3);
            font.drawText(stringValue, f5, f6, size);
        }
    }

    @Override
    public boolean mouseScrolled(double d0, double d1, double d2, double d3) {
        float mouseX = (float) (d0 / (double) this.screenScale);
        float mouseY = (float) (d1 / (double) this.screenScale);
        OverlayEditor overlayEditor = EditorManager.getActiveEditor();
        if (overlayEditor != null) {
            return overlayEditor.mouseScrolled(mouseX, mouseY, d3);
        } else {
            ClickGuiScreen.Panel panel = this.getActivePanel();
            float f2 = this.clampUnit(this.configSidebarAnimation.getFloatValue());
            float f3 = 541.5F + (1.0F - f2) * 5.0F;
            if (f2 > 0.01F && this.contains(panel, mouseX, mouseY, f3, 0.0F, 114.0F, 320.0F)) {
                float f5 = 66.0F;
                float f6 = 314.0F - f5;
                if (this.contains(panel, mouseX, mouseY, f3 + 6.0F, f5, 102.0F, f6)) {
                    this.configScrollTarget =
                            MathUtils.clamp(
                                    this.configScrollTarget - (float) d3 * 24.0F,
                                    0.0F,
                                    this.configMaxScroll);
                    GuiSounds.playLowSlider();
                }

                return true;
            } else {
                ClickGuiScreen.Panel panelValue = this.panelAt(mouseX, mouseY);
                if (panelValue != null
                        && this.stringListSetting != null
                        && this.blockDropdownOpen
                        && this.contains(
                                panelValue,
                                mouseX,
                                mouseY,
                                this.blockDropdownX,
                                this.blockDropdownY + 18.0F,
                                184.0F,
                                this.blockDropdownHeight - 18.0F)) {
                    int count = this.stringListSetting.searchBlocks(this.blockSearch).size();
                    if (d3 > 0.0) {
                        this.blockSearchScroll--;
                    } else if (d3 < 0.0) {
                        this.blockSearchScroll++;
                    }

                    this.blockSearchScroll =
                            Math.max(0, Math.min(this.blockSearchScroll, Math.max(0, count - 10)));
                    GuiSounds.playLowSlider();
                    return true;
                } else {
                    if (panelValue != null) {
                        float f4 = (mouseX - panelValue.x) / guiScale;
                        if (f4 >= 122.0F) {
                            byte b0;
                            if (f4 < 328.0F) {
                                b0 = 0;
                            } else {
                                b0 = 1;
                            }

                            panelValue.scrollTarget[b0] =
                                    MathUtils.clamp(
                                            panelValue.scrollTarget[b0] - (float) d3 * 22.0F,
                                            0.0F,
                                            panelValue.maxScroll[b0]);
                            GuiSounds.playLowSlider();
                        }
                    }

                    return true;
                }
            }
        }
    }

    private void drawMatrixSetting(
            MatrixSetting matrixSetting,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3) {
        Font font = Fonts.DEFAULT;
        String name = matrixSetting.getName();
        this.withOpacity(-922381, f3);
        this.drawText(font, name, view, f, f1, 10.0F);
        float f4 = Math.min(55.0F, f2);
        float f5 = f4 / (float) matrixSetting.size;
        float f6 = f + (f2 - f4) * 0.5F;

        for (int i = 0; i < matrixSetting.size; i++) {
            for (int j = 0; j < matrixSetting.size; j++) {
                this.drawRoundedRect(
                        view,
                        f6 + (float) j * f5,
                        f1 + 10.0F + (float) i * f5,
                        Math.max(0.5F, f5 - 0.35F),
                        Math.max(0.5F, f5 - 0.35F),
                        matrixSetting.isEnabled(j, i)
                                ? this.rgbaWithOpacity(255, 255, 255, 255, f3)
                                : this.rgbaWithOpacity(255, 255, 255, 10, f3),
                        0.5F);
            }
        }
    }

    private void drawBlurredRect(
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            float factor,
            int color) {
        Gooba.getInstance()
                .getHudManager()
                .getBlurBatchRenderer()
                .drawTintedRect(
                        view.x + f * view.scale,
                        view.y + f1 * view.scale,
                        f2 * view.scale,
                        f3 * view.scale,
                        factor,
                        new float[] {
                            f4 * view.scale, f5 * view.scale, f6 * view.scale, f7 * view.scale
                        },
                        color,
                        0.8F);
    }

    private boolean isSettingVisible(Setting<?> setting) {
        try {
            return setting.getVisibility().get();
        } catch (Exception exception) {
            return false;
        }
    }

    private void drawKeybindBadge(
            String stringValueValue,
            String stringValue,
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3,
            boolean flag) {
        float f4 = Math.min(f2 * 0.6F, Fonts.DEFAULT.measureWidth(stringValue, 10.0F) + 7.0F);
        this.drawFadedText(
                Fonts.DEFAULT,
                stringValueValue,
                view,
                f,
                this.centerTextY(Fonts.DEFAULT, stringValueValue, f1, 13.0F, 10.0F),
                f2 - f4 - 4.0F,
                10.0F,
                this.withOpacity(-922381, f3));
        this.drawRoundedRect(
                view, f + f2 - f4, f1, f4, 13.0F, this.getAccentColor(f3 * 13.0F / 255.0F), 3.0F);
        this.drawRoundedOutline(
                view,
                f + f2 - f4,
                f1,
                f4,
                13.0F,
                0.5F,
                this.rgbaWithOpacity(255, 255, 255, 18, f3),
                3.0F);
        if (flag) {
            this.drawRoundedRect(
                    view,
                    f + f2 - f4 + 3.5F,
                    f1 + 2.0F,
                    Math.max(0.0F, f4 - 7.0F),
                    9.0F,
                    this.getAccentColor(f3 * 0.45F),
                    1.0F);
        }

        this.drawFadedText(
                Fonts.DEFAULT,
                stringValue,
                view,
                f + f2 - f4 + 3.5F,
                this.centerTextY(Fonts.DEFAULT, stringValue, f1, 13.0F, 10.0F),
                f4 - 7.0F,
                10.0F,
                this.withOpacity(-922381, f3));
    }

    @Override
    public void render(DrawContext drawcontext, int i, int j, float f) {
        this.tooltipAnimation.update();
        this.mouseX = (float) i / this.screenScale;
        this.mouseY = (float) j / this.screenScale;
    }

    private String formatKeyCode(int i) {
        return i == -1 ? "N/A" : KeyCode.displayName(i).replace("NONE", "N/A");
    }

    private int getAccentColor(float f) {
        return HUDModule.getInstance().getAccentColor(this.clampUnit(f));
    }

    private ClickGuiScreen.Panel getActivePanel() {
        return this.findPanel(this.selectedCategory);
    }

    private void drawRoundedOutline(
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            int color,
            float f5) {
        RenderUtils.Render2D.drawRoundedOutline(
                view.x + f * view.scale,
                view.y + f1 * view.scale,
                f2 * view.scale,
                f3 * view.scale,
                f4 * view.scale,
                color,
                f5 * view.scale);
    }

    private int getBackgroundColor() {
        return HUDModule.getInstance().getTintedBackgroundColor();
    }

    private boolean handleSettingClick(
            ClickGuiScreen.Panel panel,
            Setting setting,
            float mouseX,
            float mouseY,
            float activeSettingXValue,
            float f3,
            float activeSettingWidthValue,
            float f5,
            int i) {

        if (!this.contains(
                panel, mouseX, mouseY, activeSettingXValue, f3, activeSettingWidthValue, f5)) {
            return false;
        } else {
            this.activeSettingX = activeSettingXValue;
            this.activeSettingWidth = activeSettingWidthValue;
            if (setting instanceof BooleanSetting booleanSetting && i == 0) {
                if (!booleanSetting.isOn()) {
                    booleanSetting.setValue(true);
                } else {
                    booleanSetting.setValue(false);
                }

                ClickGUIModule clickGUIModule =
                        Gooba.getInstance().getModuleRegistry().findModule(ClickGUIModule.class);
                if (clickGUIModule != null && booleanSetting == clickGUIModule.soundsSetting) {
                    if (booleanSetting.isOn()) {
                        MenuBackgroundRenderer.playMusic(0.15F);
                    } else {
                        MenuBackgroundRenderer.stopMusic();
                    }
                }

                GuiSounds.playOptionToggle(booleanSetting.isOn());
                return true;
            }

            if (setting instanceof SliderSetting sliderSetting2 && i == 0) {
                this.draggedSlider = sliderSetting2;
                this.updateSliderValue(sliderSetting2, mouseX);
                GuiSounds.playSlider();
                return true;
            }

            if (setting instanceof ModeSetting modeSetting2 && i == 0) {
                String stringValue =
                        this.optionAt(
                                panel,
                                modeSetting2.modes,
                                mouseX,
                                mouseY,
                                activeSettingXValue,
                                f3,
                                activeSettingWidthValue);
                if (stringValue != null) {
                    modeSetting2.setValue(stringValue);
                    GuiSounds.playOptionSelection(
                            modeSetting2.modes.indexOf(stringValue), modeSetting2.modes.size());
                }

                return true;
            }

            if (setting instanceof MultiBooleanSetting multiBooleanSetting && i == 0) {
                String text =
                        this.optionAt(
                                panel,
                                multiBooleanSetting.getOptions().stream()
                                        .map(Setting::getName)
                                        .toList(),
                                mouseX,
                                mouseY,
                                activeSettingXValue,
                                f3,
                                activeSettingWidthValue);
                if (text != null) {
                    BooleanSetting booleanSetting2 = multiBooleanSetting.findOption(text);
                    if (!booleanSetting2.isOn()) {
                        booleanSetting2.setValue(true);
                        GuiSounds.playBooleanToggle(booleanSetting2.isOn());
                    } else {
                        booleanSetting2.setValue(false);
                        GuiSounds.playBooleanToggle(booleanSetting2.isOn());
                    }
                }

                return true;
            }

            if (setting instanceof ChoiceSetting choiceSetting && i == 0) {
                List listx = choiceSetting.choices.stream().map(String::valueOf).toList();
                String textValue =
                        this.optionAt(
                                panel,
                                listx,
                                mouseX,
                                mouseY,
                                activeSettingXValue,
                                f3,
                                activeSettingWidthValue);
                if (textValue != null) {
                    choiceSetting.setValue2(choiceSetting.choices.get(listx.indexOf(textValue)));
                }

                return true;
            }

            if (setting instanceof KeybindSetting keybindSetting2 && i == 0) {
                this.editingKeybind = keybindSetting2;
                GuiSounds.playConfirmation();
                return true;
            }

            if (setting instanceof TextSetting textSetting2 && i == 0) {
                if (this.editingText != null && this.editingText != textSetting2) {
                    this.editingText.setValue(this.textInput);
                }

                if (this.editingText != textSetting2) {
                    this.textInput = textSetting2.getText();
                }

                this.editingText = textSetting2;
                this.textSelectedAll = false;
                searchFocused = false;
                this.editingConfigName = false;
                this.blockDropdownOpen = false;
                this.blockSearchFocused = false;
                GuiSounds.playSelection();
                return true;
            }

            if (setting instanceof ColorSetting colorSetting4 && i == 0) {
                if (this.contains(
                        panel,
                        mouseX,
                        mouseY,
                        activeSettingXValue + activeSettingWidthValue - 14.0F,
                        f3 - 1.5F,
                        14.0F,
                        14.0F)) {
                    this.blockDropdownOpen = false;
                    if (!colorSetting4.expanded) {
                        colorSetting4.expanded = true;
                        GuiSounds.playExpand(colorSetting4.expanded);
                        return true;
                    }

                    colorSetting4.expanded = false;
                    GuiSounds.playExpand(colorSetting4.expanded);
                    return true;
                }

                return true;
            }

            if (setting instanceof StringListSetting stringListSetting2 && i == 0) {
                if (this.contains(
                        panel,
                        mouseX,
                        mouseY,
                        activeSettingXValue + activeSettingWidthValue - 14.0F,
                        f3 - 1.5F,
                        14.0F,
                        14.0F)) {
                    boolean blockDropdownOpenValue;
                    blockDropdownOpenValue =
                            !(this.stringListSetting == stringListSetting2
                                    && this.blockDropdownOpen);

                    if (this.stringListSetting != stringListSetting2) {
                        this.blockColorSetting = null;
                    }

                    this.stringListSetting = stringListSetting2;
                    this.blockDropdownOpen = blockDropdownOpenValue;
                    this.blockSearchFocused = blockDropdownOpenValue;
                    if (blockDropdownOpenValue) {
                        this.blockSearch = "";
                        this.blockSearchCursor = 0;
                        this.blockSearchSelectedAll = false;
                        this.blockSearchScroll = 0;
                        this.blockSearchScrollOffset = 0.0F;
                        this.blockScrollAnimation.resetValue(0.0F);

                        for (Module moduleValue :
                                Gooba.getInstance().getModuleRegistry().values()) {
                            for (Setting settingValue : moduleValue.getSettings()) {
                                if (settingValue instanceof ColorSetting colorSetting5) {
                                    colorSetting5.expanded = false;
                                }
                            }
                        }
                    }

                    GuiSounds.playExpand(blockDropdownOpenValue);
                }

                return true;
            }

            if (setting instanceof MatrixSetting matrixSetting && i == 0) {
                float f6 = Math.min(55.0F, activeSettingWidthValue);
                float f7 = activeSettingXValue + (activeSettingWidthValue - f6) * 0.5F;
                float f8 = mouseX / guiScale - panel.x / guiScale;
                float f9 = mouseY / guiScale - panel.y / guiScale;
                int j = (int) ((f8 - f7) / (f6 / (float) matrixSetting.size));
                int k = (int) ((f9 - f3 - 10.0F) / (f6 / (float) matrixSetting.size));
                if (matrixSetting.isInside(j, k)) {
                    if (!matrixSetting.isEnabled(j, k)) {
                        matrixSetting.setCell(j, k, true);
                    } else {
                        matrixSetting.setCell(j, k, false);
                    }
                }

                return true;
            }

            return true;
        }
    }

    private void importConfig(String text) {
        String textValue = this.sanitizeConfigName(this.configName);
        if (textValue.isBlank()) {
            textValue = "Imported";
        }

        String textValueValue = textValue;
        int i = 2;

        while (this.configNameExists(textValueValue)) {
            int j = i++;
            textValueValue = textValue + " " + j;
        }

        this.savedConfigs.add(new ClickGuiScreen.SavedConfig(textValueValue, text));
        Gooba.getInstance().getConfigManager().savePreset(textValueValue, text);
        this.configScrollTarget = 0.0F;
        this.configScroll = 0.0F;
    }

    private void drawBlurredRoundedRect(
            ClickGuiScreen.View view,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float factor) {
        this.drawPanelBackground(view, f, f1, f2, f3, f4, f4, f4, f4, factor);
    }

    private void drawCircle(ClickGuiScreen.View view, float f, float f1, float f2, int color) {
        Gooba.getInstance()
                .getHudManager()
                .getCircleData()
                .drawCircle(
                        view.x + f * view.scale, view.y + f1 * view.scale, f2 * view.scale, color);
    }

    public boolean isClosing() {
        return this.closing;
    }

    private int withOpacity(int color, float f) {
        return ColorUtils.withOpacity(color, this.clampUnit(f));
    }

    private void drawSeparator(ClickGuiScreen.View view, float f, float f1, float f2) {
        float f3 = 4.0F;
        float f4 = f2 - f3 * 2.0F;
        float innerX = (float) Math.round((view.x + (f + f3) * view.scale) * 2.0F) * 0.5F;
        float f6 = (float) Math.round((view.y + f1 * view.scale) * 2.0F) * 0.5F;
        float widthValue = (float) Math.round(f4 * view.scale * 2.0F) * 0.5F;
        float heightValue = Math.max(1.0F, (float) Math.round(1.5F * view.scale * 2.0F) * 0.5F);
        RenderUtils.Render2D.drawRoundedRect(
                innerX,
                f6 - heightValue * 0.5F,
                widthValue,
                heightValue,
                this.rgbaWithOpacity(255, 255, 255, 160, view.alpha),
                0.0F);
    }

    private float updateSettingVisibility(Setting<?> setting) {
        EasingAnimation easingAnimation2 =
                this.settingVisibilityAnimations.computeIfAbsent(
                        setting, settingValue -> new EasingAnimation().resetProgress(0.0F));
        return this.clampUnit(
                easingAnimation2.advanceThenSampleProgress(
                        this.isSettingVisible(setting), 0.4F, this.tickDelta));
    }

    private boolean matchesSearch(Module moduleValue) {
        String text = this.moduleSearch.trim().toLowerCase(Locale.ROOT);
        return text.isEmpty()
                ? moduleValue.getCategory() == this.selectedCategory
                : moduleValue.getBigName().toLowerCase(Locale.ROOT).contains(text)
                        || this.nullToEmpty(moduleValue.getDescription())
                                .toLowerCase(Locale.ROOT)
                                .contains(text);
    }

    @Environment(EnvType.CLIENT)
    private static final class Panel {
        private final ModuleCategory category;
        private final float[] maxScroll;
        private float x;
        private final float[] scroll = new float[2];
        private final float[] scrollTarget = new float[2];
        private float y;

        private Panel(ModuleCategory moduleCategory2) {
            this.maxScroll = new float[2];
            this.category = moduleCategory2;
        }
    }

    @Environment(EnvType.CLIENT)
    private static final class SavedConfig {
        private final String name;
        private boolean deleting;
        private final EasingAnimation visibilityAnimation = new EasingAnimation().resetValue(1.0F);
        private final String encodedConfig;

        private float getOpacity() {
            return this.visibilityAnimation.getFloatValue();
        }

        private void markDeleted() {
            this.deleting = true;
        }

        private float updateOpacity() {
            return this.visibilityAnimation.approach(this.deleting ? 0.0F : 1.0F, 5.5F);
        }

        private String getName() {
            return this.name;
        }

        private boolean isDeleted() {
            return this.deleting;
        }

        private String getEncodedConfig() {
            return this.encodedConfig;
        }

        private SavedConfig(String stringValue, String text) {
            this.name = stringValue;
            this.encodedConfig = text;
        }
    }

    @Environment(EnvType.CLIENT)
    private static record View(float x, float y, float scale, float alpha) {}
}
