package dev.gooba.client;

import com.sun.jna.Callback;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface DiscordReadyCallback extends Callback {
    void apply(DiscordUser discordUser);
}
