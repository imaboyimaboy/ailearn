package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public final class TargetPositionUtils implements MinecraftAccess {
    public static Vec3d relativeFeetOffset(LivingEntity livingentity) {
        MathHelper.clamp(
                livingentity.getY() - livingentity.getY(), 0.0, (double) livingentity.getHeight());
        double d0 = MathHelper.clamp(client.player.getX() - livingentity.getX(), 0.0, 0.0);
        double d1 = MathHelper.clamp(client.player.getZ() - livingentity.getZ(), 0.0, 0.0);
        return new Vec3d(
                livingentity.getX() - client.player.getX() + d0,
                livingentity.getY() - client.player.getY() - 0.8F,
                livingentity.getZ() - client.player.getZ() + d1);
    }

    public static Vec3d clampToBox(Vec3d vec3d, Box box) {
        return new Vec3d(
                MathUtils.clamp(vec3d.x, box.minX, box.maxX),
                MathUtils.clamp(vec3d.y, box.minY, box.maxY),
                MathUtils.clamp(vec3d.z, box.minZ, box.maxZ));
    }

    public static double distanceToHitbox(Entity entity) {
        return eyeToHitboxOffset(entity).length();
    }

    public static Vec3d eyeToHitboxOffset(Entity entity) {

        Vec3d vec3d = client.player.getEyePos();

        return closestPointOnHitbox(vec3d, entity).subtract(vec3d);
    }

    public static Vec3d closestPointOnHitbox(Vec3d vec3d, Entity entity) {
        return clampToBox(vec3d, entity.getBoundingBox());
    }

    public static Vec3d relativeEyeOffset(LivingEntity livingentity) {
        double d0 =
                MathHelper.clamp(
                        livingentity.getEyeY() - livingentity.getY(),
                        0.0,
                        (double) livingentity.getHeight());
        double d1 = MathHelper.clamp(client.player.getX() - livingentity.getX(), 0.0, 0.0);
        double d2 = MathHelper.clamp(client.player.getZ() - livingentity.getZ(), 0.0, 0.0);
        return new Vec3d(
                livingentity.getX() - client.player.getX() + d1,
                livingentity.getY() - client.player.getEyeY() + d0,
                livingentity.getZ() - client.player.getZ() + d2);
    }

    private TargetPositionUtils() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static boolean isWithinRange(Entity entity, float f, boolean flag) {
        return distanceToHitbox(entity) < (double) f;
    }

    private static boolean isBlockInsideBox(Box box, BlockPos blockPos) {
        if (!client.world.getBlockState(blockPos).isOf(Blocks.COBWEB)) {
            return false;
        } else {
            Box boxValue = new Box(blockPos);
            return box.intersects(boxValue);
        }
    }

    private static boolean isTargetPosition(Box box, BlockPos blockPos) {
        return isBlockInsideBox(box, blockPos);
    }
}
