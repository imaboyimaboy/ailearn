package dev.gooba.client;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.PropertyMap;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket.Mode;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

@ModuleInfo(
        name = "FakeLag",
        desc = "Buffers outgoing packets and releases them at a fixed interval",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class FakeLagModule extends Module {
    private static FakeLagModule instance;
    private long flushAtMillis;
    private final SliderSetting delaySetting =
            new SliderSetting(this, "Delay", 1000.0F, 50.0F, 5000.0F, 50.0F);
    private OtherClientPlayerEntity ghost;
    private final ModeSetting renderingSetting =
            new ModeSetting(this, "Rendering", new String[] {"Model", "Box"});
    private Box serverBoundingBox;
    private final List<Packet<?>> queuedPackets = new CopyOnWriteArrayList<>();
    private boolean flushing;

    @EventHandler
    public void onPacket(PacketEvent packetEvent) {
        if (!this.flushing) {
            Packet packet = packetEvent.getPacket();
            if (packet instanceof PlayerRespawnS2CPacket || packet instanceof GameJoinS2CPacket) {
                this.queuedPackets.clear();
                this.flushAtMillis = 0L;
                this.serverBoundingBox = null;
                this.removeGhost();
            } else if (packetEvent.isSend()) {
                if (packet instanceof ClientStatusC2SPacket clientstatusc2spacket
                        && clientstatusc2spacket.getMode() == Mode.PERFORM_RESPAWN) {
                    return;
                }

                if (client.player != null
                        && client.world != null
                        && client.getNetworkHandler() != null) {
                    this.queuedPackets.add(packet);
                    packetEvent.cancel();
                }
            }
        }
    }

    public FakeLagModule() {
        instance = this;
    }

    public static boolean isGhost(Entity entity) {
        return instance != null && instance.ghost == entity;
    }

    private void updateGhost() {
        if (this.ghost != null && client.player != null) {
            double d0 = (this.serverBoundingBox.minX + this.serverBoundingBox.maxX) * 0.5;
            double d1 = (this.serverBoundingBox.minZ + this.serverBoundingBox.maxZ) * 0.5;
            this.ghost.refreshPositionAndAngles(
                    d0,
                    this.serverBoundingBox.minY,
                    d1,
                    client.player.getYaw(),
                    client.player.getPitch());
            this.ghost.setHeadYaw(client.player.getHeadYaw());
            this.ghost.setBodyYaw(client.player.getBodyYaw());
            this.ghost.setMainArm(client.player.getMainArm());
            this.ghost.setSneaking(client.player.isSneaking());
            this.ghost.setStackInHand(Hand.MAIN_HAND, client.player.getMainHandStack().copy());
            this.ghost.setStackInHand(Hand.OFF_HAND, client.player.getOffHandStack().copy());
            this.ghost.equipStack(
                    EquipmentSlot.HEAD, client.player.getEquippedStack(EquipmentSlot.HEAD).copy());
            this.ghost.equipStack(
                    EquipmentSlot.CHEST,
                    client.player.getEquippedStack(EquipmentSlot.CHEST).copy());
            this.ghost.equipStack(
                    EquipmentSlot.LEGS, client.player.getEquippedStack(EquipmentSlot.LEGS).copy());
            this.ghost.equipStack(
                    EquipmentSlot.FEET, client.player.getEquippedStack(EquipmentSlot.FEET).copy());
        }
    }

    private void flushPackets() {
        if (client.getNetworkHandler() == null) {
            this.queuedPackets.clear();
        } else {
            this.flushing = true;

            try {
                for (Packet<?> packet : (Iterable<Packet<?>>) (Iterable) this.queuedPackets) {
                    client.getNetworkHandler().sendPacket(packet);
                }
            } finally {
                this.queuedPackets.clear();
                this.flushing = false;
            }

            this.capturePosition();
        }
    }

    @Override
    protected void onDisable() {
        this.flushPackets();
        this.flushAtMillis = 0L;
        this.serverBoundingBox = null;
        this.removeGhost();
        super.onDisable();
    }

    private void spawnGhost() {
        if (client.player != null
                && client.world != null
                && this.serverBoundingBox != null
                && !client.options.getPerspective().isFirstPerson()) {
            this.removeGhost();
            GameProfile gameprofile = client.player.getGameProfile();
            GameProfile gameProfile =
                    new GameProfile(
                            UUID.randomUUID(),
                            gameprofile.name(),
                            new PropertyMap(gameprofile.properties()));
            this.ghost =
                    new OtherClientPlayerEntity(client.world, gameProfile) {
                        @Override
                        public boolean canHit() {
                            return false;
                        }

                        @Override
                        public boolean isCollidable(Entity entity) {
                            return false;
                        }

                        @Override
                        public void pushAwayFrom(Entity entity) {}

                        @Override
                        public boolean isPushable() {
                            return false;
                        }

                        @Override
                        public boolean collidesWith(Entity entity) {
                            return false;
                        }
                    };
            this.ghost.setNoGravity(true);
            this.updateGhost();
            client.world.addEntity(this.ghost);
        }
    }

    private void scheduleFlush() {
        this.flushAtMillis =
                System.currentTimeMillis()
                        + Math.max(50L, (long) Math.round(this.delaySetting.getFloat()));
    }

    private void ensureGhost() {
        if (this.ghost == null || this.ghost.isRemoved()) {
            this.spawnGhost();
        }
    }

    private void capturePosition() {
        if (client.player != null && client.world != null) {
            this.serverBoundingBox = client.player.getBoundingBox();
            if (this.renderingSetting.isSelected("Model")) {
                this.updateGhost();
            }
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null && this.serverBoundingBox != null) {
            if (client.options.getPerspective().isFirstPerson()) {
                this.removeGhost();
            } else if (this.renderingSetting.isSelected("Model")) {
                this.ensureGhost();
            } else {
                this.removeGhost();
                int i = ColorUtils.withAlpha(HUDModule.getInstance().getAccentColor(1.0F), 72);
                WorldEspRenderer.clear();
                WorldEspRenderer.enqueueBox(this.serverBoundingBox, i, false);
                WorldEspRenderer.flush(render3DEvent.getMatrixStack());
            }
        }
    }

    @Override
    protected void onEnable() {
        this.queuedPackets.clear();
        this.serverBoundingBox = client.player == null ? null : client.player.getBoundingBox();
        this.flushAtMillis = 0L;
        this.flushing = false;
        this.scheduleFlush();
        if (this.renderingSetting.isSelected("Model")) {
            this.spawnGhost();
        }

        super.onEnable();
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null && client.getNetworkHandler() != null) {
            if (client.options.getPerspective().isFirstPerson()) {
                this.removeGhost();
            }

            if (this.flushAtMillis == 0L) {
                this.scheduleFlush();
            }

            if (System.currentTimeMillis() >= this.flushAtMillis) {
                this.flushPackets();
                this.scheduleFlush();
            }
        } else {
            this.queuedPackets.clear();
            this.removeGhost();
            this.flushAtMillis = 0L;
        }
    }

    private void removeGhost() {
        if (this.ghost != null) {
            this.ghost.discard();
        }

        this.ghost = null;
    }
}
