package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class EventBus implements EventBusAccess {
    private final Map<Class<?>, List<EventListener>> listenerMap;
    private final List<EventBus.LambdaFactoryInfo> lambdaFactoryInfos =
            new CopyOnWriteArrayList<>();
    private final Supplier<List<EventListener>> listenerListFactory;
    private final Map<Class<?>, List<EventListener>> staticListenerCache;
    private final Map<Object, List<EventListener>> listenerCache;

    @Override
    public <T extends Cancellable> T post(T cancellable) {
        List list = this.listenerMap.get(cancellable.getClass());
        if (list != null) {
            cancellable.setCancelled(false);

            for (EventListener eventListener : (Iterable<EventListener>) (Iterable) list) {
                try {
                    eventListener.call(cancellable);
                } catch (Exception exception) {
                }

                if (cancellable.isCancelled()) {
                    break;
                }
            }
        }

        return (T) cancellable;
    }

    @Override
    public void registerLambdaFactory(String text, LambdaListener.Factory factory) {
        this.lambdaFactoryInfos.add(new EventBus.LambdaFactoryInfo(text, factory));
    }

    @Override
    public void subscribe(Class<?> oclass) {
        List list = this.getStaticListeners(oclass);
        this.subscribe(list, true);
    }

    private void subscribe(EventListener eventListener, boolean flag) {
        List list =
                this.listenerMap.computeIfAbsent(
                        eventListener.getTarget(), oclass -> this.listenerListFactory.get());
        if (!flag || !ListenerPriorityList.contains(list, eventListener)) {
            ListenerPriorityList.insert(list, eventListener);
        }
    }

    public static EventBus threadUnsafe() {
        return new EventBus(
                new IdentityHashMap<>(),
                new IdentityHashMap<>(),
                new IdentityHashMap<>(),
                CopyOnWriteArrayList::new);
    }

    public boolean isSubscribed(EventListener eventListener) {
        List list = this.listenerMap.get(eventListener.getTarget());
        return list != null && ListenerPriorityList.contains(list, eventListener);
    }

    @Override
    public void unsubscribe(Object object) {
        List list = this.listenerCache.get(object);
        if (list != null) {
            this.unsubscribe(list);
            this.listenerCache.remove(object);
        }
    }

    @Override
    public void unsubscribe(Class<?> oclass) {
        List list = this.staticListenerCache.get(oclass);
        if (list != null) {
            this.unsubscribe(list);
        }
    }

    public boolean areAllSubscribed(Class<?> oclass) {
        List list = this.staticListenerCache.get(oclass);
        if (list == null) {
            return false;
        } else {
            for (EventListener eventListener : (Iterable<EventListener>) (Iterable) list) {
                if (!this.isSubscribed(eventListener)) {
                    return false;
                }
            }

            return true;
        }
    }

    @Override
    public <T> T post(T object) {
        List list = this.listenerMap.get(object.getClass());
        if (list != null) {
            for (EventListener eventListener : (Iterable<EventListener>) (Iterable) list) {
                try {
                    eventListener.call(object);
                } catch (Exception exception) {
                }
            }
        }

        return (T) object;
    }

    private List<EventListener> getListeners(Class<?> oclass, Object object, boolean flag) {
        ArrayList arraylist = new ArrayList();
        this.getListeners(arraylist, oclass, object, flag);
        return new ImmutableListView<>(arraylist);
    }

    private List<EventListener> getInstanceListeners(Object object) {
        return this.listenerCache.computeIfAbsent(
                object, objectx -> this.getListeners(objectx.getClass(), objectx, false));
    }

    @Override
    public void unsubscribe(EventListener eventListener) {
        List list = this.listenerMap.get(eventListener.getTarget());
        if (list != null) {
            ListenerPriorityList.remove(list, eventListener);
        }
    }

    public EventBus(
            Map<Object, List<EventListener>> map,
            Map<Class<?>, List<EventListener>> staticListenerCacheValue,
            Map<Class<?>, List<EventListener>> listenerMapValue,
            Supplier<List<EventListener>> supplier) {
        this.listenerCache = map;
        this.staticListenerCache = staticListenerCacheValue;
        this.listenerMap = listenerMapValue;
        this.listenerListFactory = supplier;
    }

    private void getListeners(
            List<EventListener> list, Class<?> oclass, Object object, boolean flag) {
        while (oclass != null) {
            LambdaListener.Factory factory = null;

            for (Method method : oclass.getDeclaredMethods()) {
                if (this.isValid(method, flag)) {
                    if (LambdaListener.requireLambdaFactoryRegistration() && factory == null) {
                        factory = this.getLambdaFactory(oclass);
                    }

                    list.add(new LambdaListener(factory, oclass, object, method));
                }
            }

            oclass = oclass.getSuperclass();
        }
    }

    public boolean isSubscribed(Class<?> oclass) {
        for (EventListener eventListener : this.staticListenerCache.get(oclass)) {
            if (eventListener instanceof LambdaListener lambdaListener) {
                if (lambdaListener.owner != oclass) {
                    break;
                }

                if (!this.isSubscribed(eventListener)) {
                    return true;
                }
            }
        }

        return true;
    }

    @Override
    public boolean isListening(Class<?> oclass) {
        List list = this.listenerMap.get(oclass);
        return list != null && !list.isEmpty();
    }

    private void unsubscribe(List<EventListener> list) {
        for (EventListener eventListener : list) {
            this.unsubscribe(eventListener);
        }
    }

    private List<EventListener> getStaticListeners(Class<?> oclass) {
        return this.staticListenerCache.computeIfAbsent(
                oclass, type -> this.getListeners((Class<?>) type, null, true));
    }

    @Override
    public void subscribe(Object object) {
        if (!this.listenerCache.containsKey(object)) {
            this.subscribe(this.getInstanceListeners(object), false);
        }
    }

    public static EventBus threadSafe() {
        return new EventBus(
                Collections.synchronizedMap(new IdentityHashMap<>()),
                new ConcurrentHashMap<>(),
                new ConcurrentHashMap<>(),
                CopyOnWriteArrayList::new);
    }

    public boolean isSubscribed(Object object) {
        return this.listenerCache.containsKey(object);
    }

    public boolean areAnySubscribed(Class<?> oclass) {
        List list = this.staticListenerCache.get(oclass);
        if (list == null) {
            return false;
        } else {
            for (EventListener eventListener : (Iterable<EventListener>) (Iterable) list) {
                if (this.isSubscribed(eventListener)) {
                    return true;
                }
            }

            return false;
        }
    }

    private void subscribe(List<EventListener> list, boolean flag) {
        for (EventListener eventListener : list) {
            this.subscribe(eventListener, flag);
        }
    }

    @Override
    public void subscribe(EventListener eventListener) {
        this.subscribe(eventListener, true);
    }

    private LambdaListener.Factory getLambdaFactory(Class<?> oclass) {
        for (EventBus.LambdaFactoryInfo lambdaFactoryInfo : this.lambdaFactoryInfos) {
            if (oclass.getName().startsWith(lambdaFactoryInfo.packagePrefix)) {
                return lambdaFactoryInfo.factory;
            }
        }

        throw new ListenerInvocationException(oclass);
    }

    private boolean isValid(Method method, boolean flag) {
        if (flag && !Modifier.isStatic(method.getModifiers())) {
            return false;
        } else if (!method.isAnnotationPresent(EventHandler.class)) {
            return false;
        } else if (method.getReturnType() != void.class) {
            return false;
        } else {
            return method.getParameterCount() != 1
                    ? false
                    : !method.getParameters()[0].getType().isPrimitive();
        }
    }

    @Environment(EnvType.CLIENT)
    private static record LambdaFactoryInfo(String packagePrefix, LambdaListener.Factory factory) {}
}
