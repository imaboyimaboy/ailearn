package dev.gooba.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import dev.gooba.client.RenderEntityContext;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.sound.BiomeEffectSoundPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin({BiomeEffectSoundPlayer.class})
public class BiomeEffectSoundPlayerMixin {
    @ModifyExpressionValue(
            method = {"method_75840"},
            at = {
                @At(
                        value = "INVOKE",
                        target = "Lnet/minecraft/client/network/ClientPlayerEntity;getZ()D")
            },
            require = 0)
    private double spectator$moodZ(double d0) {
        Entity entity = RenderEntityContext.getEntity();
        return entity != null ? entity.getZ() : d0;
    }

    @ModifyExpressionValue(
            method = {"tick"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/network/ClientPlayerEntity;getEntityPos()Lnet/minecraft/util/math/Vec3d;")
            },
            require = 0)
    private Vec3d spectator$ambientPos(Vec3d vec3d) {
        Entity entity = RenderEntityContext.getEntity();
        return entity != null ? entity.getEntityPos() : vec3d;
    }

    @ModifyExpressionValue(
            method = {"method_75840"},
            at = {
                @At(
                        value = "INVOKE",
                        target = "Lnet/minecraft/client/network/ClientPlayerEntity;getX()D")
            },
            require = 0)
    private double spectator$moodX(double d0) {
        Entity entity = RenderEntityContext.getEntity();
        return entity != null ? entity.getX() : d0;
    }

    @ModifyExpressionValue(
            method = {"method_75840"},
            at = {
                @At(
                        value = "INVOKE",
                        target = "Lnet/minecraft/client/network/ClientPlayerEntity;getEyeY()D")
            },
            require = 0)
    private double spectator$moodY(double d0) {
        Entity entity = RenderEntityContext.getEntity();
        return entity != null ? entity.getEyeY() : d0;
    }
}
