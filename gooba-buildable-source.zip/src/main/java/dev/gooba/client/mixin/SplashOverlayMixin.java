package dev.gooba.client.mixin;

import com.mojang.blaze3d.systems.RenderSystem;

import dev.gooba.client.BackgroundBlur;
import dev.gooba.client.ColorUtils;
import dev.gooba.client.Fonts;
import dev.gooba.client.Gooba;
import dev.gooba.client.HudManager;
import dev.gooba.client.RenderUtils;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.resource.ResourceReload;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({SplashOverlay.class})
public abstract class SplashOverlayMixin {
    @Shadow @Final private boolean reloading;
    @Shadow @Final private MinecraftClient client;

    @Shadow private long reloadCompleteTime;

    @Unique
    private static final Identifier MENU_BG = Identifier.of("client", "textures/frame/menu.png");

    @Shadow @Final private ResourceReload reload;
    @Unique private static final Identifier LOGO = Identifier.of("client", "textures/gooba.png");
    @Shadow private float progress;
    @Unique private long goobaaStart = -1L;
    @Shadow private long reloadStartTime;

    @Inject(
            method = {"render"},
            at = {@At("HEAD")},
            cancellable = true)
    private void goobaaRender(
            DrawContext drawcontext, int i, int j, float f, CallbackInfo callbackinfo) {
        int scaledWindowWidth = drawcontext.getScaledWindowWidth();
        int scaledWindowHeight = drawcontext.getScaledWindowHeight();
        long measuringTimeMs = Util.getMeasuringTimeMs();
        if (this.goobaaStart == -1L) {
            this.goobaaStart = measuringTimeMs;
        }

        if (this.reloading && this.reloadStartTime == -1L) {
            this.reloadStartTime = measuringTimeMs;
        }

        float f1 =
                this.reloadCompleteTime > -1L
                        ? (float) (measuringTimeMs - this.reloadCompleteTime) / 1000.0F
                        : -1.0F;
        float f2 =
                this.reloadStartTime > -1L
                        ? (float) (measuringTimeMs - this.reloadStartTime) / 500.0F
                        : -1.0F;
        float f3;
        if (f1 >= 0.0F) {
            drawcontext.createNewRootLayer();
            float f4 = MathHelper.clamp(f1 * 1000.0F / 420.0F, 0.0F, 1.0F);
            f3 = 1.0F - f4 * f4 * (3.0F - 2.0F * f4);
        } else if (this.reloading) {
            if (this.client.currentScreen != null && f2 < 1.0F) {
                this.client.currentScreen.renderWithTooltip(drawcontext, i, j, f);
            } else {
                this.client.inGameHud.renderDeferredSubtitles();
            }

            drawcontext.createNewRootLayer();
            f3 = MathHelper.clamp(f2, 0.0F, 1.0F);
        } else {
            RenderSystem.getDevice()
                    .createCommandEncoder()
                    .clearColorTexture(
                            this.client.getFramebuffer().getColorAttachment(), -16118252);
            f3 = 1.0F;
        }

        float progressValue = this.reload.getProgress();
        this.progress =
                MathHelper.clamp(this.progress * 0.95F + progressValue * 0.050000012F, 0.0F, 1.0F);

        boolean flag;
        try {
            flag = this.drawGoobaa(drawcontext, f3, measuringTimeMs);
        } catch (Throwable throwable) {
            flag = false;
        }

        if (!flag) {
            this.drawFallback(drawcontext, scaledWindowWidth, scaledWindowHeight, f3);
        }

        if (f1 * 1000.0F >= 420.0F) {
            this.client.setOverlay(null);
        }

        callbackinfo.cancel();
    }

    @Unique
    private String loadingStage(float f) {
        if (f < 0.12F) {
            return "Initializing";
        } else if (f < 0.32F) {
            return "Loading Assets";
        } else if (f < 0.58F) {
            return "Loading Textures";
        } else if (f < 0.82F) {
            return "Loading Models";
        } else {
            return f < 0.97F ? "Applying Resources" : "Finishing";
        }
    }

    @Unique
    private void drawFallback(DrawContext drawcontext, int i, int j, float f) {
        int k = MathHelper.ceil(MathHelper.clamp(f, 0.0F, 1.0F) * 255.0F);
        drawcontext.fill(0, 0, i, j, -16118252);
        if (k > 4) {
            TextRenderer textrenderer = this.client.textRenderer;
            String text = this.loadingStage(this.progress);
            int l = i / 2 - textrenderer.getWidth(text) / 2;
            int i11 = j / 2 + 8;
            drawcontext.drawText(textrenderer, text, l, i11, withAlpha(15921908, k), false);
            int j1 = Math.min((int) ((float) i * 0.34F), 300);
            int k1 = i / 2 - j1 / 2;
            int l1 = i11 + 22;
            drawcontext.fill(
                    k1, l1, k1 + j1, l1 + 4, withAlpha(7764608, Math.round((float) k * 0.6F)));
            drawcontext.fill(
                    k1,
                    l1,
                    k1 + MathHelper.ceil((float) j1 * this.progress),
                    l1 + 4,
                    withAlpha(16448250, k));
        }
    }

    @Unique
    private void drawProgressBar(int i, float innerY, float f1) {
        float width = Math.min((float) i * 0.34F, 150.0F);
        float height = 4.0F;
        float innerX = (float) i * 0.5F - width * 0.5F;
        RenderUtils.Render2D.drawRoundedRect(
                innerX,
                innerY,
                width,
                height,
                ColorUtils.cachedRgba(118, 122, 128, Math.round(150.0F * f1)),
                height * 0.5F);
        float widthValue = width * this.progress;
        if (widthValue > 0.0F) {
            RenderUtils.Render2D.drawRoundedRect(
                    innerX,
                    innerY,
                    widthValue,
                    height,
                    ColorUtils.cachedRgba(250, 250, 250, Math.round(255.0F * f1)),
                    height * 0.5F);
        }
    }

    @Unique
    private boolean drawGoobaa(DrawContext drawcontext, float f, long i) {
        double scaleFactor = (double) this.client.getWindow().getScaleFactor();
        if (scaleFactor <= 0.0) {
            return false;
        } else {
            float f1 = 2.0F / (float) scaleFactor;
            int j = (int) ((float) this.client.getWindow().getScaledWidth() / f1);
            int k = (int) ((float) this.client.getWindow().getScaledHeight() / f1);
            if (j > 0 && k > 0) {
                float f2 = MathHelper.clamp((float) (i - this.goobaaStart) / 450.0F, 0.0F, 1.0F);
                float f3 = 1.0F - (1.0F - f2) * (1.0F - f2) * (1.0F - f2);
                float opacity = MathHelper.clamp(f * f3, 0.0F, 1.0F);
                if (opacity <= 0.01F) {
                    return true;
                } else {
                    drawcontext.getMatrices().pushMatrix();
                    HudManager.beginHudRender();

                    try {
                        float f5 = 1.08F;
                        float f6 = (float) j * f5;
                        float f7 = (float) k * f5;
                        RenderUtils.Images.drawOpaqueImage(
                                MENU_BG,
                                ((float) j - f6) * 0.5F,
                                ((float) k - f7) * 0.5F,
                                f6,
                                f7,
                                ColorUtils.opaqueGrayscale(255));
                        BackgroundBlur.blurDefault();
                        RenderUtils.Blur.drawRoundedBlur(
                                0.0F,
                                0.0F,
                                (float) j,
                                (float) k,
                                1.0F,
                                0.0F,
                                ColorUtils.cachedRgba(0, 0, 0, 46));
                        float f8 = (float) j * 0.5F;
                        float f9 = 62.0F;
                        float f10 = (float) k * 0.5F - 78.0F;
                        RenderUtils.Images.drawImage(
                                LOGO,
                                f8 - f9 * 0.5F,
                                f10,
                                f9,
                                f9,
                                ColorUtils.grayscaleOpacity(255, opacity));
                        String string = this.loadingStage(this.progress);
                        float size = 9.0F;
                        float f12 = f10 + f9 + 11.0F;
                        Fonts.MENU.drawCenteredText(
                                string,
                                f8,
                                f12,
                                size,
                                ColorUtils.cachedRgba(242, 242, 244, Math.round(255.0F * opacity)));
                        this.drawProgressBar(
                                j, f12 + Fonts.MENU.getLineHeight(size) + 11.0F, opacity);
                        Gooba.getInstance().getHudManager().flush();
                    } finally {
                        HudManager.endHudRender();
                        drawcontext.getMatrices().popMatrix();
                    }

                    return true;
                }
            } else {
                return false;
            }
        }
    }

    @Unique
    private static int withAlpha(int i, int j) {
        return i & 16777215 | j << 24;
    }
}
