package dev.gooba.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil.Key;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({KeyBinding.class})
public interface KeyBindingMixin {
    @Accessor("boundKey")
    Key goobaa$getBoundKey();
}
