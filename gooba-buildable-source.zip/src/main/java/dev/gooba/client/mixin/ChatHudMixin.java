package dev.gooba.client.mixin;

import dev.gooba.client.FakeTiersModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Environment(EnvType.CLIENT)
@Mixin(
        value = {ChatHud.class},
        priority = 999)
public class ChatHudMixin {
    @ModifyVariable(
            method = {
                "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V"
            },
            at = @At("HEAD"),
            argsOnly = true,
            require = 0)
    private Text fakeTiersChat(Text text) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FakeTiersModule fakeTiersModule =
                    Gooba.getInstance().getModuleRegistry().findModule(FakeTiersModule.class);
            return fakeTiersModule == null ? text : fakeTiersModule.decorateChat(text);
        } else {
            return text;
        }
    }
}
