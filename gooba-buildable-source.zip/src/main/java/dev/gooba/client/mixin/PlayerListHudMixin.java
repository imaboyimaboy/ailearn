package dev.gooba.client.mixin;

import dev.gooba.client.FakeTiersModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(
        value = {PlayerListHud.class},
        priority = 999)
public class PlayerListHudMixin {
    @Inject(
            method = {"getPlayerName"},
            at = {@At("RETURN")},
            cancellable = true,
            require = 0)
    private void fakeTiersTabName(
            PlayerListEntry playerlistentry, CallbackInfoReturnable<Text> callbackinforeturnable) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FakeTiersModule fakeTiersModule =
                    Gooba.getInstance().getModuleRegistry().findModule(FakeTiersModule.class);
            if (fakeTiersModule != null
                    && fakeTiersModule.isEnabled()
                    && fakeTiersModule.tablistSetting.isOn()
                    && playerlistentry != null) {
                Text text = (Text) callbackinforeturnable.getReturnValue();
                if (text != null) {
                    callbackinforeturnable.setReturnValue(
                            fakeTiersModule.decorateTabEntry(text, playerlistentry));
                }
            }
        }
    }
}
