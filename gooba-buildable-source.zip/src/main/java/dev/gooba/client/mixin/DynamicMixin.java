package dev.gooba.client.mixin;

import dev.gooba.client.TickSpeedAccess;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(targets = {"net/minecraft/client/render/RenderTickCounter$Dynamic"})
public class DynamicMixin implements TickSpeedAccess {
    @Shadow private float dynamicDeltaTicks;
    @Unique private float speed = 1.0F;

    @Override
    public float getSpeed() {
        return this.speed;
    }

    @Override
    public void setSpeed(float speedValue) {
        this.speed = speedValue;
    }

    @Inject(
            method = {"beginRenderTick(J)I"},
            at = {
                @At(
                        value = "FIELD",
                        target =
                                "Lnet/minecraft/client/render/RenderTickCounter$Dynamic;lastTimeMillis:J",
                        opcode = Opcodes.PUTFIELD,
                        shift = Shift.AFTER)
            })
    private void applySpeedToDelta(long i, CallbackInfoReturnable<Integer> callbackinforeturnable) {
        this.dynamicDeltaTicks = this.dynamicDeltaTicks * this.speed;
    }
}
