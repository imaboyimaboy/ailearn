package dev.gooba.client.mixin;

import dev.gooba.client.WorldTweaksModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.AtmosphericFogModifier;
import net.minecraft.client.render.fog.FogData;
import net.minecraft.client.world.ClientWorld;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({AtmosphericFogModifier.class})
public class AtmosphericFogModifierMixin {
    @Inject(
            method = {"applyStartEndModifier"},
            at = {@At("RETURN")})
    private void onApplyStartEnd(
            FogData fogdata,
            Camera camera,
            ClientWorld clientworld,
            float f,
            RenderTickCounter rendertickcounter,
            CallbackInfo callbackinfo) {
        WorldTweaksModule worldTweaksModule = WorldTweaksModule.getInstance();
        if (worldTweaksModule != null
                && worldTweaksModule.isEnabled()
                && worldTweaksModule.overrideFogSetting.isOn()) {
            float environmentalEnd = worldTweaksModule.fogDistanceSetting.getFloat();
            fogdata.environmentalStart = Math.min(2.0F, environmentalEnd * 0.25F);
            fogdata.environmentalEnd = environmentalEnd;
            fogdata.skyEnd = environmentalEnd;
            fogdata.cloudEnd = environmentalEnd;
        }
    }

    @Inject(
            method = {"getFogColor"},
            at = {@At("RETURN")},
            cancellable = true)
    private void onGetFogColor(
            ClientWorld clientworld,
            Camera camera,
            int i,
            float f,
            CallbackInfoReturnable<Integer> callbackinforeturnable) {
        WorldTweaksModule worldTweaksModule = WorldTweaksModule.getInstance();
        if (worldTweaksModule != null
                && worldTweaksModule.isEnabled()
                && worldTweaksModule.overrideFogSetting.isOn()) {
            callbackinforeturnable.setReturnValue(worldTweaksModule.getFogColor());
        }
    }
}
