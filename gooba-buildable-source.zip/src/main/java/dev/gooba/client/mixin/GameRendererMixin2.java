package dev.gooba.client.mixin;

import dev.gooba.client.CustomFOVModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({GameRenderer.class})
public class GameRendererMixin2 {
    @Inject(
            method = {"getFov"},
            at = {@At("RETURN")},
            cancellable = true,
            require = 0)
    private void onGetFov(
            Camera camera,
            float f,
            boolean flag,
            CallbackInfoReturnable<Float> callbackinforeturnable) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            CustomFOVModule customFOVModule2 =
                    Gooba.getInstance().getModuleRegistry().findModule(CustomFOVModule.class);
            if (customFOVModule2 != null && customFOVModule2.isEnabled()) {
                callbackinforeturnable.setReturnValue(customFOVModule2.fOVSetting.getFloat());
            }
        }
    }
}
