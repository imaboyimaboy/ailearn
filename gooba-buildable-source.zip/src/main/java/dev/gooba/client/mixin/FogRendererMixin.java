package dev.gooba.client.mixin;

import dev.gooba.client.ColorUtils;
import dev.gooba.client.FogEvent;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogRenderer;
import net.minecraft.client.world.ClientWorld;

import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Environment(EnvType.CLIENT)
@Mixin({FogRenderer.class})
public class FogRendererMixin {
    @Unique private static final ThreadLocal<FogEvent> FOG_EVENT = new ThreadLocal<>();

    @Inject(
            method = {"applyFog"},
            at = {@At("HEAD")})
    private void onApplyFogHead(
            Camera camera,
            int i,
            RenderTickCounter rendertickcounter,
            float f,
            ClientWorld clientworld,
            CallbackInfoReturnable<Vector4f> callbackinforeturnable) {
        FogEvent fogEvent = new FogEvent();
        fogEvent.hook();
        if (fogEvent.isCancelled()) {
            FOG_EVENT.set(fogEvent);
        } else {
            FOG_EVENT.remove();
        }
    }

    @Inject(
            method = {"applyFog"},
            at = {@At("RETURN")},
            cancellable = true)
    private void onApplyFogReturn(
            Camera camera,
            int i,
            RenderTickCounter rendertickcounter,
            float f,
            ClientWorld clientworld,
            CallbackInfoReturnable<Vector4f> callbackinforeturnable) {
        FogEvent fogEvent = FOG_EVENT.get();
        if (fogEvent != null && fogEvent.isCancelled()) {
            int color = fogEvent.getColor();
            callbackinforeturnable.setReturnValue(
                    new Vector4f(
                            ColorUtils.redFloat(color),
                            ColorUtils.greenFloat(color),
                            ColorUtils.blueFloat(color),
                            ColorUtils.alphaFloat(color)));
        }

        FOG_EVENT.remove();
    }

    @ModifyArgs(
            method = {"applyFog"},
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/render/fog/FogRenderer;applyFog(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V"))
    private void modifyFogArgs(Args args) {
        FogEvent fogEvent = FOG_EVENT.get();
        if (fogEvent != null && fogEvent.isCancelled()) {
            int color = fogEvent.getColor();
            Vector4f vector4f = args.get(2);
            vector4f.set(
                    ColorUtils.redFloat(color),
                    ColorUtils.greenFloat(color),
                    ColorUtils.blueFloat(color),
                    ColorUtils.alphaFloat(color));
            float f = 2.0F;
            float distance = fogEvent.getDistance();
            args.set(3, f);
            args.set(4, distance);
            args.set(7, distance);
            args.set(8, distance);
        }
    }
}
