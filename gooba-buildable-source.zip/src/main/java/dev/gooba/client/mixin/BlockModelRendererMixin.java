package dev.gooba.client.mixin;

import dev.gooba.client.XRayModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.BlockModelRenderer;
import net.minecraft.client.render.model.BlockModelPart;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;

@Environment(EnvType.CLIENT)
@Mixin({BlockModelRenderer.class})
public class BlockModelRendererMixin {
    private static final ThreadLocal<BlockState> CURRENT_STATE = new ThreadLocal<>();
    private static final ThreadLocal<BlockPos> CURRENT_POS = new ThreadLocal<>();

    @Redirect(
            method = {"render"},
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/render/block/BlockModelRenderer;renderSmooth(Lnet/minecraft/world/BlockRenderView;Ljava/util/List;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;ZI)V"))
    private void renderSmooth(
            BlockModelRenderer blockmodelrenderer,
            BlockRenderView blockrenderview,
            List<BlockModelPart> list,
            BlockState blockstate,
            BlockPos blockpos,
            MatrixStack matrixstack,
            VertexConsumer vertexconsumer,
            boolean flag,
            int i) {
        boolean flag1 = beginXrayRender(blockstate, blockpos);

        try {
            blockmodelrenderer.renderSmooth(
                    blockrenderview,
                    list,
                    blockstate,
                    blockpos,
                    matrixstack,
                    vertexconsumer,
                    flag,
                    i);
        } finally {
            endXrayRender(flag1);
        }
    }

    private static boolean beginXrayRender(BlockState blockstate, BlockPos blockpos) {
        XRayModule xRayModule2 = XRayModule.getInstance();
        if (xRayModule2 != null && xRayModule2.isEnabled()) {
            CURRENT_STATE.set(blockstate);
            CURRENT_POS.set(blockpos);
            return true;
        } else {
            return false;
        }
    }

    private static void endXrayRender(boolean flag) {
        if (flag) {
            CURRENT_STATE.remove();
            CURRENT_POS.remove();
        }
    }

    @Redirect(
            method = {"render"},
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/render/block/BlockModelRenderer;renderFlat(Lnet/minecraft/world/BlockRenderView;Ljava/util/List;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;ZI)V"))
    private void renderFlat(
            BlockModelRenderer blockmodelrenderer,
            BlockRenderView blockrenderview,
            List<BlockModelPart> list,
            BlockState blockstate,
            BlockPos blockpos,
            MatrixStack matrixstack,
            VertexConsumer vertexconsumer,
            boolean flag,
            int i) {
        boolean flag1 = beginXrayRender(blockstate, blockpos);

        try {
            blockmodelrenderer.renderFlat(
                    blockrenderview,
                    list,
                    blockstate,
                    blockpos,
                    matrixstack,
                    vertexconsumer,
                    flag,
                    i);
        } finally {
            endXrayRender(flag1);
        }
    }

    @ModifyArg(
            method = {"renderQuad"},
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/render/VertexConsumer;quad(Lnet/minecraft/client/util/math/MatrixStack$Entry;Lnet/minecraft/client/render/model/BakedQuad;[FFFFF[II)V"),
            index = 6)
    private float modifyQuadAlpha(float f) {
        BlockState blockstate = CURRENT_STATE.get();
        BlockPos blockpos = CURRENT_POS.get();
        if (blockstate != null) {
            int i = XRayModule.blockOpacity(blockstate, blockpos);
            if (i >= 0) {
                return (float) i / 255.0F;
            }
        }

        return f;
    }
}
