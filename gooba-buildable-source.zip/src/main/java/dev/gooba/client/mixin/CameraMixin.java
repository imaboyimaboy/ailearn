package dev.gooba.client.mixin;

import dev.gooba.client.CameraPositionEvent;
import dev.gooba.client.CameraRotationEvent;
import dev.gooba.client.NoRenderModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({Camera.class})
public abstract class CameraMixin {
    @Shadow @Final private Mutable blockPos;
    @Unique private CameraRotationEvent goobaa$rotationEvent;
    @Unique private float goobaa$originalYaw;
    @Shadow private Vec3d pos;
    @Unique private float goobaa$originalPitch;
    @Unique private boolean goobaa$inverseView;

    @Inject(
            method = {"update"},
            at = {@At("HEAD")})
    private void onUpdateHead(
            World world,
            Entity entity,
            boolean flag,
            boolean flag1,
            float f,
            CallbackInfo callbackinfo) {
        this.goobaa$inverseView = flag && flag1;
        if (entity != null) {
            this.goobaa$originalYaw = entity.getYaw(f);
            this.goobaa$originalPitch = entity.getPitch(f);
            this.goobaa$rotationEvent =
                    new CameraRotationEvent(this.goobaa$originalYaw, this.goobaa$originalPitch, f);
            this.goobaa$rotationEvent.hook();
        } else {
            this.goobaa$rotationEvent = null;
        }
    }

    @Inject(
            method = {"setPos(Lnet/minecraft/util/math/Vec3d;)V"},
            at = {@At("HEAD")},
            cancellable = true)
    private void posHook(Vec3d vec3d, CallbackInfo callbackinfo) {
        CameraPositionEvent cameraPositionEvent = new CameraPositionEvent(vec3d);
        cameraPositionEvent.hook();
        this.pos = vec3d = cameraPositionEvent.getPos();
        this.blockPos.set(vec3d.x, vec3d.y, vec3d.z);
        callbackinfo.cancel();
    }

    @Shadow
    public abstract void setRotation(float f, float f1);

    @Redirect(
            method = {"update"},
            at =
                    @At(
                            value = "INVOKE",
                            target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"))
    private void redirectSetRotation(Camera camera, float f, float f1) {
        if (this.goobaa$rotationEvent != null
                && (this.goobaa$rotationEvent.getYaw() != this.goobaa$originalYaw
                        || this.goobaa$rotationEvent.getPitch() != this.goobaa$originalPitch)) {
            if (this.goobaa$inverseView) {
                this.setRotation(
                        this.goobaa$rotationEvent.getYaw() + 180.0F,
                        -this.goobaa$rotationEvent.getPitch());
            } else {
                this.setRotation(
                        this.goobaa$rotationEvent.getYaw(), this.goobaa$rotationEvent.getPitch());
            }
        } else {
            this.setRotation(f, f1);
        }
    }

    @Inject(
            method = {"clipToSpace"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onClipToSpace(float f, CallbackInfoReturnable<Float> callbackinforeturnable) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule != null
                && noRenderModule.isEnabled()
                && noRenderModule.cameraClipSetting.isOn()) {
            callbackinforeturnable.setReturnValue(f);
        }
    }
}
