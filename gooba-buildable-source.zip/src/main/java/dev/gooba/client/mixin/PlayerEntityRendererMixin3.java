package dev.gooba.client.mixin;

import dev.gooba.client.CustomModelState;
import dev.gooba.client.CustomModelsModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerLikeEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityRenderer.class})
public class PlayerEntityRendererMixin3<
        AvatarlikeEntity extends PlayerLikeEntity & ClientPlayerLikeEntity> {
    @Inject(
            method = {"updateRenderState"},
            at = {@At("TAIL")})
    private void goobaa$updateCustomModelState(
            AvatarlikeEntity playerlikeentity,
            PlayerEntityRenderState playerentityrenderstate,
            float f,
            CallbackInfo callbackinfo) {
        CustomModelsModule customModelsModule =
                Gooba.getInstance().getModuleRegistry().findModule(CustomModelsModule.class);
        boolean flag =
                customModelsModule != null
                        && customModelsModule.shouldUseCustomModel(playerlikeentity);
        ((CustomModelState) playerentityrenderstate)
                .goobaa$setCustomModel(flag, flag ? customModelsModule.selectedModel() : "");
    }
}
