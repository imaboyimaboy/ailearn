package dev.gooba.client.mixin;

import dev.gooba.client.FastPlaceModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Environment(EnvType.CLIENT)
@Mixin({MinecraftClient.class})
public class MinecraftClientMixin2 {
    @ModifyConstant(
            method = {"doItemUse"},
            constant = {@Constant(intValue = 4)})
    private int modifyPlaceCooldown(int i) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FastPlaceModule fastPlaceModule =
                    Gooba.getInstance().getModuleRegistry().findModule(FastPlaceModule.class);
            MinecraftClient minecraftclient = (MinecraftClient) ((MinecraftClient) (Object) this);
            if (fastPlaceModule != null
                    && fastPlaceModule.isEnabled()
                    && minecraftclient.player != null) {
                int useDelay =
                        fastPlaceModule.getUseDelay(minecraftclient.player.getMainHandStack());
                if (useDelay < i) {
                    return useDelay;
                } else {
                    int useDelayValue =
                            fastPlaceModule.getUseDelay(minecraftclient.player.getOffHandStack());
                    return useDelayValue < i ? useDelayValue : i;
                }
            } else {
                return i;
            }
        } else {
            return i;
        }
    }
}
