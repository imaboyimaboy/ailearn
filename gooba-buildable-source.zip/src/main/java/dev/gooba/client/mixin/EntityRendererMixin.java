package dev.gooba.client.mixin;

import dev.gooba.client.NameTagsModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({EntityRenderer.class})
public class EntityRendererMixin<T extends Entity, S extends EntityRenderState> {
    @Inject(
            method = {"renderLabelIfPresent"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onRenderLabelIfPresent(
            S entityrenderstate,
            MatrixStack matrixstack,
            OrderedRenderCommandQueue orderedrendercommandqueue,
            CameraRenderState camerarenderstate,
            CallbackInfo callbackinfo) {
        NameTagsModule nameTagsModule = NameTagsModule.getInstance();
        if (nameTagsModule != null && nameTagsModule.isEnabled()) {
            if (entityrenderstate.entityType == EntityType.PLAYER
                    && nameTagsModule.playersSetting.isOn()) {
                callbackinfo.cancel();
            }
        }
    }

    @Inject(
            method = {"getDisplayName"},
            at = {@At("HEAD")},
            cancellable = true)
    private void hookNametag(T entity, CallbackInfoReturnable<Text> callbackinforeturnable) {
        NameTagsModule nameTagsModule = NameTagsModule.getInstance();
        if (nameTagsModule != null && nameTagsModule.isEnabled()) {
            if (entity instanceof PlayerEntity playerentity
                    && nameTagsModule.playersSetting.isOn()) {
                if (nameTagsModule.ignoreUnarmoredPlayersSetting.isOn()
                        && !NameTagsModule.isArmored(playerentity)) {
                    return;
                }

                callbackinforeturnable.setReturnValue(null);
            }
        }
    }
}
