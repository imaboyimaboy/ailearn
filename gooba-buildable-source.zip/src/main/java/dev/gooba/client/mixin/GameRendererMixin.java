package dev.gooba.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.gooba.client.ClickGuiScreen;
import dev.gooba.client.Gooba;
import dev.gooba.client.HUDModule;
import dev.gooba.client.HandEditor;
import dev.gooba.client.HudManager;
import dev.gooba.client.NoRenderModule;
import dev.gooba.client.RenderEntityContext;
import dev.gooba.client.RenderUtils;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.gui.render.state.GuiRenderState;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogRenderer;
import net.minecraft.client.render.fog.FogRenderer.FogType;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.RotationAxis;

import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({GameRenderer.class})
public abstract class GameRendererMixin {
    @Shadow @Final GuiRenderState guiState;
    @Shadow @Final private Camera camera;
    @Shadow @Final private MinecraftClient client;
    @Shadow @Final private FogRenderer fogRenderer;
    @Shadow @Final private GuiRenderer guiRenderer;

    @Shadow
    public abstract float getFov(Camera camera, float f, boolean flag);

    @Inject(
            method = {"render"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/gui/render/GuiRenderer;render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V",
                        shift = Shift.AFTER)
            })
    private void afterGuiRender(
            RenderTickCounter rendertickcounter, boolean flag, CallbackInfo callbackinfo) {
        if (this.client.world != null && this.client.player != null) {
            if (!this.isLoadingScreen(this.client.currentScreen)) {
                if (this.client.getOverlay() == null) {
                    if (this.shouldRenderOnTop(this.client.currentScreen)) {
                        this.guiState.clear();
                        int scaledX = (int) this.client.mouse.getScaledX(this.client.getWindow());
                        int scaledY = (int) this.client.mouse.getScaledY(this.client.getWindow());
                        rendertickcounter.getTickProgress(false);
                        DrawContext drawcontext =
                                new DrawContext(this.client, this.guiState, scaledX, scaledY);
                        if (this.client.currentScreen instanceof ClickGuiScreen clickGuiScreen) {
                            clickGuiScreen.renderGui(drawcontext, rendertickcounter);
                        } else if (this.client.currentScreen == null
                                && Gooba.getInstance().getClickGui().isClosing()) {
                            Gooba.getInstance()
                                    .getClickGui()
                                    .renderGui(drawcontext, rendertickcounter);
                        }

                        if (this.client.currentScreen instanceof InventoryScreen) {
                            HudManager.beginHudRender();
                            HUDModule.getInstance().renderRegionMap();
                            Gooba.getInstance().getHudManager().flush();
                            HudManager.endHudRender();
                        }

                        this.guiRenderer.render(this.fogRenderer.getFogBuffer(FogType.NONE));
                    }
                }
            }
        }
    }

    @ModifyExpressionValue(
            method = {"renderWorld"},
            at = {@At(value = "INVOKE", target = "Ljava/lang/Math;max(FF)F", ordinal = 0)})
    private float onNauseaDistortion(float f) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        return noRenderModule != null
                        && noRenderModule.isEnabled()
                        && noRenderModule.removeNegativeEffectsSetting.isOn()
                ? 0.0F
                : f;
    }

    @Unique
    private boolean shouldRenderOnTop(Screen screen) {
        if (screen == null) {
            return true;
        } else if (screen instanceof ClickGuiScreen) {
            return true;
        } else {
            return screen instanceof ChatScreen ? true : screen instanceof InventoryScreen;
        }
    }

    @Inject(
            method = {"showFloatingItem"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onShowFloatingItem(ItemStack itemstack, CallbackInfo callbackinfo) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule != null
                && noRenderModule.isEnabled()
                && noRenderModule.removeTotemAnimationSetting.isOn()) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"renderWorld"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;draw()V",
                        shift = Shift.AFTER)
            })
    private void captureHandsForEditor(
            RenderTickCounter rendertickcounter, CallbackInfo callbackinfo) {
        HandEditor handEditor2 = HandEditor.getInstance();
        if (handEditor2.isActive()) {
            handEditor2.afterHandRender();
        }
    }

    @Inject(
            method = {"close"},
            at = {@At("RETURN")})
    private void onClose(CallbackInfo callbackinfo) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getHudManager() != null) {
            Gooba.getInstance().getHudManager().close();
        }
    }

    @Inject(
            method = {"renderHand"},
            at = {@At("HEAD")},
            cancellable = true)
    private void spectator$hideHand(CallbackInfo callbackinfo) {
        if (RenderEntityContext.hasEntity()) {
            callbackinfo.cancel();
        }
    }

    @Unique
    private boolean isLoadingScreen(Screen screen) {
        if (screen == null) {
            return false;
        } else {
            String text = screen.getClass().getSimpleName().toLowerCase();
            String textValue = screen.getClass().getName().toLowerCase();
            if (text.contains("loading")) {
                return true;
            } else if (text.contains("progress")) {
                return true;
            } else if (text.contains("connecting")) {
                return true;
            } else if (text.contains("downloading")) {
                return true;
            } else if (text.contains("terrain")) {
                return true;
            } else if (text.contains("generating")) {
                return true;
            } else if (text.contains("saving")) {
                return true;
            } else if (text.contains("reload")) {
                return true;
            } else if (text.contains("resource")) {
                return true;
            } else {
                return text.contains("pack") ? true : textValue.contains("mojang");
            }
        }
    }

    @Inject(
            method = {"renderWorld"},
            at = {
                @At(
                        value = "INVOKE_STRING",
                        target = "Lnet/minecraft/util/profiler/Profiler;swap(Ljava/lang/String;)V",
                        args = {"ldc=hand"})
            })
    public void hookWorldRender(
            RenderTickCounter rendertickcounter,
            CallbackInfo callbackinfo,
            @Local(ordinal = 0) Matrix4f matrix4f,
            @Local(ordinal = 1) Matrix4f matrix4f1,
            @Local(ordinal = 0) float f,
            @Local MatrixStack matrixstack) {
        if (this.client.world != null && this.client.player != null) {
            MatrixStack matrixStack = new MatrixStack();
            matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(this.camera.getPitch()));
            matrixStack.multiply(
                    RotationAxis.POSITIVE_Y.rotationDegrees(this.camera.getYaw() + 180.0F));
            RenderUtils.Render3D.projectionMatrix.set(
                    this.client.gameRenderer.getBasicProjectionMatrix(
                            this.getFov(this.camera, f, true)));
            RenderUtils.Render3D.modelViewMatrix.set(RenderSystem.getModelViewMatrix());
            RenderUtils.Render3D.positionMatrix.set(matrixStack.peek().getPositionMatrix());
        }
    }
}
