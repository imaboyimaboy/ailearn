package dev.gooba.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Environment(EnvType.CLIENT)
@Mixin({ItemStack.class})
public abstract class ItemStackMixin2 {
    @Unique
    private static final Pattern PRICE_PATTERN = Pattern.compile("Price:?\\s*([\\d,\\s\\.]+)", 2);

    @Inject(
            method = {"getTooltip"},
            at = {@At("RETURN")},
            cancellable = true)
    private void appendUnitPrice(
            TooltipContext tooltipcontext,
            PlayerEntity playerentity,
            TooltipType tooltiptype,
            CallbackInfoReturnable<List<Text>> callbackinforeturnable) {
        try {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (!(minecraftclient.currentScreen instanceof GenericContainerScreen)) {
                return;
            }

            ItemStack itemstack = (ItemStack) ((ItemStack) (Object) this);
            if (itemstack.isEmpty() || itemstack.getCount() <= 1) {
                return;
            }

            int i = parsePriceFromLore(itemstack);
            if (i <= 0) {
                return;
            }

            int j = i / itemstack.getCount();
            if (j <= 0) {
                j = 1;
            }

            ArrayList arraylist =
                    new ArrayList((Collection) callbackinforeturnable.getReturnValue());
            int k = findPriceLineIndex(arraylist);
            MutableText mutabletext =
                    Text.literal("")
                            .append(Text.literal("$ ").formatted(Formatting.DARK_GREEN))
                            .append(Text.literal("For 1 piece: ").formatted(Formatting.WHITE))
                            .append(Text.literal(formatPrice(j)).formatted(Formatting.GREEN));
            if (k >= 0 && k + 1 <= arraylist.size()) {
                arraylist.add(k + 1, mutabletext);
            } else {
                arraylist.add(mutabletext);
            }

            callbackinforeturnable.setReturnValue(arraylist);
        } catch (Exception exception) {
        }
    }

    @Unique
    private static int findPriceLineIndex(List<Text> list) {
        for (int i = 0; i < list.size(); i++) {
            String text = Formatting.strip(((Text) list.get(i)).getString());
            if (text != null) {
                Matcher matcher = PRICE_PATTERN.matcher(text);
                if (matcher.find()) {
                    return i;
                }

                String textValue = text.toLowerCase();
                if (textValue.contains("price")
                        || textValue.contains("price")
                        || textValue.contains("prices")) {
                    return i;
                }
            }
        }

        return -1;
    }

    @Unique
    private static String formatPrice(int i) {
        String text = String.valueOf(i);
        StringBuilder stringbuilder = new StringBuilder();

        for (int j = 0; j < text.length(); j++) {
            if (j > 0 && (text.length() - j) % 3 == 0) {
                stringbuilder.append('.');
            }

            stringbuilder.append(text.charAt(j));
        }

        return stringbuilder.toString();
    }

    @Unique
    private static int parsePriceFromLore(ItemStack itemstack) {
        LoreComponent lorecomponent = itemstack.get(DataComponentTypes.LORE);
        if (lorecomponent == null) {
            return 0;
        } else {
            for (Text text : lorecomponent.lines()) {
                String textValue = Formatting.strip(text.getString());
                if (textValue != null) {
                    Matcher matcher = PRICE_PATTERN.matcher(textValue);
                    if (matcher.find()) {
                        try {
                            String text2 = matcher.group(1).replaceAll("[,\\s\\.]", "");
                            return Integer.parseInt(text2);
                        } catch (NumberFormatException numberformatexception) {
                        }
                    }
                }
            }

            return 0;
        }
    }
}
