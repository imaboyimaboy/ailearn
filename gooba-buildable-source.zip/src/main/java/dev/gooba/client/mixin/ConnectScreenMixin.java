package dev.gooba.client.mixin;

import dev.gooba.client.AutoReconnectModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.CookieStorage;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({ConnectScreen.class})
public class ConnectScreenMixin {
    @Inject(
            method = {"connect"},
            at = {@At("HEAD")},
            require = 0)
    private static void rememberConnection(
            Screen screen,
            MinecraftClient minecraftclient,
            ServerAddress serveraddress,
            ServerInfo serverinfo,
            boolean flag,
            CookieStorage cookiestorage,
            CallbackInfo callbackinfo) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            AutoReconnectModule autoReconnectModule =
                    Gooba.getInstance().getModuleRegistry().findModule(AutoReconnectModule.class);
            if (autoReconnectModule != null) {
                autoReconnectModule.rememberServer(serveraddress, serverinfo);
            }
        }
    }
}
