package dev.gooba.client.mixin;

import dev.gooba.client.CustomModelState;
import dev.gooba.client.CustomPlayerModels;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.command.ModelCommandRenderer.CrumblingOverlayCommand;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Environment(EnvType.CLIENT)
@Mixin({LivingEntityRenderer.class})
public abstract class LivingEntityRendererMixin {
    @Redirect(
            method = {"render"},
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"))
    private void goobaa$replacePlayerModel(
            OrderedRenderCommandQueue orderedrendercommandqueue,
            Model model,
            Object object,
            MatrixStack matrixstack,
            RenderLayer renderlayer,
            int i,
            int j,
            int k,
            Sprite sprite,
            int l,
            CrumblingOverlayCommand crumblingoverlaycommand,
            LivingEntityRenderState livingentityrenderstate,
            MatrixStack matrixStack,
            OrderedRenderCommandQueue orderedRenderCommandQueue,
            CameraRenderState camerarenderstate) {
        if (object instanceof PlayerEntityRenderState playerentityrenderstate
                && object instanceof CustomModelState customModelState
                && customModelState.goobaa$hasCustomModel()
                && model instanceof PlayerEntityModel playerentitymodel) {
            playerentitymodel.setAngles(playerentityrenderstate);
            if (CustomPlayerModels.render(
                    customModelState.goobaa$getCustomModel(),
                    playerentitymodel,
                    playerentityrenderstate,
                    matrixstack,
                    orderedrendercommandqueue,
                    i,
                    j,
                    k,
                    l)) {
                return;
            }
        }

        orderedrendercommandqueue.submitModel(
                model,
                object,
                matrixstack,
                renderlayer,
                i,
                j,
                k,
                sprite,
                l,
                crumblingoverlaycommand);
    }
}
