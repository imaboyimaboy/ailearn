package dev.gooba.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.pack.PackScreen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ButtonWidget.Builder;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.io.File;
import java.nio.file.Path;

@Environment(EnvType.CLIENT)
@Mixin({PackScreen.class})
public abstract class PackScreenMixin {
    @Unique private static final Logger LOGGER = LoggerFactory.getLogger(PackScreenMixin.class);
    @Unique private static final Text OPEN_FOLDER = Text.translatable("pack.openFolder");
    @Shadow private Path file;
    @Unique private static final Text FOLDER_INFO = Text.translatable("pack.folderInfo");

    @Redirect(
            method = {"init"},
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/gui/widget/ButtonWidget$Builder;build()Lnet/minecraft/client/gui/widget/ButtonWidget;"))
    private ButtonWidget redirectOpenFolderButton(Builder builder) {
        Text text = ((BuilderMixin) builder).getMessage();
        return text.equals(OPEN_FOLDER)
                ? ButtonWidget.builder(
                                OPEN_FOLDER,
                                buttonwidget -> {
                                    File fileValue = this.file.toFile();
                                    if (!fileValue.exists()) {
                                        fileValue.mkdirs();
                                    }

                                    Util.getOperatingSystem().open(fileValue);
                                })
                        .tooltip(Tooltip.of(FOLDER_INFO))
                        .build()
                : builder.build();
    }
}
