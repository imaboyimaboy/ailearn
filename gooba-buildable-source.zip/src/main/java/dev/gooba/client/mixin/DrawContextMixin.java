package dev.gooba.client.mixin;

import dev.gooba.client.NoInvLeakModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({DrawContext.class})
public class DrawContextMixin {
    @Inject(
            method = {
                "drawStackOverlay(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V"
            },
            at = {@At("HEAD")},
            cancellable = true,
            require = 0)
    private void noInvLeak_cancelOverlayStr(
            TextRenderer textrenderer,
            ItemStack itemstack,
            int i,
            int j,
            String text,
            CallbackInfo callbackinfo) {
        if (isActive() && itemstack != null && !itemstack.isEmpty()) {
            callbackinfo.cancel();
        }
    }

    private static ItemStack totem() {
        return new ItemStack(Items.TOTEM_OF_UNDYING);
    }

    @Inject(
            method = {"drawStackOverlay"},
            at = {@At("HEAD")},
            cancellable = true,
            require = 0)
    private void noInvLeak_cancelOverlay(
            TextRenderer textrenderer,
            ItemStack itemstack,
            int i,
            int j,
            CallbackInfo callbackinfo) {
        if (isActive() && itemstack != null && !itemstack.isEmpty()) {
            callbackinfo.cancel();
        }
    }

    @ModifyVariable(
            method = {"drawItem(Lnet/minecraft/item/ItemStack;III)V"},
            at = @At("HEAD"),
            argsOnly = true,
            require = 0)
    private ItemStack noInvLeak_3arg(ItemStack itemstack) {
        return isActive() && itemstack != null && !itemstack.isEmpty() ? totem() : itemstack;
    }

    @ModifyVariable(
            method = {
                "drawItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;III)V"
            },
            at = @At("HEAD"),
            argsOnly = true,
            ordinal = 0,
            require = 0)
    private ItemStack noInvLeak_entity3(ItemStack itemstack) {
        return isActive() && itemstack != null && !itemstack.isEmpty() ? totem() : itemstack;
    }

    @ModifyVariable(
            method = {"drawItem"},
            at = @At("HEAD"),
            argsOnly = true,
            require = 0)
    private ItemStack noInvLeak_2arg(ItemStack itemstack) {
        return isActive() && itemstack != null && !itemstack.isEmpty() ? totem() : itemstack;
    }

    private static boolean isActive() {
        NoInvLeakModule noInvLeakModule2 = NoInvLeakModule.getInstance();
        return noInvLeakModule2 != null && noInvLeakModule2.isEnabled();
    }
}
