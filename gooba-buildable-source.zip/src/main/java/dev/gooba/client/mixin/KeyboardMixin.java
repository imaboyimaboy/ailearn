package dev.gooba.client.mixin;

import dev.gooba.client.KeyPressEvent;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({Keyboard.class})
public class KeyboardMixin {
    @Shadow @Final private MinecraftClient client;

    @Inject(
            method = {"onKey"},
            at = {@At("HEAD")})
    private void onKey(long i, int j, KeyInput keyinput, CallbackInfo callbackinfo) {
        Screen screen = this.client.currentScreen;
        int k = keyinput.key();
        if (k != -1 && k != 0) {
            if (k < 0 || k > 7) {
                if (j == 1 && screen == null) {
                    KeyPressEvent keyPressEvent = new KeyPressEvent(k);
                    keyPressEvent.hook();
                }
            }
        }
    }
}
