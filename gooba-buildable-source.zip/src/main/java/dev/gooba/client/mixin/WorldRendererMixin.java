package dev.gooba.client.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;

import dev.gooba.client.NoRenderModule;
import dev.gooba.client.Render3DEvent;
import dev.gooba.client.ShaderESPModule;
import dev.gooba.client.ShaderSkyModule;
import dev.gooba.client.ShaderSkyRenderer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.SkyRendering;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.state.SkyRenderState;
import net.minecraft.client.util.ObjectAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;

import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({WorldRenderer.class})
public class WorldRendererMixin {
    @Shadow @Nullable private Framebuffer entityOutlineFramebuffer;

    @Inject(
            method = {"hasBlindnessOrDarkness"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onHasBlindnessOrDarkness(
            Camera camera, CallbackInfoReturnable<Boolean> callbackinforeturnable) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule != null && noRenderModule.isEnabled()) {
            if (camera.getFocusedEntity() instanceof LivingEntity livingentity) {
                boolean hasStatusEffect = livingentity.hasStatusEffect(StatusEffects.BLINDNESS);
                boolean hasStatusEffectValue = livingentity.hasStatusEffect(StatusEffects.DARKNESS);
                if (noRenderModule.removeNegativeEffectsSetting.isOn()
                        && hasStatusEffect
                        && !hasStatusEffectValue) {
                    callbackinforeturnable.setReturnValue(false);
                }

                if (noRenderModule.removeNegativeEffectsSetting.isOn()
                        && hasStatusEffectValue
                        && !hasStatusEffect) {
                    callbackinforeturnable.setReturnValue(false);
                }

                if (noRenderModule.removeNegativeEffectsSetting.isOn()) {
                    callbackinforeturnable.setReturnValue(false);
                }
            }
        }
    }

    @Inject(
            method = {"method_62215"},
            at = {
                @At(
                        value = "INVOKE",
                        target = "Lnet/minecraft/client/render/SkyRendering;renderTopSky(I)V",
                        shift = Shift.AFTER)
            },
            require = 0)
    private static void renderShaderSkyLayer(
            GpuBufferSlice gpubufferslice,
            SkyRenderState skyrenderstate,
            SkyRendering skyrendering,
            CallbackInfo callbackinfo) {
        ShaderSkyModule shaderSkyModule2 = ShaderSkyModule.getInstance();
        if (shaderSkyModule2 != null
                && shaderSkyModule2.isEnabled()
                && !shaderSkyModule2.modeSetting.isSelected("Blur")) {
            ShaderSkyRenderer.getInstance().renderSky();
        }
    }

    @Inject(
            method = {"drawEntityOutlinesFramebuffer"},
            at = {@At("HEAD")},
            cancellable = true,
            require = 0)
    private void espCancelOutlineDraw(CallbackInfo callbackinfo) {
        ShaderESPModule shaderESPModule2 = ShaderESPModule.getInstance();
        if (shaderESPModule2 != null
                && shaderESPModule2.isEnabled()
                && !ShaderESPModule.trackedEntities().isEmpty()) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"render"},
            at = {@At("RETURN")})
    private void publishWorldRenderEvent(
            ObjectAllocator objectallocator,
            RenderTickCounter rendertickcounter,
            boolean flag,
            Camera camera,
            Matrix4f matrix4f,
            Matrix4f matrix4f1,
            Matrix4f matrix4f2,
            GpuBufferSlice gpubufferslice,
            Vector4f vector4f,
            boolean flag1,
            CallbackInfo callbackinfo) {
        MatrixStack matrixstack = new MatrixStack();
        Matrix4f matrix4f3 = new Matrix4f(matrix4f);
        matrixstack.multiplyPositionMatrix(new Matrix4f(matrix4f3));
        new Render3DEvent(matrixstack, rendertickcounter.getTickProgress(true)).hook();
        ShaderESPModule.getInstance().maskFramebuffer = this.entityOutlineFramebuffer;
        if (ShaderESPModule.getInstance().isEnabled()) {
            ShaderESPModule.getInstance().renderEffects();
        }

        ShaderSkyModule shaderSkyModule2 = ShaderSkyModule.getInstance();
        if (shaderSkyModule2 != null && shaderSkyModule2.isEnabled()) {
            ShaderSkyRenderer.getInstance().renderBlur();
        }
    }
}
