package dev.gooba.client.mixin;

import dev.gooba.client.BackgroundBlur;
import dev.gooba.client.CrosshairModule;
import dev.gooba.client.Gooba;
import dev.gooba.client.HUDModule;
import dev.gooba.client.HudDragManager;
import dev.gooba.client.HudManager;
import dev.gooba.client.NoRenderModule;
import dev.gooba.client.RadarModule;
import dev.gooba.client.Render2DEvent;
import dev.gooba.client.SpotifyHUDModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderTickCounter;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({InGameHud.class})
public abstract class InGameHudMixin {
    @Inject(
            method = {"renderScoreboardSidebar"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onRenderScoreboard(
            DrawContext drawcontext,
            RenderTickCounter rendertickcounter,
            CallbackInfo callbackinfo) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule != null
                && noRenderModule.isEnabled()
                && noRenderModule.removeScoreboardSetting.isOn()) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"render"},
            at = {@At("TAIL")})
    public void onRender(
            DrawContext drawcontext,
            RenderTickCounter rendertickcounter,
            CallbackInfo callbackinfo) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient.world != null) {
            HUDModule hUDModule = HUDModule.getInstance();
            SpotifyHUDModule spotifyHUDModule =
                    Gooba.getInstance().getModuleRegistry().findModule(SpotifyHUDModule.class);
            RadarModule radarModule =
                    Gooba.getInstance().getModuleRegistry().findModule(RadarModule.class);
            BackgroundBlur.update(
                    hUDModule != null && hUDModule.isEnabled()
                            || spotifyHUDModule != null && spotifyHUDModule.isEnabled()
                            || radarModule != null && radarModule.isEnabled());
            Screen screen = minecraftclient.currentScreen;
            if (!this.isLoadingScreen(screen)) {
                drawcontext.createNewRootLayer();
                HudManager.beginHudRender();
                drawcontext.getMatrices().pushMatrix();
                Render2DEvent render2DEvent =
                        new Render2DEvent(drawcontext, rendertickcounter.getTickProgress(false));
                Gooba.getInstance()
                        .getComponentManager()
                        .findComponent(HudDragManager.class)
                        .render(drawcontext.getMatrices());
                render2DEvent.hook();
                Gooba.getInstance().getHudManager().flush();
                drawcontext.getMatrices().popMatrix();
                HudManager.endHudRender();
            }
        }
    }

    @Inject(
            method = {"renderCrosshair"},
            at = {@At("HEAD")},
            cancellable = true)
    private void removeVanillaCrosshair(
            DrawContext drawcontext,
            RenderTickCounter rendertickcounter,
            CallbackInfo callbackinfo) {
        try {
            CrosshairModule crosshairModule = CrosshairModule.getInstance();
            if (crosshairModule.isEnabled()) {
                callbackinfo.cancel();
            }
        } catch (Exception exception) {
        }
    }

    @Inject(
            method = {"renderNauseaOverlay"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onRenderNauseaOverlay(
            DrawContext drawcontext, float f, CallbackInfo callbackinfo) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule != null
                && noRenderModule.isEnabled()
                && noRenderModule.removeNegativeEffectsSetting.isOn()) {
            callbackinfo.cancel();
        }
    }

    @Unique
    private boolean isLoadingScreen(Screen screen) {
        if (screen == null) {
            return false;
        } else {
            String text = screen.getClass().getSimpleName().toLowerCase();
            String textValue = screen.getClass().getName().toLowerCase();
            if (text.contains("loading")) {
                return true;
            } else if (text.contains("progress")) {
                return true;
            } else if (text.contains("connecting")) {
                return true;
            } else if (text.contains("downloading")) {
                return true;
            } else if (text.contains("terrain")) {
                return true;
            } else if (text.contains("generating")) {
                return true;
            } else if (text.contains("saving")) {
                return true;
            } else if (text.contains("reload")) {
                return true;
            } else if (text.contains("resource")) {
                return true;
            } else {
                return text.contains("pack") ? true : textValue.contains("mojang");
            }
        }
    }

    @Inject(
            method = {"renderBossBarHud"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onRenderBossBar(
            DrawContext drawcontext,
            RenderTickCounter rendertickcounter,
            CallbackInfo callbackinfo) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule != null
                && noRenderModule.isEnabled()
                && noRenderModule.removeBossBarSetting.isOn()) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"renderStatusEffectOverlay"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onRenderStatusEffectOverlay(
            DrawContext drawcontext,
            RenderTickCounter rendertickcounter,
            CallbackInfo callbackinfo) {
        callbackinfo.cancel();
    }
}
