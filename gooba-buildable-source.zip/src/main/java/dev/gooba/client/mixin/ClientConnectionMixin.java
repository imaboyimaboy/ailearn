package dev.gooba.client.mixin;

import dev.gooba.client.MinecraftAccess;
import dev.gooba.client.PacketEvent;
import dev.gooba.client.ScreenOpenEvent;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({ClientConnection.class})
public class ClientConnectionMixin {
    @Unique private static boolean stackOverflowFix;

    @Inject(
            method = {"handlePacket"},
            at = {@At("HEAD")},
            cancellable = true)
    private static <T extends PacketListener> void triggerReceivePacketEvent(
            Packet<T> packet, PacketListener packetlistener, CallbackInfo callbackinfo) {
        PacketEvent packetEvent = new PacketEvent(packet, PacketEvent.Type.RECEIVE);
        packetEvent.hook();
        if (packetEvent.isCancelled()) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"send"},
            at = {@At("HEAD")},
            cancellable = true)
    public void triggerSendPacketEvent(Packet<?> packet, CallbackInfo callbackinfo) {
        if (!stackOverflowFix) {
            PacketEvent packetEvent = new PacketEvent(packet, PacketEvent.Type.SEND);
            packetEvent.hook();
            if (packetEvent.isCancelled()) {
                callbackinfo.cancel();
            }

            Packet packetValue = packetEvent.getPacket();
            if (packetValue != packet) {
                callbackinfo.cancel();
                stackOverflowFix = true;
                MinecraftAccess.client.getNetworkHandler().sendPacket(packetValue);
                stackOverflowFix = false;
            }

            if (packet instanceof CloseHandledScreenC2SPacket closehandledscreenc2spacket) {
                MinecraftClient minecraftclient = MinecraftClient.getInstance();
                ScreenOpenEvent screenOpenEvent =
                        new ScreenOpenEvent(
                                minecraftclient.currentScreen,
                                closehandledscreenc2spacket.getSyncId());
                screenOpenEvent.hook();
                if (screenOpenEvent.isCancelled()) {
                    callbackinfo.cancel();
                }
            }
        }
    }
}
