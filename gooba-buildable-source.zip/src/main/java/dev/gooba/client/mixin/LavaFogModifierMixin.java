package dev.gooba.client.mixin;

import dev.gooba.client.NoRenderModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogData;
import net.minecraft.client.render.fog.LavaFogModifier;
import net.minecraft.client.world.ClientWorld;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({LavaFogModifier.class})
public class LavaFogModifierMixin {
    @Inject(
            method = {"applyStartEndModifier"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onApplyStartEnd(
            FogData fogdata,
            Camera camera,
            ClientWorld clientworld,
            float f,
            RenderTickCounter rendertickcounter,
            CallbackInfo callbackinfo) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule != null
                && noRenderModule.isEnabled()
                && noRenderModule.removeLavaFogSetting.isOn()) {
            fogdata.environmentalStart = Float.MAX_VALUE;
            fogdata.environmentalEnd = Float.MAX_VALUE;
            callbackinfo.cancel();
        }
    }
}
