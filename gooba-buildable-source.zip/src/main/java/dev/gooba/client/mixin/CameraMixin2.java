package dev.gooba.client.mixin;

import dev.gooba.client.FreecamModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({Camera.class})
public abstract class CameraMixin2 {

    @Shadow
    protected abstract float clipToSpace(float f);

    @Shadow
    protected abstract void setPos(double d0, double d1, double d2);

    @Inject(
            method = {"update"},
            at = {@At("TAIL")})
    private void onUpdate(
            World world,
            Entity entity,
            boolean flag,
            boolean flag1,
            float f,
            CallbackInfo callbackinfo) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FreecamModule freecamModule2 =
                    Gooba.getInstance().getModuleRegistry().findModule(FreecamModule.class);
            if (freecamModule2 != null && freecamModule2.isActive()) {
                this.setRotation(
                        freecamModule2.interpolatedYaw(f), freecamModule2.interpolatedPitch(f));
                this.setPos(freecamModule2.interpolatedPosition(f));
                if (freecamModule2.shouldShowOwnBody()) {}
            }
        }
    }

    @Shadow
    protected abstract void setRotation(float f, float f1);

    @Shadow
    protected abstract void setPos(Vec3d vec3d);

    @Shadow
    protected abstract void moveBy(float f, float f1, float f2);
}
