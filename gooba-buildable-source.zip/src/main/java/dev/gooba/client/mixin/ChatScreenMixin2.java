package dev.gooba.client.mixin;

import dev.gooba.client.Configs;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Collections;
import java.util.List;

@Environment(EnvType.CLIENT)
@Mixin({ChatScreen.class})
public class ChatScreenMixin2 {
    @Shadow protected TextFieldWidget chatField;

    @Unique private List<String> goobaa$suggestions = Collections.emptyList();
    @Unique private int goobaa$boxW;
    @Unique private int goobaa$boxCount;
    @Unique private int goobaa$selected = 0;
    @Unique private int goobaa$boxX;
    @Unique private int goobaa$boxY;

    @Inject(
            method = {"sendMessage"},
            at = {@At("HEAD")},
            cancellable = true)
    private void interceptMessage(String text, boolean flag, CallbackInfo callbackinfo)
            throws CloneNotSupportedException {
        if (!text.isEmpty()) {
            char prefix = Gooba.getInstance().getCommandManager().getPrefix();
            if (text.charAt(0) == prefix) {
                callbackinfo.cancel();
                Gooba.getInstance().getCommandManager().executeChatMessage(text);
            }
        }
    }

    @Inject(
            method = {"render"},
            at = {@At("TAIL")})
    private void goobaa$renderSuggestions(
            DrawContext drawcontext, int i, int j, float f, CallbackInfo callbackinfo) {
        this.goobaa$boxCount = 0;
        String text = this.chatField.getText();
        char prefix = Gooba.getInstance().getCommandManager().getPrefix();
        if (!text.isEmpty() && text.charAt(0) == prefix) {
            this.goobaa$suggestions = Gooba.getInstance().getCommandManager().suggest(text);
            if (!this.goobaa$suggestions.isEmpty()) {
                if (this.goobaa$selected >= this.goobaa$suggestions.size()) {
                    this.goobaa$selected = 0;
                }

                TextRenderer textrenderer = MinecraftClient.getInstance().textRenderer;
                int goobaa$boxCountValue = Math.min(this.goobaa$suggestions.size(), 10);
                int goobaa$boxWValue = 0;

                for (int i11 = 0; i11 < goobaa$boxCountValue; i11++) {
                    goobaa$boxWValue =
                            Math.max(
                                    goobaa$boxWValue,
                                    textrenderer.getWidth(this.goobaa$suggestions.get(i11)));
                }

                goobaa$boxWValue += 6;
                int j2 = goobaa$boxCountValue * 12;
                int goobaa$boxXValue = this.chatField.getX() - 2;
                int goobaa$boxYValue = this.chatField.getY() - j2 - 1;
                this.goobaa$boxX = goobaa$boxXValue;
                this.goobaa$boxY = goobaa$boxYValue;
                this.goobaa$boxW = goobaa$boxWValue;
                this.goobaa$boxCount = goobaa$boxCountValue;
                drawcontext.fill(
                        goobaa$boxXValue,
                        goobaa$boxYValue,
                        goobaa$boxXValue + goobaa$boxWValue,
                        goobaa$boxYValue + j2,
                        -436207616);
                drawcontext.fill(
                        goobaa$boxXValue,
                        goobaa$boxYValue,
                        goobaa$boxXValue + goobaa$boxWValue,
                        goobaa$boxYValue + 1,
                        1090519039);

                for (int l1 = 0; l1 < goobaa$boxCountValue; l1++) {
                    int i2 = goobaa$boxYValue + l1 * 12;
                    boolean flag = l1 == this.goobaa$selected;
                    if (flag) {
                        drawcontext.fill(
                                goobaa$boxXValue,
                                i2,
                                goobaa$boxXValue + goobaa$boxWValue,
                                i2 + 12,
                                1442840575);
                    }

                    drawcontext.drawText(
                            textrenderer,
                            this.goobaa$suggestions.get(l1),
                            goobaa$boxXValue + 3,
                            i2 + 2,
                            flag ? -171 : -4473925,
                            false);
                }
            }
        } else {
            this.goobaa$suggestions = Collections.emptyList();
        }
    }

    @Inject(
            method = {"keyPressed"},
            at = {@At("HEAD")},
            cancellable = true)
    private void goobaa$keyPressed(
            KeyInput keyinput, CallbackInfoReturnable<Boolean> callbackinforeturnable) {
        if (Configs.isListening()
                && keyinput.getKeycode() == 86
                && (keyinput.modifiers() & 2) != 0) {
            Configs.importClipboard();
            callbackinforeturnable.setReturnValue(true);
        } else if (!this.goobaa$suggestions.isEmpty()) {
            int count = this.goobaa$suggestions.size();
            switch (keyinput.getKeycode()) {
                case 258:
                    this.goobaa$apply(
                            this.goobaa$suggestions.get(Math.min(this.goobaa$selected, count - 1)));
                    callbackinforeturnable.setReturnValue(true);
                    break;
                case 264:
                    this.goobaa$selected = (this.goobaa$selected + 1) % count;
                    callbackinforeturnable.setReturnValue(true);
                    break;
                case 265:
                    this.goobaa$selected = (this.goobaa$selected - 1 + count) % count;
                    callbackinforeturnable.setReturnValue(true);
            }
        }
    }

    @Inject(
            method = {"mouseClicked"},
            at = {@At("HEAD")},
            cancellable = true)
    private void goobaa$mouseClicked(
            Click click, boolean flag, CallbackInfoReturnable<Boolean> callbackinforeturnable) {
        int i = click.button();
        double d0 = click.x();
        double d1 = click.y();
        if (!this.goobaa$suggestions.isEmpty() && this.goobaa$boxCount != 0 && i == 0) {
            if (d0 >= (double) this.goobaa$boxX
                    && d0 <= (double) (this.goobaa$boxX + this.goobaa$boxW)
                    && d1 >= (double) this.goobaa$boxY
                    && d1 <= (double) (this.goobaa$boxY + this.goobaa$boxCount * 12)) {
                int j = (int) ((d1 - (double) this.goobaa$boxY) / 12.0);
                if (j >= 0 && j < this.goobaa$boxCount && j < this.goobaa$suggestions.size()) {
                    this.goobaa$apply(this.goobaa$suggestions.get(j));
                    callbackinforeturnable.setReturnValue(true);
                }
            }
        }
    }

    @Unique
    private void goobaa$apply(String text) {
        this.chatField.setText(text);
        this.chatField.setCursorToEnd(false);
        this.goobaa$selected = 0;
    }
}
