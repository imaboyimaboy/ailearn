package dev.gooba.client.mixin;

import dev.gooba.client.FloatingHandsModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({HeldItemRenderer.class})
public class HeldItemRendererMixin2 {
    @Inject(
            method = {"renderFirstPersonItem"},
            at = {@At("HEAD")},
            require = 0)
    private void onRenderFirstPersonItem(
            AbstractClientPlayerEntity abstractclientplayerentity,
            float f,
            float f1,
            Hand hand,
            float f2,
            ItemStack itemstack,
            float f3,
            MatrixStack matrixstack,
            OrderedRenderCommandQueue orderedrendercommandqueue,
            int i,
            CallbackInfo callbackinfo) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FloatingHandsModule floatingHandsModule =
                    Gooba.getInstance().getModuleRegistry().findModule(FloatingHandsModule.class);
            if (floatingHandsModule != null && floatingHandsModule.isEnabled()) {
                if (hand == Hand.MAIN_HAND) {
                    matrixstack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-27.0F));
                    matrixstack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-5.0F));
                    matrixstack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(0.0F));
                    matrixstack.scale(1.7F, 1.4F, 1.5F);
                    matrixstack.translate(0.3F, 0.7F, -0.7F);
                } else {
                    matrixstack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(88.0F));
                    matrixstack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-63.0F));
                    matrixstack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(77.0F));
                    matrixstack.scale(3.4F, 3.7F, 2.3F);
                    matrixstack.translate(-0.5F, 0.8F, 2.4F);
                }
            }
        }
    }
}
