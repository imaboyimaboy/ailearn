package dev.gooba.client.mixin;

import dev.gooba.client.AttackEvent;
import dev.gooba.client.PlayerActionEvent;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.ActionResult.Success;
import net.minecraft.util.ActionResult.SwingSource;
import net.minecraft.util.Hand;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({ClientPlayerInteractionManager.class})
public class ClientPlayerInteractionManagerMixin {
    @Inject(
            method = {"stopUsingItem"},
            at = {@At("HEAD")},
            cancellable = true)
    public void stopUsingItemHook(CallbackInfo callbackinfo) {
        PlayerActionEvent playerActionEvent = new PlayerActionEvent((byte) 2);
        playerActionEvent.hook();
        if (playerActionEvent.isCancelled()) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"attackEntity"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onAttackEntity(
            PlayerEntity playerentity, Entity entity, CallbackInfo callbackinfo) {
        AttackEvent attackEvent = new AttackEvent(entity);
        attackEvent.hook();
        if (attackEvent.isCancelled()) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"interactItem"},
            at = {@At("RETURN")})
    public void interactItemHook(
            PlayerEntity playerentity,
            Hand hand,
            CallbackInfoReturnable<ActionResult> callbackinforeturnable) {
        if (callbackinforeturnable.getReturnValue() instanceof Success success
                && !success.swingSource().equals(SwingSource.CLIENT)) {
            PlayerActionEvent playerActionEvent = new PlayerActionEvent((byte) 0);
            playerActionEvent.hook();
        }
    }

    @Inject(
            method = {"interactItem"},
            at = {@At("HEAD")},
            cancellable = true)
    private void gameModeHook(
            PlayerEntity playerentity,
            Hand hand,
            CallbackInfoReturnable<ActionResult> callbackinforeturnable) {
        PlayerActionEvent playerActionEvent = new PlayerActionEvent((byte) -1);
        playerActionEvent.hook();
        if (playerActionEvent.isCancelled()) {
            callbackinforeturnable.setReturnValue(ActionResult.PASS);
        }
    }
}
