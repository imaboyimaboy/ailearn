package dev.gooba.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import dev.gooba.client.AutoTotemModule;
import dev.gooba.client.MovementInputEvent;
import dev.gooba.client.PlayerInputEvent;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({KeyboardInput.class})
public abstract class KeyboardInputMixin extends Input {
    @Shadow @Final private GameOptions settings;

    @Inject(
            method = {"tick"},
            at = {
                @At(
                        value = "FIELD",
                        target =
                                "Lnet/minecraft/client/input/KeyboardInput;playerInput:Lnet/minecraft/util/PlayerInput;",
                        ordinal = 0,
                        shift = Shift.AFTER)
            },
            cancellable = true)
    public void injectInputEvent(CallbackInfo callbackinfo) {
        MovementInputEvent movementInputEvent =
                new MovementInputEvent(
                        this.playerInput,
                        this.abobaGetMovementMultiplier(
                                this.playerInput.forward(), this.playerInput.backward()),
                        this.abobaGetMovementMultiplier(
                                this.playerInput.left(), this.playerInput.right()));
        movementInputEvent.hook();
        if (AutoTotemModule.isSwapPending()) {
            this.movementVector = new Vec2f(0.0F, 0.0F);
            this.playerInput = new PlayerInput(false, false, false, false, false, false, false);
            callbackinfo.cancel();
        } else if (!movementInputEvent.isCancelled()) {
            float forward = movementInputEvent.getForward();
            float strafe = movementInputEvent.getStrafe();
            this.movementVector = new Vec2f(strafe, forward).normalize();
            this.playerInput =
                    new PlayerInput(
                            forward > 0.0F,
                            forward < 0.0F,
                            strafe > 0.0F,
                            strafe < 0.0F,
                            this.settings.jumpKey.isPressed(),
                            this.settings.sneakKey.isPressed(),
                            this.settings.sprintKey.isPressed());
            callbackinfo.cancel();
        }
    }

    @Unique
    private float abobaGetMovementMultiplier(boolean flag, boolean flag1) {
        if (flag == flag1) {
            return 0.0F;
        } else {
            return flag ? 1.0F : -1.0F;
        }
    }

    @ModifyExpressionValue(
            method = {"tick"},
            at = {@At(value = "NEW", target = "(ZZZZZZZ)Lnet/minecraft/util/PlayerInput;")})
    private PlayerInput tickHook(PlayerInput playerinput) {
        PlayerInputEvent playerInputEvent = new PlayerInputEvent(playerinput);
        playerInputEvent.hook();
        return playerinput;
    }
}
