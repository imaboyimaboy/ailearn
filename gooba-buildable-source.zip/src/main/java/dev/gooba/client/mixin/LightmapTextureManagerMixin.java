package dev.gooba.client.mixin;

import dev.gooba.client.GammaModule;
import dev.gooba.client.Gooba;
import dev.gooba.client.NoRenderModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.LightmapTextureManager;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({LightmapTextureManager.class})
public class LightmapTextureManagerMixin {
    @Inject(
            method = {"getDarkness"},
            at = {@At("HEAD")},
            cancellable = true)
    private void removeDarknessEffect(CallbackInfoReturnable<Float> callbackinforeturnable) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule != null
                && noRenderModule.isEnabled()
                && noRenderModule.removeNegativeEffectsSetting.isOn()) {
            callbackinforeturnable.setReturnValue(0.0F);
        }
    }

    @Redirect(
            method = {"update"},
            at = @At(value = "INVOKE", target = "Ljava/lang/Double;floatValue()F", ordinal = 1))
    private float goobaa$getGammaValue(Double value) {
        if (Gooba.getInstance() != null) {
            GammaModule gammaModule =
                    Gooba.getInstance().getModuleRegistry().findModule(GammaModule.class);
            if (gammaModule != null && gammaModule.isEnabled()) {
                return 200.0F;
            }
        }

        return value.floatValue();
    }
}
