package dev.gooba.client.mixin;

import dev.gooba.client.FakeTiersModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityRenderer.class})
public class PlayerEntityRendererMixin2 {
    @Inject(
            method = {"updateRenderState"},
            at = {@At("TAIL")},
            require = 0)
    private void fakeTiersPlayerNames(
            PlayerLikeEntity playerlikeentity,
            PlayerEntityRenderState playerentityrenderstate,
            float f,
            CallbackInfo callbackinfo) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FakeTiersModule fakeTiersModule =
                    Gooba.getInstance().getModuleRegistry().findModule(FakeTiersModule.class);
            if (fakeTiersModule != null
                    && fakeTiersModule.isEnabled()
                    && fakeTiersModule.nametagsSetting.isOn()
                    && playerlikeentity != null) {
                String string = playerlikeentity.getName().getString();
                if (playerentityrenderstate.playerName != null) {
                    playerentityrenderstate.playerName =
                            fakeTiersModule.decorateNametag(
                                    playerentityrenderstate.playerName, string);
                }

                if (playerentityrenderstate.displayName != null) {
                    playerentityrenderstate.displayName =
                            fakeTiersModule.decorateNametag(
                                    playerentityrenderstate.displayName, string);
                }
            }
        }
    }
}
