package dev.gooba.client.mixin;

import com.mojang.authlib.GameProfile;

import dev.gooba.client.ActionEvent;
import dev.gooba.client.AutoTotemModule;
import dev.gooba.client.MinecraftAccess;
import dev.gooba.client.MoveEvent;
import dev.gooba.client.PlayerActionEvent;
import dev.gooba.client.PlayerMotionEvent;
import dev.gooba.client.PlayerTickEvent;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({ClientPlayerEntity.class})
public abstract class ClientPlayerEntityMixin extends AbstractClientPlayerEntity {
    @Shadow public float renderYaw;
    @Shadow public float renderPitch;
    @Shadow public float lastRenderYaw;
    @Shadow public float lastRenderPitch;

    @Inject(
            method = {"tick"},
            at = {@At("HEAD")})
    private void onTickHead(CallbackInfo callbackinfo) {
        new PlayerTickEvent().hook();
    }

    @Inject(
            method = {"move"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/network/AbstractClientPlayerEntity;move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V")
            },
            cancellable = true)
    public void onMoveHook(MovementType movementtype, Vec3d vec3d, CallbackInfo callbackinfo) {
        MoveEvent moveEvent = new MoveEvent(vec3d);
        moveEvent.hook();
        double d0 = this.getX();
        double d1 = this.getZ();
        super.move(movementtype, moveEvent.getMovement());
        this.autoJump((float) (this.getX() - d0), (float) (this.getZ() - d1));
        callbackinfo.cancel();
    }

    @Shadow
    @Override
    public abstract boolean isUsingItem();

    @Inject(
            method = {"sendMovementPackets"},
            at = {@At("HEAD")},
            cancellable = true)
    private void preMotion(CallbackInfo callbackinfo) {
        PlayerMotionEvent playerMotionEvent =
                new PlayerMotionEvent(
                        this.getX(),
                        this.getY(),
                        this.getZ(),
                        (double) this.getYaw(1.0F),
                        (double) this.getPitch(1.0F),
                        this.isOnGround());
        playerMotionEvent.hook();
        if (playerMotionEvent.isCancelled()) {
            callbackinfo.cancel();
        }
    }

    @Redirect(
            method = {"applyMovementSpeedFactors"},
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/util/math/Vec2f;multiply(F)Lnet/minecraft/util/math/Vec2f;",
                            ordinal = 1))
    private Vec2f cancelItemSlowdown(Vec2f vec2f, float f) {
        PlayerActionEvent playerActionEvent = new PlayerActionEvent((byte) 1);
        playerActionEvent.hook();
        return playerActionEvent.isCancelled() && this.isUsingItem() && !this.hasVehicle()
                ? vec2f.multiply(1.0F)
                : vec2f.multiply(f);
    }

    @ModifyVariable(
            method = {"sendSprintingPacket"},
            at = @At(value = "STORE", ordinal = 0),
            ordinal = 0)
    private boolean modifySprintingFlag(boolean flag) {
        ActionEvent actionEvent = new ActionEvent(flag);
        actionEvent.hook();
        return actionEvent.isSprintState();
    }

    @Shadow
    protected abstract void autoJump(float f, float f1);

    public ClientPlayerEntityMixin(ClientWorld clientworld, GameProfile gameprofile) {
        super(clientworld, gameprofile);
    }

    @Inject(
            method = {"tickMovementInput"},
            at = {@At("TAIL")})
    private void fixCameraRenderAngles(CallbackInfo callbackinfo) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient.player != null && minecraftclient.player == (Object) this) {
            Camera camera = minecraftclient.gameRenderer.getCamera();
            this.renderPitch =
                    this.lastRenderPitch + (camera.getPitch() - this.lastRenderPitch) * 0.5F;
            this.renderYaw = this.lastRenderYaw + (camera.getYaw() - this.lastRenderYaw) * 0.5F;
        }
    }

    @Inject(
            method = {"tickMovementInput"},
            at = {@At("HEAD")})
    private void prepareTotemMovement(CallbackInfo callbackinfo) {
        if (MinecraftAccess.client.player == (Object) this) {
            AutoTotemModule autoTotemModule2 = AutoTotemModule.getInstance();
            if (autoTotemModule2 != null) {
                autoTotemModule2.stopMovementForSwap();
            }
        }
    }
}
