package dev.gooba.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import dev.gooba.client.BetterTridentModule;
import dev.gooba.client.FakeLagModule;
import dev.gooba.client.Gooba;
import dev.gooba.client.HitboxesModule;
import dev.gooba.client.MinecraftAccess;
import dev.gooba.client.ShaderESPModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({Entity.class})
public class EntityMixin implements MinecraftAccess {
    @Inject(
            method = {"pushAwayFrom"},
            at = {@At("HEAD")},
            cancellable = true)
    private void cancelFakeLagPush(Entity entity, CallbackInfo callbackinfo) {
        Entity entityValue = (Entity) ((Entity) (Object) this);
        if (FakeLagModule.isGhost(entityValue) || FakeLagModule.isGhost(entity)) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"isTouchingWaterOrRain"},
            at = {@At("HEAD")},
            cancellable = true,
            require = 0)
    private void betterTridentWaterCheck(CallbackInfoReturnable<Boolean> callbackinforeturnable) {
        if ((Object) this == client.player
                && Gooba.getInstance() != null
                && Gooba.getInstance().getModuleRegistry() != null) {
            BetterTridentModule betterTridentModule =
                    Gooba.getInstance().getModuleRegistry().findModule(BetterTridentModule.class);
            if (betterTridentModule != null && betterTridentModule.isEnabled()) {
                callbackinforeturnable.setReturnValue(true);
            }
        }
    }

    @ModifyExpressionValue(
            method = {"move"},
            at = {
                @At(
                        value = "INVOKE",
                        target = "Lnet/minecraft/entity/Entity;isLogicalSideForUpdatingMovement()Z",
                        ordinal = 1)
            })
    public boolean fixFalldistanceValue(boolean flag) {
        return (Object) this == client.player ? true : flag;
    }

    @Inject(
            method = {"getTeamColorValue"},
            at = {@At("HEAD")},
            cancellable = true,
            require = 0)
    private void espFriendTeamColor(CallbackInfoReturnable<Integer> callbackinforeturnable) {
        ShaderESPModule shaderESPModule2 = ShaderESPModule.getInstance();
        if (shaderESPModule2 != null && shaderESPModule2.isEnabled()) {
            Entity entity = (Entity) ((Entity) (Object) this);
            if (entity instanceof PlayerEntity playerentity) {
                if (Gooba.getInstance()
                        .getFriendManager()
                        .isFriend(playerentity.getName().getString())) {
                    callbackinforeturnable.setReturnValue(5635925);
                }
            }
        }
    }

    @Inject(
            method = {"isGlowing"},
            at = {@At("RETURN")},
            cancellable = true)
    private void espMarkGlowing(CallbackInfoReturnable<Boolean> callbackinforeturnable) {
        if (!(Boolean) callbackinforeturnable.getReturnValue()) {
            ShaderESPModule shaderESPModule2 = ShaderESPModule.getInstance();
            if (shaderESPModule2 != null
                    && shaderESPModule2.isEnabled()
                    && ShaderESPModule.isTracked((Entity) ((Entity) (Object) this))) {
                callbackinforeturnable.setReturnValue(true);
            }
        }
    }

    @Inject(
            method = {"getTargetingMargin"},
            at = {@At("RETURN")},
            cancellable = true)
    private void client$getTargetingMargin(CallbackInfoReturnable<Float> callbackinforeturnable) {
        Entity entity = (Entity) ((Entity) (Object) this);
        if (entity instanceof PlayerEntity) {
            if (HitboxesModule.getInstance().isEnabled()) {
                if (entity instanceof PlayerEntity playerentity
                        && Gooba.getInstance()
                                .getFriendManager()
                                .isFriend(playerentity.getName().getString())) {
                    return;
                }

                float returnValue = (Float) callbackinforeturnable.getReturnValue();
                float f = HitboxesModule.getInstance().hitboxSizeSetting.getFloat();
                callbackinforeturnable.setReturnValue(returnValue + f);
            }
        }
    }
}
