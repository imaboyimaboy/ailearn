package dev.gooba.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import dev.gooba.client.XRayModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin({Block.class})
public class BlockMixin {
    @ModifyReturnValue(
            method = {"shouldDrawSide"},
            at = {@At("RETURN")})
    private static boolean goobaa$modifyDrawSide(
            boolean flag, BlockState blockstate, BlockState blockState, Direction direction) {
        XRayModule xRayModule2 = XRayModule.getInstance();
        return xRayModule2 != null && xRayModule2.isEnabled()
                ? !xRayModule2.shouldHide(blockstate.getBlock(), null) || flag
                : flag;
    }
}
