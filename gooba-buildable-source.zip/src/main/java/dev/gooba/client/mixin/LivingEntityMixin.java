package dev.gooba.client.mixin;

import dev.gooba.client.HandSwingEvent;
import dev.gooba.client.MathUtils;
import dev.gooba.client.MinecraftAccess;
import dev.gooba.client.NoDelayModule;
import dev.gooba.client.PlayerJumpEvent;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectUtil;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({LivingEntity.class})
public abstract class LivingEntityMixin implements MinecraftAccess {
    @Inject(
            method = {"getHandSwingDuration"},
            at = {@At("HEAD")},
            cancellable = true)
    private void swingProgressHook(CallbackInfoReturnable<Integer> callbackinforeturnable) {
        if ((Object) this == client.player) {
            HandSwingEvent handSwingEvent = new HandSwingEvent();
            handSwingEvent.hook();
            if (handSwingEvent.isCancelled()) {
                float animation = handSwingEvent.getAnimation();
                if (StatusEffectUtil.hasHaste(client.player)) {
                    animation *=
                            (float) (6 - (1 + StatusEffectUtil.getHasteAmplifier(client.player)));
                } else {
                    animation *=
                            (float)
                                    (this.hasStatusEffect(StatusEffects.MINING_FATIGUE)
                                            ? 6
                                                    + (1
                                                                    + this.getStatusEffect(
                                                                                    StatusEffects
                                                                                            .MINING_FATIGUE)
                                                                            .getAmplifier())
                                                            * 2
                                            : 6);
                }

                callbackinforeturnable.setReturnValue((int) animation);
            }
        }
    }

    @Shadow
    public abstract boolean hasStatusEffect(RegistryEntry<StatusEffect> registryentry);

    @Inject(
            method = {"jump"},
            at = {@At("HEAD")})
    public void jumpYo(CallbackInfo callbackinfo) {
        LivingEntity livingentity = (LivingEntity) ((LivingEntity) (Object) this);
        if (livingentity instanceof ClientPlayerEntity) {
            new PlayerJumpEvent().hook();
        }
    }

    @Shadow
    @Nullable
    public abstract StatusEffectInstance getStatusEffect(RegistryEntry<StatusEffect> registryentry);

    @ModifyConstant(
            method = {"tickMovement"},
            constant = {@Constant(intValue = 10)})
    private int modifyJumpTicks(int i) {
        LivingEntity livingentity = (LivingEntity) ((LivingEntity) (Object) this);
        if (livingentity instanceof ClientPlayerEntity) {
            NoDelayModule noDelayModule = NoDelayModule.getInstance();
            if (noDelayModule != null
                    && noDelayModule.isEnabled()
                    && noDelayModule.jumpDelaySetting.isOn()) {
                return MathUtils.randomIntInclusive(0, 3);
            }
        }

        return i;
    }
}
