package dev.gooba.client.mixin;

import dev.gooba.client.ItemScrollerModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({HandledScreen.class})
public abstract class HandledScreenMixin<T extends ScreenHandler> extends Screen {
    private long time = 0L;
    @Shadow @Nullable protected Slot focusedSlot;
    @Shadow @Final protected T handler;

    @Shadow
    protected abstract void onMouseClick(Slot slot, int i, int j, SlotActionType slotactiontype);

    @Unique
    private boolean hasShiftDown() {
        return InputUtil.isKeyPressed(MinecraftClient.getInstance().getWindow(), 340)
                || InputUtil.isKeyPressed(MinecraftClient.getInstance().getWindow(), 344);
    }

    @Inject(
            method = {"render"},
            at = {@At("HEAD")})
    private void onRender(CallbackInfo callbackinfo) {
        ItemScrollerModule itemScrollerModule = ItemScrollerModule.getInstance();
        if (this.client != null && itemScrollerModule.isEnabled()) {
            boolean hasShiftDown = this.hasShiftDown();
            if (GLFW.glfwGetMouseButton(this.client.getWindow().getHandle(), 0) == 1
                    && hasShiftDown
                    && this.focusedSlot != null
                    && this.focusedSlot.hasStack()
                    && (float) (System.currentTimeMillis() - this.time)
                            > itemScrollerModule.transferDelaySetting.getFloat()) {
                this.onMouseClick(
                        this.focusedSlot, this.focusedSlot.id, 0, SlotActionType.QUICK_MOVE);
                this.time = System.currentTimeMillis();
            }
        }
    }

    @Unique
    private boolean hasControlDown() {
        return InputUtil.isKeyPressed(MinecraftClient.getInstance().getWindow(), 341)
                || InputUtil.isKeyPressed(MinecraftClient.getInstance().getWindow(), 345);
    }

    protected HandledScreenMixin(Text text) {
        super(text);
    }

    @Inject(
            method = {"keyPressed"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onKeyPressed(
            KeyInput keyinput, CallbackInfoReturnable<Boolean> callbackinforeturnable) {
        if (this.client != null && this.client.player != null) {
            ItemScrollerModule itemScrollerModule = ItemScrollerModule.getInstance();
            if (itemScrollerModule != null && itemScrollerModule.isEnabled()) {
                if (this.client.options.dropKey.matchesKey(keyinput)
                        && this.hasControlDown()
                        && this.hasShiftDown()
                        && this.focusedSlot != null
                        && this.focusedSlot.hasStack()) {
                    ItemStack itemstack = this.focusedSlot.getStack();
                    Item item = itemstack.getItem();

                    for (Slot slot : this.handler.slots) {
                        if (slot.hasStack() && slot.getStack().getItem() == item) {
                            this.onMouseClick(slot, slot.id, 1, SlotActionType.THROW);
                        }
                    }

                    callbackinforeturnable.setReturnValue(true);
                    callbackinforeturnable.cancel();
                }
            }
        }
    }
}
