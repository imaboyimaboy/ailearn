package dev.gooba.client.mixin;

import dev.gooba.client.NoRenderModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({InGameOverlayRenderer.class})
public class InGameOverlayRendererMixin {
    @Inject(
            method = {"renderFireOverlay"},
            at = {@At("HEAD")},
            cancellable = true)
    private static void renderFireOverlayHook(
            MatrixStack matrixstack,
            VertexConsumerProvider vertexconsumerprovider,
            Sprite sprite,
            CallbackInfo callbackinfo) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule.isEnabled() && noRenderModule.removeFireOverlaySetting.isOn()) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"renderInWallOverlay"},
            at = {@At("HEAD")},
            cancellable = true)
    private static void renderInWallOverlayHook(
            Sprite sprite,
            MatrixStack matrixstack,
            VertexConsumerProvider vertexconsumerprovider,
            CallbackInfo callbackinfo) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule.isEnabled() && noRenderModule.removeNegativeEffectsSetting.isOn()) {
            callbackinfo.cancel();
        }
    }
}
