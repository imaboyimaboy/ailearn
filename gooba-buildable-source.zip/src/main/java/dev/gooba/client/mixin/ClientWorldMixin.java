package dev.gooba.client.mixin;

import dev.gooba.client.BlockUpdateEvent;
import dev.gooba.client.Gooba;
import dev.gooba.client.MinecraftAccess;
import dev.gooba.client.WorldLoadEvent;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.world.ClientWorld.Properties;
import net.minecraft.util.math.BlockPos;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({ClientWorld.class})
public class ClientWorldMixin implements MinecraftAccess {
    @Shadow @Final private Properties clientWorldProperties;

    @Inject(
            method = {"<init>"},
            at = {@At("RETURN")})
    public void initHook(CallbackInfo callbackinfo) {
        new WorldLoadEvent().hook();
    }

    @Inject(
            method = {"handleBlockUpdate"},
            at = {@At("HEAD")})
    private void onHandleBlockUpdate(
            BlockPos blockpos, BlockState blockstate, int i, CallbackInfo callbackinfo) {
        if (Gooba.getEventBus().isListening(BlockUpdateEvent.class)) {
            ClientWorld clientworld = (ClientWorld) ((ClientWorld) (Object) this);
            BlockState blockState = clientworld.getBlockState(blockpos);
            new BlockUpdateEvent(blockpos, blockstate, blockState).hook();
        }
    }
}
