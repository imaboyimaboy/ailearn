package dev.gooba.client.mixin;

import dev.gooba.client.Gooba;
import dev.gooba.client.SkinProtectModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.AssetInfo.TextureAssetInfo;
import net.minecraft.util.Identifier;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({AbstractClientPlayerEntity.class})
public abstract class AbstractClientPlayerEntityMixin {
    @Unique private static final Identifier CAPE_ID = Identifier.of("client", "cape");
    @Unique private static final TextureAssetInfo CAPE_ASSET = new TextureAssetInfo(CAPE_ID);

    @Inject(
            method = {"getSkin"},
            at = {@At("RETURN")},
            cancellable = true)
    private void replaceCape(CallbackInfoReturnable<SkinTextures> callbackinforeturnable) {
        AbstractClientPlayerEntity abstractclientplayerentity =
                (AbstractClientPlayerEntity) ((AbstractClientPlayerEntity) (Object) this);
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient.player != null) {
            SkinProtectModule skinProtectModule =
                    Gooba.getInstance().getModuleRegistry().findModule(SkinProtectModule.class);
            SkinTextures skintextures =
                    skinProtectModule == null
                            ? null
                            : skinProtectModule.getSkinTextures(abstractclientplayerentity);
            if (skintextures != null) {
                callbackinforeturnable.setReturnValue(skintextures);
            } else {
                boolean flag =
                        abstractclientplayerentity
                                .getUuid()
                                .equals(minecraftclient.player.getUuid());
                boolean isFriend =
                        Gooba.getInstance()
                                .getFriendManager()
                                .isFriend(abstractclientplayerentity.getName().getString());
                if (flag || isFriend) {
                    SkinTextures returnValue =
                            (SkinTextures) callbackinforeturnable.getReturnValue();
                    callbackinforeturnable.setReturnValue(
                            new SkinTextures(
                                    returnValue.body(),
                                    CAPE_ASSET,
                                    CAPE_ASSET,
                                    returnValue.model(),
                                    returnValue.secure()));
                }
            }
        }
    }
}
