package dev.gooba.client.mixin;

import dev.gooba.client.FreecamModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.GameRenderer;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Environment(EnvType.CLIENT)
@Mixin({GameRenderer.class})
public class GameRendererMixin3 {
    @ModifyArg(
            method = {"bobView"},
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionfc;)V"),
            require = 0)
    private Quaternionfc scaleBobRotation(Quaternionfc quaternionfc) {
        return new Quaternionf().slerp(quaternionfc, 0.25F);
    }

    @ModifyArgs(
            method = {"bobView"},
            at =
                    @At(
                            value = "INVOKE",
                            target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V"),
            require = 0)
    private void scaleBobTranslation(Args args) {
        args.set(0, args.<Float>get(0) * 0.25F);
        args.set(1, args.<Float>get(1) * 0.25F);
        args.set(2, args.<Float>get(2) * 0.25F);
    }

    @Inject(
            method = {"renderHand"},
            at = {@At("HEAD")},
            cancellable = true,
            require = 0)
    private void freecamHands(float f, boolean flag, Matrix4f matrix4f, CallbackInfo callbackinfo) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FreecamModule freecamModule2 =
                    Gooba.getInstance().getModuleRegistry().findModule(FreecamModule.class);
            if (freecamModule2 != null && !freecamModule2.shouldShowHands()) {
                callbackinfo.cancel();
            }
        }
    }

    @Inject(
            method = {"shouldRenderBlockOutline"},
            at = {@At("HEAD")},
            cancellable = true,
            require = 0)
    private void hideFreecamBlockOutline(CallbackInfoReturnable<Boolean> callbackinforeturnable) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FreecamModule freecamModule2 =
                    Gooba.getInstance().getModuleRegistry().findModule(FreecamModule.class);
            if (freecamModule2 != null && freecamModule2.isActive()) {
                callbackinforeturnable.setReturnValue(false);
            }
        }
    }

    @Redirect(
            method = {"renderHand"},
            at =
                    @At(
                            value = "INVOKE",
                            target = "Lnet/minecraft/client/option/Perspective;isFirstPerson()Z"),
            require = 0)
    private boolean freecamRenderHandInFirstPerson(Perspective perspective) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FreecamModule freecamModule2 =
                    Gooba.getInstance().getModuleRegistry().findModule(FreecamModule.class);
            return freecamModule2 != null && freecamModule2.isActive()
                    ? freecamModule2.shouldShowHands()
                    : perspective.isFirstPerson();
        } else {
            return perspective.isFirstPerson();
        }
    }
}
