package dev.gooba.client.mixin;

import dev.gooba.client.BlockOutlinesModule;
import dev.gooba.client.ColorUtils;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.state.OutlineRenderState;
import net.minecraft.client.render.state.WorldRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({WorldRenderer.class})
public class WorldRendererMixin2 {
    @Unique private static double goobaa$curMinX;
    @Unique private static double goobaa$curMaxX;
    @Unique private static double goobaa$curMaxY;
    @Unique private static long goobaa$lastFrameTime = 0L;
    @Unique private static double goobaa$curMaxZ;
    @Unique private static boolean goobaa$hasTarget = false;
    @Unique private static double goobaa$curMinZ;
    @Unique private static double goobaa$curMinY;

    @Inject(
            method = {"renderTargetBlockOutline"},
            at = {@At("HEAD")},
            cancellable = true)
    private void goobaa$renderTargetBlockOutline(
            Immediate immediate,
            MatrixStack matrixstack,
            boolean flag,
            WorldRenderState worldrenderstate,
            CallbackInfo callbackinfo) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            BlockOutlinesModule blockOutlinesModule =
                    Gooba.getInstance().getModuleRegistry().findModule(BlockOutlinesModule.class);
            if (blockOutlinesModule != null && blockOutlinesModule.isEnabled()) {
                callbackinfo.cancel();
                if (!flag) {
                    OutlineRenderState outlinerenderstate = worldrenderstate.outlineRenderState;
                    if (outlinerenderstate == null) {
                        goobaa$hasTarget = false;
                    } else {
                        Vec3d vec3d =
                                worldrenderstate.cameraRenderState != null
                                                && worldrenderstate.cameraRenderState.pos != null
                                        ? worldrenderstate.cameraRenderState.pos
                                        : Vec3d.ZERO;
                        BlockPos blockpos = outlinerenderstate.pos();
                        VoxelShape voxelshape = outlinerenderstate.shape();
                        Box box =
                                voxelshape.isEmpty()
                                        ? new Box(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
                                        : voxelshape.getBoundingBox();
                        double goobaa$curMinXValue = (double) blockpos.getX() + box.minX;
                        double goobaa$curMinYValue = (double) blockpos.getY() + box.minY;
                        double goobaa$curMinZValue = (double) blockpos.getZ() + box.minZ;
                        double goobaa$curMaxXValue = (double) blockpos.getX() + box.maxX;
                        double goobaa$curMaxYValue = (double) blockpos.getY() + box.maxY;
                        double goobaa$curMaxZValue = (double) blockpos.getZ() + box.maxZ;
                        long nowMillis = System.currentTimeMillis();
                        if (goobaa$lastFrameTime == 0L) {
                            goobaa$lastFrameTime = nowMillis;
                        }

                        float f = (float) (nowMillis - goobaa$lastFrameTime) / 1000.0F;
                        goobaa$lastFrameTime = nowMillis;
                        if (f < 0.0F || f > 0.1F) {
                            f = 0.016F;
                        }

                        if (!goobaa$hasTarget) {
                            goobaa$curMinX = goobaa$curMinXValue;
                            goobaa$curMinY = goobaa$curMinYValue;
                            goobaa$curMinZ = goobaa$curMinZValue;
                            goobaa$curMaxX = goobaa$curMaxXValue;
                            goobaa$curMaxY = goobaa$curMaxYValue;
                            goobaa$curMaxZ = goobaa$curMaxZValue;
                            goobaa$hasTarget = true;
                        }

                        float f1 = blockOutlinesModule.transitionSpeedSetting.getFloat();
                        if (blockOutlinesModule.transitionsSetting.isOn()) {
                            float f2 = 1.0F - (float) Math.exp((double) (-f1 * f));
                            double d6 =
                                    Math.pow(goobaa$curMinXValue - goobaa$curMinX, 2.0)
                                            + Math.pow(goobaa$curMinYValue - goobaa$curMinY, 2.0)
                                            + Math.pow(goobaa$curMinZValue - goobaa$curMinZ, 2.0);
                            if (d6 > 1600.0) {
                                goobaa$curMinX = goobaa$curMinXValue;
                                goobaa$curMinY = goobaa$curMinYValue;
                                goobaa$curMinZ = goobaa$curMinZValue;
                                goobaa$curMaxX = goobaa$curMaxXValue;
                                goobaa$curMaxY = goobaa$curMaxYValue;
                                goobaa$curMaxZ = goobaa$curMaxZValue;
                            } else {
                                goobaa$curMinX =
                                        goobaa$curMinX
                                                + (goobaa$curMinXValue - goobaa$curMinX)
                                                        * (double) f2;
                                goobaa$curMinY =
                                        goobaa$curMinY
                                                + (goobaa$curMinYValue - goobaa$curMinY)
                                                        * (double) f2;
                                goobaa$curMinZ =
                                        goobaa$curMinZ
                                                + (goobaa$curMinZValue - goobaa$curMinZ)
                                                        * (double) f2;
                                goobaa$curMaxX =
                                        goobaa$curMaxX
                                                + (goobaa$curMaxXValue - goobaa$curMaxX)
                                                        * (double) f2;
                                goobaa$curMaxY =
                                        goobaa$curMaxY
                                                + (goobaa$curMaxYValue - goobaa$curMaxY)
                                                        * (double) f2;
                                goobaa$curMaxZ =
                                        goobaa$curMaxZ
                                                + (goobaa$curMaxZValue - goobaa$curMaxZ)
                                                        * (double) f2;
                            }
                        } else {
                            goobaa$curMinX = goobaa$curMinXValue;
                            goobaa$curMinY = goobaa$curMinYValue;
                            goobaa$curMinZ = goobaa$curMinZValue;
                            goobaa$curMaxX = goobaa$curMaxXValue;
                            goobaa$curMaxY = goobaa$curMaxYValue;
                            goobaa$curMaxZ = goobaa$curMaxZValue;
                        }

                        float f3 = blockOutlinesModule.alphaSetting.getFloat();
                        float f4 = blockOutlinesModule.lineWidthSetting.getFloat();
                        VertexConsumer vertexconsumer =
                                immediate.getBuffer(RenderLayers.secondaryBlockOutline());
                        Entry entry = matrixstack.peek();
                        double d7 = vec3d.x;
                        double d8 = vec3d.y;
                        double d9 = vec3d.z;
                        if (blockOutlinesModule.transitionsSetting.isOn()) {
                            double d10 = goobaa$curMinX - d7;
                            double d11 = goobaa$curMinY - d8;
                            double d12 = goobaa$curMinZ - d9;
                            double d13 = goobaa$curMaxX - d7;
                            double d14 = goobaa$curMaxY - d8;
                            double d15 = goobaa$curMaxZ - d9;
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d10,
                                    d11,
                                    d12,
                                    d13,
                                    d11,
                                    d12,
                                    goobaa$curMinX,
                                    goobaa$curMinY,
                                    goobaa$curMinZ,
                                    goobaa$curMaxX,
                                    goobaa$curMinY,
                                    goobaa$curMinZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d13,
                                    d11,
                                    d12,
                                    d13,
                                    d11,
                                    d15,
                                    goobaa$curMaxX,
                                    goobaa$curMinY,
                                    goobaa$curMinZ,
                                    goobaa$curMaxX,
                                    goobaa$curMinY,
                                    goobaa$curMaxZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d13,
                                    d11,
                                    d15,
                                    d10,
                                    d11,
                                    d15,
                                    goobaa$curMaxX,
                                    goobaa$curMinY,
                                    goobaa$curMaxZ,
                                    goobaa$curMinX,
                                    goobaa$curMinY,
                                    goobaa$curMaxZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d10,
                                    d11,
                                    d15,
                                    d10,
                                    d11,
                                    d12,
                                    goobaa$curMinX,
                                    goobaa$curMinY,
                                    goobaa$curMaxZ,
                                    goobaa$curMinX,
                                    goobaa$curMinY,
                                    goobaa$curMinZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d10,
                                    d14,
                                    d12,
                                    d13,
                                    d14,
                                    d12,
                                    goobaa$curMinX,
                                    goobaa$curMaxY,
                                    goobaa$curMinZ,
                                    goobaa$curMaxX,
                                    goobaa$curMaxY,
                                    goobaa$curMinZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d13,
                                    d14,
                                    d12,
                                    d13,
                                    d14,
                                    d15,
                                    goobaa$curMaxX,
                                    goobaa$curMaxY,
                                    goobaa$curMinZ,
                                    goobaa$curMaxX,
                                    goobaa$curMaxY,
                                    goobaa$curMaxZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d13,
                                    d14,
                                    d15,
                                    d10,
                                    d14,
                                    d15,
                                    goobaa$curMaxX,
                                    goobaa$curMaxY,
                                    goobaa$curMaxZ,
                                    goobaa$curMinX,
                                    goobaa$curMaxY,
                                    goobaa$curMaxZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d10,
                                    d14,
                                    d15,
                                    d10,
                                    d14,
                                    d12,
                                    goobaa$curMinX,
                                    goobaa$curMaxY,
                                    goobaa$curMaxZ,
                                    goobaa$curMinX,
                                    goobaa$curMaxY,
                                    goobaa$curMinZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d10,
                                    d11,
                                    d12,
                                    d10,
                                    d14,
                                    d12,
                                    goobaa$curMinX,
                                    goobaa$curMinY,
                                    goobaa$curMinZ,
                                    goobaa$curMinX,
                                    goobaa$curMaxY,
                                    goobaa$curMinZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d13,
                                    d11,
                                    d12,
                                    d13,
                                    d14,
                                    d12,
                                    goobaa$curMaxX,
                                    goobaa$curMinY,
                                    goobaa$curMinZ,
                                    goobaa$curMaxX,
                                    goobaa$curMaxY,
                                    goobaa$curMinZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d13,
                                    d11,
                                    d15,
                                    d13,
                                    d14,
                                    d15,
                                    goobaa$curMaxX,
                                    goobaa$curMinY,
                                    goobaa$curMaxZ,
                                    goobaa$curMaxX,
                                    goobaa$curMaxY,
                                    goobaa$curMaxZ,
                                    f4,
                                    f3);
                            goobaa$drawEdge(
                                    vertexconsumer,
                                    entry,
                                    d10,
                                    d11,
                                    d15,
                                    d10,
                                    d14,
                                    d15,
                                    goobaa$curMinX,
                                    goobaa$curMinY,
                                    goobaa$curMaxZ,
                                    goobaa$curMinX,
                                    goobaa$curMaxY,
                                    goobaa$curMaxZ,
                                    f4,
                                    f3);
                        } else {
                            double d16 = (double) blockpos.getX() - d7;
                            double d17 = (double) blockpos.getY() - d8;
                            double d18 = (double) blockpos.getZ() - d9;
                            outlinerenderstate
                                    .shape()
                                    .forEachEdge(
                                            (d3x, d4x, d5x, d6x, d7x, d8x) ->
                                                    goobaa$drawEdge(
                                                            vertexconsumer,
                                                            entry,
                                                            d3x + d16,
                                                            d4x + d17,
                                                            d5x + d18,
                                                            d6x + d16,
                                                            d7x + d17,
                                                            d8x + d18,
                                                            (double) blockpos.getX() + d3x,
                                                            (double) blockpos.getY() + d4x,
                                                            (double) blockpos.getZ() + d5x,
                                                            (double) blockpos.getX() + d6x,
                                                            (double) blockpos.getY() + d7x,
                                                            (double) blockpos.getZ() + d8x,
                                                            f4,
                                                            f3));
                        }

                        immediate.draw(RenderLayers.secondaryBlockOutline());
                    }
                }
            }
        }
    }

    @Unique
    private static void goobaa$drawEdge(
            VertexConsumer vertexconsumer,
            Entry entry,
            double d0,
            double d1,
            double d2,
            double d3,
            double d4,
            double d5,
            double d6,
            double d7,
            double d8,
            double d9,
            double d10,
            double d11,
            float f,
            float f1) {
        float f2 = (float) (d3 - d0);
        float f3 = (float) (d4 - d1);
        float f4 = (float) (d5 - d2);
        float f5 = (float) Math.sqrt((double) (f2 * f2 + f3 * f3 + f4 * f4));
        if (f5 != 0.0F) {
            f2 /= f5;
            f3 /= f5;
            f4 /= f5;
        }

        int i = ColorUtils.animatedAccent((int) ((d6 + d7 + d8) * 30.0));
        float f6 = (float) (i >> 16 & 0xFF) / 255.0F;
        float f7 = (float) (i >> 8 & 0xFF) / 255.0F;
        float f8 = (float) (i & 0xFF) / 255.0F;
        int j = ColorUtils.animatedAccent((int) ((d9 + d10 + d11) * 30.0));
        float f9 = (float) (j >> 16 & 0xFF) / 255.0F;
        float f10 = (float) (j >> 8 & 0xFF) / 255.0F;
        float f11 = (float) (j & 0xFF) / 255.0F;
        vertexconsumer
                .vertex(entry, (float) d0, (float) d1, (float) d2)
                .color(f6, f7, f8, f1)
                .normal(entry, f2, f3, f4)
                .lineWidth(f);
        vertexconsumer
                .vertex(entry, (float) d3, (float) d4, (float) d5)
                .color(f9, f10, f11, f1)
                .normal(entry, f2, f3, f4)
                .lineWidth(f);
    }
}
