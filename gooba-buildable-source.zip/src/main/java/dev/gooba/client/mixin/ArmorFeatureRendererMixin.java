package dev.gooba.client.mixin;

import dev.gooba.client.CustomModelState;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({ArmorFeatureRenderer.class})
public class ArmorFeatureRendererMixin {
    @Inject(
            method = {"render"},
            at = {@At("HEAD")},
            cancellable = true)
    private void goobaa$hideArmorForCustomModels(
            MatrixStack matrixstack,
            OrderedRenderCommandQueue orderedrendercommandqueue,
            int i,
            BipedEntityRenderState bipedentityrenderstate,
            float f,
            float f1,
            CallbackInfo callbackinfo) {
        if (bipedentityrenderstate instanceof CustomModelState customModelState
                && customModelState.goobaa$hasCustomModel()) {
            callbackinfo.cancel();
        }
    }
}
