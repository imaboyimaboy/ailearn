package dev.gooba.client.mixin;

import dev.gooba.client.NoRenderModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.render.fog.StatusEffectFogModifier;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({StatusEffectFogModifier.class})
public abstract class StatusEffectFogModifierMixin {
    @Inject(
            method = {"shouldApply"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onShouldApply(
            @Nullable CameraSubmersionType camerasubmersiontype,
            Entity entity,
            CallbackInfoReturnable<Boolean> callbackinforeturnable) {
        NoRenderModule noRenderModule = NoRenderModule.getInstance();
        if (noRenderModule.isEnabled()) {
            RegistryEntry registryentry = this.getStatusEffect();
            if (noRenderModule.removeNegativeEffectsSetting.isOn()
                    && registryentry == StatusEffects.BLINDNESS) {
                callbackinforeturnable.setReturnValue(false);
            }

            if (noRenderModule.removeNegativeEffectsSetting.isOn()
                    && registryentry == StatusEffects.DARKNESS) {
                callbackinforeturnable.setReturnValue(false);
            }
        }
    }

    @Shadow
    public abstract RegistryEntry<StatusEffect> getStatusEffect();
}
