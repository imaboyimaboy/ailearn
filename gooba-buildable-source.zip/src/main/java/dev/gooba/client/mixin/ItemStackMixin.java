package dev.gooba.client.mixin;

import dev.gooba.client.AutoCrystalModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({ItemStack.class})
public class ItemStackMixin {
    @Inject(
            method = {"getBobbingAnimationTime"},
            at = {@At("HEAD")},
            cancellable = true)
    private void removeCrystalBounce(CallbackInfoReturnable<Integer> callbackinforeturnable) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            AutoCrystalModule autoCrystalModule =
                    Gooba.getInstance().getModuleRegistry().findModule(AutoCrystalModule.class);
            if (autoCrystalModule != null && autoCrystalModule.shouldRemoveBounce()) {
                ItemStack itemstack = (ItemStack) ((ItemStack) (Object) this);
                if (itemstack.isOf(Items.END_CRYSTAL)) {
                    callbackinforeturnable.setReturnValue(0);
                }
            }
        }
    }
}
