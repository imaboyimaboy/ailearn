package dev.gooba.client.mixin;

import dev.gooba.client.EditorManager;
import dev.gooba.client.FreecamModule;
import dev.gooba.client.Gooba;
import dev.gooba.client.KeyPressEvent;
import dev.gooba.client.MouseButtonEvent;
import dev.gooba.client.MouseReleaseEvent;
import dev.gooba.client.MouseRotationEvent;
import dev.gooba.client.MouseScrollEvent;
import dev.gooba.client.OverlayEditor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.MouseInput;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Environment(EnvType.CLIENT)
@Mixin({Mouse.class})
public class MouseMixin {
    @Shadow @Final private MinecraftClient client;

    @Unique
    private float editorMouseX(double d0) {
        float f = 2.0F / (float) this.client.getWindow().getScaleFactor();
        return (float) (Mouse.scaleX(this.client.getWindow(), d0) / (double) f);
    }

    @Unique
    private float editorMouseY(double d0) {
        float f = 2.0F / (float) this.client.getWindow().getScaleFactor();
        return (float) (Mouse.scaleY(this.client.getWindow(), d0) / (double) f);
    }

    @Inject(
            method = {"onCursorPos"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onFreecamCursorPos(
            long i, double lastMouseXValue, double lastMouseYValue, CallbackInfo callbackinfo) {
        if (this.client.currentScreen == null) {
            if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
                FreecamModule freecamModule2 =
                        Gooba.getInstance().getModuleRegistry().findModule(FreecamModule.class);
                if (freecamModule2 != null && freecamModule2.isActive()) {
                    freecamModule2.onMousePosition(lastMouseXValue, lastMouseYValue);
                    callbackinfo.cancel();
                }
            }
        }
    }

    @Inject(
            method = {"onMouseButton"},
            at = {@At("HEAD")})
    private void onMouseButton(long i, MouseInput mouseinput, int j, CallbackInfo callbackinfo) {
        OverlayEditor overlayEditor = EditorManager.getActiveEditor();
        if (overlayEditor != null && (j == 1 || j == 0)) {
            overlayEditor.handleMouseButton(
                    this.editorMouseX(this.client.mouse.getX()),
                    this.editorMouseY(this.client.mouse.getY()),
                    mouseinput.button(),
                    j == 1);
        }

        if (j == 1 && this.client.currentScreen == null
                || j == 1 && this.client.currentScreen instanceof ChatScreen) {
            KeyPressEvent keyPressEvent = new KeyPressEvent(mouseinput.getKeycode());
            keyPressEvent.hook();
        }

        if (j == 1 && this.client.currentScreen == null
                || j == 1 && this.client.currentScreen instanceof ChatScreen) {
            double d5 = this.client.mouse.getX();
            double d1 = this.client.mouse.getY();
            double d3 =
                    d5
                            * (double) this.client.getWindow().getScaledWidth()
                            / (double) this.client.getWindow().getWidth();
            double d4 =
                    d1
                            * (double) this.client.getWindow().getScaledHeight()
                            / (double) this.client.getWindow().getHeight();
            Screen screen = this.client.currentScreen;
            MouseButtonEvent mouseButtonEvent =
                    new MouseButtonEvent(
                            mouseinput.button(), j, mouseinput.modifiers(), screen, d3, d4);
            mouseButtonEvent.hook();
        }

        if (j == 0) {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (minecraftclient.currentScreen != null) {
                double d0 =
                        minecraftclient.mouse.getX()
                                * (double) minecraftclient.getWindow().getScaledWidth()
                                / (double) minecraftclient.getWindow().getWidth();
                double d2 =
                        minecraftclient.mouse.getY()
                                * (double) minecraftclient.getWindow().getScaledHeight()
                                / (double) minecraftclient.getWindow().getHeight();
                new MouseReleaseEvent(d0, d2, mouseinput.button(), minecraftclient.currentScreen)
                        .hook();
            }
        }
    }

    @Inject(
            method = {"onCursorPos"},
            at = {@At("TAIL")})
    private void onEditorCursorPos(long i, double d0, double d1, CallbackInfo callbackinfo) {
        OverlayEditor overlayEditor = EditorManager.getActiveEditor();
        if (overlayEditor != null) {
            overlayEditor.handleMouseMove(this.editorMouseX(d0), this.editorMouseY(d1));
        }
    }

    @Inject(
            method = {"onMouseScroll"},
            at = {@At("HEAD")},
            cancellable = true)
    private void onMouseScroll(long i, double d0, double d1, CallbackInfo callbackinfo) {
        if (this.client.currentScreen == null
                && d1 != 0.0
                && Gooba.getInstance() != null
                && Gooba.getInstance().getModuleRegistry() != null) {
            FreecamModule freecamModule2 =
                    Gooba.getInstance().getModuleRegistry().findModule(FreecamModule.class);
            if (freecamModule2 != null && freecamModule2.isActive()) {
                freecamModule2.adjustSpeed(d1);
                callbackinfo.cancel();
                return;
            }
        }

        if (this.client.currentScreen == null && d1 != 0.0) {
            MouseScrollEvent mouseScrollEvent = new MouseScrollEvent(d0, d1);
            mouseScrollEvent.hook();
            if (mouseScrollEvent.isCancelled()) {
                callbackinfo.cancel();
            }
        }
    }

    @Inject(
            method = {"updateMouse"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V")
            },
            locals = LocalCapture.CAPTURE_FAILHARD,
            cancellable = true)
    private void onLook(double d0, CallbackInfo callbackinfo, double d1, double d2) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient != null && minecraftclient.player != null) {
            MouseRotationEvent mouseRotationEvent = new MouseRotationEvent(d1, d2);
            mouseRotationEvent.hook();
            if (!mouseRotationEvent.isCancelled()) {
                minecraftclient.player.changeLookDirection(
                        mouseRotationEvent.yaw, mouseRotationEvent.pitch);
            }

            callbackinfo.cancel();
        }
    }
}
