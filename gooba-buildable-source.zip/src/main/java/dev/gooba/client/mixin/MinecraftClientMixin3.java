package dev.gooba.client.mixin;

import dev.gooba.client.ClientTickEvent;
import dev.gooba.client.Gooba;
import dev.gooba.client.MouseSimulator;
import dev.gooba.client.PreClientTickEvent;
import dev.gooba.client.WindowAppearance;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({MinecraftClient.class})
public class MinecraftClientMixin3 {
    @Inject(
            method = {"onResolutionChanged"},
            at = {@At("TAIL")})
    private void applyDarkMode(CallbackInfo callbackinfo) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        WindowAppearance.enableDarkTitleBar(minecraftclient.getWindow().getHandle());
    }

    @Inject(
            method = {"doItemUse"},
            at = {@At("HEAD")},
            cancellable = true)
    private void consumeSimulatedUse(CallbackInfo callbackinfo) {
        if (MouseSimulator.isUseSuppressed() || MouseSimulator.consumePress(1)) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"tick"},
            at = {@At("TAIL")})
    private void publishClientTick(CallbackInfo callbackinfo) {
        MinecraftClient minecraftclient = (MinecraftClient) ((MinecraftClient) (Object) this);
        if (!minecraftclient.isPaused()) {
            ClientPlayerEntity clientplayerentity = minecraftclient.player;
            ClientWorld clientworld = minecraftclient.world;
            if (clientplayerentity != null && clientworld != null) {
                Gooba.getEventBus().post(new ClientTickEvent());
            }
        }
    }

    @Inject(
            method = {"getWindowTitle"},
            at = {@At("RETURN")},
            cancellable = true)
    private void getWindowTitle(CallbackInfoReturnable<String> callbackinforeturnable) {
        callbackinforeturnable.setReturnValue("Minecraft 1.21.11");
    }

    @Inject(
            method = {"handleBlockBreaking"},
            at = {@At("HEAD")},
            cancellable = true)
    private void consumeSimulatedBlockAttack(boolean flag, CallbackInfo callbackinfo) {
        if (MouseSimulator.consumePress(0)) {
            callbackinfo.cancel();
        }
    }

    @Inject(
            method = {"tick"},
            at = {@At("HEAD")})
    private void publishPreClientTick(CallbackInfo callbackinfo) {
        MinecraftClient minecraftclient = (MinecraftClient) ((MinecraftClient) (Object) this);
        if (!minecraftclient.isPaused()
                && minecraftclient.player != null
                && minecraftclient.world != null) {
            Gooba.getEventBus().post(new PreClientTickEvent());
        }
    }

    @Inject(
            method = {"doAttack"},
            at = {@At("HEAD")},
            cancellable = true)
    private void consumeSimulatedAttack(CallbackInfoReturnable<Boolean> callbackinforeturnable) {
        if (MouseSimulator.consumePress(0)) {
            callbackinforeturnable.setReturnValue(false);
        }
    }
}
