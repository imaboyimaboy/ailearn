package dev.gooba.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import dev.gooba.client.FirstPersonItemEvent;
import dev.gooba.client.HandEditor;
import dev.gooba.client.HandMatrixEvent;
import dev.gooba.client.HandRenderPhaseEvent;
import dev.gooba.client.HandsModule;
import dev.gooba.client.NoRenderModule;
import dev.gooba.client.ShaderHandModule;
import dev.gooba.client.SwingAnimationModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({HeldItemRenderer.class})
public abstract class HeldItemRendererMixin {
    @WrapWithCondition(
            method = {"renderFirstPersonItem"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/render/item/HeldItemRenderer;applyEquipOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V",
                        ordinal = 4)
            })
    private boolean cancelEquipOffsetForCustomAnim(
            HeldItemRenderer helditemrenderer, MatrixStack matrixstack, Arm arm, float f) {
        SwingAnimationModule swingAnimationModule = SwingAnimationModule.getInstance();
        return swingAnimationModule != null
                        && swingAnimationModule.isEnabled()
                        && swingAnimationModule.shouldAnimate()
                ? swingAnimationModule.animationModeSetting.isSelected("Disabled")
                : true;
    }

    @Inject(
            method = {"renderFirstPersonItem"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
                        ordinal = 0)
            })
    public void injectBeforeRenderCrossBowItem(
            AbstractClientPlayerEntity abstractclientplayerentity,
            float f,
            float f1,
            Hand hand,
            float f2,
            ItemStack itemstack,
            float f3,
            MatrixStack matrixstack,
            OrderedRenderCommandQueue orderedrendercommandqueue,
            int i,
            CallbackInfo callbackinfo) {
        HandsModule handsModule = HandsModule.getInstance();
        if (handsModule.isActive()) {
            boolean flag = hand == Hand.MAIN_HAND;
            Arm arm =
                    flag
                            ? abstractclientplayerentity.getMainArm()
                            : abstractclientplayerentity.getMainArm().getOpposite();
            handsModule.applyScale(matrixstack, arm);
            HandEditor.getInstance().updateProjectedBounds(arm, matrixstack);
        }
    }

    @WrapWithCondition(
            method = {"renderMapInOneHand"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionfc;)V",
                        ordinal = 1)
            })
    private boolean cancelMapRotationX(MatrixStack matrixstack, Quaternionfc quaternionfc) {
        return false;
    }

    @Inject(
            method = {
                "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"
            },
            at = {@At("HEAD")})
    private void onRenderItemPre(
            float f,
            MatrixStack matrixstack,
            OrderedRenderCommandQueue orderedrendercommandqueue,
            ClientPlayerEntity clientplayerentity,
            int i,
            CallbackInfo callbackinfo) {
        HandEditor handEditor2 = HandEditor.getInstance();
        if (handEditor2.isActive()) {
            handEditor2.beforeHandRender();
        } else {
            ShaderHandModule shaderHandModule2 = ShaderHandModule.getInstance();
            if (shaderHandModule2 != null && shaderHandModule2.isEnabled()) {
                new HandRenderPhaseEvent(HandRenderPhaseEvent.Phase.PRE, matrixstack, f).hook();
            }
        }
    }

    @WrapOperation(
            method = {
                "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"
            },
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionfc;)V",
                        ordinal = 0)
            },
            slice = {
                @Slice(
                        from =
                                @At(
                                        value = "INVOKE",
                                        target =
                                                "Lnet/minecraft/client/render/item/HeldItemRenderer;getHandRenderType(Lnet/minecraft/client/network/ClientPlayerEntity;)Lnet/minecraft/client/render/item/HeldItemRenderer$HandRenderType;"),
                        to =
                                @At(
                                        value = "FIELD",
                                        target =
                                                "Lnet/minecraft/client/render/item/HeldItemRenderer$HandRenderType;renderMainHand:Z"))
            })
    private void replacePitchRotation(
            MatrixStack matrixstack,
            Quaternionfc quaternionfc,
            Operation<Void> operation,
            @Local(ordinal = 3) float f) {
        if (!NoRenderModule.getInstance().removeCameraShakeSetting.isOn()) {
            float pitch = MinecraftClient.getInstance().gameRenderer.getCamera().getPitch();
            matrixstack.multiply(RotationAxis.POSITIVE_X.rotationDegrees((pitch - f) * 0.1F));
        }
    }

    @Inject(
            method = {
                "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"
            },
            at = {@At("TAIL")})
    private void onRenderItemPost(
            float f,
            MatrixStack matrixstack,
            OrderedRenderCommandQueue orderedrendercommandqueue,
            ClientPlayerEntity clientplayerentity,
            int i,
            CallbackInfo callbackinfo) {
        if (!HandEditor.getInstance().isActive()) {
            ShaderHandModule shaderHandModule2 = ShaderHandModule.getInstance();
            if (shaderHandModule2 != null && shaderHandModule2.isEnabled()) {
                new HandRenderPhaseEvent(HandRenderPhaseEvent.Phase.POST, matrixstack, f).hook();
            }
        }
    }

    @WrapWithCondition(
            method = {"renderMapInOneHand"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionfc;)V",
                        ordinal = 2)
            })
    private boolean cancelMapRotationY(MatrixStack matrixstack, Quaternionfc quaternionfc) {
        return false;
    }

    @Inject(
            method = {"renderFirstPersonItem"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
                        ordinal = 1)
            })
    public void injectBeforeRenderItem(
            AbstractClientPlayerEntity abstractclientplayerentity,
            float f,
            float f1,
            Hand hand,
            float f2,
            ItemStack itemstack,
            float f3,
            MatrixStack matrixstack,
            OrderedRenderCommandQueue orderedrendercommandqueue,
            int i,
            CallbackInfo callbackinfo) {
        HandsModule handsModule = HandsModule.getInstance();
        if (handsModule.isActive()) {
            boolean flag = hand == Hand.MAIN_HAND;
            Arm arm =
                    flag
                            ? abstractclientplayerentity.getMainArm()
                            : abstractclientplayerentity.getMainArm().getOpposite();
            handsModule.applyScale(matrixstack, arm);
            HandEditor.getInstance().updateProjectedBounds(arm, matrixstack);
        }
    }

    @ModifyExpressionValue(
            method = {
                "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"
            },
            at = {
                @At(
                        value = "FIELD",
                        target =
                                "Lnet/minecraft/client/render/item/HeldItemRenderer$HandRenderType;renderOffHand:Z")
            })
    private boolean white$showEditorOffHand(boolean flag) {
        return HandEditor.getInstance().isActive() || flag;
    }

    @ModifyExpressionValue(
            method = {
                "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"
            },
            at = {
                @At(
                        value = "FIELD",
                        target =
                                "Lnet/minecraft/client/render/item/HeldItemRenderer$HandRenderType;renderMainHand:Z")
            })
    private boolean white$showEditorMainHand(boolean flag) {
        return HandEditor.getInstance().isActive() || flag;
    }

    @ModifyArg(
            method = {
                "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"
            },
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
                            ordinal = 0),
            index = 5)
    private ItemStack white$useEditorMainHandItem(ItemStack itemstack) {
        if (!HandEditor.getInstance().isActive()) {
            return itemstack;
        } else {
            ClientPlayerEntity clientplayerentity = MinecraftClient.getInstance().player;
            return clientplayerentity == null
                    ? itemstack
                    : HandEditor.getInstance().getPreviewItem(clientplayerentity.getMainArm());
        }
    }

    @WrapOperation(
            method = {
                "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"
            },
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionfc;)V",
                        ordinal = 1)
            },
            slice = {
                @Slice(
                        from =
                                @At(
                                        value = "INVOKE",
                                        target =
                                                "Lnet/minecraft/client/render/item/HeldItemRenderer;getHandRenderType(Lnet/minecraft/client/network/ClientPlayerEntity;)Lnet/minecraft/client/render/item/HeldItemRenderer$HandRenderType;"),
                        to =
                                @At(
                                        value = "FIELD",
                                        target =
                                                "Lnet/minecraft/client/render/item/HeldItemRenderer$HandRenderType;renderMainHand:Z"))
            })
    private void replaceYawRotation(
            MatrixStack matrixstack,
            Quaternionfc quaternionfc,
            Operation<Void> operation,
            @Local(ordinal = 4) float f) {
        if (!NoRenderModule.getInstance().removeCameraShakeSetting.isOn()) {
            float yaw = MinecraftClient.getInstance().gameRenderer.getCamera().getYaw();
            matrixstack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((yaw - f) * 0.1F));
        }
    }

    @ModifyArg(
            method = {
                "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"
            },
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
                            ordinal = 1),
            index = 5)
    private ItemStack white$useEditorOffHandItem(ItemStack itemstack) {
        if (!HandEditor.getInstance().isActive()) {
            return itemstack;
        } else {
            ClientPlayerEntity clientplayerentity = MinecraftClient.getInstance().player;
            return clientplayerentity == null
                    ? itemstack
                    : HandEditor.getInstance()
                            .getPreviewItem(clientplayerentity.getMainArm().getOpposite());
        }
    }

    @WrapOperation(
            method = {"renderFirstPersonItem"},
            at = {
                @At(
                        value = "INVOKE",
                        target =
                                "Lnet/minecraft/client/render/item/HeldItemRenderer;swingArm(FLnet/minecraft/client/util/math/MatrixStack;ILnet/minecraft/util/Arm;)V")
            })
    private void handAnimationHook(
            HeldItemRenderer helditemrenderer,
            float f,
            MatrixStack matrixstack,
            int i,
            Arm arm,
            Operation<Void> operation,
            @Local(ordinal = 0, argsOnly = true)
                    AbstractClientPlayerEntity abstractclientplayerentity,
            @Local(ordinal = 0, argsOnly = true) Hand hand,
            @Local(ordinal = 3, argsOnly = true) float f1,
            @Local(ordinal = 0, argsOnly = true) ItemStack itemstack) {
        if (itemstack.getItem() instanceof CrossbowItem) {
            operation.call(helditemrenderer, f, matrixstack, i, arm);
        } else {
            FirstPersonItemEvent firstPersonItemEvent =
                    new FirstPersonItemEvent(matrixstack, hand, f, f1, arm);
            firstPersonItemEvent.hook();
            if (!firstPersonItemEvent.isCancelled()) {
                operation.call(helditemrenderer, f, matrixstack, i, arm);
            }
        }
    }

    @Inject(
            method = {"renderFirstPersonItem"},
            at = {
                @At(
                        value = "INVOKE",
                        target = "Lnet/minecraft/client/util/math/MatrixStack;push()V",
                        shift = Shift.AFTER,
                        ordinal = 0)
            })
    private void onRenderFirstPersonItem(
            AbstractClientPlayerEntity abstractclientplayerentity,
            float f,
            float f1,
            Hand hand,
            float f2,
            ItemStack itemstack,
            float f3,
            MatrixStack matrixstack,
            OrderedRenderCommandQueue orderedrendercommandqueue,
            int i,
            CallbackInfo callbackinfo) {
        Arm arm =
                hand == Hand.MAIN_HAND
                        ? abstractclientplayerentity.getMainArm()
                        : abstractclientplayerentity.getMainArm().getOpposite();
        HandMatrixEvent handMatrixEvent = new HandMatrixEvent(matrixstack, hand, arm);
        handMatrixEvent.hook();
        if (!itemstack.isEmpty()) {
            HandsModule handsModule = HandsModule.getInstance();
            if (handsModule != null) {
                handsModule.applyTranslation(matrixstack, arm);
            }
        }
    }
}
