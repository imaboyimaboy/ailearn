package dev.gooba.client.mixin;

import dev.gooba.client.BetterTridentModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.TridentItem;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Environment(EnvType.CLIENT)
@Mixin({TridentItem.class})
public class TridentItemMixin {
    @ModifyConstant(
            method = {"onStoppedUsing"},
            constant = {@Constant(intValue = 10)},
            require = 0)
    private int goobaa$modifyTridentChargeTime(int i) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            BetterTridentModule betterTridentModule =
                    Gooba.getInstance().getModuleRegistry().findModule(BetterTridentModule.class);
            if (betterTridentModule != null && betterTridentModule.isEnabled()) {
                return 0;
            }
        }

        return i;
    }
}
