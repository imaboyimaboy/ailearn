package dev.gooba.client.mixin;

import dev.gooba.client.FreecamModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({LivingEntity.class})
public class LivingEntityMixin2 {
    @Inject(
            method = {"jump"},
            at = {@At("HEAD")},
            cancellable = true)
    private void preventJump(CallbackInfo callbackinfo) {
        if ((Object) this instanceof ClientPlayerEntity) {
            if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
                FreecamModule freecamModule2 =
                        Gooba.getInstance().getModuleRegistry().findModule(FreecamModule.class);
                if (freecamModule2 != null && freecamModule2.isActive()) {
                    callbackinfo.cancel();
                }
            }
        }
    }

    @ModifyVariable(
            method = {"travel"},
            at = @At("HEAD"),
            argsOnly = true)
    private Vec3d removeMovement(Vec3d vec3d) {
        if (!((Object) this instanceof ClientPlayerEntity)) {
            return vec3d;
        } else if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FreecamModule freecamModule2 =
                    Gooba.getInstance().getModuleRegistry().findModule(FreecamModule.class);
            return freecamModule2 != null && freecamModule2.isActive()
                    ? new Vec3d(0.0, vec3d.y, 0.0)
                    : vec3d;
        } else {
            return vec3d;
        }
    }
}
