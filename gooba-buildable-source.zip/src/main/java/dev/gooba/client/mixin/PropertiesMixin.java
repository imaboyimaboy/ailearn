package dev.gooba.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import dev.gooba.client.WorldTweaksModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.world.ClientWorld.Properties;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin({Properties.class})
public abstract class PropertiesMixin {
    @Shadow private long timeOfDay;

    @ModifyReturnValue(
            method = {"getTimeOfDay"},
            at = {@At("RETURN")})
    private long hookGetTime(long i) {
        return WorldTweaksModule.getInstance().isEnabled()
                        && WorldTweaksModule.getInstance().overrideTimeSetting.isOn()
                ? (long) (WorldTweaksModule.getInstance().timeSetting.getFloat() * 1000.0F)
                : this.timeOfDay;
    }
}
