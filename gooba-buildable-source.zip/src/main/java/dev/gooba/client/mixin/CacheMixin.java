package dev.gooba.client.mixin;

import com.mojang.blaze3d.shaders.ShaderType;

import dev.gooba.client.ShaderSourceProvider;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.ShaderLoader.Cache;
import net.minecraft.util.Identifier;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({Cache.class})
public class CacheMixin {
    @Inject(
            method = {"getSource"},
            at = {@At("HEAD")},
            cancellable = true)
    private void white$provideEmbeddedSource(
            Identifier identifier,
            ShaderType shadertype,
            CallbackInfoReturnable<String> callbackinforeturnable) {
        String text = ShaderSourceProvider.loadShader(identifier, shadertype);
        if (text != null) {
            callbackinforeturnable.setReturnValue(text);
        }
    }
}
