package dev.gooba.client.mixin;

import dev.gooba.client.ChinaHatFeatureRenderer;
import dev.gooba.client.NameTagsModule;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.EntityRendererFactory.Context;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.entity.player.PlayerEntity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityRenderer.class})
public class PlayerEntityRendererMixin {
    @Inject(
            method = {"updateRenderState"},
            at = {@At("TAIL")})
    private void onUpdateRenderState(
            PlayerLikeEntity playerlikeentity,
            PlayerEntityRenderState playerentityrenderstate,
            float f,
            CallbackInfo callbackinfo) {
        NameTagsModule nameTagsModule = NameTagsModule.getInstance();
        if (nameTagsModule != null
                && nameTagsModule.isEnabled()
                && nameTagsModule.playersSetting.isOn()) {
            if (nameTagsModule.ignoreUnarmoredPlayersSetting.isOn()
                    && playerlikeentity instanceof PlayerEntity playerentity
                    && !NameTagsModule.isArmored(playerentity)) {
                return;
            }

            playerentityrenderstate.playerName = null;
            playerentityrenderstate.displayName = null;
        }
    }

    @Inject(
            method = {"<init>"},
            at = {@At("TAIL")})
    private void onInit(Context context, boolean flag, CallbackInfo callbackinfo) {
        PlayerEntityRenderer playerentityrenderer =
                (PlayerEntityRenderer) ((PlayerEntityRenderer) (Object) this);
        playerentityrenderer.addFeature(new ChinaHatFeatureRenderer(playerentityrenderer));
    }
}
