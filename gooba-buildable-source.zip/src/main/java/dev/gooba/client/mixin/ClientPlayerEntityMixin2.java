package dev.gooba.client.mixin;

import dev.gooba.client.FreecamModule;
import dev.gooba.client.Gooba;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({ClientPlayerEntity.class})
public class ClientPlayerEntityMixin2 {
    @Inject(
            method = {"tickMovement"},
            at = {@At("TAIL")})
    private void onTickMovementTail(CallbackInfo callbackinfo) {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FreecamModule freecamModule2 =
                    Gooba.getInstance().getModuleRegistry().findModule(FreecamModule.class);
            if (freecamModule2 != null && freecamModule2.isActive()) {
                ClientPlayerEntity clientplayerentity =
                        (ClientPlayerEntity) ((ClientPlayerEntity) (Object) this);
                freecamModule2.freezePlayerInput(clientplayerentity);
                clientplayerentity.sidewaysSpeed = 0.0F;
                clientplayerentity.forwardSpeed = 0.0F;
            }
        }
    }

    @Inject(
            method = {"tick"},
            at = {@At("HEAD")})
    private void onTick(CallbackInfo callbackinfo) {
        this.apply();
    }

    @Inject(
            method = {"tickMovement"},
            at = {@At("HEAD")})
    private void onTickMovementHead(CallbackInfo callbackinfo) {
        this.apply();
    }

    private void apply() {
        if (Gooba.getInstance() != null && Gooba.getInstance().getModuleRegistry() != null) {
            FreecamModule freecamModule2 =
                    Gooba.getInstance().getModuleRegistry().findModule(FreecamModule.class);
            if (freecamModule2 != null && freecamModule2.isActive()) {
                freecamModule2.freezePlayerInput(
                        (ClientPlayerEntity) ((ClientPlayerEntity) (Object) this));
            }
        }
    }
}
