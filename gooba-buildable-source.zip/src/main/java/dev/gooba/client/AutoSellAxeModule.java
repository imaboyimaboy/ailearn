package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;

@ModuleInfo(
        name = "Auto Sell Axe",
        category = ModuleCategory.DONUT,
        desc = "Switches to a netherite axe in the hotbar and holds left click")
@Environment(EnvType.CLIENT)
public class AutoSellAxeModule extends Module {

    private int findNetheriteAxeSlot() {
        if (client.player == null) {
            return -1;
        } else {
            for (int i = 0; i < 9; i++) {
                ItemStack itemstack = client.player.getInventory().getStack(i);
                if (!itemstack.isEmpty() && itemstack.isOf(Items.NETHERITE_AXE)) {
                    return i;
                }
            }

            return -1;
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null
                && client.world != null
                && client.currentScreen == null
                && client.options != null) {
            if (!client.player.getMainHandStack().isOf(Items.NETHERITE_AXE)) {
                int i = this.findNetheriteAxeSlot();
                if (i < 0) {
                    client.options.attackKey.setPressed(false);
                    return;
                }

                client.player.getInventory().setSelectedSlot(i);
                if (client.player.networkHandler != null) {
                    client.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(i));
                }
            }

            client.options.attackKey.setPressed(true);
        } else {
            if (client.options != null) {
                client.options.attackKey.setPressed(false);
            }
        }
    }

    @Override
    protected void onDisable() {
        if (client.options != null) {
            client.options.attackKey.setPressed(false);
        }
    }
}
