package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class MatrixSetting extends Setting<boolean[][]> {
    public MatrixSetting(Module module, String name, int size) {
        super(module, name, new boolean[size][size]);
        this.size = size;
        resetCrosshair();
    }

    public final int size;

    public void resetCrosshair() {
        clear();
        int center = getCenter();

        int gap = Math.max(1, size / 7);
        int armLength = Math.max(2, size / 5);
        for (int offset = gap; offset < gap + armLength && center + offset < size; offset++) {
            setCell(center, center - offset, true);
            setCell(center, center + offset, true);
            setCell(center - offset, center, true);
            setCell(center + offset, center, true);
        }
    }

    public int getCenter() {
        return this.size / 2;
    }

    public boolean isInside(int i, int j) {
        return i >= 0 && j >= 0 && i < this.size && j < this.size;
    }

    public void loadRows(List<String> list) {
        this.clear();

        for (int i = 0; i < this.size && i < list.size(); i++) {
            String text = (String) list.get(i);

            for (int j = 0; j < this.size && j < text.length(); j++) {
                boolean[] aboolean = ((boolean[][]) this.getValue())[i];
                if (text.charAt(j) == '1') {
                    aboolean[j] = true;
                } else {
                    aboolean[j] = false;
                }
            }
        }
    }

    public List<String> serializeRows() {
        ArrayList arraylist = new ArrayList(this.size);

        for (boolean[] aboolean : (boolean[][]) this.getValue()) {
            StringBuilder stringbuilder = new StringBuilder(this.size);

            for (boolean flag : aboolean) {
                stringbuilder.append((char) (flag ? '1' : '0'));
            }

            arraylist.add(stringbuilder.toString());
        }

        return arraylist;
    }

    public void setCell(int i, int j, boolean enabled) {
        if (this.isInside(i, j)) {
            ((boolean[][]) this.getValue())[j][i] = enabled;
        }
    }

    public MatrixSetting visibleWhen(Supplier supplier) {
        return (MatrixSetting) super.visibleWhen(supplier);
    }

    public void clear() {
        for (boolean[] aboolean : (boolean[][]) this.getValue()) {
            Arrays.fill(aboolean, false);
        }
    }

    public boolean isEnabled(int i, int j) {
        return this.isInside(i, j) && ((boolean[][]) this.getValue())[j][i];
    }
}
