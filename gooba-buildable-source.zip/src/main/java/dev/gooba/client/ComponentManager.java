package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.HashMap;

@Environment(EnvType.CLIENT)
public final class ComponentManager
        extends HashMap<Class<? extends ClientComponent>, ClientComponent> {
    public void initialize() {
        this.register(
                new ClientComponent[] {
                    new TargetRingRenderer(),
                    new RotationStateManager(),
                    new HudDragManager(),
                    new ReservedComponent()
                });
        this.values().forEach(clientComponent -> Gooba.getEventBus().subscribe(clientComponent));
    }

    public <T extends ClientComponent> T findComponent(Class<T> oclass) {
        return this.values().stream()
                .filter(clientComponent -> clientComponent.getClass() == oclass)
                .map(oclass::cast)
                .findFirst()
                .orElse(null);
    }

    public void register(ClientComponent[] clientComponents) {
        for (ClientComponent clientComponent : clientComponents) {
            this.put(
                    (Class<? extends ClientComponent>) clientComponent.getClass(), clientComponent);
        }
    }
}
