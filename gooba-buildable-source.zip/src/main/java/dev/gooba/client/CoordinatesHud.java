package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class CoordinatesHud implements HudElement {
    private static float measureCoordinate(String string) {
        return Fonts.INTER_SEMIBOLD.measureWidth(string, 7.2F)
                + Fonts.INTER_SEMIBOLD.measureWidth("x", 7.2F);
    }

    @Override
    public void render(PositionSetting positionSetting2, HUDModule hUDModule) {
        float f = hUDModule.hudSizeSetting.getFloat();
        float innerX = positionSetting2.position.x;
        float innerY = positionSetting2.position.y;
        String string = Integer.toString(client.player.getBlockX());
        String stringValue = Integer.toString(client.player.getBlockY());
        String string2 = Integer.toString(client.player.getBlockZ());
        float f3 =
                measureCoordinate(string)
                        + measureCoordinate(stringValue)
                        + measureCoordinate(string2)
                        + 6.0F;
        float width = 16.0F * f;
        float widthValue = (8.0F + f3) * f;
        float f6 = width + 0.5F * f + widthValue;
        float height = 13.5F * f;
        float f8 = 4.0F * f;
        hUDModule.drawBackground(innerX, innerY, width, height, f8, 1.0F);
        float innerXValue = innerX + width + 0.5F * f;
        hUDModule.drawBackground(innerXValue, innerY, widthValue, height, f8, 1.0F);
        String string3 = "W";
        float size = 7.5F * f;
        float f11 = innerX + (width - 8.0F * f) * 0.5F;
        Font font = Fonts.GOOBA_ICONS;
        float f13 = Fonts.GOOBA_ICONS.centerTextX(string3, f11, 8.0F * f, size);
        float f14 = Fonts.GOOBA_ICONS.centerTextY(string3, innerY, height, size);
        hUDModule.getAccentColor(1.0F);
        font.drawText(string3, f13, f14, size);
        float f12 = innerXValue + 4.0F * f;
        f12 = drawCoordinate(string, "x", f12, innerY, height, f, hUDModule);
        f12 += 3.0F * f;
        f12 = drawCoordinate(stringValue, "y", f12, innerY, height, f, hUDModule);
        f12 += 3.0F * f;
        drawCoordinate(string2, "z", f12, innerY, height, f, hUDModule);
        positionSetting2.size.set(f6, height);
    }

    private static float centerTextY(float f, float height, float size) {
        return Fonts.INTER_SEMIBOLD.centerTextY("Ag09:", f, height, size) + 0.45F * size / 7.2F;
    }

    private static float drawCoordinate(
            String string,
            String stringValue,
            float f,
            float f1,
            float height,
            float f3,
            HUDModule hUDModule) {
        float size = 7.2F * f3;
        float f5 = centerTextY(f1, height, size);
        Fonts.INTER_SEMIBOLD.drawText(string, f, f5, size);
        float f6 = f + Fonts.INTER_SEMIBOLD.measureWidth(string, size);
        Font font = Fonts.INTER_SEMIBOLD;
        hUDModule.getAccentColor(1.0F);
        font.drawText(stringValue, f6, f5, size);
        return f6 + Fonts.INTER_SEMIBOLD.measureWidth(stringValue, size);
    }
}
