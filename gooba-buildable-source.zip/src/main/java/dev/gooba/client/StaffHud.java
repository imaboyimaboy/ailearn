package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.world.GameMode;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

@Environment(EnvType.CLIENT)
public class StaffHud implements MinecraftAccess {

    private static final Set<Integer> STAFF_PREFIXES = Set.of(9733, 9734, 42, 10025, 10026, 10027);
    private final EasingAnimation heightAnimation;
    private final EasingAnimation visibilityAnimation = createAnimation(0.0F);
    private final EasingAnimation widthAnimation = new EasingAnimation().resetValue(0.0F);

    private static final Pattern USERNAME_PATTERN = Pattern.compile("^\\w{3,16}$");
    private final Map<String, StaffHud.StaffData> staff;

    private void removeExpiredEntries() {
        this.staff
                .entrySet()
                .removeIf(
                        entry ->
                                !entry.getValue().active
                                        && entry.getValue().visibilityAnimation.getFloatValue()
                                                <= 0.001F);
    }

    private static String statusLabel(StaffHud.StaffData staffData) {
        return staffData.spectating ? "Spec" : "Active";
    }

    private static String stripStaffPrefix(String text) {
        if (text != null && !text.isEmpty()) {
            int i = 0;

            while (i < text.length()) {
                int codePoint = text.codePointAt(i);
                if (!STAFF_PREFIXES.contains(codePoint)) {
                    break;
                }

                i += Character.charCount(codePoint);
            }

            return i == 0 ? text : text.substring(i).stripLeading();
        } else {
            return text;
        }
    }

    public void renderStaff(PositionSetting positionSetting2, HUDModule hUDModule) {
        if (client.player != null && client.player.networkHandler != null) {
            float f = hUDModule.hudSizeSetting.getFloat();
            float innerX = positionSetting2.position.x;
            float innerY = positionSetting2.position.y;
            this.staff.values().forEach(cu5$staffdatax -> cu5$staffdatax.active = false);

            for (PlayerListEntry playerlistentry : client.player.networkHandler.getPlayerList()) {
                if (playerlistentry.getProfile() != null) {
                    String text = playerlistentry.getProfile().name();
                    if (text != null && USERNAME_PATTERN.matcher(text).matches()) {
                        String textValue =
                                playerlistentry.getDisplayName() == null
                                        ? text
                                        : playerlistentry.getDisplayName().getString();
                        String textValueValue = textValue;
                        if (playerlistentry.getScoreboardTeam() != null) {
                            String string =
                                    playerlistentry.getScoreboardTeam().getPrefix().getString();
                            textValueValue = string + textValue;
                        }

                        textValueValue = textValueValue.stripLeading();
                        boolean flag;
                        flag =
                                !(!text.equalsIgnoreCase("DrDonutt")
                                        && !text.equalsIgnoreCase("ArchivePedro2"));

                        if (hasStaffPrefix(textValueValue) || flag) {
                            StaffHud.StaffData staffDataValue =
                                    this.staff.computeIfAbsent(text, StaffHud.StaffData::new);
                            staffDataValue.active = true;
                            staffDataValue.playerEntry = playerlistentry;
                            if (playerlistentry.getGameMode() == GameMode.SPECTATOR) {
                                staffDataValue.spectating = true;
                            } else {
                                staffDataValue.spectating = false;
                            }

                            String text2 = textValueValue.isEmpty() ? text : textValueValue;
                            staffDataValue.displayName = stripStaffPrefix(text2);
                        }
                    }
                }
            }

            ArrayList<StaffHud.StaffData> arraylist = new ArrayList<>(this.staff.values());
            arraylist.sort(
                    Comparator.comparing(
                            cu5$staffdatax -> cu5$staffdatax.username,
                            String.CASE_INSENSITIVE_ORDER));
            float f33 = 0.0F;
            float f34 =
                    16.0F
                            + Fonts.INTER_SEMIBOLD.measureWidth("  ", 7.5F)
                            + Fonts.INTER_SEMIBOLD.measureVisibleWidth("Staff", 7.5F);
            float f35 = 0.0F;
            boolean flag1 = false;

            for (StaffHud.StaffData staffData3 :
                    (Iterable<StaffHud.StaffData>) (Iterable) arraylist) {
                float f38 =
                        staffData3.visibilityAnimation.approach(
                                staffData3.active ? 1.0F : 0.0F, 2.5F);
                if (staffData3.active) {
                    flag1 = true;
                }

                if (staffData3.active || !(f38 <= 0.001F)) {
                    f33 += 14.0F * f38;
                    float f3 =
                            Fonts.INTER_SEMIBOLD.measureVisibleWidth(staffData3.displayName, 7.2F);
                    float f4 =
                            Fonts.INTER_SEMIBOLD.measureVisibleWidth(statusLabel(staffData3), 7.2F);
                    float f5 = 22.0F + f3 + 0.5F + 8.0F + f4;
                    f35 = Math.max(f35, f5);
                }
            }

            float target = Math.max(f34, f35);
            float targetValue = 15.0F + f33;
            boolean flag2;
            flag2 =
                    !(!hUDModule.alwaysShowSetting.isOn()
                            && !flag1
                            && !(f33 > 0.001F)
                            && !(client.currentScreen instanceof ChatScreen));

            if (flag2 && this.visibilityAnimation.getFloatValue() <= 0.001F) {
                this.widthAnimation.resetValue(target);
                this.heightAnimation.resetValue(targetValue);
            }

            float factor = animate(this.visibilityAnimation, flag2 ? 1.0F : 0.0F);
            if (!flag2 && !(factor > 0.01F)) {
                positionSetting2.visible = false;
            } else {
                positionSetting2.visible = true;
            }

            if (factor <= 0.01F) {
                this.removeExpiredEntries();
                positionSetting2.size.set(f34 * f, 15.0F * f);
            } else {
                float f40 = this.widthAnimation.approach(target, 2.5F) * f;
                float f41 = this.heightAnimation.approach(targetValue, 2.5F) * f;
                float height = 15.0F * f;
                float f7 = 4.0F * f;
                String string2 = "T";
                float size = 7.5F * f;
                float f9 = Fonts.INTER_SEMIBOLD.measureWidth("  ", 7.5F * f);
                float width7 =
                        16.0F * f
                                + f9
                                + Fonts.INTER_SEMIBOLD.measureVisibleWidth("Staff", 7.5F * f);
                hUDModule.drawBackground(innerX, innerY, width7, height, f7, factor);
                float f11 = innerX + 4.0F * f;
                Font font = Fonts.GOOBA_ICONS;
                float f42 = Fonts.GOOBA_ICONS.centerTextX(string2, f11, 8.0F * f, size);
                float f43 = Fonts.GOOBA_ICONS.centerTextY(string2, innerY, height, size);
                hUDModule.getAccentColor(factor);
                font.drawText(string2, f42, f43, size);
                float f12 = f11 + 8.0F * f + f9;
                float width = Fonts.INTER_SEMIBOLD.measureVisibleWidth("Staff", 7.5F * f);
                float f14 = Fonts.INTER_SEMIBOLD.centerTextX("Staff", f12, width, 7.5F * f);
                float f15 = centerTextY(innerY, height, 7.5F * f);
                font = Fonts.INTER_SEMIBOLD;
                float sizeValue = 7.5F * f;
                ColorUtils.multiplyAlpha(-657931, factor);
                font.drawText("Staff", f14, f15, sizeValue);
                float innerYValue = innerY + height;

                for (StaffHud.StaffData staffData4 :
                        (Iterable<StaffHud.StaffData>) (Iterable) arraylist) {
                    float floatValue = staffData4.visibilityAnimation.getFloatValue();
                    if (!(floatValue <= 0.001F)) {
                        float f18 = 13.5F * floatValue * f;
                        float opacity = floatValue * factor;
                        innerYValue += 0.5F * floatValue * f;
                        float f20 = (1.0F - floatValue) * 8.0F * f;
                        innerX += f20;
                        float f21 = innerYValue + 13.5F * f * 0.5F;
                        String stringValue = statusLabel(staffData4);
                        float size3 = 7.2F * f;
                        float width8 = 13.5F * f;
                        float innerXValue = innerX + width8 + 0.5F * f;
                        float widthValue =
                                Fonts.INTER_SEMIBOLD.measureVisibleWidth(
                                        staffData4.displayName, size3);
                        float width9 = 8.0F * f + widthValue;
                        float innerX2 = innerXValue + width9 + 0.5F * f;
                        float width11 =
                                Fonts.INTER_SEMIBOLD.measureVisibleWidth(stringValue, size3);
                        float width10 = 8.0F * f + width11;
                        hUDModule.drawBackground(
                                innerX, innerYValue, width8, 13.5F * f, f7, opacity);
                        hUDModule.drawBackground(
                                innerXValue, innerYValue, width9, 13.5F * f, f7, opacity);
                        hUDModule.drawBackground(
                                innerX2, innerYValue, width10, 13.5F * f, f7, opacity);
                        if (staffData4.playerEntry != null
                                && staffData4.playerEntry.getSkinTextures() != null
                                && staffData4.playerEntry.getSkinTextures().body() != null) {
                            RenderUtils.Images.drawImageRegion(
                                    staffData4.playerEntry.getSkinTextures().body().texturePath(),
                                    innerX + (width8 - 8.0F * f) * 0.5F,
                                    f21 - 4.0F * f,
                                    8.0F * f,
                                    8.0F * f,
                                    0.125F,
                                    0.125F,
                                    0.25F,
                                    0.25F,
                                    ColorUtils.withOpacity(
                                            ColorUtils.opaqueGrayscale(255), opacity),
                                    1.0F,
                                    2.0F * f);
                        }

                        float f30 = centerTextY(innerYValue, 13.5F * f, size3);
                        float f31 =
                                Fonts.INTER_SEMIBOLD.centerTextX(
                                        staffData4.displayName,
                                        innerXValue + 4.0F * f,
                                        widthValue,
                                        size3);
                        font = Fonts.INTER_SEMIBOLD;
                        String displayName = staffData4.displayName;
                        ColorUtils.multiplyAlpha(-657931, opacity);
                        font.drawText(displayName, f31, f30, size3);
                        float f32 =
                                Fonts.INTER_SEMIBOLD.centerTextX(
                                        stringValue, innerX2 + 4.0F * f, width11, size3);
                        int color =
                                staffData4.spectating
                                        ? ColorUtils.rgb(255, 40, 40)
                                        : ColorUtils.rgb(40, 255, 70);
                        font = Fonts.INTER_SEMIBOLD;
                        ColorUtils.withOpacity(color, opacity);
                        font.drawText(stringValue, f32, f30, size3);
                        innerX -= f20;
                        innerYValue += f18;
                    }
                }

                this.removeExpiredEntries();
                positionSetting2.size.set(f40, f41);
            }
        }
    }

    private static boolean hasStaffPrefix(String text) {
        if (text != null && !text.isEmpty()) {
            int codePoint = text.codePointAt(0);
            return codePoint == 9733
                    || codePoint == 9734
                    || codePoint == 42
                    || codePoint == 10025
                    || codePoint == 10026
                    || codePoint == 10027;
        } else {
            return false;
        }
    }

    private static float animate(EasingAnimation easingAnimation2, float f) {
        easingAnimation2.animateTo((double) f, 0.3F, Easings.OUT_EXPO, true);
        easingAnimation2.update();
        return easingAnimation2.getFloatValue();
    }

    public StaffHud() {
        this.heightAnimation = new EasingAnimation().resetValue(15.0F);
        this.staff = new LinkedHashMap<>();
    }

    private static float centerTextY(float f, float height, float size) {
        return Fonts.INTER_SEMIBOLD.centerTextY("Ag09:", f, height, size) + 0.45F * size / 7.2F;
    }

    private static EasingAnimation createAnimation(float f) {
        return new EasingAnimation()
                .setCurrentValue((double) f)
                .setStartValue((double) f)
                .setTargetValue((double) f)
                .setDurationMillis(1.0);
    }

    @Environment(EnvType.CLIENT)
    private static class StaffData {
        private boolean active;
        private boolean spectating;
        private final EasingAnimation visibilityAnimation = new EasingAnimation().resetValue(0.0F);
        private final String username;
        private PlayerListEntry playerEntry;
        private String displayName;

        private StaffData(String stringValue) {
            this.username = stringValue;
            this.displayName = stringValue;
        }
    }
}
