package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.PlayerListEntry;

import java.util.Locale;

@Environment(EnvType.CLIENT)
public class WatermarkHud implements HudElement {
    private static void drawShimmerText(
            Font font,
            String stringValue,
            float f,
            float f1,
            float size,
            float f3,
            HUDModule hUDModule) {
        float f4 = font.measureWidth(stringValue, size);
        float f5 = 0.0F;
        int i = 0;

        while (i < stringValue.length()) {
            int codePoint = stringValue.codePointAt(i);
            String string = new String(Character.toChars(codePoint));
            float f6 = font.measureWidth(string, size);
            float f7 = f4 <= 0.0F ? 0.0F : (f5 + f6 * 0.5F) / f4;
            float f8 = f + f5;
            shimmerColor(f7, f3, hUDModule);
            font.drawText(string, f8, f1, size);
            f5 += f6;
            i += Character.charCount(codePoint);
        }
    }

    private String displayedUsername() {
        String username = client.getSession().getUsername();
        NameProtectModule nameProtectModule =
                Gooba.getInstance().getModuleRegistry().findModule(NameProtectModule.class);
        return nameProtectModule != null && nameProtectModule.isEnabled()
                ? nameProtectModule.protectedName()
                : username;
    }

    private static void drawSeparator(float f, float f1, float height, float f3) {
        String string = "|";
        float size = 7.0F * f3;
        Font font = Fonts.SF_MEDIUM;
        float f5 = Fonts.SF_MEDIUM.centerTextX(string, f, 4.0F * f3, size);
        float f6 = centerTextY(Fonts.SF_MEDIUM, f1, height, size);
        ColorUtils.cachedRgba(170, 170, 175, 190);
        font.drawText(string, f5, f6, size);
    }

    private static void drawInfoCell(
            Font font,
            String string,
            String stringValue,
            float f,
            float f1,
            float height,
            float f3,
            Font fontValue,
            HUDModule hUDModule) {
        float size = 8.0F * f3;
        float f6 = font.centerTextX(string, f, 15.0F * f3, size);
        float f7 = font.centerTextY(string, f1, height, size);
        hUDModule.getAccentColor(1.0F);
        font.drawText(string, f6, f7, size);
        drawSeparator(f + 15.0F * f3, f1, height, f3);
        float sizeValue = 7.0F * f3;
        fontValue.drawText(
                stringValue,
                f + 21.0F * f3,
                centerTextY(fontValue, f1, height, sizeValue),
                sizeValue);
    }

    private static float drawInfoCellAndAdvance(
            Font font,
            String string,
            String stringValue,
            float f,
            float f1,
            float height,
            float f3,
            Font fontValue,
            HUDModule hUDModule) {
        float size = 8.0F * f3;
        float width = 15.0F * f3;
        float f8 = font.centerTextX(string, f, width, size);
        float f9 = font.centerTextY(string, f1, height, size);
        hUDModule.getAccentColor(1.0F);
        font.drawText(string, f8, f9, size);
        drawSeparator(f + width, f1, height, f3);
        float f6 = f + width + 6.0F * f3;
        float sizeValue = 7.0F * f3;
        fontValue.drawText(
                stringValue, f6, centerTextY(fontValue, f1, height, sizeValue), sizeValue);
        return f6 + fontValue.measureWidth(stringValue, sizeValue) + 4.0F * f3;
    }

    private int pingMillis() {
        if (client.player != null && client.player.networkHandler != null) {
            PlayerListEntry playerlistentry =
                    client.player.networkHandler.getPlayerListEntry(client.player.getUuid());
            return playerlistentry == null ? 0 : Math.max(0, playerlistentry.getLatency());
        } else {
            return 0;
        }
    }

    private static float centerTextY(Font font, float f, float height, float size) {
        return font.centerTextY("Ag09:", f, height, size) + 0.6F * size / 7.0F;
    }

    private static float shimmerPosition() {
        float f = (float) (System.currentTimeMillis() % 1500L) / 1500.0F;
        return 2.1F - f * 3.2F;
    }

    private static float measureCellWidth(Font font, String string, Font fontValue, String text) {
        return 21.0F + font.measureWidth(string, 7.0F) + 4.0F;
    }

    private static int shimmerColor(float f, float f1, HUDModule hUDModule) {
        float f2 = Math.abs(f - f1);
        float f3 = Math.max(0.0F, Math.min(1.0F, 1.0F - f2 / 1.1F));
        f3 = f3 * f3 * (3.0F - 2.0F * f3);
        return ColorUtils.withOpacity(hUDModule.getAccentColor(1.0F), 1.0F - f3 * 0.65F);
    }

    @Override
    public void render(PositionSetting positionSetting2, HUDModule hUDModule) {
        if (client.player != null) {
            float f = hUDModule.hudSizeSetting.getFloat();
            float innerX = positionSetting2.position.x;
            float innerY = positionSetting2.position.y;
            float height = 15.0F * f;
            float f4 = 2.0F * f;
            float sizeValue = 7.0F * f;
            Font font = Fonts.SF_MEDIUM;
            String string = this.displayedUsername();
            int currentFps = client.getCurrentFps();
            String stringValue = currentFps + " fps";
            int j = this.pingMillis();
            String string2 = j + " Ping";
            String string3 = String.format(Locale.US, "%.1f Ticks", ServerInfo.ticksPerSecond);
            double d0 = client.player.getX() - client.player.lastX;
            double d1 = client.player.getZ() - client.player.lastZ;
            String string4 =
                    String.format(Locale.US, "%.1f Bps", Math.sqrt(d0 * d0 + d1 * d1) * 20.0);
            float f6 = measureCellWidth(font, "Goobaa+", Fonts.LOGO, "\ue000");
            float f7 = measureCellWidth(font, string, Fonts.GOOBA_ICONS, "N");
            float f8 = measureCellWidth(font, stringValue, Fonts.GOOBA_ICONS, "L");
            float f9 = f7 + f8;
            float innerXValue = innerX + (f6 + 2.0F) * f;
            float f11 = measureCellWidth(font, string2, Fonts.GOOBA_ICONS, "D");
            float f12 = measureCellWidth(font, string3, Fonts.ALPHA, "$");
            float f13 = measureCellWidth(font, string4, Fonts.ALPHA, "@");
            float innerYValue = innerY + height + f4;
            float innerX2 = innerX + (f11 + 2.0F) * f;
            float innerX3 = innerX2 + (f12 + 2.0F) * f;
            hUDModule.drawBackground(innerX, innerY, f6 * f, height, 4.0F * f, 1.0F);
            hUDModule.drawBackground(innerXValue, innerY, f9 * f, height, 4.0F * f, 1.0F);
            hUDModule.drawBackground(innerX, innerYValue, f11 * f, height, 4.0F * f, 1.0F);
            hUDModule.drawBackground(innerX2, innerYValue, f12 * f, height, 4.0F * f, 1.0F);
            hUDModule.drawBackground(innerX3, innerYValue, f13 * f, height, 4.0F * f, 1.0F);
            float size = 11.0F * f;
            float f18 = shimmerPosition();
            drawShimmerText(
                    Fonts.LOGO,
                    "\ue000",
                    Fonts.LOGO.centerTextX("\ue000", innerX, 15.0F * f, size),
                    Fonts.LOGO.centerTextY("\ue000", innerY, height, size),
                    size,
                    f18,
                    hUDModule);
            drawSeparator(innerX + 15.0F * f, innerY, height, f);
            drawShimmerText(
                    font,
                    "Goobaa+",
                    innerX + 21.0F * f,
                    centerTextY(font, innerY, height, sizeValue),
                    sizeValue,
                    f18,
                    hUDModule);
            float f19 =
                    drawInfoCellAndAdvance(
                            Fonts.GOOBA_ICONS,
                            "N",
                            string,
                            innerXValue,
                            innerY,
                            height,
                            f,
                            font,
                            hUDModule);
            drawInfoCellAndAdvance(
                    Fonts.GOOBA_ICONS, "L", stringValue, f19, innerY, height, f, font, hUDModule);
            drawInfoCell(
                    Fonts.GOOBA_ICONS,
                    "D",
                    string2,
                    innerX,
                    innerYValue,
                    height,
                    f,
                    font,
                    hUDModule);
            drawInfoCell(
                    Fonts.ALPHA, "$", string3, innerX2, innerYValue, height, f, font, hUDModule);
            drawInfoCell(
                    Fonts.ALPHA, "@", string4, innerX3, innerYValue, height, f, font, hUDModule);
            float f20 = f6 + 2.0F + f9;
            float f21 = f11 + 2.0F + f12 + 2.0F + f13;
            positionSetting2.size.set(Math.max(f20, f21) * f, 30.0F * f + f4);
        }
    }
}
