package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;

@Environment(EnvType.CLIENT)
public final class RenderEntityContext {
    private static Entity entity;

    public static boolean hasEntity() {
        return entity != null;
    }

    public static Entity getEntity() {
        return entity;
    }

    private RenderEntityContext() {}
}
