package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public class ShaderEspPipeline {
    private int height;
    private static final Identifier VERTEX_SHADER = Identifier.of("client", "core/shader_esp_glow");
    private static final RenderPipeline UPSAMPLE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/shader_esp_up"))
                            .withVertexShader(VERTEX_SHADER)
                            .withFragmentShader(Identifier.of("client", "core/shader_esp_up"))
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("EspKawaseData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private ByteBuffer espUniformData;
    private final GpuTexture[] mipTextures = new GpuTexture[5];

    private static final RenderPipeline COMBINE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/shader_esp_combine"))
                            .withVertexShader(VERTEX_SHADER)
                            .withFragmentShader(Identifier.of("client", "core/shader_esp_combine"))
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("EspData", UniformType.UNIFORM_BUFFER)
                            .withSampler("maskTexture")
                            .withSampler("glowTexture")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
    private GpuBuffer kawaseUniformBuffer;
    private ByteBuffer kawaseUniformData;
    private boolean initialized;
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
    private static final RenderPipeline DOWNSAMPLE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/shader_esp_down"))
                            .withVertexShader(VERTEX_SHADER)
                            .withFragmentShader(Identifier.of("client", "core/shader_esp_down"))
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("EspKawaseData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.LIGHTNING)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());

    private final int[] mipHeights;
    private GpuBuffer vertexBuffer;
    private final GpuTextureView[] mipTextureViews = new GpuTextureView[5];
    private static final Vector3f MODEL_OFFSET = new Vector3f(0.0F, 0.0F, 0.0F);
    private int width;
    private final int[] mipWidths = new int[5];
    private GpuBuffer espUniformBuffer;

    private void putColor(int i) {
        this.espUniformData.putFloat((float) (i >> 16 & 0xFF) / 255.0F);
        this.espUniformData.putFloat((float) (i >> 8 & 0xFF) / 255.0F);
        this.espUniformData.putFloat((float) (i & 0xFF) / 255.0F);
    }

    public ShaderEspPipeline() {
        this.mipHeights = new int[5];
        this.initialized = false;
        this.width = 0;
        this.height = 0;
    }

    private void resizeMipmaps(int widthValue, int heightValue) {
        if (widthValue != this.width || heightValue != this.height || this.mipTextures[0] == null) {
            this.closeMipmaps();
            int mipWidth = widthValue;
            int mipHeight = heightValue;

            for (int i11 = 0; i11 < 5; i11++) {
                mipWidth = Math.max(1, mipWidth / 2);
                mipHeight = Math.max(1, mipHeight / 2);
                this.mipWidths[i11] = mipWidth;
                this.mipHeights[i11] = mipHeight;
                int j1 = i11;
                this.mipTextures[i11] =
                        RenderSystem.getDevice()
                                .createTexture(
                                        () -> "minecraft:shader_esp_mip_" + j1,
                                        12,
                                        TextureFormat.RGBA8,
                                        mipWidth,
                                        mipHeight,
                                        1,
                                        1);
                this.mipTextureViews[i11] =
                        RenderSystem.getDevice().createTextureView(this.mipTextures[i11]);
            }

            this.width = widthValue;
            this.height = heightValue;
        }
    }

    private static float cycleProgress(float f) {
        long i = Math.max(1L, (long) (f * 1000.0F));
        return (float) (System.currentTimeMillis() % i) / (float) i;
    }

    private void closeMipmaps() {
        for (int i = 0; i < 5; i++) {
            if (this.mipTextureViews[i] != null) {
                this.mipTextureViews[i].close();
                this.mipTextureViews[i] = null;
            }

            if (this.mipTextures[i] != null) {
                this.mipTextures[i].close();
                this.mipTextures[i] = null;
            }
        }
    }

    private void uploadKawaseUniforms(CommandEncoder commandencoder, float f, float f1, float f2) {
        this.kawaseUniformData.clear();
        this.kawaseUniformData.putFloat(f);
        this.kawaseUniformData.putFloat(f1);
        this.kawaseUniformData.putFloat(f2);
        this.kawaseUniformData.putFloat(0.0F);
        this.kawaseUniformData.flip();
        commandencoder.writeToBuffer(this.kawaseUniformBuffer.slice(), this.kawaseUniformData);
    }

    public void close() {
        this.closeMipmaps();
        if (this.kawaseUniformBuffer != null) {
            this.kawaseUniformBuffer.close();
            this.kawaseUniformBuffer = null;
        }

        if (this.espUniformBuffer != null) {
            this.espUniformBuffer.close();
            this.espUniformBuffer = null;
        }

        if (this.vertexBuffer != null) {
            this.vertexBuffer.close();
            this.vertexBuffer = null;
        }

        if (this.kawaseUniformData != null) {
            MemoryUtil.memFree(this.kawaseUniformData);
            this.kawaseUniformData = null;
        }

        if (this.espUniformData != null) {
            MemoryUtil.memFree(this.espUniformData);
            this.espUniformData = null;
        }

        this.initialized = false;
        this.width = 0;
        this.height = 0;
    }

    private void uploadEspUniforms(
            CommandEncoder commandencoder, int i, int j, ShaderEspPipeline.Params params) {
        this.espUniformData.clear();
        this.putColor(params.mainColor);
        this.espUniformData.putFloat(clamp(params.opacity, 0.0F, 1.0F));
        this.putColor(params.friendColor);
        this.espUniformData.putFloat(params.highlightFriends ? 1.0F : 0.0F);
        this.espUniformData.putFloat(1.0F / (float) i);
        this.espUniformData.putFloat(1.0F / (float) j);
        this.espUniformData.putFloat((float) Math.max(0, Math.min(5, params.outlineWidth)));
        this.espUniformData.putFloat((float) params.outlineMode);
        this.espUniformData.putFloat(Math.max(0.0F, params.glowStrength));
        this.espUniformData.putFloat(Math.max(0.05F, params.glowFalloff));
        this.espUniformData.putFloat(Math.max(0.0F, params.fillOpacity));
        this.espUniformData.putFloat(Math.max(0.0F, params.innerGlow));
        this.espUniformData.putFloat(Math.max(0.0F, params.outlineStrength));
        this.espUniformData.putFloat(clamp(params.outlineWhite, 0.0F, 1.0F));
        this.espUniformData.putFloat(params.glowEnabled ? 1.0F : 0.0F);
        this.espUniformData.putFloat(params.fillEnabled ? 1.0F : 0.0F);
        this.espUniformData.putFloat(cycleProgress(params.shimmerPeriod));
        this.espUniformData.putFloat(params.shimmerEnabled ? 1.0F : 0.0F);
        this.espUniformData.putFloat(Math.max(0.005F, params.shimmerWidth));
        this.espUniformData.putFloat(Math.max(0.0F, params.shimmerBrightness));
        this.espUniformData.putFloat(
                params.pulseEnabled ? clamp(params.pulseAmount, 0.0F, 1.0F) : 0.0F);
        this.espUniformData.putFloat(cycleProgress(1.0F / Math.max(0.05F, params.pulseSpeed)));
        this.espUniformData.putFloat(Math.max(0.0F, params.saturation));
        this.espUniformData.putFloat(params.outlineEnabled ? 1.0F : 0.0F);
        this.espUniformData.flip();
        commandencoder.writeToBuffer(this.espUniformBuffer.slice(), this.espUniformData);
    }

    public void render(
            GpuTextureView gputextureview,
            GpuTextureView gpuTextureView,
            int widthValue,
            int heightValue,
            ShaderEspPipeline.Params params) {
        this.initialize();
        this.resizeMipmaps(widthValue, heightValue);
        float f = clamp(params.blurRadius, 0.0F, 1.0F);
        int k = Math.max(1, Math.min(5, 1 + Math.round(f * 4.0F)));
        float f1 = 0.5F + f * 3.5F;
        CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
        GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
        GpuTextureView gputextureviewValue = gputextureview;
        int widthValueValue = widthValue;
        int heightValueValue = heightValue;

        for (int j1 = 0; j1 < k; j1++) {
            this.uploadKawaseUniforms(
                    commandencoder,
                    0.5F / (float) widthValueValue,
                    0.5F / (float) heightValueValue,
                    1.0F);
            GpuBufferSlice gpubufferslice =
                    RenderSystem.getDynamicUniforms()
                            .write(
                                    RenderSystem.getModelViewMatrix(),
                                    COLOR_MODULATOR,
                                    MODEL_OFFSET,
                                    TEXTURE_MATRIX);
            GpuTextureView gputextureviewValueValue = gputextureviewValue;

            int j2 = j1;

            try (RenderPass renderPass =
                    commandencoder.createRenderPass(
                            () -> "minecraft:shader_esp_down_" + j2,
                            this.mipTextureViews[j1],
                            OptionalInt.of(0))) {
                renderPass.setPipeline(DOWNSAMPLE_PIPELINE);
                renderPass.setVertexBuffer(0, this.vertexBuffer);
                renderPass.bindTexture("Sampler0", gputextureviewValueValue, gpusampler);
                RenderSystem.bindDefaultUniforms(renderPass);
                renderPass.setUniform("DynamicTransforms", gpubufferslice);
                renderPass.setUniform("EspKawaseData", this.kawaseUniformBuffer);
                renderPass.draw(0, 6);
            }

            gputextureviewValue = this.mipTextureViews[j1];
            widthValueValue = this.mipWidths[j1];
            heightValueValue = this.mipHeights[j1];
        }

        for (int k1 = k - 1; k1 > 0; k1--) {
            this.uploadKawaseUniforms(
                    commandencoder,
                    0.5F / (float) this.mipWidths[k1],
                    0.5F / (float) this.mipHeights[k1],
                    f1);
            GpuBufferSlice gpuBufferSlice =
                    RenderSystem.getDynamicUniforms()
                            .write(
                                    RenderSystem.getModelViewMatrix(),
                                    COLOR_MODULATOR,
                                    MODEL_OFFSET,
                                    TEXTURE_MATRIX);
            int l1 = k1;

            try (RenderPass renderpass =
                    commandencoder.createRenderPass(
                            () -> {
                                int jx = l1 - 1;
                                return "minecraft:shader_esp_up_" + jx;
                            },
                            this.mipTextureViews[l1 - 1],
                            OptionalInt.of(0))) {
                renderpass.setPipeline(UPSAMPLE_PIPELINE);
                renderpass.setVertexBuffer(0, this.vertexBuffer);
                renderpass.bindTexture("Sampler0", this.mipTextureViews[l1], gpusampler);
                RenderSystem.bindDefaultUniforms(renderpass);
                renderpass.setUniform("DynamicTransforms", gpuBufferSlice);
                renderpass.setUniform("EspKawaseData", this.kawaseUniformBuffer);
                renderpass.draw(0, 6);
            }
        }

        this.uploadEspUniforms(commandencoder, widthValue, heightValue, params);
        GpuBufferSlice gpuBufferSliceValue =
                RenderSystem.getDynamicUniforms()
                        .write(
                                RenderSystem.getModelViewMatrix(),
                                COLOR_MODULATOR,
                                MODEL_OFFSET,
                                TEXTURE_MATRIX);

        try (RenderPass renderPassValue =
                commandencoder.createRenderPass(
                        () -> "minecraft:shader_esp_combine",
                        gpuTextureView,
                        OptionalInt.empty())) {
            renderPassValue.setPipeline(COMBINE_PIPELINE);
            renderPassValue.setVertexBuffer(0, this.vertexBuffer);
            renderPassValue.bindTexture("maskTexture", gputextureview, gpusampler);
            renderPassValue.bindTexture("glowTexture", this.mipTextureViews[0], gpusampler);
            RenderSystem.bindDefaultUniforms(renderPassValue);
            renderPassValue.setUniform("DynamicTransforms", gpuBufferSliceValue);
            renderPassValue.setUniform("EspData", this.espUniformBuffer);
            renderPassValue.draw(0, 6);
        }
    }

    private static float clamp(float f, float f1, float f2) {
        return f < f1 ? f1 : Math.min(f, f2);
    }

    private void initialize() {
        if (!this.initialized) {
            this.kawaseUniformData = MemoryUtil.memAlloc(16);
            this.espUniformData = MemoryUtil.memAlloc(112);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.vertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "minecraft:shader_esp_dummy_vertex", 32, bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.kawaseUniformBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:shader_esp_kawase_ubo", 136, 16L);
            this.espUniformBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "minecraft:shader_esp_ubo", 136, 112L);
            this.initialized = true;
        }
    }

    @Environment(EnvType.CLIENT)
    public static final class Params {
        public float shimmerPeriod;
        public boolean outlineEnabled;
        public float shimmerBrightness;
        public float glowStrength;
        public float fillOpacity;
        public float blurRadius;
        public float glowFalloff;
        public int friendColor;
        public boolean glowEnabled;
        public float pulseSpeed;
        public boolean highlightFriends;
        public int mainColor = -16711681;
        public float innerGlow;
        public int outlineMode;
        public boolean pulseEnabled;
        public boolean shimmerEnabled;
        public float opacity;
        public float outlineStrength;
        public float saturation;
        public boolean fillEnabled;
        public float outlineWhite;
        public float pulseAmount;
        public float shimmerWidth;
        public int outlineWidth;

        public Params() {
            this.friendColor = -11141291;
            this.highlightFriends = true;
            this.opacity = 1.0F;
            this.saturation = 1.0F;
            this.glowEnabled = true;
            this.blurRadius = 0.5F;
            this.glowStrength = 1.4F;
            this.glowFalloff = 1.2F;
            this.fillEnabled = true;
            this.fillOpacity = 0.35F;
            this.innerGlow = 0.5F;
            this.outlineEnabled = true;
            this.outlineWidth = 2;
            this.outlineMode = 0;
            this.outlineStrength = 1.5F;
            this.outlineWhite = 0.5F;
            this.pulseEnabled = false;
            this.pulseSpeed = 1.0F;
            this.pulseAmount = 0.3F;
            this.shimmerEnabled = true;
            this.shimmerWidth = 0.04F;
            this.shimmerPeriod = 5.0F;
            this.shimmerBrightness = 0.8F;
        }
    }
}
