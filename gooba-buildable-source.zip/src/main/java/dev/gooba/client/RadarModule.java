package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.AbstractClientPlayerEntity;

import org.joml.Vector2f;

@ModuleInfo(
        name = "Radar",
        category = ModuleCategory.RENDER,
        desc = "Shows nearby players on a draggable circular minimap")
@Environment(EnvType.CLIENT)
public class RadarModule extends Module {
    public final SliderSetting sizeSetting =
            new SliderSetting(this, "Size", 110.0F, 70.0F, 180.0F, 1.0F);
    public final PositionSetting radarSetting;
    public final SliderSetting rangeSetting =
            new SliderSetting(this, "Range", 48.0F, 12.0F, 96.0F, 1.0F);

    public RadarModule() {
        this.radarSetting = new PositionSetting(this, "Radar", new Vector2f(18.0F, 120.0F));
    }

    @EventHandler
    public void onRender2D(Render2DEvent render2DEvent) {
        if (client.world != null && client.player != null) {
            float width = this.sizeSetting.getFloat();
            float innerX = this.radarSetting.position.x;
            float innerY = this.radarSetting.position.y;
            float centerX = innerX + width * 0.5F;
            float centerY = innerY + width * 0.5F;
            float f5 = width * 0.5F;
            HUDModule hUDModule = HUDModule.getInstance();
            this.radarSetting.size.set(width, width);
            this.radarSetting.visible = true;
            hUDModule.drawBackground(innerX, innerY, width, width, f5, 1.0F);
            Gooba.getInstance()
                    .getHudManager()
                    .getCircleData()
                    .drawCircle(
                            centerX, centerY, f5 - 2.0F, ColorUtils.cachedRgba(105, 105, 115, 48));
            Gooba.getInstance()
                    .getHudManager()
                    .getCircleData()
                    .drawCircle(
                            centerX, centerY, f5 * 0.54F, ColorUtils.cachedRgba(105, 105, 115, 30));
            hUDModule.drawRoundedBackground(
                    centerX - 0.35F,
                    innerY + 8.0F,
                    0.7F,
                    width - 16.0F,
                    0.35F,
                    ColorUtils.grayscaleOpacity(255, 0.13F));
            hUDModule.drawRoundedBackground(
                    innerX + 8.0F,
                    centerY - 0.35F,
                    width - 16.0F,
                    0.7F,
                    0.35F,
                    ColorUtils.grayscaleOpacity(255, 0.13F));
            Gooba.getInstance()
                    .getHudManager()
                    .getCircleData()
                    .drawCircle(centerX, centerY, 3.0F, hUDModule.getAccentColor(1.0F));
            double d0 = Math.toRadians((double) client.player.getYaw());
            double d1 = Math.cos(d0);
            double d2 = Math.sin(d0);
            this.drawDirectionLabel("N", centerX, centerY, 0.0, -1.0, d1, d2, f5 - 8.0F, hUDModule);
            this.drawDirectionLabel("E", centerX, centerY, 1.0, 0.0, d1, d2, f5 - 8.0F, hUDModule);
            this.drawDirectionLabel("S", centerX, centerY, 0.0, 1.0, d1, d2, f5 - 8.0F, hUDModule);
            this.drawDirectionLabel("W", centerX, centerY, -1.0, 0.0, d1, d2, f5 - 8.0F, hUDModule);
            float f6 = f5 - 13.0F;
            float f7 = this.rangeSetting.getFloat();
            float f8 = Math.max(9.0F, width * 0.105F);

            for (AbstractClientPlayerEntity abstractclientplayerentity :
                    client.world.getPlayers()) {
                if (abstractclientplayerentity != client.player
                        && !FakeLagModule.isGhost(abstractclientplayerentity)
                        && abstractclientplayerentity.isAlive()
                        && !abstractclientplayerentity.isSpectator()) {
                    double d3 = abstractclientplayerentity.getX() - client.player.getX();
                    double d4 = abstractclientplayerentity.getZ() - client.player.getZ();
                    double d5 = Math.sqrt(d3 * d3 + d4 * d4);
                    if (!(d5 > (double) f7)) {
                        double d6 = d3 * d1 - d4 * d2;
                        double d7 = d3 * d2 + d4 * d1;
                        float f9 = (float) (d6 / (double) f7 * (double) f6);
                        float f10 = (float) (d7 / (double) f7 * (double) f6);
                        float f11 = (float) Math.sqrt((double) (f9 * f9 + f10 * f10));
                        if (f11 > f6) {
                            f9 *= f6 / f11;
                            f10 *= f6 / f11;
                        }

                        float f12 = centerX + f9 - f8 * 0.5F;
                        float f13 = centerY + f10 - f8 * 0.5F;
                        int i = ColorUtils.opaqueGrayscale(255);
                        RenderUtils.Images.drawRoundedRegion(
                                abstractclientplayerentity.getSkin().body().texturePath(),
                                f12,
                                f13,
                                f8,
                                f8,
                                0.125F,
                                0.125F,
                                0.25F,
                                0.25F,
                                i,
                                f8 * 0.28F);
                        RenderUtils.Images.drawRoundedRegion(
                                abstractclientplayerentity.getSkin().body().texturePath(),
                                f12,
                                f13,
                                f8,
                                f8,
                                0.625F,
                                0.125F,
                                0.75F,
                                0.25F,
                                i,
                                f8 * 0.28F);
                    }
                }
            }
        }
    }

    private void drawDirectionLabel(
            String string,
            float f,
            float f1,
            double d0,
            double d1,
            double d2,
            double d3,
            float f2,
            HUDModule hUDModule) {
        float size = 8.0F;
        int color = hUDModule.getAccentColor(0.9F);
        float f4 = f + (float) (d0 * d2 - d1 * d3) * f2;
        float f5 = f1 + (float) (d0 * d3 + d1 * d2) * f2 - size * 0.5F;
        Fonts.SF_BOLD.drawCenteredText(string, f4, f5, size, color);
    }
}
