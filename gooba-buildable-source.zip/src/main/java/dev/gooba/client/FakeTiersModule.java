package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;

@ModuleInfo(
        name = "Fake Tiers",
        category = ModuleCategory.COMBAT,
        desc = "Shows fake PvP tiers for you or other players client-side.")
@Environment(EnvType.CLIENT)
public class FakeTiersModule extends Module {
    public final ColorSetting lT3ColorSetting;
    public final ColorSetting lT5ColorSetting;
    public final ModeSetting tierSetting;
    public final BooleanSetting tablistSetting;
    public final ColorSetting hT3ColorSetting;
    public final ColorSetting lT4ColorSetting;
    public final ModeSetting applyToSetting =
            new ModeSetting(this, "Apply To", new String[] {"You", "Others", "All"});
    public final ColorSetting hT4ColorSetting;

    public final ColorSetting hT2ColorSetting;
    public final BooleanSetting nametagsSetting;
    public final BooleanSetting chatSetting;
    public final ColorSetting lT1ColorSetting;
    public final ColorSetting customColorSetting;
    public final ColorSetting lT2ColorSetting;
    public final ColorSetting hT1ColorSetting;
    public final ColorSetting hT5ColorSetting;
    public final ModeSetting iconSetting;
    public final TextSetting customTierSetting;

    public String iconGlyph() {
        String string = this.iconSetting.getSelectedMode();
        switch (string) {
            case "Vanilla":
                return "\ue708";
            case "Sword":
                return "\ue706";
            case "Axe":
                return "\ue701";
            case "Pot":
                return "\ue704";
            case "Mace":
                return "\ue702";
            case "UHC":
                return "\ue707";
            case "SMP":
                return "\ue705";
            case "Nethop":
                return "\ue703";
            case "Bed":
                return "\ue801";
            case "Bow":
                return "\ue802";
            case "Creeper":
                return "\ue803";
            case "Debuff":
                return "\ue804";
            case "Dia Crystal":
                return "\ue805";
            case "Dia SMP":
                return "\ue806";
            case "Elytra":
                return "\ue807";
            case "Manhunt":
                return "\ue808";
            case "Minecart":
                return "\ue809";
            case "OG Vanilla":
                return "\ue810";
            case "Speed":
                return "\ue811";
            case "Trident":
                return "\ue812";
            case "MCTiers":
                return "\ue901";
            case "Subtiers":
                return "\ue902";
            default:
                return "";
        }
    }

    public String tierLabel() {
        if ("Custom".equalsIgnoreCase(this.tierSetting.getSelectedMode())) {
            String string = this.customTierSetting.getText();
            return string != null && !string.isEmpty() ? string : "HT1";
        } else {
            return this.tierSetting.getSelectedMode();
        }
    }

    public FakeTiersModule() {
        this.tierSetting =
                new ModeSetting(
                        this,
                        "Tier",
                        new String[] {
                            "HT1", "LT1", "HT2", "LT2", "HT3", "LT3", "HT4", "LT4", "HT5", "LT5",
                            "Custom"
                        });
        this.customTierSetting = new TextSetting(this, "Custom Tier", "HT1");
        this.iconSetting =
                new ModeSetting(
                        this,
                        "Icon",
                        new String[] {
                            "None",
                            "Vanilla",
                            "Sword",
                            "Axe",
                            "Pot",
                            "Mace",
                            "UHC",
                            "SMP",
                            "Nethop",
                            "Bed",
                            "Bow",
                            "Creeper",
                            "Debuff",
                            "Dia Crystal",
                            "Dia SMP",
                            "Elytra",
                            "Manhunt",
                            "Minecart",
                            "OG Vanilla",
                            "Speed",
                            "Trident",
                            "MCTiers",
                            "Subtiers"
                        });
        this.tablistSetting = new BooleanSetting(this, "Tablist", true);
        this.nametagsSetting = new BooleanSetting(this, "Nametags", true);
        this.chatSetting = new BooleanSetting(this, "Chat", true);
        this.hT1ColorSetting = new ColorSetting(this, "HT1 Color", -1525190);
        this.lT1ColorSetting = new ColorSetting(this, "LT1 Color", -2772139);
        this.hT2ColorSetting = new ColorSetting(this, "HT2 Color", -3877913);
        this.lT2ColorSetting = new ColorSetting(this, "LT2 Color", -6248526);
        this.hT3ColorSetting = new ColorSetting(this, "HT3 Color", -483494);
        this.lT3ColorSetting = new ColorSetting(this, "LT3 Color", -3769534);
        this.hT4ColorSetting = new ColorSetting(this, "HT4 Color", -8293222);
        this.lT4ColorSetting = new ColorSetting(this, "LT4 Color", -10134663);
        this.hT5ColorSetting = new ColorSetting(this, "HT5 Color", -7372120);
        this.lT5ColorSetting = new ColorSetting(this, "LT5 Color", -10134663);
        this.customColorSetting = new ColorSetting(this, "Custom Color", -22016);
    }

    public boolean appliesTo(String text) {
        if (this.isEnabled() && text != null && !text.isEmpty()) {
            String string = this.applyToSetting.getSelectedMode();
            if ("All".equalsIgnoreCase(string)) {
                return true;
            } else if (client.player == null) {
                return false;
            } else {
                boolean flag = text.equalsIgnoreCase(client.player.getName().getString());
                if ("You".equalsIgnoreCase(string)) {
                    return flag;
                } else {
                    return !"Others".equalsIgnoreCase(string) ? true : !flag;
                }
            }
        } else {
            return false;
        }
    }

    public Text tierText() {
        String text = this.tierLabel();
        int i = this.tierColor(text);
        MutableText mutabletext =
                Text.literal(text).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(i)));
        String string = this.iconGlyph();
        if (!string.isEmpty()) {
            MutableText mutableText =
                    Text.literal(string + " ")
                            .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)));
            return Text.empty().append(mutableText).append(mutabletext);
        } else {
            return mutabletext;
        }
    }

    public int tierColor(String text) {
        if (text == null) {
            return 16777215;
        } else {
            String textValue = text.toUpperCase().trim();
            switch (textValue) {
                case "HT1":
                    return this.hT1ColorSetting.getColor() & 16777215;
                case "LT1":
                    return this.lT1ColorSetting.getColor() & 16777215;
                case "HT2":
                    return this.hT2ColorSetting.getColor() & 16777215;
                case "LT2":
                    return this.lT2ColorSetting.getColor() & 16777215;
                case "HT3":
                    return this.hT3ColorSetting.getColor() & 16777215;
                case "LT3":
                    return this.lT3ColorSetting.getColor() & 16777215;
                case "HT4":
                    return this.hT4ColorSetting.getColor() & 16777215;
                case "LT4":
                    return this.lT4ColorSetting.getColor() & 16777215;
                case "HT5":
                    return this.hT5ColorSetting.getColor() & 16777215;
                case "LT5":
                    return this.lT5ColorSetting.getColor() & 16777215;
                default:
                    return this.customColorSetting.getColor() & 16777215;
            }
        }
    }

    private List<String> affectedNames() {
        String text;
        String textValue;
        if (client.player != null) {
            text = client.player.getName().getString();
            textValue = this.applyToSetting.getSelectedMode();
        } else {
            text = "";
            textValue = this.applyToSetting.getSelectedMode();
        }

        if ("You".equalsIgnoreCase(textValue)) {
            return text.isEmpty() ? List.of() : List.of(text);
        } else {
            LinkedHashSet<String> linkedhashset = new LinkedHashSet<>();
            if ("All".equalsIgnoreCase(textValue) && !text.isEmpty()) {
                linkedhashset.add(text);
            }

            ClientPlayNetworkHandler clientplaynetworkhandler = client.getNetworkHandler();
            if (clientplaynetworkhandler != null) {
                for (PlayerListEntry playerlistentry : clientplaynetworkhandler.getPlayerList()) {
                    if (playerlistentry != null
                            && playerlistentry.getProfile() != null
                            && playerlistentry.getProfile().name() != null) {
                        String text2 = playerlistentry.getProfile().name();
                        boolean flag;
                        flag = (!text.isEmpty() && text2.equalsIgnoreCase(text));

                        if ("All".equalsIgnoreCase(textValue)
                                || !flag && "Others".equalsIgnoreCase(textValue)) {
                            linkedhashset.add(text2);
                        }
                    }
                }
            }

            return linkedhashset.stream()
                    .filter(text3 -> !text3.isEmpty())
                    .sorted(Comparator.comparingInt(String::length).reversed())
                    .toList();
        }
    }

    public Text decorateChat(Text text) {
        if (text != null && this.isEnabled() && this.chatSetting.isOn()) {
            List<String> list = this.affectedNames();
            if (list.isEmpty()) {
                return text;
            } else {
                ArrayList arraylist = new ArrayList();
                text.visit(
                        (stylex, sx) -> {
                            sx.codePoints()
                                    .forEach(
                                            ix ->
                                                    arraylist.add(
                                                            new FakeTiersModule.StyledCp(
                                                                    ix, stylex)));
                            return Optional.empty();
                        },
                        Style.EMPTY);
                String string = this.iconGlyph();
                String textValue = this.tierLabel();
                int i = this.tierColor(textValue);
                Style style = Style.EMPTY.withColor(TextColor.fromRgb(16777215));
                Style style4 = Style.EMPTY.withColor(TextColor.fromRgb(i));
                Style style5 = Style.EMPTY.withColor(Formatting.GRAY);
                ArrayList arrayList = new ArrayList();
                if (!string.isEmpty()) {
                    string.codePoints()
                            .forEach(ix -> arrayList.add(new FakeTiersModule.StyledCp(ix, style)));
                    arrayList.add(new FakeTiersModule.StyledCp(32, style));
                }

                textValue
                        .codePoints()
                        .forEach(ix -> arrayList.add(new FakeTiersModule.StyledCp(ix, style4)));
                " | "
                        .codePoints()
                        .forEach(i1 -> arrayList.add(new FakeTiersModule.StyledCp(i1, style5)));
                List listValue =
                        list.stream()
                                .filter(sx -> sx != null && !sx.isEmpty())
                                .map(text2 -> text2.codePoints().toArray())
                                .sorted(
                                        Comparator.<int[]>comparingInt(aintx -> aintx.length)
                                                .reversed())
                                .toList();
                ArrayList arrayListValue = new ArrayList(arraylist.size() + 10);
                boolean flag = false;
                int j = 0;

                while (j < arraylist.size()) {
                    int[] aint = null;

                    for (int[] aintValue : (Iterable<int[]>) (Iterable) listValue) {
                        if (matchesName(arraylist, j, aintValue)) {
                            aint = aintValue;
                            break;
                        }
                    }

                    if (aint != null) {
                        boolean flag1;
                        flag1 =
                                (j >= 3
                                        && ((FakeTiersModule.StyledCp) arraylist.get(j - 1)).cp
                                                == 32
                                        && ((FakeTiersModule.StyledCp) arraylist.get(j - 2)).cp
                                                == 124
                                        && ((FakeTiersModule.StyledCp) arraylist.get(j - 3)).cp
                                                == 32);

                        if (!flag1) {
                            arrayListValue.addAll(arrayList);
                        }

                        for (int l = 0; l < aint.length; l++) {
                            arrayListValue.add((FakeTiersModule.StyledCp) arraylist.get(j + l));
                        }

                        j += aint.length;
                        flag = true;
                    } else {
                        arrayListValue.add((FakeTiersModule.StyledCp) arraylist.get(j++));
                    }
                }

                if (!flag) {
                    return text;
                } else {
                    MutableText mutabletext = Text.empty().setStyle(text.getStyle());
                    int k = 0;

                    while (k < arrayListValue.size()) {
                        Style styleValue = ((FakeTiersModule.StyledCp) arrayListValue.get(k)).style;
                        StringBuilder stringbuilder = new StringBuilder();

                        do {
                            stringbuilder.appendCodePoint(
                                    ((FakeTiersModule.StyledCp) arrayListValue.get(k)).cp);
                            k++;
                        } while (k < arrayListValue.size()
                                && styleValue.equals(
                                        ((FakeTiersModule.StyledCp) arrayListValue.get(k)).style));

                        mutabletext.append(
                                Text.literal(stringbuilder.toString()).setStyle(styleValue));
                    }

                    return mutabletext;
                }
            }
        } else {
            return text;
        }
    }

    public Text decorateNametag(Text text, String textValue) {
        if (text != null && this.appliesTo(textValue)) {
            MutableText mutabletext =
                    Text.empty()
                            .append(this.tierText())
                            .append(
                                    Text.literal(" | ")
                                            .setStyle(Style.EMPTY.withColor(Formatting.GRAY)));
            return Text.empty().append(mutabletext).append(text);
        } else {
            return text;
        }
    }

    public Text decorateTabEntry(Text text, PlayerListEntry playerlistentry) {
        if (text != null && this.appliesTo(playerlistentry)) {
            MutableText mutabletext =
                    Text.empty()
                            .append(this.tierText())
                            .append(
                                    Text.literal(" | ")
                                            .setStyle(Style.EMPTY.withColor(Formatting.GRAY)));
            return Text.empty().append(mutabletext).append(text);
        } else {
            return text;
        }
    }

    public boolean appliesTo(PlayerListEntry playerlistentry) {
        if (this.isEnabled() && playerlistentry != null) {
            String string = this.applyToSetting.getSelectedMode();
            if ("All".equalsIgnoreCase(string)) {
                return true;
            } else if (client.player == null) {
                return false;
            } else {
                boolean flag = false;
                if (playerlistentry.getProfile() != null) {
                    if (playerlistentry.getProfile().id() != null) {
                        flag = client.player.getUuid().equals(playerlistentry.getProfile().id());
                    }

                    if (!flag && playerlistentry.getProfile().name() != null) {
                        flag =
                                playerlistentry
                                        .getProfile()
                                        .name()
                                        .equalsIgnoreCase(client.player.getName().getString());
                    }
                }

                if ("You".equalsIgnoreCase(string)) {
                    return flag;
                } else {
                    return !"Others".equalsIgnoreCase(string) ? true : !flag;
                }
            }
        } else {
            return false;
        }
    }

    private static boolean matchesName(List<FakeTiersModule.StyledCp> list, int i, int[] aint) {
        if (aint.length != 0 && i + aint.length <= list.size()) {
            for (int j = 0; j < aint.length; j++) {
                if (Character.toLowerCase(((FakeTiersModule.StyledCp) list.get(i + j)).cp)
                        != Character.toLowerCase(aint[j])) {
                    return false;
                }
            }

            return true;
        } else {
            return false;
        }
    }

    @Environment(EnvType.CLIENT)
    private static record StyledCp(int cp, Style style) {}
}
