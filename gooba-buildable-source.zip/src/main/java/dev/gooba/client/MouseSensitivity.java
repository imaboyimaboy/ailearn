package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class MouseSensitivity implements MinecraftAccess {
    public static float getSensitivityScale() {
        float f;
        return (f = (float) (client.options.getMouseSensitivity().getValue() * 0.6 + 0.2))
                * f
                * f
                * 8.0F;
    }

    public static float getRotationStep() {
        return (float) ((double) getSensitivityScale() * 0.15);
    }

    public static float roundToMouseSteps(float f) {
        return (float) Math.round(f / getRotationStep());
    }

    public static float quantizeRotation(float f) {
        return roundToMouseSteps(f) * getRotationStep();
    }
}
