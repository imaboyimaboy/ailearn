package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class ItemRenderGuard {
    public static final ThreadLocal<Boolean> threadLocal = ThreadLocal.withInitial(() -> false);

    private ItemRenderGuard() {}
}
