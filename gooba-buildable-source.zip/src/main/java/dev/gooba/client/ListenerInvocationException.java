package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ListenerInvocationException extends RuntimeException {
    public ListenerInvocationException(Class<?> oclass) {
        super("No registered lambda listener for '" + oclass.getName() + "'.");
    }
}
