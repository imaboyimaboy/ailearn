package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class RowAnimationState {
    final EasingAnimation animation = new EasingAnimation();

    RowAnimationState() {}
}
