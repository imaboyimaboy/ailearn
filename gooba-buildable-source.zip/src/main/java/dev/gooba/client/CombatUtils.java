package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;

import java.security.SecureRandom;

@Environment(EnvType.CLIENT)
public final class CombatUtils implements MinecraftAccess {
    private static int remainingComboHits;
    private static final SecureRandom secureRandom = new SecureRandom();

    public static long attackCount;
    private static boolean comboActive;
    private static final CooldownTimer attackTimer = new CooldownTimer();
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static boolean canAttack(
            LivingEntity livingentity, boolean flag, boolean flag1, long i, float[] afloat) {
        return canAttack(livingentity, flag, true, flag1, i, afloat);
    }

    public static boolean hasAttackDelayElapsed(long i) {
        return attackTimer.hasElapsed((double) i);
    }

    private static int getComboLimit() {
        return 3;
    }

    public static void incrementAttackCount() {
        attackCount++;
    }

    public static boolean isAimingAt(LivingEntity livingentity, double d0) {
        return livingentity != null
                && EntityRaycast.intersectsTarget(
                        MathHelper.wrapDegrees(mc.player.getYaw()),
                        mc.player.getPitch(),
                        (double) ((float) d0),
                        livingentity);
    }

    public static boolean shouldResetSprint(LivingEntity livingentity, float[] afloat) {
        return livingentity != null
                && canAttack(livingentity, false, false, -50L, afloat)
                && !mc.player.isOnGround()
                && !mc.player.isSubmergedIn(FluidTags.WATER)
                && mc.player.getVelocity().y <= 0.0030162615090425808;
    }

    public static long getAttackDelayMillis() {
        if (mc.player == null) {
            return (500L);
        } else {
            double attributeValue = mc.player.getAttributeValue(EntityAttributes.ATTACK_SPEED);
            float f = 0.2F;
            long i = (long) (1.0 / attributeValue * 1000.0 * (double) (1.0F - Math.min(f, 1.0F)));
            if (attributeValue == 4.0
                    || attributeValue == 4.4000000059604645
                    || attributeValue == 4.800000011920929) {
                i = (450L);
            }

            return Math.max(i, 450L);
        }
    }

    public static boolean canPerformCritical(boolean flag) {
        if (mc.player == null) {
            return true;
        } else if (mc.player.getMainHandStack().getItem() == Items.MACE) {
            return true;
        } else if (!flag) {
            return true;
        } else {
            boolean canCriticalThisFall = CollisionUtils.canCriticalThisFall();
            if (canCriticalThisFall) {
                return true;
            } else {
                boolean flag2;
                flag2 =
                        (AttackAuraModule.getInstance().additionalChecksSetting.isOn("Smart Crits")
                                && mc.player.isOnGround()
                                && !mc.options.jumpKey.isPressed());

                return flag2 || CollisionUtils.isCriticalPrevented();
            }
        }
    }

    public static Runnable[] blockingActions(boolean flag) {
        Runnable[] arunnable = new Runnable[] {() -> {}, () -> {}};
        if (flag && mc.player != null) {
            if (mc.player.isBlocking()) {
                Hand hand = mc.player.getActiveHand();
                if (hand == null) {
                    return arunnable;
                }

                arunnable[0] =
                        () ->
                                mc.getNetworkHandler()
                                        .sendPacket(
                                                new PlayerActionC2SPacket(
                                                        Action.RELEASE_USE_ITEM,
                                                        BlockPos.ORIGIN,
                                                        Direction.DOWN));
                arunnable[1] =
                        () ->
                                mc.getNetworkHandler()
                                        .sendPacket(
                                                new PlayerInteractItemC2SPacket(
                                                        hand,
                                                        0,
                                                        mc.player.getYaw(),
                                                        mc.player.getPitch()));
            }

            return arunnable;
        } else {
            return arunnable;
        }
    }

    public static Runnable[] sprintActions(boolean flag) {
        Runnable[] arunnable = new Runnable[] {() -> {}, () -> {}};
        if (flag && mc.player != null) {
            if (mc.player.isSprinting()
                    && !mc.player.isOnGround()
                    && !CollisionUtils.isCriticalPrevented()) {
                arunnable[0] =
                        () -> {
                            if (AttackAuraModule.getInstance()
                                    .sprintModeSetting
                                    .isSelected("Silent")) {
                                mc.options.sprintKey.setPressed(false);
                            } else {
                                mc.options.sprintKey.setPressed(false);
                                mc.player.setSprinting(false);
                            }
                        };
                arunnable[1] =
                        () -> {
                            mc.options.sprintKey.setPressed(true);
                            mc.player.setSprinting(true);
                        };
            }

            return arunnable;
        } else {
            return arunnable;
        }
    }

    private CombatUtils() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static void tryComboAttack(
            LivingEntity livingentity, boolean flag, boolean flag1, boolean flag2) {
        if (livingentity == null
                || remainingComboHits == 0
                || !flag2
                || livingentity.hurtTime != 0) {
            resetCombo();
        }

        if (flag2
                && livingentity != null
                && (isSlowComboStep() ? hasAttackDelayElapsed(250L) : hasAttackDelayElapsed(150L))
                && mc.player.handSwinging) {
            if (!CombatUtils.comboActive && remainingComboHits == 0 && livingentity.hurtTime == 0) {
                CombatUtils.comboActive = true;
                remainingComboHits = 3;
            }

            if (CombatUtils.comboActive
                    && remainingComboHits > 0
                    && livingentity != null
                    && (!flag1 || isAimingAt(livingentity, 6.0))
                    && attack(livingentity, () -> {}, () -> {}, Hand.MAIN_HAND, flag)) {
                remainingComboHits--;
            }
        }
    }

    public static void resetAttackCount() {
        attackCount = 0L;
    }

    public static void resetCombo() {
        comboActive = false;
        remainingComboHits = 0;
    }

    public static Runnable[] shieldBreakActions(LivingEntity livingentity, boolean flag) {
        Runnable[] arunnable = new Runnable[] {() -> {}, () -> {}};
        if (flag && mc.player != null) {
            if (livingentity instanceof PlayerEntity playerentity) {
                if (!playerentity.isBlocking()) {
                    return arunnable;
                }

                ItemStack itemstack = playerentity.getMainHandStack();
                ItemStack offHandStack = playerentity.getOffHandStack();
                Item item;
                if (itemstack.isEmpty()) {
                    item = null;
                } else {
                    item = itemstack.getItem();
                }

                Item itemValue;
                if (offHandStack.isEmpty()) {
                    itemValue = null;
                } else {
                    itemValue = offHandStack.getItem();
                }

                if (item == Items.SHIELD || itemValue == Items.SHIELD) {
                    int i = findAxeSlot();
                    int selectedSlot = mc.player.getInventory().getSelectedSlot();
                    if (i != -1 && i != selectedSlot) {
                        arunnable[0] =
                                () -> {
                                    if (mc.getNetworkHandler() != null) {
                                        mc.getNetworkHandler()
                                                .sendPacket(new UpdateSelectedSlotC2SPacket(i));
                                    }
                                };
                        arunnable[1] =
                                () -> {
                                    if (mc.getNetworkHandler() != null) {
                                        mc.getNetworkHandler()
                                                .sendPacket(
                                                        new UpdateSelectedSlotC2SPacket(
                                                                selectedSlot));
                                    }
                                };
                    }
                }
            }

            return arunnable;
        } else {
            return arunnable;
        }
    }

    public static boolean attack(
            LivingEntity livingentity,
            Runnable runnable,
            Runnable runnableValue,
            Hand hand,
            boolean flag) {
        if (runnable != null) {
            runnable.run();
        }

        if (livingentity != null && mc.interactionManager != null && mc.player != null) {
            mc.interactionManager.attackEntity(mc.player, livingentity);
            if (hand != null) {
                mc.player.swingHand(hand);
            }

            if (flag) {
                incrementAttackCount();
            } else {
                resetAttackCount();
            }

            attackTimer.reset();
        }

        if (runnableValue != null) {
            runnableValue.run();
        }

        return livingentity != null;
    }

    public static boolean canAttack(
            LivingEntity livingentity,
            boolean flag,
            boolean flag1,
            boolean flag2,
            long i,
            float[] afloat) {
        if (flag1
                && livingentity != null
                && !TargetPositionUtils.isWithinRange(livingentity, afloat[0], true)) {
            return false;
        } else if (!isAttackReady(i)) {
            return false;
        } else {
            boolean canPerformCritical = canPerformCritical(flag2);
            if (canPerformCritical && flag && !isAimingAt(livingentity, (double) afloat[0])) {
                canPerformCritical = false;
            }

            return canPerformCritical;
        }
    }

    public static int findAxeSlot() {
        if (mc.player == null) {
            return -1;
        } else {
            for (int i = 0; i < 9; i++) {
                if (mc.player.getInventory().getStack(i).getItem() instanceof AxeItem) {
                    return i;
                }
            }

            return -1;
        }
    }

    public static boolean isAttackReady(long i) {
        return attackTimer.hasElapsed((double) (getAttackDelayMillis() + i));
    }

    public static boolean isSlowComboStep() {
        return attackCount % (7L) == (3L);
    }
}
