package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class ServerNavigationHud implements HudElement {
    private static final int[][] REGION_COLORS =
            new int[][] {
                {159, 206, 99},
                {0, 166, 99},
                {79, 173, 234},
                {47, 110, 186},
                {245, 194, 66},
                {252, 136, 3}
            };

    private static final Identifier PLAYER_ARROW =
            Identifier.of("client", "textures/visuals/arrow.png");
    private float displayedYaw;

    private static final String[] REGION_NAMES =
            new String[] {"EU Central", "EU West", "NA East", "NA West", "Asia", "Oceania"};
    private long lastFrameNanos;
    private static final int[] GLITCHED_REGIONS = new int[] {89, 90, 97};
    private static final String[] ADVANCED_REGION_LABELS =
            new String[] {
                "Glitched (no RTP spots)", "Good for media / baltop", "Good for media / other bases"
            };
    private static final int[][] ADVANCED_REGION_COLORS =
            new int[][] {{190, 60, 220}, {70, 130, 220}, {170, 170, 170}};
    private static final int[] BALTOP_REGIONS = new int[] {4, 5, 8, 30};
    private static final int[][] REGION_GRID =
            new int[][] {
                {82, 5},
                {100, 3},
                {101, 3},
                {102, 3},
                {103, 2},
                {104, 2},
                {105, 2},
                {106, 2},
                {91, 2},
                {83, 5},
                {44, 3},
                {75, 3},
                {42, 3},
                {41, 2},
                {40, 2},
                {39, 2},
                {38, 2},
                {92, 2},
                {84, 5},
                {45, 3},
                {14, 3},
                {13, 3},
                {12, 2},
                {11, 2},
                {10, 2},
                {37, 2},
                {93, 2},
                {85, 5},
                {46, 5},
                {74, 5},
                {3, 3},
                {2, 2},
                {1, 2},
                {25, 2},
                {36, 2},
                {94, 2},
                {86, 4},
                {47, 4},
                {72, 4},
                {71, 4},
                {5, 2},
                {4, 2},
                {24, 2},
                {35, 2},
                {95, 2},
                {87, 4},
                {51, 1},
                {17, 1},
                {9, 0},
                {8, 0},
                {7, 0},
                {23, 0},
                {34, 0},
                {96, 2},
                {88, 4},
                {54, 1},
                {18, 1},
                {61, 0},
                {62, 0},
                {21, 0},
                {22, 0},
                {33, 0},
                {97, 0},
                {89, 0},
                {26, 1},
                {27, 0},
                {28, 0},
                {29, 0},
                {30, 0},
                {59, 0},
                {32, 0},
                {98, 0},
                {90, 0},
                {107, 1},
                {108, 1},
                {109, 1},
                {110, 1},
                {111, 1},
                {112, 1},
                {113, 1},
                {99, 0}
            };
    private PlayerEntity trackedPlayer;
    private static final int[] BASE_REGIONS =
            new int[] {2, 7, 28, 29, 32, 34, 59, 86, 88, 98, 99, 109, 112, 113};

    @Override
    public void render(PositionSetting positionSetting2, HUDModule hUDModule) {
        float f = hUDModule.hudSizeSetting.getFloat();
        float f1 = hUDModule.regionMapCellSizeSetting.getFloat() * f;
        float f2 = 4.0F * f;
        float f3 = f1 * 9.0F;
        boolean isOn = hUDModule.regionMapDisplaySetting.isOn("Coordinates");
        boolean isOnValue = hUDModule.regionMapDisplaySetting.isOn("Region Labels");
        boolean isOn2 = hUDModule.regionMapDisplaySetting.isOn("Grid");
        boolean isOn3 = hUDModule.regionMapDisplaySetting.isOn("Player Indicator");
        boolean isOn4 = hUDModule.regionMapDisplaySetting.isOn("Advanced Map");
        int i;
        if (isOnValue) {
            i = isOn4 ? ADVANCED_REGION_LABELS.length : REGION_NAMES.length;
        } else {
            i = 0;
        }

        float f4 = isOn ? 18.0F * f : 0.0F;
        float f5 = (float) i * 10.0F * f;
        float f6 = !isOn && !isOnValue ? 0.0F : 4.0F * f;
        float width = Math.max(f3 + f2 * 2.0F, 122.0F * f);
        float height = f2 * 2.0F + f3 + f6 + f4 + f5;
        float innerX = positionSetting2.position.x;
        float innerY = positionSetting2.position.y;
        float f11 = innerX + (width - f3) * 0.5F;
        float f12 = innerY + f2;
        float f13 = MathHelper.clamp(hUDModule.regionMapOpacitySetting.getFloat(), 0.1F, 1.0F);
        positionSetting2.visible = true;
        hUDModule.drawBackground(innerX, innerY, width, height, 6.0F * f, 1.0F);
        this.drawRegionGrid(
                f11, f12, f1, f13, isOn4, isOn2, hUDModule.regionMapLabelSizeSetting.getFloat(), f);
        if (isOn3) {
            this.drawPlayerIndicator(f11, f12, f1, hUDModule);
        }

        float f14 = f12 + f3 + f6;
        if (isOn) {
            int j = this.currentRegion();
            String stringValue =
                    String.format(
                            "Position: X: %d, Z: %d",
                            (int) client.player.getX(), (int) client.player.getZ());
            String text;
            if (j == -1) {
                text = "Current Region: Outside map";
            } else {
                String string = this.currentRegionName();
                text = "Current Region: " + j + " (" + string + ")";
            }

            String textValue = text;
            Font font = Fonts.SF_REGULAR;
            float f15 = innerX + f2;
            float size = 6.5F * f;
            ColorUtils.cachedRgba(245, 245, 248, 230);
            font.drawText(stringValue, f15, f14, size);
            Font fontValue = Fonts.SF_REGULAR;
            f15 = innerX + f2;
            float f16 = f14 + 8.0F * f;
            size = 6.5F * f;
            ColorUtils.cachedRgba(205, 202, 211, 220);
            fontValue.drawText(textValue, f15, f16, size);
            f14 += f4;
        }

        if (isOnValue) {
            this.drawLegend(innerX + f2, f14, f, isOn4);
        }

        positionSetting2.size.set(width, height);
    }

    private int currentRegion() {
        int i = this.regionIndex(client.player.getX());
        int j = this.regionIndex(client.player.getZ());
        return i >= 0 && i < 9 && j >= 0 && j < 9 ? REGION_GRID[j * 9 + i][0] : -1;
    }

    private void drawLegend(float innerX, float f1, float f2, boolean flag) {
        String[] astring = flag ? ADVANCED_REGION_LABELS : REGION_NAMES;
        int[][] aint = flag ? ADVANCED_REGION_COLORS : REGION_COLORS;

        for (int i = 0; i < astring.length; i++) {
            float f3 = f1 + (float) i * 10.0F * f2;
            RenderUtils.Render2D.drawRoundedRect(
                    innerX,
                    f3 + 1.0F * f2,
                    7.0F * f2,
                    7.0F * f2,
                    ColorUtils.cachedRgba(aint[i][0], aint[i][1], aint[i][2], 230),
                    2.0F * f2);
            Font font = Fonts.SF_REGULAR;
            String string = astring[i];
            float f4 = innerX + 10.0F * f2;
            float f5 = f3 + 1.15F * f2;
            float size = 6.25F * f2;
            ColorUtils.cachedRgba(235, 232, 240, 225);
            font.drawText(string, f4, f5, size);
        }
    }

    private int[] advancedRegionColor(int i) {
        if (this.containsRegion(GLITCHED_REGIONS, i)) {
            return ADVANCED_REGION_COLORS[0];
        } else if (this.containsRegion(BALTOP_REGIONS, i)) {
            return ADVANCED_REGION_COLORS[1];
        } else {
            return this.containsRegion(BASE_REGIONS, i) ? ADVANCED_REGION_COLORS[2] : null;
        }
    }

    private int regionIndex(double d0) {
        return (int) Math.floor((d0 + 225000.0) / 50000.0);
    }

    private String currentRegionName() {
        int i = this.regionIndex(client.player.getX());
        int j = this.regionIndex(client.player.getZ());
        return i >= 0 && i < 9 && j >= 0 && j < 9
                ? REGION_NAMES[REGION_GRID[j * 9 + i][1]]
                : "Unknown";
    }

    private boolean containsRegion(int[] aint, int i) {
        for (int j : aint) {
            if (j == i) {
                return true;
            }
        }

        return false;
    }

    private void drawRegionGrid(
            float f,
            float f1,
            float f2,
            float f3,
            boolean flag,
            boolean flag1,
            float f4,
            float f5) {
        Font font = Fonts.SF_MEDIUM;
        float size = Math.max(4.5F * f5, 6.25F * f5 * f4);

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                int k = i * 9 + j;
                int l = REGION_GRID[k][0];
                int[] aint = this.advancedRegionColor(l);
                if (!flag) {
                    aint = REGION_COLORS[REGION_GRID[k][1]];
                }

                float f7 = flag1 ? 0.65F * f5 : 0.25F * f5;
                float innerX = f + (float) j * f2 + f7;
                float innerY = f1 + (float) i * f2 + f7;
                float width = f2 - f7 * 2.0F;
                int color =
                        aint == null
                                ? ColorUtils.cachedRgba(21, 18, 27, Math.round(190.0F * f3))
                                : ColorUtils.cachedRgba(
                                        aint[0], aint[1], aint[2], Math.round(225.0F * f3));
                RenderUtils.Render2D.drawRoundedRect(
                        innerX, innerY, width, width, color, Math.min(2.5F * f5, width * 0.18F));
                String string = String.valueOf(l);
                float f11 = f + (float) j * f2 + (f2 - font.measureWidth(string, size)) * 0.5F;
                float f12 =
                        f1 + (float) i * f2 + (f2 - font.getLineHeight(size)) * 0.5F - 0.35F * f5;
                ColorUtils.cachedRgba(255, 255, 255, 238);
                font.drawText(string, f11, f12, size);
            }
        }
    }

    private void drawPlayerIndicator(float f, float f1, float f2, HUDModule hUDModule) {
        float tickProgress = client.getRenderTickCounter().getTickProgress(false);
        Vec3d vec3d = client.player.getLerpedPos(tickProgress);
        double d0 = (vec3d.x + 225000.0) / 50000.0;
        double d1 = (vec3d.z + 225000.0) / 50000.0;
        if (!(d0 < 0.0) && !(d0 >= 9.0) && !(d1 < 0.0) && !(d1 >= 9.0)) {
            long nowNanos = System.nanoTime();
            float yaw = client.player.getYaw();
            if (this.trackedPlayer == client.player
                    && this.lastFrameNanos != 0L
                    && nowNanos - this.lastFrameNanos <= 500000000L) {
                float f5 = Math.min(0.05F, (float) (nowNanos - this.lastFrameNanos) / 1.0E9F);
                this.displayedYaw =
                        this.displayedYaw
                                + MathHelper.wrapDegrees(yaw - this.displayedYaw)
                                        * (1.0F - (float) Math.exp((double) (-20.0F * f5)));
            } else {
                this.displayedYaw = yaw;
                this.trackedPlayer = client.player;
            }

            this.lastFrameNanos = nowNanos;
            float f8 =
                    hUDModule.regionMapPlayerSizeSetting.getFloat()
                            * hUDModule.hudSizeSetting.getFloat();
            float f6 = f + (float) d0 * f2;
            float f7 = f1 + (float) d1 * f2;
            Gooba.getInstance()
                    .getHudManager()
                    .getTextureBatchRenderer()
                    .draw(
                            PLAYER_ARROW,
                            f6 - f8 * 0.5F,
                            f7 - f8 * 0.5F,
                            f8,
                            f8,
                            0.0F,
                            0.0F,
                            1.0F,
                            1.0F,
                            new int[] {-1, -1, -1, -1},
                            new float[] {0.0F, 0.0F, 0.0F, 0.0F},
                            1.0F,
                            this.displayedYaw + 180.0F);
        } else {
            this.lastFrameNanos = 0L;
        }
    }
}
