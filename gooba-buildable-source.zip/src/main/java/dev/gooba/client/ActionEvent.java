package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ActionEvent extends Event {
    private boolean sprintState;

    @Override
    public String toString() {
        return "ActionEvent(sprintState=" + this.isSprintState() + ")";
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        } else if (!(object instanceof ActionEvent actionEvent)) {
            return false;
        } else if (!actionEvent.canEqual(this)) {
            return false;
        } else {
            return !super.equals(object)
                    ? false
                    : this.isSprintState() == actionEvent.isSprintState();
        }
    }

    public boolean isSprintState() {
        return this.sprintState;
    }

    public ActionEvent(boolean sprintStateValue) {
        this.sprintState = sprintStateValue;
    }

    protected boolean canEqual(Object object) {
        return object instanceof ActionEvent;
    }

    public void setSprintState(boolean sprintStateValue) {
        this.sprintState = sprintStateValue;
    }

    @Override
    public int hashCode() {
        int i = super.hashCode();
        return i * 59 + (this.isSprintState() ? 79 : 97);
    }
}
