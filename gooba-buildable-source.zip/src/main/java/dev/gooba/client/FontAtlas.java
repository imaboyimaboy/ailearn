package dev.gooba.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

@Environment(EnvType.CLIENT)
public class FontAtlas {
    private float distanceRange;
    private float fontSize;
    private boolean bottomOrigin;
    private float atlasHeight;
    private static final Logger logger = LoggerFactory.getLogger("client/Font");
    final Map<String, Float> widthCache;
    private float baseline;
    private final Identifier metricsResource;

    private float atlasWidth = 512.0F;
    private final Map<Integer, GlyphMetrics> glyphs;
    private final Identifier textureResource;
    private float lineHeight;
    private final AtomicBoolean loaded;

    public float getAtlasWidth() {
        return this.atlasWidth;
    }

    private float getFloatOrDefault(JsonObject jsonobject, String text, float f) {
        return jsonobject.has(text) ? jsonobject.get(text).getAsFloat() : f;
    }

    public void ensureLoaded() {
        if (!this.loaded.get()) {
            synchronized (this) {
                if (!this.loaded.get()) {
                    this.loadMetrics();
                }
            }
        }
    }

    public Identifier getTextureResource() {
        return this.textureResource;
    }

    private void parseGlyph(JsonObject jsonobject, float f) {
        int i = -1;
        if (jsonobject.has("unicode")) {
            i = jsonobject.get("unicode").getAsInt();
        } else if (jsonobject.has("char")) {
            String characterText = jsonobject.get("char").getAsString();
            if (!characterText.isEmpty()) {
                i = characterText.codePointAt(0);
            }
        } else if (jsonobject.has("id")) {
            i = jsonobject.get("id").getAsInt();
        }

        if (i >= 0) {
            float f11 = this.getFloatOrDefault(jsonobject, "advance", 0.0F) * this.fontSize;
            if (f11 == 0.0F) {
                f11 = this.getFloatOrDefault(jsonobject, "xadvance", 0.0F);
            }

            float f1 = 0.0F;
            float f2 = 0.0F;
            float f3 = 0.0F;
            float f4 = 0.0F;
            float f5 = 0.0F;
            float f6 = 0.0F;
            if (jsonobject.has("atlasBounds")) {
                JsonObject atlasBounds = jsonobject.getAsJsonObject("atlasBounds");
                float floatOrDefault = this.getFloatOrDefault(atlasBounds, "left", 0.0F);
                float floatOrDefaultValue = this.getFloatOrDefault(atlasBounds, "bottom", 0.0F);
                float floatOrDefault2 = this.getFloatOrDefault(atlasBounds, "right", 0.0F);
                float floatOrDefault3 = this.getFloatOrDefault(atlasBounds, "top", 0.0F);
                f1 = floatOrDefault;
                f3 = floatOrDefault2 - floatOrDefault;
                f4 = floatOrDefault3 - floatOrDefaultValue;
                if (this.bottomOrigin) {
                    f2 = this.atlasHeight - floatOrDefault3;
                } else {
                    f2 = floatOrDefaultValue;
                }
            } else if (jsonobject.has("x")
                    && jsonobject.has("y")
                    && jsonobject.has("width")
                    && jsonobject.has("height")) {
                f1 = this.getFloatOrDefault(jsonobject, "x", 0.0F);
                f2 = this.getFloatOrDefault(jsonobject, "y", 0.0F);
                f3 = this.getFloatOrDefault(jsonobject, "width", 0.0F);
                f4 = this.getFloatOrDefault(jsonobject, "height", 0.0F);
            }

            if (jsonobject.has("planeBounds")) {
                JsonObject planeBounds = jsonobject.getAsJsonObject("planeBounds");
                float floatOrDefault4 = this.getFloatOrDefault(planeBounds, "left", 0.0F);
                float floatOrDefault5 = this.getFloatOrDefault(planeBounds, "bottom", 0.0F);
                float floatOrDefault6 = this.getFloatOrDefault(planeBounds, "right", 0.0F);
                float floatOrDefault7 = this.getFloatOrDefault(planeBounds, "top", 0.0F);
                f5 = floatOrDefault4 * this.fontSize;
                f6 = (this.baseline - floatOrDefault7) * this.fontSize;
            } else if (jsonobject.has("xoffset") && jsonobject.has("yoffset")) {
                f5 = this.getFloatOrDefault(jsonobject, "xoffset", 0.0F);
                f6 = this.getFloatOrDefault(jsonobject, "yoffset", 0.0F);
            }

            this.glyphs.put(
                    i,
                    new GlyphMetrics(
                            i, f1, f2, f3, f4, f5, f6, f11, this.atlasWidth, this.atlasHeight));
        }
    }

    public FontAtlas(Identifier identifier, Identifier textureResourceValue) {
        this.atlasHeight = 512.0F;
        this.fontSize = 32.0F;
        this.lineHeight = 40.0F;
        this.baseline = 0.95F;
        this.distanceRange = 4.0F;
        this.bottomOrigin = false;
        this.loaded = new AtomicBoolean(false);
        this.widthCache =
                new LinkedHashMap<String, Float>(512, 0.75F, true) {

                    @Override
                    protected boolean removeEldestEntry(Entry<String, Float> entry) {
                        return this.size() > 2048;
                    }
                };
        this.metricsResource = identifier;
        this.textureResource = textureResourceValue;
        this.glyphs = new HashMap<>();
    }

    public float getAtlasHeight() {
        return this.atlasHeight;
    }

    public float getFontSize() {
        return this.fontSize;
    }

    public float getDistanceRange() {
        return this.distanceRange;
    }

    public void preload() {
        if (!this.loaded.get()) {
            synchronized (this) {
                if (!this.loaded.get()) {
                    this.loadMetrics();
                }
            }
        }
    }

    private void parseMetrics(JsonObject jsonobject) {
        float f = 1.0F;
        if (jsonobject.has("atlas")) {
            JsonObject atlas = jsonobject.getAsJsonObject("atlas");
            this.atlasWidth = this.getFloatOrDefault(atlas, "width", 512.0F);
            this.atlasHeight = this.getFloatOrDefault(atlas, "height", 512.0F);
            this.fontSize = this.getFloatOrDefault(atlas, "size", 32.0F);
            this.distanceRange = this.getFloatOrDefault(atlas, "distanceRange", 4.0F);
            if (atlas.has("yOrigin")) {
                String yOrigin = atlas.get("yOrigin").getAsString();
                this.bottomOrigin = yOrigin.equalsIgnoreCase("bottom");
            }
        }

        if (jsonobject.has("metrics")) {
            JsonObject metrics = jsonobject.getAsJsonObject("metrics");
            f = this.getFloatOrDefault(metrics, "emSize", 1.0F);
            float floatOrDefault = this.getFloatOrDefault(metrics, "lineHeight", 1.2F);
            this.lineHeight = floatOrDefault * this.fontSize;
            float floatOrDefaultValue = this.getFloatOrDefault(metrics, "descender", 0.0F);
            this.baseline = floatOrDefault + floatOrDefaultValue;
        }

        if (jsonobject.has("glyphs")) {
            for (JsonElement jsonelement : jsonobject.getAsJsonArray("glyphs")) {
                JsonObject asJsonObject = jsonelement.getAsJsonObject();
                this.parseGlyph(asJsonObject, f);
            }
        }
    }

    public int getGlyphCount() {
        return this.glyphs.size();
    }

    private void loadMetrics() {
        try {
            Optional optional =
                    MinecraftClient.getInstance()
                            .getResourceManager()
                            .getResource(this.metricsResource);
            if (optional.isEmpty()) {
                logger.warn("Font JSON not found: {}", this.metricsResource);
                this.loaded.set(true);
                return;
            }

            try (InputStream inputstream = ((Resource) optional.get()).getInputStream();
                    InputStreamReader inputstreamreader =
                            new InputStreamReader(inputstream, StandardCharsets.UTF_8); ) {
                JsonObject jsonobject = JsonParser.parseReader(inputstreamreader).getAsJsonObject();
                this.parseMetrics(jsonobject);
                this.loaded.set(true);
            }
        } catch (Exception exception) {
            logger.error("Failed to load font: {}", this.metricsResource, exception);
            this.loaded.set(true);
        }
    }

    public GlyphMetrics getGlyphMetrics(int i) {
        return this.glyphs.get(i);
    }

    public float getLineHeight() {
        return this.lineHeight;
    }
}
