package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.Screen;

@Environment(EnvType.CLIENT)
public class ScreenOpenEvent extends CancellableEvent {
    private int windowId;
    private Screen screen;

    public ScreenOpenEvent(Screen screen, int windowIdValue) {
        this.screen = screen;
        this.windowId = windowIdValue;
    }

    public int getWindowId() {
        return this.windowId;
    }

    public Screen getScreen() {
        return this.screen;
    }
}
