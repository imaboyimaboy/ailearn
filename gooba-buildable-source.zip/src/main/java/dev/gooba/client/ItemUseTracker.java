package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.function.BiConsumer;

@Environment(EnvType.CLIENT)
public final class ItemUseTracker implements MinecraftAccess {
    private static final List<BiConsumer<PlayerEntity, ItemUseTracker.Item>> listeners =
            new ArrayList<>();
    private static final Map<UUID, Map<ItemUseTracker.Item, Long>> cooldowns = new HashMap<>();
    private static final ItemUseTracker instance = new ItemUseTracker();
    private static final Map<UUID, ItemUseTracker.Use> useStates = new HashMap<>();

    private static void removeExpiredUses(long i, Map<ItemUseTracker.Item, Long> map) {
        map.values().removeIf(olong -> olong <= i);
    }

    private static ItemUseTracker.Use createUseState(UUID uuid) {
        return new ItemUseTracker.Use();
    }

    private ItemUseTracker() {}

    private static boolean hasNoTrackedItems(Entry entry) {
        return ((Map) entry.getValue()).isEmpty();
    }

    private static Map createItemCooldowns(UUID uuid) {
        return new EnumMap<>(ItemUseTracker.Item.class);
    }

    @Environment(EnvType.CLIENT)
    public static enum Buff {
        STRENGTH("Strength", StatusEffects.STRENGTH, -43691),
        SPEED("Speed", StatusEffects.SPEED, -11141121),
        RESISTANCE("Resist", StatusEffects.RESISTANCE, -7829249),
        REGENERATION("Regena", StatusEffects.REGENERATION, -43521),
        FIRE_RESISTANCE("Fireproof", StatusEffects.FIRE_RESISTANCE, -22016),
        ABSORPTION("Absorb", StatusEffects.ABSORPTION, -171);

        public final RegistryEntry<StatusEffect> effect;
        public final String displayName;
        public final int color;

        private Buff(String stringValue, RegistryEntry registryentry, int colorValue) {
            this.displayName = stringValue;
            this.effect = registryentry;
            this.color = colorValue;
        }
    }

    @Environment(EnvType.CLIENT)
    public static enum Item {
        NOTCH("Charka", 150, Items.ENCHANTED_GOLDEN_APPLE),
        GAPPLE("Gepl", 30, Items.GOLDEN_APPLE),
        HEAL("Khilka", 20, Items.POTION),
        NAUSEA("Nausea", 60, Items.POTION),
        CHORUS("Horus", 20, Items.CHORUS_FRUIT),
        KELP("Plast", 20, Items.DRIED_KELP),
        SCRAP("Ladder", 15, Items.NETHERITE_SCRAP);

        public final String displayName;
        public final net.minecraft.item.Item item;
        public final int cooldownSeconds;

        private Item(String stringValue, int cooldownSecondsValue, net.minecraft.item.Item item) {
            this.displayName = stringValue;
            this.cooldownSeconds = cooldownSecondsValue;
            this.item = item;
        }
    }

    @Environment(EnvType.CLIENT)
    private static class Use {
        ItemStack itemStack = ItemStack.EMPTY;
    }
}
