package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@ModuleInfo(
        name = "Spawner Notifier",
        category = ModuleCategory.DONUT,
        desc = "Notifies you when a mob spawner is found.")
@Environment(EnvType.CLIENT)
public final class SpawnerNotifierModule extends Module {
    public final BooleanSetting soundSetting;
    public final BooleanSetting chatFeedbackSetting;
    private boolean soundQueued;
    public final BooleanSetting eSPSetting;
    public final BooleanSetting tracersSetting;
    private final Map<BlockPos, String> spawners;
    private int pendingCount;
    private String pendingName;
    public final ColorSetting colorSetting;
    private ExecutorService scanner;
    private final Set<ChunkPos> scannedChunks;
    public final SliderSetting tracersAlphaSetting;
    public final BooleanSetting hUDNotificationSetting =
            new BooleanSetting(this, "HUD Notification", true);
    public final ColorSetting beamsColorSetting;
    public final SliderSetting eSPAlphaSetting;
    private final Object notificationLock;
    private long soundDueMillis;
    private long notificationDueMillis;
    public final BooleanSetting spawnerBeamsSetting;
    public final SliderSetting pitchSetting;

    @Override
    protected void onDisable() {
        this.resetNotifications();
        this.spawners.clear();
        this.scannedChunks.clear();
        if (this.scanner != null) {
            this.scanner.shutdownNow();

            try {
                this.scanner.awaitTermination(1L, TimeUnit.SECONDS);
            } catch (InterruptedException interruptedexception) {
            }

            this.scanner = null;
        }
    }

    private void scanChunk(WorldChunk worldchunk) {
        if (worldchunk != null && !worldchunk.isEmpty() && client.world != null) {
            ChunkPos chunkpos = worldchunk.getPos();
            int bottomY = worldchunk.getBottomY();
            int j = bottomY + worldchunk.getHeight();
            int startX = chunkpos.getStartX();
            int startZ = chunkpos.getStartZ();
            Mutable mutable = new Mutable();

            for (int i1 = 0; i1 < 16; i1++) {
                for (int j1 = 0; j1 < 16; j1++) {
                    for (int bottomYValue = bottomY; bottomYValue < j; bottomYValue++) {
                        mutable.set(startX + i1, bottomYValue, startZ + j1);
                        if (worldchunk.getBlockState(mutable).isOf(Blocks.SPAWNER)) {
                            BlockPos blockpos = mutable.toImmutable();
                            String text = this.getSpawnerType(worldchunk.getBlockEntity(blockpos));
                            this.recordSpawner(blockpos, text);
                        }
                    }
                }
            }
        }
    }

    private String spawnerTypeAt(BlockPos blockpos) {
        if (client.world == null) {
            return "Unknown";
        } else {
            try {
                BlockEntity blockentity = client.world.getBlockEntity(blockpos);
                return this.getSpawnerType(blockentity);
            } catch (Exception exception) {
                return "Unknown";
            }
        }
    }

    private void queueNotification(String stringValue) {
        synchronized (this.notificationLock) {
            if (this.pendingCount == 0) {
                this.pendingName = stringValue;
            }

            this.pendingCount++;
            this.notificationDueMillis = System.currentTimeMillis() + 250L;
        }
    }

    private void resetNotifications() {
        synchronized (this.notificationLock) {
            this.pendingName = null;
            this.pendingCount = 0;
            this.notificationDueMillis = 0L;
            this.soundQueued = false;
            this.soundDueMillis = 0L;
        }
    }

    private String getSpawnerType(BlockEntity blockentity) {
        if (blockentity instanceof MobSpawnerBlockEntity mobspawnerblockentity
                && client.world != null) {
            try {
                NbtCompound nbtcompound =
                        mobspawnerblockentity.createNbt(client.world.getRegistryManager());
                return this.readSpawnerType(nbtcompound);
            } catch (Exception exception) {
                return "Unknown";
            }
        }

        return "Unknown";
    }

    private void flushNotifications() {
        boolean flagx = false;
        String text;
        int i;
        synchronized (this.notificationLock) {
            long nowMillis = System.currentTimeMillis();
            if (this.pendingCount > 0 && nowMillis >= this.notificationDueMillis) {
                text = this.pendingName;
                i = this.pendingCount;
                this.pendingName = null;
                this.pendingCount = 0;
                this.notificationDueMillis = 0L;
            } else {
                text = null;
                i = 0;
            }

            if (this.soundQueued && nowMillis >= this.soundDueMillis) {
                this.soundQueued = false;
                this.soundDueMillis = 0L;
                flagx = true;
            }
        }

        if (text != null && this.hUDNotificationSetting.isOn()) {
            NotificationManager.showItem(
                    text + " Found!: " + i + " Spawner(s) detected",
                    NotificationManager.Type.INFO,
                    new ItemStack(Blocks.SPAWNER));
        }

        if (flagx && this.soundSetting.isOn() && client.player != null) {
            try {
                client.player.playSound(
                        SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(),
                        1.0F,
                        this.pitchSetting.getFloat());
            } catch (Exception exception) {
            }
        }
    }

    public SpawnerNotifierModule() {
        this.chatFeedbackSetting = new BooleanSetting(this, "Chat Feedback", false);
        this.soundSetting = new BooleanSetting(this, "Sound", true);
        this.pitchSetting = new SliderSetting(this, "Pitch", 0.5F, 0.0F, 2.0F, 0.1F);
        this.eSPSetting = new BooleanSetting(this, "ESP", true);
        this.eSPAlphaSetting = new SliderSetting(this, "ESP Alpha", 128.0F, 0.0F, 255.0F, 1.0F);
        this.tracersSetting = new BooleanSetting(this, "Tracers", true);
        this.tracersAlphaSetting =
                new SliderSetting(this, "Tracers Alpha", 235.0F, 0.0F, 255.0F, 1.0F);
        this.spawnerBeamsSetting = new BooleanSetting(this, "Spawner Beams", false);
        this.beamsColorSetting = new ColorSetting(this, "Beams Color", 1350574335);
        this.colorSetting = new ColorSetting(this, "Color", -7700826);
        this.spawners = new ConcurrentHashMap<>();
        this.scannedChunks = ConcurrentHashMap.newKeySet();
        this.notificationLock = new Object();
    }

    private void queueSound() {
        synchronized (this.notificationLock) {
            this.soundQueued = true;
            this.soundDueMillis = System.currentTimeMillis() + 250L;
        }
    }

    private String formatEntityName(String text) {
        if (text != null && !text.isEmpty()) {
            String textValue = text;
            int i = text.indexOf(58);
            if (i >= 0) {
                textValue = text.substring(i + 1);
            }

            String[] astring = textValue.split("_");
            StringBuilder stringbuilder = new StringBuilder();

            for (int j = 0; j < astring.length; j++) {
                if (j > 0) {
                    stringbuilder.append(' ');
                }

                if (!astring[j].isEmpty()) {
                    stringbuilder.append(Character.toUpperCase(astring[j].charAt(0)));
                    if (astring[j].length() > 1) {
                        stringbuilder.append(astring[j].substring(1));
                    }
                }
            }

            String text2 = stringbuilder.toString().trim();
            return text2.isEmpty() ? "Unknown" : text2;
        } else {
            return "Unknown";
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null) {
            if (this.scanner != null && !this.scanner.isShutdown()) {
                int value = client.options.getViewDistance().getValue();
                ChunkPos chunkpos = client.player.getChunkPos();

                for (int j = chunkpos.x - value; j <= chunkpos.x + value; j++) {
                    for (int k = chunkpos.z - value; k <= chunkpos.z + value; k++) {
                        ChunkPos chunkPos = new ChunkPos(j, k);
                        if (!this.scannedChunks.contains(chunkPos)
                                && client.world.isChunkLoaded(j, k)) {
                            WorldChunk worldchunk =
                                    client.world.getChunkManager().getWorldChunk(j, k, false);
                            if (worldchunk != null) {
                                this.scannedChunks.add(chunkPos);
                                this.scanner.submit(() -> this.scanChunk(worldchunk));
                            }
                        }
                    }
                }
            }

            double d0 = 1048576.0;
            this.spawners
                    .keySet()
                    .removeIf(
                            blockpos -> {
                                double d1 = client.player.getX() - ((double) blockpos.getX() + 0.5);
                                double d2 = client.player.getY() - ((double) blockpos.getY() + 0.5);
                                double d3 = client.player.getZ() - ((double) blockpos.getZ() + 0.5);
                                boolean flagx = d1 * d1 + d2 * d2 + d3 * d3 > d0;
                                boolean flag1 =
                                        client.world != null
                                                && client.world.isChunkLoaded(
                                                        blockpos.getX() >> 4, blockpos.getZ() >> 4)
                                                && !this.isLoadedSpawner(blockpos);
                                return flagx || flag1;
                            });
            this.scannedChunks.removeIf(
                    chunkposx -> {
                        int ix = Math.abs(chunkposx.x - client.player.getChunkPos().x);
                        int jx = Math.abs(chunkposx.z - client.player.getChunkPos().z);
                        return ix > client.options.getViewDistance().getValue() + 2
                                || jx > client.options.getViewDistance().getValue() + 2;
                    });

            for (Entry entry : this.spawners.entrySet()) {
                if ("Unknown".equals(entry.getValue())) {
                    String stringValue = this.spawnerTypeAt((BlockPos) entry.getKey());
                    if (!"Unknown".equals(stringValue)) {
                        entry.setValue(stringValue);
                    }
                }
            }

            this.flushNotifications();
        }
    }

    public String displayName(String text) {
        return !"Unknown".equals(text) ? text : "Spawner";
    }

    private void recordSpawner(BlockPos blockpos, String text) {
        if (text == null) {
            text = "Unknown";
        }

        if (!this.spawners.containsKey(blockpos)) {
            this.spawners.put(blockpos, text);
            String stringValue = this.displayName(text);
            if (this.isEnabled()) {
                if (this.hUDNotificationSetting.isOn()) {
                    this.queueNotification(stringValue);
                }

                if (this.chatFeedbackSetting.isOn() && client.player != null) {
                    ClientPlayerEntity clientplayerentity = client.player;
                    int l = blockpos.getX();
                    int k = blockpos.getZ();
                    int j = blockpos.getY();
                    int i = l;
                    clientplayerentity.sendMessage(
                            Text.literal(
                                    "§7[§dSpawner Notifier§7] §fFound §d"
                                            + stringValue
                                            + "§f at §e"
                                            + i
                                            + ", "
                                            + j
                                            + ", "
                                            + k),
                            false);
                }

                if (this.soundSetting.isOn()) {
                    this.queueSound();
                }
            }
        } else if (!"Unknown".equals(text)) {
            this.spawners.put(blockpos, text);
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && client.world != null && !this.spawners.isEmpty()) {
            int i = Math.max(0, Math.min(255, Math.round(this.eSPAlphaSetting.getFloat())));
            int j = Math.max(0, Math.min(255, Math.round(this.tracersAlphaSetting.getFloat())));
            int k = i << 24 | this.colorSetting.getColor() & 16777215;
            WorldEspRenderer.clear();

            for (BlockPos blockpos : this.spawners.keySet()) {
                if (this.isLoadedSpawner(blockpos)) {
                    if (this.eSPSetting.isOn()) {
                        Box box =
                                new Box(
                                        (double) blockpos.getX(),
                                        (double) blockpos.getY(),
                                        (double) blockpos.getZ(),
                                        (double) blockpos.getX() + 1.0,
                                        (double) blockpos.getY() + 1.0,
                                        (double) blockpos.getZ() + 1.0);
                        WorldEspRenderer.enqueueBox(box, k, j, this.tracersSetting.isOn());
                    }

                    if (this.spawnerBeamsSetting.isOn()) {
                        double d2 = 0.125;
                        double d0 = (double) blockpos.getX() + 0.5;
                        double d1 = (double) blockpos.getZ() + 0.5;
                        Box boxValue =
                                new Box(
                                        d0 - d2,
                                        (double) blockpos.getY() + 1.0,
                                        d1 - d2,
                                        d0 + d2,
                                        320.0,
                                        d1 + d2);
                        WorldEspRenderer.enqueueBox(
                                boxValue, this.beamsColorSetting.getColor(), false);
                    }
                }
            }

            WorldEspRenderer.flush(render3DEvent.getMatrixStack());
        }
    }

    @Override
    protected void onEnable() {
        this.spawners.clear();
        this.scannedChunks.clear();
        this.resetNotifications();
        this.scanner =
                Executors.newSingleThreadExecutor(
                        runnable -> {
                            Thread thread = new Thread(runnable, "SpawnerNotifier-Scanner");
                            thread.setDaemon(true);
                            return thread;
                        });
        if (client.world != null && client.player != null) {
            int value = client.options.getViewDistance().getValue();
            ChunkPos chunkpos = client.player.getChunkPos();

            for (int j = chunkpos.x - value; j <= chunkpos.x + value; j++) {
                for (int k = chunkpos.z - value; k <= chunkpos.z + value; k++) {
                    if (client.world.isChunkLoaded(j, k)) {
                        WorldChunk worldchunk = client.world.getChunk(j, k);
                        if (worldchunk != null) {
                            this.scanner.submit(() -> this.scanChunk(worldchunk));
                        }
                    }
                }
            }
        }
    }

    public boolean isLoadedSpawner(BlockPos blockpos) {
        return client.world != null
                && client.world.isChunkLoaded(blockpos.getX() >> 4, blockpos.getZ() >> 4)
                && client.world.getBlockState(blockpos).isOf(Blocks.SPAWNER);
    }

    @EventHandler
    public void onBlockUpdate(BlockUpdateEvent blockUpdateEvent) {
        BlockPos blockpos = blockUpdateEvent.getPos();
        BlockPos blockposValue = blockpos.toImmutable();
        if (blockUpdateEvent.getState().isOf(Blocks.SPAWNER)) {
            String stringValue = this.spawnerTypeAt(blockpos);
            this.recordSpawner(blockposValue, stringValue);
        } else {
            this.spawners.remove(blockposValue);
        }
    }

    private String readSpawnerType(NbtCompound nbtcompound) {
        if (nbtcompound == null) {
            return "Unknown";
        } else {
            try {
                if (nbtcompound.contains("SpawnData")) {
                    NbtCompound nbtCompound = nbtcompound.getCompound("SpawnData").orElse(null);
                    if (nbtCompound != null && nbtCompound.contains("entity")) {
                        NbtCompound nbtCompoundValue =
                                nbtCompound.getCompound("entity").orElse(null);
                        if (nbtCompoundValue != null && nbtCompoundValue.contains("id")) {
                            String text = nbtCompoundValue.getString("id").orElse(null);
                            if (text != null) {
                                return this.formatEntityName(text);
                            }
                        }
                    }
                }

                if (nbtcompound.contains("SpawnPotentials")) {
                    NbtList nbtlist = nbtcompound.getList("SpawnPotentials").orElse(null);
                    if (nbtlist != null && !nbtlist.isEmpty()) {
                        NbtElement nbtelement = (NbtElement) nbtlist.get(0);
                        if (nbtelement instanceof NbtCompound nbtCompound2
                                && nbtCompound2.contains("data")) {
                            NbtCompound nbtCompound3 =
                                    nbtCompound2.getCompound("data").orElse(null);
                            if (nbtCompound3 != null && nbtCompound3.contains("entity")) {
                                NbtCompound nbtCompound4 =
                                        nbtCompound3.getCompound("entity").orElse(null);
                                if (nbtCompound4 != null && nbtCompound4.contains("id")) {
                                    String textValue = nbtCompound4.getString("id").orElse(null);
                                    if (textValue != null) {
                                        return this.formatEntityName(textValue);
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception exception) {
            }

            return "Unknown";
        }
    }
}
