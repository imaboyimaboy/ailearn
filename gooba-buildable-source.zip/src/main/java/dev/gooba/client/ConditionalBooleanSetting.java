package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class ConditionalBooleanSetting extends Setting<Boolean> {
    private Boolean cachedValue;

    public Boolean isOn() {
        if (this.cachedValue == null) {
            this.cachedValue = (Boolean) super.getValue();
        }

        return (this.cachedValue && this.getVisibility().get());
    }

    public ConditionalBooleanSetting onChange(Runnable runnable) {
        return (ConditionalBooleanSetting)
                super.onChange(
                        () -> {
                            runnable.run();
                            if ((Boolean) super.getValue() && this.getVisibility().get()) {
                                this.cachedValue = true;
                            } else {
                                this.cachedValue = false;
                            }
                        });
    }

    public ConditionalBooleanSetting setValue(Boolean obool) {
        if (obool && this.getVisibility().get()) {
            this.cachedValue = true;
        } else {
            this.cachedValue = false;
        }

        return (ConditionalBooleanSetting) super.setValue(obool);
    }

    public ConditionalBooleanSetting visibleWhen(Supplier supplier) {
        return (ConditionalBooleanSetting) super.visibleWhen(supplier);
    }

    public ConditionalBooleanSetting(Module moduleValue, String nameValue, Boolean boolean_) {
        super(moduleValue, nameValue, boolean_);
        this.cachedValue = boolean_;
    }

    public ConditionalBooleanSetting(String nameValue, Boolean boolean_) {
        super(nameValue, boolean_);
        this.cachedValue = boolean_;
    }
}
