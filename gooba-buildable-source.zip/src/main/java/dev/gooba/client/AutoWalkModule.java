package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
        name = "Auto Walk",
        category = ModuleCategory.OTHER,
        desc = "Automatically walks in a selected direction.")
@Environment(EnvType.CLIENT)
public class AutoWalkModule extends Module {
    public final BooleanSetting sprintSetting;
    public final ModeSetting directionSetting =
            new ModeSetting(
                    this,
                    "Direction",
                    new String[] {"Forwards", "Forwards", "Backwards", "Left", "Right"});

    @Override
    protected void onDisable() {
        this.releaseMovementKeys();
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null && client.currentScreen == null) {
            this.releaseMovementKeys();
            String string = this.directionSetting.getSelectedMode();
            switch (string.hashCode()) {
                case -934227760:
                    if (string.equals("Backwards")) {
                        client.options.backKey.setPressed(true);
                        client.options.sprintKey.setPressed(this.sprintSetting.isOn());
                        return;
                    }
                    break;
                case 2364455:
                    if (string.equals("Left")) {
                        client.options.leftKey.setPressed(true);
                        client.options.sprintKey.setPressed(this.sprintSetting.isOn());
                        return;
                    }
                    break;
                case 78959100:
                    if (string.equals("Right")) {
                        client.options.rightKey.setPressed(true);
                        client.options.sprintKey.setPressed(this.sprintSetting.isOn());
                        return;
                    }
            }

            client.options.forwardKey.setPressed(true);
            client.options.sprintKey.setPressed(this.sprintSetting.isOn());
        }
    }

    private void releaseMovementKeys() {
        client.options.forwardKey.setPressed(false);
        client.options.backKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
        client.options.sprintKey.setPressed(false);
    }

    public AutoWalkModule() {
        this.sprintSetting = new BooleanSetting(this, "Sprint", false);
    }
}
