package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Environment(EnvType.CLIENT)
public final class DiscordPresenceManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("Goobaa/Discord");
    private static final String APPLICATION_ID = "1535976126726275094";
    private static final String LARGE_IMAGE =
            "https://i.ibb.co/Cs3x5YTL/4d1f7f9b-63ee-4b4f-9faf-d67fb5ed11db.png";
    private final DiscordRichPresence presence = new DiscordRichPresence();
    private DiscordRpcLibrary library;
    private DiscordEventHandlers handlers;
    private ScheduledExecutorService worker;
    private volatile boolean connected;

    public synchronized void start() {
        if (worker != null) return;
        library = DiscordRpcLibrary.Loader.getDiscordRpcLibrary();
        if (library == null) return;
        handlers = new DiscordEventHandlers();
        handlers.ready =
                user -> {
                    connected = true;
                    LOGGER.info("Discord presence connected.");
                };
        handlers.disconnected =
                (code, message) -> {
                    connected = false;
                    LOGGER.warn("Discord presence disconnected ({}): {}", code, message);
                };
        handlers.errored =
                (code, message) -> LOGGER.warn("Discord presence error ({}): {}", code, message);
        try {
            library.Discord_Initialize(APPLICATION_ID, handlers, true, "");
            presence.startTimestamp = System.currentTimeMillis() / 1000L;
            presence.largeImageKey = LARGE_IMAGE;
            presence.largeImageText = "Goobaa - 1.21.11";
            updatePresence();
            worker =
                    Executors.newSingleThreadScheduledExecutor(
                            task -> {
                                Thread thread = new Thread(task, "Goobaa-Discord-Presence");
                                thread.setDaemon(true);
                                return thread;
                            });
            worker.scheduleWithFixedDelay(this::poll, 0, 2, TimeUnit.SECONDS);
            LOGGER.info("Discord presence started.");
        } catch (RuntimeException | LinkageError failure) {
            LOGGER.error("Unable to start Discord presence.", failure);
            stop();
        }
    }

    private synchronized void poll() {
        if (worker == null) return;
        try {
            library.Discord_RunCallbacks();
            updatePresence();
        } catch (RuntimeException | LinkageError failure) {
            LOGGER.error("Discord presence update failed.", failure);
            stop();
        }
    }

    private void updatePresence() {
        String serverAddress = ServerInfo.serverAddress;
        presence.details =
                serverAddress == null
                                || serverAddress.isBlank()
                                || serverAddress.equalsIgnoreCase("Vanilla")
                                || serverAddress.equalsIgnoreCase("Local")
                        ? "Lobby"
                        : serverAddress;
        presence.state = null;
        DiscordPresenceModule module =
                Gooba.getInstance().getModuleRegistry().findModule(DiscordPresenceModule.class);
        boolean showButtons = module != null && module.showButtonsSetting.isOn();
        String firstLabel = showButtons ? module.button1LabelSetting.getText() : null;
        String firstUrl = showButtons ? module.button1URLSetting.getText() : null;
        String secondLabel = showButtons ? module.button2LabelSetting.getText() : null;
        String secondUrl = showButtons ? module.button2URLSetting.getText() : null;
        boolean firstButtonVisible = hasText(firstLabel) && hasText(firstUrl);
        boolean secondButtonVisible = hasText(secondLabel) && hasText(secondUrl);
        presence.button_label_1 = firstButtonVisible ? truncateLabel(firstLabel) : null;
        presence.button_url_1 = firstButtonVisible ? firstUrl : null;
        presence.button_label_2 = secondButtonVisible ? truncateLabel(secondLabel) : null;
        presence.button_url_2 = secondButtonVisible ? secondUrl : null;
        library.Discord_UpdatePresence(presence);
    }

    private static boolean hasText(String text) {
        return text != null && !text.isBlank();
    }

    private static String truncateLabel(String label) {
        return label.substring(0, Math.min(label.length(), 31));
    }

    public boolean isConnected() {
        return connected;
    }

    public synchronized boolean isRunning() {
        return worker != null;
    }

    public synchronized void stop() {
        if (worker != null) {
            worker.shutdownNow();
            worker = null;
        }
        connected = false;
        if (library != null) {
            try {
                library.Discord_ClearPresence();
            } catch (RuntimeException | LinkageError failure) {
                LOGGER.warn("Unable to clear Discord presence.", failure);
            } finally {
                try {
                    library.Discord_Shutdown();
                } catch (RuntimeException | LinkageError failure) {
                    LOGGER.warn("Unable to shut down Discord presence.", failure);
                }
                library = null;
                handlers = null;
            }
        }
    }
}
