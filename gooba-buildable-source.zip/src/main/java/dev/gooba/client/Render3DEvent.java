package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;

@Environment(EnvType.CLIENT)
public class Render3DEvent extends Event {
    private final MatrixStack matrixStack;
    private final float tickDelta;

    public MatrixStack getMatrixStack() {
        return this.matrixStack;
    }

    public float getTickDelta() {
        return this.tickDelta;
    }

    public Render3DEvent(MatrixStack matrixstack, float tickDeltaValue) {
        this.matrixStack = matrixstack;
        this.tickDelta = tickDeltaValue;
    }
}
