package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public final class ChunkBlockScanner implements MinecraftAccess {

    public static List<BlockPos> findBlocks(int i, Predicate<BlockState> predicate) {
        ArrayList arraylist = new ArrayList();
        if (client.world != null && client.player != null && i > 0) {
            ChunkPos chunkpos = client.player.getChunkPos();
            int j = Math.max(2, client.options.getClampedViewDistance()) + 3;

            for (int k = chunkpos.x - j; k <= chunkpos.x + j; k++) {
                for (int l = chunkpos.z - j; l <= chunkpos.z + j; l++) {
                    if (client.world.isChunkLoaded(k, l)) {
                        WorldChunk worldchunk = client.world.getChunk(k, l);
                        ChunkSection[] achunksection = worldchunk.getSectionArray();
                        int startX = worldchunk.getPos().getStartX();
                        int startZ = worldchunk.getPos().getStartZ();

                        for (int k1 = 0; k1 < achunksection.length; k1++) {
                            ChunkSection chunksection = achunksection[k1];
                            int l1 = worldchunk.getBottomY() + (k1 << 4);
                            if (!chunksection.isEmpty() && chunksection.hasAny(predicate)) {
                                for (int i2 = 0; i2 < 16; i2++) {
                                    int j2 = l1 + i2;

                                    for (int k2 = 0; k2 < 16; k2++) {
                                        int l2 = startX + k2;

                                        for (int i3 = 0; i3 < 16; i3++) {
                                            int j3 = startZ + i3;
                                            if (predicate.test(
                                                    chunksection.getBlockState(k2, i2, i3))) {
                                                arraylist.add(new BlockPos(l2, j2, j3));
                                                if (arraylist.size() >= i) {
                                                    return arraylist;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return arraylist;
        } else {
            return arraylist;
        }
    }

    private ChunkBlockScanner() {}
}
