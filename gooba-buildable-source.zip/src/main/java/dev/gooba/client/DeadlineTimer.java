package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class DeadlineTimer {
    private long startedAtMillis = -1L;

    public boolean hasElapsed(double durationMillis) {
        return (double) (System.currentTimeMillis() - this.startedAtMillis) >= durationMillis;
    }

    public DeadlineTimer() {
        this.startedAtMillis = System.currentTimeMillis();
    }

    public long elapsedMillis() {
        return System.currentTimeMillis() - this.startedAtMillis;
    }

    public void setStartTime(long startedAtMillisValue) {
        this.startedAtMillis = startedAtMillisValue;
    }
}
