package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class MoveEvent extends Event {
    private Vec3d movement;

    @Override
    public String toString() {
        return "MoveEvent(movement=" + this.getMovement() + ")";
    }

    public Vec3d getMovement() {
        return this.movement;
    }

    protected boolean canEqual(Object object) {
        return object instanceof MoveEvent;
    }

    public MoveEvent(Vec3d vec3d) {
        this.movement = vec3d;
    }

    public void setMovement(Vec3d vec3d) {
        this.movement = vec3d;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        } else if (!(object instanceof MoveEvent moveEvent)) {
            return false;
        } else if (!moveEvent.canEqual(this)) {
            return false;
        } else {
            Vec3d vec3d = this.getMovement();
            Vec3d vec3d1 = moveEvent.getMovement();
            return vec3d == null ? vec3d1 == null : vec3d.equals(vec3d1);
        }
    }

    @Override
    public int hashCode() {
        byte b0 = 1;
        Vec3d vec3d = this.getMovement();
        return b0 * 59 + (vec3d == null ? 43 : vec3d.hashCode());
    }
}
