package dev.gooba.client;

import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;

import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public class HandEffectFramebuffer {
    private FramebufferDifferenceShader framebufferDifferenceShader;
    private GpuTextureView depthAfterView;
    private int glowMode;
    private int width;
    private int outlineWidth;
    private KawaseBlur kawaseBlur;
    private GlassOutlineShader glassOutlineShader;
    private boolean burnFillMode;
    private GpuTextureView maskView;
    private float burnStrength;
    private float smokeScale;
    private float trailStrength;
    private final GpuTexture[] trailTextures = new GpuTexture[2];
    private BurnCompositeShader burnCompositeShader;
    private final MinecraftClient minecraftClient;
    private boolean burnEnabled;
    private GpuTexture depthAfter;
    private GpuTextureView sceneAfterView;
    private int tintColor;
    private static HandEffectFramebuffer instance;

    private float trailDecay;
    private GpuTextureView sceneBeforeView;
    private float flameSpeed;
    private GpuTexture depthBefore;
    private int fillColor;
    private float saturation;
    private float burnColorMix;
    private int outlineColor;
    private float blurRadius;
    private boolean captureEditorOverlay;
    private GpuTextureView depthBeforeView;
    private float smokeSpeed;
    private float flameHeight;
    private float smokeAmount;
    private float frostScale;
    private GpuTexture burnGlow;
    private boolean maskReady;
    private boolean outlineEnabled;
    private int height;
    private boolean glassEnabled;
    private boolean enabled;
    private GpuTexture mask;
    private float glassDistortion;
    private float burnRadius;
    private float crackIntensity;
    private boolean reflectionEnabled;
    private GpuTexture sceneAfter;
    private float smokeReach;
    private boolean initialized;
    private GpuTextureView burnGlowView;
    private float iceIntensity;
    private final GpuTextureView[] trailViews = new GpuTextureView[2];
    private GlassCompositeShader glassCompositeShader;
    private GpuTexture sceneBefore;
    private int trailIndex = 0;
    private float tintIntensity;
    private boolean captureReady;
    private int fireColor;
    private int blurPasses;
    private float glowStrength;
    private boolean useItemColor;

    public void setReflectionEnabled(boolean reflectionEnabledValue) {
        this.reflectionEnabled = reflectionEnabledValue;
    }

    public void setOutlineWidth(int outlineWidthValue) {
        this.outlineWidth = outlineWidthValue;
    }

    public void setGlowColors(int fillColorValue) {
        this.fillColor = fillColorValue;
        this.outlineColor = fillColorValue;
    }

    public void setSaturation(float saturationValue) {
        this.saturation = saturationValue;
    }

    private void initialize() {

        if (!this.initialized) {
            if (this.kawaseBlur != null) {
                this.kawaseBlur.close();
            }

            if (this.glassCompositeShader != null) {
                this.glassCompositeShader.close();
            }

            if (this.framebufferDifferenceShader != null) {
                this.framebufferDifferenceShader.close();
            }

            if (this.glassOutlineShader != null) {
                this.glassOutlineShader.close();
            }

            if (this.burnCompositeShader != null) {
                this.burnCompositeShader.close();
            }

            this.kawaseBlur = new KawaseBlur();
            this.glassCompositeShader = new GlassCompositeShader();
            this.framebufferDifferenceShader = new FramebufferDifferenceShader();
            this.glassOutlineShader = new GlassOutlineShader();
            this.burnCompositeShader = new BurnCompositeShader();
            this.width = 0;
            this.height = 0;
            this.initialized = true;
        }
    }

    public void captureAfterHands() {
        if (this.enabled && this.captureReady) {
            Framebuffer framebuffer = this.minecraftClient.getFramebuffer();
            if (framebuffer != null && framebuffer.getColorAttachment() != null) {
                CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
                commandencoder.copyTextureToTexture(
                        framebuffer.getColorAttachment(),
                        this.sceneAfter,
                        0,
                        0,
                        0,
                        0,
                        0,
                        this.width,
                        this.height);
                if (framebuffer.getDepthAttachment() != null) {
                    commandencoder.copyTextureToTexture(
                            framebuffer.getDepthAttachment(),
                            this.depthAfter,
                            0,
                            0,
                            0,
                            0,
                            0,
                            this.width,
                            this.height);
                }
            }
        }
    }

    public void setBurnEnabled(boolean burnEnabledValue) {
        this.burnEnabled = burnEnabledValue;
    }

    public void captureBeforeHands() {
        if (this.enabled) {
            this.initialize();
            Framebuffer framebuffer = this.minecraftClient.getFramebuffer();
            if (framebuffer != null && framebuffer.getColorAttachment() != null) {
                int textureWidth = framebuffer.textureWidth;
                int textureHeight = framebuffer.textureHeight;
                this.resize(textureWidth, textureHeight);
                CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
                commandencoder.copyTextureToTexture(
                        framebuffer.getColorAttachment(),
                        this.sceneBefore,
                        0,
                        0,
                        0,
                        0,
                        0,
                        textureWidth,
                        textureHeight);
                if (framebuffer.getDepthAttachment() != null) {
                    commandencoder.copyTextureToTexture(
                            framebuffer.getDepthAttachment(),
                            this.depthBefore,
                            0,
                            0,
                            0,
                            0,
                            0,
                            textureWidth,
                            textureHeight);
                }

                this.captureReady = true;
            }
        }
    }

    public void setCrackIntensity(float crackIntensityValue) {
        this.crackIntensity = crackIntensityValue;
    }

    public static HandEffectFramebuffer getInstance() {
        if (instance == null) {
            instance = new HandEffectFramebuffer();
        }

        return instance;
    }

    public void setTintColor(int tintColorValue) {
        this.tintColor = tintColorValue;
    }

    private void resize(int widthValue, int heightValue) {
        if (widthValue != this.width || heightValue != this.height || this.sceneBefore == null) {
            this.closeTextures();
            this.sceneBefore =
                    RenderSystem.getDevice()
                            .createTexture(
                                    () -> "minecraft:glass_scene_before",
                                    13,
                                    TextureFormat.RGBA8,
                                    widthValue,
                                    heightValue,
                                    1,
                                    1);
            this.sceneBeforeView = RenderSystem.getDevice().createTextureView(this.sceneBefore);
            this.sceneAfter =
                    RenderSystem.getDevice()
                            .createTexture(
                                    () -> "minecraft:glass_scene_after",
                                    13,
                                    TextureFormat.RGBA8,
                                    widthValue,
                                    heightValue,
                                    1,
                                    1);
            this.sceneAfterView = RenderSystem.getDevice().createTextureView(this.sceneAfter);
            this.depthBefore =
                    RenderSystem.getDevice()
                            .createTexture(
                                    () -> "minecraft:glass_depth_before",
                                    13,
                                    TextureFormat.DEPTH32,
                                    widthValue,
                                    heightValue,
                                    1,
                                    1);
            this.depthBeforeView = RenderSystem.getDevice().createTextureView(this.depthBefore);
            this.depthAfter =
                    RenderSystem.getDevice()
                            .createTexture(
                                    () -> "minecraft:glass_depth_after",
                                    13,
                                    TextureFormat.DEPTH32,
                                    widthValue,
                                    heightValue,
                                    1,
                                    1);
            this.depthAfterView = RenderSystem.getDevice().createTextureView(this.depthAfter);
            this.mask =
                    RenderSystem.getDevice()
                            .createTexture(
                                    () -> "minecraft:glass_mask",
                                    13,
                                    TextureFormat.RGBA8,
                                    widthValue,
                                    heightValue,
                                    1,
                                    1);
            this.maskView = RenderSystem.getDevice().createTextureView(this.mask);
            this.burnGlow =
                    RenderSystem.getDevice()
                            .createTexture(
                                    () -> "minecraft:burn_glow",
                                    13,
                                    TextureFormat.RGBA8,
                                    widthValue,
                                    heightValue,
                                    1,
                                    1);
            this.burnGlowView = RenderSystem.getDevice().createTextureView(this.burnGlow);

            for (int k = 0; k < 2; k++) {
                int l = k;
                this.trailTextures[k] =
                        RenderSystem.getDevice()
                                .createTexture(
                                        () -> "minecraft:burn_trail_" + l,
                                        13,
                                        TextureFormat.RGBA8,
                                        widthValue,
                                        heightValue,
                                        1,
                                        1);
                this.trailViews[k] =
                        RenderSystem.getDevice().createTextureView(this.trailTextures[k]);
                CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
                RenderPass renderpass =
                        commandencoder.createRenderPass(
                                () -> "minecraft:burn_trail_clear",
                                this.trailViews[k],
                                OptionalInt.of(0));
                if (renderpass != null) {
                    renderpass.close();
                }
            }

            this.trailIndex = 0;
            this.width = widthValue;
            this.height = heightValue;
        }
    }

    public void compositeEffects() {
        if (this.enabled && this.captureReady) {
            Framebuffer framebuffer = this.minecraftClient.getFramebuffer();
            if (framebuffer != null && framebuffer.getColorAttachment() != null) {
                this.framebufferDifferenceShader.renderMask(
                        this.maskView,
                        this.sceneBeforeView,
                        this.sceneAfterView,
                        this.depthBeforeView,
                        this.depthAfterView,
                        this.width,
                        this.height);
                this.maskReady = true;
                boolean flagx;
                flagx = (this.iceIntensity > 0.001F);

                boolean flag1;
                flag1 = (this.smokeAmount > 0.001F);

                if (this.glassEnabled || flagx || flag1) {
                    GpuTextureView gputextureview;
                    if (this.glassEnabled) {
                        gputextureview =
                                this.kawaseBlur.blur(
                                        this.sceneBefore,
                                        this.sceneBeforeView,
                                        this.width,
                                        this.height,
                                        this.blurPasses,
                                        this.blurRadius);
                    } else {
                        gputextureview = this.sceneBeforeView;
                    }

                    if (gputextureview == null) {
                        this.captureReady = false;
                        return;
                    }

                    float f = this.glassEnabled ? this.saturation : 1.0F;
                    int i;
                    if (this.glassEnabled) {
                        i = this.tintColor;
                    } else {
                        i = 0;
                    }

                    float f1 = this.glassEnabled ? this.tintIntensity : 0.0F;
                    this.glassCompositeShader.render(
                            framebuffer.getColorAttachmentView(),
                            this.sceneBeforeView,
                            gputextureview,
                            this.maskView,
                            this.width,
                            this.height,
                            f,
                            this.reflectionEnabled,
                            i,
                            f1,
                            0.0F,
                            this.glassDistortion,
                            this.iceIntensity,
                            this.frostScale,
                            this.crackIntensity,
                            this.smokeAmount,
                            this.smokeScale,
                            this.smokeSpeed,
                            this.smokeReach);
                }

                if (this.outlineEnabled) {
                    this.glassOutlineShader.render(
                            this.maskView,
                            framebuffer.getColorAttachmentView(),
                            this.width,
                            this.height,
                            this.glowStrength,
                            this.outlineWidth,
                            this.glowMode,
                            this.fillColor,
                            this.outlineColor,
                            this.sceneAfterView,
                            this.useItemColor);
                }

                if (this.burnEnabled) {
                    this.burnCompositeShader.uploadUniforms(
                            this.width,
                            this.height,
                            this.burnFillMode,
                            this.burnRadius,
                            this.burnStrength,
                            this.flameSpeed,
                            this.burnColorMix,
                            this.trailDecay,
                            this.flameHeight,
                            this.flameSpeed,
                            this.trailStrength,
                            this.fireColor,
                            this.burnStrength);
                    this.burnCompositeShader.renderGlow(
                            this.burnGlowView, this.sceneAfterView, this.maskView);
                    int trailIndexValue = this.trailIndex;
                    int trailIndex2 = 1 - this.trailIndex;
                    this.burnCompositeShader.renderTrail(
                            this.trailViews[trailIndex2],
                            this.trailViews[trailIndexValue],
                            this.burnGlowView,
                            this.sceneAfterView,
                            this.maskView);
                    this.trailIndex = trailIndex2;
                    this.burnCompositeShader.composite(
                            framebuffer.getColorAttachmentView(),
                            this.maskView,
                            this.burnGlowView,
                            this.trailViews[trailIndex2]);
                }

                if (this.captureEditorOverlay && this.sceneAfter != null) {
                    RenderSystem.getDevice()
                            .createCommandEncoder()
                            .copyTextureToTexture(
                                    framebuffer.getColorAttachment(),
                                    this.sceneAfter,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    this.width,
                                    this.height);
                }

                this.captureReady = false;
            } else {
                this.captureReady = false;
            }
        }
    }

    public void setGlowStrength(float glowStrengthValue) {
        this.glowStrength = glowStrengthValue;
    }

    public void setTintIntensity(float tintIntensityValue) {
        this.tintIntensity = tintIntensityValue;
    }

    public void close() {
        this.closeTextures();
        if (this.kawaseBlur != null) {
            this.kawaseBlur.close();
        }

        if (this.glassCompositeShader != null) {
            this.glassCompositeShader.close();
        }

        if (this.framebufferDifferenceShader != null) {
            this.framebufferDifferenceShader.close();
        }

        if (this.glassOutlineShader != null) {
            this.glassOutlineShader.close();
        }

        if (this.burnCompositeShader != null) {
            this.burnCompositeShader.close();
        }

        this.kawaseBlur = null;
        this.glassCompositeShader = null;
        this.framebufferDifferenceShader = null;
        this.glassOutlineShader = null;
        this.burnCompositeShader = null;
        this.width = 0;
        this.height = 0;
        this.initialized = false;
        this.captureReady = false;
    }

    private void closeTextures() {
        if (this.sceneBeforeView != null) {
            this.sceneBeforeView.close();
            this.sceneBeforeView = null;
        }

        if (this.sceneBefore != null) {
            this.sceneBefore.close();
            this.sceneBefore = null;
        }

        if (this.sceneAfterView != null) {
            this.sceneAfterView.close();
            this.sceneAfterView = null;
        }

        if (this.sceneAfter != null) {
            this.sceneAfter.close();
            this.sceneAfter = null;
        }

        if (this.depthBeforeView != null) {
            this.depthBeforeView.close();
            this.depthBeforeView = null;
        }

        if (this.depthBefore != null) {
            this.depthBefore.close();
            this.depthBefore = null;
        }

        if (this.depthAfterView != null) {
            this.depthAfterView.close();
            this.depthAfterView = null;
        }

        if (this.depthAfter != null) {
            this.depthAfter.close();
            this.depthAfter = null;
        }

        if (this.maskView != null) {
            this.maskView.close();
            this.maskView = null;
        }

        if (this.mask != null) {
            this.mask.close();
            this.mask = null;
        }

        if (this.burnGlowView != null) {
            this.burnGlowView.close();
            this.burnGlowView = null;
        }

        if (this.burnGlow != null) {
            this.burnGlow.close();
            this.burnGlow = null;
        }

        for (int i = 0; i < 2; i++) {
            if (this.trailViews[i] != null) {
                this.trailViews[i].close();
                this.trailViews[i] = null;
            }

            if (this.trailTextures[i] != null) {
                this.trailTextures[i].close();
                this.trailTextures[i] = null;
            }
        }
    }

    public void renderEditorOverlay() {
        if (this.enabled
                && this.maskReady
                && this.sceneBefore != null
                && this.sceneAfterView != null
                && this.maskView != null
                && this.glassCompositeShader != null) {
            Framebuffer framebuffer = this.minecraftClient.getFramebuffer();
            if (framebuffer != null
                    && framebuffer.getColorAttachment() != null
                    && framebuffer.getColorAttachmentView() != null) {
                RenderBatchDispatcher.flush();
                CommandEncoder commandencoder = RenderSystem.getDevice().createCommandEncoder();
                commandencoder.copyTextureToTexture(
                        framebuffer.getColorAttachment(),
                        this.sceneBefore,
                        0,
                        0,
                        0,
                        0,
                        0,
                        this.width,
                        this.height);
                this.glassCompositeShader.render(
                        framebuffer.getColorAttachmentView(),
                        this.sceneBeforeView,
                        this.sceneAfterView,
                        this.maskView,
                        this.width,
                        this.height,
                        1.0F,
                        false,
                        0,
                        0.0F,
                        0.0F,
                        this.glassDistortion,
                        0.0F,
                        this.frostScale,
                        0.0F,
                        0.0F,
                        this.smokeScale,
                        this.smokeSpeed,
                        this.smokeReach);
                if (this.outlineEnabled && this.glassOutlineShader != null) {
                    this.glassOutlineShader.render(
                            this.maskView,
                            framebuffer.getColorAttachmentView(),
                            this.width,
                            this.height,
                            this.glowStrength,
                            this.outlineWidth,
                            this.glowMode,
                            this.fillColor,
                            this.outlineColor,
                            this.sceneAfterView,
                            this.useItemColor);
                }

                this.maskReady = false;
            } else {
                this.maskReady = false;
            }
        }
    }

    public HandEffectFramebuffer() {
        this.width = 0;
        this.height = 0;
        this.captureReady = false;
        this.maskReady = false;
        this.captureEditorOverlay = false;
        this.enabled = false;
        this.initialized = false;
        this.glassEnabled = true;
        this.blurRadius = 6.0F;
        this.blurPasses = 4;
        this.saturation = 1.0F;
        this.reflectionEnabled = true;
        this.tintColor = 0;
        this.tintIntensity = 0.1F;

        this.glassDistortion = 0.0F;
        this.iceIntensity = 0.0F;
        this.frostScale = 18.0F;
        this.crackIntensity = 0.5F;
        this.smokeAmount = 0.0F;
        this.smokeScale = 6.0F;
        this.smokeSpeed = 0.25F;
        this.smokeReach = 40.0F;
        this.burnEnabled = false;
        this.burnRadius = 15.0F;
        this.burnStrength = 1.18F;
        this.flameSpeed = 1.1F;
        this.flameHeight = 28.0F;
        this.trailDecay = 0.94F;
        this.trailStrength = 1.16F;
        this.fireColor = 16744486;
        this.burnColorMix = 0.0F;
        this.burnFillMode = false;
        this.outlineEnabled = true;
        this.glowStrength = 20.0F;
        this.fillColor = -1;
        this.outlineColor = -1;
        this.outlineWidth = 1;
        this.glowMode = 2;
        this.useItemColor = false;
        this.minecraftClient = MinecraftClient.getInstance();
        instance = this;
    }

    public void setShimmerEnabled(boolean shimmerEnabledValue) {
        if (this.glassOutlineShader != null) {
            this.glassOutlineShader.setShimmerEnabled(shimmerEnabledValue);
        }
    }

    public void setGlowMode(int glowModeValue) {
        this.glowMode = glowModeValue;
    }

    public void setCaptureEditorOverlay(boolean captureEditorOverlayValue) {
        this.captureEditorOverlay = captureEditorOverlayValue;
    }

    public void setIceIntensity(float iceIntensityValue) {
        this.iceIntensity = iceIntensityValue;
    }

    public void setGlassEnabled(boolean glassEnabledValue) {
        this.glassEnabled = glassEnabledValue;
    }

    public void setEnabled(boolean enabledValue) {
        this.enabled = enabledValue;
        if (enabledValue) {
            this.initialize();
        }
    }

    public void setSmokeAmount(float smokeAmountValue) {
        this.smokeAmount = smokeAmountValue;
    }

    public void setUseItemColor(boolean useItemColorValue) {
        this.useItemColor = useItemColorValue;
    }

    public void setOutlineEnabled(boolean outlineEnabledValue) {
        this.outlineEnabled = outlineEnabledValue;
    }

    public void setOutlineColor(int outlineColorValue) {
        this.outlineColor = outlineColorValue;
    }

    public void setFrostScale(float frostScaleValue) {
        this.frostScale = frostScaleValue;
    }
}
