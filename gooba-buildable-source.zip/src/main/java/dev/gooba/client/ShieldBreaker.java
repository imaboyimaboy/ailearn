package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;

@Environment(EnvType.CLIENT)
public final class ShieldBreaker implements MinecraftAccess {

    private ShieldBreaker() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

    public static Runnable[] swapActions(LivingEntity livingentity, boolean flag) {
        Runnable[] arunnable = new Runnable[] {() -> {}, () -> {}};
        if (flag
                && client.player != null
                && livingentity instanceof PlayerEntity playerentity
                && playerentity.isBlocking()) {
            ItemStack itemstack = playerentity.getMainHandStack();
            ItemStack offHandStack = playerentity.getOffHandStack();
            if (!itemstack.isOf(Items.SHIELD) && !offHandStack.isOf(Items.SHIELD)) {
                return arunnable;
            }

            int i = findAxeSlot();
            int selectedSlot = client.player.getInventory().getSelectedSlot();
            if (i >= 0 && i != selectedSlot) {
                arunnable[0] =
                        () -> {
                            if (client.getNetworkHandler() != null) {
                                client.getNetworkHandler()
                                        .sendPacket(new UpdateSelectedSlotC2SPacket(i));
                            }
                        };
                arunnable[1] =
                        () -> {
                            if (client.getNetworkHandler() != null) {
                                client.getNetworkHandler()
                                        .sendPacket(new UpdateSelectedSlotC2SPacket(selectedSlot));
                            }
                        };
                return arunnable;
            }

            return arunnable;
        }

        return arunnable;
    }

    public static int findAxeSlot() {
        if (client.player == null) {
            return -1;
        } else {
            for (int i = 0; i < 9; i++) {
                if (client.player.getInventory().getStack(i).getItem() instanceof AxeItem) {
                    return i;
                }
            }

            return -1;
        }
    }
}
