package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface EventListener {
    int getPriority();

    Class<?> getTarget();

    void call(Object object);

    boolean isStatic();
}
