package dev.gooba.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Environment(EnvType.CLIENT)
public class FriendManager {
    private static final Path FRIENDS_FILE = GoobaPaths.CONFIG_DIRECTORY.resolve("friends.json");
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Set<String> friends = new HashSet<>();

    public boolean removeFriend(String text) {
        boolean flag = this.friends.remove(text.toLowerCase());
        if (flag) {
            this.save();
        }

        return flag;
    }

    private void load() {
        if (Files.exists(FRIENDS_FILE)) {
            try (InputStreamReader inputstreamreader =
                    new InputStreamReader(
                            new FileInputStream(FRIENDS_FILE.toFile()), StandardCharsets.UTF_8)) {
                JsonArray jsonarray = JsonParser.parseReader(inputstreamreader).getAsJsonArray();
                this.friends.clear();
                jsonarray.forEach(
                        jsonelement -> this.friends.add(jsonelement.getAsString().toLowerCase()));
            } catch (IOException ioexception) {
            }
        }
    }

    private void save() {
        JsonArray jsonarray = new JsonArray();
        this.friends.forEach(jsonarray::add);

        try {
            Files.createDirectories(FRIENDS_FILE.getParent());
        } catch (IOException ioexception) {
            return;
        }

        try (OutputStreamWriter outputstreamwriter =
                new OutputStreamWriter(
                        new FileOutputStream(FRIENDS_FILE.toFile()), StandardCharsets.UTF_8)) {
            gson.toJson((JsonElement) jsonarray, outputstreamwriter);
        } catch (IOException ioexception) {
        }
    }

    public boolean addFriend(String text) {
        boolean flag = this.friends.add(text.toLowerCase());
        if (flag) {
            this.save();
        }

        return flag;
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        this.load();
    }

    public Set<String> getFriends() {
        return Collections.unmodifiableSet(this.friends);
    }

    public void initialize() {
        this.load();
        Gooba.getEventBus().subscribe(this);
    }

    public boolean isFriend(String text) {
        return this.friends.contains(text.toLowerCase());
    }
}
