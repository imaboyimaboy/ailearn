package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

@ModuleInfo(
        name = "Chunk Finder v2",
        category = ModuleCategory.DONUT,
        desc = "Highlights suspicious things, where green chunk appears.")
@Environment(EnvType.CLIENT)
public class ChunkFinderV2Module extends Module {
    private final AtomicInteger activeScans;
    public final SliderSetting tracersAlphaSetting;
    private static final Direction[] HORIZONTAL_DIRECTIONS =
            new Direction[] {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    public final SliderSetting scanRadiusSetting =
            new SliderSetting(this, "Scan Radius", 24.0F, 1.0F, 32.0F, 1.0F);
    private final ConcurrentHashMap<ChunkPos, Block> detectedChunks;
    public final BooleanSetting noHolesSetting;
    public final BooleanSetting blockHighlightSetting;
    private final Deque<ChunkPos> scanQueue;
    public final SliderSetting minimumVeinLengthSetting;
    private static final Block[] CANDIDATE_BLOCKS =
            new Block[] {Blocks.DIORITE, Blocks.ANDESITE, Blocks.GRAVEL, Blocks.SAND, Blocks.DIRT};
    public final SliderSetting alphaSetting;
    public final ColorSetting chunkColorSetting;
    public final BooleanSetting chatNotificationSetting;
    private ChunkPos lastPlayerChunk;
    private final ConcurrentHashMap<ChunkPos, List<BlockPos>> detectedBlocks;

    public final ColorSetting blockHighlightColorSetting;
    private ExecutorService scanner;
    public final SliderSetting chunksPerTickSetting =
            new SliderSetting(this, "Chunks Per Tick", 16.0F, 1.0F, 64.0F, 1.0F);
    public final BooleanSetting showTracersSetting;

    private void notifyDetection(Block block, ChunkPos chunkpos, List<BlockPos> list) {
        String string = blockDisplayName(block);
        int i = chunkpos.x;
        int j = chunkpos.z;
        String text;
        if (list != null && !list.isEmpty()) {
            BlockPos blockpos = (BlockPos) list.get(0);
            text =
                    String.format(
                            "§f%d §7y §f%d §7z §f%d",
                            blockpos.getX(), blockpos.getY(), blockpos.getZ());
        } else {
            text = String.format("§fcx %d cz %d", i, j);
        }

        client.execute(
                () -> {
                    if (client.player != null) {
                        client.player.playSound(
                                SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.2F, 1.2F);
                        NotificationManager.showItem(
                                "Chunk Finder v2: Chunk found!",
                                NotificationManager.Type.INFO,
                                new ItemStack(Blocks.CHEST));
                        if (this.chatNotificationSetting.isOn()) {
                            ChatMessages.send(
                                    String.format(
                                            "§a[ChunkFinder v2] §7Found §f%s §7at %s",
                                            string, text));
                        }
                    }
                });
    }

    private void queueChunk(int i, int j) {
        if (client.world != null && client.world.isChunkLoaded(i, j)) {
            ChunkPos chunkpos = new ChunkPos(i, j);
            if (!this.detectedChunks.containsKey(chunkpos)) {
                this.scanQueue.offer(chunkpos);
            }
        }
    }

    private void queueSurroundingChunks(ChunkPos chunkpos) {
        this.scanQueue.clear();
        int i = Math.max(1, Math.round(this.scanRadiusSetting.getFloat()));

        for (int j = 0; j <= i; j++) {
            for (int k = -j; k <= j; k++) {
                this.queueChunk(chunkpos.x + k, chunkpos.z - j);
                if (j != 0) {
                    this.queueChunk(chunkpos.x + k, chunkpos.z + j);
                }
            }

            for (int l = -j + 1; l < j; l++) {
                this.queueChunk(chunkpos.x - j, chunkpos.z + l);
                if (j != 0) {
                    this.queueChunk(chunkpos.x + j, chunkpos.z + l);
                }
            }
        }
    }

    private boolean containsMiningHoles(WorldChunk worldchunk) {
        if (worldchunk != null && !worldchunk.isEmpty()) {
            int startX = worldchunk.getPos().getStartX();
            int startZ = worldchunk.getPos().getStartZ();
            int bottomY = worldchunk.getBottomY();
            int l = bottomY + worldchunk.getHeight();
            Mutable mutable = new Mutable();

            for (int startXValue = startX; startXValue < startX + 16; startXValue++) {
                for (int startZValue = startZ; startZValue < startZ + 16; startZValue++) {
                    int bottomYValue = bottomY;

                    while (bottomYValue < l) {
                        mutable.set(startXValue, bottomYValue, startZValue);
                        boolean flag = false;
                        int l1 = 0;
                        if (this.isVerticalHole(worldchunk, mutable)) {
                            Mutable mutableValue =
                                    new Mutable(startXValue, bottomYValue, startZValue);

                            while (this.isVerticalHole(worldchunk, mutableValue)) {
                                mutableValue.move(Direction.UP);
                                if (mutableValue.getY() >= l) {
                                    break;
                                }
                            }

                            l1 = mutableValue.getY() - bottomYValue;
                            if (l1 >= 4) {
                                return true;
                            }

                            if (l1 > 0) {
                                flag = true;
                            }
                        }

                        if (!flag && this.isEastWestHole(worldchunk, mutable)) {
                            Mutable mutable4 = new Mutable(startXValue, bottomYValue, startZValue);

                            while (this.isEastWestHole(worldchunk, mutable4)) {
                                mutable4.move(Direction.UP);
                                if (mutable4.getY() >= l) {
                                    break;
                                }
                            }

                            l1 = mutable4.getY() - bottomYValue;
                            if (l1 >= 4) {
                                return true;
                            }

                            if (l1 > 0) {
                                flag = true;
                            }
                        }

                        if (!flag && this.isNorthSouthHole(worldchunk, mutable)) {
                            Mutable mutable5 = new Mutable(startXValue, bottomYValue, startZValue);

                            while (this.isNorthSouthHole(worldchunk, mutable5)) {
                                mutable5.move(Direction.UP);
                                if (mutable5.getY() >= l) {
                                    break;
                                }
                            }

                            l1 = mutable5.getY() - bottomYValue;
                            if (l1 >= 4) {
                                return true;
                            }

                            if (l1 > 0) {
                                flag = true;
                            }
                        }

                        if (flag && l1 > 0) {
                            bottomYValue += l1;
                        } else {
                            bottomYValue++;
                        }
                    }
                }
            }

            return false;
        } else {
            return false;
        }
    }

    private boolean isCandidateBlock(Block block) {
        for (Block blockValue : CANDIDATE_BLOCKS) {
            if (block == blockValue) {
                return true;
            }
        }

        return false;
    }

    @Override
    protected void onDisable() {
        if (this.scanner != null) {
            this.scanner.shutdownNow();

            try {
                this.scanner.awaitTermination(1L, TimeUnit.SECONDS);
            } catch (InterruptedException interruptedexception) {
            }

            this.scanner = null;
        }

        this.clearDetections();
    }

    private BlockState getBlockStateAt(WorldChunk worldchunk, BlockPos blockpos) {
        int i = blockpos.getX() >> 4;
        int j = blockpos.getZ() >> 4;
        if (i == worldchunk.getPos().x && j == worldchunk.getPos().z) {
            return worldchunk.getBlockState(blockpos);
        } else {
            return client.world != null
                    ? client.world.getBlockState(blockpos)
                    : Blocks.AIR.getDefaultState();
        }
    }

    private boolean isOpenCell(WorldChunk worldchunk, BlockPos blockpos) {
        BlockState blockstate = this.getBlockStateAt(worldchunk, blockpos);
        VoxelShape voxelshape =
                blockstate.getCollisionShape(
                        (BlockView) (client.world != null ? client.world : worldchunk.getWorld()),
                        blockpos);
        return voxelshape.isEmpty() || !VoxelShapes.fullCube().equals(voxelshape);
    }

    private void clearDetections() {
        this.scanQueue.clear();
        this.detectedChunks.clear();
        this.detectedBlocks.clear();
        this.lastPlayerChunk = null;
        this.activeScans.set(0);
    }

    @Override
    protected void onEnable() {
        this.clearDetections();
        this.scanner =
                Executors.newSingleThreadExecutor(
                        runnable -> {
                            Thread thread = new Thread(runnable, "Goobaa-ChunkFinderV2-Scanner");
                            thread.setDaemon(true);
                            return thread;
                        });
    }

    private void recordDetection(ChunkPos chunkpos, Block block, List<BlockPos> list) {
        boolean flag;
        flag = (this.detectedChunks.putIfAbsent(chunkpos, block) == null);

        if (flag) {
            this.detectedBlocks.put(chunkpos, list);
            this.notifyDetection(block, chunkpos, list);
        }
    }

    public ChunkFinderV2Module() {
        this.minimumVeinLengthSetting =
                new SliderSetting(this, "Minimum Vein Length", 5.0F, 2.0F, 21.0F, 1.0F);
        this.noHolesSetting = new BooleanSetting(this, "No Holes", false);
        this.chatNotificationSetting = new BooleanSetting(this, "Chat Notification", true);
        this.blockHighlightSetting = new BooleanSetting(this, "Block Highlight", false);
        this.blockHighlightColorSetting = new ColorSetting(this, "Block Highlight Color", 16720418);
        this.chunkColorSetting = new ColorSetting(this, "Chunk Color", 65280);
        this.alphaSetting = new SliderSetting(this, "Alpha", 40.0F, 0.0F, 255.0F, 1.0F);
        this.showTracersSetting = new BooleanSetting(this, "Show Tracers", false);
        this.tracersAlphaSetting =
                new SliderSetting(this, "Tracers Alpha", 70.0F, 0.0F, 255.0F, 1.0F);
        this.scanQueue = new ArrayDeque<>();
        this.detectedChunks = new ConcurrentHashMap<>();
        this.detectedBlocks = new ConcurrentHashMap<>();
        this.activeScans = new AtomicInteger(0);
    }

    private void submitScan(WorldChunk worldchunk) {
        if (this.scanner != null && !this.scanner.isShutdown()) {
            this.activeScans.incrementAndGet();
            this.scanner.submit(new ChunkFinderV2Module.ScanRunnable(worldchunk));
        }
    }

    private static boolean isRiverBiome(RegistryEntry<Biome> registryentry) {
        if (registryentry == null) {
            return false;
        } else {
            try {
                return registryentry.matchesKey(BiomeKeys.RIVER);
            } catch (Throwable throwable) {
                return false;
            }
        }
    }

    @EventHandler
    public void onRender3D(Render3DEvent render3DEvent) {
        if (client.player != null && !this.detectedChunks.isEmpty()) {
            int integer = this.chunkColorSetting.getColor();
            int alpha = Math.round(this.alphaSetting.getFloat());
            int k = ColorUtils.withAlpha(integer, alpha);
            WorldEspRenderer.clear();

            for (Entry entry : this.detectedChunks.entrySet()) {
                ChunkPos chunkpos = (ChunkPos) entry.getKey();
                Box box =
                        new Box(
                                (double) chunkpos.getStartX(),
                                60.0,
                                (double) chunkpos.getStartZ(),
                                (double) chunkpos.getStartX() + 16.0,
                                60.05,
                                (double) chunkpos.getStartZ() + 16.0);
                WorldEspRenderer.enqueueBox(box, k, this.showTracersSetting.isOn());
            }

            if (this.blockHighlightSetting.isOn()) {
                int integerValue = this.blockHighlightColorSetting.getColor();
                int i1 = ColorUtils.withAlpha(integerValue, Math.max(85, alpha));

                for (List list : this.detectedBlocks.values()) {
                    if (list != null) {
                        for (BlockPos blockpos : (Iterable<BlockPos>) (Iterable) list) {
                            Box boxValue =
                                    new Box(
                                            (double) blockpos.getX(),
                                            (double) blockpos.getY(),
                                            (double) blockpos.getZ(),
                                            (double) blockpos.getX() + 1.0,
                                            (double) blockpos.getY() + 1.0,
                                            (double) blockpos.getZ() + 1.0);
                            WorldEspRenderer.enqueueBox(boxValue, i1, false);
                        }
                    }
                }
            }

            WorldEspRenderer.flush(render3DEvent.getMatrixStack());
        }
    }

    private static String blockDisplayName(Block block) {
        if (block == Blocks.DIORITE) {
            return "Diorite";
        } else if (block == Blocks.ANDESITE) {
            return "Andesite";
        } else if (block == Blocks.GRAVEL) {
            return "Gravel";
        } else if (block == Blocks.SAND) {
            return "Sand";
        } else if (block == Blocks.DIRT) {
            return "Dirt";
        } else {
            return block == Blocks.CLAY ? "Clay (River)" : "Unknown";
        }
    }

    private boolean isCandidateAt(Block block, BlockPos blockpos) {
        if (client.world == null) {
            return this.isCandidateBlock(block);
        } else if (block == Blocks.CLAY) {
            return isRiverBiome(client.world.getBiome(blockpos));
        } else if (block == Blocks.SAND) {
            return !isDesertBiome(client.world.getBiome(blockpos)) && blockpos.getY() < 50;
        } else {
            return block == Blocks.DIRT ? blockpos.getY() < 50 : this.isCandidateBlock(block);
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null && client.world != null) {
            ChunkPos chunkpos = client.player.getChunkPos();
            if (this.lastPlayerChunk == null
                    || !this.lastPlayerChunk.equals(chunkpos)
                    || this.scanQueue.isEmpty() && this.activeScans.get() == 0) {
                this.lastPlayerChunk = chunkpos;
                this.queueSurroundingChunks(chunkpos);
            }

            int i = Math.max(1, Math.round(this.chunksPerTickSetting.getFloat()));
            int j = i * 2;
            int k = 0;

            while (k < i && this.activeScans.get() < j && !this.scanQueue.isEmpty()) {
                ChunkPos chunkPosValue = this.scanQueue.poll();
                if (chunkPosValue == null) {
                    break;
                }

                if (client.world.isChunkLoaded(chunkPosValue.x, chunkPosValue.z)
                        && !this.detectedChunks.containsKey(chunkPosValue)) {
                    WorldChunk worldchunk;
                    try {
                        worldchunk = client.world.getChunk(chunkPosValue.x, chunkPosValue.z);
                    } catch (Throwable throwable) {
                        continue;
                    }

                    if (worldchunk != null && !worldchunk.isEmpty()) {
                        this.submitScan(worldchunk);
                        k++;
                    }
                }
            }
        }
    }

    private boolean isEastWestHole(WorldChunk worldchunk, BlockPos blockpos) {
        return this.isOpenCell(worldchunk, blockpos)
                && this.isOpenCell(worldchunk, blockpos.east(1))
                && this.isOpenCell(worldchunk, blockpos.east(2))
                && !this.isOpenCell(worldchunk, blockpos.north())
                && !this.isOpenCell(worldchunk, blockpos.south())
                && !this.isOpenCell(worldchunk, blockpos.east(3))
                && !this.isOpenCell(worldchunk, blockpos.west())
                && !this.isOpenCell(worldchunk, blockpos.east(1).north())
                && !this.isOpenCell(worldchunk, blockpos.east(1).south())
                && !this.isOpenCell(worldchunk, blockpos.east(2).north())
                && !this.isOpenCell(worldchunk, blockpos.east(2).south());
    }

    private boolean isNorthSouthHole(WorldChunk worldchunk, BlockPos blockpos) {
        return this.isOpenCell(worldchunk, blockpos)
                && this.isOpenCell(worldchunk, blockpos.south(1))
                && this.isOpenCell(worldchunk, blockpos.south(2))
                && !this.isOpenCell(worldchunk, blockpos.east())
                && !this.isOpenCell(worldchunk, blockpos.west())
                && !this.isOpenCell(worldchunk, blockpos.south(3))
                && !this.isOpenCell(worldchunk, blockpos.north())
                && !this.isOpenCell(worldchunk, blockpos.south(1).east())
                && !this.isOpenCell(worldchunk, blockpos.south(1).west())
                && !this.isOpenCell(worldchunk, blockpos.south(2).east())
                && !this.isOpenCell(worldchunk, blockpos.south(2).west());
    }

    private static boolean isDesertBiome(RegistryEntry<Biome> registryentry) {
        if (registryentry == null) {
            return false;
        } else {
            try {
                return registryentry.matchesKey(BiomeKeys.DESERT);
            } catch (Throwable throwable) {
                return false;
            }
        }
    }

    private boolean isVerticalHole(WorldChunk worldchunk, BlockPos blockpos) {
        return this.isOpenCell(worldchunk, blockpos)
                && !this.isOpenCell(worldchunk, blockpos.north())
                && !this.isOpenCell(worldchunk, blockpos.south())
                && !this.isOpenCell(worldchunk, blockpos.east())
                && !this.isOpenCell(worldchunk, blockpos.west());
    }

    @Environment(EnvType.CLIENT)
    private static final class ScanResult {
        final List<BlockPos> positions;
        final Block block;

        ScanResult(Block block, List<BlockPos> list) {
            this.block = block;
            this.positions = list;
        }
    }

    @Environment(EnvType.CLIENT)
    private final class ScanRunnable implements Runnable {

        private final WorldChunk worldChunk;
        private final ChunkPos chunkPos;

        private ChunkFinderV2Module.ScanResult findVein(List<BlockPos> list) {
            int i =
                    Math.max(
                            2,
                            Math.round(
                                    ChunkFinderV2Module.this.minimumVeinLengthSetting.getFloat()));
            ConcurrentHashMap concurrenthashmap = new ConcurrentHashMap();

            for (BlockPos blockpos : list) {
                if (Thread.currentThread().isInterrupted()) {
                    return null;
                }

                Block block = this.getCachedBlock(blockpos, concurrenthashmap);
                if (ChunkFinderV2Module.this.isCandidateAt(block, blockpos)
                        && !this.getCachedBlock(blockpos.up(), concurrenthashmap).equals(block)) {
                    int j = 1;

                    for (BlockPos blockposValue = blockpos.down();
                            j <= 21
                                    && this.getCachedBlock(blockposValue, concurrenthashmap)
                                            .equals(block);
                            blockposValue = blockposValue.down()) {
                        j++;
                    }

                    int k;
                    if (block != Blocks.DIRT && block != Blocks.SAND) {
                        k = i;
                    } else {
                        k = Math.max(5, i);
                    }

                    if (j >= k) {
                        boolean flag = true;

                        for (int l = 0; l < j && flag; l++) {
                            BlockPos blockPos = blockpos.down(l);

                            for (Direction direction : ChunkFinderV2Module.HORIZONTAL_DIRECTIONS) {
                                if (!this.getCachedBlock(
                                                blockPos.offset(direction), concurrenthashmap)
                                        .equals(Blocks.STONE)) {
                                    flag = false;
                                    break;
                                }
                            }
                        }

                        if (flag) {
                            ArrayList arraylist = new ArrayList(j);

                            for (int i1 = 0; i1 < j; i1++) {
                                arraylist.add(blockpos.down(i1));
                            }

                            return new ChunkFinderV2Module.ScanResult(block, arraylist);
                        }
                    }
                }
            }

            return null;
        }

        ScanRunnable(WorldChunk worldchunk) {
            this.worldChunk = worldchunk;
            this.chunkPos = worldchunk.getPos();
        }

        private List<BlockPos> collectCandidateBlocks() {
            ArrayList arraylist = new ArrayList();
            int startX = this.chunkPos.getStartX();
            int startZ = this.chunkPos.getStartZ();
            int bottomY = this.worldChunk.getBottomY();
            int l = this.worldChunk.getTopYInclusive() + 1;
            Mutable mutable = new Mutable();

            for (int bottomYValue = bottomY; bottomYValue < l; bottomYValue++) {
                for (int j1 = 0; j1 < 16; j1++) {
                    for (int k1 = 0; k1 < 16; k1++) {
                        mutable.set(startX + j1, bottomYValue, startZ + k1);
                        Block block = this.worldChunk.getBlockState(mutable).getBlock();
                        if (ChunkFinderV2Module.this.isCandidateAt(block, mutable)) {
                            arraylist.add(mutable.toImmutable());
                        }
                    }
                }
            }

            return arraylist;
        }

        @Override
        public void run() {
            try {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }

                List list = this.collectCandidateBlocks();
                if (list.isEmpty()) {
                    return;
                }

                ChunkFinderV2Module.ScanResult scanResult = this.findVein(list);
                if (scanResult == null) {
                    return;
                }

                if (!ChunkFinderV2Module.this.noHolesSetting.isOn()
                        || !ChunkFinderV2Module.this.containsMiningHoles(this.worldChunk)) {
                    Block block = scanResult.block;
                    List listValue = scanResult.positions;
                    MinecraftAccess.client.execute(
                            () ->
                                    ChunkFinderV2Module.this.recordDetection(
                                            this.chunkPos, block, listValue));
                    return;
                }
            } finally {
                ChunkFinderV2Module.this.activeScans.decrementAndGet();
            }
        }

        private Block getCachedBlock(
                BlockPos blockpos, ConcurrentHashMap<BlockPos, Block> concurrenthashmap) {
            return concurrenthashmap.computeIfAbsent(
                    blockpos,
                    blockposx -> {
                        int i = blockposx.getX() >> 4;
                        int j = blockposx.getZ() >> 4;
                        if (i == this.chunkPos.x && j == this.chunkPos.z) {
                            return this.worldChunk.getBlockState(blockposx).getBlock();
                        } else {
                            return MinecraftAccess.client.world != null
                                    ? MinecraftAccess.client
                                            .world
                                            .getBlockState(blockposx)
                                            .getBlock()
                                    : Blocks.AIR;
                        }
                    });
        }
    }
}
