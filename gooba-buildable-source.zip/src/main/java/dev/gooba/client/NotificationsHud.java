package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import org.joml.Matrix3x2fStack;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Environment(EnvType.CLIENT)
public class NotificationsHud implements HudElement {
    private final Map<NotificationManager.Entry, EasingAnimation> positionAnimations;
    private final Map<String, Boolean> moduleStates;
    private boolean initialized;
    private final Set<String> activeEffects;
    private final Set<EquipmentSlot> warnedArmorSlots;
    private final EasingAnimation visibilityAnimation = new EasingAnimation();

    private static Identifier effectTexture(RegistryEntry<StatusEffect> registryentry) {
        return registryentry
                .getKey()
                .map(RegistryKey::getValue)
                .map(identifier -> identifier.withPrefixedPath("mob_effect/"))
                .orElse(Identifier.ofVanilla("mob_effect/speed"));
    }

    private void drawNotification(
            NotificationManager.Entry entry,
            String text,
            Render2DEvent render2DEvent,
            float innerX,
            float innerY,
            float widthValue,
            float opacity,
            float f4,
            HUDModule hUDModule) {
        float height = 20.0F * f4;
        float f6 = 8.0F * f4;
        hUDModule.drawBackground(innerX, innerY, widthValue, height, f6, opacity);
        float width = 14.0F * f4;
        float innerXValue = innerX + 4.0F * f4;
        float innerYValue = innerY + (height - width) * 0.5F;
        RenderUtils.Render2D.drawRoundedRect(
                innerXValue,
                innerYValue,
                width,
                width,
                hUDModule.getAccentColor(opacity * 0.24F),
                5.0F * f4);
        this.drawIcon(
                entry, render2DEvent, innerXValue, innerYValue, width, opacity, f4, hUDModule);
        float f10 = innerXValue + width + 4.0F * f4;
        float size = 7.5F * f4;
        float f12 = Fonts.INTER_SEMIBOLD.centerTextY(text, innerY, height, size);
        Module module = this.findModule(entry);
        if (module != null && entry.message != null && text.contains(entry.message)) {
            int i = text.indexOf(entry.message);
            String string = text.substring(0, i);
            String stringValue = text.substring(i, i + entry.message.length());
            String string2 = text.substring(i + entry.message.length());
            Font font = Fonts.INTER_SEMIBOLD;
            ColorUtils.grayscaleOpacity(255, opacity);
            font.drawText(string, f10, f12, size);
            f10 += Fonts.INTER_SEMIBOLD.measureWidth(string, size);
            font = Fonts.INTER_SEMIBOLD;
            hUDModule.getAccentColor(opacity);
            font.drawText(stringValue, f10, f12, size);
            f10 += Fonts.INTER_SEMIBOLD.measureWidth(stringValue, size);
            font = Fonts.INTER_SEMIBOLD;
            ColorUtils.grayscaleOpacity(255, opacity);
            font.drawText(string2, f10, f12, size);
        } else {
            Font fontValue = Fonts.INTER_SEMIBOLD;
            ColorUtils.grayscaleOpacity(255, opacity);
            fontValue.drawText(text, f10, f12, size);
        }
    }

    private Module findModule(NotificationManager.Entry entry) {
        if (entry != null
                && entry.type == NotificationManager.Type.MODULE
                && entry.message != null
                && !entry.message.isEmpty()) {
            for (Module module : Gooba.getInstance().getModuleRegistry().values()) {
                if (module.getBigName().equalsIgnoreCase(entry.message)
                        || module.getName().equalsIgnoreCase(entry.message)) {
                    return module;
                }
            }

            return null;
        } else {
            return null;
        }
    }

    private void drawIcon(
            NotificationManager.Entry entry,
            Render2DEvent render2DEvent,
            float f,
            float f1,
            float width,
            float opacity,
            float f4,
            HUDModule hUDModule) {

        Module module = this.findModule(entry);
        if (module != null) {
            ModuleCategory moduleCategory2 = module.getCategory();
            String icon = moduleCategory2.getIcon();
            Font font =
                    moduleCategory2 == ModuleCategory.DONUT
                            ? Fonts.DONUT_ICON
                            : Fonts.CATEGORY_ICONS;
            float size = 7.0F * f4;
            float f8 = font.centerTextX(icon, f, width, size);
            float f9 = font.centerTextY(icon, f1, width, size);
            hUDModule.getAccentColor(opacity);
            font.drawText(icon, f8, f9, size);
        } else if (entry != null && entry.iconTexture != null) {
            float f7 = 9.0F * f4;
            Matrix3x2fStack matrix3x2fstack = render2DEvent.getDrawContext().getMatrices();
            matrix3x2fstack.pushMatrix();
            matrix3x2fstack.translate(f + (width - f7) * 0.5F, f1 + (width - f7) * 0.5F);
            matrix3x2fstack.scale(f7 / 12.0F, f7 / 12.0F);
            render2DEvent
                    .getDrawContext()
                    .drawGuiTexture(
                            RenderPipelines.GUI_TEXTURED,
                            entry.iconTexture,
                            0,
                            0,
                            12,
                            12,
                            ColorUtils.grayscaleOpacity(255, opacity));
            matrix3x2fstack.popMatrix();
        } else if (entry != null && entry.itemStack != null && !entry.itemStack.isEmpty()) {
            ItemIconRenderer.drawCentered(
                    render2DEvent.getDrawContext(),
                    entry.itemStack,
                    f + width * 0.5F,
                    f1 + width * 0.5F,
                    0.5625F * f4,
                    opacity);
        } else {
            String string =
                    entry != null && entry.type == NotificationManager.Type.WARNING ? "!" : "O";
            float sizeValue = 7.0F * f4;
            Font fontValue = Fonts.ALPHA;
            float f10 = Fonts.ALPHA.centerTextX(string, f, width, sizeValue);
            float f11 = Fonts.ALPHA.centerTextY(string, f1, width, sizeValue);
            hUDModule.getAccentColor(opacity);
            fontValue.drawText(string, f10, f11, sizeValue);
        }
    }

    public void updateNotifications(
            BooleanSetting booleanSetting,
            BooleanSetting booleanSetting2,
            BooleanSetting booleanSetting3) {
        if (client.player != null && client.world != null) {
            Collection collection = Gooba.getInstance().getModuleRegistry().values();
            if (!this.initialized) {
                for (Module module : (Iterable<Module>) (Iterable) collection) {
                    this.moduleStates.put(module.getName(), module.isEnabled());
                }

                this.initialized = true;
            } else if (booleanSetting.isOn()) {
                for (Module moduleValue : (Iterable<Module>) (Iterable) collection) {
                    boolean orDefault =
                            this.moduleStates.getOrDefault(moduleValue.getName(), false);
                    boolean isEnabled = moduleValue.isEnabled();
                    if (orDefault != isEnabled) {
                        String bigName = moduleValue.getBigName();
                        String text = isEnabled ? " enabled" : " disabled";
                        String bigNameValue = bigName;
                        NotificationManager.showIcon(
                                "Module " + bigNameValue + text,
                                NotificationManager.Type.MODULE,
                                moduleValue.getBigName());
                    }

                    this.moduleStates.put(moduleValue.getName(), isEnabled);
                }
            } else {
                for (Module module3 : (Iterable<Module>) (Iterable) collection) {
                    this.moduleStates.put(module3.getName(), module3.isEnabled());
                }
            }

            if (booleanSetting2.isOn()) {
                EquipmentSlot[] aequipmentslot =
                        new EquipmentSlot[] {
                            EquipmentSlot.HEAD,
                            EquipmentSlot.CHEST,
                            EquipmentSlot.LEGS,
                            EquipmentSlot.FEET
                        };

                for (EquipmentSlot equipmentslot : aequipmentslot) {
                    ItemStack itemstack = client.player.getEquippedStack(equipmentslot);
                    if (!itemstack.isEmpty() && itemstack.getMaxDamage() != 0) {
                        float f =
                                1.0F
                                        - (float) itemstack.getDamage()
                                                / (float) itemstack.getMaxDamage();
                        if (f < 0.1F && !this.warnedArmorSlots.contains(equipmentslot)) {
                            this.warnedArmorSlots.add(equipmentslot);

                            String textValue =
                                    switch (equipmentslot) {
                                        case HEAD -> "Helmet";
                                        case CHEST -> "Bib";
                                        case LEGS -> "Leggings";
                                        case FEET -> "Boots";
                                        default -> equipmentslot.getName();
                                    };
                            NotificationManager.show(
                                    textValue + " almost broken!",
                                    NotificationManager.Type.WARNING,
                                    5000L);
                        } else if (f >= 0.1F) {
                            this.warnedArmorSlots.remove(equipmentslot);
                        }
                    } else {
                        this.warnedArmorSlots.remove(equipmentslot);
                    }
                }
            }

            if (booleanSetting3.isOn()) {
                for (StatusEffectInstance statuseffectinstance : client.player.getStatusEffects()) {
                    String string =
                            statuseffectinstance.getEffectType().value().getName().getString();
                    int duration = statuseffectinstance.getDuration();
                    if (duration > 0) {
                        if (duration > 200) {
                            this.activeEffects.remove(string);
                        } else if (!this.activeEffects.contains(string)) {
                            this.activeEffects.add(string);
                            Identifier identifier =
                                    effectTexture(statuseffectinstance.getEffectType());
                            NotificationManager.showTexture(
                                    string + " ends!",
                                    NotificationManager.Type.EFFECT,
                                    identifier,
                                    4000L);
                        }
                    }
                }
            }
        }
    }

    @Override
    public void render(PositionSetting positionSetting2, HUDModule hUDModule) {}

    private float measureWidth(String string, float f) {
        return (26.0F + Fonts.INTER_SEMIBOLD.measureWidth(string, 7.5F)) * f;
    }

    public NotificationsHud() {
        this.positionAnimations = new IdentityHashMap<>();
        this.activeEffects = new HashSet<>();
        this.moduleStates = new HashMap<>();
        this.initialized = false;
        this.warnedArmorSlots = new HashSet<>();
    }

    public void render(
            PositionSetting positionSetting2, HUDModule hUDModule, Render2DEvent render2DEvent) {
        float f = hUDModule.hudSizeSetting.getFloat();
        float f1 = 2.0F;
        float scaleFactor = (float) client.getWindow().getScaleFactor();
        float f3 = f1 / scaleFactor;
        int i = (int) ((float) client.getWindow().getScaledWidth() / f3);
        synchronized (NotificationManager.getNotifications()) {
            List<NotificationManager.Entry> list = NotificationManager.getNotifications();
            list.removeIf(
                    cfa$entryx ->
                            cfa$entryx.dismissing
                                    && cfa$entryx.visibilityAnimation.getFloatValue() <= 0.01F);
            this.positionAnimations.keySet().retainAll(list);

            for (NotificationManager.Entry entryValue :
                    (Iterable<NotificationManager.Entry>) (Iterable) list) {
                if (entryValue.isExpired()) {
                    entryValue.dismissing = true;
                }

                entryValue.visibilityAnimation.approach(
                        entryValue.dismissing ? 0.0F : 1.0F, entryValue.dismissing ? 8.0F : 9.0F);
            }

            String string = "Notifications";
            float f12 = this.measureWidth(string, f);
            float f4 = 0.0F;

            for (NotificationManager.Entry entry :
                    (Iterable<NotificationManager.Entry>) (Iterable) list) {
                float floatValue = entry.visibilityAnimation.getFloatValue();
                if (!(floatValue <= 0.01F)) {
                    f12 = Math.max(f12, this.measureEntryWidth(entry, f));
                    f4 += 22.0F * f * floatValue;
                }
            }

            if (f4 <= 0.0F) {
                f4 = 20.0F * f;
            }

            positionSetting2.size.set(f12, f4);
            positionSetting2.targetPosition.x = (float) i * 0.5F - f12 * 0.5F;
            positionSetting2.position.x = (float) i * 0.5F - f12 * 0.5F;
            float innerY = positionSetting2.position.y;
            boolean flagx;
            flagx =
                    (client.currentScreen instanceof ChatScreen
                            && list.stream()
                                    .noneMatch(
                                            cfa$entryx ->
                                                    cfa$entryx.visibilityAnimation.getFloatValue()
                                                            > 0.01F));

            if (!flagx
                    && !list.stream()
                            .anyMatch(
                                    cfa$entryx ->
                                            cfa$entryx.visibilityAnimation.getFloatValue()
                                                    > 0.01F)) {
                positionSetting2.visible = false;
            } else {
                positionSetting2.visible = true;
            }

            this.visibilityAnimation.approach(flagx ? 1.0F : 0.0F, 6.0F);
            float opacity = MathHelper.clamp(this.visibilityAnimation.getFloatValue(), 0.0F, 1.0F);
            if (opacity > 0.01F) {
                float widthValue = this.measureWidth(string, f);
                this.drawNotification(
                        null,
                        string,
                        render2DEvent,
                        (float) i * 0.5F - widthValue * 0.5F,
                        innerY,
                        widthValue,
                        opacity,
                        f,
                        hUDModule);
            }

            for (NotificationManager.Entry entry2 :
                    (Iterable<NotificationManager.Entry>) (Iterable) list) {
                float floatValueValue = entry2.visibilityAnimation.getFloatValue();
                if (!(floatValueValue <= 0.01F)) {
                    float widthValueValue = this.measureEntryWidth(entry2, f);
                    float innerX = (float) i * 0.5F - widthValueValue * 0.5F;
                    float target = (innerY - positionSetting2.position.y) / f;
                    EasingAnimation easingAnimation2 = this.positionAnimations.get(entry2);
                    if (easingAnimation2 == null) {
                        easingAnimation2 = new EasingAnimation().resetValue(target);
                        this.positionAnimations.put(entry2, easingAnimation2);
                    }

                    float f11 =
                            positionSetting2.position.y
                                    + easingAnimation2.approach(target, 3.5F) * f;
                    this.drawNotification(
                            entry2,
                            plainText(entry2.iconText),
                            render2DEvent,
                            innerX,
                            f11 + (1.0F - floatValueValue) * 6.0F * f,
                            widthValueValue,
                            floatValueValue,
                            f,
                            hUDModule);
                    innerY += 22.0F * f * floatValueValue;
                }
            }
        }
    }

    private float measureEntryWidth(NotificationManager.Entry entry, float f) {
        return this.measureWidth(plainText(entry.iconText), f);
    }

    private static String plainText(String text) {
        return TextFormatting.stripColorTags(text);
    }
}
