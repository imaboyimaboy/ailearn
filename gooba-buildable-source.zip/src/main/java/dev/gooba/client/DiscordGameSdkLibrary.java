package dev.gooba.client;

import com.sun.jna.Callback;
import com.sun.jna.Library;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.PointerByReference;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface DiscordGameSdkLibrary extends Library {

    int DiscordCreate(long i, long j, Pointer pointer, PointerByReference pointerbyreference);

    @Environment(EnvType.CLIENT)
    public interface DiscordCreateParamsSetEventsData extends Callback {
        void callback(Pointer pointer);
    }

    @Environment(EnvType.CLIENT)
    public static class Loader {}
}
