package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import java.nio.ByteBuffer;

@Environment(EnvType.CLIENT)
public class RectData extends UniformBatchRenderer {
    private static final Identifier PIPELINE_ID = Identifier.of("client", "pipeline/rect");
    private static final Identifier VERTEX_SHADER = Identifier.of("client", "core/shader_blur");

    private static final Identifier FRAGMENT_SHADER = Identifier.of("client", "core/shader_blur");
    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(PIPELINE_ID)
                            .withVertexShader(RectData.VERTEX_SHADER)
                            .withFragmentShader(RectData.FRAGMENT_SHADER)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("RectData", UniformType.UNIFORM_BUFFER)
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());
    private final int[] gradientColors = new int[9];

    public RectData() {
        super("rect", PIPELINE, "RectData", 64, 224, 32);
    }

    private int averageColors(int[] aint) {
        int i = 0;
        int j = 0;
        int k = 0;
        int l = 0;

        for (int i1 : aint) {
            l += i1 >> 24 & 0xFF;
            i += i1 >> 16 & 0xFF;
            j += i1 >> 8 & 0xFF;
            k += i1 & 0xFF;
        }

        int length = aint.length;
        return l / length << 24 | i / length << 16 | j / length << 8 | k / length;
    }

    public void drawShadow(
            float innerX,
            float innerY,
            float width,
            float height,
            int color,
            float[] afloat,
            float spread,
            float softness,
            float opacity) {
        if (!(width <= 0.0F) && !(height <= 0.0F) && !(spread <= 0.0F) && !(softness <= 0.0F)) {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (minecraftclient.getFramebuffer() != null) {
                for (int j = 0; j < 9; j++) {
                    this.gradientColors[j] = color;
                }

                float f7 = Math.max(0.5F, spread);
                this.writeRectangle(
                        innerX - f7,
                        innerY - f7,
                        width + f7 * 2.0F,
                        height + f7 * 2.0F,
                        innerX,
                        innerY,
                        width,
                        height,
                        0.0F,
                        afloat,
                        spread,
                        softness,
                        opacity,
                        color);
                this.finishInstance();
            }
        }
    }

    @Override
    public int getSortOrder() {
        return 0;
    }

    private void writeRectangle(
            float f,
            float f1,
            float width,
            float height,
            float innerX,
            float innerY,
            float innerWidth,
            float innerHeight,
            float feather,
            float[] afloat,
            float spread,
            float softness,
            float opacity,
            int shadowColor) {
        ByteBuffer bytebuffer = this.beginInstance();
        bytebuffer.putFloat(f);
        bytebuffer.putFloat(f1);
        bytebuffer.putFloat(width);
        bytebuffer.putFloat(height);
        bytebuffer.putFloat(afloat[0]);
        bytebuffer.putFloat(afloat[1]);
        bytebuffer.putFloat(afloat[2]);
        bytebuffer.putFloat(afloat[3]);

        for (int j = 0; j < 9; j++) {
            int gradientColor = this.gradientColors[j];
            float f12 = (float) (gradientColor >> 24 & 0xFF) / 255.0F;
            float f13 = (float) (gradientColor >> 16 & 0xFF) / 255.0F;
            float f14 = (float) (gradientColor >> 8 & 0xFF) / 255.0F;
            float f15 = (float) (gradientColor & 0xFF) / 255.0F;
            bytebuffer.putFloat(f13);
            bytebuffer.putFloat(f14);
            bytebuffer.putFloat(f15);
            bytebuffer.putFloat(f12);
        }

        bytebuffer.putFloat(innerX);
        bytebuffer.putFloat(innerY);
        bytebuffer.putFloat(innerWidth);
        bytebuffer.putFloat(innerHeight);
        bytebuffer.putFloat(spread);
        bytebuffer.putFloat(softness);
        bytebuffer.putFloat(Math.max(0.05F, opacity));
        bytebuffer.putFloat(feather);
        bytebuffer.putFloat((float) (shadowColor >> 16 & 0xFF) / 255.0F);
        bytebuffer.putFloat((float) (shadowColor >> 8 & 0xFF) / 255.0F);
        bytebuffer.putFloat((float) (shadowColor & 0xFF) / 255.0F);
        bytebuffer.putFloat((float) (shadowColor >> 24 & 0xFF) / 255.0F);
    }

    public void drawSoftRect(
            float innerX,
            float innerY,
            float width,
            float height,
            int[] aint,
            float[] afloat,
            float feather) {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient.getFramebuffer() != null) {
            this.prepareGradientColors(aint);
            this.writeRectangle(
                    innerX, innerY, width, height, innerX, innerY, width, height, feather, afloat,
                    0.0F, 0.0F, 1.0F, 0);
            this.finishInstance();
        }
    }

    private void prepareGradientColors(int[] aint) {
        if (aint.length == 1) {
            for (int i = 0; i < 9; i++) {
                this.gradientColors[i] = aint[0];
            }
        } else if (aint.length == 4) {
            this.gradientColors[0] = aint[0];
            this.gradientColors[1] = this.averageColors(new int[] {aint[0], aint[1]});
            this.gradientColors[2] = aint[1];
            this.gradientColors[3] = this.averageColors(new int[] {aint[0], aint[3]});
            this.gradientColors[4] =
                    this.averageColors(new int[] {aint[0], aint[1], aint[2], aint[3]});
            this.gradientColors[5] = this.averageColors(new int[] {aint[1], aint[2]});
            this.gradientColors[6] = aint[3];
            this.gradientColors[7] = this.averageColors(new int[] {aint[3], aint[2]});
            this.gradientColors[8] = aint[2];
        } else if (aint.length >= 9) {
            System.arraycopy(aint, 0, this.gradientColors, 0, 9);
        } else {
            for (int j = 0; j < 9; j++) {
                this.gradientColors[j] = aint[j % aint.length];
            }
        }
    }

    public void drawRect(
            float innerX, float innerY, float width, float height, int[] aint, float[] afloat) {
        this.drawSoftRect(innerX, innerY, width, height, aint, afloat, 0.0F);
    }
}
