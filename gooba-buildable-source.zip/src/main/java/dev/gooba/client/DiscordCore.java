package dev.gooba.client;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FieldOrder({"vtable"})
@Environment(EnvType.CLIENT)
public class DiscordCore extends Structure {
    public DiscordCoreVtable vtable;

    public DiscordCore(Pointer pointer) {
        super(pointer);
        this.read();
    }

    public DiscordCore() {}
}
