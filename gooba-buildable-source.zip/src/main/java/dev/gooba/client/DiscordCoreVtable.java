package dev.gooba.client;

import com.sun.jna.Callback;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.Structure.FieldOrder;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FieldOrder({
    "destroy",
    "run_callbacks",
    "set_log_hook",
    "get_user_manager",
    "get_image_manager",
    "get_activity_manager",
    "get_relationship_manager",
    "get_lobby_manager",
    "get_network_manager",
    "get_overlay_manager",
    "get_storage_manager",
    "get_store_manager",
    "get_voice_manager",
    "get_achievement_manager"
})
@Environment(EnvType.CLIENT)
public class DiscordCoreVtable extends Structure {
    public DiscordCoreVtable.GetManagerFunc get_voice_manager;
    public DiscordCoreVtable.GetManagerFunc get_relationship_manager;
    public DiscordCoreVtable.GetManagerFunc get_overlay_manager;
    public DiscordCoreVtable.RunCallbacksFunc run_callbacks;
    public DiscordCoreVtable.GetManagerFunc get_store_manager;
    public DiscordCoreVtable.GetManagerFunc get_user_manager;
    public DiscordCoreVtable.SetLogHookFunc set_log_hook;
    public DiscordCoreVtable.DestroyFunc destroy;
    public DiscordCoreVtable.GetManagerFunc get_image_manager;
    public DiscordCoreVtable.GetManagerFunc get_network_manager;
    public DiscordCoreVtable.GetManagerFunc get_storage_manager;
    public DiscordCoreVtable.GetManagerFunc get_activity_manager;

    public DiscordCoreVtable.GetManagerFunc get_achievement_manager;
    public DiscordCoreVtable.GetManagerFunc get_lobby_manager;

    static {
    }

    @Environment(EnvType.CLIENT)
    public interface DestroyFunc extends Callback {
        void invoke(long i);
    }

    @Environment(EnvType.CLIENT)
    public interface GetManagerFunc extends Callback {
        Pointer invoke(long i);
    }

    @Environment(EnvType.CLIENT)
    public interface RunCallbacksFunc extends Callback {
        int invoke(long i);
    }

    @Environment(EnvType.CLIENT)
    public interface SetLogHookFunc extends Callback {
        void invoke(long i, int j, Pointer pointer, Pointer pointerValue);
    }
}
