package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class NotificationManager {
    private static final List<NotificationManager.Entry> notifications = new ArrayList<>();

    public static List<NotificationManager.Entry> getNotifications() {
        return notifications;
    }

    public static void showItem(String text, NotificationManager.Type type, ItemStack itemstack) {
        enqueue(text, type, null, null, itemstack, 3000L);
    }

    public static void showTexture(
            String text, NotificationManager.Type type, Identifier identifier, long i) {
        enqueue(text, type, null, identifier, null, i);
    }

    public static void showIcon(String text, NotificationManager.Type type, String textValue) {
        enqueue(text, type, textValue, null, null, 3000L);
    }

    public static void show(String text, NotificationManager.Type type, long i) {
        enqueue(text, type, null, null, null, i);
    }

    public static void showItem(
            String text, NotificationManager.Type type, ItemStack itemstack, long i) {
        enqueue(text, type, null, null, itemstack, i);
    }

    private static void enqueue(
            String text,
            NotificationManager.Type type,
            String textValue,
            Identifier identifier,
            ItemStack itemstack,
            long i) {
        if (text != null && !text.isBlank()) {
            synchronized (notifications) {
                notifications.removeIf(
                        entry ->
                                entry.dismissing
                                        && entry.visibilityAnimation.getFloatValue() <= 0.01F);
                long j =
                        notifications.stream().filter(entryValue -> !entryValue.dismissing).count();

                for (NotificationManager.Entry entry2 : notifications) {
                    if (j < (8L)) {
                        break;
                    }

                    if (!entry2.dismissing) {
                        entry2.dismissing = true;
                        j--;
                    }
                }

                notifications.add(
                        new NotificationManager.Entry(
                                text,
                                type == null ? NotificationManager.Type.INFO : type,
                                textValue,
                                identifier,
                                itemstack,
                                Math.max(250L, i)));
            }
        }
    }

    @Environment(EnvType.CLIENT)
    public static class Entry {
        private final long durationMillis;
        private final long createdAtMillis;
        public final EasingAnimation visibilityAnimation = new EasingAnimation();
        public final String message;
        public final String iconText;
        public final Identifier iconTexture;
        public boolean dismissing = false;
        public final NotificationManager.Type type;
        public final ItemStack itemStack;

        Entry(
                String text,
                NotificationManager.Type typeValue,
                String stringValue,
                Identifier identifier,
                ItemStack itemstack,
                long durationMillisValue) {
            this.createdAtMillis = System.currentTimeMillis();
            this.iconText = text;
            this.type = typeValue;
            this.message = stringValue;
            this.iconTexture = identifier;
            this.itemStack = itemstack;
            this.durationMillis = durationMillisValue;
        }

        public boolean isExpired() {
            return System.currentTimeMillis() - this.createdAtMillis >= this.durationMillis;
        }
    }

    @Environment(EnvType.CLIENT)
    public static enum Type {
        MODULE,
        EFFECT,
        INFO,
        WARNING;
    }
}
