package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket.Handler;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;

@ModuleInfo(
        name = "Optimized Crystals",
        desc = "Removes attacked crystals immediately on the client",
        category = ModuleCategory.COMBAT)
@Environment(EnvType.CLIENT)
public class OptimizedCrystalsModule extends Module {
    @EventHandler
    public void onPacket(PacketEvent packetEvent) {
        if (packetEvent.isSend() && client.player != null && client.world != null) {
            if (packetEvent.getPacket()
                    instanceof PlayerInteractEntityC2SPacket playerinteractentityc2spacket) {
                playerinteractentityc2spacket.handle(
                        new Handler() {
                            @Override
                            public void interact(Hand hand) {}

                            @Override
                            public void interactAt(Hand hand, Vec3d vec3d) {}

                            @Override
                            public void attack() {
                                OptimizedCrystalsModule.this.removeAttackedCrystal();
                            }
                        });
            }
        }
    }

    private void removeAttackedCrystal() {
        if (client.crosshairTarget instanceof EntityHitResult entityhitresult) {
            if (entityhitresult.getType() == Type.ENTITY) {
                if (entityhitresult.getEntity() instanceof EndCrystalEntity endcrystalentity) {
                    if (this.canDamageCrystal()) {
                        endcrystalentity.discard();
                        endcrystalentity.setRemoved(RemovalReason.KILLED);
                        endcrystalentity.onRemoved();
                    }
                }
            }
        }
    }

    private boolean canDamageCrystal() {
        StatusEffectInstance statuseffectinstance =
                client.player.getStatusEffect(StatusEffects.WEAKNESS);
        if (statuseffectinstance == null) {
            return true;
        } else {
            StatusEffectInstance statusEffect =
                    client.player.getStatusEffect(StatusEffects.STRENGTH);
            if (statusEffect != null
                    && statusEffect.getAmplifier() > statuseffectinstance.getAmplifier()) {
                return true;
            } else {
                ItemStack itemstack = client.player.getMainHandStack();
                return itemstack.isIn(ItemTags.SWORDS)
                        || itemstack.isIn(ItemTags.AXES)
                        || itemstack.isIn(ItemTags.PICKAXES)
                        || itemstack.isIn(ItemTags.SHOVELS)
                        || itemstack.isIn(ItemTags.HOES)
                        || itemstack.isOf(Items.MACE)
                        || itemstack.isOf(Items.TRIDENT);
            }
        }
    }
}
