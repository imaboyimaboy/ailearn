package dev.gooba.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.util.Identifier;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

@Environment(EnvType.CLIENT)
public class FontBatchRenderer implements RenderBatchDispatcher.Batched {

    private ByteBuffer glyphData;
    private int glyphCount;
    private static final Identifier PIPELINE_ID = Identifier.of("client", "pipeline/msdf");
    private static final Map<String, String> normalizedTextCache;
    private static final Map<Integer, Integer> smallCapitalReplacements;
    private static final String FORMATTING_CODES;
    private static final int[] FORMATTING_COLORS = new int[32];
    private boolean initialized;
    private final ArrayList<FontBatchRenderer.FontChunk> pendingChunks;
    private static final int LIGHTNING_CODE_POINT;
    private GpuBuffer[] uniformBuffers;
    private static final Identifier SHADER_ID = Identifier.of("client", "core/msdf");
    private GpuBuffer dummyVertexBuffer;
    private float outlineWidth;

    private final Map<GpuTexture, GpuTextureView> textureViews;
    private int uniformBufferIndex = 0;
    private int outlineColor;
    private FontAtlas currentAtlas;
    private static final RenderPipeline PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET)
                            .withLocation(PIPELINE_ID)
                            .withVertexShader(FontBatchRenderer.SHADER_ID)
                            .withFragmentShader(FontBatchRenderer.SHADER_ID)
                            .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                            .withUniform("FontData", UniformType.UNIFORM_BUFFER)
                            .withSampler("Sampler0")
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build());

    private FontBatchRenderer.ColorAdvance parseColorAdvance(String text, int i, int color, int k) {
        TextFormatting.ColorTag colorTag = TextFormatting.parseColorTag(text, i, color);
        if (colorTag != null) {
            return new FontBatchRenderer.ColorAdvance(colorTag.length(), colorTag.color(), true);
        } else {
            int codePoint = text.codePointAt(i);
            int charCount = Character.charCount(codePoint);
            if ((codePoint == 167 || codePoint == 38) && i + charCount < text.length()) {
                int codePointValue = text.codePointAt(i + charCount);
                if (codePointValue == 35 && i + charCount + 6 < text.length()) {
                    try {
                        String textValue = text.substring(i + charCount + 1, i + charCount + 7);
                        int i21 = 0xFF000000 | Integer.parseInt(textValue, 16);
                        return new FontBatchRenderer.ColorAdvance(charCount + 7, i21, true);
                    } catch (Exception exception) {
                    }
                }

                int k1 = FORMATTING_CODES.indexOf(Character.toLowerCase((char) codePointValue));
                if (k1 >= 0) {
                    int l1 = k1 < 16 ? FORMATTING_COLORS[k1] : (k1 == 21 ? color : k);
                    return new FontBatchRenderer.ColorAdvance(
                            charCount + Character.charCount(codePointValue), l1, true);
                }
            }

            return new FontBatchRenderer.ColorAdvance(0, k, false);
        }
    }

    private void submitPendingGlyphs() {
        if (this.glyphCount != 0 && this.currentAtlas != null) {
            MinecraftClient minecraftclient = MinecraftClient.getInstance();
            if (minecraftclient.getFramebuffer() == null) {
                this.glyphCount = 0;
                this.currentAtlas = null;
            } else {
                AbstractTexture abstracttexture =
                        minecraftclient
                                .getTextureManager()
                                .getTexture(this.currentAtlas.getTextureResource());
                if (abstracttexture == null) {
                    this.glyphCount = 0;
                    this.currentAtlas = null;
                } else {
                    GpuTexture gputexture;
                    try {
                        gputexture = abstracttexture.getGlTexture();
                    } catch (Exception exception) {
                        this.glyphCount = 0;
                        this.currentAtlas = null;
                        return;
                    }

                    if (this.pendingChunks.size() >= 127) {
                        RenderBatchDispatcher.renderImmediately(this, false);
                    }

                    int glyphCountValue = this.glyphCount;
                    int j = this.glyphData.position();
                    this.glyphData.position(0);
                    this.glyphData.putFloat((float) this.getViewportWidth());
                    this.glyphData.putFloat((float) this.getViewportHeight());
                    this.glyphData.putFloat(2.0F);
                    this.glyphData.putFloat(this.outlineWidth);
                    this.glyphData.putFloat((float) (this.outlineColor >> 16 & 0xFF) / 255.0F);
                    this.glyphData.putFloat((float) (this.outlineColor >> 8 & 0xFF) / 255.0F);
                    this.glyphData.putFloat((float) (this.outlineColor & 0xFF) / 255.0F);
                    this.glyphData.putFloat((float) (this.outlineColor >> 24 & 0xFF) / 255.0F);
                    this.glyphData.putFloat(this.currentAtlas.getAtlasWidth());
                    this.glyphData.putFloat(this.currentAtlas.getAtlasHeight());
                    this.glyphData.putFloat(this.currentAtlas.getDistanceRange());
                    this.glyphData.putFloat(this.currentAtlas.getFontSize());
                    this.glyphData.putInt(glyphCountValue);
                    this.glyphData.putInt(0);
                    this.glyphData.putInt(0);
                    this.glyphData.putInt(0);
                    this.glyphData.position(0);
                    this.glyphData.limit(j);
                    GpuBuffer gpubuffer = this.nextUniformBuffer();
                    RenderSystem.getDevice()
                            .createCommandEncoder()
                            .writeToBuffer(
                                    gpubuffer.slice(0L, (long) this.glyphData.remaining()),
                                    this.glyphData);
                    this.glyphData.limit(this.glyphData.capacity());
                    this.pendingChunks.add(
                            new FontBatchRenderer.FontChunk(
                                    gpubuffer,
                                    this.getOrCreateTextureView(gputexture),
                                    glyphCountValue));
                    this.glyphCount = 0;
                    this.currentAtlas = null;
                }
            }
        } else {
            this.glyphCount = 0;
            this.currentAtlas = null;
        }
    }

    @Override
    public void prepare(CommandEncoder commandencoder) {
        this.submitPendingGlyphs();
    }

    public void drawText(
            FontAtlas fontAtlas2,
            String string,
            float f,
            float f1,
            float size,
            int color,
            float outlineWidthValue,
            int outlineColorValue,
            float rotationDegrees) {

        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient.getFramebuffer() != null) {
            if (string != null && !string.isEmpty()) {
                string = this.normalizeGlyphs(string);
                string = TextFormatting.expandAliases(string);
                fontAtlas2.ensureLoaded();
                if (fontAtlas2.getGlyphCount() != 0) {
                    this.initialize();
                    if (RenderBatchDispatcher.isBatching()) {
                        RenderBatchDispatcher.enqueue(this);
                    }

                    if (this.currentAtlas != null
                            && (this.currentAtlas != fontAtlas2
                                    || this.outlineWidth != outlineWidthValue
                                    || this.outlineColor != outlineColorValue)) {
                        this.flush();
                    }

                    this.currentAtlas = fontAtlas2;
                    this.outlineWidth = outlineWidthValue;
                    this.outlineColor = outlineColorValue;
                    float f5 = size / fontAtlas2.getFontSize();
                    float f6 = f;
                    float f7 = f1;
                    float f8 = (float) Math.toRadians((double) rotationDegrees);
                    float f9 = 0.0F;
                    float f10 = 0.0F;
                    if (rotationDegrees != 0.0F) {
                        f9 = f + this.measureWidth(fontAtlas2, string, size) / 2.0F;
                        f10 = f1 + this.measureHeight(fontAtlas2, string, size) / 2.0F;
                    }

                    int colorValue = color;
                    int l = 0;

                    while (l < string.length()) {
                        FontBatchRenderer.ColorAdvance colorAdvance =
                                this.parseColorAdvance(string, l, color, colorValue);
                        if (colorAdvance.matched()) {
                            colorValue = colorAdvance.color();
                            l += colorAdvance.skip();
                        } else {
                            int codePoint = string.codePointAt(l);
                            int charCount = Character.charCount(codePoint);
                            if (codePoint == 10) {
                                f6 = f;
                                f7 += fontAtlas2.getLineHeight() * f5;
                                l += charCount;
                            } else {
                                GlyphMetrics glyphMetrics = fontAtlas2.getGlyphMetrics(codePoint);
                                if (glyphMetrics == null) {
                                    GlyphMetrics glyphMetrics2 = fontAtlas2.getGlyphMetrics(63);
                                    if (glyphMetrics2 != null) {
                                        f6 += glyphMetrics2.advance * f5;
                                    } else {
                                        f6 += size * 0.5F;
                                    }

                                    l += charCount;
                                } else {
                                    float f14 = f6 + glyphMetrics.offsetX * f5;
                                    float f11 = f7 + glyphMetrics.offsetY * f5;
                                    float f12 = glyphMetrics.width * f5;
                                    float f13 = glyphMetrics.height * f5;
                                    if (glyphMetrics.width > 0.0F && glyphMetrics.height > 0.0F) {
                                        this.appendGlyph(
                                                f14,
                                                f11,
                                                f12,
                                                f13,
                                                glyphMetrics.u0,
                                                glyphMetrics.v0,
                                                glyphMetrics.u1,
                                                glyphMetrics.v1,
                                                colorValue,
                                                f8,
                                                f9,
                                                f10,
                                                f5);
                                    }

                                    f6 += glyphMetrics.advance * f5;
                                    if (this.glyphCount >= 256) {
                                        this.flush();
                                        this.currentAtlas = fontAtlas2;
                                    }

                                    l += charCount;
                                }
                            }
                        }
                    }

                    if (!RenderBatchDispatcher.isBatching()) {
                        this.flush();
                    }
                }
            }
        }
    }

    private String normalizeGlyphs(String text) {
        String textValue = normalizedTextCache.get(text);
        if (textValue != null) {
            return textValue;
        } else {
            StringBuilder stringbuilder = null;
            int j = 0;

            while (j < text.length()) {
                int codePoint = text.codePointAt(j);
                int charCount = Character.charCount(codePoint);
                if (codePoint == LIGHTNING_CODE_POINT) {
                    if (stringbuilder == null) {
                        stringbuilder = new StringBuilder(text.substring(0, j));
                    }
                } else {
                    Integer integer = smallCapitalReplacements.get(codePoint);
                    if (integer != null) {
                        if (stringbuilder == null) {
                            stringbuilder = new StringBuilder(text.substring(0, j));
                        }

                        stringbuilder.appendCodePoint(integer);
                    } else if (stringbuilder != null) {
                        stringbuilder.appendCodePoint(codePoint);
                    }
                }

                j += charCount;
            }

            String text2 = stringbuilder != null ? stringbuilder.toString() : text;
            normalizedTextCache.put(text, text2);
            return text2;
        }
    }

    private FontBatchRenderer.ColorAdvance parseColorAdvance(String text, int i) {
        return this.parseColorAdvance(text, i, 0, 0);
    }

    public void drawFadedText(
            FontAtlas fontAtlas2,
            String string,
            float f,
            float f1,
            float size,
            float maxWidth,
            int color) {

        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        if (minecraftclient.getFramebuffer() != null) {
            if (string != null && !string.isEmpty()) {
                if (this.measureWidth(fontAtlas2, string, size) <= maxWidth) {
                    this.drawText(fontAtlas2, string, f, f1, size, color, 0.0F, 0, 0.0F);
                } else {
                    int j = color >> 24 & 0xFF;
                    if (j != 0) {
                        int k = color & 16777215;
                        float f4 = maxWidth - 40.0F;
                        string = this.normalizeGlyphs(string);
                        string = TextFormatting.expandAliases(string);
                        fontAtlas2.ensureLoaded();
                        if (fontAtlas2.getGlyphCount() != 0) {
                            this.initialize();
                            if (RenderBatchDispatcher.isBatching()) {
                                RenderBatchDispatcher.enqueue(this);
                            }

                            if (this.currentAtlas != null
                                    && (this.currentAtlas != fontAtlas2
                                            || this.outlineWidth != 0.0F
                                            || this.outlineColor != 0)) {
                                this.flush();
                            }

                            this.currentAtlas = fontAtlas2;
                            this.outlineWidth = 0.0F;
                            this.outlineColor = 0;
                            float f5 = size / fontAtlas2.getFontSize();
                            float f6 = 0.0F;
                            int l = 0;

                            while (l < string.length()) {
                                FontBatchRenderer.ColorAdvance colorAdvance =
                                        this.parseColorAdvance(string, l);
                                if (colorAdvance.matched()) {
                                    l += colorAdvance.skip();
                                } else {
                                    int codePoint = string.codePointAt(l);
                                    int charCount = Character.charCount(codePoint);
                                    GlyphMetrics glyphMetrics =
                                            fontAtlas2.getGlyphMetrics(codePoint);
                                    float f7;
                                    if (glyphMetrics != null) {
                                        f7 = glyphMetrics.advance * f5;
                                    } else {
                                        GlyphMetrics glyphMetrics2 = fontAtlas2.getGlyphMetrics(63);
                                        f7 =
                                                glyphMetrics2 != null
                                                        ? glyphMetrics2.advance * f5
                                                        : size * 0.5F;
                                    }

                                    if (f6 + f7 > maxWidth) {
                                        break;
                                    }

                                    int l1 = j;
                                    if (f6 > f4) {
                                        float f8 = (f6 - f4) / (maxWidth - f4);
                                        l1 = (int) ((float) j * (1.0F - f8));
                                    }

                                    if (l1 > 0
                                            && glyphMetrics != null
                                            && glyphMetrics.width > 0.0F
                                            && glyphMetrics.height > 0.0F) {
                                        this.appendGlyph(
                                                f + f6 + glyphMetrics.offsetX * f5,
                                                f1 + glyphMetrics.offsetY * f5,
                                                glyphMetrics.width * f5,
                                                glyphMetrics.height * f5,
                                                glyphMetrics.u0,
                                                glyphMetrics.v0,
                                                glyphMetrics.u1,
                                                glyphMetrics.v1,
                                                l1 << 24 | k,
                                                0.0F,
                                                0.0F,
                                                0.0F,
                                                f5);
                                        if (this.glyphCount >= 256) {
                                            this.flush();
                                            this.currentAtlas = fontAtlas2;
                                        }
                                    }

                                    f6 += f7;
                                    l += charCount;
                                }
                            }

                            if (!RenderBatchDispatcher.isBatching()) {
                                this.flush();
                            }
                        }
                    }
                }
            }
        }
    }

    private void appendGlyph(
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            float f7,
            int i,
            float f8,
            float f9,
            float f10,
            float f11) {
        if (this.glyphCount == 0) {
            this.glyphData.clear();
            this.glyphData.position(64);
        }

        this.glyphData.putFloat(f);
        this.glyphData.putFloat(f1);
        this.glyphData.putFloat(f2);
        this.glyphData.putFloat(f3);
        this.glyphData.putFloat(f4);
        this.glyphData.putFloat(f5);
        this.glyphData.putFloat(f6);
        this.glyphData.putFloat(f7);
        float f12 = (float) (i >> 24 & 0xFF) / 255.0F;
        float f13 = (float) (i >> 16 & 0xFF) / 255.0F;
        float f14 = (float) (i >> 8 & 0xFF) / 255.0F;
        float f15 = (float) (i & 0xFF) / 255.0F;
        this.glyphData.putFloat(f13);
        this.glyphData.putFloat(f14);
        this.glyphData.putFloat(f15);
        this.glyphData.putFloat(f12);
        this.glyphData.putFloat(f8);
        this.glyphData.putFloat(f9);
        this.glyphData.putFloat(f10);
        this.glyphData.putFloat(f11);
        this.glyphCount++;
    }

    @Override
    public int getSortOrder() {
        return 3;
    }

    public FontBatchRenderer() {
        this.initialized = false;
        this.textureViews = new HashMap<>();
        this.glyphCount = 0;
        this.currentAtlas = null;
        this.outlineWidth = 0.0F;
        this.outlineColor = 0;
        this.pendingChunks = new ArrayList<>();
    }

    public void close() {
        this.glyphCount = 0;
        this.currentAtlas = null;
        this.clear();

        for (GpuTextureView gputextureview : this.textureViews.values()) {
            if (!gputextureview.isClosed()) {
                gputextureview.close();
            }
        }

        this.textureViews.clear();
        if (this.uniformBuffers != null) {
            for (GpuBuffer gpubuffer : this.uniformBuffers) {
                if (gpubuffer != null) {
                    gpubuffer.close();
                }
            }

            this.uniformBuffers = null;
        }

        this.uniformBufferIndex = 0;
        if (this.dummyVertexBuffer != null) {
            this.dummyVertexBuffer.close();
            this.dummyVertexBuffer = null;
        }

        if (this.glyphData != null) {
            MemoryUtil.memFree(this.glyphData);
            this.glyphData = null;
        }

        this.initialized = false;
    }

    public float measureWidth(FontAtlas fontAtlas2, String string, float size) {

        fontAtlas2.ensureLoaded();
        float f1 = size / fontAtlas2.getFontSize();
        string = this.normalizeGlyphs(string);
        Float value = fontAtlas2.widthCache.get(string);
        if (value != null) {
            return value * f1;
        } else {
            String text = TextFormatting.plainText(string);
            Float valueValue = text.equals(string) ? null : fontAtlas2.widthCache.get(text);
            if (valueValue == null) {
                valueValue = this.measureUnscaledWidth(fontAtlas2, text);
                fontAtlas2.widthCache.put(text, valueValue);
            }

            fontAtlas2.widthCache.put(string, valueValue);
            return valueValue * f1;
        }
    }

    static {
        for (int i = 0; i < 16; i++) {
            int j = (i >> 3 & 1) * 85;
            int k = (i >> 2 & 1) * 170 + j;
            int l = (i >> 1 & 1) * 170 + j;
            int i1 = (i & 1) * 170 + j;
            if (i == 6) {
                k += 85;
            }

            FORMATTING_COLORS[i] = 0xFF000000 | k << 16 | l << 8 | i1;
            FORMATTING_COLORS[i + 16] = (k & 16579836) >> 2 << 24 | k << 16 | l << 8 | i1;
        }

        FORMATTING_CODES =
                new String(
                        new char[] {
                            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',
                            'e', 'f', 'k', 'l', 'm', 'n', 'o', 'r'
                        });
        normalizedTextCache =
                new LinkedHashMap<String, String>(257, 0.75F, true) {
                    @Override
                    protected boolean removeEldestEntry(Entry<String, String> entry) {
                        return this.size() > 256;
                    }
                };
        smallCapitalReplacements = new HashMap<>();
        smallCapitalReplacements.put(7424, 97);
        smallCapitalReplacements.put(665, 98);
        smallCapitalReplacements.put(7428, 99);
        smallCapitalReplacements.put(7429, 100);
        smallCapitalReplacements.put(7431, 101);
        smallCapitalReplacements.put(1171, 102);
        smallCapitalReplacements.put(610, 103);
        smallCapitalReplacements.put(668, 104);
        smallCapitalReplacements.put(618, 105);
        smallCapitalReplacements.put(7434, 106);
        smallCapitalReplacements.put(7435, 107);
        smallCapitalReplacements.put(671, 108);
        smallCapitalReplacements.put(7437, 109);
        smallCapitalReplacements.put(628, 110);
        smallCapitalReplacements.put(7439, 111);
        smallCapitalReplacements.put(7448, 112);
        smallCapitalReplacements.put(491, 113);
        smallCapitalReplacements.put(640, 114);
        smallCapitalReplacements.put(7451, 116);
        smallCapitalReplacements.put(7452, 117);
        smallCapitalReplacements.put(7456, 118);
        smallCapitalReplacements.put(7457, 119);
        smallCapitalReplacements.put(655, 121);
        smallCapitalReplacements.put(7458, 122);
        LIGHTNING_CODE_POINT = "⚡".codePointAt(0);
    }

    private float measureUnscaledWidth(FontAtlas fontAtlas2, String text) {
        float f = 0.0F;
        float f1 = 0.0F;
        int i = 0;

        while (i < text.length()) {
            FontBatchRenderer.ColorAdvance colorAdvance = this.parseColorAdvance(text, i);
            if (colorAdvance.matched()) {
                i += colorAdvance.skip();
            } else {
                int codePoint = text.codePointAt(i);
                int charCount = Character.charCount(codePoint);
                if (codePoint == 10) {
                    f1 = Math.max(f1, f);
                    f = 0.0F;
                    i += charCount;
                } else {
                    GlyphMetrics glyphMetrics = fontAtlas2.getGlyphMetrics(codePoint);
                    if (glyphMetrics != null) {
                        f += glyphMetrics.advance;
                    } else {
                        GlyphMetrics glyphMetrics2 = fontAtlas2.getGlyphMetrics(63);
                        if (glyphMetrics2 != null) {
                            f += glyphMetrics2.advance;
                        } else {
                            f += fontAtlas2.getFontSize() * 0.5F;
                        }
                    }

                    i += charCount;
                }
            }
        }

        return Math.max(f1, f);
    }

    private int getViewportHeight() {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        return minecraftclient != null && minecraftclient.getWindow() != null
                ? (int) Math.ceil((double) minecraftclient.getWindow().getFramebufferHeight() / 2.0)
                : 540;
    }

    public float measureHeight(FontAtlas fontAtlas2, String text, float size) {
        fontAtlas2.ensureLoaded();
        float f1 = size / fontAtlas2.getFontSize();
        int i = 1;

        for (int j = 0; j < text.length(); j++) {
            if (text.charAt(j) == '\n') {
                i++;
            }
        }

        return (float) i * fontAtlas2.getLineHeight() * f1;
    }

    private GpuBuffer nextUniformBuffer() {
        GpuBuffer gpubuffer = this.uniformBuffers[this.uniformBufferIndex];
        if (gpubuffer == null) {
            int uniformBufferIndexValue = this.uniformBufferIndex;
            gpubuffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "client:font_uniform_" + uniformBufferIndexValue,
                                    136,
                                    16448L);
            this.uniformBuffers[this.uniformBufferIndex] = gpubuffer;
        }

        this.uniformBufferIndex = (this.uniformBufferIndex + 1) % 128;
        return gpubuffer;
    }

    public void flush() {
        this.submitPendingGlyphs();
        if (!RenderBatchDispatcher.isBatching() && !this.pendingChunks.isEmpty()) {
            RenderBatchDispatcher.renderImmediately(this, false);
        }
    }

    private void initialize() {
        if (!this.initialized) {
            this.glyphData = MemoryUtil.memAlloc(16448);
            ByteBuffer bytebuffer = MemoryUtil.memAlloc(4);
            bytebuffer.putInt(0);
            bytebuffer.flip();
            this.dummyVertexBuffer =
                    RenderSystem.getDevice()
                            .createBuffer(() -> "client:font_dummy_vertex", 32, bytebuffer);
            MemoryUtil.memFree(bytebuffer);
            this.uniformBuffers = new GpuBuffer[128];
            this.initialized = true;
        }
    }

    private GpuTextureView getOrCreateTextureView(GpuTexture gputexture) {
        GpuTextureView gputextureview = this.textureViews.get(gputexture);
        if (gputextureview == null || gputextureview.isClosed()) {
            this.textureViews
                    .entrySet()
                    .removeIf(
                            entry -> {
                                if (!entry.getKey().isClosed() && !entry.getValue().isClosed()) {
                                    return false;
                                } else {
                                    if (!entry.getValue().isClosed()) {
                                        entry.getValue().close();
                                    }

                                    return true;
                                }
                            });
            gputextureview = RenderSystem.getDevice().createTextureView(gputexture);
            this.textureViews.put(gputexture, gputextureview);
        }

        return gputextureview;
    }

    private int getViewportWidth() {
        MinecraftClient minecraftclient = MinecraftClient.getInstance();
        return minecraftclient != null && minecraftclient.getWindow() != null
                ? (int) Math.ceil((double) minecraftclient.getWindow().getFramebufferWidth() / 2.0)
                : 960;
    }

    @Override
    public void clear() {
        this.pendingChunks.clear();
    }

    @Override
    public void render(RenderPass renderpass) {
        if (!this.pendingChunks.isEmpty()) {
            GpuSampler gpusampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
            renderpass.setPipeline(PIPELINE);
            renderpass.setVertexBuffer(0, this.dummyVertexBuffer);

            for (FontBatchRenderer.FontChunk fontChunk : this.pendingChunks) {
                if (!fontChunk.view().isClosed()) {
                    renderpass.bindTexture("Sampler0", fontChunk.view(), gpusampler);
                    renderpass.setUniform("FontData", fontChunk.buffer());
                    renderpass.draw(0, fontChunk.count() * 6);
                }
            }

            this.pendingChunks.clear();
        }
    }

    @Environment(EnvType.CLIENT)
    private static record ColorAdvance(int skip, int color, boolean matched) {}

    @Environment(EnvType.CLIENT)
    private static record FontChunk(GpuBuffer buffer, GpuTextureView view, int count) {}
}
