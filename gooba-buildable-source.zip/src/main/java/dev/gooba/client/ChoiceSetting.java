package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.List;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class ChoiceSetting<T> extends Setting<T> {
    private T cachedValue;
    public List<T> choices;

    @Override
    public Object getValue() {
        if (this.cachedValue == null) {
            this.cachedValue = (T) super.getValue();
        }

        return this.cachedValue;
    }

    public ChoiceSetting onChange(Runnable runnable) {
        return (ChoiceSetting)
                super.onChange(
                        () -> {
                            runnable.run();
                            this.cachedValue = (T) super.getValue();
                        });
    }

    public ChoiceSetting visibleWhen(Supplier supplier) {
        return (ChoiceSetting) super.visibleWhen(supplier);
    }

    public ChoiceSetting setValue(Object object) {
        this.cachedValue = (T) object;
        return (ChoiceSetting) super.setValue(object);
    }

    public ChoiceSetting setValue2(Object object) {
        this.cachedValue = (T) object;
        return (ChoiceSetting) super.setValue(object);
    }

    @SafeVarargs
    public ChoiceSetting(Module moduleValue, String nameValue, T... objectArray) {
        super(moduleValue, nameValue, objectArray[0]);
        this.choices = List.of((T[]) objectArray);
        this.setValue(objectArray[0]);
        this.cachedValue = (T) objectArray[0];
    }
}
