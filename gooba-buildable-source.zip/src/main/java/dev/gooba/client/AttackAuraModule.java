package dev.gooba.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.AxolotlEntity;
import net.minecraft.entity.passive.CodEntity;
import net.minecraft.entity.passive.DolphinEntity;
import net.minecraft.entity.passive.FishEntity;
import net.minecraft.entity.passive.GlowSquidEntity;
import net.minecraft.entity.passive.PufferfishEntity;
import net.minecraft.entity.passive.SalmonEntity;
import net.minecraft.entity.passive.SchoolingFishEntity;
import net.minecraft.entity.passive.SquidEntity;
import net.minecraft.entity.passive.TropicalFishEntity;
import net.minecraft.entity.passive.TurtleEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

@ModuleInfo(
        name = "Attack Aura",
        desc = "Automatically selects, aims at, and attacks nearby targets",
        category = ModuleCategory.COMBAT,
        key = 82)
@Environment(EnvType.CLIENT)
public class AttackAuraModule extends Module {
    public ModeSetting sprintModeSetting;
    private final List<AttackAuraModule.CubeFragment> fragments;
    public MultiBooleanSetting additionalChecksSetting;
    private int lastHurtTime;
    public SliderSetting extraDetectionRangeSetting;
    private int attackParity;
    private static final RenderPipeline CUBE_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                            .withLocation(Identifier.of("client", "pipeline/aura_target_cube"))
                            .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                            .withCull(false)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withBlend(BlendFunction.TRANSLUCENT)
                            .build());
    private long lastEffectFrameMillis;
    public MultiBooleanSetting pauseWhenSetting;
    public static LivingEntity target;
    public BooleanSetting cubeGlowSetting;
    private float targetCubeYaw;
    private float targetCubePitch;
    private Matrix4f cubeMatrix;
    private float cubeYaw;
    private float cubeHalfSize;
    public MultiBooleanSetting targetsSetting;
    public SliderSetting cubeThicknessSetting;
    public float snapTicksRemaining;
    private float hitFlash;
    private LivingEntity effectTarget;
    public ModeSetting targetEffectSetting;
    public long postAttackPauseUntilMillis;
    private static final RenderLayer CUBE_LAYER =
            RenderLayer.of(
                    "aura_target_cube",
                    RenderSetup.builder(AttackAuraModule.CUBE_PIPELINE)
                            .translucent()
                            .expectedBufferSize(16384)
                            .build());
    public SliderSetting cubeRotationSpeedSetting;
    public ModeSetting rotationModeSetting;
    public SliderSetting fOVSetting;
    public static int attackSuppressionTicks;
    public BooleanSetting changeColorOnHitSetting;
    public SliderSetting cubeSizeSetting;
    private Vec3d cubePosition;
    private final Random random;
    public ModeSetting snapModeSetting;
    public ModeSetting movementCorrectionSetting;
    public BooleanSetting showFOVSetting;
    private int attacksSincePause;
    private int attacksBeforePause;
    private float cubePitch;
    private boolean fragmentsSpawned;
    public long aimChangeUntilMillis;
    public boolean attackOccurred;

    private double targetGroundY;
    public boolean postAttackPause;
    public SliderSetting attackRangeSetting =
            new SliderSetting(this, "Attack Range", 3.0F, 2.5F, 6.0F, 0.1F);

    private void drawCubeGlow(
            Render3DEvent render3DEvent,
            Quaternionf quaternionf,
            double d0,
            double d1,
            double d2,
            float f,
            float f1,
            int i,
            float f2,
            Immediate immediate) {
        RenderLayer renderlayer =
                TargetRingRenderer.texturedLayer.apply(
                        Identifier.of("client", "textures/visuals/particles_2.png"));
        VertexConsumer vertexconsumer = immediate.getBuffer(renderlayer);
        MatrixStack matrixstack = render3DEvent.getMatrixStack();
        Quaternionf rotation = client.gameRenderer.getCamera().getRotation();
        int j = this.multiplyAlpha(this.withAlpha(i, 55), 0.45F * f2);
        float f3 = f1 * 5.0F;

        for (float[] afloat : this.getCubeCornerEdges(f)) {
            for (int k = 0; k <= 2; k++) {
                float f4 = (float) k * 0.5F;
                float f5 = afloat[0] + (afloat[3] - afloat[0]) * f4;
                float f6 = afloat[1] + (afloat[4] - afloat[1]) * f4;
                float f7 = afloat[2] + (afloat[5] - afloat[2]) * f4;
                Vector3f vector3f = quaternionf.transform(new Vector3f(f5, f6, f7));
                this.drawBillboard(
                        vertexconsumer,
                        matrixstack,
                        rotation,
                        d0 + (double) vector3f.x,
                        d1 + (double) vector3f.y,
                        d2 + (double) vector3f.z,
                        f3,
                        j);
            }
        }

        for (byte b0 = -1; b0 <= 1; b0 += 2) {
            for (byte b1 = -1; b1 <= 1; b1 += 2) {
                for (byte b2 = -1; b2 <= 1; b2 += 2) {
                    Vector3f vector3f1 =
                            quaternionf.transform(
                                    new Vector3f((float) b0 * f, (float) b1 * f, (float) b2 * f));
                    this.drawBillboard(
                            vertexconsumer,
                            matrixstack,
                            rotation,
                            d0 + (double) vector3f1.x,
                            d1 + (double) vector3f1.y,
                            d2 + (double) vector3f1.z,
                            f3 * 1.2F,
                            j);
                }
            }
        }

        immediate.draw(renderlayer);
    }

    public static AttackAuraModule getInstance() {
        return (AttackAuraModule) ModuleLookup.getModule(AttackAuraModule.class);
    }

    @EventHandler
    public void onPlayerTick(PlayerTickEvent playerTickEvent) {
        if (target == null || !this.isValidTarget(target)) {
            this.updateTarget();
        }

        if (attackSuppressionTicks != 0) {
            attackSuppressionTicks--;
        }

        if (!this.shouldPause() && target != null) {
            this.attackTarget();
        }
    }

    public float[] getAttackRanges() {
        return new float[] {
            this.attackRangeSetting.getFloat(), this.extraDetectionRangeSetting.getFloat()
        };
    }

    private boolean isValidTarget(LivingEntity livingentity) {
        if (livingentity instanceof ClientPlayerEntity) {
            return false;
        } else if (FakeLagModule.isGhost(livingentity)) {
            return false;
        } else if (client.player.distanceTo(livingentity) > this.getDetectionRange()) {
            return false;
        } else if (!this.additionalChecksSetting.isOn("Hit through blocks")
                && !client.player.canSee(livingentity)) {
            return false;
        } else {
            if (livingentity instanceof PlayerEntity playerentity) {
                if (AntiBotModule.getInstance().isBot(playerentity)) {
                    return false;
                }

                if (Gooba.getInstance()
                                .getFriendManager()
                                .isFriend(playerentity.getName().getString())
                        && !this.targetsSetting.isOn("Friends")) {
                    return false;
                }
            }

            if (livingentity instanceof PlayerEntity && !this.targetsSetting.isOn("Players")) {
                return false;
            } else if (livingentity instanceof PlayerEntity
                    && livingentity.getArmorVisibility() <= 0.0F
                    && !this.targetsSetting.isOn("Unarmored Players")) {
                return false;
            } else if (livingentity instanceof PlayerEntity
                    && ((PlayerEntity) livingentity).isCreative()) {
                return false;
            } else {
                return (livingentity instanceof Monster
                                        || livingentity instanceof SlimeEntity
                                        || livingentity instanceof VillagerEntity
                                        || livingentity instanceof AnimalEntity
                                        || livingentity instanceof FishEntity
                                        || livingentity instanceof SchoolingFishEntity
                                        || livingentity instanceof CodEntity
                                        || livingentity instanceof SalmonEntity
                                        || livingentity instanceof TropicalFishEntity
                                        || livingentity instanceof PufferfishEntity
                                        || livingentity instanceof SquidEntity
                                        || livingentity instanceof GlowSquidEntity
                                        || livingentity instanceof DolphinEntity
                                        || livingentity instanceof TurtleEntity
                                        || livingentity instanceof AxolotlEntity)
                                && !this.targetsSetting.isOn("Mobs")
                        ? false
                        : !livingentity.isInvulnerable()
                                && livingentity.isAlive()
                                && !(livingentity instanceof ArmorStandEntity);
            }
        }
    }

    private float getDetectionRange() {
        return this.attackRangeSetting.getFloat() + this.extraDetectionRangeSetting.getFloat();
    }

    private float getDistanceScaledThickness(Vec3d vec3d, double d0, double d1, double d2) {
        double d3 = d0 - vec3d.x;
        double d4 = d1 - vec3d.y;
        double d5 = d2 - vec3d.z;
        double d6 = Math.sqrt(d3 * d3 + d4 * d4 + d5 * d5);
        return (float) Math.max(0.1, d6 * 0.007);
    }

    private int getTargetColor() {
        int targetColor = ColorUtils.hudAccent();
        if ((targetColor >> 24 & 0xFF) == 0) {
            targetColor |= -16777216;
        }

        return targetColor;
    }

    private void updateTarget() {
        if (FakePlayerModule.fakePlayer != null
                && FakePlayerModule.fakePlayer.isAlive()
                && client.player.distanceTo(FakePlayerModule.fakePlayer)
                        <= this.getDetectionRange()) {
            target = FakePlayerModule.fakePlayer;
        } else {
            LivingEntity livingentity = null;
            double MAX_VALUE = Double.MAX_VALUE;
            Vec3d vec3dx = client.player.getEyePos();
            Vec3d vec3d1 = client.player.getRotationVec(1.0F).normalize();

            for (Entity entity : client.world.getEntities()) {
                if (entity instanceof LivingEntity) {
                    LivingEntity entityValue = (LivingEntity) entity;
                    if (this.isValidTarget(entityValue)) {
                        Vec3d vec3d2 =
                                entityValue
                                        .getEntityPos()
                                        .add(0.0, (double) entityValue.getHeight() * 0.5, 0.0);
                        Vec3d vec3d3 = vec3d2.subtract(vec3dx).normalize();
                        double MAX_VALUEValue =
                                Math.acos(MathHelper.clamp(vec3d1.dotProduct(vec3d3), -1.0, 1.0));
                        if (MAX_VALUEValue < MAX_VALUE) {
                            MAX_VALUE = MAX_VALUEValue;
                            livingentity = entityValue;
                        }
                    }
                }
            }

            target = livingentity;
        }
    }

    private void drawCubeEdge(
            VertexConsumer vertexconsumer,
            Quaternionf quaternionf,
            double d0,
            double d1,
            double d2,
            float[] afloat,
            float f,
            int i) {
        if ((i >> 24 & 0xFF) > 0) {
            Vector3f vector3f = new Vector3f(afloat[0], afloat[1], afloat[2]);
            Vector3f vector3f1 = new Vector3f(afloat[3], afloat[4], afloat[5]);
            Vector3f vector3f2 = new Vector3f(vector3f1).sub(vector3f);
            Vector3f vector3f5;
            Vector3f vector3f6;
            Vector3f vector3f7;
            Vector3f vector3f8;
            Vector3f vector3f9;
            Vector3f vector3f10;
            Vector3f vector3f11;
            Vector3f vector3f12;
            if (Math.abs(vector3f2.x) > 1.0E-5F) {
                Vector3f vector3f3 = new Vector3f(0.0F, f, 0.0F);
                Vector3f vector3f4 = new Vector3f(0.0F, 0.0F, f);
                vector3f5 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).sub(vector3f3).sub(vector3f4));
                vector3f6 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).add(vector3f3).sub(vector3f4));
                vector3f7 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).add(vector3f3).add(vector3f4));
                vector3f8 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).sub(vector3f3).add(vector3f4));
                vector3f9 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).sub(vector3f3).sub(vector3f4));
                vector3f10 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).add(vector3f3).sub(vector3f4));
                vector3f11 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).add(vector3f3).add(vector3f4));
                vector3f12 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).sub(vector3f3).add(vector3f4));
            } else if (Math.abs(vector3f2.y) > 1.0E-5F) {
                Vector3f vector3f13 = new Vector3f(f, 0.0F, 0.0F);
                Vector3f vector3f15 = new Vector3f(0.0F, 0.0F, f);
                vector3f5 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).sub(vector3f13).sub(vector3f15));
                vector3f6 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).add(vector3f13).sub(vector3f15));
                vector3f7 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).add(vector3f13).add(vector3f15));
                vector3f8 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).sub(vector3f13).add(vector3f15));
                vector3f9 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).sub(vector3f13).sub(vector3f15));
                vector3f10 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).add(vector3f13).sub(vector3f15));
                vector3f11 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).add(vector3f13).add(vector3f15));
                vector3f12 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).sub(vector3f13).add(vector3f15));
            } else {
                Vector3f vector3f14 = new Vector3f(f, 0.0F, 0.0F);
                Vector3f vector3f16 = new Vector3f(0.0F, f, 0.0F);
                vector3f5 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).sub(vector3f14).sub(vector3f16));
                vector3f6 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).add(vector3f14).sub(vector3f16));
                vector3f7 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).add(vector3f14).add(vector3f16));
                vector3f8 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f).sub(vector3f14).add(vector3f16));
                vector3f9 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).sub(vector3f14).sub(vector3f16));
                vector3f10 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).add(vector3f14).sub(vector3f16));
                vector3f11 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).add(vector3f14).add(vector3f16));
                vector3f12 =
                        this.transformPoint(
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                new Vector3f(vector3f1).sub(vector3f14).add(vector3f16));
            }

            this.drawPrismSides(
                    vertexconsumer,
                    vector3f5,
                    vector3f6,
                    vector3f7,
                    vector3f8,
                    vector3f9,
                    vector3f10,
                    vector3f11,
                    vector3f12,
                    i);
        }
    }

    private void drawQuad(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            Vector3f vector3f,
            Vector3f vector3f1,
            Vector3f vector3f2,
            Vector3f vector3f3,
            int i) {
        vertexconsumer.vertex(matrix4f, vector3f.x, vector3f.y, vector3f.z).color(i);
        vertexconsumer.vertex(matrix4f, vector3f1.x, vector3f1.y, vector3f1.z).color(i);
        vertexconsumer.vertex(matrix4f, vector3f2.x, vector3f2.y, vector3f2.z).color(i);
        vertexconsumer.vertex(matrix4f, vector3f3.x, vector3f3.y, vector3f3.z).color(i);
    }

    private void drawThickLine(
            VertexConsumer vertexconsumer,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            float f5,
            float f6,
            int i) {
        if ((i >> 24 & 0xFF) > 0) {
            Vector3f vector3f = new Vector3f(f, f1, f2);
            Vector3f vector3f1 = new Vector3f(f3, f4, f5);
            Vector3f vector3f2 = new Vector3f(vector3f1).sub(vector3f);
            if (!(vector3f2.lengthSquared() < 1.0E-10F)) {
                vector3f2.normalize();
                Vector3f vector3f3;
                if (Math.abs(vector3f2.y) < 0.99F) {
                    vector3f3 = new Vector3f(0.0F, 1.0F, 0.0F);
                } else {
                    vector3f3 = new Vector3f(1.0F, 0.0F, 0.0F);
                }

                Vector3f vector3f4 = new Vector3f();
                vector3f2.cross(vector3f3, vector3f4).normalize().mul(f6);
                Vector3f vector3f5 = new Vector3f();
                vector3f2.cross(vector3f4, vector3f5).normalize().mul(f6);
                Vector3f vector3f6 = new Vector3f(vector3f).sub(vector3f4).sub(vector3f5);
                Vector3f vector3f7 = new Vector3f(vector3f).add(vector3f4).sub(vector3f5);
                Vector3f vector3f8 = new Vector3f(vector3f).add(vector3f4).add(vector3f5);
                Vector3f vector3f9 = new Vector3f(vector3f).sub(vector3f4).add(vector3f5);
                Vector3f vector3f10 = new Vector3f(vector3f1).sub(vector3f4).sub(vector3f5);
                Vector3f vector3f11 = new Vector3f(vector3f1).add(vector3f4).sub(vector3f5);
                Vector3f vector3f12 = new Vector3f(vector3f1).add(vector3f4).add(vector3f5);
                Vector3f vector3f13 = new Vector3f(vector3f1).sub(vector3f4).add(vector3f5);
                this.drawPrismSides(
                        vertexconsumer,
                        vector3f6,
                        vector3f7,
                        vector3f8,
                        vector3f9,
                        vector3f10,
                        vector3f11,
                        vector3f12,
                        vector3f13,
                        i);
            }
        }
    }

    private void tickFragments() {
        Iterator iterator = this.fragments.iterator();

        while (iterator.hasNext()) {
            AttackAuraModule.CubeFragment cubeFragment =
                    (AttackAuraModule.CubeFragment) iterator.next();
            cubeFragment.previousPosition = cubeFragment.position;
            cubeFragment.previousRotation = new Vector3f(cubeFragment.rotation);
            cubeFragment.position = cubeFragment.position.add(cubeFragment.velocity);
            cubeFragment.velocity =
                    new Vec3d(
                            cubeFragment.velocity.x * 0.98,
                            cubeFragment.velocity.y - 0.028,
                            cubeFragment.velocity.z * 0.98);
            if (cubeFragment.position.y <= cubeFragment.groundY && cubeFragment.velocity.y < 0.0) {
                cubeFragment.position =
                        new Vec3d(
                                cubeFragment.position.x,
                                cubeFragment.groundY,
                                cubeFragment.position.z);
                cubeFragment.velocity =
                        new Vec3d(
                                cubeFragment.velocity.x * 0.55,
                                -cubeFragment.velocity.y * 0.38,
                                cubeFragment.velocity.z * 0.55);
                cubeFragment.angularVelocity *= 0.6F;
            }

            Quaternionf quaternionf =
                    new Quaternionf()
                            .fromAxisAngleRad(
                                    cubeFragment.rotationAxis.x,
                                    cubeFragment.rotationAxis.y,
                                    cubeFragment.rotationAxis.z,
                                    cubeFragment.angularVelocity);
            cubeFragment.rotation = quaternionf.transform(new Vector3f(cubeFragment.rotation));
            cubeFragment.age++;
            if (cubeFragment.age >= cubeFragment.lifetime) {
                iterator.remove();
            }
        }
    }

    public void drawFragments(Render3DEvent render3DEvent, Immediate immediate) {
        if (!this.fragments.isEmpty()) {
            Vec3d vec3dx = client.gameRenderer.getCamera().getCameraPos();
            int targetColor = this.getTargetColor();
            VertexConsumer vertexconsumer = immediate.getBuffer(CUBE_LAYER);
            this.cubeMatrix = render3DEvent.getMatrixStack().peek().getPositionMatrix();
            float tickDelta = render3DEvent.getTickDelta();

            for (AttackAuraModule.CubeFragment cubeFragment : this.fragments) {
                float f1 =
                        1.0F
                                - (float) cubeFragment.age
                                        / (float) Math.max(1, cubeFragment.lifetime);
                float f2;
                if (f1 > 0.3F) {
                    f2 = 1.0F;
                } else {
                    f2 = Math.max(0.0F, f1 / 0.3F);
                }

                if (!(f2 <= 0.0F)) {
                    Vec3d vec3d1 =
                            new Vec3d(
                                    MathHelper.lerp(
                                            (double) tickDelta,
                                            cubeFragment.previousPosition.x,
                                            cubeFragment.position.x),
                                    MathHelper.lerp(
                                            (double) tickDelta,
                                            cubeFragment.previousPosition.y,
                                            cubeFragment.position.y),
                                    MathHelper.lerp(
                                            (double) tickDelta,
                                            cubeFragment.previousPosition.z,
                                            cubeFragment.position.z));
                    Vector3f vector3f =
                            new Vector3f(cubeFragment.previousRotation)
                                    .lerp(cubeFragment.rotation, tickDelta);
                    double d0 = vec3d1.x - vec3dx.x;
                    double d1 = vec3d1.y - vec3dx.y;
                    double d2 = vec3d1.z - vec3dx.z;
                    float f3 =
                            this.getDistanceScaledThickness(vec3dx, vec3d1.x, vec3d1.y, vec3d1.z)
                                    * this.cubeThicknessSetting.getFloat()
                                    * 0.5F;
                    int j = this.multiplyAlpha(this.withAlpha(targetColor, 255), f2);
                    this.drawThickLine(
                            vertexconsumer,
                            (float) (d0 - (double) vector3f.x),
                            (float) (d1 - (double) vector3f.y),
                            (float) (d2 - (double) vector3f.z),
                            (float) (d0 + (double) vector3f.x),
                            (float) (d1 + (double) vector3f.y),
                            (float) (d2 + (double) vector3f.z),
                            f3,
                            j);
                }
            }

            immediate.draw(CUBE_LAYER);
        }
    }

    private void drawPrismSides(
            VertexConsumer vertexconsumer,
            Vector3f vector3f,
            Vector3f vector3f1,
            Vector3f vector3f2,
            Vector3f vector3f3,
            Vector3f vector3f4,
            Vector3f vector3f5,
            Vector3f vector3f6,
            Vector3f vector3f7,
            int i) {
        this.drawQuad(
                vertexconsumer, this.cubeMatrix, vector3f, vector3f4, vector3f5, vector3f1, i);
        this.drawQuad(
                vertexconsumer, this.cubeMatrix, vector3f1, vector3f5, vector3f6, vector3f2, i);
        this.drawQuad(
                vertexconsumer, this.cubeMatrix, vector3f2, vector3f6, vector3f7, vector3f3, i);
        this.drawQuad(
                vertexconsumer, this.cubeMatrix, vector3f3, vector3f7, vector3f4, vector3f, i);
    }

    private void spawnCubeFragments() {
        float cubeHalfSizeValue = this.cubeHalfSize;
        Vec3d vec3dx = this.cubePosition;
        Quaternionf quaternionf =
                new Quaternionf()
                        .rotateY((float) Math.toRadians((double) this.cubeYaw))
                        .rotateX((float) Math.toRadians((double) this.cubePitch));
        double d0 = this.targetGroundY + 0.05;

        for (float[] afloat : this.getCubeCornerEdges(cubeHalfSizeValue)) {
            Vector3f vector3f =
                    quaternionf.transform(new Vector3f(afloat[0], afloat[1], afloat[2]));
            Vector3f vector3f1 =
                    quaternionf.transform(new Vector3f(afloat[3], afloat[4], afloat[5]));
            Vec3d vec3d1 =
                    vec3dx.add((double) vector3f.x, (double) vector3f.y, (double) vector3f.z);
            Vec3d vec3d2 =
                    vec3dx.add((double) vector3f1.x, (double) vector3f1.y, (double) vector3f1.z);
            Vec3d vec3d3 = vec3d1.add(vec3d2).multiply(0.5);
            Vector3f vector3f2 =
                    new Vector3f(
                            (float) (vec3d2.x - vec3d3.x),
                            (float) (vec3d2.y - vec3d3.y),
                            (float) (vec3d2.z - vec3d3.z));
            Vec3d vec3d4 = vec3d3.subtract(vec3dx);
            if (vec3d4.lengthSquared() < 1.0E-6) {
                vec3d4 =
                        new Vec3d(
                                this.random.nextDouble() - 0.5,
                                0.0,
                                this.random.nextDouble() - 0.5);
            }

            vec3d4 = vec3d4.normalize();
            double d1 = 0.12 + this.random.nextDouble() * 0.14;
            Vec3d vec3d5 =
                    vec3d4.multiply(d1)
                            .add(
                                    (this.random.nextDouble() - 0.5) * 0.06,
                                    0.08 + this.random.nextDouble() * 0.16,
                                    (this.random.nextDouble() - 0.5) * 0.06);
            Vector3f vector3f3 =
                    new Vector3f(
                            this.random.nextFloat() - 0.5F,
                            this.random.nextFloat() - 0.5F,
                            this.random.nextFloat() - 0.5F);
            if (vector3f3.lengthSquared() < 1.0E-6F) {
                vector3f3.set(0.0F, 1.0F, 0.0F);
            }

            vector3f3.normalize();
            float f1 = 0.12F + this.random.nextFloat() * 0.28F;
            int i = 50 + this.random.nextInt(30);
            this.fragments.add(
                    new AttackAuraModule.CubeFragment(
                            vec3d3, vector3f2, vec3d5, vector3f3, f1, d0, i));
        }
    }

    private boolean shouldPause() {
        boolean flagx;
        flagx = (client.player.isUsingItem() && this.pauseWhenSetting.isOn("Eating"));

        boolean flag1;
        flag1 =
                (this.pauseWhenSetting.isOn("Container Open")
                        && client.currentScreen != null
                        && !(client.currentScreen instanceof ClickGuiScreen));

        return flagx || flag1;
    }

    private float[][] getCubeCornerEdges(float f) {
        float f1 = f * 0.46F;
        float f2 = f - f1;
        float[][] afloat = new float[24][];
        int i = 0;

        for (byte b0 = -1; b0 <= 1; b0 += 2) {
            for (byte b1 = -1; b1 <= 1; b1 += 2) {
                for (byte b2 = -1; b2 <= 1; b2 += 2) {
                    float f3 = (float) b0 * f;
                    float f4 = (float) b1 * f;
                    float f5 = (float) b2 * f;
                    afloat[i++] = new float[] {f3, f4, f5, (float) b0 * f2, f4, f5};
                    afloat[i++] = new float[] {f3, f4, f5, f3, (float) b1 * f2, f5};
                    afloat[i++] = new float[] {f3, f4, f5, f3, f4, (float) b2 * f2};
                }
            }
        }

        return afloat;
    }

    public void resetTargetEffect() {
        this.cubeYaw = 0.0F;
        this.cubePitch = 0.0F;
        this.targetCubeYaw = 0.0F;
        this.targetCubePitch = 0.0F;
        this.hitFlash = 0.0F;
        this.lastHurtTime = 0;
        this.lastEffectFrameMillis = System.currentTimeMillis();
        this.effectTarget = null;
        this.cubePosition = null;
        this.cubeHalfSize = 0.6F;
        this.targetGroundY = 0.0;
        this.fragmentsSpawned = false;
        this.fragments.clear();
        this.cubeMatrix = null;
    }

    private void putTexturedVertex(
            VertexConsumer vertexconsumer,
            Matrix4f matrix4f,
            float f,
            float f1,
            float f2,
            float f3,
            float f4,
            int i) {
        vertexconsumer
                .vertex(matrix4f, f, f1, f2)
                .color(i)
                .texture(f3, f4)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(15728880)
                .normal(0.0F, 0.0F, 1.0F);
    }

    private int withAlpha(int i, int j) {

        return MathHelper.clamp(j, 0, 255) << 24 | i & 16777215;
    }

    @EventHandler
    private void onMovementInput(MovementInputEvent movementInputEvent) {
        if (target != null
                && client.player != null
                && client.world != null
                && CombatUtils.shouldResetSprint(target, this.getAttackRanges())
                && target != null
                && !CollisionUtils.isCriticalPrevented()
                && this.sprintModeSetting.isSelected("Legit")) {
            movementInputEvent.setForward(0.0F);
            movementInputEvent.setStrafe(0.0F);
        }

        if (target != null
                && client.player != null
                && client.world != null
                && this.movementCorrectionSetting.isSelected("Free")) {
            MovementUtils.correctMovementInput(
                    movementInputEvent,
                    client.player.getYaw(),
                    client.gameRenderer.getCamera().getYaw());
        }

        if (target != null
                && client.player != null
                && client.world != null
                && this.movementCorrectionSetting.isSelected("Focused")
                && !client.player.isSubmergedInWater()) {
            Vec3d vec3dx = target.getEntityPos().subtract(client.player.getEyePos()).normalize();
            float f = (float) Math.toDegrees(Math.atan2(-vec3dx.x, vec3dx.z));
            MovementUtils.correctMovementInput(movementInputEvent, client.player.getYaw(), f);
        }
    }

    private int interpolateColor(int i, int j, float f) {
        float f1 = MathHelper.clamp(f, 0.0F, 1.0F);
        int k = i >> 16 & 0xFF;
        int l = i >> 8 & 0xFF;
        int i11 = i & 0xFF;
        int j1 = i >> 24 & 0xFF;
        int k1 = j >> 16 & 0xFF;
        int l1 = j >> 8 & 0xFF;
        int i2 = j & 0xFF;
        int j2 = j >> 24 & 0xFF;
        int k2 = (int) ((float) k + (float) (k1 - k) * f1);
        int l2 = (int) ((float) l + (float) (l1 - l) * f1);
        int i3 = (int) ((float) i11 + (float) (i2 - i11) * f1);
        int j3 = (int) ((float) j1 + (float) (j2 - j1) * f1);
        return j3 << 24 | k2 << 16 | l2 << 8 | i3;
    }

    private int multiplyAlpha(int i, float f) {

        int j = MathHelper.clamp((int) ((float) (i >> 24 & 255) * f), 0, 255);

        return j << 24 | i & 16777215;
    }

    @EventHandler
    public void onPlayerRotation(PlayerRotationEvent playerRotationEvent) {}

    @EventHandler
    public void onRender2D(Render2DEvent render2DEvent) {
        if (client.player != null && client.world != null && target != null) {
            if (!this.rotationModeSetting.isSelected("Snap")
                    || !this.snapModeSetting.isSelected("FOV")
                    || !this.showFOVSetting.isOn()
                    || client.player == null
                    || client.world == null) {
                return;
            }

            float f = 2.0F;
            float scaleFactor = (float) client.getWindow().getScaleFactor();
            float f2 = f / scaleFactor;
            int i = (int) ((float) client.getWindow().getScaledWidth() / f2);
            int j = (int) ((float) client.getWindow().getScaledHeight() / f2);
            float f3 = (float) i;
            float f4 = (float) j;
            float f5 = f3 / 2.0F;
            float f6 = f4 / 2.0F;
            float f7 = RenderUtils.Render3D.projectionMatrix.m00();
            int hurtTime = target.hurtTime;
            float progress = (float) Math.sin((double) hurtTime * (Math.PI / 10));
            int endColor = ColorUtils.cachedRgba(255, 100, 100, 255);
            float radius =
                    (float)
                            (Math.tan(Math.toRadians((double) (this.fOVSetting.getFloat() - 15.0F)))
                                    * (double) (f3 / 2.0F)
                                    * (double) f7);
            float width = radius * 2.0F;
            float f11 = f5 - radius;
            float f12 = f6 - radius;
            if (target != null) {}

            int color =
                    ColorUtils.interpolate(
                            ColorUtils.scaleAlpha(ColorUtils.opaqueGrayscale(255), 255.0F),
                            endColor,
                            progress);
            RenderUtils.Render2D.drawRoundedOutline(
                    f11, f12, width, width, 1.0F, ColorUtils.withOpacity(color, 0.1F), radius);
        }
    }

    private void drawBillboard(
            VertexConsumer vertexconsumer,
            MatrixStack matrixstack,
            Quaternionf quaternionf,
            double d0,
            double d1,
            double d2,
            float f,
            int i) {
        if ((i >> 24 & 0xFF) > 0) {
            matrixstack.push();
            matrixstack.translate(d0, d1, d2);
            matrixstack.multiply(quaternionf);
            Matrix4f matrix4fx = matrixstack.peek().getPositionMatrix();
            this.putTexturedVertex(vertexconsumer, matrix4fx, -f, -f, 0.0F, 0.0F, 1.0F, i);
            this.putTexturedVertex(vertexconsumer, matrix4fx, f, -f, 0.0F, 1.0F, 1.0F, i);
            this.putTexturedVertex(vertexconsumer, matrix4fx, f, f, 0.0F, 1.0F, 0.0F, i);
            this.putTexturedVertex(vertexconsumer, matrix4fx, -f, f, 0.0F, 0.0F, 0.0F, i);
            matrixstack.pop();
        }
    }

    public void attackTarget() {
        if (!(TargetPositionUtils.distanceToHitbox(target)
                >= (double) this.attackRangeSetting.getFloat().floatValue())) {
            float[] afloat = this.getAttackRanges();
            afloat = new float[] {afloat[0], afloat[1], afloat[0] + afloat[1]};
            if (target != null) {
                CombatUtils.tryComboAttack(target, false, true, false);
                LivingEntity livingentity = target;
                boolean flagx;
                if (!this.rotationModeSetting.isSelected("HvH")) {
                    flagx = CombatUtils.canAttack(livingentity, true, true, true, 0L, afloat);
                } else {
                    flagx = CombatUtils.canAttack(livingentity, false, true, true, 0L, afloat);
                }

                if (flagx) {
                    Runnable[] arunnable = CombatUtils.shieldBreakActions(target, true);
                    Runnable[] runnableArray = CombatUtils.blockingActions(true);
                    Runnable[] runnables;
                    if (!this.sprintModeSetting.isSelected("Packet")
                            && !this.sprintModeSetting.isSelected("Silent")) {
                        runnables = CombatUtils.sprintActions(false);
                    } else {
                        runnables = CombatUtils.sprintActions(true);
                    }

                    Runnable runnable =
                            () -> {
                                runnables[0].run();
                                runnableArray[0].run();
                                arunnable[0].run();
                            };
                    Runnable runnableValue =
                            () -> {
                                arunnable[1].run();
                                runnableArray[1].run();
                                runnables[1].run();
                            };
                    CombatUtils.attack(target, runnable, runnableValue, Hand.MAIN_HAND, false);
                    this.attackOccurred = true;
                    this.aimChangeUntilMillis = System.currentTimeMillis() + (250L);
                    this.attackParity = (this.attackParity + 1) % 2;
                    this.attacksSincePause++;
                    if (this.attacksSincePause >= this.attacksBeforePause) {
                        this.attacksSincePause = 0;
                        this.attacksBeforePause = ThreadLocalRandom.current().nextInt(15, 19);
                        this.postAttackPause = true;
                        this.postAttackPauseUntilMillis =
                                System.currentTimeMillis()
                                        + (long) ThreadLocalRandom.current().nextInt(50, 70);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (this.targetEffectSetting.isSelected("Cube")) {
            this.tickFragments();
            LivingEntity livingentity = this.effectTarget;
            if (livingentity != null) {
                boolean flagx =
                        livingentity.isRemoved()
                                || livingentity.getHealth() <= 0.0F
                                || livingentity.isDead();
                if (flagx) {
                    if (!this.fragmentsSpawned && this.cubePosition != null) {
                        this.spawnCubeFragments();
                    }

                    this.fragmentsSpawned = true;
                    this.effectTarget = null;
                    this.lastHurtTime = 0;
                } else {
                    int hurtTime = livingentity.hurtTime;
                    if (hurtTime > this.lastHurtTime) {
                        int j = 1 + this.random.nextInt(3);
                        int k = this.random.nextInt(2);
                        float f = this.random.nextBoolean() ? 1.0F : -1.0F;
                        float f1 = this.random.nextBoolean() ? 1.0F : -1.0F;
                        this.targetCubeYaw += f * 90.0F * (float) j;
                        this.targetCubePitch += f1 * 90.0F * (float) k;
                        this.hitFlash = 1.0F;
                    }

                    this.lastHurtTime = hurtTime;
                }
            }
        }
    }

    public void drawTargetCube(
            Render3DEvent render3DEvent, LivingEntity livingentity, float f, Immediate immediate) {
        Vec3d vec3dx = client.gameRenderer.getCamera().getCameraPos();
        Vec3d vec3d1 = livingentity.getLerpedPos(render3DEvent.getTickDelta());
        float height = livingentity.getHeight();
        float width = livingentity.getWidth();
        if (livingentity.isAlive()) {
            if (this.effectTarget != livingentity) {
                this.lastHurtTime = livingentity.hurtTime;
            }

            this.effectTarget = livingentity;
            this.fragmentsSpawned = false;
        }

        float f3 = (float) Easings.IN_OUT_SINE.ease((double) MathHelper.clamp(f, 0.0F, 1.0F));
        if (!(f3 <= 0.001F)) {
            float cubeHalfSizeValue =
                    (width * 0.5F + 0.08F) * this.cubeSizeSetting.getFloat() * (0.55F + 0.45F * f3);
            Vec3d vec3d2 = vec3d1.add(0.0, (double) height * 0.5, 0.0);
            this.cubePosition = vec3d2;
            this.cubeHalfSize = cubeHalfSizeValue;
            this.targetGroundY = vec3d1.y;
            long nowMillis = System.currentTimeMillis();
            float f5 =
                    MathHelper.clamp(
                            (float) (nowMillis - this.lastEffectFrameMillis) / 1000.0F, 0.0F, 0.1F);
            this.lastEffectFrameMillis = nowMillis;
            float f6 =
                    1.0F
                            - (float)
                                    Math.exp(
                                            (double)
                                                    (-(6.0F
                                                                    + this.cubeRotationSpeedSetting
                                                                                    .getFloat()
                                                                            * 3.0F)
                                                            * f5));
            this.cubeYaw = this.cubeYaw + (this.targetCubeYaw - this.cubeYaw) * f6;
            this.cubePitch = this.cubePitch + (this.targetCubePitch - this.cubePitch) * f6;
            if (Math.abs(this.targetCubeYaw - this.cubeYaw) < 0.05F) {
                this.cubeYaw = this.targetCubeYaw;
            }

            if (Math.abs(this.targetCubePitch - this.cubePitch) < 0.05F) {
                this.cubePitch = this.targetCubePitch;
            }

            this.hitFlash = Math.max(0.0F, this.hitFlash - f5 * 2.2F);
            int targetColor = this.getTargetColor();
            int targetColorValue = targetColor;
            if (this.changeColorOnHitSetting.isOn() && this.hitFlash > 0.0F) {
                targetColorValue =
                        this.interpolateColor(
                                targetColor,
                                ColorUtils.cachedRgba(255, 25, 25, 255),
                                this.hitFlash);
            }

            targetColorValue = this.multiplyAlpha(this.withAlpha(targetColorValue, 190), f3);
            Quaternionf quaternionf =
                    new Quaternionf()
                            .rotateY((float) Math.toRadians((double) this.cubeYaw))
                            .rotateX((float) Math.toRadians((double) this.cubePitch));
            float f7 =
                    this.getDistanceScaledThickness(vec3dx, vec3d2.x, vec3d2.y, vec3d2.z)
                            * this.cubeThicknessSetting.getFloat()
                            * 0.5F;
            VertexConsumer vertexconsumer = immediate.getBuffer(CUBE_LAYER);
            double d0 = vec3d2.x - vec3dx.x;
            double d1 = vec3d2.y - vec3dx.y;
            double d2 = vec3d2.z - vec3dx.z;
            this.cubeMatrix = render3DEvent.getMatrixStack().peek().getPositionMatrix();

            for (float[] afloat : this.getCubeCornerEdges(cubeHalfSizeValue)) {
                this.drawCubeEdge(
                        vertexconsumer, quaternionf, d0, d1, d2, afloat, f7, targetColorValue);
            }

            for (byte b0 = -1; b0 <= 1; b0 += 2) {
                for (byte b1 = -1; b1 <= 1; b1 += 2) {
                    for (byte b2 = -1; b2 <= 1; b2 += 2) {
                        this.drawCubeJoint(
                                vertexconsumer,
                                quaternionf,
                                d0,
                                d1,
                                d2,
                                (float) b0 * cubeHalfSizeValue,
                                (float) b1 * cubeHalfSizeValue,
                                (float) b2 * cubeHalfSizeValue,
                                f7,
                                targetColorValue);
                    }
                }
            }

            immediate.draw(CUBE_LAYER);
            if (this.cubeGlowSetting.isOn()) {
                this.drawCubeGlow(
                        render3DEvent,
                        quaternionf,
                        d0,
                        d1,
                        d2,
                        cubeHalfSizeValue,
                        f7,
                        targetColor,
                        f3,
                        immediate);
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        target = null;
        this.attacksSincePause = 0;
        this.postAttackPause = false;
        this.resetTargetEffect();
    }

    public AttackAuraModule() {
        this.extraDetectionRangeSetting =
                new SliderSetting(this, "Extra Detection Range", 1.0F, 0.0F, 3.0F, 0.1F);
        this.targetsSetting =
                new MultiBooleanSetting(
                        this,
                        "Targets",
                        new BooleanSetting[] {
                            new BooleanSetting("Players", true),
                            new BooleanSetting("Unarmored Players", true),
                            new BooleanSetting("Mobs", false),
                            new BooleanSetting("Friends", false)
                        });
        this.rotationModeSetting =
                new ModeSetting(
                        this, "Rotation Mode", new String[] {"Universal", "Grim", "Snap", "HvH"});
        this.snapModeSetting =
                new ModeSetting(this, "Snap Mode", new String[] {"360", "FOV"})
                        .visibleWhen(() -> this.rotationModeSetting.isSelected("Snap"));
        this.fOVSetting =
                new SliderSetting(this, "FOV", 50.0F, 25.0F, 90.0F, 1.0F)
                        .visibleWhen(
                                () ->
                                        (this.rotationModeSetting.isSelected("Snap")
                                                && this.snapModeSetting.isSelected("FOV")));
        this.showFOVSetting =
                new BooleanSetting(this, "Show FOV", false)
                        .visibleWhen(
                                () ->
                                        (this.rotationModeSetting.isSelected("Snap")
                                                && this.snapModeSetting.isSelected("FOV")));
        this.sprintModeSetting =
                new ModeSetting(this, "Sprint Mode", new String[] {"Packet", "Silent", "Legit"});
        this.movementCorrectionSetting =
                new ModeSetting(this, "Movement Correction", new String[] {"Focused", "Free"});
        this.targetEffectSetting =
                new ModeSetting(
                                this,
                                "Target Effect",
                                new String[] {"Off", "Image", "Spirits", "Ring", "Cubes", "Cube"})
                        .visibleWhen(() -> false);
        this.cubeSizeSetting =
                new SliderSetting(this, "Cube size", 1.15F, 0.6F, 2.5F, 0.05F)
                        .visibleWhen(() -> this.targetEffectSetting.isSelected("Cube"));
        this.cubeRotationSpeedSetting =
                new SliderSetting(this, "Cube rotation speed", 1.2F, 0.2F, 4.0F, 0.05F)
                        .visibleWhen(() -> this.targetEffectSetting.isSelected("Cube"));
        this.cubeThicknessSetting =
                new SliderSetting(this, "Cube thickness", 2.2F, 0.6F, 5.0F, 0.1F)
                        .visibleWhen(() -> this.targetEffectSetting.isSelected("Cube"));
        this.changeColorOnHitSetting =
                new BooleanSetting(this, "Change Color On Hit", true)
                        .visibleWhen(() -> this.targetEffectSetting.isSelected("Cube"));
        this.cubeGlowSetting =
                new BooleanSetting(this, "Cube Glow", true)
                        .visibleWhen(() -> this.targetEffectSetting.isSelected("Cube"));
        this.additionalChecksSetting =
                new MultiBooleanSetting(
                        this,
                        "Additional Checks",
                        new BooleanSetting[] {
                            new BooleanSetting("Smart Crits", false),
                            new BooleanSetting("Hit through blocks", false)
                        });
        this.pauseWhenSetting =
                new MultiBooleanSetting(
                        this,
                        "Pause When",
                        new BooleanSetting[] {
                            new BooleanSetting("Eating", false),
                            new BooleanSetting("Container Open", false)
                        });
        this.snapTicksRemaining = 0.0F;
        this.attackOccurred = false;
        this.aimChangeUntilMillis = 0L;
        this.attacksSincePause = 0;
        this.attacksBeforePause = ThreadLocalRandom.current().nextInt(14, 19);
        this.postAttackPause = false;
        this.postAttackPauseUntilMillis = 0L;
        this.lastEffectFrameMillis = System.currentTimeMillis();
        this.cubeHalfSize = 0.6F;
        this.fragments = new ArrayList<>();
        this.random = new Random();
    }

    @EventHandler
    private void onWorldLoad(WorldLoadEvent worldLoadEvent) {
        target = null;
        this.attacksSincePause = 0;
        this.postAttackPause = false;
        this.resetTargetEffect();
    }

    private Vector3f transformPoint(
            Quaternionf quaternionf, double d0, double d1, double d2, Vector3f vector3f) {
        quaternionf.transform(vector3f);
        vector3f.add((float) d0, (float) d1, (float) d2);
        return vector3f;
    }

    public double angularDistanceToTarget(LivingEntity livingentity) {

        Vec3d vec3dx =
                livingentity.getEntityPos().add(0.0, (double) livingentity.getHeight() * 0.5, 0.0);

        Vec3d vec3d1 = vec3dx.subtract(client.player.getEyePos());

        float f = (float) Math.toDegrees(Math.atan2(-vec3d1.x, vec3d1.z));

        float f1 =
                (float)
                        MathHelper.clamp(
                                -Math.toDegrees(
                                        Math.atan2(vec3d1.y, Math.hypot(vec3d1.x, vec3d1.z))),
                                -90.0,
                                90.0);

        float f2 = MathHelper.wrapDegrees(f - Rotation.getCameraYaw());

        float f3 = f1 - Rotation.getCameraPitch();

        return Math.hypot((double) f2, (double) f3);
    }

    private void drawCubeJoint(
            VertexConsumer vertexconsumer,
            Quaternionf quaternionf,
            double d0,
            double d1,
            double d2,
            float f,
            float f1,
            float f2,
            float f3,
            int i) {
        if ((i >> 24 & 0xFF) > 0) {
            Vector3f vector3f =
                    this.transformPoint(
                            quaternionf, d0, d1, d2, new Vector3f(f - f3, f1 - f3, f2 - f3));
            Vector3f vector3f1 =
                    this.transformPoint(
                            quaternionf, d0, d1, d2, new Vector3f(f + f3, f1 - f3, f2 - f3));
            Vector3f vector3f2 =
                    this.transformPoint(
                            quaternionf, d0, d1, d2, new Vector3f(f + f3, f1 + f3, f2 - f3));
            Vector3f vector3f3 =
                    this.transformPoint(
                            quaternionf, d0, d1, d2, new Vector3f(f - f3, f1 + f3, f2 - f3));
            Vector3f vector3f4 =
                    this.transformPoint(
                            quaternionf, d0, d1, d2, new Vector3f(f - f3, f1 - f3, f2 + f3));
            Vector3f vector3f5 =
                    this.transformPoint(
                            quaternionf, d0, d1, d2, new Vector3f(f + f3, f1 - f3, f2 + f3));
            Vector3f vector3f6 =
                    this.transformPoint(
                            quaternionf, d0, d1, d2, new Vector3f(f + f3, f1 + f3, f2 + f3));
            Vector3f vector3f7 =
                    this.transformPoint(
                            quaternionf, d0, d1, d2, new Vector3f(f - f3, f1 + f3, f2 + f3));
            this.drawQuad(
                    vertexconsumer, this.cubeMatrix, vector3f, vector3f1, vector3f2, vector3f3, i);
            this.drawQuad(
                    vertexconsumer, this.cubeMatrix, vector3f4, vector3f7, vector3f6, vector3f5, i);
            this.drawQuad(
                    vertexconsumer, this.cubeMatrix, vector3f, vector3f4, vector3f5, vector3f1, i);
            this.drawQuad(
                    vertexconsumer, this.cubeMatrix, vector3f3, vector3f2, vector3f6, vector3f7, i);
            this.drawQuad(
                    vertexconsumer, this.cubeMatrix, vector3f, vector3f3, vector3f7, vector3f4, i);
            this.drawQuad(
                    vertexconsumer, this.cubeMatrix, vector3f1, vector3f5, vector3f6, vector3f2, i);
        }
    }

    @EventHandler
    public void onClientTick2(ClientTickEvent clientTickEvent) throws CloneNotSupportedException {
        if (target != null && client.player != null && client.world != null) {
            float[] afloat = this.getAttackRanges();
            afloat = new float[] {afloat[0], afloat[1], afloat[0] + afloat[1]};
            boolean canAttack = CombatUtils.canAttack(target, false, true, true, -350L, afloat);

            for (RotationMode rotationMode : RotationMode.values()) {
                if (this.rotationModeSetting.isSelected(rotationMode.getName())) {
                    rotationMode
                            .getRotationModeHandler()
                            .updateRotation(this, target, afloat, canAttack);
                    break;
                }
            }
        }
    }

    @Environment(EnvType.CLIENT)
    private static class CubeFragment {
        private Vector3f previousRotation;
        private final Vector3f rotationAxis;
        private Vec3d position;
        private float angularVelocity;
        private final double groundY;
        private Vector3f rotation;
        private Vec3d previousPosition;
        private final int lifetime;
        private Vec3d velocity;
        private int age;

        private CubeFragment(
                Vec3d vec3d,
                Vector3f vector3f,
                Vec3d vec3d1,
                Vector3f vector3f1,
                float angularVelocityValue,
                double groundYValue,
                int lifetimeValue) {
            this.previousPosition = vec3d;
            this.position = vec3d;
            this.previousRotation = new Vector3f(vector3f);
            this.rotation = vector3f;
            this.velocity = vec3d1;
            this.rotationAxis = vector3f1;
            this.angularVelocity = angularVelocityValue;
            this.groundY = groundYValue;
            this.lifetime = lifetimeValue;
        }
    }
}
