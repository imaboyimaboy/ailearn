package dev.gooba.client;

import com.google.common.collect.Lists;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Collections;
import java.util.List;
import java.util.function.BooleanSupplier;

@Environment(EnvType.CLIENT)
public class Script {
    private int tickStepIndex;
    private final List<Script.ScriptTickStep> tickSteps;
    private final List<Script.ScriptStep> timedSteps;
    private final ElapsedTimer elapsedTimer = new ElapsedTimer();
    private int timedStepIndex;
    private boolean paused;
    private Script.LoopStrategy loopStrategy;

    public Script addTickStep(int i, ScriptAction scriptAction2, BooleanSupplier booleansupplier) {
        return this.addTickStep(i, scriptAction2, booleansupplier, 0);
    }

    public Script addTickStep(
            int i, ScriptAction scriptAction2, BooleanSupplier booleansupplier, int j) {
        this.tickSteps.add(new Script.ScriptTickStep(i, scriptAction2, booleansupplier, j));
        Collections.sort(this.tickSteps);
        return this;
    }

    public void resetCursors() {
        this.timedStepIndex = 0;
        this.tickStepIndex = 0;
    }

    public void resetTimer() {
        this.elapsedTimer.reset();
    }

    public Script() {
        this.timedSteps = Lists.newCopyOnWriteArrayList();
        this.tickSteps = Lists.newCopyOnWriteArrayList();
        this.loopStrategy = new Script.FiniteLoopStrategy(1);
        this.clear();
    }

    public void tick() {
        if ((!this.timedSteps.isEmpty() || !this.tickSteps.isEmpty()) && !this.paused) {
            this.timedSteps.forEach(
                    scriptstep -> {
                        if (this.timedStepIndex < this.timedSteps.size()) {
                            Script.ScriptStep scriptStep = this.timedSteps.get(this.timedStepIndex);
                            if (scriptStep.getCondition().getAsBoolean()
                                    && this.elapsedTimer.hasElapsed(
                                            (double) scriptStep.getDelayMillis())) {
                                scriptStep.getAction().perform();
                                this.timedStepIndex++;
                                this.resetTimer();
                                if (this.loopStrategy.shouldRepeat(
                                        this.timedStepIndex, this.timedSteps.size())) {
                                    this.resetCursors();
                                    this.loopStrategy.onLoopComplete();
                                }
                            }
                        }
                    });
            this.tickSteps.forEach(
                    scripttickstep -> {
                        if (this.tickStepIndex < this.tickSteps.size()) {
                            Script.ScriptTickStep scriptTickStep =
                                    this.tickSteps.get(this.tickStepIndex);
                            if (scriptTickStep.getCondition().getAsBoolean()
                                    && scriptTickStep.getRemainingTicks() <= 0) {
                                scriptTickStep.getAction().perform();
                                this.tickStepIndex++;
                                this.resetTimer();
                                if (this.loopStrategy.shouldRepeat(
                                        this.tickStepIndex, this.tickSteps.size())) {
                                    this.resetCursors();
                                    this.loopStrategy.onLoopComplete();
                                }
                            }

                            scriptTickStep.tick();
                        }
                    });
            this.timedStepIndex = Math.min(this.timedStepIndex, this.timedSteps.size());
            this.tickStepIndex = Math.min(this.tickStepIndex, this.tickSteps.size());
        }
    }

    public Script clear() {
        this.timedSteps.clear();
        this.tickSteps.clear();
        this.resetTimer();
        this.resetCursors();
        return this;
    }

    public boolean isFinished() {
        return this.timedStepIndex >= this.timedSteps.size()
                && this.tickStepIndex >= this.tickSteps.size()
                && !this.paused
                && this.loopStrategy.isFinished();
    }

    @Environment(EnvType.CLIENT)
    public static class FiniteLoopStrategy implements Script.LoopStrategy {
        private int completedLoops;
        private final int repeatCount;

        @Override
        public boolean shouldRepeat(int i, int j) {
            return i >= j && this.completedLoops < this.repeatCount;
        }

        @Override
        public void onLoopComplete() {
            this.completedLoops++;
        }

        @Override
        public boolean isFinished() {
            return this.completedLoops >= this.repeatCount;
        }

        public FiniteLoopStrategy(int i) {
            this.repeatCount = i - 1;
        }
    }

    @Environment(EnvType.CLIENT)
    public static class InfiniteLoopStrategy implements Script.LoopStrategy {
        @Override
        public boolean isFinished() {
            return false;
        }

        @Override
        public void onLoopComplete() {}

        @Override
        public boolean shouldRepeat(int i, int j) {
            return i >= j;
        }
    }

    @Environment(EnvType.CLIENT)
    public interface LoopStrategy {
        void onLoopComplete();

        boolean isFinished();

        boolean shouldRepeat(int i, int j);
    }

    @Environment(EnvType.CLIENT)
    public static final class ScriptStep implements Comparable<Script.ScriptStep> {
        private int delayMillis;
        private ScriptAction action;
        private int priority;
        private BooleanSupplier condition;

        public int getDelayMillis() {
            return this.delayMillis;
        }

        public ScriptAction getAction() {
            return this.action;
        }

        public BooleanSupplier getCondition() {
            return this.condition;
        }

        @Override
        public int compareTo(Script.ScriptStep scriptStep) {
            return Integer.compare(scriptStep.getPriority(), this.getPriority());
        }

        public int getPriority() {
            return this.priority;
        }
    }

    @Environment(EnvType.CLIENT)
    public static final class ScriptTickStep implements Comparable<Script.ScriptTickStep> {
        private ScriptAction action;
        private int remainingTicks;
        private int priority;
        private BooleanSupplier condition;

        public ScriptAction getAction() {
            return this.action;
        }

        public int getPriority() {
            return this.priority;
        }

        public void tick() {
            this.remainingTicks--;
        }

        public int getRemainingTicks() {
            return this.remainingTicks;
        }

        public BooleanSupplier getCondition() {
            return this.condition;
        }

        public ScriptTickStep(
                int remainingTicksValue,
                ScriptAction scriptAction2,
                BooleanSupplier booleansupplier,
                int priorityValue) {
            this.remainingTicks = remainingTicksValue;
            this.action = scriptAction2;
            this.condition = booleansupplier;
            this.priority = priorityValue;
        }

        @Override
        public int compareTo(Script.ScriptTickStep scriptTickStep) {
            return Integer.compare(scriptTickStep.getPriority(), this.getPriority());
        }
    }
}
