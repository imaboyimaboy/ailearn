package dev.gooba.client;

import java.util.Map;

/** GLSL resource paths. */
public final class ShaderCatalog {
    public static final Map<String, String> RESOURCES =
            Map.ofEntries(
                    Map.entry(
                            "core/arc_outline_vertex|vsh",
                            "/assets/client/shaders/core/arc_outline_vertex.vsh"),
                    Map.entry("core/arc_vertex|vsh", "/assets/client/shaders/core/arc_vertex.vsh"),
                    Map.entry("core/blur|fsh", "/assets/client/shaders/core/blur.fsh"),
                    Map.entry("core/blur|vsh", "/assets/client/shaders/core/blur.vsh"),
                    Map.entry(
                            "core/burn_composite|fsh",
                            "/assets/client/shaders/core/burn_composite.fsh"),
                    Map.entry(
                            "core/burn_composite|vsh",
                            "/assets/client/shaders/core/burn_composite.vsh"),
                    Map.entry(
                            "core/arc_outline_fragment|fsh",
                            "/assets/client/shaders/core/arc_outline_fragment.fsh"),
                    Map.entry(
                            "core/arc_fragment|fsh",
                            "/assets/client/shaders/core/arc_fragment.fsh"),
                    Map.entry("core/burn_glow|fsh", "/assets/client/shaders/core/burn_glow.fsh"),
                    Map.entry("core/burn_glow|vsh", "/assets/client/shaders/core/burn_glow.vsh"),
                    Map.entry("core/burn_trail|fsh", "/assets/client/shaders/core/burn_trail.fsh"),
                    Map.entry("core/burn_trail|vsh", "/assets/client/shaders/core/burn_trail.vsh"),
                    Map.entry(
                            "core/circle_progress|fsh",
                            "/assets/client/shaders/core/circle_progress.fsh"),
                    Map.entry(
                            "core/circle_progress|vsh",
                            "/assets/client/shaders/core/circle_progress.vsh"),
                    Map.entry(
                            "core/clickgui_dots|fsh",
                            "/assets/client/shaders/core/clickgui_dots.fsh"),
                    Map.entry(
                            "core/clickgui_dots|vsh",
                            "/assets/client/shaders/core/clickgui_dots.vsh"),
                    Map.entry("core/fog_blur|fsh", "/assets/client/shaders/core/fog_blur.fsh"),
                    Map.entry("core/fog_blur|vsh", "/assets/client/shaders/core/fog_blur.vsh"),
                    Map.entry(
                            "core/glass_composite|fsh",
                            "/assets/client/shaders/core/glass_composite.fsh"),
                    Map.entry(
                            "core/glass_composite|vsh",
                            "/assets/client/shaders/core/glass_composite.vsh"),
                    Map.entry(
                            "core/glass_outline_combine|fsh",
                            "/assets/client/shaders/core/glass_outline_combine.fsh"),
                    Map.entry(
                            "core/glass_outline_down|fsh",
                            "/assets/client/shaders/core/glass_outline_down.fsh"),
                    Map.entry(
                            "core/glass_outline_up|fsh",
                            "/assets/client/shaders/core/glass_outline_up.fsh"),
                    Map.entry(
                            "core/glass_outline|vsh",
                            "/assets/client/shaders/core/glass_outline.vsh"),
                    Map.entry(
                            "core/glow_outline|fsh",
                            "/assets/client/shaders/core/glow_outline.fsh"),
                    Map.entry(
                            "core/glow_outline|vsh",
                            "/assets/client/shaders/core/glow_outline.vsh"),
                    Map.entry("core/grayscale|fsh", "/assets/client/shaders/core/grayscale.fsh"),
                    Map.entry("core/grayscale|vsh", "/assets/client/shaders/core/grayscale.vsh"),
                    Map.entry(
                            "core/halftone_dots|fsh",
                            "/assets/client/shaders/core/halftone_dots.fsh"),
                    Map.entry(
                            "core/halftone_dots|vsh",
                            "/assets/client/shaders/core/halftone_dots.vsh"),
                    Map.entry("core/image|fsh", "/assets/client/shaders/core/image.fsh"),
                    Map.entry("core/image|vsh", "/assets/client/shaders/core/image.vsh"),
                    Map.entry(
                            "core/kawase_down|fsh", "/assets/client/shaders/core/kawase_down.fsh"),
                    Map.entry(
                            "core/kawase_down|vsh", "/assets/client/shaders/core/kawase_down.vsh"),
                    Map.entry("core/kawase_up|fsh", "/assets/client/shaders/core/kawase_up.fsh"),
                    Map.entry("core/kawase_up|vsh", "/assets/client/shaders/core/kawase_up.vsh"),
                    Map.entry(
                            "core/main_menu_grid|fsh",
                            "/assets/client/shaders/core/main_menu_grid.fsh"),
                    Map.entry(
                            "core/main_menu_grid|vsh",
                            "/assets/client/shaders/core/main_menu_grid.vsh"),
                    Map.entry("core/mask_diff|fsh", "/assets/client/shaders/core/mask_diff.fsh"),
                    Map.entry("core/mask_diff|vsh", "/assets/client/shaders/core/mask_diff.vsh"),
                    Map.entry("core/menu_rays|fsh", "/assets/client/shaders/core/menu_rays.fsh"),
                    Map.entry("core/menu_rays|vsh", "/assets/client/shaders/core/menu_rays.vsh"),
                    Map.entry("core/msdf|fsh", "/assets/client/shaders/core/msdf.fsh"),
                    Map.entry("core/msdf|vsh", "/assets/client/shaders/core/msdf.vsh"),
                    Map.entry("core/outline|fsh", "/assets/client/shaders/core/outline.fsh"),
                    Map.entry("core/outline|vsh", "/assets/client/shaders/core/outline.vsh"),
                    Map.entry("core/rect|fsh", "/assets/client/shaders/core/rect.fsh"),
                    Map.entry("core/rect|vsh", "/assets/client/shaders/core/rect.vsh"),
                    Map.entry("core/scanlines|fsh", "/assets/client/shaders/core/scanlines.fsh"),
                    Map.entry("core/scanlines|vsh", "/assets/client/shaders/core/scanlines.vsh"),
                    Map.entry(
                            "core/shader_esp_combine|fsh",
                            "/assets/client/shaders/core/shader_esp_combine.fsh"),
                    Map.entry(
                            "core/shader_esp_down|fsh",
                            "/assets/client/shaders/core/shader_esp_down.fsh"),
                    Map.entry(
                            "core/shader_esp_glow|vsh",
                            "/assets/client/shaders/core/shader_esp_glow.vsh"),
                    Map.entry(
                            "core/shader_esp_mask|fsh",
                            "/assets/client/shaders/core/shader_esp_mask.fsh"),
                    Map.entry(
                            "core/shader_esp_mask|vsh",
                            "/assets/client/shaders/core/shader_esp_mask.vsh"),
                    Map.entry(
                            "core/shader_esp_outline_combine|fsh",
                            "/assets/client/shaders/core/shader_esp_outline_combine.fsh"),
                    Map.entry(
                            "core/shader_esp_outline_down|fsh",
                            "/assets/client/shaders/core/shader_esp_outline_down.fsh"),
                    Map.entry(
                            "core/shader_esp_outline_mask|fsh",
                            "/assets/client/shaders/core/shader_esp_outline_mask.fsh"),
                    Map.entry(
                            "core/shader_esp_outline_up|fsh",
                            "/assets/client/shaders/core/shader_esp_outline_up.fsh"),
                    Map.entry(
                            "core/shader_esp_outline|vsh",
                            "/assets/client/shaders/core/shader_esp_outline.vsh"),
                    Map.entry(
                            "core/shader_esp_up|fsh",
                            "/assets/client/shaders/core/shader_esp_up.fsh"),
                    Map.entry(
                            "core/shader_sky_aurora|fsh",
                            "/assets/client/shaders/core/shader_sky_aurora.fsh"),
                    Map.entry(
                            "core/shader_sky_blur|fsh",
                            "/assets/client/shaders/core/shader_sky_blur.fsh"),
                    Map.entry(
                            "core/shader_sky_boxes|fsh",
                            "/assets/client/shaders/core/shader_sky_boxes.fsh"),
                    Map.entry(
                            "core/shader_sky_celestial|fsh",
                            "/assets/client/shaders/core/shader_sky_celestial.fsh"),
                    Map.entry(
                            "core/shader_sky_celestial|vsh",
                            "/assets/client/shaders/core/shader_sky_celestial.vsh"),
                    Map.entry(
                            "core/shader_sky_fractal|fsh",
                            "/assets/client/shaders/core/shader_sky_fractal.fsh"),
                    Map.entry(
                            "core/shader_sky_fullscreen|vsh",
                            "/assets/client/shaders/core/shader_sky_fullscreen.vsh"),
                    Map.entry("core/shader_sky|fsh", "/assets/client/shaders/core/shader_sky.fsh"),
                    Map.entry("core/shader_sky|vsh", "/assets/client/shaders/core/shader_sky.vsh"),
                    Map.entry("core/texture|fsh", "/assets/client/shaders/core/texture.fsh"),
                    Map.entry("core/texture|vsh", "/assets/client/shaders/core/texture.vsh"),
                    Map.entry(
                            "core/rect_onetap|fsh", "/assets/client/shaders/core/rect_onetap.fsh"),
                    Map.entry(
                            "core/texture_onetap|fsh",
                            "/assets/client/shaders/core/texture_onetap.fsh"),
                    Map.entry(
                            "core/texture_antialiased|fsh",
                            "/assets/client/shaders/core/texture_antialiased.fsh"));

    private ShaderCatalog() {}
}
