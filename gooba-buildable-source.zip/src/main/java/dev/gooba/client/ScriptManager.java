package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Environment(EnvType.CLIENT)
public class ScriptManager {
    private final Map<String, Script> scripts = new ConcurrentHashMap<>();

    private static Boolean alwaysTrue() {
        return true;
    }

    private static Script createScript(String text) {
        return new Script();
    }

    private static void clearScript(String text, Script script) {
        script.clear();
    }

    private static Script registerScript(String text, Script script) {
        script.clear();
        return script;
    }
}
