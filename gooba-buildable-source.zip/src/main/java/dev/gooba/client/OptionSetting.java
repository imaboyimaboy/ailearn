package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.util.List;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class OptionSetting extends Setting<String> {
    public OptionSetting(Module module, String name, String... options) {
        super(module, name, options[0]);
        this.selectionAnimation = new DecelerateAnimation(300, 1.0);
        this.options = List.of(options);
        this.setValue(options[0]);
        this.selectedOption = options[0];
    }

    public TimedAnimation selectionAnimation;
    public List<String> options;

    private String selectedOption;

    public OptionSetting visibleWhen(Supplier supplier) {
        return (OptionSetting) super.visibleWhen(supplier);
    }

    @Override
    public OptionSetting onVisibilityChanged(Runnable callback) {
        super.onVisibilityChanged(callback);
        return this;
    }

    public String getSelectedOption(int i) {
        if (this.selectedOption == null) {
            this.selectedOption = (String) super.getValue();
        }

        return this.selectedOption;
    }

    public OptionSetting setValue(String selectedOptionValue) {
        this.selectedOption = selectedOptionValue;
        return (OptionSetting) super.setValue(selectedOptionValue);
    }

    public OptionSetting onChange(Runnable runnable) {
        return (OptionSetting)
                super.onChange(
                        () -> {
                            runnable.run();
                            this.selectedOption = (String) super.getValue();
                        });
    }
}
