package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.texture.Sprite;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;

@Environment(EnvType.CLIENT)
public class HudManager {

    private static boolean previousBlendEnabled = false;
    private final RectData rectData;
    private final FontRenderer fontRenderer;
    private final TextureBatchRenderer textureBatchRenderer;
    private final CircleData circleData;
    private final BlurBatchRenderer blurBatchRenderer;

    private final OutlineData outlineData;

    private static boolean previousDepthMask = false;
    private static boolean previousDepthTestEnabled = false;
    private boolean fontsInitialized = false;

    public static void endHudRender() {
        RenderBatchDispatcher.setBatching(false);
        if (previousDepthMask) {
            GL11.glDepthMask(true);
        }

        if (previousDepthTestEnabled) {
            GL11.glEnable(2929);
        } else {
            GL11.glDisable(2929);
        }

        if (!previousBlendEnabled) {
            GL11.glDisable(3042);
        }
    }

    public RectData getRectData() {
        return this.rectData;
    }

    public static void beginHudRender() {

        RenderBatchDispatcher.setBatching(true);
        previousDepthTestEnabled = GL11.glIsEnabled(2929);
        previousDepthMask = GL11.glGetBoolean(2930);
        previousBlendEnabled = GL11.glIsEnabled(3042);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glEnable(3042);
        GL14.glBlendFuncSeparate(770, 771, 1, 771);
    }

    private void initializeFonts() {
        if (!this.fontsInitialized) {
            this.fontsInitialized = true;
            this.fontRenderer.registerFonts(Fonts.fontResources());
        }
    }

    public static void drawSprite(
            Sprite sprite, float f, float f1, float f2, float f3, int i, boolean flag) {
        if (sprite != null && f2 != 0.0F && f3 != 0.0F) {
            float f4 = flag ? 1.0F : 0.0F;
            RenderUtils.Images.drawImageRegion(
                    sprite.getAtlasId(),
                    f,
                    f1,
                    f2,
                    f3,
                    sprite.getMinU(),
                    sprite.getMinV(),
                    sprite.getMaxU(),
                    sprite.getMaxV(),
                    i,
                    f4,
                    0.0F);
        }
    }

    public void flush() {
        RenderBatchDispatcher.flush();
        this.blurBatchRenderer.flush();
        this.rectData.flush();
        this.circleData.flush();
        this.fontRenderer.flush();
    }

    public CircleData getCircleData() {
        return this.circleData;
    }

    public void close() {
        this.rectData.close();
        this.circleData.close();
        this.fontRenderer.clear();
        this.textureBatchRenderer.close();
        this.blurBatchRenderer.close();
        this.outlineData.close();
        BackgroundBlur.close();
    }

    public TextureBatchRenderer getTextureBatchRenderer() {
        return this.textureBatchRenderer;
    }

    public OutlineData getOutlineData() {
        return this.outlineData;
    }

    public FontRenderer getFontRenderer() {
        this.initializeFonts();
        return this.fontRenderer;
    }

    public HudManager() {
        this.fontRenderer = new FontRenderer();
        this.rectData = new RectData();
        this.circleData = new CircleData();
        this.outlineData = new OutlineData();
        this.blurBatchRenderer = new BlurBatchRenderer();
        this.textureBatchRenderer = new TextureBatchRenderer();
    }

    public BlurBatchRenderer getBlurBatchRenderer() {
        return this.blurBatchRenderer;
    }
}
