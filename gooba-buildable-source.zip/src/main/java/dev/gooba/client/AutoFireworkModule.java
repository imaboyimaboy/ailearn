package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

@ModuleInfo(
        name = "Auto Firework",
        category = ModuleCategory.OTHER,
        desc = "Automatically uses firework rockets while flying and restocks from inventory.")
@Environment(EnvType.CLIENT)
public class AutoFireworkModule extends Module {
    public final SliderSetting delaySetting =
            new SliderSetting(this, "Delay", 0.1F, 0.1F, 5.0F, 0.1F);
    private int sourceSlot = -1;
    private long slotReadyAtMillis;
    private int swapDelayTicks;
    private long nextUseAtMillis;
    private int swapStep;

    private int destinationSlot = -1;

    private int findLargestInventoryStack(PlayerInventory playerinventory) {
        int i = -1;
        int j = 0;

        for (int k = 9; k < 36; k++) {
            ItemStack itemstack = playerinventory.getStack(k);
            if (this.isFirework(itemstack) && itemstack.getCount() > j) {
                i = k;
                j = itemstack.getCount();
            }
        }

        return i;
    }

    @Override
    protected void onDisable() {

        this.resetSwap();
    }

    private boolean isFirework(ItemStack itemstack) {
        return itemstack != null && itemstack.isOf(Items.FIREWORK_ROCKET);
    }

    private void beginInventorySwap(int destinationSlotValue, int sourceSlotValue) {
        if (destinationSlotValue >= 0 && destinationSlotValue < 9 && sourceSlotValue >= 9) {
            this.destinationSlot = destinationSlotValue;
            this.sourceSlot = sourceSlotValue;
            this.swapStep = 1;
            this.swapDelayTicks = 0;
        }
    }

    private int toScreenSlot(int i) {
        return i < 9 ? 36 + i : i;
    }

    private void advanceInventorySwap() {
        if (this.swapDelayTicks > 0) {
            this.swapDelayTicks--;
        } else if (client.player != null && client.interactionManager != null) {
            int syncId = client.player.currentScreenHandler.syncId;
            switch (this.swapStep) {
                case 1:
                    client.interactionManager.clickSlot(
                            syncId,
                            this.toScreenSlot(this.sourceSlot),
                            0,
                            SlotActionType.PICKUP,
                            client.player);
                    this.swapStep = 2;
                    break;
                case 2:
                    client.interactionManager.clickSlot(
                            syncId,
                            this.toScreenSlot(this.destinationSlot),
                            0,
                            SlotActionType.PICKUP,
                            client.player);
                    this.swapStep = 3;
                    break;
                case 3:
                    client.interactionManager.clickSlot(
                            syncId,
                            this.toScreenSlot(this.sourceSlot),
                            0,
                            SlotActionType.PICKUP,
                            client.player);
                    long nowMillis = System.currentTimeMillis();
                    this.slotReadyAtMillis = nowMillis + 100L;
                    this.nextUseAtMillis =
                            nowMillis + (long) Math.round(this.delaySetting.getFloat() * 1000.0F);
                    this.resetSwap();
                    return;
            }

            this.swapDelayTicks = 4;
        } else {
            this.resetSwap();
        }
    }

    private int findHotbarFirework(PlayerInventory playerinventory) {
        int selectedSlot = playerinventory.getSelectedSlot();
        if (this.isFirework(playerinventory.getStack(selectedSlot))
                && playerinventory.getStack(selectedSlot).getCount() > 1) {
            return selectedSlot;
        } else {
            for (int j = 0; j < 9; j++) {
                if (this.isFirework(playerinventory.getStack(j))
                        && playerinventory.getStack(j).getCount() > 1) {
                    return j;
                }
            }

            if (this.isFirework(playerinventory.getStack(selectedSlot))) {
                return selectedSlot;
            } else {
                for (int k = 0; k < 9; k++) {
                    if (this.isFirework(playerinventory.getStack(k))) {
                        return k;
                    }
                }

                return -1;
            }
        }
    }

    @Override
    protected void onEnable() {

        this.nextUseAtMillis = 0L;
        this.slotReadyAtMillis = 0L;
        this.resetSwap();
    }

    @EventHandler
    public void onClientTick(ClientTickEvent clientTickEvent) {
        if (client.player != null
                && client.world != null
                && client.currentScreen == null
                && client.interactionManager != null) {
            if (this.swapStep != 0) {
                this.advanceInventorySwap();
            } else {
                PlayerInventory playerinventory = client.player.getInventory();
                int destinationSlotValue = this.findHotbarFirework(playerinventory);
                if (destinationSlotValue < 0) {
                    int sourceSlotValue = this.findLargestInventoryStack(playerinventory);
                    if (sourceSlotValue >= 0) {
                        this.beginInventorySwap(playerinventory.getSelectedSlot(), sourceSlotValue);
                    }
                } else if (playerinventory.getSelectedSlot() != destinationSlotValue) {
                    playerinventory.setSelectedSlot(destinationSlotValue);
                    this.slotReadyAtMillis = System.currentTimeMillis() + 100L;
                } else {
                    ItemStack itemstack = client.player.getMainHandStack();
                    if (this.isFirework(itemstack)) {
                        if (itemstack.getCount() <= 1) {
                            int sourceSlotValueValue =
                                    this.findLargestInventoryStack(playerinventory);
                            if (sourceSlotValueValue >= 0) {
                                this.beginInventorySwap(destinationSlotValue, sourceSlotValueValue);
                            }
                        } else {
                            long nowMillis = System.currentTimeMillis();
                            if (nowMillis >= this.nextUseAtMillis
                                    && nowMillis >= this.slotReadyAtMillis) {
                                client.interactionManager.interactItem(
                                        client.player, Hand.MAIN_HAND);
                                this.nextUseAtMillis =
                                        nowMillis
                                                + (long)
                                                        Math.round(
                                                                this.delaySetting.getFloat()
                                                                        * 1000.0F);
                            }
                        }
                    }
                }
            }
        }
    }

    private void resetSwap() {
        this.swapStep = 0;
        this.sourceSlot = -1;
        this.destinationSlot = -1;
        this.swapDelayTicks = 0;
    }
}
