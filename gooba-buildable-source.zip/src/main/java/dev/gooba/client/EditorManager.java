package dev.gooba.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class EditorManager {
    private static final OverlayEditor[] overlayEditors =
            new OverlayEditor[] {HandEditor.getInstance()};

    static {
    }

    public static OverlayEditor getActiveEditor() {
        for (OverlayEditor overlayEditor : overlayEditors) {
            if (overlayEditor.isActive()) {
                return overlayEditor;
            }
        }

        return null;
    }

    private EditorManager() {}
}
