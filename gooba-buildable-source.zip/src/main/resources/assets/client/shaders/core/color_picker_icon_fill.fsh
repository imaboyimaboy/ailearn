#version 330

#moj_import <minecraft:dynamictransforms.glsl>

in vec2 fragCoord;
in vec4 vertexColor;

out vec4 fragColor;

float roundedDistance(vec2 point, vec2 halfSize, float radius) {
    vec2 distance = abs(point) - halfSize + radius;
    return min(max(distance.x, distance.y), 0.0) + length(max(distance, 0.0)) - radius;
}

void main() {
    vec2 point = fragCoord * 11.0 - 5.5;
    float alpha = 1.0 - smoothstep(-0.7, 0.7, roundedDistance(point, vec2(5.0), 2.0));
    vec4 color = vertexColor * ColorModulator;
    color.a *= alpha;
    if (color.a <= 0.0) {
        discard;
    }
    fragColor = color;
}
