#version 330

#moj_import <minecraft:dynamictransforms.glsl>

in vec2 fragCoord;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    float distance = length(fragCoord * 4.0 - 2.0);
    float outer = 1.0 - smoothstep(1.35, 2.0, distance);
    float inner = 1.0 - smoothstep(0.65, 1.3, distance);
    vec4 color = vertexColor * ColorModulator;
    color.a *= outer * (1.0 - inner);
    if (color.a <= 0.0) {
        discard;
    }
    fragColor = color;
}
