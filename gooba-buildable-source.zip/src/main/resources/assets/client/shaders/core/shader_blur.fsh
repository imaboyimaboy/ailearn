#version 150

in vec2 fragCoord;
in vec2 pixelCoord;
in vec2 rectSize;
in vec4 cornerRadii;
in vec4 fragColors[9];
in float guiScale;
in float innerBlur;
in float glowSize;
in float glowStrength;
in float glowSoftness;
in vec4 glow;

out vec4 fragColor;

float roundedDistance(vec2 position, vec2 size, vec4 radius) {
    radius.xy = position.x > 0.0 ? radius.xy : radius.wz;
    radius.x = position.y > 0.0 ? radius.x : radius.y;
    vec2 value = abs(position) - size + radius.x;
    return min(max(value.x, value.y), 0.0) + length(max(value, 0.0)) - radius.x;
}

vec4 radiusOrder() {
    return vec4(cornerRadii.x, cornerRadii.w, cornerRadii.z, cornerRadii.y);
}

float roundedAlpha(vec2 size, vec2 coordinate, vec4 radius) {
    vec2 center = size * 0.5;
    float distance = roundedDistance(center - coordinate, center - 1.0, radius);
    float edge = max(fwidth(distance), 0.5 / guiScale);
    return 1.0 - smoothstep(-edge, edge, distance);
}

vec4 gradientColor(vec2 uv) {
    float x = clamp(uv.x, 0.0, 1.0);
    float y = clamp(uv.y, 0.0, 1.0);
    if (x >= y) return fragColors[0] * (1.0 - x) + fragColors[2] * (x - y) + fragColors[8] * y;
    return fragColors[0] * (1.0 - y) + fragColors[8] * x + fragColors[6] * (y - x);
}

void main() {
    vec4 radius = radiusOrder();
    vec2 center = rectSize * 0.5;
    float distance = roundedDistance(center - pixelCoord, center - 1.0, radius);
    if (glowSize > 0.001 && glowStrength > 0.0) {
        float spread = max(glowSize * max(glowSoftness, 0.05), 0.001);
        float shadow = 1.0 - smoothstep(-spread, spread, distance);
        float outside = step(0.0, distance);
        float shadowAlpha = shadow * glow.a * glowStrength * outside;
        if (shadowAlpha <= 0.001) discard;
        fragColor = vec4(glow.rgb, shadowAlpha);
        return;
    }
    vec4 color = gradientColor(fragCoord);
    color.a *= roundedAlpha(rectSize, pixelCoord, radius);
    if (color.a <= 0.001) discard;
    fragColor = color;
}
