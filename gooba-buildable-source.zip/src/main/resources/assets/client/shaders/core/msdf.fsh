#version 150

in vec2 texCoord;
in vec4 charColor;
in float outlineWidth;
in vec4 outColor;
in float pxRange;
in vec2 atlasSize;

out vec4 fragColor;

uniform sampler2D Sampler0;

float median(float r, float g, float b) {
    return max(min(r, g), min(max(r, g), b));
}

// Manual bilinear sampling to bypass engine-level nearest filtering
vec4 textureBilinear(sampler2D sampler, vec2 uv, vec2 size) {
    vec2 st = uv * size - 0.5;
    vec2 i_st = floor(st);
    vec2 f_st = fract(st);

    vec4 a = texture(sampler, (i_st + vec2(0.5, 0.5)) / size);
    vec4 b = texture(sampler, (i_st + vec2(1.5, 0.5)) / size);
    vec4 c = texture(sampler, (i_st + vec2(0.5, 1.5)) / size);
    vec4 d = texture(sampler, (i_st + vec2(1.5, 1.5)) / size);

    return mix(mix(a, b, f_st.x), mix(c, d, f_st.x), f_st.y);
}

float screenPxRange() {
    float pixelSize = length(dFdx(texCoord)) + length(dFdy(texCoord));
    if (pixelSize == 0.0) return pxRange;
    return max(pxRange / (pixelSize * max(atlasSize.x, atlasSize.y)), 1.0);
}

void main() {
    // Manually sample because Sampler0 view may be defaulted to nearest
    vec4 mtsdf = textureBilinear(Sampler0, texCoord, atlasSize);
    
    // MSDF Median
    float sd = median(mtsdf.r, mtsdf.g, mtsdf.b);
    
    // MTSDF refinement (alpha stores a tight SDF)
    sd = min(sd, mtsdf.a);

    float screenPxDist = screenPxRange() * (sd - 0.5);
    float opacity = smoothstep(-0.6, 0.6, screenPxDist);

    if (outlineWidth > 0.0) {
        float outlineDist = screenPxDist + outlineWidth;
        float outlineOpacity = smoothstep(-0.6, 0.6, outlineDist);

        vec4 fill = vec4(charColor.rgb, charColor.a * opacity);
        vec4 outline = vec4(outColor.rgb, outColor.a * max(0.0, outlineOpacity - opacity));

        fragColor = fill + outline * (1.0 - fill.a);
    } else {
        fragColor = vec4(charColor.rgb, charColor.a * opacity);
    }

    if (fragColor.a < 0.004) {
        discard;
    }
}