#version 330

#moj_import <minecraft:dynamictransforms.glsl>

in vec2 fragCoord;
in vec4 vertexColor;

out vec4 fragColor;

float roundedDistance(vec2 point, vec2 halfSize, float radius) {
    vec2 distance = abs(point) - halfSize + radius;
    return min(max(distance.x, distance.y), 0.0) + length(max(distance, 0.0)) - radius;
}

void main() {
    vec2 point = fragCoord * 56.0 - 28.0;
    float alpha = 1.0 - smoothstep(-0.7, 0.7, roundedDistance(point, vec2(27.5), 2.0));
    vec3 horizontal = mix(vertexColor.rgb, vec3(1.0), fragCoord.x);
    vec3 result = mix(horizontal, vec3(0.0), 1.0 - fragCoord.y);
    vec4 color = vec4(result, vertexColor.a) * ColorModulator;
    color.a *= alpha;
    if (color.a <= 0.0) {
        discard;
    }
    fragColor = color;
}
