#version 150

in vec2 fragCoord;
in vec2 pixelCoord;
in vec2 rectSize;
in vec4 cornerRadii;
in vec4 fragColors[9];
in float guiScale;
in float innerBlur;
in float glowSize;
in float glowStrength;
in float glowSoftness;
in vec4 glow;

out vec4 fragColor;

float rdist(vec2 pos, vec2 size, vec4 radius) {
    radius.xy = pos.x > 0.0 ? radius.xy : radius.wz;
    radius.x = pos.y > 0.0 ? radius.x : radius.y;
    vec2 value = abs(pos) - size + radius.x;
    return min(max(value.x, value.y), 0.0) + length(max(value, 0.0)) - radius.x;
}

float ralpha(vec2 size, vec2 coord, vec4 radius) {
    vec2 center = size * 0.5;
    float dist = rdist(center - coord * size, center - 1.0, radius);
    return 1.0 - smoothstep(0.0, 1.0, dist);
}

vec4 gradientColor(vec2 uv) {
    float x = clamp(uv.x, 0.0, 1.0);
    float y = clamp(uv.y, 0.0, 1.0);
    if (x >= y) {
        return fragColors[0] * (1.0 - x) + fragColors[2] * (x - y) + fragColors[8] * y;
    }
    return fragColors[0] * (1.0 - y) + fragColors[8] * x + fragColors[6] * (y - x);
}

void main() {
    vec4 radius = vec4(cornerRadii.x, cornerRadii.w, cornerRadii.z, cornerRadii.y);
    float alpha = ralpha(rectSize, fragCoord, radius);
    vec4 color = gradientColor(fragCoord);
    if (glowSize > 0.0 && glowStrength > 0.0) {
        vec2 center = rectSize * 0.5;
        float dist = rdist(center - fragCoord * rectSize, center - 1.0, radius);
        float outside = max(dist, 0.0);
        float fade = 1.0 - smoothstep(0.0, glowSize * max(glowSoftness, 0.05), outside);
        float edge = smoothstep(0.0, 1.0, dist);
        float glowAlpha = fade * edge * glow.a * glowStrength;
        if (glowAlpha == 0.0) discard;
        fragColor = vec4(glow.rgb, glowAlpha);
        return;
    }
    color.a *= alpha;
    if (color.a == 0.0) discard;
    fragColor = color;
}
