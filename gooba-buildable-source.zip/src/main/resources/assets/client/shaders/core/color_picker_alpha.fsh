#version 330

#moj_import <minecraft:dynamictransforms.glsl>

in vec2 fragCoord;
in vec4 vertexColor;

out vec4 fragColor;

float roundedDistance(vec2 point, vec2 halfSize, float radius) {
    vec2 distance = abs(point) - halfSize + radius;
    return min(max(distance.x, distance.y), 0.0) + length(max(distance, 0.0)) - radius;
}

void main() {
    vec2 point = fragCoord * vec2(4.0, 56.0) - vec2(2.0, 28.0);
    float mask = 1.0 - smoothstep(-0.7, 0.7, roundedDistance(point, vec2(1.5, 27.5), 1.0));
    vec2 pixel = fragCoord * vec2(4.0, 56.0);
    float checker = mod(floor(pixel.x / 2.0) + floor(pixel.y / 4.0), 2.0);
    vec3 checkerColor = mix(vec3(0.24), vec3(0.42), checker);
    vec3 result = mix(checkerColor, vertexColor.rgb, fragCoord.y);
    vec4 color = vec4(result, vertexColor.a) * ColorModulator;
    color.a *= mask;
    if (color.a <= 0.0) {
        discard;
    }
    fragColor = color;
}
