#version 330

#moj_import <minecraft:dynamictransforms.glsl>

in vec2 fragCoord;
in vec4 vertexColor;

out vec4 fragColor;

float roundedDistance(vec2 point, vec2 halfSize, float radius) {
    vec2 distance = abs(point) - halfSize + radius;
    return min(max(distance.x, distance.y), 0.0) + length(max(distance, 0.0)) - radius;
}

vec3 hueColor(float hue) {
    vec3 value = abs(fract(hue + vec3(0.0, 0.6666667, 0.3333333)) * 6.0 - 3.0);
    return clamp(value - 1.0, 0.0, 1.0);
}

void main() {
    vec2 point = fragCoord * vec2(4.0, 56.0) - vec2(2.0, 28.0);
    float alpha = 1.0 - smoothstep(-0.7, 0.7, roundedDistance(point, vec2(1.5, 27.5), 1.0));
    vec4 color = vec4(hueColor(1.0 - fragCoord.y), vertexColor.a) * ColorModulator;
    color.a *= alpha;
    if (color.a <= 0.0) {
        discard;
    }
    fragColor = color;
}
