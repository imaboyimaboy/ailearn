import java.io.File

data class NativeToolchain(val msvc: File, val headers: File, val libraries: File, val jdk: File) {
    val compiler: File get() = msvc.resolve("bin/Hostx64/x64/cl.exe")
    val environment: Map<String, String> get() = mapOf(
        "PATH" to compiler.parent + File.pathSeparator + System.getenv("PATH"),
        "INCLUDE" to (listOf(msvc.resolve("include")) +
            listOf("ucrt", "shared", "um", "winrt", "cppwinrt").map(headers::resolve))
            .joinToString(File.pathSeparator),
        "LIB" to listOf(msvc.resolve("lib/x64"), libraries.resolve("ucrt/x64"),
            libraries.resolve("um/x64")).joinToString(File.pathSeparator)
    )
}

fun latest(candidates: List<File>, description: String): File =
    candidates.filter(File::isDirectory).maxByOrNull { it.absolutePath }
        ?: throw GradleException("Cannot find $description.")

fun File.children(): List<File> = listFiles()?.filter(File::isDirectory).orEmpty()

fun nativeToolchain(): NativeToolchain {
    if (!System.getProperty("os.name").startsWith("Windows")) {
        throw GradleException("The native libraries require Windows x64 and MSVC.")
    }
    fun override(name: String) = providers.gradleProperty(name).orNull?.let(::file)
    val programs = listOfNotNull(System.getenv("ProgramFiles(x86)"), System.getenv("ProgramFiles"))
        .map(::File)
    val msvc = override("msvc") ?: latest(programs.flatMap { base ->
        base.resolve("Microsoft Visual Studio").children().flatMap { year ->
            year.children().flatMap { edition -> edition.resolve("VC/Tools/MSVC").children() }
        }
    }, "MSVC; install Visual Studio C++ Build Tools or set -Pmsvc=<version-directory>")
    val nuget = File(System.getProperty("user.home"), ".nuget/packages")
    val headers = override("sdkHeaders") ?: latest(
        programs.flatMap { it.resolve("Windows Kits/10/Include").children() } +
            nuget.resolve("microsoft.windows.sdk.cpp").children().flatMap { it.resolve("c/Include").children() },
        "Windows SDK headers; install the Windows SDK or set -PsdkHeaders=<version-directory>"
    )
    val libraries = override("sdkLibraries") ?: latest(
        programs.flatMap { it.resolve("Windows Kits/10/Lib").children() } +
            nuget.resolve("microsoft.windows.sdk.cpp.x64").children().map { it.resolve("c") },
        "Windows SDK libraries; install the Windows SDK or set -PsdkLibraries=<version-directory>"
    )
    val jdk = override("jdk") ?: File(System.getenv("JAVA_HOME") ?: System.getProperty("java.home"))
    listOf(msvc.resolve("bin/Hostx64/x64/cl.exe"), headers.resolve("um/Windows.h"),
        headers.resolve("cppwinrt/winrt/Windows.Media.Control.h"),
        libraries.resolve("um/x64/WindowsApp.lib"), jdk.resolve("include/jni.h")).forEach {
        if (!it.isFile) throw GradleException("Missing native build requirement: $it")
    }
    return NativeToolchain(msvc, headers, libraries, jdk)
}

val rpc = file("vendor/discord-rpc")
val media = file("vendor/media-player-info")
val output = layout.buildDirectory.dir("libs")

val compileRpc by tasks.registering(Exec::class) {
    inputs.dir(rpc)
    inputs.dir("vendor/rapidjson/include")
    outputs.file(output.map { it.file("discord-rpc.dll") })
    doFirst {
        val toolchain = nativeToolchain()
        val work = layout.buildDirectory.dir("rpc").get().asFile.apply { mkdirs() }
        output.get().asFile.mkdirs()
        workingDir(work)
        environment(toolchain.environment)
        commandLine(listOf(toolchain.compiler.absolutePath, "/nologo", "/O2", "/EHsc", "/std:c++17",
            "/DNDEBUG", "/Brepro", "/W3", "/MT", "/LD", "/DDISCORD_WINDOWS", "/DDISCORD_DYNAMIC_LIB",
            "/DDISCORD_BUILDING_SDK", "/I${rpc.resolve("include")}", "/I${rpc.resolve("src")}",
            "/I${file("vendor/rapidjson/include")}") +
            listOf("discord_rpc.cpp", "rpc_connection.cpp", "serialization.cpp", "connection_win.cpp",
                "discord_register_win.cpp", "dllmain.cpp").map { rpc.resolve("src/$it").absolutePath } +
            listOf("/link", "/Brepro", "/DYNAMICBASE", "/NXCOMPAT",
                "/OUT:${output.get().file("discord-rpc.dll").asFile}", "advapi32.lib", "psapi.lib"))
    }
}

val compileMedia by tasks.registering(Exec::class) {
    inputs.dir(media.resolve("native"))
    outputs.file(output.map { it.file("MediaPlayerInfo.dll") })
    doFirst {
        val toolchain = nativeToolchain()
        val work = layout.buildDirectory.dir("media").get().asFile.apply { mkdirs() }
        output.get().asFile.mkdirs()
        workingDir(work)
        environment(toolchain.environment)
        commandLine(toolchain.compiler.absolutePath, "/nologo", "/O2", "/EHsc", "/std:c++17",
            "/DNDEBUG", "/Brepro", "/W3", "/MD", "/LD", "/I${toolchain.jdk.resolve("include")}",
            "/I${toolchain.jdk.resolve("include/win32")}", media.resolve("native/main.cpp").absolutePath,
            "/link", "/Brepro", "/DYNAMICBASE", "/NXCOMPAT",
            "/OUT:${output.get().file("MediaPlayerInfo.dll").asFile}", "WindowsApp.lib")
    }
}

tasks.register("buildNative") {
    group = "build"
    description = "Build the Windows x64 Discord RPC and media DLLs."
    dependsOn(compileRpc, compileMedia)
}
