package krispy.feature;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import krispy.event.EventListener;
import krispy.event.events.Render3DEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.setting.BooleanSetting;
import krispy.module.setting.NumberSetting;
import krispy.utils.EncryptedString;
import krispy.utils.RenderUtils;
import krispy.utils.RenderVisibility;
import krispy.utils.Utils;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class PlayerEspModule extends Module {
   private final NumberSetting alpha;
   private final NumberSetting lineWidth;
   private final BooleanSetting tracers;
   private final List<RenderUtils.ColoredBox> renderBoxes = new ArrayList<>();
   private final List<RenderUtils.ColoredLine> renderLines = new ArrayList<>();

   public PlayerEspModule() {
      super(EncryptedString.of("Player ESP"), EncryptedString.of("Renders players through walls"), -1, Category.RENDER);
      this.alpha = new NumberSetting(EncryptedString.of("Alpha"), 0.0, 255.0, 100.0, 1.0);
      this.lineWidth = new NumberSetting(EncryptedString.of("Line width"), 1.0, 10.0, 1.0, 1.0);
      this.tracers = new BooleanSetting(EncryptedString.of("Tracers"), false)
         .setDescription(EncryptedString.of("Draws a line from the camera to each player"));
      this.addSettings(this.alpha, this.lineWidth, this.tracers);
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (this.mc.world == null || this.mc.player == null) {
         return;
      }
      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }

      Vec3d cameraPosition = camera.getCameraPos();
      float tickProgress = camera.getLastTickProgress();
      MatrixStack matrices = event.matrixStack;
      matrices.push();
      RenderUtils.applyCameraTransform(matrices, camera);
      this.renderBoxes.clear();
      this.renderLines.clear();
      Vec3d tracerStart = this.getTracerStart(camera, cameraPosition);
      int playerIndex = 0;

      for (PlayerEntity player : this.mc.world.getPlayers()) {
         if (player == this.mc.player || player.isRemoved() || !player.isAlive()) {
            continue;
         }
         Vec3d position = player.getLerpedPos(tickProgress);
         float halfWidth = player.getWidth() * 0.5F;
         double minX = position.x - halfWidth;
         double minY = position.y;
         double minZ = position.z - halfWidth;
         double maxX = position.x + halfWidth;
         double maxY = position.y + player.getHeight();
         double maxZ = position.z + halfWidth;
         if (!this.tracers.getValue() && !RenderVisibility.box(minX, minY, minZ, maxX, maxY, maxZ)) {
            playerIndex++;
            continue;
         }

         Color color = Utils.getMainColor(this.alpha.getIntValue(), playerIndex++).brighter();
         this.renderBoxes.add(new RenderUtils.ColoredBox(minX, minY, minZ, maxX, maxY, maxZ, color));
         if (this.tracers.getValue()) {
            Vec3d target = position.add(0.0, player.getHeight() * 0.5, 0.0);
            Color tracerColor = Utils.getMainColor(255, playerIndex);
            this.renderLines.add(new RenderUtils.ColoredLine(
               tracerStart, target, tracerColor, (float)this.lineWidth.getIntValue()
            ));
         }
      }

      RenderUtils.renderFilledBoxes(matrices, this.renderBoxes);
      if (this.tracers.getValue()) {
         RenderUtils.renderLines(matrices, this.renderLines);
      }
      matrices.pop();
   }

   private Vec3d getTracerStart(Camera camera, Vec3d cameraPosition) {
      return RenderUtils.getTracerStart(camera);
   }
}
